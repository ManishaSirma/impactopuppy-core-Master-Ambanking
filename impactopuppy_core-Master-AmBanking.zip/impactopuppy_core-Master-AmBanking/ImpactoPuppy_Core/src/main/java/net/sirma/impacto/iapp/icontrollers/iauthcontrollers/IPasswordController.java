/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1 	       | Bhuvi 		| Feb 24, 2019  | #BHU00001   | Initial writing
      |0.3.14.283  | Syed 		| Jun 11, 2019 | #MAQ00018  | Password History
      |0.3.14.285  | Syed 		| Jun 11, 2019 | #MAQ00019  | Password Policy
      |0.3.14.327  | Bhuvi 		| Jul 29, 2019 | #BHUVI002  | Send Notification on password change and reset
      |0.4.1.367   | Bhuvi 		| Aug 29, 2019 | #BHUVI003  | Is current version Added


      ----------------------------------------------------------------------------------------------
      
*/

package net.sirma.impacto.iapp.icontrollers.iauthcontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.google.gson.JsonArray; //MAQ00018
import com.google.gson.JsonObject;
import com.google.gson.internal.LinkedTreeMap;

import net.sirma.impacto.iapp.ialgo.RSAAsymetricCrypt;
import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IpasscodeController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;

public class IPasswordController {

// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(ILogoutController.class); // Nye- Change Class Name
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private RSAAsymetricCrypt i$RSA = new RSAAsymetricCrypt();
	private IpasscodeController i$Pass = new IpasscodeController();//#NYE00048
	@Autowired
	private AuthenticationManager authenticationManager;

// **********************************************************************//
	
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			if(SOpr.equalsIgnoreCase("RESET"))
			{
				isonMsg=resetPassword(isonMsg);
				
			}
			if(SOpr.equalsIgnoreCase("CHANGE"))
			{
				isonMsg=changePassword(isonMsg);
			}
			
		}catch(Exception e)
		{
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
			
		}
		return isonMsg;
	}
																							
 private JsonObject changePassword(JsonObject isonMsg)
 {
	 try
	 {
		 JsonObject i$body = isonMsg.getAsJsonObject("i-body");
		 String username = i$impactoUtil.decryptPkey(i$body.get("username").getAsString());
//		 String ipassCode = i$impactoUtil.decryptPkey(i$body.get("ipassCode").getAsString());
		 String password = i$impactoUtil.decryptPkey(i$body.get("password").getAsString());
		 String getPass=i$RSA.decryptText(i$body.get("newPassword").getAsString());
		 String CollName = ("ICOR_M_USER_PRF");
		 JsonObject Jfilter = new JsonObject();
		 //MAQ00018 starts
		 JsonObject i$PassHist = db$Ctrl.db$GetRow("ICOR_M_PASSWORD_HISTORY", "{'userId': "+username +"}","{'_id':0}");
		 JsonObject J$userdet = db$Ctrl.db$GetRow("ICOR_M_PWD_PLCY", "{}");
		 //MAQ00018 ends
		 Jfilter.addProperty("userId", username);
		 JsonObject icorMUserPrf = db$Ctrl.db$GetRow(CollName, Jfilter.toString());
		 if (icorMUserPrf == null) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER NOT FOUND");
				return isonMsg;
		 }
		 
			String sLogipassCodeReq = null;
			String sLoginCapReq = null;
            
			try {
				sLogipassCodeReq = i$ResM.getGobalValJObj("srcJson").get("LoginipassCode").getAsString();
			} catch (Exception E) {
				sLogipassCodeReq = "Y";
			}
			;
			try {
				sLoginCapReq = i$ResM.getGobalValJObj("srcJson").get("LoginCaptcha").getAsString();
			} catch (Exception E) {
				sLoginCapReq = "Y";
			}
		 
//				if (I$utils.$iStrFuzzyMatch(sLogipassCodeReq, "Y")) { // #NYE00048 Comments
//					try {
//						if (!i$Pass.Verify$PassCode(ipassCode)) {
//							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//									"PASSWORD CHANGED FAILED - INVALID OR UNKNOWN USER KEY");
//							return isonMsg;
//						}
//					} catch (Exception Ex) {
//
//						Ex.printStackTrace();
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//								"PASSWORD CHANGED FAILED - INVALID OR UNKNOWN USER KEY");
//						return isonMsg;
//					}
//				}

			if (I$utils.$iStrFuzzyMatch(sLoginCapReq, "Y")) 
			{
				try {
					String secCode = i$body.get("secCode").getAsString();
					String captchaID = i$body.get("captchaID").getAsString();
					if (I$utils.$iStrBlank(secCode) || I$utils.$iStrBlank(captchaID)
							|| db$Ctrl.db$GetRowCnt("ICOR_S_CAPTCHA_VALIDATOR",
									"{ secCode: \"" + secCode + "\", captchaID: \"" + captchaID + "\" }") < 1) {
						if (I$utils.$iStrFuzzyMatch(secCode, "")) {

							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"AUTHENTICATION FAILED : INVALID CAPTCHA");
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "PASSWORD CHANGED FAILED : INVALID CAPTCHA");
				}
			}
			try
			{
			String userPassDecrypt = password;// #BHVUVI002 Added
			String currPassEncypt=icorMUserPrf.get("userPwd").getAsString();
			userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt,icorMUserPrf.get("salt").getAsString());
			
			if(!I$utils.$iStrFuzzyMatch(userPassDecrypt,currPassEncypt))
			{
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CURRENT PASSWORD MATCH FAILED");
				return isonMsg;
			}
			
			//MAQ00018 starts
			Boolean passMatch = i$impactoUtil.checkPassHist(getPass, i$PassHist, J$userdet);
			
			if(passMatch == true) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "This Password has already been used");
				return isonMsg;
			}
			//MAQ00018 ends	
			//MAQ00019 starts
			Boolean passPolicyMet = i$impactoUtil.checkPassPolicy(getPass, J$userdet);
			
			if(passPolicyMet == false) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg.get("i-body").getAsJsonObject(),"policy",J$userdet);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Password does not meet Policy Requirements");
				return isonMsg;
			}
			//MAQ00019 ends
			}
			catch(Exception e)
			{
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CURRENT PASSWORD MATCH FAILED", e.getMessage().toString());
				e.printStackTrace();
				return isonMsg;
			}
			
		    String StrGetSalt=i$impactoUtil.getSalt(30);
			String StrEncrytPass=i$impactoUtil.generateSecurePassword(getPass, StrGetSalt);			
			db$Ctrl.db$StorePassHist(StrGetSalt,StrEncrytPass,i$PassHist,username); // #MAQ00018 
		
			JsonObject i$Doc = new JsonObject();
			i$Doc.addProperty("userPwd", StrEncrytPass);
			i$Doc.addProperty("salt", StrGetSalt);
			i$Doc.addProperty("ForcePasswordChange", "N");
			i$Doc.add("LastPasswordChange", i$ResM.adddate(new Date()));

			db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF", i$Doc, Jfilter, "true");
			Jfilter.addProperty("isCurrVer", "Y");// #BHUVI003 
			db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF_LEDGER", i$Doc, Jfilter, "true");
            
			sendNotification(icorMUserPrf,isonMsg);// #BHVUVI002 Added
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PASSWORD RESET SUCCESSFULLY");	 
		 
	 }catch(Exception e)
	 {
		isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
		e.printStackTrace();
		return isonMsg;
	 }
 
	return isonMsg; 
 }
	
 private JsonObject resetPassword(JsonObject isonMsg)
 {
	 try
	 {      JsonObject i$body = isonMsg.getAsJsonObject("i-body");
	        String username = i$impactoUtil.decryptPkey(i$body.get("username").getAsString());
	        String newPassword=i$RSA.decryptText(i$body.get("newPassword").getAsString());
	        String Password=i$RSA.decryptText(i$body.get("newPassword").getAsString());
	        String CollName = ("ICOR_M_USER_PRF");
			JsonObject Jfilter = new JsonObject();
	        Jfilter.addProperty("userId", username);
			JsonObject icorMUserPrf = db$Ctrl.db$GetRow(CollName, Jfilter.toString());
			if (icorMUserPrf == null) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER NOT FOUND");
				return isonMsg;
			}
	        
	        if(!Password.equals(newPassword))
	        {
	        	isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "NEW PASSWORD AND CONFIRM PASSWORD DOESNOT MATCH");
	        	return isonMsg;
	        }
	       //MAQ00019 starts
	        JsonObject J$userdet = db$Ctrl.db$GetRow("ICOR_M_PWD_PLCY", "{}");
			Boolean passPolicyMet = i$impactoUtil.checkPassPolicy(newPassword, J$userdet);
			
			if(passPolicyMet == false) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg.get("i-body").getAsJsonObject(),"policy",J$userdet);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Password does not meet Policy Requirements");
				return isonMsg;
			}
			//MAQ00019 ends
	        
			Jfilter = new JsonObject();
			Jfilter.addProperty("userId", username);
		 
		    
			String StrGetSalt=i$impactoUtil.getSalt(30);
			String StrEncrytPass=i$impactoUtil.generateSecurePassword(newPassword, StrGetSalt);
			// #MAQ00018 starts
			JsonObject i$PassHist = db$Ctrl.db$GetRow("ICOR_M_PASSWORD_HISTORY", "{'userId': "+username +"}","{'_id':0}");
			db$Ctrl.db$StorePassHist(StrGetSalt,StrEncrytPass,i$PassHist,username);
			// #MAQ00018 ends
		
			JsonObject i$Doc = new JsonObject();
			i$Doc.addProperty("userPwd", StrEncrytPass);
			i$Doc.addProperty("salt", StrGetSalt);
			i$Doc.addProperty("ForcePasswordChange", "N");
			i$Doc.add("LastPasswordChange", i$ResM.adddate(new Date()));

			db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF", i$Doc, Jfilter, "true");
			Jfilter.addProperty("isCurrVer", "Y");// #BHUVI003 
			db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF_LEDGER", i$Doc, Jfilter, "true");

			sendNotification(icorMUserPrf,isonMsg);// #BHVUVI002 Added
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PASSWORD RESET SUCCESSFULLY");	  
		 

	 }catch(Exception e)
	 {
		 isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
	 }
	return isonMsg;
 }
//#BHUVI002 Start

	public void sendNotification(JsonObject icorMUserPrf, JsonObject isonMsg) {
		ISmsService I$ISmsService = new ISmsService();
		IWhatsupService I$Whatsapp = new IWhatsupService();
		IEmailService i$Email = new IEmailService();

		try {
			String strTempName =  i$ResM.getOpr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(strTempName, "RESET")) {
				strTempName = "TMPL#TT#AS#PSWDRESETESUCES";//#YPR00066 Changes
			}
			else 
				strTempName = "TMPL#TT#AS#PSWDCHNGESUCES";//#YPR00066 Changes
			
			JsonObject argJson = new JsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject to$emailIds = new JsonObject();
			JsonObject $mobNum = new JsonObject();
			JsonObject $whatsappNumbers = new JsonObject();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendMailOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("EmpMail")) {
					to$emailIds.addProperty("toemailid1", icorMUserPrf.get("EmpMail").getAsString());
					argJson.add("toemailIds", to$emailIds);
					map$Data.addProperty("FullName", icorMUserPrf.get("name").getAsString());
					map$Data.addProperty("tmp$name", strTempName);
					argJson.add("map$Data", map$Data);
					i$Email.sendEmail(argJson);

				}
			}

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendSmsOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("MobNum") && icorMUserPrf.has("IsdMobNum")) {
					$mobNum.addProperty("Mob_Number1", icorMUserPrf.get("IsdMobNum").getAsString()
							.concat(icorMUserPrf.get("MobNum").getAsString()));
				}
				argJson.add("mobile$numbers", $mobNum);
				map$Data.addProperty("FullName", icorMUserPrf.get("name").getAsString());
				map$Data.addProperty("tmp$name", strTempName);
				argJson.add("map$Data", map$Data);
				I$ISmsService.sendSMS(argJson);

			}

			if (I$utils.$iStrFuzzyMatch(commMode.get("iWhatsUpOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("WhtsAppNum") && icorMUserPrf.has("IsdWhtsAppNum")) {
					$whatsappNumbers.addProperty("Whatsapp_Numbers1", icorMUserPrf.get("IsdWhtsAppNum").getAsString()
							.concat(icorMUserPrf.get("WhtsAppNum").getAsString()));
				} else {
					if (icorMUserPrf.has("MobNum") && icorMUserPrf.has("IsdMobNum")) {
						$whatsappNumbers.addProperty("Whatsapp_Numbers1", icorMUserPrf.get("IsdMobNum").getAsString()
								.concat(icorMUserPrf.get("MobNum").getAsString()));
					}
				}
				argJson.add("mobile$numbers", $whatsappNumbers);
				map$Data.addProperty("FullName", icorMUserPrf.get("name").getAsString());
				map$Data.addProperty("tmp$name", strTempName);
				argJson.add("map$Data", map$Data);
				I$Whatsapp.sendWhatsup(argJson);

			}

		} catch (Exception e) {
			e.getMessage();
		}
		// #BHUVI002 Ends
	}
}
