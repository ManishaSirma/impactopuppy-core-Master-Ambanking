/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Oct 9, 2018  | #BVB00006   | Added new functions 
      |0.1 Beta    | Vijay 		| Oct 15, 2018 | #BVB00007   | Development fix for User roles -- Need to be removed for prod 
      |0.1 Beta    | Vijay 		| Nov 27, 2018 | #BVB00015   | Code for Getting All function rights a User has.			
      |0.1 Beta    | Vijay 		| Dec 01, 2018 | #BVB00017   | Issue for Running Filter Creation 
      |0.1 Beta    | Vijay 		| Dec 09, 2018 | #BVB00020   | 1) Reflection code removed as deployment failing in some cases. 
      														   2) Added new functions for framework extension  
      |0.1.6       | Vijay 		| Dec 14, 2018 | #BVB00029   | 1) Added new functions for Update, Insert, Count with isonMsg 2) HasRights functions issues fix          														   
      |0.1.7       | Niegil		| jan 09, 2019 | #00000002   | GridFS Upload Code    
      |0.1.7       | Vijay		| jan 09, 2019 | #BVB00034   | DB Controller Code for GETROW variation         
      |0.1 7       | Niegil 	| Jan 15, 2019 | #00000003   | Source Code Validation FrameWork Changes      														   
      |0.1 7       | Niegil 	| Jan 16, 2019 | #00000004   | Added Sort Option for Mongo Query
      |0.2.1       | Syed	 	| Jan 21, 2019 | #MAQ00001   | Added db$getRowAgg() with skip and limit
      |0.2.1       | Syed	 	| Jan 24, 2019 | #MAQ00002   | Added  db$GetAggregate() from iBridge
      |0.2.1       | Syed	 	| Jan 31, 2019 | #MAQ00003   | Added  db$GetRows() overloaded function 
      |0.2.1       | Vijay 		| Feb 01, 2019 | #BVB00047   | Ambassador banking Login Rights  
      |0.2.1       | Syed	 	| Feb 06, 2019 | #MAQ00004   | Added active filter
      |0.2.1       | Niegil 	| Feb 07, 2019 | #NYE00004   | Frm Changes for SEQ Gen
      |0.2.1       | Vijay 		| Feb 14, 2019 | #BVB00058   | GetRow function with Object Id
      |0.2.1       | Vijay 		| Feb 14, 2019 | #BVB00074   | db$GetRows with String filters. Acquire and Release attached to Session ID
      |0.2.1       | Vijay 		| Feb 14, 2019 | #BVB00081   | User Validity Check
      |1.0         | MAQ 		| Mar 08, 2019 | #MAQ00005   | Added db$GetRowCnt() with JsonObject filter db$GetRowCnt
      |0.2.1       | Vijay 		| Mar 17, 2019 | #BVB00097   | Getting Branch access of users
      |0.2.1       | Vijay 		| Feb 09, 2019 | #BVB00052   | UpdateMany Functions
      |0.3.3       | Syed 		| Apr 06, 2019 | #MAQ00005   | Added Sorting function for all Summary pages
      |0.3.6       | Vijay 		| Apr 17, 2019 | #BVB00119   | Release And Acquire Feature Release & Checking if self user is logged In, Adding release with ID   
      |0.3.2.202   | Syed 		| Apr 08, 2019 | #MAQ00009   | Changed GET$COUNT function for Summary calls
      |0.3.2.202   | Syed 		| Apr 09, 2019 | #MAQ00010   | Added condition to check if Role is active for Func Access
      |0.3.2.202   | Syed 		| May 06, 2019 | #BZ000001   | Added check for role as queue access
      |0.3.6       | Vijay  	| Apr 26, 2019 | #BVB00129   | Fix for QueAccess Function. Earlier it was array. It is Object 
      |0.3.7       | Vijay  	| May 04, 2019 | #BVB00139   | Refining the Function Access to return a combined response 
      |0.3.7       | Vijay  	| May 04, 2019 | #BVB00140   | Adding function for aggregate which will accept as it is List
      !0.3.7       | Baz      	| May 06, 2019 | #BZ000042   | Changed db$hasQuOprRights for Including Role as Queue Access
      !0.3.7       | Baz      	| May 07, 2019 | #BZ000041   | changed DBhasQRights for Role as Queue access
      |0.3.11.262  | Syed 		| May 28, 2019 | #MAQ00014   | Changing modifyAccess function according to framework
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes 
      |0.3.14.283  | Syed 		| Jun 11, 2019 | #MAQ00018   | Password History
      |0.3.14.283  | Bhuvi 		| Jun 19, 2019 | #BHUVI001   | Added skip Absolute to skip manually 
      |0.3.14.283  | Bhuvi 		| Jun 19, 2019 | #BHUVI002   | Added bulk update by passing Array with where condition($in) 
      |0.3.17      | Vijay 		| Jul 20, 2019 | #BVB00186   | Joint Partner Details
      |0.3.14.327  | Bhuvi 		| Jul 25, 2019 | #BHUVI003   | Added get distinct from db
	  |0.3.16.338  | Syed       | Aug 06, 2019 | #MAQ000025  | Adding multiple Restrictions for CBS_E_DATA
	  |0.3.17      | Vijay      | Aug 14, 2019 | #BVB00199   | Accounts pulling issue in transactions 
      |3.2.5.446   | Pruthvi    | Mar 09, 2020 | #YPR00001   | update function for $addToSet modifier
      |3.2.5.446   | Pruthvi    | Mar 12, 2020 | #YPR00002   | update function for $push modifier
      |3.2.5.446   | Pappu      | Mar 06, 2021 | #PKY00002   | Code for show DataBase Connection failed if connection not establish.
      |4.2 Beta    | Pappu      | Jun 23 2021  | #PKY00017   | written a function to fetch data related to customerNo 
      |4.3         | Syed       | Jun 23 2021  | #MAQ00122   | Added code for verifyotp max count 3
      |4.4         | Sushmita   | Jun 30 2021  | #SKP0001    | Added code for verifyotp after success
      |4.5         | Sushmita   | Jul 05 2021  | #SKP0002    | Changed projection to integer to get the record
      |4.5         | Pappu      | Aug 02 2021  | #PKY00034   | Added condition to handle AccountClassType
      |4.5         | Samadhan   | Sep 01 2021  | #SRP00019   | Added Condition for FD Accounts
      |4.5 		   | Manikanta  | Mar 08 2022  | #MVT00040   | Added code to upload scanned files
      |4.5		   | Manikanta  | Mar 08 2022  | #MVT00042   | Added code to download the scanned files
      |4.5		   | Manikanta  | Feb 23 2023  | #MVT00107   | Added code to handle 155 CustomerAccountClass in account data
      |4.5		   | Sumit      | Aug 02 2023  | #SKG00017   | Added code for preview the documents history reflecting multiple times
      |4.5		   | Sumit      | Aug 17 2023  | #SKG00022   | Added code for Sharing, Downloading, Editing, Verifying the documents in Manuel Workspace, but the history is showing different statement.
      |4.5		   | Sumit      | Aug 18 2023  | #SKG00023   | Added code for Sharing history
      |4.5		   | Sumit      | Aug 19 2023  | #SKG00024   | Added code for Verifying history
      |4.5		   | Sumit      | Aug 24 2023  | #SKG00025   | Added code for  google drive  history
      |4.5		   | Sumit      | Aug 25 2023  | #SKG00026   | Added code for  aperture service request not showing user name 
      |4.5		   | Sumit      | Aug 29 2023  | #SKG00027   | Added code for  FAVOURITE & UNFAVOURITE history
      |0.5         | karthik    | Aug 31 2023  | #NK00010    | Added code for validation of filekey in trash module
      |4.5		   | Sumit      | Sep 29 2023  | #SKG00031   | Added code for  cif id instead of name in Loan Application , Lincu , Payroll, FCIP, FIP
      |4.5		   | Sumit      | Sep 29 2023  | #SKG00032   | Added code for  folder info history
      |4.5		   | Sumit      | Nov 07 2023  | #SKG00036   | Added code for  history
      |4.5		   | Srikanth   | Jan 12 2024  | #SRI00030   | Added code for  projection
      |4.5		   | Srikanth   | Mar 06 2024  | #SRI00039   | Added code for  db$GetRows function
      |4.5		   | Srikanth   | Mar 11 2024  | #SRI00042   | Added code for  db$GetRows$Sort function
  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins

package net.sirma.impacto.iapp.icontrollers.idbcontollers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.idbworkers.ImongoWorker;
import org.apache.commons.lang.StringUtils;

public class DBController {
	private Logger logger = LoggerFactory.getLogger(DBController.class);
	
	// #BVB00020 Starts
	/*
	 * private final String strClassPrefix =
	 * "net.sirma.impacto.iapp.iworkers.idbworkers.I"; private final String
	 * strClassSuffix = "Worker"; private final String dbConnectiontype =
	 * PropLoader.env.getProperty("impacto.db.type"); private final String
	 * dbClassName = strClassPrefix + dbConnectiontype.toLowerCase() +
	 * strClassSuffix;
	 */

	// #BVB00020 Ends
	IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	public JsonObject db$GetRow(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};

	// ##BVB00006 Starts
	public JsonObject db$GetRow(String CollName, JsonObject Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};

	// #00000002 Begins

	public JsonObject db$GrdFSDwld(JsonObject isonMsg) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "fs.files");
			if (I$utils.$iStrFuzzyMatch(i$ResM.getOpr2(isonMsg), "base64"))
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GrdFSDwldB24");
			else
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GrdFSDwld");
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	//#MVT00042 starts
	public JsonObject db$GrdFSScanDwld(JsonObject isonMsg) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "fs.files");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GrdFSScanDwld");
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	//#MVT00042 ends
	public JsonObject db$GrdFSUpld(JsonObject isonMsg) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "fs.files");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GrdFSUpld");
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$MultiGrdFSUpld(JsonObject isonMsg) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "fs.files");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "MultiGrdFSUpld");
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	
	
	public JsonObject db$GrdFSReqUpld(JsonObject isonMsg) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "fs.files");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GrdFSReqUpld");
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	//#MVT00040 starts
	public JsonObject db$GrdFSScanUpld(JsonObject isonMsg) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "fs.files");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GrdFSScanUpld");
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	//#MVT00040 ends
	// #00000002 Ends

	public JsonObject db$GetRow(String CollName, String Jfilter, String projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00034 Starts
	public JsonObject db$GetRow(String CollName, String Jfilter, JsonObject projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00034 Ends

	public JsonObject db$GetRow(String CollName, JsonObject Jfilter, JsonObject projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};

	// #00000004 Adds Sort to Get Rows - Begins

	public JsonArray db$GetRows$Sort(String CollName, String Jfilter, String Sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", Sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetRows$Sort(String CollName, String Jfilter, String projection, String Sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", Sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetRows$Sort(String CollName, JsonObject projection, JsonObject sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};
	
	//SRI00042 Changes Starts 
	public JsonArray db$GetRows$Sort(String CollName,JsonObject Jfilter, JsonObject projection, int skip, int limit,JsonObject sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};
	//SRI00042 Changes Ends 

	public JsonArray db$GetRows$Sort(String CollName, JsonObject Jfilter, JsonObject projection, JsonObject sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetRows$Sort(String CollName, String Jfilter, int skip, int limit, String Sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", Sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetRows$Sort(String CollName, JsonObject filter, JsonObject projection, int skip, int limit,
			String Sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", filter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", Sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetRows$Sort(String CollName, String filter, JsonObject projection, int skip, int limit,
			JsonObject Sort) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", filter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sort", Sort);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #00000004 Add Sort to Get Rows - Ends

	public JsonArray db$GetRows(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};
	// #SRI00039 Starts
	public JsonArray db$GetRows(String CollName, String Jfilter, String projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};
	// #SRI00039 Ends
	// #BVB00020 Starts
	public JsonArray db$GetRows(String CollName, JsonObject projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetRows(String CollName, JsonObject Jfilter, JsonObject projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00020 Ends
	// #BVB00074 Starts
	public JsonArray db$GetRows(String CollName, String Jfilter, JsonObject projection) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00074 Ends
	public JsonObject db$GetRows(String CollName, String Jfilter, int skip, int limit) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00006 Ends
	public JsonObject db$GetRows(String CollName, String Jfilter, String projection, int skip, int limit) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00020 Starts

	public JsonObject db$GetRows(String CollName, JsonObject filter, JsonObject projection, int skip, int limit) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", filter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00020 Ends

	@SuppressWarnings("null")
	public JsonObject db$ReleaseRow(String recID) {
		JsonParser parser = new JsonParser();
		JsonObject filter = new JsonObject();
		try {
			// Going to Release Record
			// #BVB00074 Starts
			filter.addProperty("ReqID", recID);
			// filter.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
			// #BVB00074 Ends
			db$Remove("ICOR_M_ID_ACQ", filter);

			return i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_SUCC,
					"RECORD SUCESSFULLY RELEASE");
		} catch (Exception e) {
			logger.error("Failed to Release Row " + e.getMessage());
			e.printStackTrace();
			return i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
					"FAILED TO RELEASE ROW");
		}
	};

	// #BVB00119 Starts
	public JsonObject db$ReleaseRow(JsonObject recID) {
		JsonParser parser = new JsonParser();
		JsonObject filter = new JsonObject();
		String recIDS = "";
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		try {
			// Going to Release Record
			// #BVB00074 Starts
			try {
				// i$Match = i$ResM.getMatch(isonMsg);
				// recID = i$Match.get("_id").getAsString();

				recIDS = i$ResM.convertId(recID);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Failed to Get _id Match", e);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID RECORD ID", e.getMessage().toString());
			}
			;
			filter.addProperty("ReqID", recIDS);
			// filter.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
			// #BVB00074 Ends
			db$Remove("ICOR_M_ID_ACQ", filter);

			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD SUCESSFULLY RELEASE");
		} catch (Exception e) {
			logger.error("Failed to Release Row " + e.getMessage());
			e.printStackTrace();
			return i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
					"FAILED TO RELEASE ROW");
		}
	};

	public JsonObject db$ReleaseRowS(String scrId, JsonObject Jfilter) { // #BVB00167
		JsonParser parser = new JsonParser();
		JsonObject filter = new JsonObject();
		String recID = null;
		JsonObject recIdObject = null;
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		JsonObject projection = new JsonObject(); // #BVB00167
		try {
			// Going to Release Record
			// #BVB00074 Starts
			String CollName = "";
			String LCollName = "";
			filter.addProperty("SCRID", scrId);
			projection.addProperty("SCRID", 1);
			projection.addProperty("COLLNAME", 1);
			projection.addProperty("L_COLLNAME", 1);

			JsonObject isonMapJson = db$GetRow("ICOR_C_SCR_COLL_MAP", filter, projection);
			// String scrId = isonMapJson.get("SCRID").getAsString();
			try {
				// i$Match = i$ResM.getMatch(isonMsg);
				// recID = i$Match.get("_id").getAsString();
				// Get the globals, get from master first, if it is empty, then go to Ledger.

				CollName = isonMapJson.get("COLLNAME").getAsString();
				LCollName = isonMapJson.get("L_COLLNAME").getAsString();
				JsonObject rec = db$GetRow(LCollName, Jfilter);
				if (I$utils.$isNull(rec)) {
					rec = db$GetRow(CollName, Jfilter);
				}
				recIdObject = rec.getAsJsonObject("_id");
				recID = i$ResM.convertId(recIdObject);

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Failed to Get _id Match", e);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED DUE TO MISSING IMATCH ANNOTE",
						e.getMessage().toString());
			}
			;
			filter = new JsonObject();
			filter.addProperty("ReqID", recID);

			// filter.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
			// #BVB00074 Ends
			db$Remove("ICOR_M_ID_ACQ", filter);

			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD SUCESSFULLY RELEASE");
		} catch (Exception e) {
			logger.error("Failed to Release Row " + e.getMessage());
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RELEASE ROW");
		}
	};

	// #BVB00119 Ends

	public JsonObject db$ReleaseRowC(String CollName, JsonObject Jfilter, String userId) {// #BVB00167
		JsonParser parser = new JsonParser();
		JsonObject filter = new JsonObject();
		String recID = null;
		JsonObject recIdObject = null;
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		try {
			// Going to Release Record
			// #BVB00074 Starts
			try {
				// i$Match = i$ResM.getMatch(isonMsg);
				// recID = i$Match.get("_id").getAsString();
				JsonObject rec = db$GetRow(CollName, Jfilter);
				recIdObject = rec.getAsJsonObject("_id");
				recID = i$ResM.convertId(recIdObject);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Failed to Get _id Match", e);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID RECORD ID", e.getMessage().toString());
			}
			;
			filter.addProperty("ReqID", recID);
			filter.addProperty("acquiredBy", userId);
			// #BVB00074 Ends
			db$Remove("ICOR_M_ID_ACQ", filter);

			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD SUCESSFULLY RELEASE");
		} catch (Exception e) {
			logger.error("Failed to Release Row " + e.getMessage());
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RELEASE ROW");
		}
	};

	// #BVB00167 Starts
	public JsonObject db$ReleaseRowS(String scrId, JsonObject Jfilter, String userId) {
		JsonParser parser = new JsonParser();
		JsonObject filter = new JsonObject();
		String recID = null;
		JsonObject recIdObject = null;
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		JsonObject projection = new JsonObject();
		try {
			// Going to Release Record
			// #BVB00074 Starts
			String CollName = "";
			String LCollName = "";
			filter.addProperty("SCRID", scrId);
			projection.addProperty("SCRID", 1);
			projection.addProperty("COLLNAME", 1);
			projection.addProperty("L_COLLNAME", 1);

			JsonObject isonMapJson = db$GetRow("ICOR_C_SCR_COLL_MAP", filter, projection);
			// String scrId = isonMapJson.get("SCRID").getAsString();
			try {
				// i$Match = i$ResM.getMatch(isonMsg);
				// recID = i$Match.get("_id").getAsString();
				// Get the globals, get from master first, if it is empty, then go to Ledger.

				CollName = isonMapJson.get("COLLNAME").getAsString();
				LCollName = isonMapJson.get("L_COLLNAME").getAsString();
				JsonObject rec = db$GetRow(LCollName, Jfilter);
				if (I$utils.$isNull(rec)) {
					rec = db$GetRow(CollName, Jfilter);
				}
				recIdObject = rec.getAsJsonObject("_id");
				recID = i$ResM.convertId(recIdObject);

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Failed to Get _id Match", e);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED DUE TO MISSING IMATCH ANNOTE",
						e.getMessage().toString());
			}
			;
			filter = new JsonObject();
			filter.addProperty("ReqID", recID);
			filter.addProperty("acquiredBy", userId);
			// #BVB00074 Ends
			db$Remove("ICOR_M_ID_ACQ", filter);

			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD SUCESSFULLY RELEASE");
		} catch (Exception e) {
			logger.error("Failed to Release Row " + e.getMessage());
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RELEASE ROW");
		}
	};

	// #BVB00167 Ends
	public JsonObject db$AcqRow(String CollName1, JsonObject Jfilter) {
		// public JsonObject db$AcqRow(JsonObject Jfilter) {
		// JsonObject isonMsg = isonMsgIn.deepCopy();
		JsonParser parser = new JsonParser();
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		Gson gson = new Gson();
		try {
			String recID = null;
			JsonObject recIdObject = null;

			// JsonObject i$Match = null;
			// JsonObject i$Match = Jfilter.deepCopy();
			JsonObject alreadyAcq = null;
			// String primaryKey = isonMsg.get("primaryKey").getAsString();
			String primaryKey = "";
			JsonObject filter = new JsonObject();
			JsonObject setter = new JsonObject();
			String CollName = "";
			String LCollName = "";
			JsonObject isonMapJson = i$ResM.getGobalValJObj("isonMapJson");
			String scrId = isonMapJson.get("SCRID").getAsString();
			try {
				// i$Match = i$ResM.getMatch(isonMsg);
				// recID = i$Match.get("_id").getAsString();
				// Get the globals, get from master first, if it is empty, then go to Ledger.

				CollName = isonMapJson.get("COLLNAME").getAsString();
				LCollName = isonMapJson.get("L_COLLNAME").getAsString();
				JsonObject rec = db$GetRow(LCollName, Jfilter);
				if (I$utils.$isNull(rec)) {
					rec = db$GetRow(CollName, Jfilter);
				} else {
					CollName = LCollName;
				}
				recIdObject = rec.getAsJsonObject("_id");
				recID = i$ResM.convertId(recIdObject);

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Failed to Get _id Match", e);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED DUE TO MISSING IMATCH ANNOTE",
						e.getMessage().toString());
			}
			;
			primaryKey = scrId;
			// #BVB00119 Starts
			Set<Entry<String, JsonElement>> entrySet = Jfilter.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				if (I$utils.$iStrFuzzyMatch(primaryKey, "")) {
					primaryKey = entry.getValue().getAsString();
				} else {
					primaryKey = primaryKey + "~" + entry.getValue().getAsString();
				}

			}
			// #BVB00119 Ends
			try {

				// #BVB00074 Starts
				filter.addProperty("ReqID", recID);
				filter.addProperty("primaryKey", primaryKey);
				// #BVB00074 Starts
				alreadyAcq = db$GetRow("ICOR_M_ID_ACQ", filter);
				// if (alreadyAcq != null) { // #BVB00119
				if (alreadyAcq != null && !I$utils.$iStrFuzzyMatch(alreadyAcq.get("acquiredBy").getAsString(),
						IResManipulator.iloggedUser.get())) { // #BVB00119
					logger.error("Failed Checking Lock..");
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Record Already Acquired or Locked by .." + alreadyAcq.get("acquiredBy").getAsString());
					return isonMsg;
				} else if (alreadyAcq != null && I$utils.$iStrFuzzyMatch(alreadyAcq.get("acquiredBy").getAsString(),
						IResManipulator.iloggedUser.get())) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD SUCESSFULLY ACQUIRED");
				}
			} catch (Exception e) {
				logger.error("Failed Checking Lock..");
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED EXECUTE FUNCTION",
						e.getMessage().toString());
				return isonMsg;
			}

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "QueryAcq");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recID", recID);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "acquiredby", IResManipulator.iloggedUser.get());
			JsonObject db$ResultAq = db$ControllerResult(argJson);
			JsonObject i$body = db$ResultAq.get("i-body").getAsJsonObject();
			// Going to Lock Record
			// #BVB00074 Starts
			setter.addProperty("ReqID", recID);
			setter.addProperty("ScrId", scrId);
			setter.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
			setter.addProperty("primaryKey", primaryKey);
			// #BVB00119 Starts
			setter.add("filter", Jfilter);
			setter.addProperty("CollName", CollName);
			// #BVB00119 Ends
			setter.add("createdAt", i$ResM.addDateTime(new Date()));
			setter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId"));
			// #BVB00074 Starts
			db$InsertRow("ICOR_M_ID_ACQ", setter);

			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD SUCESSFULLY ACQUIRED");
		} catch (Exception e) {
			logger.error("Invalid Paramter or Unknow Resource " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED EXECUTE FUNCTION",
					e.getMessage().toString());
			return isonMsg;
		}
		return isonMsg;
	};

	public String db$GetColS(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsString();
		} catch (Exception e) {
			return null;
		}
	};

	public Integer db$GetColI(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsInt();
		} catch (Exception e) {
			return 0;
		}
	};

	public Double db$GetColD(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsDouble();
		} catch (Exception e) {
			return null;
		}
	};

	public Float db$GetColF(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsFloat();
		} catch (Exception e) {
			return null;
		}
	};

	public BigDecimal db$GetColBD(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsBigDecimal();
		} catch (Exception e) {
			return null;
		}
	};

	public BigInteger db$GetColBI(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsBigInteger();
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetColGSON(JsonObject db$Result, String colName) {
		try {
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body.get(0).getAsJsonObject().get(colName).getAsJsonObject();
		} catch (Exception e) {
			return null;
		}
	};

	public Integer db$GetRowCnt(String CollName, JsonObject Jfilter) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result.getAsJsonArray("i-body").size();
		} catch (Exception e) {
			return -1;
		}
	};
	
	public Integer db$GetRowCnt(String CollName, String Jfilter) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result.getAsJsonArray("i-body").size();
		} catch (Exception e) {
			return -1;
		}
	};
	
	// #MAQ00122 Starts
	public Integer db$GetOtpCnt(String CollName, String sfilter) {
			int iBodySize;
			try {
				sfilter = sfilter.substring(0,sfilter.length()-2) + ", $or:[{'verCnt':{$exists:false}},{'verCnt':{$lt:3}}]}";
				JsonObject argJson = new JsonObject();
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", sfilter);
				JsonObject db$Result = db$ControllerResult(argJson);
				iBodySize = db$Result.getAsJsonArray("i-body").size();
			} catch (Exception e) {
				iBodySize = -1;
			}
			if(iBodySize < 1)
			{
				db$UpdateOtpSeq(sfilter);
			}
	// #SKP0001 Starts
			else if(iBodySize == 1)
			{
				db$setOtpvrncnt(sfilter);
			}
			return iBodySize;	
		};
		
	public void db$setOtpvrncnt(String sfilter){
			JsonParser parser = new JsonParser();
			JsonObject queryfilter = new JsonObject();
			
			try {
				JsonObject argJson = new JsonObject();
				JsonObject isonReq = new JsonObject();
				queryfilter.addProperty("iSecKey", parser.parse(sfilter).getAsJsonObject().get("iSecKey").getAsString());
				isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
						"i-body", "{'verCnt': 999 }");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "ICOR_S_IOTP_VALIDATOR");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
				db$ControllerResult(isonReq, argJson);
			} catch (Exception e) {}
		};
	// #SKP0001 Ends
		
	public void db$UpdateOtpSeq(String sfilter) {
			int verCnt = 0;
			JsonParser parser = new JsonParser();
			JsonObject queryfilter = new JsonObject();
			
			try {
				JsonObject argJson = new JsonObject();
				queryfilter.addProperty("iSecKey", parser.parse(sfilter).getAsJsonObject().get("iSecKey").getAsString());		
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "ICOR_S_IOTP_VALIDATOR");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
				JsonObject db$Result = db$ControllerResult(argJson);
				verCnt = db$Result.getAsJsonArray("i-body").get(0).getAsJsonObject().get("verCnt").getAsInt();
			} catch (Exception e) {}	

			try {
				verCnt = verCnt+1;
				JsonObject argJson = new JsonObject();
				JsonObject isonReq = new JsonObject();
				isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
						"i-body", "{'verCnt':"+ verCnt +"}");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "ICOR_S_IOTP_VALIDATOR");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
				db$ControllerResult(isonReq, argJson);
			} catch (Exception e) {}
		};
	// #MAQ00122 Ends
				
	// #BVB00006 Starts
	public JsonObject db$Remove(String CollName, String Jfilter) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Remove");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$Remove(String CollName, JsonObject Jfilter) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Remove");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00006 Ends

	public JsonObject db$GetRandRows(String CollName, int nRecs) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RandomDoc");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "SampleSize", Integer.toString(nRecs));
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};

	public String db$GetRandCol(String CollName, String ColName) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RandomDoc");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "SampleSize", "1");
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			JsonObject i$bodyRow = (JsonObject) i$body.get(0);
			return i$bodyRow.get(ColName).toString();
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$InsertRow(String CollName, JsonObject i$Doc) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Insert");
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow(String CollName, JsonObject i$Doc, String queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow(String CollName, JsonObject i$Doc, JsonObject queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00029 Starts
	public JsonObject db$UpdateRow(String CollName, JsonObject isonReq, JsonObject i$Doc, JsonObject queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonParser parser = new JsonParser();
			// isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", i$Doc);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00029 Ends

	// #BVB00006 Starts
	public JsonObject db$UpdateRow(String CollName, JsonObject i$Doc, JsonObject queryfilter, String upsert) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "upsert", upsert);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00006 Ends

	// #BVB00029 Starts
	public JsonObject db$UpdateRow(String CollName, JsonObject isonReq, JsonObject i$Doc, JsonObject queryfilter,
			String upsert) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "upsert", upsert);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00029 Ends

	// #BVB00011 Starts
	public JsonObject db$UpdateRowId(String CollName, JsonObject i$Doc, String queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update$id");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00011 Ends

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows, String queryfilter,
			String projection) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MaxRow", maxRows.toString());
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00006 Starts

	public JsonObject db$GetSummRowsPg(String CollName, JsonObject isonReq, String queryfilter, int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetSummRowsPg(String CollName, JsonObject isonReq, String queryfilter, String projection,
			int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetSummRowsArray(String CollName, JsonObject isonReq, String queryfilter, String projection,
			int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetSummRowsArray(String CollName, JsonObject isonReq, String queryfilter, JsonObject projection,
			int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetSummRowsArray(String CollName, JsonObject isonReq, String queryfilter, JsonObject projection,
			int skip, int limit, boolean isStringOnly) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter, true);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	
	public JsonArray db$GetSummRowsArray(String CollName, JsonObject queryfilter, JsonObject projection) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	
	

	// #BVB00020 Starts

	public JsonArray db$GetSummRowsArray(String CollName, JsonObject queryfilter, JsonObject projection, int skip,
			int limit) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetSummRowsArray(String CollName, String queryfilter, String projection, int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonArray db$GetSummRowsArray(String CollName, String queryfilter, JsonObject projection, int skip,
			int limit) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00020 Ends
	// BHUVI001 Starts
	public JsonArray db$GetSummRowsArray(String CollName, String queryfilter, JsonObject projection, int skip,
			int limit, String skipAbsolute) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skipAbsolute", skipAbsolute);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
			// return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	// BHUVI001 Ends

	public JsonObject db$GetSummRowsPg(String CollName, JsonObject isonReq, String queryfilter, JsonObject projection,
			int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00006 Ends

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows, JsonObject queryfilter,
			JsonObject projection) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MaxRow", maxRows.toString());
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #MAQ00003 start
	public JsonObject db$GetSummRowsPg(String CollName, JsonObject isonReq, Integer maxRows, JsonObject queryfilter,
			JsonObject projection, int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MaxRow", maxRows.toString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetSummRowsPg(String CollName, JsonObject isonReq, Integer maxRows, String queryfilter,
			JsonObject projection, int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MaxRow", maxRows.toString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	}
	// #MAQ00003 end

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows, String queryfilter,
			JsonObject projection) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MaxRow", maxRows.toString());
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows, JsonObject queryfilter,
			String projection) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MaxRow", maxRows.toString());
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00020 Starts

	public JsonObject db$InsertMany(String CollName, JsonArray i$Docs) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Docs);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "BulkInsert");
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00020 Ends
	
	// #PKY00002 Starts
	public boolean checkDBConnection(JsonObject obj) {
		// returns true if connection establish
		boolean dbResult = true;
		Ioutils i$outis = new Ioutils();
		DBController db = new DBController();
		try {
			if (i$outis.$iStrFuzzyMatch(i$ResM.getSrvcopr(obj), "handShake")) {				
				try {
					JsonObject filter = new JsonObject();
					filter.addProperty("SVRNAME", "SessionKey");
					JsonObject Result$ = db.db$GetRow("ICOR_C_SVR_OPR_MAP", filter);
					if (I$utils.$isNull(Result$)) {
						dbResult = false;
					}
				}catch(Exception e) {
					dbResult = false;
				}
			}
		} catch (Exception e) {
			
		}
		return dbResult;
	}
	// #PKY00002 Ends

	// 000007
	public JsonObject db$InsertMany$Retry(String CollName, JsonArray i$Docs) {
		JsonObject argJson = new JsonObject();
		JsonObject isonReq = new JsonObject();
		JsonParser parser = new JsonParser();
		boolean bSucc = false;
		int iRtryCnt = 0;
		do {
			try {
				isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
						parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", i$Docs);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "BulkInsert");
				isonReq = db$ControllerResult(isonReq, argJson);
				bSucc = true;
				break;
			} catch (Exception e) {
				e.printStackTrace();
				logger.debug("Failed to Connect Mongo.." + e.getMessage());
				try {
					logger.debug("Sleeping before Retry MongoInsert..");
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				iRtryCnt++;
				logger.debug("Going for Retry MongoInsert.." + Integer.toString(iRtryCnt));
			}
			
			
		} while (iRtryCnt <= 3);
		

		if (bSucc)
			logger.debug("Success in MongoInsert Retry.." + Integer.toString(iRtryCnt));
		else
			logger.debug("Failed in MongoInsert even after " + Integer.toString(iRtryCnt) + " no retries");

		return isonReq;
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq) {
		return db$GetSummRows(CollName, isonReq, -1, "{}", "{}");
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows) {
		return db$GetSummRows(CollName, isonReq, maxRows, "{}", "{}");
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows, String queryFilter) {
		return db$GetSummRows(CollName, isonReq, maxRows, queryFilter, "{}");
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, Integer maxRows, JsonObject queryFilter) {
		return db$GetSummRows(CollName, isonReq, maxRows, queryFilter, "{}");
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, JsonObject projection, Integer maxRows) {
		return db$GetSummRows(CollName, isonReq, maxRows, "{}", projection);
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, String projection, Integer maxRows) {
		return db$GetSummRows(CollName, isonReq, maxRows, "{}", projection);
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, String queryfilter, String projection) {
		return db$GetSummRows(CollName, isonReq, -1, queryfilter, projection);
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, JsonObject queryfilter,
			JsonObject projection) {
		return db$GetSummRows(CollName, isonReq, -1, queryfilter, projection);
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, String queryfilter, JsonObject projection) {
		return db$GetSummRows(CollName, isonReq, -1, queryfilter, projection);
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, JsonObject queryfilter, String projection) {
		return db$GetSummRows(CollName, isonReq, -1, queryfilter, projection);
	};

	// #BVB00020 Starts

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, String projection) {
		return db$GetSummRows(CollName, isonReq, -1, "{}", projection);
	};

	public JsonObject db$GetSummRows(String CollName, JsonObject isonReq, JsonObject projection) {
		return db$GetSummRows(CollName, isonReq, -1, "{}", projection);
	};
	// #BVB00020 Ends

	public JsonObject db$InsertRow(String CollName, String i$Doc) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", parser.parse(i$Doc).getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Insert");
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow(String CollName, String i$Doc, String queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	
	public JsonObject db$FindAndUpdateRow(String CollName, String i$Doc, String queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "dbins", i$Doc);			
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "QueryUpdate");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow(String CollName, String i$Doc, JsonObject queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow(String CollName, String i$Doc, String queryfilter, String upsert) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow(String CollName, String i$Doc, JsonObject queryfilter, String upsert) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	
	// #YPR00002 Starts
	// #YPR00001 Starts
	public JsonObject db$UpdateRowOperator(String CollName, String i$Doc, JsonObject queryfilter, String upsert,String operator) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "operator",operator);// #YPR00002 Starts
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			logger.debug("*******checking SRM123 0821 exception*********"+e.getMessage());
			return null;
			
		}
	};
	// #YPR00001 Ends
	// #YPR00002 Ends
	
	public JsonObject db$GetTopRows(String CollName, JsonObject queryfilter, JsonObject sortBy, Integer recSize) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Top");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", sortBy);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", recSize);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetLeastRows(String CollName, JsonObject queryfilter, JsonObject sortBy, Integer recSize) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Least");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", sortBy);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", recSize);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetTopRows(String CollName, String queryfilter, String sortCol, Integer recSize) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Top");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", "{\"" + sortCol + "\":-1}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", recSize);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetLeastRows(String CollName, String queryfilter, String sortCol, Integer recSize) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Least");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", "{\"" + sortCol + "\":-1}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", recSize);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetTopRow(String CollName, JsonObject queryfilter, JsonObject sortBy) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Top");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", sortBy);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", 1);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateNestedArr(String CollName, String i$Doc, JsonObject queryfilter, String upsert,String operator, String arrFilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "operator",operator);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "arrFilter",arrFilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	
	public JsonObject db$GetLeastRow(String CollName, JsonObject queryfilter, JsonObject sortBy) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Least");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", sortBy);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", 1);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetTopRow(String CollName, String queryfilter, String sortCol) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Top");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", "{\"" + sortCol + "\":-1}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", 1);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetLeastRow(String CollName, String queryfilter, String sortCol) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Least");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", "{\"" + sortCol + "\":-1}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", -1);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetTopRow(String CollName, JsonObject queryfilter, String sortCol) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Top");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", "{\"" + sortCol + "\":-1}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", 1);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetLeastRow(String CollName, JsonObject queryfilter, String sortCol) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Least");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sortBy", "{\"" + sortCol + "\":-1}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "recSize", -1);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00006 Starts
	// #BVB00020 Commenting
	/*
	 * public int db$getCount(String CollName, String Jfilter) { try { JsonObject
	 * argJson = new JsonObject(); i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
	 * argJson, "CollName", CollName); i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
	 * argJson, "MongoOprMode", "Count"); i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
	 * argJson, "queryfilter", Jfilter); JsonObject db$Result =
	 * db$ControllerResult(argJson); return
	 * i$ResM.getBody(db$Result).get("iRowCnt").getAsInt(); } catch (Exception e) {
	 * return 0; } }
	 */

	// #BVB00006 Ends

	public JsonObject db$getFunctionAccess(String userId) {

		try {
			// Getting roles of a User
			JsonObject i$runningQuery = new JsonObject();
			i$runningQuery.addProperty("userId", userId);
			i$runningQuery.addProperty("active", "A"); // #MAQ00001
			JsonObject i$MasterUserPrf = db$GetRow("ICOR_M_USER_PRF", i$runningQuery.toString());
			JsonArray i$roles = i$MasterUserPrf.getAsJsonArray("roles");
			JsonArray i$access = new JsonArray();

			// Getting all function access for user based on User id
			JsonArray i$MasterFuncAccU = db$GetRows("ICOR_M_USER_PRF", i$runningQuery.toString());

			for (int i = 0; i < i$MasterFuncAccU.size(); i++) {
				i$access.add(i$MasterFuncAccU.get(i).getAsJsonObject().getAsJsonArray("functionAccessA"));
			}

			i$runningQuery = new JsonObject();
			// Getting all Function access User has based on roles.
			for (int i = 0; i < i$roles.size(); i++) {
				i$runningQuery.addProperty("roleId", i$roles.get(i).toString());
				i$runningQuery.addProperty("active", "A"); // #MAQ00001
				JsonArray i$MasterFuncAcc = db$GetRows("ICOR_M_FUNC_ACC", i$runningQuery.toString());
				for (int j = 0; j < i$MasterFuncAcc.size(); j++) {
					i$access.add(i$MasterFuncAcc.get(j).getAsJsonObject().getAsJsonArray("functionAccessA"));
					// i$access.add
				}

			}

			// here i$access has all the function the user can access.

		} catch (Exception e) {

		}

		return null;
	}

	// #00000003 Begins
	public boolean db$hasModuleAccessAny(String userId, ArrayList<String> arrModuleList) {
		String sMatchString = null;
		int iRowCnt = 0;
		try {
			for (int i = 0; i < arrModuleList.size(); i++) {
				if (i == 0)
					sMatchString = "\"" + arrModuleList.get(i) + "\"";
				else
					sMatchString = ",\"" + arrModuleList.get(i) + "\"";
			}
			;
			iRowCnt = db$GetCountI("ICOR_M_USER_PRF",
					"{\"userId\":\"" + userId + "\", \"active\":\"A\",\"modules\":{\"$in\": [" + sMatchString + "]}}"); // #MAQ00001
			return iRowCnt > 0;
		} catch (Exception e) {
			return false;
		}
	};

	public boolean db$NoModuleAccessAny(String userId, ArrayList<String> arrModuleList) {
		String sMatchString = null;
		int iRowCnt = 0;
		try {
			for (int i = 0; i < arrModuleList.size(); i++) {
				if (i == 0)
					sMatchString = "\"" + arrModuleList.get(i) + "\"";
				else
					sMatchString = ",\"" + arrModuleList.get(i) + "\"";
			}
			;
			iRowCnt = db$GetCountI("ICOR_M_USER_PRF",
					"{\"userId\":\"" + userId + "\", \"active\":\"A\",\"modules\":{\"$in\": [" + sMatchString + "]}}"); // #MAQ00001
			return !(iRowCnt > 0);
		} catch (Exception e) {
			return true;
		}
	};

	public boolean db$NoModuleAccessAll(String userId, ArrayList<String> arrModuleList) {
		String sMatchString = null;
		int iRowCnt = 0;
		try {
			for (int i = 0; i < arrModuleList.size(); i++) {
				if (i == 0)
					sMatchString = "\"modules\":{\"$in\": [\"" + arrModuleList.get(i) + "\"]}";
				else
					sMatchString = ",\"modules\":{\"$in\": [\"" + arrModuleList.get(i) + "\"]}";
			}
			;
			iRowCnt = db$GetCountI("ICOR_M_USER_PRF",
					"{\"userId\":\"" + userId + "\", \"active\":\"A\"," + sMatchString + "}"); // #MAQ00001
			return !(iRowCnt > 0);
		} catch (Exception e) {
			return false;
		}
	};

	public boolean db$hasModuleAccessAll(String userId, ArrayList<String> arrModuleList) {
		String sMatchString = null;
		int iRowCnt = 0;
		try {
			for (int i = 0; i < arrModuleList.size(); i++) {
				if (i == 0)
					sMatchString = "\"modules\":{\"$in\": [\"" + arrModuleList.get(i) + "\"]}";
				else
					sMatchString = ",\"modules\":{\"$in\": [\"" + arrModuleList.get(i) + "\"]}";
			}
			;
			iRowCnt = db$GetCountI("ICOR_M_USER_PRF",
					"{\"userId\":\"" + userId + "\", \"active\":\"A\"," + sMatchString + "}"); // #MAQ00001
			return iRowCnt > 0;
		} catch (Exception e) {
			return false;
		}
	};

	public JsonArray db$getDMSAccessWS() {
        JsonArray resWs = new JsonArray();
        JsonArray accessWrkSpcsArr = new JsonArray();
        try {
            JsonObject projQ = new JsonObject();
            String userId = IResManipulator.iloggedUser.get();
            JsonObject queryfilter = new JsonObject();
            queryfilter.addProperty("userId", userId);
            queryfilter.addProperty("active", "A");
            JsonObject userInfo = db$GetRow("ICOR_M_USER_PRF", queryfilter.toString());
            JsonArray roleIds = userInfo.get("roles").getAsJsonArray();
            String filter = "{'$and':[{'operation':{$ne:'DELETE'}},{'isCurrVer':'Y'},{'$or':[{'scope':'Protected', 'roleOrUserType':'U','allowed$Users': {'$in':['"+userId+"']}},{'scope':'Protected','roleOrUserType':'R','allowed$Roles':{'$in':"+roleIds+"}},{'scope':'Public'},{'scope':'Private','initiator':'"+userId+"'}]}]}";                                 
            projQ.addProperty("workspaceId",1);
            projQ.addProperty("_id",0);
            resWs = db$GetRows("ICOR_M_DMS_WORKSPACES",filter, projQ);
			for(int i=0 ;i<resWs.size(); i++) {
				JsonObject i$runningObj = resWs.get(i).getAsJsonObject(); 
				String workspaceId = i$runningObj.get("workspaceId").getAsString();
				accessWrkSpcsArr.add(workspaceId);
			}
        }catch(Exception e) {
            e.printStackTrace();
            
        }
        return accessWrkSpcsArr;
    }
	
	public void db$logDmsHstry(JsonObject isonMsg) {
        String ScrId = i$ResM.getScreenID(isonMsg);
		String SOpr = i$ResM.getOpr(isonMsg);
		String sSvr = i$ResM.getSrvcName(isonMsg);
		String sOpr = i$ResM.getSrvcopr(isonMsg);
		String doc$Operation = i$ResM.getSrvcopr3(isonMsg); //SKG00022 changes
        JsonObject i$body = i$ResM.getBody(isonMsg);
        JsonParser parser = new JsonParser();
        try {
            JsonObject queryfilter = new JsonObject();
            JsonObject qryDelFltr = new JsonObject();
        	JsonObject i$Doc = new JsonObject();
        	Boolean inActvteHisRecs = false;
			
        	// SKG00025 changes starts 
			try {
				if (I$utils.$iStrBlank(IResManipulator.iloggedUser.get())) {
					i$Doc.addProperty("User", i$body.get("user").getAsString());
				} else {
					i$Doc.addProperty("User", IResManipulator.iloggedUser.get());
				}
			} catch (Exception e) {
				i$Doc.addProperty("User", IResManipulator.iloggedUser.get());
			}
			//SKG00031 changes starts 
			try {
				String parentFolderName = i$body.get("LinkedCustNo").getAsString();	//SKG00031 changes
				JsonObject projection1 = new JsonObject();	//SKG00031 changes  

				if (I$utils.$iStrFuzzyMatch(parentFolderName, "ALOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLTRREQ")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFIP") ||I$utils.$iStrFuzzyMatch(parentFolderName, "AFCIP")||I$utils.$iStrFuzzyMatch(parentFolderName, "ALINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DPAY")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFCIP")) {
					JsonObject filter = new JsonObject();
					//JsonObject projection = new JsonObject();
//					JsonObject cif = new JsonObject();
					projection1.addProperty("_id", 0);
					projection1.addProperty("CustomerFullName", 1);
					filter.addProperty("CustomerId", i$Doc.get("User").getAsString());
				    JsonObject db$res = db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection1);
					i$Doc.addProperty("User", db$res.get("CustomerFullName").getAsString());

				} 
			}catch (Exception e) {
				e.printStackTrace();
			}	//SKG00031 changes starts 
			// SKG00025 changes end 
 			i$Doc.addProperty("Action", ScrId+"_"+SOpr);
 			i$Doc.addProperty("Date", i$ResM.getOnlydate(new Date()));
 			i$Doc.addProperty("userAction", doc$Operation);//SKG00022 changes
 			i$Doc.addProperty("Operation", SOpr);
           if(I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRWS")){
        	   JsonObject wrkspcDet = new JsonObject();
        	   if(!I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
          		 wrkspcDet = db$GetRow("ICOR_M_DMS_WORKSPACES", "{'workspaceId':'"+i$body.get("workspaceId").getAsString()+"','isCurrVer':'Y'}");
        		 i$Doc.addProperty("OperatedOnVer", wrkspcDet.get("verNo").getAsInt()-1);
        	   }else if(I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
            	 wrkspcDet = db$GetTopRow("ICOR_M_DMS_WORKSPACES", "{'workspaceId':'"+i$body.get("workspaceId").getAsString()+"','isCurrVer':'N','operation':'DELETE'}","_id").getAsJsonObject().get("i-body").getAsJsonArray().get(0).getAsJsonObject();
        		 i$Doc.addProperty("OperatedOnVer", wrkspcDet.get("verNo").getAsInt());
        		 i$Doc.addProperty("active","I");
        	   }
        		 queryfilter.addProperty("historyId", i$body.get("workspaceId").getAsString());
        		 i$Doc.addProperty("OperatedOn", "Workspace");
        		 i$Doc.addProperty("Name",wrkspcDet.get("workspaceName").getAsString());
        		 i$Doc.addProperty("parentFolderId","");
        		 i$Doc.addProperty("folderLevel",wrkspcDet.get("folderLevel").getAsString());
        		 i$Doc.addProperty("currVer", wrkspcDet.get("verNo").getAsInt());
        		 i$Doc.addProperty("remarks", wrkspcDet.get("errorMsg").getAsString());
             	queryfilter.addProperty("active","A");
 		   }else if(I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRFL")||(i$body.has("folderId") && I$utils.$iStrFuzzyMatch(sSvr, "ImpactoSeqService"))||(I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && i$body.has("folderId") && !i$body.has("dmsApi") && I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "Y")) || (I$utils.$iStrFuzzyMatch(ScrId, "FABFLUPD") && I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "Y"))){ // #YPR00111 changes #TKS00014 chnages
 			  JsonObject fldrDet = new JsonObject();
 			  if(!I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
 				 fldrDet = db$GetRow("ICOR_M_DMS_FOLDERS", "{'folderId':'"+i$body.get("folderId").getAsString()+"','isCurrVer':'Y'}");
        		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt()-1);
 			  }else if(I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
 				 fldrDet = db$GetTopRow("ICOR_M_DMS_FOLDERS", "{'folderId':'"+i$body.get("folderId").getAsString()+"','isCurrVer':'N','operation':'DELETE'}","_id").getAsJsonObject().get("i-body").getAsJsonArray().get(0).getAsJsonObject();
        		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
    				qryDelFltr.addProperty("historyId", i$body.get("folderId").getAsString());
    				inActvteHisRecs = true;
       	      }
 			    i$Doc.addProperty("OperatedOn", "Folder");
       		    String fldrIdPath = fldrDet.get("folderIdPath").getAsString()+"/"+i$body.get("folderId").getAsString();
       		    List<String>  updateIds =  Arrays.asList(fldrIdPath.split("/"));
 			    queryfilter.add("historyId",parser.parse("{$in:"+updateIds+"}").getAsJsonObject());
       		    i$Doc.addProperty("Name",fldrDet.get("folderName").getAsString());
       		    i$Doc.addProperty("parentFolderId",fldrDet.get("parentFolderId").getAsString());
       		    i$Doc.addProperty("folderLevel",fldrDet.get("folderLevel").getAsString());
       		    i$Doc.addProperty("currVer", fldrDet.get("verNo").getAsInt());
       		    i$Doc.addProperty("remarks", fldrDet.get("errorMsg").getAsString());
            	queryfilter.addProperty("active","A");

 		   }else if((I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "Y"))
 				   ||I$utils.$iStrFuzzyMatch(ScrId, "ODSCRDOC") || (I$utils.$iStrFuzzyMatch(ScrId, "FABFLUPD") && 
 						   I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "N"))
 				   || I$utils.$iStrFuzzyMatch(ScrId, "FDMFLDLD") || I$utils.$iStrFuzzyMatch(ScrId, "OABQRSCD") || (I$utils.$iStrFuzzyMatch(ScrId, "ODSMODUP") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY"))){//#TKS00014 chnages //SKG00017 changes
 			  JsonObject docPrntData = new JsonObject();
 			  JsonObject docDet = new JsonObject();
 			  JsonObject docFilter = new JsonObject();
			  JsonObject projection = new JsonObject();
    		   if((I$utils.$iStrFuzzyMatch(ScrId, "ODSCRDOC")&& I$utils.$iStrFuzzyMatch(SOpr, "UPDATE"))){//SKG00017
			      docFilter.addProperty("folderId",i$body.get("folderId").getAsString());//SKG00017
    	    	}else if(I$utils.$iStrFuzzyMatch(ScrId, "FDMFLDLD") || I$utils.$iStrFuzzyMatch(ScrId, "OABQRSCD") ||(I$utils.$iStrFuzzyMatch(ScrId, "ODSMODUP") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY"))) {
    	    		//#TKS00016 starts
    	    		JsonObject ftkData = db$GetRow("fs.files","{'metadata.FileUrlToken':'"+i$body.get("FileUrlToken").getAsString()+"','metadata.isCurrVer':'Y'}").get("metadata").getAsJsonObject();
    	    		//docFilter.addProperty("folderId",ftkData.get("parentFolderId").getAsString());//SKG00032 chnages
    		        docFilter.addProperty("workspaceId",ftkData.get("workspaceId").getAsString());
    		      //#TKS00016 ends
    		        //SKG00024 starts 
    	    	}else if(I$utils.$iStrFuzzyMatch(ScrId, "ODSCRDOC")  && I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
    	    	//	docFilter.addProperty("folderId",i$body.get("folderId").getAsString());// SKG00032 changes
    	    		docFilter.addProperty("parentFolderId",i$body.get("parentFolderId").getAsString());
    		        docFilter.addProperty("workspaceId",i$body.get("workspaceId").getAsString());
    		      //SKG00024 end 
    	    	}else {
  		          docFilter.addProperty("folderId",i$body.get("parentFolderId").getAsString());
  		          docFilter.addProperty("workspaceId",i$body.get("workspaceId").getAsString());
    	    	}
		        docFilter.addProperty("isCurrVer","Y");
		        projection.addProperty("initiator",1);
		        projection.addProperty("folderIdPath",1);
		        projection.addProperty("folderId",1);
		        projection.addProperty("folderLevel",1);
		        docPrntData = db$GetRow("ICOR_M_DMS_FOLDERS", docFilter,projection);
 			  if(!I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
 		          docDet = db$GetRow("fs.files","{'metadata.FileUrlToken':'"+i$body.get("FileUrlToken").getAsString()+"','metadata.isCurrVer':'Y'}").get("metadata").getAsJsonObject();
        		  i$Doc.addProperty("OperatedOnVer", docDet.get("verNo").getAsInt()-1);
        		  if((I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE"))) {
        			  i$Doc.addProperty("User",docDet.get("initiator").getAsString());
        			  }
 			  }else if(I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
 		          docDet = db$GetRow("fs.files","{'metadata.FileUrlToken':'"+i$body.get("FileUrlToken").getAsString()+"','metadata.isCurrVer':'N'}").get("metadata").getAsJsonObject();
        		  i$Doc.addProperty("OperatedOnVer", docDet.get("verNo").getAsInt());
    			  qryDelFltr.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
    			  inActvteHisRecs = true;
       	      }
       		    String fldrIdPath = docPrntData.get("folderIdPath").getAsString()+"/"+i$body.get("FileUrlToken").getAsString();
       		    List<String>  updateIds =  Arrays.asList(fldrIdPath.split("/"));
       		    i$Doc.addProperty("OperatedOn", "File");
 			    queryfilter.add("historyId",parser.parse("{$in:"+updateIds+"}").getAsJsonObject());
       		    i$Doc.addProperty("Name",docDet.get("FileName").getAsString());
       		    i$Doc.addProperty("parentFolderId",docPrntData.get("folderId").getAsString());
       		    i$Doc.addProperty("folderLevel",docPrntData.get("folderLevel").getAsString());
       		    i$Doc.addProperty("currVer", docDet.get("verNo").getAsInt());
       		    i$Doc.addProperty("remarks", "Record Sucessfully "+SOpr.toLowerCase()+"d");
            	queryfilter.addProperty("active","A");
            	
 		   }else if(I$utils.$iStrFuzzyMatch(ScrId, "FDMAPUPD")) {
 			  JsonObject docPrntData = new JsonObject();
 			  JsonObject docDet = new JsonObject();
 			  JsonObject docFilter = new JsonObject();
			  JsonObject projection = new JsonObject();
			  JsonArray FileUrlTokens = i$body.get("files").getAsJsonArray();
			  if(i$body.has("historyOnFile") && i$body.get("historyOnFile").getAsBoolean()) {
				  for(int i = 0 ; i < FileUrlTokens.size() ; i++) {
					  JsonObject ftkData = db$GetRow("fs.files","{'metadata.FileUrlToken':'"+FileUrlTokens.get(i).getAsJsonObject().get("FileUrlToken").getAsString()+"','metadata.isCurrVer':'Y'}").get("metadata").getAsJsonObject();
					  docFilter.addProperty("folderId",ftkData.get("parentFolderId").getAsString());
					  docFilter.addProperty("workspaceId",ftkData.get("workspaceId").getAsString());
				        docFilter.addProperty("isCurrVer","Y");
				        projection.addProperty("initiator",1);
				        projection.addProperty("folderIdPath",1);
				        projection.addProperty("folderId",1);
				        projection.addProperty("folderLevel",1);
				        docPrntData = db$GetRow("ICOR_M_DMS_FOLDERS", docFilter,projection);
		 			  if(!I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
		 		          docDet = db$GetRow("fs.files","{'metadata.FileUrlToken':'"+FileUrlTokens.get(i).getAsJsonObject().get("FileUrlToken").getAsString()+"','metadata.isCurrVer':'Y'}").get("metadata").getAsJsonObject();
		        		  i$Doc.addProperty("OperatedOnVer", docDet.get("verNo").getAsInt()-1);
		 			  }
		       		    String fldrIdPath = docPrntData.get("folderIdPath").getAsString()+"/"+FileUrlTokens.get(i).getAsJsonObject().get("FileUrlToken").getAsString();
		       		    List<String>  updateIds =  Arrays.asList(fldrIdPath.split("/"));
		       		    i$Doc.addProperty("OperatedOn", "File");
		 			    queryfilter.add("historyId",parser.parse("{$in:"+updateIds+"}").getAsJsonObject());
		       		    i$Doc.addProperty("Name",docDet.get("FileName").getAsString());
		       		    i$Doc.addProperty("parentFolderId",docPrntData.get("folderId").getAsString());
		       		    i$Doc.addProperty("folderLevel",docPrntData.get("folderLevel").getAsString());
		       		    i$Doc.addProperty("currVer", docDet.get("verNo").getAsInt());
		       		    i$Doc.addProperty("remarks", "Record Sucessfully "+SOpr.toLowerCase()+"d");
		            	queryfilter.addProperty("active","A");
		     			i$Doc.add("ModifiedAt", i$ResM.adddate(new Date()));
		     			//// SKG00025 changes starts 
		     			try {
		    				if (I$utils.$iStrBlank(IResManipulator.iloggedUser.get())) {
		    					i$Doc.addProperty("ModifiedBy", i$body.get("user").getAsString());
		    				} else {
		    					i$Doc.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
		    				}
		    			} catch (Exception e) {
	    					i$Doc.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
		    			}	//// SKG00025 changes end 	
		     			//SKG00031 changes starts 
		     			try {
		     				String parentFolderName = i$body.get("LinkedCustNo").getAsString();	//SKG00031 changes
		     				JsonObject projection1 = new JsonObject();	//SKG00031 changes  
		    				if (I$utils.$iStrFuzzyMatch(parentFolderName, "ALOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLTRREQ")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFIP") ||I$utils.$iStrFuzzyMatch(parentFolderName, "AFCIP")||I$utils.$iStrFuzzyMatch(parentFolderName, "ALINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DPAY")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFCIP")) {
		    					JsonObject filter = new JsonObject();
		    					//JsonObject projection = new JsonObject();
//		    					JsonObject cif = new JsonObject();
		    					projection1.addProperty("_id", 0);
		    					projection1.addProperty("CustomerFullName", 1);
		    					filter.addProperty("CustomerId", i$Doc.get("ModifiedBy").getAsString());
		    				    JsonObject db$res = db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection1);
		    					i$Doc.addProperty("ModifiedBy", db$res.get("CustomerFullName").getAsString());

		    				} 
		    			}catch (Exception e) {
		    				e.printStackTrace();
		    			}	//SKG00031 changes end 
		     			String iDoc = "{'history':"+i$Doc+"}";
		            	logger.debug("*******checking 111111 exception SRM1111*********");
		     			db$UpdateRowOperator("fs.files", iDoc, queryfilter, "false", "push");//SKG00036 changes
				  }
			  }else if(i$body.has("historyOnFolder") && i$body.get("historyOnFolder").getAsBoolean()) {
					JsonObject fldrDet = new JsonObject();
					fldrDet = db$GetRow("ICOR_M_DMS_FOLDERS",
							"{'folderId':'" + i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString() + "','isCurrVer':'Y'}");
					i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt() - 1);
	 			    i$Doc.addProperty("OperatedOn", "Folder");
	       		    String fldrIdPath = fldrDet.get("folderIdPath").getAsString()+"/"+i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString();
	       		    List<String>  updateIds =  Arrays.asList(fldrIdPath.split("/"));
	 			    queryfilter.add("historyId",parser.parse("{$in:"+updateIds+"}").getAsJsonObject());
	       		    i$Doc.addProperty("Name",fldrDet.get("folderName").getAsString());
	       		    i$Doc.addProperty("parentFolderId",fldrDet.get("parentFolderId").getAsString());
	       		    i$Doc.addProperty("folderLevel",fldrDet.get("folderLevel").getAsString());
	       		    i$Doc.addProperty("currVer", fldrDet.get("verNo").getAsInt());
	       		    i$Doc.addProperty("remarks", fldrDet.get("errorMsg").getAsString());
	            	queryfilter.addProperty("active","A");
	            	i$Doc.add("ModifiedAt", i$ResM.adddate(new Date()));
	            	//// SKG00025 changes starts 
	            	try {
	    				if (I$utils.$iStrBlank(IResManipulator.iloggedUser.get())) {
	    					i$Doc.addProperty("ModifiedBy", i$body.get("user").getAsString());
	    				} else {
	    					i$Doc.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
	    				}
	    			} catch (Exception e) {
    					i$Doc.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
	    			}	 //// SKG00025 changes end 
	            	//SKG00031 changes starts 
	            	try {
	            		String parentFolderName = i$body.get("LinkedCustNo").getAsString();	//SKG00031 changes
	        			JsonObject projection1 = new JsonObject();	//SKG00031 changes  
	    				if (I$utils.$iStrFuzzyMatch(parentFolderName, "ALOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLTRREQ")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFIP") ||I$utils.$iStrFuzzyMatch(parentFolderName, "AFCIP")||I$utils.$iStrFuzzyMatch(parentFolderName, "ALINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DPAY")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFCIP")) {
	    					JsonObject filter = new JsonObject();
	    					//JsonObject projection = new JsonObject();
//	    					JsonObject cif = new JsonObject();
	    					projection1.addProperty("_id", 0);
	    					projection1.addProperty("CustomerFullName", 1);
	    					filter.addProperty("CustomerId", i$Doc.get("ModifiedBy").getAsString());
	    				    JsonObject db$res = db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection1);
	    					i$Doc.addProperty("ModifiedBy", db$res.get("CustomerFullName").getAsString());

	    				} 
	    			}catch (Exception e) {
	    				e.printStackTrace();
	    			}	//SKG00031 changes end 
	            	String iDoc = "{'history':"+i$Doc+"}";
	     			db$UpdateRowOperator("fs.files", iDoc, queryfilter, "false", "push");//SKG00036
			  }
			  
   			return;
 		   }
 		   else if(I$utils.$iStrFuzzyMatch(ScrId, "ODSARRFL")){
  			  JsonObject fldrDet = new JsonObject();
  			  if(I$utils.$iStrFuzzyMatch(SOpr, "ARCHIVE")) {
  				 fldrDet = db$GetRow("ICOR_M_DMS_ARCHIVES", "{'folderId':'"+i$body.get("folderId").getAsString()+"','isCurrVer':'Y' , 'Archive':'Y'}");
         		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
  			  }else if(I$utils.$iStrFuzzyMatch(SOpr, "UNARCHIVE")) {
  				fldrDet = db$GetRow("ICOR_M_DMS_ARCHIVES", "{'folderId':'"+i$body.get("folderId").getAsString()+"','isCurrVer':'N' , 'Archive':'N'}");
     		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
  			  }
  			  else if(I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
  				 fldrDet = db$GetTopRow("ICOR_M_DMS_FOLDERS", "{'folderId':'"+i$body.get("folderId").getAsString()+"','isCurrVer':'N','operation':'DELETE'}","_id").getAsJsonObject().get("i-body").getAsJsonArray().get(0).getAsJsonObject();
         		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
     				qryDelFltr.addProperty("historyId", i$body.get("folderId").getAsString());
     				inActvteHisRecs = true;
        	      }
  			    i$Doc.addProperty("OperatedOn", "Folder");
        		    String fldrIdPath = fldrDet.get("folderIdPath").getAsString()+"/"+i$body.get("folderId").getAsString();
        		    List<String>  updateIds =  Arrays.asList(fldrIdPath.split("/"));
  			    queryfilter.add("historyId",parser.parse("{$in:"+updateIds+"}").getAsJsonObject());
        		    i$Doc.addProperty("Name",fldrDet.get("folderName").getAsString());
        		    i$Doc.addProperty("parentFolderId",fldrDet.get("parentFolderId").getAsString());
        		    i$Doc.addProperty("folderLevel",fldrDet.get("folderLevel").getAsString());
        		    i$Doc.addProperty("currVer", fldrDet.get("verNo").getAsInt());
        		    i$Doc.addProperty("remarks", fldrDet.get("errorMsg").getAsString());
                	queryfilter.addProperty("active","A");
  		   }else if(I$utils.$iStrFuzzyMatch(ScrId, "ODSAARFL")){
   			  JsonObject fldrDet = new JsonObject();
   			  if(I$utils.$iStrFuzzyMatch(SOpr, "ARCHIVE")) {
   				 fldrDet = db$GetRow("ICOR_M_DMS_ARCHIVES", "{'folderId':'"+i$body.get("archiveFolder").getAsString()+"','isCurrVer':'Y' , 'Archive':'Y'}");
          		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
   			  }else if(I$utils.$iStrFuzzyMatch(SOpr, "UNARCHIVE")) {
   				fldrDet = db$GetRow("ICOR_M_DMS_ARCHIVES", "{'folderId':'"+i$body.get("archiveFolder").getAsString()+"','isCurrVer':'N' , 'Archive':'N'}");
      		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
   			  }
   			  else if(I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
   				 fldrDet = db$GetTopRow("ICOR_M_DMS_FOLDERS", "{'folderId':'"+i$body.get("archiveFolder").getAsString()+"','isCurrVer':'N','operation':'DELETE'}","_id").getAsJsonObject().get("i-body").getAsJsonArray().get(0).getAsJsonObject();
          		    i$Doc.addProperty("OperatedOnVer", fldrDet.get("verNo").getAsInt());
      				qryDelFltr.addProperty("historyId", i$body.get("folderId").getAsString());
      				inActvteHisRecs = true;
         	      }
   			    i$Doc.addProperty("OperatedOn", "Folder");
         		    String fldrIdPath = fldrDet.get("folderIdPath").getAsString()+"/"+i$body.get("archiveFolder").getAsString();
         		    List<String>  updateIds =  Arrays.asList(fldrIdPath.split("/"));
   			    queryfilter.add("historyId",parser.parse("{$in:"+updateIds+"}").getAsJsonObject());
         		    i$Doc.addProperty("Name",fldrDet.get("folderName").getAsString());
         		    i$Doc.addProperty("parentFolderId",fldrDet.get("parentFolderId").getAsString());
         		    i$Doc.addProperty("folderLevel",fldrDet.get("folderLevel").getAsString());
         		    i$Doc.addProperty("currVer", fldrDet.get("verNo").getAsInt());
         		    i$Doc.addProperty("remarks", fldrDet.get("errorMsg").getAsString());
                 	queryfilter.addProperty("active","A");
   		   }
 		   else if(I$utils.$iStrFuzzyMatch(sSvr, "DMSLDOC") && I$utils.$iStrFuzzyMatch(sOpr, "delDoc")) {//#TKS00007 changes.
  			   	queryfilter.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
  			   	JsonObject queryFltr = new JsonObject();
	  			i$Doc.addProperty("Action", sSvr+"_"+sOpr);
	  			i$Doc.addProperty("Operation", sOpr);
	  			i$Doc.addProperty("OperatedOn", "File");
	  			queryFltr.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsString());
	  			JsonObject fileData = new JsonObject();
	  			JsonObject fldrData = new JsonObject();
	  			fileData = db$GetRow("fs.files", queryFltr);
	  			queryFltr.remove("metadata.FileUrlToken");
	  			queryFltr.addProperty("folderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			fldrData = db$GetRow("ICOR_M_DMS_FOLDERS", queryFltr);
	  			i$Doc.addProperty("OperatedOnVer", fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("Name", fileData.get("metadata").getAsJsonObject().get("FileName").getAsString());
	  			i$Doc.addProperty("parentFolderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			i$Doc.addProperty("folderLevel",fldrData.get("folderLevel").getAsString());
	  			i$Doc.addProperty("currVer",fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("remarks", "Document Deleted through API");
  		   }
 		  else if ((I$utils.$iStrFuzzyMatch(sSvr, "shareViaEmail") && I$utils.$iStrFuzzyMatch(sOpr, "shareFiles")) || (I$utils.$iStrFuzzyMatch(sSvr, "shareViaDrive") && I$utils.$iStrFuzzyMatch(sOpr, "shareddl"))) {//SKG00023 changes starts//SKG00025 changes
			   	queryfilter.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
			   	JsonObject queryFltr = new JsonObject();
	  			i$Doc.addProperty("Action", sSvr+"_"+sOpr);
	  			i$Doc.addProperty("Operation", sOpr);
	  			i$Doc.addProperty("OperatedOn", "File");
	  			queryFltr.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsString());
	  			JsonObject fileData = new JsonObject();
	  			JsonObject fldrData = new JsonObject();
	  			fileData = db$GetRow("fs.files", queryFltr);
	  			queryFltr.remove("metadata.FileUrlToken");
	  			queryFltr.addProperty("folderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			fldrData = db$GetRow("ICOR_M_DMS_FOLDERS", queryFltr);
	  			i$Doc.addProperty("OperatedOnVer", fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("Name", fileData.get("metadata").getAsJsonObject().get("FileName").getAsString());
	  			i$Doc.addProperty("parentFolderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			i$Doc.addProperty("folderLevel",fldrData.get("folderLevel").getAsString());
	  			i$Doc.addProperty("currVer",fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("remarks", "File Sent Successfully");//SKG00023 changes end 
		   }
 		  else if(I$utils.$iStrFuzzyMatch(ScrId, "ODSFAVRT")){//SKG00027 changes starts
 				//queryfilter.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
  			  if(I$utils.$iStrFuzzyMatch(SOpr, "FAVOURITE")) {
  				queryfilter.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
			   	JsonObject queryFltr = new JsonObject();
	  			i$Doc.addProperty("Action", ScrId+"_"+SOpr);
	  			i$Doc.addProperty("Operation", SOpr);
	  			i$Doc.addProperty("OperatedOn", "File");
	  			queryFltr.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsString());
	  			JsonObject fileData = new JsonObject();
	  			JsonObject fldrData = new JsonObject();
	  			fileData = db$GetRow("fs.files", queryFltr);
	  			queryFltr.remove("metadata.FileUrlToken");
	  			queryFltr.addProperty("folderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			fldrData = db$GetRow("ICOR_M_DMS_FOLDERS", queryFltr);
	  			i$Doc.addProperty("OperatedOnVer", fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("Name", fileData.get("metadata").getAsJsonObject().get("FileName").getAsString());
	  			i$Doc.addProperty("parentFolderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			i$Doc.addProperty("folderLevel",fldrData.get("folderLevel").getAsString());
	  			i$Doc.addProperty("currVer",fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("remarks", "Documents Successfully Added to Favorites");//SKG00023 changes end 
  			  }else if(I$utils.$iStrFuzzyMatch(SOpr, "UNFAVOURITE")) {
  				queryfilter.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
			   	JsonObject queryFltr = new JsonObject();
	  			i$Doc.addProperty("Action", ScrId+"_"+SOpr);
	  			i$Doc.addProperty("Operation", SOpr);
	  			i$Doc.addProperty("OperatedOn", "File");
	  			queryFltr.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsString());
	  			JsonObject fileData = new JsonObject();
	  			JsonObject fldrData = new JsonObject();
	  			fileData = db$GetRow("fs.files", queryFltr);
	  			queryFltr.remove("metadata.FileUrlToken");
	  			queryFltr.addProperty("folderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			fldrData = db$GetRow("ICOR_M_DMS_FOLDERS", queryFltr);
	  			i$Doc.addProperty("OperatedOnVer", fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("Name", fileData.get("metadata").getAsJsonObject().get("FileName").getAsString());
	  			i$Doc.addProperty("parentFolderId", fileData.get("metadata").getAsJsonObject().get("parentFolderId").getAsString());
	  			i$Doc.addProperty("folderLevel",fldrData.get("folderLevel").getAsString());
	  			i$Doc.addProperty("currVer",fldrData.get("verNo").getAsString());
	  			i$Doc.addProperty("remarks", "Documents Successfully Removed from Favorites");//SKG00023 changes end 
  			  }
  			 
 		  }//SKG00027 changes end
  		   
       		logger.debug("*******checking 22222 exception*********");
 			i$Doc.add("ModifiedAt", i$ResM.adddate(new Date()));
 			//// SKG00025 changes starts 
 			try {
				if (I$utils.$iStrBlank(IResManipulator.iloggedUser.get())) {
					i$Doc.addProperty("ModifiedBy", i$body.get("user").getAsString());
				} else {
					i$Doc.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
				}
			} catch (Exception e) {
				i$Doc.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
			}// SKG00025 changes end 
 			//SKG00031 changes starts 
 			try {
 				String parentFolderName = i$body.get("LinkedCustNo").getAsString();	//SKG00031 changes
 				JsonObject projection1 = new JsonObject();	//SKG00031 changes  
				if (I$utils.$iStrFuzzyMatch(parentFolderName, "ALOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLTRREQ")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DLOANS")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFIP") ||I$utils.$iStrFuzzyMatch(parentFolderName, "AFCIP")||I$utils.$iStrFuzzyMatch(parentFolderName, "ALINCU")||I$utils.$iStrFuzzyMatch(parentFolderName, "DPAY")||I$utils.$iStrFuzzyMatch(parentFolderName, "DFCIP")) {
					JsonObject filter = new JsonObject();
					//JsonObject projection = new JsonObject();
//					JsonObject cif = new JsonObject();
					projection1.addProperty("_id", 0);
					projection1.addProperty("CustomerFullName", 1);
					filter.addProperty("CustomerId", i$Doc.get("ModifiedBy").getAsString());
				    JsonObject db$res = db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection1);
					i$Doc.addProperty("ModifiedBy", db$res.get("CustomerFullName").getAsString());

				} 
			}catch (Exception e) {
				e.printStackTrace();
			}
 			//SKG00031 changes end 
 			String iDoc = "{'history':"+i$Doc+"}";
 			logger.debug("*******I$DOC*********" + iDoc);
 			db$UpdateRowOperator("fs.files", iDoc, queryfilter, "false", "push");//SKG00036 changes
 			logger.debug("*******AFTER UPDATING THE HISTORY*********");
 			if(inActvteHisRecs) {
 	       		logger.debug("*******checking SRM1111 123123 exception*********");
 				qryDelFltr.addProperty("active","A");
 				logger.debug("*******iNSIDE IF CONDITION OF THE ISACTIVEHISRECS*********");
 				db$UpdateRowOperator("fs.files", "{'active':'I'}", qryDelFltr, "false", "N");//SKG00036 changes
 				
 			}

        }catch(Exception e) {
        	logger.debug("*******checking history exception SRM1111*********"+e.getMessage());
            e.printStackTrace();
            
        }
    }
	
	public boolean db$DocPassVerify(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		int iRowCnt = 0;
		try {
			JsonObject fkFilter = new JsonObject();
			fkFilter.addProperty("metadata.isCurrVer", "Y");
			fkFilter.addProperty("metadata.fileKey", I$impactoUtil.encrypt(i$body.get("fileKey").getAsString()));
			if(i$body.get("FileUrlToken").isJsonArray())
				fkFilter.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsJsonArray().get(0).getAsString());
			else
				fkFilter.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsString());
			fkFilter.addProperty("metadata.isPswrdPrctd", true); // #SRM00012 changes
			iRowCnt = db$GetRowCnt("fs.files", fkFilter);
			return iRowCnt > 0;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	// NK00010 starts
	public boolean db$docpassverifytrash(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		int iRowCnt = 0;
		try {
			JsonObject fkFilter = new JsonObject();
			fkFilter.addProperty("isCurrVer", "N");
			fkFilter.addProperty("fileKey", I$impactoUtil.encrypt(i$body.get("fileKey").getAsString()));
			if(i$body.get("FileUrlToken").isJsonArray())
				fkFilter.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsJsonArray().get(0).getAsString());
			else
				fkFilter.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
			fkFilter.addProperty("isPswrdPrctd", true);
			iRowCnt = db$GetRowCnt("ICOR_M_DMS_TRASH", fkFilter);
			return iRowCnt > 0;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	// NK00010 ends
	// #BVB00047
	public ArrayList<String> db$getAccessModules(String userId) {
		ArrayList<String> moduleList = new ArrayList<String>();
		try {
			Gson gson = new Gson();
			JsonObject filter = new JsonObject();
			filter.addProperty("userId", userId);
			filter.addProperty("active", "A"); // #MAQ00001
			JsonArray i$modules = db$GetRow("ICOR_M_USER_PRF", filter).getAsJsonArray("modules");
			moduleList = I$impactoUtil.$jsonArrayToSList(i$modules);

		} catch (Exception e) {
			moduleList = null;
		}
		return moduleList;
	}

	public boolean db$hasModuleRights(String userId, JsonArray module) {

		return db$hasModuleAccessAny(userId, I$impactoUtil.$jsonArrayToSList(module));

	}
	// #BVB00047 Ends

	public JsonArray db$IDoczScopeAccess(String CollName,JsonArray projection) {
        JsonArray resDocs = new JsonArray();
        try {
            JsonObject projQ = new JsonObject();
            String userId = IResManipulator.iloggedUser.get();
            JsonObject queryfilter = new JsonObject();
            queryfilter.addProperty("userId", userId);
            queryfilter.addProperty("active", "A");
            JsonObject userInfo = db$GetRow("ICOR_M_USER_PRF", queryfilter.toString());
            JsonArray roleIds = userInfo.get("roles").getAsJsonArray();
            String filter = "{'$and':[{'operation':{$ne:'DELETE'}},{'isCurrVer':'Y'},{'$or':[{'scope':'Protected', 'roleOrUserType':'U','allowed$Users': {'$in':['"+userId+"']}},{'scope':'Protected','roleOrUserType':'R','allowed$Roles':{'$in':"+roleIds+"}},{'scope':'Public'},{'scope':'Private','initiator':'"+userId+"'}]}]}";                                 
            for(int i=0;i<projection.size();i++) {
                projQ.addProperty(projection.get(i).getAsString(),1);
            }
             resDocs = db$GetRows(CollName,filter, projQ);
             //isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body",resDocs);
        }catch(Exception e) {
            e.printStackTrace();
            
        }
        return resDocs;
    }
	
	// NYE BEGINS
	// public JsonArray db$getQRights(String userId) { // #BVB00129
	public JsonArray db$getQRights(String userId) { // #BVB00129
		try {

			// JsonArray i$QueAcc = new JsonArray();// #BVB00129
			JsonObject i$QueAcc = new JsonObject();// #BVB00129
			JsonArray i$QueAccs = new JsonArray();

			JsonObject i$runningQuery = new JsonObject();
			JsonObject res = new JsonObject();

			// Getting Function Access Based on User Id
			i$runningQuery.addProperty("roleOrUser", "U");
			i$runningQuery.addProperty("userId", userId);
			String iRoles = getRoles();
			String qury = "{\"roleOrUser\":\"R\",\"roleId\":{ \"$in\": [" + iRoles + "]}}";

			JsonArray i$MasterQueAcc = db$GetRows("ICOR_M_QUEUE_ACC", i$runningQuery.toString());

			if (i$MasterQueAcc != null) {
				for (int i = 0; i < i$MasterQueAcc.size(); i++) {
					// #BVB00129 Starts
					// i$QueAcc.addAll(i$MasterQueAcc.get(i).getAsJsonObject().getAsJsonArray("queueAccess"));
					// i$QueAcc.addAll(i$MasterQueAcc.get(i).getAsJsonObject().getAsJsonObject("queueAccess"));

					i$QueAccs.add(i$MasterQueAcc.get(i).getAsJsonObject().get("queueAccess")); // #BZ000041 change

					// #BVB00129 Ends
				}
			}

			// getting the role and assigned Queues
			// #BZ000041 Begins
			JsonArray i$MasterRoleAccess = new JsonArray();
			// "{\"_id\":0,\"queueAccess\":1}"
			i$MasterRoleAccess = db$GetRows("ICOR_M_QUEUE_ACC", qury);
			if (i$MasterRoleAccess != null) {
				for (int i = 0; i < i$MasterRoleAccess.size(); i++) {
					i$QueAccs.add(i$MasterRoleAccess.get(i).getAsJsonObject().get("queueAccess"));

				}
			}

			// #BZ000041 Ends
// #BVB00129 Starts 
//			// Getting roles of a User
//			i$runningQuery = new JsonObject();
//			i$runningQuery.addProperty("userId", userId);
//			JsonObject i$MasterUserPrf = db$GetRow("ICOR_M_USER_PRF", i$runningQuery.toString());
//			JsonArray i$roles = i$MasterUserPrf.getAsJsonArray("roles");
//
//			for (int i = 0; i < i$roles.size(); i++) {
//				i$runningQuery = new JsonObject(); // #BVB00017
//				i$runningQuery.addProperty("roleOrUser", "R");
//				i$runningQuery.addProperty("roleId", i$roles.getAsJsonArray().get(i).getAsString());
//
//				i$MasterQueAcc = db$GetRows("ICOR_M_FUNC_ACC", i$runningQuery.toString());
//
//				if (i$MasterQueAcc != null) {
//					for (int j = 0; j < i$MasterQueAcc.size(); j++) {
//						i$QueAcc.addAll(i$MasterQueAcc.get(j).getAsJsonObject().getAsJsonArray("queueAccess"));
//					}
//				}
//			}
// #BVB00129 Ends

			return i$QueAccs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	// NYE ENDS

	public boolean db$hasRights(String userId, String scrId, String scrOpr) {
		try {
			boolean i$hasRights = false;
			JsonObject i$runningQuery = new JsonObject();
			i$runningQuery.addProperty("functionAccessA.function_id", scrId);
			i$runningQuery.addProperty("functionAccessA." + scrOpr, true);
			i$runningQuery.addProperty("active", "A"); // #MAQ00001

			JsonArray i$MasterFuncAcc = db$GetRows("ICOR_M_FUNC_ACC", i$runningQuery.toString());

			// Getting roles of a User
			i$runningQuery = new JsonObject();
			i$runningQuery.addProperty("active", "A");
			i$runningQuery.addProperty("userId", userId);
			JsonObject i$MasterUserPrf = db$GetRow("ICOR_M_USER_PRF", i$runningQuery.toString());
			JsonArray i$roles = i$MasterUserPrf.getAsJsonArray("roles");

			// #BVB00007 Starts
			if (I$utils.$iExistsInArrayJ(i$roles, "ALLROLES")) {
				i$hasRights = true;
				return i$hasRights; // #BVB00029
			}
			;
			// #BVB00007 Ends

			for (int i = 0; i < i$MasterFuncAcc.size(); i++) {
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = i$MasterFuncAcc.get(i).getAsJsonObject();
				if (I$utils.$iStrFuzzyMatch(i$runningObj.get("roleOrUser").getAsString(), "R")) {
					if (I$utils.$iExistsInArrayJ(i$roles, i$runningObj.get("roleId").getAsString())) {
						i$hasRights = true;
						break;
					}
				} else if (I$utils.$iStrFuzzyMatch(i$runningObj.get("roleOrUser").getAsString(), "U")) {
					if (I$utils.$iStrFuzzyMatch(i$runningObj.get("userId").getAsString(), userId)) {
						i$hasRights = true;
						break;
					}
				}
			}

			return i$hasRights;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// #BVB00015 Starts
	public JsonArray db$getRights(String userId) {
		try {

			JsonArray i$funcAcc = new JsonArray();

			JsonObject i$runningQuery = new JsonObject();

			// Getting Function Access Based on User Id

			i$runningQuery.addProperty("roleOrUser", "U");
			i$runningQuery.addProperty("userId", userId);
			i$runningQuery.addProperty("active", "A"); // #MAQ00001

			JsonArray i$MasterFuncAcc = db$GetRows("ICOR_M_FUNC_ACC", i$runningQuery.toString());

			if (i$MasterFuncAcc != null) {
				for (int i = 0; i < i$MasterFuncAcc.size(); i++) {
					i$funcAcc.addAll(i$MasterFuncAcc.get(i).getAsJsonObject().getAsJsonArray("functionAccessA"));
				}
			}

			// Getting roles of a User
			i$runningQuery = new JsonObject();
			i$runningQuery.addProperty("userId", userId);
			i$runningQuery.addProperty("active", "A"); // #MAQ00001
			JsonObject i$MasterUserPrf = db$GetRow("ICOR_M_USER_PRF", i$runningQuery.toString());
			JsonArray i$roles = i$MasterUserPrf.getAsJsonArray("roles");

			for (int i = 0; i < i$roles.size(); i++) {
				// #MAQ00010 starts
				i$runningQuery = new JsonObject();
				i$runningQuery.addProperty("roleId", i$roles.getAsJsonArray().get(i).getAsString());
				i$runningQuery.addProperty("active", "A");
				JsonObject i$RolePrf = db$GetRow("ICOR_M_USER_RL_PRF", i$runningQuery.toString());
				try {
					if (i$RolePrf != null) {
						i$runningQuery = new JsonObject();
						i$runningQuery.addProperty("roleOrUser", "R");
						i$runningQuery.addProperty("roleId", i$roles.getAsJsonArray().get(i).getAsString());
						i$runningQuery.addProperty("active", "A");

						i$MasterFuncAcc = db$GetRows("ICOR_M_FUNC_ACC", i$runningQuery.toString());

						if (i$MasterFuncAcc != null) {
							for (int j = 0; j < i$MasterFuncAcc.size(); j++) {
								i$funcAcc.addAll(
										i$MasterFuncAcc.get(j).getAsJsonObject().getAsJsonArray("functionAccessA"));
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				// #MAQ00010 ends
			}
			// refine this object here: i$funcAcc -- this should return only one object per
			// screen id

			i$funcAcc = I$impactoUtil.refineFunctionAccess(i$funcAcc); // #BVB00139
			return i$funcAcc;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// #BVB00015 Ends

	// #BVBCURR

	public JsonObject db$getAmbRights(String userId) {

		JsonObject i$rights = new JsonObject();
		JsonObject filter = new JsonObject();
		try {
			filter = new JsonObject();
			filter.addProperty("Amd_Id", userId);
			JsonObject icorMAmb = db$GetRow("ICOR_M_B2U_AMBASSADOR", filter);
			if (!I$utils.$isNull(icorMAmb)) {
				// MAQ000025 starts
//				i$rights.addProperty("BranAllow", icorMAmb.get("BranAllow").getAsString());
//				i$rights.add("BranRestrs", icorMAmb.get("BranRestrs").getAsJsonArray());
				JsonObject Restrictions = icorMAmb.get("Restrictions").getAsJsonObject();
				i$rights.addProperty("BranAllow", Restrictions.get("CBS_BRANCHAllow").getAsString());
				i$rights.add("BranRestrs", Restrictions.get("CBS_BRANCHList").getAsJsonArray());
				// MAQ000025 ends
				i$rights.addProperty("TranAllow", icorMAmb.get("TranAllow").getAsString());
				i$rights.add("TranRestrs", icorMAmb.get("TranRestrs").getAsJsonArray());
			}else {
				i$rights = null;
			}
		} catch (Exception e) {
			i$rights = null;
		}
		return i$rights;
	}

	// BVBCURR

	public JsonObject db$copyCollection(String CollName, String outCollName, JsonObject match) {

		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Copy");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "match", match);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "out", outCollName);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;

		} catch (Exception e) {
			return null;
		}

	}

	public JsonObject db$copyCollection(String CollName, String outCollName, JsonObject match, JsonObject projection) {

		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Copy");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "match", match);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "out", outCollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;

		} catch (Exception e) {
			return null;
		}

	}

	public JsonObject db$UpdateRow$Where(String CollName, JsonObject i$Doc, String queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update$Where");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$UpdateRow$Where(String CollName, JsonObject i$Doc, JsonObject queryfilter) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update$Where");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$GetCount(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RCount");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00029 Starts
	public JsonObject db$GetCount(String CollName, JsonObject isonReq, String Jfilter) {
		try {
			JsonObject argJson = new JsonObject();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RCount");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			isonReq = db$ControllerResult(isonReq, argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return isonReq;

		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00029 Ends

	// #BVB00020 Starts

	public int db$GetCountI(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RCount");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			int i$count = db$Result.getAsJsonObject("i-body").get("iRowCnt").getAsInt();
			return i$count;
		} catch (Exception e) {
			return 0;
		}
	};

	public int db$GetCountI(String CollName, JsonObject Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RCount");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			int i$count = db$Result.getAsJsonObject("i-body").get("iRowCnt").getAsInt();
			return i$count;
		} catch (Exception e) {
			return 0;
		}
	};

	// #BVB00020 Ends

	// #MAQ00009 starts
	public int db$GetCountI(String CollName, JsonObject isonReq, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RCount");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			JsonObject db$Result = db$ControllerResult(argJson);
			int i$count = db$Result.getAsJsonObject("i-body").get("iRowCnt").getAsInt();
			return i$count;
		} catch (Exception e) {
			return 0;
		}
	};
	// #MAQ00009 ends

	public int db$GetCountIS(String CollName, JsonObject isonReq, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "RCount");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter, true);
			JsonObject db$Result = db$ControllerResult(argJson);
			int i$count = db$Result.getAsJsonObject("i-body").get("iRowCnt").getAsInt();
			return i$count;
		} catch (Exception e) {
			return 0;
		}
	};

	public JsonObject db$UpdateWNewFld(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Update$NewFld");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #00000009 Begins
	public JsonObject db$CreateColln(String CollName) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "CreateColln");
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// 0000010 begins
	public JsonObject db$GetChartData(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "get$ChartData");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	public JsonObject db$createIndex(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "create$Index");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00029 Starts
	public JsonObject db$InsertRow(String CollName, JsonObject isonReq, JsonObject i$Doc) {
		try {
			JsonObject argJson = new JsonObject();
			JsonParser parser = new JsonParser();
			// isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonReq, "i-body", "{}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Insert");
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #MAQ00001 Start
	public JsonObject db$getRowAgg(String CollName, JsonObject projection, int skip, int limit) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "QueryAgg");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			JsonObject db$Result = db$ControllerResult(argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};
	// #MAQ00001 End

	public JsonArray db$getRowAgg(String CollName, String Jfilter, JsonObject projection) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "QueryAgg");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00029 Ends

	// #NYE00001 Begins
	public Integer db$GetSeq(String seqid) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject seqJson = new JsonObject();
			Integer incBy = 0;
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "ICOR_S_SEQ_GEN");
			seqJson = db$GetRow("ICOR_S_SEQ_GEN", "{ \"seqID\": \"" + seqid + "\"}");
			if (seqJson == null)
				return null;
			incBy = seqJson.get("i-body").getAsJsonObject().get("incBy").getAsInt();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GetSeq");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", "{\"seqID\":\"" + seqid + "\"}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "updateClause",
					"update: {$inc:{currVal:" + incBy.toString() + "}}");
			JsonObject db$Result = db$ControllerResult(argJson);
			Integer iCurrVal = db$Result.get("i-body").getAsJsonObject().get("currVal").getAsInt();
			return iCurrVal;
		} catch (Exception e) {
			return null;
		}
	};

	// #NYE00004 Begins
	public String db$GetSeqFor(String seqid, String sAppend2) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject seqJson = new JsonObject();
			Integer incBy = 0;
			String sAppend = "";
			String sAppJulian = "";
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "ICOR_S_SEQ_GEN");
			seqJson = db$GetRow("ICOR_S_SEQ_GEN", "{ \"seqID\": \"" + seqid + "\"}");
			if (seqJson == null)
				return null;
			incBy = seqJson.get("incBy").getAsInt();
			if (seqJson.has("append"))// #NYE00004
				sAppend = seqJson.get("append").getAsString();

			if (seqJson.has("appendJulianDT"))// #NYE00004
			{
				if (I$utils.$iStrFuzzyMatch(seqJson.get("appendJulianDT").getAsString(), "Y"))
					sAppJulian = Integer.toString(I$utils
							.convertToJulian(new SimpleDateFormat("ddMMyyy").format(Calendar.getInstance().getTime())));
			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GetSeq");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", "{\"seqID\":\"" + seqid + "\"}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "updateClause",
					"{$inc:{currVal:" + incBy.toString() + "}}");
			JsonObject db$Result = db$ControllerResult(argJson);
			String sCurrVal = db$Result.get("i-body").getAsJsonObject().get("currVal").getAsString();// #NYE00004

			return sAppend + sAppend2 + sAppJulian + I$impactoUtil.lpad(sCurrVal, seqJson.get("len").getAsInt(), "0");
		} catch (Exception e) {
			return null;
		}
	};
	// #NYE00004 Ends

	public String db$GetSeqFor(String seqid) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject seqJson = new JsonObject();
			Integer incBy = 0;
			String sAppend = "";
			String sAppJulian = "";
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", "ICOR_S_SEQ_GEN");
			seqJson = db$GetRow("ICOR_S_SEQ_GEN", "{ \"seqID\": \"" + seqid + "\"}");
			if (seqJson == null)
				return null;
			incBy = seqJson.get("incBy").getAsInt();
			if (seqJson.has("append"))// #NYE00004
				sAppend = seqJson.get("append").getAsString();

			if (seqJson.has("appendJulianDT"))// #NYE00004
			{
				if (I$utils.$iStrFuzzyMatch(seqJson.get("appendJulianDT").getAsString(), "Y"))
					sAppJulian = Integer.toString(I$utils
							.convertToJulian(new SimpleDateFormat("ddMMyyy").format(Calendar.getInstance().getTime())));
			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "GetSeq");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", "{\"seqID\":\"" + seqid + "\"}");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "updateClause",
					"{$inc:{currVal:" + incBy.toString() + "}}");
			JsonObject db$Result = db$ControllerResult(argJson);
			String sCurrVal = db$Result.get("i-body").getAsJsonObject().get("currVal").getAsString();// #NYE00004

			return sAppend + sAppJulian + I$impactoUtil.lpad(sCurrVal, seqJson.get("len").getAsInt(), "0");
		} catch (Exception e) {
			return null;
		}
	};

	// #MAQ00002 Start
	public JsonObject db$GetAggregate(String CollName, String Jfilter) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Aggregate");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", Jfilter);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			// JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	};

	// #MAQ00002 End
	// #BVB00140 Starts
	public JsonArray db$DoAggregate(String CollName, JsonArray options) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "AggregateWOP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "options", options);
			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = i$ResM.getBodyA(db$Result);// db$Result.getAsJsonArray("i-body");

			return i$body;
		} catch (Exception e) {
			return null;
		}
	};
	// #BVB00140 Ends

	public JsonObject db$ControllerResult(JsonObject reqMessage, JsonObject argJson) {
		try {
			JsonObject result$ = null;
			// Class<?> dbClass = Class.forName(dbClassName);
			// Object db$Caller = dbClass.newInstance();
			// Method dbWorkerFunc = dbClass.getMethod("processDBOpr", JsonObject.class,
			// JsonObject.class);
			ImongoWorker I$mongoWorker = new ImongoWorker();
			result$ = I$mongoWorker.processDBOpr(reqMessage, argJson);

			// result$ = (JsonObject) dbWorkerFunc.invoke(db$Caller, reqMessage, argJson);
			return result$;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("DB Controller Error: " + e.getMessage());
			return null;
		}
	};

	public JsonObject db$ControllerResult(JsonObject argJson) {
		try {
			JsonObject result$ = null;
			/*
			 * Class<?> dbClass = Class.forName(dbClassName); Object db$Caller =
			 * dbClass.newInstance(); Method dbWorkerFunc =
			 * dbClass.getMethod("processDBOpr", JsonObject.class);
			 */

			ImongoWorker I$mongoWorker = new ImongoWorker();
			result$ = I$mongoWorker.processDBOpr(argJson);
			/* result$ = (JsonObject) dbWorkerFunc.invoke(db$Caller, argJson); */
			return result$;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("DB Controller Error: " + e.getMessage());
			return null;
		}
	};

	// #NYE00001 Ends

	public boolean db$hasQuOprRights(String userId, String wklFlow, String queues, String oprs, String iRoles) {
		try {

			JsonObject wf$Query = new JsonObject();
			String queryString = null;
			if (oprs.contains("NULL")) {
				queryString = "queueAccess." + wklFlow + "." + queues;
			} else {
				queryString = "queueAccess." + wklFlow + "." + queues + "." + oprs;
			}

			String qury = "{\"roleOrUser\":\"R\",\"roleId\":{ \"$in\": [" + iRoles + "]}," + "\"" + queryString + "\""
					+ ":true}"; // #BZ000042 change
			// String query1 = "{\"$and\":[{\"roleOrUser\":\"R\"},{\"roleId\":{ \"$in\": ["
			// + sroleMatch + "]}}]},{\"roleId\":1,\"queueAccess\":1}";

			wf$Query.addProperty("userId", userId);
			wf$Query.addProperty("active", "A"); // #MAQ00001
			wf$Query.addProperty(queryString, true);
			if (db$GetRowCnt("ICOR_M_QUEUE_ACC", wf$Query.toString()) >= 1) {
				return true;
			} else if (db$GetRowCnt("ICOR_M_QUEUE_ACC", qury) >= 1) { // #BZ000042 change
				return true;
			} else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// #BVB00058 Starts
	public JsonObject db$GetRowWithId(String CollName, String id) {
		try {

			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "QueryWithId");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "id", id);
			JsonObject db$Result = db$ControllerResult(argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return (JsonObject) i$body.get(0);
		} catch (Exception e) {
			return null;
		}
	};

	// #BVB00058 Ends

	public JsonObject getLoggedInUsers(JsonObject isonMsg) {
		JsonArray loggedInList = new JsonArray();
		String filter = "";
		JsonObject projection = new JsonObject();

		try {
			filter = "{'userId':{$exists:true}}";
			projection.addProperty("userId", "1");
			projection.addProperty("createdAt", "1");
			projection.addProperty("lastActivityAt", "1");
			loggedInList = db$GetRows("ICOR_S_SESSION_VALIDATOR", filter, projection);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, loggedInList);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOGGED IN USERS FETCHED SUCESSFULLY");

		} catch (Exception e) {
			logger.debug("Failed in Fetching Logged In users with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "FAILED WHILE FETCHING LOGGED IN USERS");
		}

		return isonMsg;
	}

	// #BVB00081 starts

	public boolean isUserValid(String userId) {
		boolean isUserValid = false;
		JsonObject filter = new JsonObject();
		try {
			filter.addProperty("userId", userId);
			filter.addProperty("active", "A");
			filter.addProperty("recordStat", "O");

			if (db$GetCountI("ICOR_M_USER_PRF", filter) > 0) {
				isUserValid = true;
			}
		} catch (Exception e) {
			logger.debug("Failed in Verifying is User is Valid or not with: " + e.getMessage());
		}

		return isUserValid;
	}

	public boolean isUserValid() {
		boolean isUserValid = false;
		JsonObject filter = new JsonObject();
		try {
			filter.addProperty("userId", IResManipulator.iloggedUser.get());
			filter.addProperty("active", "A");
			filter.addProperty("recordStat", "O");

			if (db$GetCountI("ICOR_M_USER_PRF", filter) > 0) {
				isUserValid = true;
			}
		} catch (Exception e) {
			logger.debug("Failed in Verifying is User is Valid or not with: " + e.getMessage());
		}

		return isUserValid;
	}

	// #BVB00081 Ends
	// #BVB00097 Starts
	public JsonArray getUserAllowedBrns(String userId) {
		JsonArray userABrn = new JsonArray();
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		try {
			filter.addProperty("Amd_Id", userId);
			// MAQ000025 starts
			projection.addProperty("Restrictions", "1");
			projection.addProperty("_id", 0);
			JsonObject icorMbAmb = db$GetRow("ICOR_M_B2U_AMBASSADOR", filter, projection);
//			String branAllow = icorMbAmb.get("BranAllow").getAsString();
//			JsonArray branRestrs = icorMbAmb.getAsJsonArray("BranRestrs");
			JsonObject Restrictions = icorMbAmb.get("Restrictions").getAsJsonObject();
			String branAllow = Restrictions.get("CBS_BRANCHAllow").getAsString();
			JsonArray branRestrs = Restrictions.get("CBS_BRANCHList").getAsJsonArray();
			if (I$utils.$iStrFuzzyMatch(branAllow, "A")) {
				userABrn = branRestrs;
			} else if (I$utils.$iStrFuzzyMatch(branAllow, "D")) {
				// Get all existing branches.. Remove these from that list
				projection = new JsonObject();
				filter = new JsonObject();
				JsonArray existingBrns = new JsonArray();
				filter.addProperty("Type", "CBS_BRANCH");
				projection.addProperty("KeyId", "1");
				projection.addProperty("_id", 0);
				JsonArray Branchcodes = db$GetRows("ICOR_M_CBS_E_DATA", filter, projection);
				for (int i = 0; i < Branchcodes.size(); i++) {
					existingBrns.add(Branchcodes.get(i).getAsJsonObject().get("KeyId").getAsString());
				}
				userABrn = I$impactoUtil.notInArray(existingBrns, branRestrs);
				// MAQ000025 ends
			}
		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Faled in Getting User Allowed Modules: " + e.getMessage());
			userABrn = new JsonArray();
		}
		return userABrn;
	}
	
	// #BVB00097 Ends
	// #BVB00052 Starts
	public JsonObject db$UpdateMany(String CollName, JsonArray i$Doc, JsonArray queryfilter, String upsert) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "BulkUpdate");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "upsert", upsert);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};

	// #MAQ00014 starts
	public String getSelfModifyAccess(String ScrId) {
		String selfModifyAccess = "N";
		try {
			JsonObject filter = new JsonObject();
			filter.addProperty("SCRID", ScrId);
			JsonObject projection = new JsonObject();
			projection.addProperty("SELFMODIFYALLOWED", 1);
			projection.addProperty("_id", 0);
			JsonObject res = db$GetRow("ICOR_C_SCR_COLL_MAP", filter, projection);
			selfModifyAccess = res.get("SELFMODIFYALLOWED").getAsString();
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getMessage());
		}

		return selfModifyAccess;
	}
	// #MAQ00014 ends

	// #BVB00052 Ends
	public DBController() {
		// construnct
	}

	// MAQ00005 code starts
	public JsonObject db$GetRows$Sort(String CollName, JsonObject isonMsg, Integer i$MaxRow, JsonObject filter,
			JsonObject projection, int skip, int limit, String sort) {
		try {
			JsonObject argJson = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Query");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", filter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "projection", projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "skip", skip);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "limit", limit);
			argJson.addProperty("sort", sort);
			JsonObject db$Result = db$ControllerResult(isonMsg, argJson);
			return db$Result;
		} catch (Exception e) {
			return null;
		}
	}
	// MAQ00005 code ends

	// MAQ00018 starts
	public JsonObject db$StorePassHist(String StrGetSalt, String StrEncrytPass, JsonObject i$PassHist, String username) {
		try {
			JsonArray hist = new JsonArray();
			JsonObject Jfilter = new JsonObject();
			String merSaltPass = StrGetSalt + "_IMP_" + StrEncrytPass;

			if (i$PassHist != null) {
				Jfilter.addProperty("userId", IResManipulator.iloggedUser.get());
				i$PassHist.get("passHist").getAsJsonArray().add(merSaltPass);
				db$UpdateRow("ICOR_M_PASSWORD_HISTORY", i$PassHist, Jfilter, "false");
			} else {
				i$PassHist = new JsonObject();
				i$PassHist.addProperty("userId", username);
				hist.add(merSaltPass);
				i$PassHist.add("passHist", hist);
				db$InsertRow("ICOR_M_PASSWORD_HISTORY", i$PassHist);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// MAQ00018 ends
	// BHUVI002 Starts
	public JsonObject db$UpdateMany(String CollName, JsonObject i$Doc, JsonArray queryfilter, String columnName,
			String upsert) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", i$Doc);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "BulkUpdate");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "upsert", upsert);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "columnName", columnName);
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	// BHUVI002 Ends
	//#BHUVI003 Start
	public JsonArray db$Distinct(String CollName, String queryfilter,String fieldName) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Distinct");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "queryfilter", queryfilter);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "fieldName", fieldName);
			JsonObject db$Result = db$ControllerResult(isonReq, argJson);
			JsonArray i$body = db$Result.getAsJsonArray("i-body");
			return i$body;
		} catch (Exception e) {
			return null;
		}
	};
	//#BHUVI003 Ends
	// getting the attached Roles for the user ID
	// #00000020 begins
	@SuppressWarnings("unused")
	public String getRoles() {
		ArrayList<String> iQueus = new ArrayList<String>();
		ArrayList<String> iRoles = new ArrayList<String>();
		String sroleMatch = null;
		try {

			ArrayList<String> iUsrQueus = new ArrayList<String>();
			ArrayList<String> wrkFlws = new ArrayList<String>();
			JsonArray i$Roles = db$GetRows("ICOR_M_USER_PRF",
					"{\"userId\":\"" + IResManipulator.iloggedUser.get() + "\"}", "{\"roles\":1}");
			if (i$Roles != null) {
				for (int i = 0; i < i$Roles.size(); i++) {
					try {
						iRoles.add(i$Roles.get(i).getAsJsonObject().get("roles").getAsString());
					} catch (Exception e) { // #00000006 | Fixes for defect ID 285 starts
						JsonObject irole = new JsonObject();
						irole = i$Roles.get(i).getAsJsonObject();
						JsonArray irls = new JsonArray();
						irls = irole.get("roles").getAsJsonArray();
						for (int itr = 0; itr < irls.size(); itr++) {
							String abcs = irls.get(itr).getAsString();
							iRoles.add(abcs);

						}

					}
				}

				// Get the Ques for the Workflow Ids with user ID

				for (int i = 0; i < iRoles.size(); i++) {
					if (i == 0)
						sroleMatch = "\"" + iRoles.get(i) + "\"";
					else
						sroleMatch += ",\"" + iRoles.get(i) + "\"";
				}
				;
				return sroleMatch;
			}
		} catch (Exception e) {
			// nothing here
		}

		return sroleMatch;

	}// #00000020 ends
	// #BVB00186 Starts 
	public JsonArray db$getAccounts(String CustNo) {
		JsonArray custNoArr = new JsonArray(); 
		custNoArr.add(CustNo);
		return db$getAccounts(custNoArr); 
	}

	public JsonArray db$getAccounts(JsonArray CustNo) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonArray accountData = new JsonArray();
		String accType = "";
		String custNos = "{$in:['";
		try {
			if (CustNo.size() > 0) {
//				String userId = IResManipulator.iloggedUser.get();
//				JsonArray userABrn = getUserAllowedBrns(userId);
//				String alwBrn = "{'$in':['";
//				if (userABrn.size() > 0) {
//					for (int i = 0; i < userABrn.size(); i++) {
//						// {'$in':[]}
//						String runningBrn = userABrn.get(i).getAsString();
//						if (i <= userABrn.size() - 2) {
//							alwBrn = alwBrn + runningBrn + "','";
//						} else {
//							alwBrn = alwBrn + runningBrn + "']}";
//						}
//					}
//				} else {
//					alwBrn = alwBrn + "']}";
//				}
//				// Should not get the self account details
//				filter = new JsonObject();
//				filter.addProperty("userId", userId);
//				JsonObject icorMusrPf = db$GetRow("ICOR_M_USER_PRF", filter);
//				// #BVB00199 Starts 
				String memberNo = ""; 
//				try {
//					memberNo = icorMusrPf.get("memberNo").getAsString();
//				}catch (Exception e) {
//					memberNo = ""; 
//				}
				// #BVB00199 Ends
				if (CustNo.size() > 0) {
					for (int i = 0; i < CustNo.size(); i++) {
						String runningCustNo = CustNo.get(i).getAsString();
						if (i <= CustNo.size() - 2) {
							custNos = custNos + runningCustNo + "','";
						} else {
							custNos = custNos + runningCustNo + "']}";
						}
					}
				} else {
					custNos = custNos + "']}";
				}

//				String filterS = "{'$and' :[ {'CustNo':'" + CustNo + "', 'AcBranch': " + alwBrn
//						+ "}, {'CustNo': {'$nin':['" + memberNo + "']}}]}";
				
				try {
					accType =IDataValidator.J$TempStorage.get().get("AccountClassType").getAsString();    //#PKY00034 changes
				}catch(Exception e) {
					
				}
				
				String filterS = "";
				if(I$utils.$iStrBlank(accType))
					filterS = "{'$and' :[ {'CustNo':" + custNos + "}, {'CustNo': {'$nin':['" + memberNo + "']}}]}";
				else if(I$utils.$iStrFuzzyMatch(accType, "Shares"))         //#SRP00019 Starts
					filterS = "{'AccountClassType':'"+accType+"','$and' :[ {'CustNo':" + custNos + "},{'CustomerAccountClass': {'$ne':'155'}}, {'CustNo': {'$nin':['" + memberNo + "']}}]}";   //#PKY00034 #MVT00107 changes
				else if(I$utils.$iStrFuzzyMatch(accType, "FD"))
				    filterS = "{'AccountClassType':{'$in':['Shares','Deposits']},'$and' :[ {'CustNo':" + custNos + "}, {'CustNo': {'$nin':['" + memberNo + "']}}]}";  //#SRP00019 Ends
				
				projection.addProperty("_id", 0);
				projection.addProperty("CustAcNo", 1);  // #SKP0002 changed to integer
				projection.addProperty("AcDesc", 1);    // #SKP0002 changed to integer
				// projection.addProperty("CustNo", "1"); 
				projection.addProperty("AcCcy", 1);     // #SKP0002 changed to integer
				projection.addProperty("AcBranch", 1);  // #SKP0002 changed to integer
				projection.addProperty("CustomerImg", 1); // #SKP0002 changed to integer
				projection.addProperty("AccountClassType", 1);  
				projection.addProperty("AccountClassDesc", 1);  //#SRI00030 changes 
				// #BVB00180 Starts

				accountData = db$GetRows("ICOR_M_CBS_ACCOUNT_DATA", filterS, projection);
				// Get Joint Accounts 
				JsonArray accounts = new JsonArray();
				if (I$utils.$isNull(accountData)) {
					accountData = new JsonArray();
				}else {
					for(int i=0; i<accountData.size(); i++) {
						try {
						accounts.add(accountData.get(i).getAsJsonObject().get("CustAcNo").getAsString());
						}catch (Exception e) {
							// Eat Up 
						}
					}
					accountData.addAll(db$getJointAccounts(accounts));
				}
			}
		} catch (Exception e) {
			accountData = new JsonArray();
		}
		return accountData;
	}

	public JsonArray db$getJointAccounts(String CustAcNo) {
		JsonArray custAccNoArr = new JsonArray(); 
		custAccNoArr.add(CustAcNo);
		return db$getJointAccounts(custAccNoArr); 
	}
	
	public JsonArray db$getJointAccountsNoAcess(String CustAcNo) {
		JsonArray custAccNoArr = new JsonArray(); 
		custAccNoArr.add(CustAcNo);
		return db$getJointAccounts(custAccNoArr); 
	}
	
	public JsonArray db$getJointAccounts(JsonArray CustAcNos) {
		JsonObject filter = new JsonObject(); 
		JsonObject projection = new JsonObject(); 
		JsonArray jointAccounts = new JsonArray(); 
		JsonArray custNos = new JsonArray(); 
		String cusAccNos=  "{$in:['"; 
		try {
			// Get all customer No linked
			
			if (CustAcNos.size() > 0) {
				for (int i = 0; i < CustAcNos.size(); i++) {
					String runningCustAccNo = CustAcNos.get(i).getAsString();
					if (i <= CustAcNos.size() - 2) {
						cusAccNos = cusAccNos + runningCustAccNo + "','";
					} else {
						cusAccNos = cusAccNos + runningCustAccNo + "']}";
					}
				}
			} else {
				cusAccNos = cusAccNos + "']}";
			}
			
			filter.addProperty("CustAcNo", cusAccNos);
			String filterS = "{'CustAcNo':"+cusAccNos+"}"; 
			//filter.addProperty("", ); // Need to add end date
			JsonArray linkedCustNo = db$GetRows("ICOR_M_CBS_JOINT_DATA", filterS,projection); 
			
			for(int i=0 ;i<linkedCustNo.size(); i++) {
				JsonObject i$runningObj = linkedCustNo.get(i).getAsJsonObject(); 
				String cif = i$runningObj.get("CustNo").getAsString();
				custNos.add(cif);
			}
			jointAccounts.addAll(db$getAccounts(custNos) );
			// Get all the accounts of customers given

		} catch (Exception e) {
			// Eat Up 
		}
		
		return jointAccounts;

	}
	// #BVB00186 Ends

	public JsonObject db$InsertRow(String CollName, String i$Doc, String sessionType) {
		try {
			JsonObject argJson = new JsonObject();
			JsonObject isonReq = new JsonObject();
			JsonParser parser = new JsonParser();
			isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
					"i-body", parser.parse(i$Doc).getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "CollName", CollName);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "MongoOprMode", "Insert");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "sessionType", sessionType);
			
			isonReq = db$ControllerResult(isonReq, argJson);
			return isonReq;
		} catch (Exception e) {
			return null;
		}
	};
	//#PKY00017 starts
	public JsonObject cbsCifData (String custId, String project) {  //takes customerId as filter
		JsonObject cbs$Data = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		try {
			if(!I$utils.$iStrBlank(custId)) {
				filter.addProperty("CustomerId",custId);
				if(I$utils.$iStrBlank(project)) {
					projection.addProperty("_id", 0);
				}
				cbs$Data = db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection);
				return cbs$Data;
			}
			else {
				return null;
			}
		}catch(Exception e) {
			return null;
		}
	}
	//#PKY00017 ends

}