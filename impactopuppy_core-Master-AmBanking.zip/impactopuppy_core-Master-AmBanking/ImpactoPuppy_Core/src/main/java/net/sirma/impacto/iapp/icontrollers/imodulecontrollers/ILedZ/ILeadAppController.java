/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Baz 		| Mar 25, 2019 | #0000001   | Initial writing
      |0.2.1       | Pappu      | Jul 20, 2021 | #PKY00025  | Fixed issue of i-stat
      |0.2.1       | Pappu      | Oct 14, 2021 | #PKY00053  | Handle ModifiedAt field
      |0.2.1	   | Manikanta  | OCT 12, 2022 | #MVT00079  | Added code to skip loan workflow
      |0.2.1	   | Manikanta  | Dec 15, 2022 | #MVT00096  | Added code to handle skipping loan application in threads
      |0.2.1	   | Madhura    | Dec 16, 2022 | #MSA00001  | Added code query operation for Existing Loan Application
      |0.2.1	   | Manikanta  | Jan 06, 2022 | #MVT00096  | Added code to send loan notification with by attaching pdf's
      |0.2.1       | Sindhu     | Jan 11, 2023 | #SRM00021  | Handled code for fetching the loan records that are from digiApp
      |0.2.1	   | Manikanta  | Jan 13, 2023 | #MVT00098  | Added code to for existing loan application details
      |0.2.1	   | Manikanta  | Feb 01, 2023 | #MVT00102  | Added code for Loan PDF attachment issues
      |0.2.1	   | Madhura    | May 23, 2023 | #MSA00015  | Added code for Unsecured Loan Feature
      |0.2.1	   | Sindhu     | Jun 23, 2023 | #SRM00044  | Added code for casa150 account validation
      |0.2.1	   | Manikanta  | Aug 08, 2023 | #MVT00133  | Added code to handle casa 150 for AL01 and CL01 Loan applications
      |0.2.1	   | Madhura    | Aug 21, 2023 | #MSA00032  | Added code to handle Success msg for Existing Loan applications.
      |0.2.1	   | Srikanth   | Feb 19, 2024 | #SRI00033  | Added code to handle the loanCategory to add in the Data base 
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers.ILedZ;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.codec.Base64;

import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IThreadController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IGDriveAPIController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.OtpController;
import net.sirma.impacto.iapp.ihelpers.IPDFPopulator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ILeadAppController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS****** *****************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil Im$utils = new ImpactoUtil();
	private OtpController i$otpC = new OtpController();
	private IResManipulator i$ResM = new IResManipulator();
	private IFuncSrvcController srvcFunction = new IFuncSrvcController();
	private IAppMessageHandler iAppMsgHandler = new IAppMessageHandler();   //#PKY00025 changes
	private static final Logger logger = LoggerFactory.getLogger(ILeadAppController.class);

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OLDLNCRT") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				return createLNAPApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OLDLNCRT") && I$utils.$iStrFuzzyMatch(SOpr, "PARTIAL_SAVE")) {
				return partialSaveLNAPApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OLDLNCRT") && I$utils.$iStrFuzzyMatch(SOpr, "GET_REC")) {
				return getVersionRecords(isonMsg, isonheader, isonMapJson);
			}else if (I$utils.$iStrFuzzyMatch(Scr, "OLDLNCRT") && I$utils.$iStrFuzzyMatch(SOpr, "AUTO_RENEWAL")) {
				return autoRenewalApln(isonMsg, isonheader, isonMapJson);
			}else if (I$utils.$iStrFuzzyMatch(Scr, "OLDEXIST") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				return existQuery(isonMsg, isonheader, isonMapJson);//MSA00001 changes
			}else if (I$utils.$iStrFuzzyMatch(Scr, "SLDLNCRT") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				return digiApln(isonMsg, isonheader, isonMapJson); // #SRM00021 Changes
			}
			else if (I$utils.$iStrFuzzyMatch(Scr, "LABLNTYP") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				return digiLoanType(isonMsg, isonheader, isonMapJson); // #SRM00021 Changes
			}
			else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	private JsonObject getVersionRecords(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject query = new JsonObject();
			query.addProperty("isCurrVer", "Y");

			query.addProperty("WorkFlowId", i$body.get("WorkFlowId").getAsString());
			query.addProperty("applicationId", i$body.get("applicationId").getAsString());
			query.addProperty("referenceNo", i$body.get("referenceNo").getAsString());

			JsonArray inc$appls = db$Ctrl.db$GetRows("ICOR_C_B2U_LOAN_APPLICATIONS_LEDGER", query);
			return i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, inc$appls);

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}

		return isonMsg;
	}
	
	//MSA starts
	public JsonObject digiLoanType(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String loanType = i$body.get("LoanType").getAsString();
			String loanProduct = i$body.get("LoanProduct").getAsString();
			JsonObject fltr = new JsonObject();
			fltr.addProperty("KeyDesc", loanType);
			fltr.addProperty("LoanProduct",loanProduct);
			JsonObject proj = new JsonObject();
			proj.addProperty("_id", 0);
			proj.addProperty("DefaultInterestRate", 1);
			proj.addProperty("DefaultTenor", 1);
			proj.addProperty("BranchDate", 1);
			proj.addProperty("MinInterestRate", 1);
			proj.addProperty("MaxInterestRate", 1);
			proj.addProperty("DefaultIntrestRate", 1);
			proj.addProperty("MinTenor", 1);
			proj.addProperty("MaxTenor", 1);
			proj.addProperty("TenorUnit", 1);
			JsonObject data = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", fltr, proj);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, data);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA FETCHED SUCCESSFULLY");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO FETCH DATA");
		}

		return isonMsg;
	}//MSA ends
	  //#SRM00021 begins
    public JsonObject digiApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

        String Coll_Name = "";
        try {
            Coll_Name = isonMapJson.get("COLLNAME").getAsString();
        } catch (Exception e) {
            Coll_Name = null;
        }
        ;
        JsonObject projection = new JsonObject();
        JsonObject queryFilter = new JsonObject();
        queryFilter.addProperty("digiApp", true);
        JsonArray appl = new JsonArray();
        projection.addProperty("applicationId", 1);
        projection.addProperty("createdAt", 1);
        projection.addProperty("WRK_FLW_STAGE", 1);
        appl = db$Ctrl.db$GetRows(Coll_Name, queryFilter, projection);
        isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", appl);
        
        return isonMsg;
    }
    //#SRM00021 ends

	public JsonObject createLNAPApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
        JsonObject jConfig = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String ScrCtrlClass = null;
		String sAppNumber = null;
		jBody = i$ResM.getBody(isonMsg);
        jConfig = i$ResM.getConfig(isonMsg);
        String srcId = jConfig.get("SrcID").getAsString();
		String Scr = i$ResM.getScreenID(isonMsg);
		IPDFPopulator ipdfPop = new IPDFPopulator();
		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;
			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "isCurrVer", "Y");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
					i$ResM.adddate(new Date()).getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "ModifiedAt",i$ResM.adddate(new Date()).getAsJsonObject()); //PKY00053 changes

			try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "iLeadSource",
					i$ResM.getClientApp(isonMsg));
			}catch(Exception e) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "iLeadSource",
						i$ResM.getSrcId(isonMsg));	
			}
			

			jFilter.addProperty("referenceNo", sRef);
			jFilter.addProperty("applicationId", sAppNumber);

			// Construct the PDF Json Object P.S: Keys should match with the PDF field
			// Names"
			JsonObject pdfDetails = new JsonObject();

			// get the customer details cbs_cif_data collection
			JsonObject cif$data = new JsonObject();
			String cif = jBody.get("cif").getAsString();
			cif$data = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", "{\"CustomerId\":\"" + cif + "\"}");

			try {
				pdfDetails.addProperty("FirstName", cif$data.get("CustomerFirstName").getAsString());
				pdfDetails.addProperty("LastName", cif$data.get("CustomerLastName").getAsString());
				pdfDetails.addProperty("MidleName", cif$data.get("CustomerMiddleName").getAsString());

				pdfDetails.addProperty("HomeAddress", cif$data.get("AddressForCorrespondence1").getAsString());
				pdfDetails.addProperty("Line 2", cif$data.get("AddressForCorrespondence2").getAsString());
				pdfDetails.addProperty("Line 3", cif$data.get("AddressForCorrespondence3").getAsString());
				pdfDetails.addProperty("Line 4", cif$data.get("AddressForCorrespondence4").getAsString());
				try {
					pdfDetails.addProperty("Employer", cif$data.get("BorrowerCurrentEmployer").getAsString());
				} catch (Exception e) {
					pdfDetails.addProperty("Employer", "N/A");
				}
				;
				try {
					pdfDetails.addProperty("Employer's Address",
							cif$data.get("CustomerEmployerDescription").getAsString());
				} catch (Exception e) {
					pdfDetails.addProperty("Employer's Address", "N/A");
				}
				;

				try {
					pdfDetails.addProperty("Date Of Birth", cif$data.get("CustomerDobDate").getAsString());    //#PKY00025  changes
				} catch (Exception e) {
					pdfDetails.addProperty("Date Of Birth", "N/P");
				}
				;
				pdfDetails.addProperty("Purpose Of Loan", jBody.get("loanDetails").getAsJsonObject().get("loanPurpose").getAsString());    //#PKY00025  changes

				Date date = new Date();

				pdfDetails.addProperty("MemberNo", cif$data.get("CustomerId").getAsString());

				Date today = new Date();
				String strDate = null;

				try {
					SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
					strDate = formatter.format(today);
					pdfDetails.addProperty("Date", strDate);
				} catch (Exception e) {
					pdfDetails.addProperty("Date", "01/01/2019");
				}
				String fileName = "Lead" + " " + sAppNumber + ".pdf";

				String fileUrlToken = ipdfPop.populatePdf(pdfDetails, sAppNumber, fileName);

				try {
					jBody.addProperty("pdfFileUrlToken", fileUrlToken);
				} catch (Exception e) {
					// pass
				}

			} catch (Exception e) {

			}

			String srefqry = "{$ne: \"" + sRef + "\"}";
			JsonObject subqry = new JsonObject();
			subqry.addProperty("$ne", sRef);
			jFilter.add("referenceNo", subqry.getAsJsonObject());
			jFilter.addProperty("applicationId", sAppNumber);
			// String ftr$qry = "{\"applicationId\":\""+sAppNumber+"\",\"referenceNo\":{$ne:
			// \""+sRef+"\"}}";
			JsonObject $update = new JsonObject();
			$update.addProperty("isCurrVer", "N");
			db$Ctrl.db$UpdateRow(Coll_Name, $update, jFilter);
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", $update, jFilter);

			// Insert the data to the version history logger/ledger.
			db$Ctrl.db$InsertRow("ICOR_C_LD_LEAD_APPLICATIONS_LEDGER", jBody);

			// WOrkflow Status
			jFilter = new JsonObject();
			jFilter.addProperty("referenceNo", sRef);
			jFilter.addProperty("applicationId", sAppNumber);
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);
			if(I$utils.$iStrFuzzyMatch(srcId,"TecuDigiApp")) { //#SRM00021 changes
                jBody.addProperty("digiApp", true);
            }
			if (!(Appl$Json != null)) {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "O_OPEN"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}
			jBody.addProperty("referenceNo", sRef);
			JsonObject Jbdy = new JsonObject();
			// trigger Workflow
			if (I$utils.$iStrFuzzyMatch(DcStatus, "Completed")) {
				
				// update the referDc Applicaiton
				updateReferDcStatus(sAppNumber, Coll_Name);
				//#PKY00025 starts
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", IResManipulator.iloggedUser.get());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
				//#MVT00133 changes begins
				/*try {
                	JsonObject ison$Body = new JsonObject();
        			ison$Body = isonMsg.deepCopy();
        			JsonObject i$body = ison$Body.get("i-body").getAsJsonObject();
        			JsonArray funcDtl = new JsonArray();
        			JsonObject funcDtlObj = new JsonObject();
        			funcDtlObj.addProperty("memberId",cif);
        			funcDtlObj.addProperty("funcName","GET_CIF_SHARE_DEPOSIT");
        			funcDtl.add(funcDtlObj);
        			i$body.add("funcDetails", funcDtl);
                	JsonObject data = srvcFunction.exeCallOrcl(ison$Body); 
                	if((data.has("i-body")&&data.getAsJsonObject("i-body").getAsJsonArray("funcRes").size()<1)) {
                		jBody.addProperty("casa150", "true"); //SRM00044 Changes
                	} else {
//                		jBody.addProperty("casa150", "true");
						jBody.addProperty("accountNo", data.getAsJsonObject("GET_CIF_SHARE_DEPOSIT").get("l_data").getAsString());
                	}
                }catch(Exception e) {
                	logger.debug(e.getMessage());
                }*/
				
				jFilter.addProperty("applicationId", sAppNumber);
				jFilter.addProperty("referenceNo", sRef);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
                JsonObject loanDetails = jBody.get("loanDetails").getAsJsonObject();//MSA00015 starts
                
/*                try {
                	JsonObject ison$Body = new JsonObject();
        			ison$Body = isonMsg.deepCopy();
        			JsonObject i$body = ison$Body.get("i-body").getAsJsonObject();
        			JsonArray funcDtl = new JsonArray();
        			JsonObject funcDtlObj = new JsonObject();
        			funcDtlObj.addProperty("memberId",cif);
        			funcDtlObj.addProperty("funcName","GET_CIF_SHARE_DEPOSIT");
        			funcDtl.add(funcDtlObj);
        			i$body.add("funcDetails", funcDtl);
                	JsonObject data = srvcFunction.exeCallOrcl(ison$Body); 
                	if((data.has("i-body")&&data.getAsJsonObject("i-body").getAsJsonArray("funcRes").size()<1)) {
                		jBody.addProperty("casa150", "true"); //SRM00044 Changes
                	} else {
                		jBody.addProperty("casa150", "true");
//						jBody.addProperty("accountNo", data.getAsJsonObject("GET_CIF_SHARE_DEPOSIT").get("l_data").getAsString());
                	}
                }catch(Exception e) {
                	logger.debug(e.getMessage());
                }*/
                
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);// #MVT00096 changes begins
				if (!(I$utils.$iStrFuzzyMatch(loanDetails.get("loanProduct").getAsString(), "CL01") || I$utils.$iStrFuzzyMatch(loanDetails.get("loanProduct").getAsString(), "LOC"))) {
					// #MVT00079 changes starts  //#MVT00133 changes ends
					if (jBody.get("loanDetails").getAsJsonObject().get("amount").getAsDouble() < jBody.get("loanDetails").getAsJsonObject().get("totalShareBalance").getAsDouble()) {
						try {
							// isonMsg = skipWorkFlow(isonMsg, isonheader, isonMapJson);
							ExecutorService executor = Executors.newFixedThreadPool(1);// creating a pool of threads
							for (int i = 0; i < 1; i++) {
								Runnable worker = new skipLoanWorkflowFwdThread(isonMsg, isonheader, isonMapJson);
								executor.execute(worker);// calling execute method of ExecutorService
							}
							logger.debug("Finished all threads");
							if (I$utils.$iStrFuzzyMatch(loanDetails.get("loanProduct").getAsString(), "AL01")) {// MSA00095 starts
								JsonObject filter = new JsonObject();
								JsonObject proj = new JsonObject();
								filter.addProperty("applicationId", sAppNumber);
								proj.addProperty("tranCdData", 1);
								JsonObject flxCubeResp = db$Ctrl.db$GetRow("ICOR_C_LD_LEAD_APPLICATIONS", filter, proj);
								if (flxCubeResp.has("tranCdData")) {
									JsonObject trandata = flxCubeResp.get("tranCdData").getAsJsonObject();
									String statMsg = i$ResM.getStatMsg(trandata);
									if (I$utils.$iStrFuzzyMatch(statMsg, i$ResM.I_SUCC)) {
										return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Your Loan Application has been APPROVED and your share deposit account has been credited.You can now proceed to access your funds via Transfer, Cash Withdrawal or In-Branch Withdrawal.");
									} else {
										String msgText = trandata.get("i-stat").getAsJsonObject().get("i-error")
												.getAsJsonObject().get("msgtext").getAsString();
										return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, msgText);
									}
								} else {
									logger.debug("Finished all threads");
									return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Your Loan Application has been APPROVED and your share deposit account has been credited.You can now proceed to access your funds via Transfer, Cash Withdrawal or In-Branch Withdrawal.");
								}
							} // MSA00095 ends
//							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
//									"Your Loan application has been Submitted. A TECU representative will contact you within 24-48 hrs.");
//							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
//									"Your Loan Application has been APPROVED and your share deposit account has been credited.You can now proceed to access your funds via Transfer, Cash Withdrawal or In-Branch Withdrawal.");
						} catch (Exception e) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION CREATION");
							return isonMsg;
						}
					} // #MVT00079 changes ends
				} // MSA00015 ends
					// Fwd the Control to Workflow COntroller.
				ExecutorService executor = Executors.newFixedThreadPool(1);// creating a pool of threads
				for (int i = 0; i < 1; i++) {
					Runnable worker = new imbpmFromLeadFwdThread(isonMsg, isonheader, isonMapJson);
					executor.execute(worker);// calling execute method of ExecutorService
				}
//				executor.shutdown();
//				while (!executor.isTerminated()) {
//				}
				if (I$utils.$iStrFuzzyMatch(loanDetails.get("loanProduct").getAsString(), "AL01")) {
					logger.debug("Finished all threads");
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
							"Your Loan Application has been APPROVED and your share deposit account has been credited.You can now proceed to access your funds via Transfer, Cash Withdrawal or In-Branch Withdrawal.");
				}
				logger.debug("Finished all threads");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
						"Your Loan application has been Submitted. A TECU representative will contact you within 24-48 hrs.");
			} else {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				} // #PKY00025 ends
			
			 // Workflow loop End
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			jBody.addProperty("referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION CREATION");
			return isonMsg;
		}
	}
	
	// Threading for skipping loan workflows Controller // #MVT00096 begins
	class skipLoanWorkflowFwdThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject isonMapJson;
		JsonObject isonheader;

		public skipLoanWorkflowFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
			this.message = "RUN";
			this.iosnMsg = isonMsg;
			this.isonMapJson = isonMapJson;
			this.isonheader = isonheader;

		}

		public void run() {
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
			logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
			JsonObject i$res = skipWorkFlow(iosnMsg, isonMapJson, isonheader);// call processmessage method that
																				// sleeps the
			// logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}

	}//#MVT00096 ends
	// #MVT00079 starts
	public JsonObject skipWorkFlow(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String ScrCtrlClass = null;
			JsonObject Jbdy = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject jFilter = new JsonObject();
			JsonObject task$Json = new JsonObject();
			JsonObject app$Json = new JsonObject();
			JsonObject $tsk$Filter = new JsonObject();
			Gson gson = new GsonBuilder().serializeNulls().create();
			
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			String sRef = ibody.get("referenceNo").getAsString();
			String sAppNumber = ibody.get("applicationId").getAsString();
			JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP",
					"{\"SCRID\":" + i$ResM.getScreenID(isonMsg) + "}", "{\"WORKFLOW\":1}");

			JsonObject query = new JsonObject();
			query.addProperty("applicationId", sAppNumber);
			query.addProperty("referenceNo", sRef);
			query.addProperty("isCurrVer", "Y");
			app$Json = db$Ctrl.db$GetRow("ICOR_C_LD_LEAD_APPLICATIONS", query);
			//#MVT00096 begins
			try {
				JsonObject flter = new JsonObject();
				JsonArray attachment = new JsonArray();
				
				app$Json.addProperty("WorkFlowId", "IMPACTO_LEAD_WRKFLOW");
				JsonArray docs = app$Json.get("documents").getAsJsonObject().get("documentDetails").getAsJsonArray();
				
				for (int i = 0; i < docs.size(); i++) {
					try {
						String temp = null;
						String tokens = null;
//						Base64.Encoder enc = Base64.getEncoder();
//						BASE64Encoder encoder = new BASE64Encoder();
						JsonObject mailObject =  new JsonObject();
						JsonObject docObject = docs.get(i).getAsJsonObject();
						
						if (I$utils.$iStrFuzzyMatch(docObject.get("idType").getAsString(), "Disclosure Statement") || I$utils.$iStrFuzzyMatch(docObject.get("idType").getAsString(), "Promissory Note")) {
							tokens = docObject.get("sides").getAsJsonArray().get(0).getAsJsonObject().get("FileUrlToken").getAsString();
							
							flter.addProperty("FileUrlToken", tokens);
							String urlId = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", flter).get("FileUrlId").getAsString();
							isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId",urlId);
							isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
							temp = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
							byte[] pdf = org.apache.commons.codec.binary.Base64.decodeBase64(temp.getBytes());
							String strBase64 = org.apache.commons.codec.binary.Base64.encodeBase64String(pdf);

							if(I$utils.$iStrFuzzyMatch(docObject.get("idType").getAsString(), "Disclosure Statement")) {
								mailObject.addProperty("fileName", "MEMBER DISCLOSURE"+".pdf");
							} else {
								mailObject.addProperty("fileName", "PROMISSORY NOTE"+".pdf");
							}
							mailObject.addProperty("docType", "application/pdf");
							mailObject.addProperty("template", strBase64);//#MVT00102 changes ends
							attachment.add(mailObject);
						}
					} catch (Exception e) {
						logger.debug(e.getMessage());
					}
				}
				app$Json.add("attachment", attachment);
				i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#LOAN#NOTIFICATION#MAIL");
/*				String promissoryURLToken = Im$utils.objFromArrWithSearch(docs, "idType", "PROMISSORY").get("sides")
						.getAsJsonArray().get(0).getAsJsonObject().get("FileUrlToken").getAsString();
				String discloserURLToken = Im$utils.objFromArrWithSearch(docs, "idType", "MEMBER DISCLOSURE").get("sides")
						.getAsJsonArray().get(0).getAsJsonObject().get("FileUrlToken").getAsString();
				
				urlToken.add(promissoryURLToken);
				urlToken.add(discloserURLToken);
				tokens = "{'$in':   " + urlToken + "   }";

//				prject.addProperty("_id", 0);
				filterObject.add("FileUrlToken", parser.parse(tokens).getAsJsonObject());

				flter.add("metadata.FileUrlToken", parser.parse(tokens).getAsJsonObject());
				JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_M_DMS_LOGGER", filterObject, prject);
				JsonArray fileURLIds = db$Ctrl.db$GetRows("fs.files", flter, prject);
//				String id = fileURLIds.get(0).getAsJsonObject().get("_id").getAsString();
//				String fileURLId1 = db$Ctrl.db$GetRows("ICOR_M_DMS_LOGGER", flter).get("FileUrlId").getAsString();
//				isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId",fileURLId1);
//				isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
//				JsonObject fileData = db$Ctrl.db$GetRowWithId("fs.files", i$Body.get(0).getAsJsonObject().get("FileUrlId").getAsString());
				
//				appJson.addProperty("Msg_Annotation", "TECU_LOAN_SUCCESS_NOTIFICATION");
//				String temp = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
//				mailObject.addProperty("docType", "application/pdf");
//				mailObject.addProperty("fileName", "PROMISSORY NOTE"+".pdf");
//				mailObject.addProperty("template", temp);
//				attachment.add(mailObject);
//				app$Json.add("attachment", attachment);*/				
			}catch(Exception e) {
				logger.debug(e.getMessage());				
			}
			//#MVT00096 ends
			task$Json.addProperty("cbsCif", "NA");
			task$Json.addProperty("isCurrVer", "Y");
			task$Json.addProperty("cbsStatus", "NA");
			task$Json.addProperty("CurrentTask", "4");
			task$Json.addProperty("PreTskStage", "3");
			task$Json.addProperty("NewTskStage", "4");
			task$Json.addProperty("NxtTskStage", "5");
			task$Json.addProperty("CurrentTskStage", "4");
			task$Json.addProperty("Queue", "QE#APPROVE");
			task$Json.addProperty("WorkFlowId", "IMPACTO_LEAD_WRKFLOW");
			task$Json.addProperty("TaskId", Im$utils.generateRandomKey(16));
			task$Json.addProperty("CurrentStageName", "APPROVE APPLICATION");
//			task$Json.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
			task$Json.add("UpdatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
			task$Json.add("InitiatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
			task$Json.addProperty("applicantName", ibody.get("CustomerFullName").getAsString());

			try {
				task$Json.addProperty("cbsCif",
						app$Json.get("contactDetails").getAsJsonObject().get("CIF").getAsString());
			} catch (Exception e) {
				// pass
			}
			try {
				task$Json.add("contactDetails", app$Json.get("contactDetails").getAsJsonObject());
			} catch (Exception e) {
				// pass
			}
			task$Json.addProperty("approvedby", app$Json.get("createdBy").getAsString());
			try {
				task$Json.add("remarks", app$Json.get("WorkFlowRemarks").getAsJsonArray());
				task$Json.add("latestRemarks", app$Json.get("WorkFlowLatestRemarks").getAsJsonArray());
			} catch (Exception e) {
				// pass
			}
			// #00000025 begins
			try {
				task$Json.addProperty("iLeadSource", app$Json.get("iLeadSource").getAsString());
			} catch (Exception e) {
				// pass
			}
			try {
				task$Json.addProperty("cif", app$Json.get("cif").getAsString());
			} catch (Exception e) {
				// pass
			} //SRI00033  Changes Starts 
			try {
				task$Json.addProperty("loanProduct", app$Json.getAsJsonObject("loanDetails").get("loanProduct").getAsString());

			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				task$Json.addProperty("loanProductDesc", app$Json.getAsJsonObject("loanDetails").get("loanProductDesc").getAsString());

			} catch (Exception e) {
				e.printStackTrace();
			}		// //SRI00033  Changes Ends  
			$tsk$Filter.addProperty("referenceNo", ibody.get("referenceNo").getAsString());
			$tsk$Filter.addProperty("applicationId", ibody.get("applicationId").getAsString());
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter, "true");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr", "ACCEPT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId", "IMPACTO_LEAD_WRKFLOW");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage", "4");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "CurrentStageName", "APPROVE APPLICATION");
			try {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId",
						i$ResM.getBody(isonMsg).get("userId").getAsString());
			} catch (Exception e) {

			}
			if(ibody.has("casa150")) { //SRM00044 changes
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "casa150",
						i$ResM.getBody(isonMsg).get("casa150").getAsString());
			}
			if(ibody.has("accountNo")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "accountNo",
						i$ResM.getBody(isonMsg).get("accountNo").getAsString());
			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			
/*			JsonObject jWrkArgs = new JsonObject();
			
            jWrkArgs.add("isonMsg", isonMsg);
            jWrkArgs.add("isonMsg", jWrkArgs.deepCopy());
			jWrkArgs.addProperty("clsName",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString());
			jWrkArgs.addProperty("funcName", "processMsg");
			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker);
			t.start();*/

			// Fwd the Control to Workflow COntroller.
			ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
				if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
				}
			} else {

				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				return isonMsg;
			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION REGISTRATION");
			return isonMsg;
		}
	}
	//#MVT00079 ends
	public void updateReferDcStatus(String sAppNumber, String Coll_Name) {

		// app$Json.addProperty("DcStatus", "ReferDcIncomplete");
		try {
			JsonObject jFlter = new JsonObject();
			jFlter.addProperty("applicationId", sAppNumber);
			JsonObject Apl$Json = new JsonObject();
			Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
			if (Apl$Json != null) {
				if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
					jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
					JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
					if (task$Json != null) {
						task$Json.addProperty("Queue", "ReferDcResubmit");
						db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);

					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private JsonObject autoRenewalApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject autoRenewalDetails = new JsonObject();
			JsonObject updateObj = new JsonObject();
			JsonObject Appl$Json = new JsonObject();
			JsonObject fltr = new JsonObject();
			//#MVT00098 Changes starts
			String referenceNo = i$body.get("referenceNo").getAsString();
			String applicationId = i$body.get("applicationId").getAsString();
			JsonObject documents = i$body.get("documents").getAsJsonObject();
			
			if (i$body.has("autoRenewalDetails")) {
				autoRenewalDetails = i$body.get("autoRenewalDetails").getAsJsonObject();
			}
			if (i$body.has("locDetails")) {
				autoRenewalDetails = i$body.get("locDetails").getAsJsonObject();
			}
			if (i$body.has("customerId")) {
				fltr = new JsonObject();
				JsonObject proj = new JsonObject();

				proj.addProperty("CustomerFullName", 1);
				proj.addProperty("CustomerEmailId", 1);
				proj.addProperty("CustomerMobileId", 1);
				fltr.addProperty("CustomerId", i$body.get("customerId").getAsString());
				Appl$Json = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr, proj);
			}
			fltr = new JsonObject();
			fltr.addProperty("referenceNo", referenceNo);
			fltr.addProperty("applicationId", applicationId);
			fltr.addProperty("isCurrVer", "Y");
			
			updateObj.add("documents", documents);
			updateObj.addProperty("isCurrVer", "Y");
			updateObj.addProperty("referenceNo", referenceNo);
			updateObj.addProperty("applicationId", applicationId);
			updateObj.addProperty("DcStatus", i$body.get("DcStatus").getAsString());
			updateObj.addProperty("customerId", i$body.get("customerId").getAsString());
			updateObj.addProperty("applicationType", i$body.get("applicationType").getAsString());
			updateObj.addProperty("CustomerFullName", Appl$Json.get("CustomerFullName").getAsString());
			updateObj.addProperty("CustomerEmailId", Appl$Json.get("CustomerEmailId").getAsString());
			updateObj.addProperty("CustomerMobileId", Appl$Json.get("CustomerMobileId").getAsString());
			updateObj.add("autoRenewalDetails", autoRenewalDetails);
			updateObj.addProperty("createdBy", IResManipulator.iloggedUser.get());
			updateObj.addProperty("createdAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			updateObj.addProperty("ModifiedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			db$Ctrl.db$UpdateRow("ICOR_C_EXST_LEAD_APPLICATIONS", updateObj, fltr,"true");
			
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			//MSA00032 starts
			String loanAccNo = autoRenewalDetails.get("loanAccNum").getAsString();
			String loanProduct = loanAccNo.substring(9, 13);
			String loanLOCProduct = loanAccNo.substring(9, 12);
			if (I$utils.$iStrFuzzyMatch(loanProduct, "CL01") || I$utils.$iStrFuzzyMatch(loanLOCProduct, "155")) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Your Loan application has been Submitted. A TECU representative will contact you within 24-48 hrs.");
			}
			else {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Your Loan application has been Approved and your share deposit account has been credited. You can now proceed to access your funds via Transfer, Cheque Request or In-Branch Cash Withdrawal.");
			}
			//MSA00032 ends
//			i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
		}catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATE APPLICATION");
			return isonMsg;
		} //#MVT00098 Changes ends
		return isonMsg;
	}
	
	private JsonObject partialSaveLNAPApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String sAppNumber = null;
		int VersionNumber = 0;
		jBody = i$ResM.getBody(isonMsg);
		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;

			JsonObject query = new JsonObject();

			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			query.addProperty("referenceNo", sRef);
			query.addProperty("applicationId", sAppNumber);

			VersionNumber = db$Ctrl.db$GetCountI("ICOR_C_LD_LEAD_APPLICATIONS_LEDGER", query.toString());
			VersionNumber++;
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "version", "V" + "" + VersionNumber);
			jFilter.addProperty("referenceNo", sRef);
			jFilter.addProperty("applicationId", sAppNumber);

			// WOrkflow Status
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);

			// Insert the data to the version history logger.
			db$Ctrl.db$InsertRow("ICOR_C_B2U_LEAD_VERSION_LOGGER", jBody);
			try {
				jBody.remove("version");
			} catch (Exception e) {
				// Pass
			}
			// Update the main loan application collection
			jBody.addProperty("LatestVersion", "V" + "" + VersionNumber);
			if (!(Appl$Json != null)) {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "O_OPEN"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}

			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOAN APPLICATION UPDATED SUCCESSFULLY");

		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			jBody.addProperty("referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION REGISTRATION");
			return isonMsg;
		}

	}
	//#PKY00025 starts
	// Threading for calling IMBPM Controller // #BZ00002 change begins
		class imbpmFromLeadFwdThread implements Runnable {
			private String message;
			JsonArray flght$Opr;
			JsonObject iosnMsg;
			JsonObject isonMapJson;
			JsonObject isonheader;

			public imbpmFromLeadFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
				this.message = "RUN";
				this.iosnMsg = isonMsg;
				this.isonMapJson = isonMapJson;
				this.isonheader = isonheader;

			}

			public void run() {
				logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
				logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
				JsonObject i$res = mirrorControllerOfLeads(iosnMsg, isonMapJson, isonheader);// call processmessage method that
																						// sleeps the
				// logger.debug("Thread Result" + i$res.toString());
				logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
			}

		}
		
		public JsonObject mirrorControllerOfLeads(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

			try {
				JsonObject Jbdy = new JsonObject();
				JsonObject jBody = new JsonObject();
				JsonObject task$Json = new JsonObject();
				JsonObject $tsk$Filter = new JsonObject();
				jBody = i$ResM.getBody(isonMsg);
				String sRef = null;
				String Coll_Name = "";
				String DcStatus = null;
				String ScrCtrlClass = null;
				String sAppNumber = null;

				JsonObject jFilter = new JsonObject();
				
				// Redirecting to Create KYC application workflow
				sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
				sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
				// DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
				// update the referDc Applicaiton
				JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP",
						"{\"SCRID\":" + i$ResM.getScreenID(isonMsg) + "}", "{\"WORKFLOW\":1}");

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
				// #DVJ00032 Starts
				try {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", 
							i$ResM.getBody(isonMsg).get("userId").getAsString());
				}catch(Exception e) {
					
				}
				if(jBody.has("casa150")) { //SRM00044 changes
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "casa150",
							i$ResM.getBody(isonMsg).get("casa150").getAsString());
					task$Json.addProperty("casa150", "true");
				}
				if(jBody.has("accountNo")) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "accountNo",
							i$ResM.getBody(isonMsg).get("accountNo").getAsString());
					task$Json.addProperty("accountNo", i$ResM.getBody(isonMsg).get("accountNo").getAsString());
				}
				task$Json.addProperty("isCurrVer", "Y");
				$tsk$Filter.addProperty("referenceNo", Jbdy.get("referenceNo").getAsString());
				$tsk$Filter.addProperty("applicationId", Jbdy.get("applicationId").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter, "true");
				// #DVJ00032 Ends
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
				// Fwd the Control to Workflow COntroller.
				ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
				Class<?> ctrlClass;
				ctrlClass = Class.forName(ScrCtrlClass);
				JsonObject result$ = null;
				Method ctrlFunc = null;
				ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
				Object ctrl$Caller = ctrlClass.newInstance();
				result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
					if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
					} else {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
					}
				} else {

					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
					return isonMsg;
				}

			} catch (Exception e) {
				return null;
			}
		}
		//#PKY00025  ends
		// MSA00001 starts
		public JsonObject existQuery(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
			try {
				JsonObject i$body = i$ResM.getBody(isonMsg);
				String applId = i$body.get("applicationId").getAsString();
				JsonObject data = new JsonObject();
				String cif = i$body.get("customerId").getAsString();
				JsonObject fltr = new JsonObject();
				fltr.addProperty("CustomerId", cif);
				JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
				String addr = cifData.get("PAddress1").getAsString() + ", " + cifData.get("PAddress2").getAsString() + ", "
						+ cifData.get("PAddress3").getAsString() + ", " + cifData.get("PAddress4").getAsString();
				String empAddr = cifData.get("EAddress1").getAsString() + ", " + cifData.get("EAddress2").getAsString()
						+ ", " + cifData.get("EAddress3").getAsString();
				JsonObject persDetl = new JsonObject();
				persDetl.addProperty("homeAddress", addr);
				persDetl.addProperty("emailId", cifData.get("CustomerEmailId").getAsString());
				persDetl.addProperty("DOB", cifData.get("CustomerDobDate").getAsString());
				persDetl.addProperty("primaryCode", cifData.get("CustomerMobileIsdNo").getAsInt());
				persDetl.addProperty("primaryMobile", cifData.get("CustomerMobileId").getAsString());
				persDetl.addProperty("martialStatus", cifData.get("CustomerMaritalStatus").getAsString());
				persDetl.addProperty("martialStatusDesc", cifData.get("Maritalstatusdesc").getAsString());
				persDetl.addProperty("employer", cifData.get("CustomerCurrentEmployer").getAsString());
				persDetl.addProperty("employmentStatusDesc", cifData.get("CustomerEmployerDesc").getAsString());
				persDetl.addProperty("employerAddress", empAddr);
				persDetl.addProperty("employmentStatus", cifData.get("Employmentmodedesc").getAsString());
				persDetl.addProperty("workCode", cifData.get("CustomerMobileIsdNo").getAsInt());
				persDetl.addProperty("workPhone", cifData.get("ETelephone").getAsString());
				persDetl.addProperty("position", cifData.get("Occupation").getAsString());
				
				JsonObject fltr2 = new JsonObject();
				JsonObject proj = new JsonObject();
				fltr2.addProperty("applicationId", applId);
				proj.addProperty("_id", 0);
				JsonObject exstdata = db$Ctrl.db$GetRow("ICOR_C_EXST_LEAD_APPLICATIONS", fltr2, proj);
//				data.add(exstdata);
				exstdata.add("memberInfo",persDetl);
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Retrieved Successfully");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, exstdata);

			} catch (Exception e) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
			}
			return isonMsg;
		}
		// MSA00001 ends
		
	public ILeadAppController() {
		// Cons
	}
}
// #0000001 Ends