/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ---------------------------------------------------------------------------------------------
      |0.1.1       | Baz 		| May 07, 2019 | #BZ00001   | Intial Writting
      |0.1.1       | Baz 		| May 14, 2019 | #BZ00002   | Threading for calling the IBPM Controller
      |0.1.1       | Baz 		| May 31, 2019 | #BZ00003   | check if CIF present
      |0.1.1       | Baz 		| June 1, 2019 | #BZ00004   | changed the thread calling way
      |1.0.0       | Baz 		| Sep 17, 2019 | #0000005   | Added Screen ID for reKYM lite
      |1.0.0	   | Manikanta 	| May 27, 2023 | #MVT00120  | Added code for refer user and summary code
      |1.0.0	   | Manikanta  | May 29, 2023 | #MVT00121  | Added code to save refer user applications
      |1.0.0	   | Sindhu     | June 1, 2023 | #SRM00039  | Added code to send email for refer-customer
      |1.0.0	   | Srikanth   | jan 24, 2024 | #SRI00031  | Added code to update the data in the CIF collection 
      --------------------------------------------------------------------------------------------------
*/
// #BZ00001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller.preflightOprThread;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IRKYCController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IEmailService i$Email = new IEmailService();
	private ISmsService I$ISmsService = new ISmsService();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(IRKYCController.class);
	// ####################################################################################

	JsonObject thread$isonMsg = new JsonObject();
	JsonObject thread$isonheader = new JsonObject();
	JsonObject thread$isonMapJson = new JsonObject();
	JsonObject ibody = new JsonObject();
	JsonObject icbsbody = new JsonObject();
	String rCollName = null;
	String userid = null;
	private String svrOpr;

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OABRKYCB") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				userid = IResManipulator.iloggedUser.get();
				thread$isonMsg = isonMsg;
				thread$isonheader = isonheader;
				thread$isonMapJson = isonMapJson;
				return createKYCApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABCRKYL") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")){  //#0000005 Changes
				userid = IResManipulator.iloggedUser.get();
				thread$isonMsg = isonMsg;
				thread$isonheader = isonheader;
				thread$isonMapJson = isonMapJson;
				return createKYCApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABCRKYL") && I$utils.$iStrFuzzyMatch(SOpr, "REFER_USER")) {// #MVT00120 changes begins
				return referUsrAppln(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABCRKYL") && I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {// #MVT00121 changes begins
				return saveReferUserInfo(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "SABCRKYL")
					&& (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY") || I$utils.$iStrFuzzyMatch(SOpr, "QUERY"))) {
				return referApplnSummary(isonMsg, isonheader);
			} // #MVT00120 changes ends
			else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	}

	public JsonObject createKYCApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String ScrCtrlClass = null;
		String sAppNumber = null;
		jBody = i$ResM.getBody(isonMsg);
		String cif = null;
		String SOpr = i$ResM.getOpr(isonMsg);
		String Scr = i$ResM.getScreenID(isonMsg);
		JsonObject i$header = new JsonObject();
		// remove the _id from the body if it exist
		try {
			jBody.remove("_id");
		} catch (Exception e) {}

		// #BZ00003 begins
		try {
			cif = jBody.get("contactDetails").getAsJsonObject().get("CIF").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CIF NOT PRESENT EXCEPTION_OH001");
		}
		// #BZ00003 Ends
		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;

			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
					i$ResM.adddate(new Date()).getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
					i$ResM.adddate(new Date()).getAsJsonObject());

			String qry$up = "{$and:[{\"applicationId\":\"" + sAppNumber + "\", \"referenceNo\" : {$ne:\"" + sRef
					+ "\"}, \"isCurrVer\":\"Y\"}]}";

			String srefqry = "{$ne: \"" + sRef + "\"}";
			JsonObject subqry = new JsonObject();
			subqry.addProperty("$ne", sRef);
			jFilter.add("referenceNo", subqry.getAsJsonObject());
			jFilter.addProperty("applicationId", sAppNumber);
			// String ftr$qry = "{\"applicationId\":\""+sAppNumber+"\",\"referenceNo\":{$ne:
			// \""+sRef+"\"}}";
			JsonObject $update = new JsonObject();
			$update.addProperty("isCurrVer", "N");
			db$Ctrl.db$UpdateRow(Coll_Name, $update, jFilter);
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", $update, jFilter);

			// WOrkflow Status
			jFilter = new JsonObject();
			jFilter.addProperty("applicationId", sAppNumber);
			jFilter.addProperty("referenceNo", sRef);
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);

			if (!(Appl$Json != null)) {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}

			jBody.addProperty("referenceNo", sRef);
			JsonObject Jbdy = new JsonObject();
			// trigger Workflow
			if (I$utils.$iStrFuzzyMatch(DcStatus, "COMPLETED")) {
				
				JsonObject date$convert = jBody.get("personalInfo").getAsJsonObject();
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("priDocDOI").getAsString());
					date$convert.add("priDocDOI_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;

				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("priDocDOE").getAsString());
					date$convert.add("priDocDOE_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("secDocDOI").getAsString());
					date$convert.add("secDocDOI_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("secDocDOE").getAsString());
					date$convert.add("secDocDOE_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				// update the collection with Date
				// #BZ00004 begins
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
				//SRI00031 starts
				try {
					if (jBody != null) {
						JsonObject changedVals = jBody.getAsJsonObject("changedVals");
						if (changedVals.has("mobileNumber") || changedVals.has("mobileISD")
								|| changedVals.has("emailId")) {
							JsonObject filter = new JsonObject();
							String cifId = jBody.getAsJsonObject("contactDetails").get("CIF").getAsString();
							JsonObject updateObj = new JsonObject();
							// Check if mobileNumber is present
							if (changedVals.has("mobileNumber")) {
								String mobileNumber = changedVals.get("mobileNumber").getAsString();
								updateObj.addProperty("CustomerMobileId", mobileNumber);
							}
							// Check if mobileISD is present
							if (changedVals.has("mobileISD")) {
								String mobileISD = changedVals.get("mobileISD").getAsString();
								updateObj.addProperty("CustomerMobileIsdNo", mobileISD);
							}
							// Check if emailId is present
							if (changedVals.has("emailId")) {
								String newEmail = changedVals.get("emailId").getAsString();
								updateObj.addProperty("CustomerEmailId", newEmail);
							}
							filter.addProperty("CustomerId", cifId);
							JsonObject icorMCbsCif = db$Ctrl.db$UpdateRow("ICOR_M_CBS_CIF_DATA", updateObj, filter);
						}
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				//SRI00031 ends
                try {

					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
	
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
                }finally {
                	ExecutorService executor = Executors.newFixedThreadPool(5);// creating a pool of threads
    				for (int i = 0; i < 1; i++) {
    					
    					Runnable worker = new imbpmFwdThread(isonMsg, isonheader, isonMapJson);
    					executor.execute(worker);// calling execute method of ExecutorService
    				}
                }// #BZ00004 Ends

			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");

		}

	}

	public void updateReferDcStatus(String sAppNumber, String Coll_Name) {
		// Change the rejected application queue so that application may not appear in
		// rejected list
		try {
			JsonObject jFlter = new JsonObject();
			jFlter.addProperty("applicationId", sAppNumber);
			JsonObject Apl$Json = new JsonObject();
			Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
			if (Apl$Json != null) {
				if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
					jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
					JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
					if (task$Json != null) {
						task$Json.addProperty("Queue", "ReferDcResubmit");
						db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);

					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//Date Format Change 

	public JsonObject dateFromatter(String date) {
		SimpleDateFormat dmyFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
		Date orDate;
		JsonObject retDate = new JsonObject();
		try {
			orDate = dmyFormat.parse(date);
			retDate = i$ResM.adddate(orDate);
			return retDate;
		} catch (Exception e) {
			return null;
		}

	}

	// Threading for calling IMBPM Controller // #BZ00002 change begins
	class imbpmFwdThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject isonMapJson;
		JsonObject isonheader;


		public imbpmFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) throws InterruptedException {
			Thread.sleep(100);
			this.message = "RUN";
			this.iosnMsg = isonMsg;
			this.isonMapJson = isonMapJson;
			this.isonheader = isonheader;
			JsonObject i$header = new JsonObject();
		}

		public void run() {
			logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
			JsonObject i$res = mirrorController(iosnMsg, isonMapJson, isonheader);// call processmessage method that
																					// sleeps the
			logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}

	}

	public JsonObject mirrorController(JsonObject isonMsg, JsonObject isonMapJson, JsonObject isonheader) {

		try {
			JsonObject Jbdy = new JsonObject();
			JsonObject jBody = new JsonObject();
			jBody = i$ResM.getBody(isonMsg);
			String sRef = null;
			String Coll_Name = "";
			String DcStatus = null;
			String ScrCtrlClass = null;
			String sAppNumber = null;
			String Scr = i$ResM.getScreenID(isonMsg);
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;

			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			// DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			// update the referDc Applicaiton
			JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP", "{\"SCRID\":\"" + Scr + "\"}",
					"{\"WORKFLOW\":1}");

			// Update the dates format #Va000028 Change Begins

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			// Fwd the Control to Workflow COntroller.
			ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
				if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
				}
			} else {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				return isonMsg;
			}

		} catch (Exception e) {
			return null;
		}
	}
	//#MVT00120 begins
	public JsonObject referApplnSummary(JsonObject isonMsg, JsonObject headers) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject res$blder = new JsonObject();
			JsonObject projection = new JsonObject();
			String SOpr = i$ResM.getOpr(isonMsg);
			filter.addProperty("isCurrVer", "Y");
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");

			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				try {
					JsonArray resArray = new JsonArray();
					projection.addProperty("_id", 0);
					projection.addProperty("ReferedTo", 1);
					projection.addProperty("referenceNo", 1);
					projection.addProperty("applicationId", 1);
					filter.addProperty("ReferedTo", ibody.get("cif").getAsString());
					filter.addProperty("operationDone", "REFER_USER");
					JsonArray lovData = db$Ctrl.db$GetRows("ICOR_C_B2U_RE_KYC_LITE_APPS", filter, projection);
					for(int i=0;i<lovData.size();i++) {
						JsonObject ldata = new JsonObject();
						ldata.addProperty("KeyId", lovData.get(i).getAsJsonObject().get("applicationId").getAsString());
						ldata.addProperty("KeyDesc", lovData.get(i).getAsJsonObject().get("referenceNo").getAsString());
						ldata.addProperty("ReferedTo", lovData.get(i).getAsJsonObject().get("ReferedTo").getAsString());
						resArray.add(ldata);
					}
					res$blder.addProperty("TotalRowCount", lovData.size());
					res$blder.add("PaginatedApplications", resArray);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
					return isonMsg;
				} catch(Exception e) {
					logger.debug(e.getMessage());
				}
			}
			filter.addProperty("applicationId", ibody.get("applicationId").getAsString());
			filter.addProperty("referenceNo", ibody.get("referenceNo").getAsString());
			JsonObject usrData = db$Ctrl.db$GetRow("ICOR_C_B2U_RE_KYC_LITE_APPS", filter);
//			res$blder.addProperty("TotalRowCount", summaryData.size());
//			res$blder.add("PaginatedApplications", summaryData);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, usrData);

		} catch (Exception e) {
			logger.debug(e.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO FETCH THE DATA");
		}
		i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA FETCHED SUCCESSFULLY");
		return isonMsg;	}
	
	public JsonObject referUsrAppln(JsonObject isonMsg) {
		try {
			int refercount = 0;
			JsonObject filter = new JsonObject();
			JsonObject projctn =  new JsonObject();
			JsonObject IBMObject = new JsonObject();
			JsonObject prvStgObj = new JsonObject();
			JsonArray referArray = new JsonArray();
			JsonObject referobjt = new JsonObject();
			JsonObject updateObject = new JsonObject();
			JsonObject msgObject = new JsonObject();
			JsonObject fltr = new JsonObject();
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");
			
			projctn.addProperty("CONTROL_JSON.STGLIFECYCLE", 1);
			filter.addProperty("WORKFLOWID", ibody.get("WorkFlowId").getAsString());
			JsonObject workflow = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", filter, projctn);

			filter = new JsonObject();
			String applicationId = ibody.get("applicationId").getAsString();
			filter.addProperty("referenceNo", ibody.get("ReqKeyFld").getAsString());
			filter.addProperty("applicationId", ibody.get("applicationId").getAsString());
			JsonObject app$Json = db$Ctrl.db$GetRow("ICOR_C_B2U_RE_KYC_LITE_APPS", filter);
			JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", filter);
			JsonObject stgLifeCycle = workflow.getAsJsonObject("CONTROL_JSON").getAsJsonObject("STGLIFECYCLE");
			JsonObject currStg = stgLifeCycle.getAsJsonObject("1");
			
			if (app$Json.has("referUsrCount")) {
				refercount = app$Json.get("referUsrCount").getAsInt();
				if (refercount > 2) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"This Application Already Reffered Twice, We Cannot Refer The Tpplication More Then Twice To User");
				}
//				referArray.add(app$Json.get("ReferData").getAsJsonArray());  //SRM
			}
			if(app$Json.has("LatestRemarks")) {
				updateObject.add("Remarks", app$Json.get("LatestRemarks").getAsJsonArray());
			}
			refercount++;
			String cif = app$Json.getAsJsonObject("contactDetails").get("CIF").getAsString();
			referobjt.addProperty("ReferedTo", cif);
//			referobjt.addProperty("referUsrCount", refercount); //SRM
			referobjt.addProperty("RefferedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
			referobjt.addProperty("ReferedBy", IResManipulator.iloggedUser.get());
//			referArray.add(referobjt); //SRM
			
//			updateObject.add("ReferData", referArray); //SRM
			updateObject.addProperty("ReferedTo", cif);
			updateObject.addProperty("referUsrCount", refercount);
			updateObject.add("LatestRemarks", ibody.getAsJsonArray("LatestRemarks"));
			updateObject.addProperty("WorkFlowStatus", currStg.get("STGNAME").getAsString());
			updateObject.addProperty("operationDone", "REFER_USER");
			db$Ctrl.db$UpdateRow("ICOR_C_B2U_RE_KYC_LITE_APPS", updateObject, filter);

			prvStgObj.addProperty("PreTskStage", 0);
			IBMObject.add("prevStageDetail", prvStgObj);
			IBMObject.addProperty("Queue", "QE#INIT");
			IBMObject.addProperty("ModifiedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			IBMObject.addProperty("CurrentStageName", currStg.get("STGNAME").getAsString());
			IBMObject.addProperty("CurrentTskStage", currStg.get("CURR_STG_NO").getAsString());
			IBMObject.addProperty("CurrentTask", currStg.get("CURR_STG_NO").getAsString());
			IBMObject.addProperty("NxtTskStage", currStg.get("NEXT_STG_NO").getAsString());
			IBMObject.addProperty("NewTskStage", currStg.get("CURR_STG_NO").getAsString());
			IBMObject.addProperty("PreTskStage", currStg.get("PREV_STG_NO").getAsString());
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", IBMObject, filter);
			ibody.addProperty("CurrentStageName", currStg.get("STGNAME").getAsString());
			
			fltr.addProperty("CustomerId", cif); // #SRM00039 changes start
			JsonObject data = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
			String emailId = data.get("CustomerEmailId").getAsString();
			String mobileNo = data.get("CustomerMobileIsdNo").getAsString() + data.get("CustomerMobileId").getAsString();
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("tmp$name", "TMPL#REFER#MEMBER#NOTIFICATION");
			map$Data.addProperty("memberName", data.get("CustomerFullName").getAsString());
			map$Data.addProperty("cifId", cif);
			map$Data.addProperty("applicationId", applicationId);	
			msgObject.add("map$Data", map$Data);
			msgObject.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + emailId + "\"}"));
			msgObject.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + mobileNo + "\"}"));

			JsonObject i$resE = i$Email.SendEmailWOThread(msgObject);
			JsonObject i$resM = I$ISmsService.SendSMSWOThread(msgObject);
// #SRM00039 changes end
		} catch(Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATE THE APPLICATION");
		}
		i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
		return isonMsg;
	}
	//#MVT00120 ends
	//#MVT00121 Begins
	public JsonObject saveReferUserInfo(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject projctn = new JsonObject();
			JsonObject jsonData = new JsonObject();
			JsonObject prvStgObj = new JsonObject();
			JsonObject ibmObject = new JsonObject();
			
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");			
			String applnId = ibody.get("applicationId").getAsString();
			String referenceNo = ibody.get("referenceNo").getAsString();
			
			filter.addProperty("applicationId", applnId);
			filter.addProperty("referenceNo", referenceNo);
			JsonObject ibm$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", filter);
			JsonObject app$Json = db$Ctrl.db$GetRow("ICOR_C_B2U_RE_KYC_LITE_APPS", filter);
			String workflowId = ibm$Json.get("WorkFlowId").getAsString();
			
			ibody.remove("_id");
			JsonObject $update = new JsonObject();
			$update.addProperty("isCurrVer", "N");
			db$Ctrl.db$UpdateRow("ICOR_C_B2U_RE_KYC_LITE_APPS", $update, filter);			
			ibody.addProperty("isCurrVer", "Y");
			db$Ctrl.db$InsertRow("ICOR_C_B2U_RE_KYC_LITE_APPS", ibody);

			JsonObject flter = new JsonObject();
			flter.addProperty("WORKFLOWID", workflowId);
			projctn.addProperty("CONTROL_JSON.STGLIFECYCLE", 1);
			JsonObject workflow = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", flter, projctn);
			JsonObject stgLifeCycle = workflow.getAsJsonObject("CONTROL_JSON").getAsJsonObject("STGLIFECYCLE");
			JsonObject newtsg = stgLifeCycle.getAsJsonObject(ibm$Json.get("NxtTskStage").getAsString());

			filter.addProperty("isCurrVer", "Y");
			prvStgObj.addProperty("PreTskStage", 0);
			prvStgObj.addProperty("NewTskStage", "1");
			prvStgObj.addProperty("Queue", "QE#INIT");
			prvStgObj.addProperty("CurrentTask", "INIT");
			prvStgObj.addProperty("CurrentStageName", "INITIATION");
			prvStgObj.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
			
			ibmObject.add("prevStageDetail", prvStgObj);
			ibmObject.addProperty("Queue", "QE#AUTHORIZE");
			ibmObject.addProperty("ModifiedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			ibmObject.add("contactDetails", ibody.get("contactDetails").getAsJsonObject());
			ibmObject.addProperty("CurrentStageName", newtsg.get("STGNAME").getAsString());
			ibmObject.addProperty("CurrentTskStage", newtsg.get("CURR_STG_NO").getAsString());
			ibmObject.addProperty("CurrentTask", newtsg.get("CURR_STG_NO").getAsString());
			ibmObject.addProperty("NxtTskStage", newtsg.get("NEXT_STG_NO").getAsString());
			ibmObject.addProperty("NewTskStage", newtsg.get("CURR_STG_NO").getAsString());
			ibmObject.addProperty("PreTskStage", newtsg.get("PREV_STG_NO").getAsString());
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", ibmObject, filter);

			jsonData.addProperty("operationDone", "ACCEPT");
			jsonData.addProperty("WorkFlowStatus", newtsg.get("STGNAME").getAsString());
			jsonData.addProperty("LastModifiedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			db$Ctrl.db$UpdateRow("ICOR_C_B2U_RE_KYC_LITE_APPS", jsonData, filter);
			
			ibody.remove("additionalDetails");
			ibody.remove("ReKYMDocStatus");
			ibody.remove("changedVals");
			ibody.remove("contactDetails");
			ibody.remove("documents");
			ibody.remove("employment");
			ibody.remove("moreInfo");
			ibody.remove("fatcaDeclaration");
			ibody.remove("personalInfo");
			ibody.remove("primaryOCrResult");
			ibody.remove("secondaryOCRResult");
			ibody.remove("cbsDetails");
			ibody.remove("summaryScreen");
			ibody.remove("raw_ocr_result");
			ibody.remove("identificationInfo");
			ibody.remove("politicatalExposedDetailsDetails");
			ibody.remove("extraDocDetails");
			ibody.remove("fatcaDeclaration");
			ibody.remove("enhanced_due");
			ibody.remove("expiredDocs");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
		} catch(Exception e) {
			logger.debug(e.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATE THE APPLICATION");
		}
		i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION SAVED SUCCESSFULLY");
		return isonMsg;
	}
	//#MVT00121 ends
////#BZ00002    ends 
	public IRKYCController() {
		// Cons
	}
}
// #BZ00001 Ends 