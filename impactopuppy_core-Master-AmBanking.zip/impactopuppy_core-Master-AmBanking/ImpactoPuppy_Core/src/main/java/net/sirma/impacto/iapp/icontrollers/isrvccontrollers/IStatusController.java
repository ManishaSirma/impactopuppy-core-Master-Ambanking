/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Pappu      | Nov 9, 2022  | #PKY00079   | Handled pdf alignment issue
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import com.google.gson.JsonParser;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64.OutputStream;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller;

public class IStatusController {
    //*******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
    private DBController db$Ctrl = new DBController();
    private Ioutils I$utils = new Ioutils();
    private IResManipulator i$ResM = new IResManipulator();
    private IMbpmContorller i$IMbpm = new IMbpmContorller();
    private Logger logger = LoggerFactory.getLogger(IStatusController.class); //Nye- Change Class Name always
    //**********************************************************************//
	
    public JsonObject processMsg(JsonObject isonMsg , JsonObject isonheader, JsonObject isonMapJson)
    {   
    	try
    	{
			String SOpr = i$ResM.getOpr(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SvrName, "STATUS") && I$utils.$iStrFuzzyMatch(SrvOpr, "GETSTATUS")) {
				return generateStatus(isonMsg);
			}
    	return null;
    	}
    	catch(Exception e)
    	{
    		logger.error("Generic Controller Error: " + e.getMessage());
    		e.printStackTrace();
    		return null;
    	}
    };
	
	
    public JsonObject generateStatus(JsonObject isonMsg){
    	try {
    		JsonObject i$body = isonMsg.getAsJsonObject("i-body");
    		JsonObject i$header = isonMsg.getAsJsonObject("i-header");
    		i$header.addProperty("srvcname" , "");
    		i$header.addProperty("srvcopr" , "");
    		i$header.addProperty("screenid" , "XEXCBRFD");
    		i$header.addProperty("operation" , "CREATE");
    		i$header.addProperty("operation1" , "@");
    		i$header.addProperty("operation2" , "@");
    		i$header.addProperty("operation3" , "@");
    		String accountNo = i$body.get("accountNo").getAsString();
    		String branch = i$body.get("branch").getAsString();
    		String dcn = "";
    		try {
    			dcn = i$body.get("dcn").getAsString();
    		}catch(Exception e){}
    		if(I$utils.$iStrFuzzyMatch(branch, ""))
    			branch = accountNo.substring(0, 3);
    		String cif = "";
    		try {
        		cif = i$body.get("cif").getAsString();
    		}catch(Exception e){}
    		String fromDate = i$body.get("fromDate").getAsString();
    		String toDate = i$body.get("toDate").getAsString();
    		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    		LocalDate start = LocalDate.parse(fromDate);
    		LocalDate end = LocalDate.parse(toDate);
    		if(!start.isBefore(end)) {
    			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Enter Valid Date");
    			return isonMsg;
    		}
    		Period difference = Period.between(start, end);  
    		if(difference.getYears() >= 2) {
    			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Enter Date Between Time Period of 2 Years");
    			return isonMsg;
    		}
    		JsonObject trnData = new JsonObject();
    		if(dcn.equals("")) {
        		trnData.addProperty("brn", branch);
        		trnData.addProperty("accNo", accountNo);
        		trnData.addProperty("acccy", i$IMbpm.fecthValueFormJson(
        				i$body, "acccy", ""));
        		trnData.addProperty("acslType", i$IMbpm.fecthValueFormJson(
        				i$body, "acslType", ""));
        		trnData.addProperty("stmtType", i$IMbpm.fecthValueFormJson(
        				i$body, "stmtType", ""));
        		trnData.addProperty("printOt", i$IMbpm.fecthValueFormJson(
        				i$body, "printOt", ""));
        		trnData.addProperty("fromDt", fromDate);
        		trnData.addProperty("toDt", toDate);
        		trnData.addProperty("lnkdaCdtl", i$IMbpm.fecthValueFormJson(
        				i$body, "lnkdaCdtl", ""));
        		trnData.addProperty("bkdt", i$IMbpm.fecthValueFormJson(
        				i$body, "bkdt", ""));
        		trnData.addProperty("accType", i$IMbpm.fecthValueFormJson(
        				i$body, "accType", ""));
        		trnData.addProperty("virAccTrns", i$IMbpm.fecthValueFormJson(
        				i$body, "virAccTrns", ""));
        		trnData.addProperty("asyncReq", i$IMbpm.fecthValueFormJson(
        				i$body, "asyncReq", ""));
        		trnData.addProperty("dcn", i$IMbpm.fecthValueFormJson(
        				i$body, "dcn", ""));
        		trnData.addProperty("chg", i$IMbpm.fecthValueFormJson(
        				i$body, "chg", ""));
        		trnData.addProperty("frmAccNo", i$IMbpm.fecthValueFormJson(
        				i$body, "frmAccNo", ""));
        		trnData.addProperty("frmAcccy", i$IMbpm.fecthValueFormJson(
        				i$body, "frmAcccy", ""));
        		trnData.addProperty("toAccNo", i$IMbpm.fecthValueFormJson(
        				i$body, "toAccNo", ""));
        		trnData.addProperty("toAcccy", i$IMbpm.fecthValueFormJson(
        				i$body, "toAcccy", ""));
        		trnData.addProperty("tsAccNo", i$IMbpm.fecthValueFormJson(
        				i$body, "tsAccNo", ""));
        		trnData.addProperty("mulAcc", i$IMbpm.fecthValueFormJson(
        				i$body, "mulAcc", ""));
        		trnData.addProperty("trnRefNo", i$IMbpm.fecthValueFormJson(
        				i$body, "trnRefNo", ""));
        		trnData.addProperty("frmAcBrn", i$IMbpm.fecthValueFormJson(
        				i$body, "frmAcBrn", ""));
        		trnData.addProperty("toAcBrn", i$IMbpm.fecthValueFormJson(
        				i$body, "toAcBrn", ""));
        		trnData.addProperty("sessionId", i$IMbpm.fecthValueFormJson(
        				i$body, "sessionId", ""));
        		trnData.addProperty("repRefNo", i$IMbpm.fecthValueFormJson(
        				i$body, "repRefNo", ""));
        		trnData.addProperty("status", i$IMbpm.fecthValueFormJson(
        				i$body, "status", ""));
        		trnData.addProperty("errorReason", i$IMbpm.fecthValueFormJson(
        				i$body, "errorReason", ""));
        		trnData.addProperty("frmAvBrnF", i$IMbpm.fecthValueFormJson(
        				i$body, "frmAvBrnF", ""));
        		trnData.addProperty("toAcBrnF", i$IMbpm.fecthValueFormJson(
        				i$body, "toAcBrnF", ""));
        		trnData.addProperty("ovdSet", i$IMbpm.fecthValueFormJson(
        				i$body, "ovdSet", ""));
        		i$body = new JsonObject();
        		i$body.add("trnData", trnData);
        		i$body.addProperty("extSys", "FLEXCUBE");
        		i$body.addProperty("trnCd", "CASA_ACDOPTN");
        		i$body.addProperty("ctrnCd", "@");
        		i$body.addProperty("ctrnOpr", "@");
        		i$body.addProperty("ctrnOpr1", "@");
        		i$body.addProperty("ctrnOpr2", "@");
        		i$body.addProperty("ctrnOpr3", "@");
        		i$body.addProperty("trnBrn", trnData.get("brn").getAsString());
    		}else {
        		trnData.addProperty("accNo", accountNo);
        		trnData.addProperty("printOt", i$IMbpm.fecthValueFormJson(
        				i$body, "printOt", ""));
        		trnData.addProperty("fromDt", fromDate);
        		trnData.addProperty("toDt", toDate);
        		trnData.addProperty("dcn", i$body.get("dcn").getAsString());
        		trnData.addProperty("sentToCust", "Y");
        		trnData.addProperty("msgType", "D");
        		trnData.addProperty("brnCd", i$IMbpm.fecthValueFormJson(
        				i$body, "brnCd", ""));
        		i$body = new JsonObject();
        		i$body.add("trnData", trnData);
        		i$body.addProperty("extSys", "FLEXCUBE");
        		i$body.addProperty("trnCd", "LOAN_CLDLSTMT");
        		i$body.addProperty("ctrnCd", "@");
        		i$body.addProperty("ctrnOpr", "@");
        		i$body.addProperty("ctrnOpr1", "@");
        		i$body.addProperty("ctrnOpr2", "@");
        		i$body.addProperty("ctrnOpr3", "@");
        		i$body.addProperty("trnBrn", branch);
    			
    		}
    		isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_HEADER,i$header);
    		isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
    		Class<?> ctrlClass;
			ctrlClass = Class.forName("net.sirma.impacto.iapp.icontrollers.imodulecontrollers.ICoreSysReqFwderController");
			JsonObject resultf$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class,
					JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			resultf$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonMsg, isonMsg);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(resultf$), i$ResM.I_SUCC)) {
				i$body = resultf$.get("i-body").getAsJsonObject();
				String accDetails = "";
				if(dcn.equals(""))
					accDetails = i$body.get("BLK_ACTBS_ACCOUNT_REPORT").getAsString();
				else
					accDetails = i$body.get("BLK_ACVWS_FCJ_LOAN_STMT").getAsString();
				if(I$utils.$iStrFuzzyMatch(accDetails, "")) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to get the account details");
	    			return isonMsg;
				}
				String[] accDetailsArr = accDetails.split("~");
				i$body = new JsonObject();
				trnData = new JsonObject();
				if(dcn.equals("")) {
					trnData.addProperty("dcn", accDetailsArr[2]);
					trnData.addProperty("refno", accDetailsArr[1]);
					trnData.addProperty("sender", cif);
					trnData.addProperty("media", "MAIL");
					trnData.addProperty("swiftMsg", "");
					trnData.addProperty("node", "");
					trnData.addProperty("makerId", "");
					trnData.addProperty("makerdtStamp", "");
					trnData.addProperty("authStat", "");
					trnData.addProperty("checkerdtStamp", "");
					trnData.addProperty("checkerId", "");
					trnData.addProperty("latestVerNo", "");
					trnData.addProperty("remarks", "");
					trnData.addProperty("rejectReason", "");
					trnData.addProperty("msgTrailer", "");
					trnData.addProperty("msgType", "");
					trnData.addProperty("lang", "ENG");
					i$body.add("trnData", trnData);
					i$body.addProperty("extSys", "FLEXCUBE");
					i$body.addProperty("trnCd", "CASA_MSDVWMSG");
					i$body.addProperty("ctrnCd", "@");
					i$body.addProperty("ctrnOpr", "@");
					i$body.addProperty("ctrnOpr1", "@");
					i$body.addProperty("ctrnOpr2", "@");
					i$body.addProperty("ctrnOpr3", "@");
					i$body.addProperty("trnBrn", accDetailsArr[0]);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
				}else {
					trnData.addProperty("dcn", accDetailsArr[4]);
					trnData.addProperty("refrenceNo", accDetailsArr[0]);
					trnData.addProperty("branch", "100");
					trnData.addProperty("module", "CL");
					trnData.addProperty("message", "");
					i$body.add("trnData", trnData);
					i$body.addProperty("extSys", "FLEXCUBE");
					i$body.addProperty("trnCd", "LOAN_CLDGNADV");
					i$body.addProperty("ctrnCd", "@");
					i$body.addProperty("ctrnOpr", "@");
					i$body.addProperty("ctrnOpr1", "@");
					i$body.addProperty("ctrnOpr2", "@");
					i$body.addProperty("ctrnOpr3", "@");
					i$body.addProperty("trnBrn", accDetailsArr[7]);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
				}
				ctrlClass = Class.forName("net.sirma.impacto.iapp.icontrollers.imodulecontrollers.ICoreSysReqFwderController");
				ctrlFunc = null;
				ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class,
						JsonObject.class);
				ctrl$Caller = ctrlClass.newInstance();
				resultf$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonMsg, isonMsg);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(resultf$), i$ResM.I_SUCC)) {
					i$body = new JsonObject();
					i$body = resultf$.get("i-body").getAsJsonObject();
					String statements = "";
					if (dcn.equals("")) {
						statements = i$body.get("BLK_MESSAGE").getAsString();
						//PKY00079 starts
						JsonArray JsonArr = new JsonArray();
						JsonArr.add(i$body.get("BLK_MESSAGE").getAsString());
						String[] statementsArr = JsonArr.get(0).getAsString().split("\n");
						
						int countForSpace = 0, countForAddress = 0, countForAddress2 = 0, address3Count = 0;
						for (int i = 0; i < statementsArr.length; i++) {
							String trimStr = statementsArr[i].trim();
							String str = statementsArr[i];
							if (trimStr.startsWith("ADDRESS_2") && countForAddress2 == 0) {
								String strToReplace = "";
								String strFromReplace = "";
								countForAddress2++;
								int entryCount = 0;
								while (entryCount <= 7) {
									String strforValidation = statementsArr[i + entryCount];
									strToReplace = strforValidation;
									strFromReplace = strforValidation.trim();
									String valStrArr[] = strforValidation.split("  ");
									String strToConcat = "";
									entryCount++;
									for (int j = 0; j < valStrArr.length; j++) {
										String iterateStr = valStrArr[j].trim();
										if ((iterateStr.length() > 0 && !iterateStr.contains(" ") && iterateStr.contains("ADDRESS"))
												|| (iterateStr.startsWith("Cust ID")) || (iterateStr.startsWith("Account No"))) {
											int secEntryCount = entryCount - 1;
											int stopExcution = 0;
											while (stopExcution >= 0) {
												secEntryCount++;
												String strstrforReplacementNotrim = statementsArr[i + secEntryCount];
												String strforReplacement = strstrforReplacementNotrim.trim();
												String finalStrToReplace = "";
												if (iterateStr.contains("ADDRESS_2") && strforReplacement.startsWith("Cust ID")) {
													finalStrToReplace = iterateStr + "                      " + strforReplacement
															+ "                                               ";
													statements = statements.replace(strToReplace, finalStrToReplace);
													statements = statements.replace(strstrforReplacementNotrim, "removeField1");
													stopExcution = -1;
												}
												if (iterateStr.contains("ADDRESS_3") && address3Count == 0
														&& strforReplacement.startsWith("Account No")) {
													finalStrToReplace = iterateStr + "                      " + strforReplacement
															+ "                                     ";
													statements = statements.replace(strToReplace, finalStrToReplace);
													statements = statements.replace(strstrforReplacementNotrim, "removeField2");
													address3Count++;
													stopExcution = -1;
												}
												if (iterateStr.contains("ADDRESS_3") && address3Count == 1
														&& strforReplacement.startsWith("Account Desc.")) {
													finalStrToReplace = iterateStr + "                      " + strforReplacement
															+ "                              ";
													statements = statements.replace(strToReplace, finalStrToReplace);
													statements = statements.replace(strstrforReplacementNotrim, "");
													address3Count++;
													stopExcution = -1;
												}
												if (iterateStr.startsWith("Cust ID") && strforReplacement.startsWith("Account Class")) {
													statements = statements.replace(strstrforReplacementNotrim, "");
													statements = statements.replace("removeField1", strstrforReplacementNotrim);
													stopExcution = -1;
												}
												if (iterateStr.startsWith("Account No")
														&& strforReplacement.startsWith("Account Currency")) {
													statements = statements.replace(strstrforReplacementNotrim, "");
													statements = statements.replace("removeField2", strstrforReplacementNotrim); 
													stopExcution = -1;
												}
											}
										}
									}
								}
							}
							if (trimStr.startsWith("Account Open Date ")) {
								statements = statements.replace("   Account Open Date", "Account Open Date");
							}
							if (trimStr.startsWith("OPENING BALANCE  CREDIT")) {
								statements = statements.replace("   OPENING BALANCE  CREDIT", "OPENING BALANCE CREDIT");
							}
							if (trimStr.startsWith("Trn Code/Narrative") && trimStr.contains("REFERENCE")
									&& trimStr.contains("Book Date") && countForSpace == 0) {
								countForSpace++;
								int entryCount = 0;
								while (entryCount <= 17) {
									String strforValidation = statementsArr[i + entryCount];// 19
									String valStrArr[] = strforValidation.split(" ");
									String strToReplace = "";
									entryCount++;
									for (int j = 0; j < valStrArr.length; j++) {
										String iterateStr = valStrArr[j];
										if (iterateStr.length() >= 19 && iterateStr.contains("-") && iterateStr.matches(".*\\d.*")) {
											strToReplace = iterateStr;
											String strToReplace1 = strToReplace.substring(0, 19);
											String strToReplace2 = strToReplace.substring(20);
											String dateStrArr[] = strToReplace2.split("-");
											for (int k = 0; k < dateStrArr.length; k++) {
												String checkDoubleDigitDate = dateStrArr[k];
												if (checkDoubleDigitDate.length() <= 1) {
													strToReplace2 = strToReplace2.replace(checkDoubleDigitDate,
															"0" + checkDoubleDigitDate);
												}
											}
											String strFromReplace = strToReplace1 + " " + strToReplace2;
											statements = statements.replace(strToReplace, strFromReplace);
										}
									}
								}
							}

							if (trimStr.startsWith("ADDRESS_1") && countForAddress == 0) {
								String strToReplace = "";
								String strFromReplace = "";
								countForAddress++;
								int entryCount = 0;
								while (entryCount <= 2) {
									String strforValidation = statementsArr[i + entryCount];
									if (entryCount == 0) {
										strToReplace = strforValidation;
										strFromReplace = strforValidation.trim();
										entryCount++;
										continue;
									}
									String valStrArr[] = strforValidation.split("  ");
									entryCount++;
									for (int j = 0; j < valStrArr.length; j++) {
										String iterateStr = valStrArr[j].trim();
										if (iterateStr.length() > 0 && iterateStr.contains(" ") && !iterateStr.contains("ADDRESS_")) {
											strFromReplace = strFromReplace + " " + iterateStr;
										}
									}
								}
								statements = statements.replace(strToReplace, strFromReplace);
							}
						}
						statements = statements.replace("    Branch Address  :", "Branch Address :");
						statements = statements.replaceAll("(?m)^[ \t]*\r?\n\n", "");
						//PKY00079 ends
					}
					else {
						statements = i$body.get("CLVWS_DLY_MSG_OUT").getAsString();
						//PKY00079 starts
						JsonArray JsonArr = new JsonArray();
						JsonArr.add(i$body.get("CLVWS_DLY_MSG_OUT").getAsString());
						String []statementsArr = JsonArr.get(0).getAsString().split("\n");
						for(int i=0; i< statementsArr.length; i++) {
							String trimStr = statementsArr[i].trim();
							String str = statementsArr[i];
							if (trimStr.startsWith("Loan Type       :")) {
								statements = statements.replace(str, str.trim());
								statements = statements.replace("Loan Type       :", "                  Loan Type     :");
							}
							if (trimStr.startsWith("Loan Number     :")) {
								statements = statements.replace("                 Loan Number     :", "Loan Number  :");
								
							}
							if (trimStr.startsWith("Period")) {
								statements = statements.replace(str, str.trim());
								statements = statements.replace("Period", "                       Period");
							}
							if (trimStr.startsWith("Installments")) {
								statements = statements.replace("           Installments", "Installments");
							}
							if (i == 0) {
								statements = statements.replace(str.trim(), str+ "                    ");
							}
							if (i == statementsArr.length-3 || i == statementsArr.length-2 || i == statementsArr.length-1) {
								if(i == statementsArr.length-1) {
									statements = statements.replace(str, str+"                       ");
								}else {
									statements = statements.replace(str, str+"     ");
								}
							}
							if (trimStr.startsWith("SIRMA CONSULTING")) {
								int counttt = 0;
								while(counttt <=4) {
									String strng = statementsArr[i +counttt];
									String valStrArr[] = strng.split("  ");
									for(int j = 0; j< valStrArr.length; j++) {
										String fnalStr = valStrArr[j];
										if(fnalStr.length() >=2) {
											statements = statements.replace(fnalStr, fnalStr +"              ");
											counttt++;
										}
									}
								}
							}
						}
						//PKY00079 ends
					}
					if(I$utils.$iStrFuzzyMatch(statements, "")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Generate the Statement");
		    			return isonMsg;
					}
					ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
					Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
					//PKY00079 starts
					if(dcn.equals("")) {
						document.setMargins(4, 4, 10, 10);
					}else {
						document.setMargins(140, 140, 20, 20);
					}
					document.setMarginMirroring(true);
					//PKY00079 ends
					PdfWriter.getInstance(document, byteArrayOutputStream).setPdfVersion(PdfWriter.PDF_VERSION_1_7);
					document.open();
					//PKY00079 starts
					Font font = new Font();
					if(dcn.equals("")) {
						font = new Font(FontFamily.COURIER, 9, Font.NORMAL, BaseColor.BLACK);
					}else {
						font = new Font(FontFamily.COURIER, 8, Font.NORMAL, BaseColor.BLACK);
					}
					Chunk content = new Chunk(statements);
					Paragraph para = new Paragraph();
					para.setFont(font);
					para.setLeading(0, 1);
					para.setAlignment(para.ALIGN_JUSTIFIED_ALL);
					para.add(content);
					document.add(para);
					//PKY00079 ends
					document.close();
					byte[] pdfBytes = byteArrayOutputStream.toByteArray();
					String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
					
					i$body = new JsonObject();
					i$body.addProperty("cif", cif);
					i$body.addProperty("accountNo", accountNo);
					i$body.addProperty("branch", branch);
					i$body.addProperty("statementPdf", base64Str);
					db$Ctrl.db$InsertRow("ICOR_C_FCUBS_STATEMENT" , i$body);
					i$body.remove("accountNo");
					i$body.remove("branch");
					if(i$body.has("cif"))
						i$body.remove("cif");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
				}else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Generate the Statement");
	    			return isonMsg;
				}
				
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to get the account details");
    			return isonMsg;
			}
    	}catch(Exception e) {
    		
    	}
    	return isonMsg;
    }
    
	public IStatusController()
	{
		//Cons
	}

}
//#00000001 Ends