/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag    | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.16.340  | Syed       | Aug 05, 2019 | #MAQ000025  | Initial Writings
      |0.3.16.340  | Srikanth   | Nov 14, 2023 | #SRI00021   | Handling The Country code LOV Part 
      ----------------------------------------------------------------------------------------------
*/
// #MAQ000025 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javassist.expr.NewArray;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRKYCController.imbpmFwdThread;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil; // #MAQ000015
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICbsEDataRestrictionsController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
	JsonObject projection = new JsonObject();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				return RestSummary(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				return RestQuery(isonMsg, isonheader, isonMapJson);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	}

	public JsonObject RestSummary(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		String Coll_Name = "";
		String ScrId = i$ResM.getScreenID(isonMsg);
		i$body = i$ResM.getBody(isonMsg);
		JsonArray response = new JsonArray();
		// #MAQ000015 starts
		String SOpr = i$ResM.getOpr(isonMsg);

		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();

		String SOpr1 = i$ResM.getOpr1(isonMsg);
		String SOpr2 = i$ResM.getOpr2(isonMsg);

		if (i$Match == null) {
			JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
			i$Match = new JsonObject();
			try {
				// if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
						&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") // #MAQ00001
				)) {

					for (int i = 0; i < i$MatchMap.size(); i++) {
						// #BVB00183 Starts
						JsonElement matchElm = i$ResM.getBodyElement(isonMsg, i$MatchMap.get(i).getAsString());
						if (!I$utils.$isNull(matchElm)) { // #BVB00188
							if (matchElm.isJsonPrimitive()) {
								i$Match.addProperty(i$MatchMap.get(i).getAsString(),
										i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
							} else if (matchElm.isJsonArray()) {
								JsonArray matchArr = matchElm.getAsJsonArray();
								String iMatchStr = "{'$in': ['";
								for (int j = 0; j < matchArr.size(); j++) {
									if (j < matchArr.size() - 1)
										iMatchStr = iMatchStr + matchArr.get(j).getAsString() + "','";
									else {
										iMatchStr = iMatchStr + matchArr.get(j).getAsString() + "']}";
									}
								}

								i$Match.add(i$MatchMap.get(i).getAsString(), parser.parse(iMatchStr).getAsJsonObject());

							}
							// #BVB00183 Ends
							// #BVB00188 Starts
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
							return isonMsg;
						}
						// #BVB00188 Ends
					}
					;
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
				} else {
					i$Match = null;
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
				}
			} catch (Exception e) {
				i$Match = null;
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}"); // #MAQ00001
			}
			;
		}
		;

		// #BVB00005 Ends
		// #BVB00016 Starts
		if (i$ProjectionArray != null) {
			for (int i = 0; i < i$ProjectionArray.size(); i++) {
				i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
			}
		} else {

			JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
			if (i$ProjectionMap != null) {// #BVB00033
				try {
					if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						for (int i = 0; i < i$ProjectionMap.size(); i++) {
							i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
						}
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
					} else {
						i$Projection = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
					}
				} catch (Exception e) {
					e.printStackTrace();
					i$Projection = null;
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
				}
				;
				// #BVB00033 Starts
			} else {
				i$Projection = null;
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
			}
			// #BVB00033 Ends
		}
		// #BVB00016 Ends
		// #MAQ000015 ends
		try {

			try {
				i$body = isonMsg.getAsJsonObject("i-body");
			} catch (Exception e) {
				i$body = null;
			}
			Integer i$MaxRow = -1;
			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}

			int intPgNo, intRecs;
			try {
				intPgNo = i$body.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = i$body.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 0;
			}
			// #MAQ00013 starts
			String sort = "";
			try {
				String sortField = i$body.get("sort").getAsString();
				sort = "{'" + sortField + "':1}";
			} catch (Exception e) {
				sort = "{'_id':-1}";
			}

			try {
				String Type = i$body.get("Type").getAsString();
				JsonObject allwListQuery = getUserAllowedList(IResManipulator.iloggedUser.get(), Type);
				i$Match.add("KeyId", allwListQuery);
			} catch (Exception e) {
				e.printStackTrace();
			}

//			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY"))
//			{
//				
//				JsonObject j$DataFilter = I$impactoUtil.get$FrmDataSetFilter(isonMsg);
//				
//				// #NYE00015 Begin
//				if (j$DataFilter != null)
//				{
//					// Get Formated I-MATCH Dataset Filter
//					i$Match = j$DataFilter;
//				}
//				// #NYE00015 End
//			}
			// #NYE00014
			if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
				// #MAQ00009 starts
				int iRowCnt = 0;
				JsonObject db$res = null;

				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
				try {
					if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {

						iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
						db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection, intPgNo,
								intRecs, sort);

						// #MAQ00002 end
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
				i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");
				i$body.addProperty("iRowCnt", iRowCnt);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				return isonMsg;
				// #MAQ00009 ends

			}
			// #MAQ00014 ends
			// #MAQ00004 ends
			else {
				// #MAQ00005 code starts
				if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
					if (I$utils.$iStrFuzzyMatch(ScrId, "LABCDTFR")) {
						JsonObject mainData = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection, intPgNo,
								intRecs, sort); 
						i$body = new JsonObject();
						i$body.add("data", i$ResM.getBodyA(mainData));
						i$Match.addProperty("frequent", "Y");
						JsonObject frequentData = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection, intPgNo,
								intRecs, sort);
						 
						i$body.add("frequent", i$ResM.getBodyA(frequentData));
						
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
						return isonMsg; 
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "LABCDATA") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")
							&& I$utils.$iStrFuzzyMatch(
									isonMsg.get("i-body").getAsJsonObject().get("Type").getAsString(), "CBS_CNTRY")) { // SRI00021
																														// Starts
						sort = "{'_id':1}";
						JsonObject res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
								intPgNo, intRecs, sort);
						JsonArray AllData = res.get("i-body").getAsJsonArray();
						JsonObject desiredObject = null;
						String targetKeyId = "TT";
						for (int i = 0; i < AllData.size(); i++) {
							JsonObject TTData = AllData.get(i).getAsJsonObject();
							String currentKeyId = TTData.getAsJsonPrimitive("KeyId").getAsString();
							if (targetKeyId.equals(currentKeyId)) {
								desiredObject = TTData;
								AllData.remove(i);
							}
						}
						response.add(desiredObject);
						response.addAll(AllData);
					    i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, response);
					    return isonMsg;
					}																										//SRI00021 Ends
					else {
						return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection, intPgNo,
								intRecs, sort));
					}
					// #MAQ00005 code ends
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
					return isonMsg;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_RSTS");
		}

	}

	public JsonObject RestQuery(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		String Coll_Name = "";

		i$body = i$ResM.getBody(isonMsg);
		// #MAQ000015 starts
		String SOpr = i$ResM.getOpr(isonMsg);

		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();

		String SOpr1 = i$ResM.getOpr1(isonMsg);
		String SOpr2 = i$ResM.getOpr2(isonMsg);

		try {
			Coll_Name = isonMapJson.get("COLLNAME").getAsString();
		} catch (Exception e) {
			Coll_Name = null;
		}

		if (I$utils.$isNull(i$body.get("KeyId"))) { // #BVB00188
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "KeyId is Null");
			return isonMsg;
		}

		if (i$Match == null) {
			JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
			i$Match = new JsonObject();
			try {
				// if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
						&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") // #MAQ00001
				)) {

					for (int i = 0; i < i$MatchMap.size(); i++) {
						// #BVB00183 Starts
						JsonElement matchElm = i$ResM.getBodyElement(isonMsg, i$MatchMap.get(i).getAsString());
						if (!I$utils.$isNull(matchElm)) { // #BVB00188
							if (matchElm.isJsonPrimitive()) {
								i$Match.addProperty(i$MatchMap.get(i).getAsString(),
										i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
							} else if (matchElm.isJsonArray()) {
								JsonArray matchArr = matchElm.getAsJsonArray();
								String iMatchStr = "{'$in': ['";
								for (int j = 0; j < matchArr.size(); j++) {
									if (j < matchArr.size() - 1)
										iMatchStr = iMatchStr + matchArr.get(j).getAsString() + "','";
									else {
										iMatchStr = iMatchStr + matchArr.get(j).getAsString() + "']}";
									}
								}

								i$Match.add(i$MatchMap.get(i).getAsString(), parser.parse(iMatchStr).getAsJsonObject());

							}
							// #BVB00183 Ends
							// #BVB00188 Starts
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
							return isonMsg;
						}
						// #BVB00188 Ends
					}
					;
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
				} else {
					i$Match = null;
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
				}
			} catch (Exception e) {
				i$Match = null;
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}"); // #MAQ00001
			}
			;
		}
		;

		// #BVB00005 Ends
		// #BVB00016 Starts
		if (i$ProjectionArray != null) {
			for (int i = 0; i < i$ProjectionArray.size(); i++) {
				i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
			}
		} else {

			JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
			if (i$ProjectionMap != null) {// #BVB00033
				try {
					if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						for (int i = 0; i < i$ProjectionMap.size(); i++) {
							i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
						}
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
					} else {
						i$Projection = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
					}
				} catch (Exception e) {
					e.printStackTrace();
					i$Projection = null;
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
				}
				;
				// #BVB00033 Starts
			} else {
				i$Projection = null;
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
			}
			// #BVB00033 Ends
		}
		// #BVB00016 Ends
		// #MAQ000015 ends

		JsonObject icorRestObj = new JsonObject();
		try {
			JsonArray filterArray = new JsonArray();
			JsonObject filterObj1 = new JsonObject();
			JsonObject filterObj2 = new JsonObject();
			String Type = i$body.get("Type").getAsString();

			JsonObject allwListQuery = getUserAllowedList(IResManipulator.iloggedUser.get(), Type);
			filterObj1.addProperty("KeyId", i$body.get("KeyId").getAsString());
			filterObj2.add("KeyId", allwListQuery);
			filterArray.add(filterObj1);
			filterArray.add(filterObj2);
//			i$Match.remove("KeyId");
			i$Match.add("$and", filterArray);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			icorRestObj = db$Ctrl.db$GetRow(Coll_Name, i$Match, i$Projection);
			if (!I$utils.$isNull(icorRestObj)) {
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorRestObj);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
			} else {
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_WARNING, "NO RECORDS FOUND");
			}
		} catch (Exception e) {
//			logger.debug("Failed in Dedup Query with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
		}

		return isonMsg;
	}

	public JsonObject getUserAllowedList(String userId, String Type) {
		JsonObject filter = new JsonObject();
		JsonObject subqry = new JsonObject();
		try {
			filter.addProperty("Amd_Id", userId);
			JsonObject icorRtsAmb = db$Ctrl.db$GetRow("ICOR_M_B2U_AMBASSADOR", filter);
			JsonObject Restrictions = icorRtsAmb.get("Restrictions").getAsJsonObject();
			if (Restrictions.has(Type + "Allow")) {
				String typeAllow = Restrictions.get(Type + "Allow").getAsString();
				JsonArray TypeRestrs = Restrictions.get(Type + "List").getAsJsonArray();
				if (I$utils.$iStrFuzzyMatch(typeAllow, "A")) {
					subqry.add("$in", TypeRestrs);
				} else if (I$utils.$iStrFuzzyMatch(typeAllow, "D")) {
					subqry.add("$nin", TypeRestrs);
				}
			} else {
				subqry.add("$nin", new JsonArray());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return subqry;
	}

}
// #MAQ000025 Ends 