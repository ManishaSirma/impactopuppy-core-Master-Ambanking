/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Dec 1, 2018  | #BVB00020   | Added Projection 
      |0.2.1       | Vijay 		| Jan 18, 2019 | #BVB00039   | SDN Upload Changes 
      |0.2.1       | Niegil 	| Feb 07, 2019 | #NYE00040   | Constants Added 
      |0.2.1       | Vijay  	| Feb 17, 2019 | #BVB00060   | Constants Added for Flexcube WS Adapter  
      |0.2.1       | Niegil 	| Feb 27, 2019 | #NYE00041   | Constants Added Error Framework
      |0.3.9       | Vijay 		| May 27, 2019 | #BVB00158   | CData Handling in CoreReq Forwarder
      |0.2.1       | Niegil 	| May 22, 2019 | #NYE10042   | Added DataSet Filter KeyName
      |0.3.14      | VIjay  	| Jun 10, 2019 | #BVB00164   | NoSqlInjection Correction Changes
      |0.3.15      | Vijay  	| Jun 18, 2019 | #BVB00171   | Session Handling for SessionTracking SrcId
      |0.3.17      | Vijay 		| Aug 05, 2019 | #BVB00191   | ReKyc Flow change
      |0.3.17      | Pavithra 	| Aug 22, 2023 | #PAV00015   | Constants added
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

public enum IConstants {
    I_SUCC("i-SUCC"),
    I_SUCCESS("i-success"),
    I_ERR("i-ERROR"),
    I_ERROR("i-error"),
    I_WRN("i-WARN"),
    I_HEADER("i-header"),
    I_WARNING("i-warn"),//#NYE00040
    I_MSGTEXT("msgtext"),
    I_SUCCWCD("iS#WS00001"),
    I_BDYTAG("i-body"),
    I_BDYRTAG("#BODYRTAG#"),
    I_STATTAG("i-stat"),
    I_STATTAGMSG("i-statMsg"), // #NYE00041  
    I_STATMSGCODE("msgcode"), // #NYE00041 
    I_CONFREQ("conReq"), // #NYE00041 
    I_MATCH("i-match"),
    I_PROJECTION("i-projection"),    // #BVB00020 
    I_RAR("RAR"), // #BVB00039
    I_ZIP("ZIP"),// #BVB00039
    I_DSTFLTR("dataSetFltr"), //#NYE10042
    I_ERRWCD("iE#WS00001"),
    I_WRNWCD("iW#WS00001"),
    I_CALLJAVA("CALLJAVA"), // #BVB00060 
    I_CALLWS("CALLWS"),// #BVB00060 
    // #BVB00191 Starts 
    //I_DRIVERSPERMIT("Drivers Permit"),
   I_DRIVERPERMIT("Driver's Permit"),
    I_DRIVERSPERMIT("DRIVER'S PERMIT"),//#PAV00015 Changes Starts
   // I_NATIONALID("National Id"),
    I_NATIONALID("NATIONAL IDENTIFICATION CARD"),//#PAV00015 Changes Starts
    
    I_PASSPORT("PASSPORT"), I_PRIDOC ("Primary Document"), I_SECDOC("Secondary Document"),
    I_XML("XML"),
    //SBC0087 Starts
    I_NO_PEP_SELECTION("{\n"+
            "  \"isHeadOfState\": \"N\",\n"+
            "  \"isHeadOfGovt\": \"N\",\n"+
            "  \"isSenPolitician\": \"N\",\n"+
            "  \"isSenGovtOfficial\": \"N\",\n"+
            "  \"isSenJudicialOfficial\": \"N\",\n"+
            "  \"isSenMilitaryOfficial\": \"N\",\n"+
            "  \"isSenExecSOC\": \"N\",\n"+
            "  \"isImpPPO\": \"N\",\n"+
            "  \"isImmediateFamily\": \"N\",\n"+
            "  \"isPersonIntrntnlOrg\": \"N\",\n"+
            "  \"isPepAssociate\": \"N\"\n"+
            "}"),
    
    //SBC0087 Ends
    
    // #BVB00191 Ends
    I_DEF_FLXDS("nkebcDlm/GXheLaABzw86cueKSLxXmur/D9bE2YMrlkvChbfNTnJR2XSLJfVQy/s"),// #00000002
  //#00000002 Begins 
    // #BVB00158 Added  p_spl_parsing and p_blk_parsing to the request below
     I_FLXWSPRM("{\r\n" + 
    		"  \"OrclOprMode\": \"CallProc\",\r\n" + 
    		"  \"OrclProcName\": \"procimpactoflxwsadaptor_custom\",\r\n" + 
    		"  \"Paramters\": {\r\n" + 
    		"    \"p_is_req_clob\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"IN\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_req_xml_str\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"IN\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_req_xml_clob\": {\r\n" + 
    		"      \"Type\": \"CLOB\",\r\n" + 
    		"      \"Mode\": \"IN\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_instr_xml\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"INOUT\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_is_res_clob\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"OUT\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_res_xml_str\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"OUT\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_res_xml_clob\": {\r\n" + 
    		"      \"Type\": \"CLOB\",\r\n" + 
    		"      \"Mode\": \"OUT\",\r\n" + 
    		"      \"ResFld\": \"1\"\r\n" + 
    		"    },\r\n" +  
    		"    \"p_spl_parsing\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"IN\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    },\r\n" + 
    		"    \"p_blk_parsing\": {\r\n" + 
    		"      \"Type\": \"VARCHAR\",\r\n" + 
    		"      \"Mode\": \"IN\",\r\n" + 
    		"      \"ResFld\": \"0\"\r\n" + 
    		"    }\r\n" +
    		"  }\r\n" + 
    		"}"),
    //#00000002 Ends
    I_REQTPL("{\r\n" + 
    		"  \"i-config\":{\r\n" + 
    		"    \"sitekey\" :\"\",\r\n" + 
    		"    \"browser\":\"\",\r\n" + 
    		"    \"clientApp\":\"\",\r\n" + 
    		"    \"imecd\":\"\",\r\n" + 
    		"    \"os\":\"\",\r\n" + 
    		"    \"brwversion\":\"\",\r\n" + 
    		"    \"osversion\":\"\",\r\n" + 
    		"    \"iclntversion\":\"\",\r\n" + 
    		"	\"sessionID\":\"\"\r\n" + 
    		"  },\r\n" + 
    		"  \"i-header\" :{\r\n" + 
    		"    \"msg-id\":\"\",\r\n" + 
    		"    \"key-hash\":\"\",\r\n" + 
    		"    \"screenid\" :\"\",\r\n" + 
    		"    \"srvcname\" :\"\",\r\n" + 
    		"    \"srvcopr\" :\"\",\r\n" + 
    		"    \"srvcopr1\" :\"\",\r\n" + 
    		"    \"srvcopr2\" :\"\",\r\n" + 
    		"    \"srvcopr3\" :\"\",\r\n" + 
    		"    \"operation\" :\"\",\r\n" + 
    		"    \"operation1\" :\"\",\r\n" + 
    		"    \"operation2\" :\"\",\r\n" + 
    		"    \"operation3\" :\"\"\r\n" + 
    		"  },\r\n" + 
    		"  \"i-body\" :#BODYRTAG#,\r\n" +
    		"  \"i-match\" :{},\r\n" + 
    		"  \"i-stat\":{\r\n" + 
    		"    \"i-stat\":\"_STATMSG\",\r\n" + 
    		"    \"i-success\":{\r\n" + 
    		"      \"msgcode\":\"_SUCC\",\r\n" + 
    		"	  \"msgcode\":\"_SUCCTEXT\"\r\n" + 
    		"    },\r\n" + 
    		"    \"i-warn\":{\r\n" + 
    		"      \"msgcode\":\"_WARN\",\r\n" + 
    		"	  \"msgcode\":\"_WARNTEXT\"\r\n" + 
    		"    },\r\n" + 
    		"    \"i-error\":{\r\n" + 
    		"      \"msgcode\":\"_ERR\",\r\n" + 
    		"	  \"msgcode\":\"_ERRTEXT\"\r\n" + 
    		"    }\r\n" + 
    		"  }\r\n" + 
    		"}"),
    I_REQTPL_NBDY("{\r\n" + 
    		"  \"i-config\":{\r\n" + 
    		"    \"sitekey\" :\"\",\r\n" + 
    		"    \"browser\":\"\",\r\n" + 
    		"    \"clientApp\":\"\",\r\n" + 
    		"    \"imecd\":\"\",\r\n" + 
    		"    \"os\":\"\",\r\n" + 
    		"    \"brwversion\":\"\",\r\n" + 
    		"    \"osversion\":\"\",\r\n" + 
    		"    \"iclntversion\":\"\",\r\n" + 
    		"	\"sessionID\":\"\"\r\n" + 
    		"  },\r\n" + 
    		"  \"i-header\" :{\r\n" + 
    		"    \"msg-id\":\"\",\r\n" + 
    		"    \"key-hash\":\"\",\r\n" + 
    		"    \"screenid\" :\"\",\r\n" + 
    		"    \"srvcname\" :\"\",\r\n" + 
    		"    \"srvcopr\" :\"\",\r\n" + 
    		"    \"srvcopr1\" :\"\",\r\n" + 
    		"    \"srvcopr2\" :\"\",\r\n" + 
    		"    \"srvcopr3\" :\"\",\r\n" + 
    		"    \"operation\" :\"\",\r\n" + 
    		"    \"operation1\" :\"\",\r\n" + 
    		"    \"operation2\" :\"\",\r\n" + 
    		"    \"operation3\" :\"\"\r\n" + 
    		"  },\r\n" + 
    		"  \"i-body\" :{},\r\n" +
    		"  \"i-match\" :{},\r\n" + 
    		"  \"i-stat\":{\r\n" + 
    		"    \"i-stat\":\"_STATMSG\",\r\n" + 
    		"    \"i-success\":{\r\n" + 
    		"      \"msgcode\":\"_SUCC\",\r\n" + 
    		"	  \"msgcode\":\"_SUCCTEXT\"\r\n" + 
    		"    },\r\n" + 
    		"    \"i-warn\":{\r\n" + 
    		"      \"msgcode\":\"_WARN\",\r\n" + 
    		"	  \"msgcode\":\"_WARNTEXT\"\r\n" + 
    		"    },\r\n" + 
    		"    \"i-error\":{\r\n" + 
    		"      \"msgcode\":\"_ERR\",\r\n" + 
    		"	  \"msgcode\":\"_ERRTEXT\"\r\n" + 
    		"    }\r\n" + 
    		"  }\r\n" + 
    		"}"),
    I_WEBVAL("{\r\n" + 
    		"    \"ANNOTATION\":\"\",\r\n" + 
    		"    \"BYPASS\":\"\",\r\n" + 
    		"    \"FIELDS\":[{\r\n" + 
    		"      \"FIELDNAME\":\"\",\r\n" + 
    		"      \"FIELDTYPE\":\"\",\r\n" + 
    		"      \"FIELDLEN\":\"\",\r\n" + 
    		"      \"REQUIRED\":\"\",\r\n" + 
    		"      \"ENNUMTYPE\":{}\r\n" + 
    		"    }]\r\n" + 
    		"}"),
    I_RESISTAT("{\r\n" + 
			"    \"i-statMsg\":\"#STATMSG\",\r\n" + 
			"    \"i-success\":{\r\n" + 
			"      \"msgcode\":\"#SUCC\",\r\n" + 
			"	  \"msgtext\":\"#STEXT\"\r\n" + 
			"    },\r\n" + 
			"    \"i-warn\":{\r\n" + 
			"      \"msgcode\":\"#WARN\",\r\n" + 
			"	  \"msgtext\":\"#WTEXT\"\r\n" + 
			"    },\r\n" + 
			"    \"i-error\":{\r\n" + 
			"      \"msgcode\":\"#ERR\",\r\n" + 
			"	  \"msgtext\":\"#ETEXT\"\r\n" + 
			"    }\r\n" + 
			"  }"),
    // #BVB00171 Starts 
    I_CORE_SESSION("{\r\n" + 
    		"    \"sessionId\": \"2019061711292050058cd9bb2-a5e4-4b6d-af33-0a577de2efb3\",\r\n" + 
    		"    \"PVal\": \"MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIam3V8WdTFlKzEi9srxDvJOeRJzbgeWqKPSgkfm+hiB3fT2+Y5UARn7tqwGEA+9EipVoiLQdVzduZoGM+JfbIHFub9NLOE8jk3tfU+USUaG+OxY32A340jcyF7mogQYHS73wnvqLe0aVc/iz2Y1WKKyhTmb5MYYSYYiG4MqBG7LAgMBAAECgYEAhZskpKkf97cuuD69KnkuH3eF4qzuTFFNW+AQrU+ecJrLpbk5vePUg/ejNeV+Il+0mpUFoA2/pjnLY+0rpj6Q5m+EJZnbxJSS86vymvM3JAcN+q+v//mIzF7/CqbBuWzglrBngSqvC+97aavwrb6o0o3gITINPVnEn17dhmUPSYECQQDUazeljtOCiPTd7FjbWwU2tCtMjidrAUuyGmvV1+1uy1qub57aPdBIqCUzboPWCfvrsBIpbF2hraCMtI8UQet7AkEAokcf15vrDN43KWXydqin9cMmHzgLLM+St6ZGL++EwS8r8kfx0vLfrdMr9IvJ00IszhjiyAfBhFEgEflBJBVA8QJAOXGhQ9FjG4rkBVvUD8YGm+uPRg2vVT2tdcW1YcgZ+ntd04x1/fj3aZ6nKMh7OJfMm8kqsC8RBxcIMuTlSIonHwJAc/lqu1d1+6NQPujaCI1uRAis1QDjk6nhTBir7pQ6BypkOOnL3Juw2fSiZEoG+lE/3icQ5C4O0jZ8Ofwt3tDFsQJAbpFwWtl/q8WPG8q5CfXZTCi5Ak/NWlzDSDWPtazX6fAFqxAw3M2bCwP8a44/XO++g/AbPPzoRkwOl3TTGrfrqw==\",\r\n" + 
    		"    \"SVal\": \"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSck04sFvHOfvURxo8/q9Q4eGZ1DCzPqhIKeTHLEyliUg9wpIuFJG1GsZ26DXEdbFgo0iFtZX7k7tizxdUUiF9x2S6y1oUtnWU0xRCWUWe4w7vR7DxLFIbBwdU15cW1QnNFDpn3L4Ciot5eiFGAR+BIRJPaGkGjPJrvVVRPqgBawIDAQAB\",\r\n" + 
    		"    \"createdAt\": \"2019-06-17T09:28:00.000Z\",\r\n" + 
    		"    \"lastActivityAt\": \"2032-06-17T09:28:00.000Z\",\r\n" + 
    		"    \"privateKey\": \"MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJJyTTiwW8c5+9RHGjz+r1Dh4ZnUMLM+qEgp5McsTKWJSD3Cki4UkbUaxnboNcR1sWCjSIW1lfuTu2LPF1RSIX3HZLrLWhS2dZTTFEJZRZ7jDu9HsPEsUhsHB1TXlxbVCc0UOmfcvgKKi3l6IUYBH4EhEk9oaQaM8mu9VVE+qAFrAgMBAAECgYBndmOCIm6k4R0+iwFJiHGZxgvZ3ySM7j57xUVBRdXcuZGVOIqIDbYnagQ+661Y4AFyEcnh1TliJKwlkcOcqe3IWmXQnzetpnUFknEtFBtUmEblUwqNTWbeKb61OByv94WuMdE9rzjrpuU1Cvao5ajZPGZaOAEemCmqmz/3MqfX4QJBAMNdE2lcU94uLfqvimZsm4NWPKxYDY+lNzSJAL3iseMRRtHR8DMy+PeOWzjp5RIIU5iXN+UlvKcw62ykXg6Qz3ECQQC/5nDYGz2KXZKxitJhouWHw/18p/28qllWq98UTaXTyiup0h/kSpSf/mr4Hll2YzPlSyVpKIwDHRXjH+d6vOibAkAyYmDNPXiLxpEpI/inrb71wlnngNYOg+eW7vZ4Am0qSJxhJKm0KqM3BUnVhc0EN42Hvwg1WuQqol01KbbwPryhAkEAs8caToruk3LoW+X3BDtMl21YS/FBt/9LJPRtUCMSSKCtWTIeaIwqQt1hr0MXgt6bHqPQz3yJ9tzHxXj9LjJOIwJARjQTZTls2kgaT1BlCm/jjC+/PXVVw82KKfk5BX7VK6Eta2fZE7txzpu94NVMdudk8rARNjX96O2646ogB/62ZA==\",\r\n" + 
    		"    \"publicKeyE\": \"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGpt1fFnUxZSsxIvbK8Q7yTnkSc24Hlqij0oJH5voYgd309vmOVAEZ+7asBhAPvRIqVaIi0HVc3bmaBjPiX2yBxbm/TSzhPI5N7X1PlElGhvjsWN9gN+NI3Mhe5qIEGB0u98J76i3tGlXP4s9mNViisoU5m+TGGEmGIhuDKgRuywIDAQAB\"\r\n" + 
    		"}"),
    I_ORACLE("ORACLE"),
    I_MONGO("MONGO"),
    I_CUSMEM("Member"), I_CUSMEMCAPS("MEMBER"),
    I_RESTATARR("{\"i-statMsg\": \"#STATMSG\", \"i-success\": [], \"i-warn\": [], \"i-error\": [] }"),
	I_SUCCTEXT("Request completed successfully"), I_WRNTEXT("Request completed with warnings"), 
	I_ERRTEXT("Request failed with errors"),I_MAIN_SESSION("MainSession"),I_PRAGMA_SESSION("MainSession"),
	I_CONF("i-conf"), I_SUP_LOC_MSG("i-suppLocalMsg"), I_CONFIG("i-config");
	
	// #BVB00171 Ends
	private final String text;
    IConstants(final String text) {
        this.text = text;
    }
    @Override
    public String toString() {
        return text.toString();
    }
};
//#00000001 Ends