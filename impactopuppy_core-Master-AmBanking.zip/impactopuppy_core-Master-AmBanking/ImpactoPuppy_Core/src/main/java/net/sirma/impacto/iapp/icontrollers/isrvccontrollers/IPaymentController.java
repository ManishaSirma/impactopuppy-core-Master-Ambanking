/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |4.3 Beta    | Vijay   	| Sep 08 2020  | #BVB02101   | Initial writing
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB02101 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class IPaymentController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private static DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil imp$utils = new ImpactoUtil();

	private IResManipulator i$ResM = new IResManipulator();
	private IEmailService i$Email = new IEmailService();
	private ISmsService i$SmsSrvc = new ISmsService();
	private Logger logger = LoggerFactory.getLogger(IPaymentController.class); // #NYE00003 - Change Class Name
	// **********************************************************************//

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			String SOpr = i$ResM.getOpr(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "MAKEPAYMENT")) {
				return generatePaymentLink(i$body, isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OPERATION");
			}
			//else if (I$utils.$iStrFuzzyMatch(SrvOpr, "verifyToken")) {
				//return verifyToken(i$body, isonMsg);
			//}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg;
		}
		return null;
	};
	
	private JsonObject generatePaymentLink(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonParser parser = new JsonParser();
			JsonObject JResp = new JsonObject();
			isonMsg = productCreation(argJson , isonMsg , parser , JResp);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
				String productId = isonMsg.get("i-body").getAsJsonObject().get("productId").getAsString();
				String unitAmount = argJson.get("unitAmount").getAsString();
				String currency = argJson.get("currency").getAsString();
				isonMsg = priceCreation(isonMsg , productId , unitAmount , currency);
			}
			
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
				String priceId = isonMsg.get("i-body").getAsJsonObject().get("priceId").getAsString();
				isonMsg = paymentLinkCreation(isonMsg , priceId);
			}
//			if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
//				String paymentIntentId = isonMsg.get("i-body").getAsJsonObject().get("paymentIntentId").getAsString();
//				isonMsg = paymentStatus(isonMsg , paymentIntentId);
//			}
			return isonMsg;

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Generating Payment Link ");
		}

	}

	private JsonObject productCreation(JsonObject argJson , JsonObject isonMsg , JsonParser parser, JsonObject JResp) {
		try {
			JsonObject i$body = new JsonObject();
			i$body = isonMsg.get("i-body").getAsJsonObject();
			String orgId = i$body.get("productName").getAsString();
			String prodName = argJson.get("productName").getAsString();
			String unitAmount = argJson.get("unitAmount").getAsString();
			String currency = argJson.get("currency").getAsString();
			JsonObject icorCParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", 
    				"{'paymentObj'=1}");
			String authorization = icorCParam.get("paymentObj").getAsJsonObject().get("Authorization").getAsString();
			OkHttpClient client = new OkHttpClient().newBuilder().build();
			MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
			RequestBody body = RequestBody.create(mediaType, "name=" + prodName + "");
			;
			Request request = new Request.Builder().url("https://api.stripe.com/v1/products").method("POST", body)
					.addHeader("Authorization",
							authorization)
					.addHeader("Content-Type", "application/x-www-form-urlencoded").build();
			Response response = client.newCall(request).execute();
			String resBody = "";
			String productId = "";
			if (response.code() == 200) {
				resBody = response.body().string();
				JResp = parser.parse(resBody).getAsJsonObject();
				JResp.addProperty("orgId", orgId);
				Timestamp stamp = new Timestamp(System.currentTimeMillis());
				Date date = new Date(stamp.getTime());
				JResp.addProperty("created", date.toString());
				db$Ctrl.db$InsertRow("ICOR_C_LIC_STRIPE_PRODUCTS" , JResp);
				productId = JResp.get("id").getAsString();
				i$body.addProperty("productId", productId);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Product Created Successfully ");
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in creating Product");
			}
		}catch(Exception e) {}
		return isonMsg;
	}
	
	private JsonObject priceCreation(JsonObject isonMsg , String productId , String unitAmount , String currency) {
		try {
			String resBody = "";
			JsonParser parser = new JsonParser();
			JsonObject JResp = new JsonObject();
			JsonObject i$body = new JsonObject();
			String priceId = "";
			i$body = isonMsg.get("i-body").getAsJsonObject();
			String orgId = i$body.get("productName").getAsString();
			JsonObject icorCParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", 
    				"{'paymentObj'=1}");
			String authorization = icorCParam.get("paymentObj").getAsJsonObject().get("Authorization").getAsString();
			OkHttpClient client = new OkHttpClient().newBuilder().build();
			MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
			RequestBody body = RequestBody.create(mediaType,
					"unit_amount=" + unitAmount + "&currency=" + currency + "&product=" + productId + "");
			Request request = new Request.Builder().url("https://api.stripe.com/v1/prices").method("POST", body).addHeader(
					"Authorization",
					authorization)
					.addHeader("Content-Type", "application/x-www-form-urlencoded").build();
			Response response = client.newCall(request).execute();
			if (response.code() == 200) {
				resBody = response.body().string();
				JResp = parser.parse(resBody).getAsJsonObject();
				JResp.addProperty("orgId", orgId);
				Timestamp stamp = new Timestamp(System.currentTimeMillis());
				Date date = new Date(stamp.getTime());
				JResp.addProperty("created", date.toString());
				db$Ctrl.db$InsertRow("ICOR_C_LIC_STRIPE_PRICE" , JResp);
				priceId = JResp.get("id").getAsString();
				i$body.addProperty("priceId", priceId);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Price Created Successfully ");
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Creating Price");
			}
		}catch(Exception e) {
			
		}
		
		return isonMsg;
	}
	
	private JsonObject paymentLinkCreation(JsonObject isonMsg , String priceId) {
		try {
			String resBody = "";
			JsonParser parser = new JsonParser();
			JsonObject JResp = new JsonObject();
			JsonObject i$body = new JsonObject();
			String paymentLink = "";
			JsonObject icorCParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", 
    				"{'paymentObj'=1}");
			Instant instant = Instant.now();
			long seconds = TimeUnit.MINUTES.toSeconds( 33 );
			Instant fiveMinutesLater = instant.plusSeconds( seconds );
			long output = fiveMinutesLater.getEpochSecond();
			Timestamp stamp = new Timestamp(System.currentTimeMillis()+30*60*1000);
//			int i = stamp.getSeconds();
			String authorization = icorCParam.get("paymentObj").getAsJsonObject().get("Authorization").getAsString();
			String successUrl = icorCParam.get("paymentObj").getAsJsonObject().get("paymentLinks").getAsJsonObject().get("successUrl").getAsString();
			String cancelUrl = icorCParam.get("paymentObj").getAsJsonObject().get("paymentLinks").getAsJsonObject().get("cancelUrl").getAsString();
			i$body = isonMsg.get("i-body").getAsJsonObject();
			String orgId = i$body.get("productName").getAsString();
			OkHttpClient client = new OkHttpClient().newBuilder()
					  .build();
					MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
					RequestBody body = RequestBody.create(mediaType, "success_url="+successUrl+"&cancel_url="+cancelUrl+"&line_items[0][price]="+priceId+"&line_items[0][quantity]=2&mode=payment&expires_at="+output+"");
					Request request = new Request.Builder()
					  .url("https://api.stripe.com/v1/checkout/sessions")
					  .method("POST", body)
					  .addHeader("Authorization", authorization)
					  .addHeader("Content-Type", "application/x-www-form-urlencoded")
					  .build();
					Response response = client.newCall(request).execute();
			if (response.code() == 200) {
				resBody = response.body().string();
				JResp = parser.parse(resBody).getAsJsonObject();
				JResp.addProperty("orgId", orgId);
				Date date = new Date(stamp.getTime());
				JResp.addProperty("created", date.toString());
				db$Ctrl.db$InsertRow("ICOR_C_LIC_STRIPE_PAYMENTLINKS" , JResp);
				paymentLink = JResp.get("url").getAsString();
				i$body.addProperty("paymentLink", paymentLink);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Payment Link Created Successfully ");
			}else {
				resBody = response.body().string();
				JResp = parser.parse(resBody).getAsJsonObject();
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Creating Payment Link");
			}
		}catch(Exception e) {
			
		}
		return isonMsg;
	}
	
//	private JsonObject paymentStatus(JsonObject isonMsg , String paymentIntentId) {
//		try {
//			String resBody = "";
//			JsonParser parser = new JsonParser();
//			JsonObject JResp = new JsonObject();
//			JsonObject i$body = new JsonObject();
//			String status = "";
//			i$body = isonMsg.get("i-body").getAsJsonObject();
//			String orgId = i$body.get("productName").getAsString();
//			OkHttpClient client = new OkHttpClient().newBuilder()
//					  .build();
//					Request request = new Request.Builder()
//					  .url("https://api.stripe.com/v1/payment_intents/"+paymentIntentId+"")
//					  .method("GET", null)
//					  .addHeader("Authorization", "Bearer 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")
//					  .build();
//					Response response = client.newCall(request).execute();
//					if (response.code() == 200) {
//						resBody = response.body().string();
//						JResp = parser.parse(resBody).getAsJsonObject();
//						JResp.addProperty("orgId", orgId);
//						Timestamp stamp = new Timestamp(System.currentTimeMillis());
//						Date date = new Date(stamp.getTime());
//						JResp.addProperty("created", date.toString());
//						db$Ctrl.db$InsertRow("ICOR_C_IBORG_STRIPE_PAYMENTSTATUS" , JResp);
//						status = JResp.get("status").getAsString();
//						i$body.addProperty("paymentStatus", status);
//						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Payment Processed Successfully ");
//					}else {
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Processing Payment");
//					}
//		}catch(Exception e) {
//			
//		}
//		return isonMsg;
//	}
}