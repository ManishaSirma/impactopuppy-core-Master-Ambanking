/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag    | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.2       | Baz 		| May 15, 2019 | #BZ00000001   | Initial writting
      |0.3.12.272  | Syed 		| May 30, 2019 | #MAQ000015    | Added DataSet filter for CIF Summary
      |0.3.12.272  | Manikanta  | Jan 23, 2023 | #MVT00101	   | Added code for CIF summary
      ----------------------------------------------------------------------------------------------
*/
// #BZ00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRKYCController.imbpmFwdThread;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil; // #MAQ000015
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICifController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil(); // #MAQ000015
	private static final Logger logger = LoggerFactory.getLogger(ICifController.class);

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "SB2UCIFD") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				return createKYCApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "SB2UCIFD") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				return createKYCApln(isonMsg, isonheader, isonMapJson);
			} else if(I$utils.$iStrFuzzyMatch(Scr, "LCRCCUDT") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")){ //#MVT00101 changes
				return cifSummary(isonMsg, isonMapJson);
			}
			{
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	}
	//#MVT00101 begins
	public JsonObject cifSummary(JsonObject isonMsg, JsonObject isonMapJson) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			
			JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
			if (i$ProjectionMap != null) {
				for (int i = 0; i < i$ProjectionMap.size(); i++) {
					projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
				}
			}
            JsonObject subqry = new JsonObject();
            subqry.addProperty("$ne", "96");
            filter.add("CustomerCategory", subqry.getAsJsonObject());
            filter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			filter.addProperty("CustomerDobDate", ibody.get("CustomerDobDate").getAsString());
			ibody = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection);
			if(I$utils.$isNull(ibody)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORD FOUND");
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
		} catch(Exception e) {
			logger.debug(e.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
		}
		return isonMsg;
	}
	//#MVT00101 ends
	public JsonObject createKYCApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String Coll_Name = "";

		jBody = i$ResM.getBody(isonMsg);
		// #MAQ000015 starts
		String SOpr = i$ResM.getOpr(isonMsg);
		JsonObject i$Match = new JsonObject();
		// #MAQ000015 ends
		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}

			int skip = 0;
			int limit = 10;
			int totalAppls = 0;
			try {
				skip = jBody.get("intPgNo").getAsInt(); // #MAQ000015 
			} catch (Exception e) {
				skip = 0;
			}
			;
			try {
				limit = jBody.get("intRecs").getAsInt(); // #MAQ000015 
			} catch (Exception e) {
				limit = 10;
			}
			;
			JsonArray res$blder = new JsonArray();

			JsonObject Proj = new JsonObject();
			Proj.addProperty("_id", 0);
			Proj.addProperty("CustomerId", 1);
			Proj.addProperty("CustomerFullName", 1);
			Proj.addProperty("CustomerType", 1);
			Proj.addProperty("CustomerBranch", 1);
			Proj.addProperty("digiCheck", 1);
			// #MAQ000015 starts
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY"))
			{
				
				JsonObject j$DataFilter = I$impactoUtil.get$FrmDataSetFilter(isonMsg);
				
				// #NYE00015 Begin
				if (j$DataFilter != null)
				{
					// Get Formated I-MATCH Dataset Filter
					i$Match = j$DataFilter;
				}
				// #NYE00015 End
			}
			//	#NYE00014

			totalAppls = db$Ctrl.db$GetCountI(Coll_Name, i$Match);
			JsonObject cif$apps = db$Ctrl.db$GetRows(Coll_Name, i$Match.toString(), Proj.toString(), skip, limit);
			// #MAQ000015 ends
			JsonArray cif$s = cif$apps.get("i-body").getAsJsonArray();
			for (int i = 0; i < cif$s.size(); i++) {
				JsonObject cif = cif$s.get(i).getAsJsonObject();
				JsonObject filter = new JsonObject();
				JsonObject cif$proj = new JsonObject();

				filter.addProperty("cif", cif.get("CustomerId").getAsString());
				cif$proj.addProperty("documents", 1);
				JsonObject cif$docs = db$Ctrl.db$GetRow("ICOR_M_B2U_DOC_TRACKER", filter, cif$proj);
				if (cif$docs != null) {
					try {
						cif.add("documents", cif$docs);
					} catch (Exception e) {
						// pass
					}

				}
				res$blder.add(cif);
			}

			JsonObject res$ = new JsonObject();
			res$.add("PaginatedCifs", res$blder);
			res$.addProperty("TotalApplsInQueue", "" + totalAppls);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$);
			// isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
			// wrk$flwTasks);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");

		}

	}

	public ICifController() {
		// Cons
	}
}
// #BZ00000001 Ends 