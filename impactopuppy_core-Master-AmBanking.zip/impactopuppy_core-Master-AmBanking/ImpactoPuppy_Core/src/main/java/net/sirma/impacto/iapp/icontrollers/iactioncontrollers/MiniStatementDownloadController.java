/*
Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
Sirma Business Consulting India reserves all rights to this code . No part of this code should 
be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
take all reasonable precautions to protect the source code and documentation, and preserve its
confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
and permanent injunctive relief in addition to such remedies as may otherwise be available.

//But by the grace of God We are what we are, and his grace to us was not without effect. No, 
//We worked harder than all of them--yet not We, but the grace of God that was with us.
----------------------------------------------------------------------------------------------
|Version No  | Changed by   | Date         | Change Tag  | Changes Done
----------------------------------------------------------------------------------------------
|0.1 Beta    | Pappu 		| Jun 3, 2022  | #PKY00073   | Initial writing
----------------------------------------------------------------------------------------------

*/
//#PKY00073 Begins

package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.net.URLDecoder;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.FlexGenericWSApadter;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IXmlParser;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

import org.apache.commons.codec.binary.Base64;

@Controller
public class MiniStatementDownloadController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	private JsonObject JLogger = new JsonObject();
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	private JsonObject JTransmitter = new JsonObject();
	private IXmlParser I$XmlParser = new IXmlParser();
	private FlexGenericWSApadter flexWsAdap = new FlexGenericWSApadter();
	private Ioutils I$utils = new Ioutils();
	// **********************************************************************//
	private static final Logger logger = LoggerFactory.getLogger(MiniStatementDownloadController.class);

	@SuppressWarnings("resource")
	@RequestMapping(value = { "", "/miniStatement.pdf", "/Letter_Request_travel.pdf" , "/Letter_Request_bank.pdf" , "/Letter_Request_other.pdf","/Family_Idemnity_Plane_Deduction_Form.pdf","/T_FD_Application_PDF.pdf","/Beneficiary_Agreement_Fixed_Deposit.pdf","/Terms_And_Conditions_Fixed_Deposits .pdf","/Cuna_Designation_Of_Beneficiary_Phase2.pdf","/enhanced_due_diligence_form.pdf","/joint_patner.pdf","/Internet_Mobile_Facility.pdf","/member_onboarding.pdf","/MEMBER DISCLOSURE STATEMENT.pdf"}, method = RequestMethod.GET, produces = "application/pdf")
	@ResponseBody()
	public void viewMiniStatement(HttpServletRequest request, HttpServletResponse response, Locale locale) throws Exception {
		try {
			String query = "";
			try {
				String queryFrmUrl = request.getQueryString();
				query = URLDecoder.decode(queryFrmUrl, "UTF-8");
			} catch (Exception e) {

			}
			if (!I$utils.$iStrBlank(query)) {
				String[] fQuery = query.split("=");
				JsonObject filter = new JsonObject();
				JsonObject isonMsg = new JsonObject();
				filter.addProperty("FileUrlToken", fQuery[1]);
				JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
				if (!I$utils.$isNull(icorMDmsLogger)) {
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(icorMDmsLogger), i$ResM.I_SUCC)) {
						isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
						isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
							JsonObject fileData = db$Ctrl.db$GetRowWithId("fs.files", icorMDmsLogger.get("FileUrlId").getAsString());
							JsonObject fileDataMeta = fileData.getAsJsonObject("metadata");
							if (I$utils.$iStrFuzzyMatch(fileDataMeta.get("DocType").getAsString(), "CASA MINI STATEMENT") || I$utils.$iStrFuzzyMatch(fileDataMeta.get("DocType").getAsString(), "LOAN MINI STATEMENT") || I$utils.$iStrFuzzyMatch(fileDataMeta.get("DocType").getAsString(), "LETTER MINI STATEMENT")) {
								String base64Str = i$ResM.getBody(isonMsg).get("FileContent").getAsString();
								byte[] pdf = Base64.decodeBase64(base64Str.getBytes());
								response.setContentType("application/pdf");
								response.setContentLength(pdf.length);
								response.getOutputStream().write(pdf);
							}
						}
					}
				}
			}
			if (!I$utils.$iStrFuzzyMatch(response.getContentType(), "application/pdf")) {
				response.setContentType("text/html");
				// response.setContentLength(pdf.length);
				response.getOutputStream().print("Invalid url");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setContentType("text/html");
			// response.setContentLength(pdf.length);
			response.getOutputStream().print("Invalid url");
		}
	}
}
//#PKY00073 ends