/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Dec 20, 2018  | #00000001   | Initial writing
      |0.3.8       | Vijay 		| May 14, 2019  | #BVB00151   | Adding Name to Response
      |0.3.9	   | Manikanta  | Jan 28, 2022  | ##MVT00031  | Added code for Register account data
      |----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ialgo.ImpactoTOTP;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IdentityAppController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoTOTP i$TOTP = new ImpactoTOTP();
	private OtpController iotp = new OtpController();
	private Logger logger = LoggerFactory.getLogger(IpasscodeController.class); // Nye- Change Class Name
	// **********************************************************************//

	
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String sSOpr = i$ResM.getSrvcopr(isonMsg);
			String sSvr = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(sSvr, "ImpactoIdentityService") && I$utils.$iStrFuzzyMatch(sSOpr, "Register")) 
			{
				return Register$Identity(isonMsg);
			}
			else 
			{
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
		return null;
	}
	
	
	
	public JsonObject Register$Identity (JsonObject isonMsg)
	{
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject jBody = new JsonObject();
		JsonObject r$ec = new JsonObject();
		JsonObject jblkBody = new JsonObject();
		String scifID =null;
		String sSecKey = null;
		String sOTP = null;
		try
		{
			scifID = i$body.get("cifID").getAsString();
			sSecKey = i$body.get("Key").getAsString();
			sOTP = i$body.get("valStr").getAsString();
			try
			{ 
				r$ec = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", "{\"Key_Owner\":\""+scifID+"\",\"Key_Mode\":\"CID\"}");
			}
			catch(Exception e)
			{
				r$ec = null;
			}
			
			if (r$ec == null) 
			 return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN IMPACTO USER");
			else
			{
				// Verify The OTP
				JsonObject argJson = new JsonObject();
				argJson.addProperty("otp",sOTP);
				argJson.addProperty("iSecKey",sSecKey);
				if (iotp.verify$OTP(argJson))
				{
					//Save to DB
					jBody.addProperty("identityIME", i$ResM.getIME(isonMsg));
					db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", jBody, "{\"Key_Owner\":\""+
						scifID+"\",\"Key_Mode\":{\"$regex\": \"[C]\"}}");
					
					jblkBody.addProperty("succKey",r$ec.get("Key_Token").getAsString());
					jblkBody.addProperty("cif",scifID);
					jblkBody.addProperty("prfPic",r$ec.get("prfPic").getAsString());
					jblkBody.addProperty("Name",r$ec.get("Name").getAsString()); // #BVB00151

					//#MVT00031 changes startes
					String cif = r$ec.get("Key_Owner").getAsString();
					String prfPic = r$ec.get("prfPic").getAsString();
					String name = r$ec.get("Name").getAsString();
					JsonArray accountData = new JsonArray();
					JsonObject filter = new JsonObject();
					JsonObject projection = new JsonObject();
					filter.addProperty("CustNo", cif);
					projection.addProperty("CustAcNo", "1");
					projection.addProperty("AcDesc", "1");
					projection.addProperty("AcCcy", "1");
					projection.addProperty("AcBranch", "1");
					projection.addProperty("CustomerImg", "1");

					accountData = db$Ctrl.db$GetRows("ICOR_M_CBS_ACCOUNT_DATA", filter, projection);
					if (accountData.size() > 0) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ACCOUNTS RETRIEVED SUCESSFULLY");
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
					}
					// #BVB00180 Ends
					JsonObject i$res = new JsonObject();
					jblkBody.add("accountData", accountData);

					// #BVB00079 Starts
					// Adding Biometrics if Available
					if (r$ec.has("bioMetrics")) {
						jblkBody.add("bioMetrics", r$ec.get("bioMetrics").getAsJsonObject());
					}
					// Adding identityIME if available
					if (r$ec.has("identityIME")) {
						jblkBody.addProperty("identityIME", r$ec.get("identityIME").getAsString());
					}
					jblkBody.addProperty("keyToken", r$ec.get("Key_Token").getAsString());
					// #BVB00079 Ends
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jblkBody);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "MEMBER OR " + i$ResM.I_CUSMEMCAPS + " SUCESSFULLY REGISTERED FOR IMPACTO MY-IDENTITY");
					
				} else {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
				}//#MVT00031 Changes ends
			}
		}catch(Exception es)
		{
			es.printStackTrace();
			logger.debug(es.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN IMPACTO MY-IDENTITY REGISTRATION");
			return isonMsg;
		}
	}

}

//#00000001 Ends