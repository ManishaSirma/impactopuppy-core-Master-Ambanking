/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Jan 17, 2019 | #00000001   | Initial writing
      |0.2.1       | Vijay 		| Jan 24, 2019 | #BVB00040   | Intial Fixes For CBS Adapter 
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import com.ximpleware.*;

import net.sirma.impacto.iapp.iutils.Ioutils;
import com.github.underscore.lodash.U;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class IXmlParser {
	private Logger logger = LoggerFactory.getLogger(IXmlParser.class);
	private Ioutils I$utils = new Ioutils();

	public String cov$Xml2Str(Document xml) {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = tf.newTransformer();
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(xml), new StreamResult(writer));
			String output = writer.getBuffer().toString();
			return output;
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return null;
	}

	public String cov$XmlStr2JsonStr(String sXml) {
		try {
			return U.xmlToJson(sXml);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public JsonObject cov$XmlStr2Json(String sXml) {
		try {
			JsonParser parser = new JsonParser();
			return parser.parse(U.xmlToJson(sXml)).getAsJsonObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// #BVB00040
	public String getXpathValDom(String xpathString, String xmlString) {

		// Create XPathFactory object
		XPathFactory xpathFactory = XPathFactory.newInstance();
		String stringRes = "";
		// Create XPath object
		XPath xpath = xpathFactory.newXPath();

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = null;

		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
			doc.getDocumentElement().normalize();

			XPathExpression expr = xpath.compile(xpathString);
			stringRes = (String) expr.evaluate(doc, XPathConstants.STRING);

		} catch (Exception e) {

			stringRes = null;
		}

		return stringRes;
	}

	public String getTagValue(String sourcetag, String xmlBody) {
 
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		String finalBuf = "";
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlBody)));
			doc.getDocumentElement().normalize();
			NodeList nodes = doc.getElementsByTagName(sourcetag);
			for (int i = 0; i < nodes.getLength(); i++) {

				Node elem = nodes.item(i);
				StringWriter buf = new StringWriter();
				Transformer xform = TransformerFactory.newInstance().newTransformer();
				xform.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				xform.setOutputProperty(OutputKeys.INDENT, "yes");
				xform.transform(new DOMSource(elem), new StreamResult(buf));
				finalBuf = buf.toString();

				finalBuf = finalBuf.replaceAll("<" + sourcetag + ">", "");
				finalBuf = finalBuf.replaceAll("</" + sourcetag + ">", "");
				//logger.debug("Final Response: " + finalBuf);
			}

		} catch (Exception e) {

			finalBuf = null;
		}
		return finalBuf;
	}

	// #BVB00040
	public String getXpathVal(String Xpath, String xml) {
		try {
			VTDGen vg = new VTDGen();
			byte[] bytes = null;
			bytes = xml.getBytes("UTF-8");
			vg.setDoc(bytes);
			vg.parse(true);
			String sVal = "";
			VTDNav vn = vg.getNav();
			AutoPilot ap = new AutoPilot(vn);
			ap.selectXPath(Xpath);
			int iResult = -1;
			int iCount = 0;
			while ((iResult = ap.evalXPath()) != -1) {
				logger.debug("Element name ==> " + vn.toString(iResult));
				int iIndex = vn.getText();
				if (iIndex != -1) {

					if (I$utils.$iStrBlank(sVal))
						sVal = vn.toNormalizedString(iIndex);
					else
						sVal = sVal + "\r\n" + vn.toNormalizedString(iIndex);
				}
				iCount++;
			}
			logger.debug("Total # of element " + iCount);
			logger.debug("sVal :" + sVal);
			return sVal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getMessage());
			return null;
		}
	};

	public String getXpathVal(String Xpath, Document d$xml) {
		try {
			String xml = cov$Xml2Str(d$xml);
			VTDGen vg = new VTDGen();
			byte[] bytes = null;
			bytes = xml.getBytes("UTF-8");
			vg.setDoc(bytes);
			vg.parse(true);
			String sVal = "";
			VTDNav vn = vg.getNav();
			AutoPilot ap = new AutoPilot(vn);
			ap.selectXPath(Xpath);
			int iResult = -1;
			int iCount = 0;
			while ((iResult = ap.evalXPath()) != -1) {
				logger.debug("Element name ==> " + vn.toString(iResult));
				int iIndex = vn.getText();
				if (iIndex != -1) {

					if (I$utils.$iStrBlank(sVal))
						sVal = vn.toNormalizedString(iIndex);
					else
						sVal = sVal + "\r\n" + vn.toNormalizedString(iIndex);
				}
				iCount++;
			}
			logger.debug("Total # of element " + iCount);
			logger.debug("sVal :" + sVal);
			return sVal;
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getMessage());
			return null;
		}
	};

	public Document cov$Str2Xml(String xmlStr) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlStr)));
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
// #00000001 Ends