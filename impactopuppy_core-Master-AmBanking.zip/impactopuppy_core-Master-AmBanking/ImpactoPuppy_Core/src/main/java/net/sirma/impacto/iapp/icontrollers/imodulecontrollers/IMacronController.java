/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.7       | Vijay 		| May 02, 2019 | #BVB00138   | Initial writing
      |0.3.9       | Vijay 		| May 26, 2019 | #BVB00155   | Threshold setter for SDN Scan and Adding fieldName specific search
      ----------------------------------------------------------------------------------------------
*/
// #BVB00138 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;

import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.codec.language.Soundex;

public class IMacronController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IMacronController.class);

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			JsonObject i$body = new JsonObject();

			if (I$utils.$iStrFuzzyMatch(Scr, "OCRSDNMC") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				loadSdnMacron(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OCRSDNMC") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				doSDNScan(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject loadSdnMacron(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		try {
			JsonArray macronsA = new JsonArray();
			// load 10 recs from ICOR_M_SDN_DETAIL
			JsonArray sdnDet = db$Ctrl.db$GetSummRowsArray("ICOR_M_SDN_DETAILS_TEST", "{'FullName': {$ne:''}}",
					"{'FullName':1, '_id': 0,'FName':1,'LName':1,'SdnListId':1}", 0, 5);
			JsonObject macronObj = new JsonObject();

			// Get FName, LName, Full Name and do the above logic and insert into
			// ICOR_M_SDN_DET_MICRONS with Micron_ID, Lang as extra feilds

			for (int i = 0; i < sdnDet.size(); i++) {
				JsonObject i$runningObj = sdnDet.get(i).getAsJsonObject();
				String SdnListId = i$runningObj.get("SdnListId").getAsString();
				Set<Entry<String, JsonElement>> entrySet = i$runningObj.entrySet();
				for (Map.Entry<String, JsonElement> entry : entrySet) {
					String currField = entry.getKey();
					String currVal = i$runningObj.get(currField).getAsString();
					if (!I$utils.$iStrFuzzyMatch(currVal, "") || !I$utils.$iStrFuzzyMatch(currField, "SdnListId")) {
						macronsA = new JsonArray();
						macronObj = new JsonObject();
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 3, 1));
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 3, 2));
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 2, 1));
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 1, 1));

						for (int j = 0; j < macronsA.size(); j++) {
							macronObj.addProperty(macronsA.get(j).getAsString(), 1);
						}
						filter = new JsonObject();
						filter.addProperty("Micron_ID", currVal);
						filter.addProperty("FieldName", currField);

						macronObj.addProperty("Micron_ID", currVal);
						macronObj.addProperty("Lang", "ENG");
						macronObj.addProperty("FieldName", currField);
						macronObj.addProperty("SdnListId", SdnListId);

						// db$Ctrl.db$InsertRow("ICOR_M_SDN_DET_MICRONS", macronObj);
						db$Ctrl.db$UpdateRow("ICOR_M_SDN_DET_MICRONS", macronObj, filter, "true");
					}
				}
			}
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOAD COMPLETED");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOAD FAILED WITH", e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject loadSdnMac(JsonObject sdnDetail, JsonArray macroReqArr) {
		JsonObject filter = new JsonObject();

		JsonArray macronsA = new JsonArray();
		JsonObject macronObj = new JsonObject();
		try {

			// build the object

			// Get FName, LName, Full Name and do the above logic and insert into
			// ICOR_M_SDN_DET_MICRONS with Micron_ID, Lang as extra feilds

			String SdnListId = sdnDetail.get("SdnListId").getAsString();
			Set<Entry<String, JsonElement>> entrySet = sdnDetail.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				String currField = entry.getKey();
				String currVal = sdnDetail.get(currField).getAsString();
				if (sdnDetail.get(currField).isJsonPrimitive()) {
					if (I$utils.isInArray(macroReqArr, currField) && !I$utils.$iStrFuzzyMatch(currVal, "")) {
						macronsA = new JsonArray();
						macronObj = new JsonObject();
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 3, 1));
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 3, 2));
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 2, 1));
						macronsA.addAll(i$impactoUtil.sLdD(currVal, 1, 1));

						for (int j = 0; j < macronsA.size(); j++) {
							macronObj.addProperty(macronsA.get(j).getAsString(), 1);
						}
						filter = new JsonObject();
						filter.addProperty("Micron_ID", currVal);
						filter.addProperty("FieldName", currField);

						macronObj.addProperty("Micron_ID", currVal);
						macronObj.addProperty("Lang", "ENG");
						macronObj.addProperty("FieldName", currField);
						macronObj.addProperty("SdnListId", SdnListId);

						// db$Ctrl.db$InsertRow("ICOR_M_SDN_DET_MICRONS", macronObj);
						// db$Ctrl.db$UpdateRow("ICOR_M_SDN_DET_MICRONS", macronObj, filter, "true");
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOAD FAILED WITH",
			// e.getMessage());
		}
		return macronObj;
	}

	public JsonObject doSDNScan(JsonObject isonMsg) {
		Gson gson = new Gson();
		JsonArray i$hits = new JsonArray();
		try {

			String searchText = i$ResM.getBodyElementS(isonMsg, "value");

			JsonArray totalAlpha = i$impactoUtil.sLdDTrn(searchText, 1, 1);
			JsonArray totalS3D1 = i$impactoUtil.sLdDTrn(searchText, 3, 1);
			JsonArray totalS2D1 = i$impactoUtil.sLdDTrn(searchText, 2, 1);
			JsonArray totalS3D1add = new JsonArray();
			JsonArray totalS2D1add = new JsonArray();
			JsonArray totalAlphaadd = new JsonArray();

			for (int i = 0; i < totalAlpha.size(); i++) {
				String i$runningStr = totalAlpha.get(i).getAsString();
				JsonObject i$runningObj = new JsonObject();
				JsonArray i$runningArr = new JsonArray();
				i$runningArr.add(i$runningStr);
				i$runningArr.add(0);
				i$runningObj.add("$ifNull", i$runningArr);
				totalAlphaadd.add(i$runningObj);

			}

			for (int i = 0; i < totalS3D1.size(); i++) {
				String i$runningStr = totalS3D1.get(i).getAsString();
				JsonObject i$runningObj = new JsonObject();
				JsonArray i$runningArr = new JsonArray();
				i$runningArr.add(i$runningStr);
				i$runningArr.add(0);
				i$runningObj.add("$ifNull", i$runningArr);

				totalS3D1add.add(i$runningObj);

			}

			for (int i = 0; i < totalS2D1.size(); i++) {
				String i$runningStr = totalS2D1.get(i).getAsString();
				JsonObject i$runningObj = new JsonObject();
				JsonArray i$runningArr = new JsonArray();
				i$runningArr.add(i$runningStr);
				i$runningArr.add(0);
				i$runningObj.add("$ifNull", i$runningArr);

				totalS2D1add.add(i$runningObj);

			}

			String totalAlphaStr = "{$addFields: {totalAlpha: {$add: " + gson.toJson(totalAlphaadd) + " } } }";
			String totalS3D1Str = "{$addFields: {totalS3D1: {$add: " + gson.toJson(totalS3D1add) + " } } }";
			String totalS2D1Str = "{$addFields: {totalS2D1: {$add: " + gson.toJson(totalS2D1add) + " } } }";
			String projection = "{ $project: { 'FieldName' : 1, 'Micron_ID' : 1, 'SdnListId' :1, 'Lang' :1 } }";
			String matchStr = "{'$match': {'$and': [{'totalAlpha': {'$gte': 3 } }, {'$or': [{'totalS3D1': {'$gte': 2 } }, {'totalS2D1': {'$gte': 3 } }] }] } }";
			JsonArray i$AggParam = new JsonArray();
			i$AggParam.add(totalAlphaStr);
			i$AggParam.add(totalS3D1Str);
			i$AggParam.add(totalS2D1Str);
			i$AggParam.add(matchStr);
			i$AggParam.add(projection);

			i$hits = db$Ctrl.db$DoAggregate("ICOR_M_SDN_DET_MICRONS", i$AggParam);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$hits);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SDN QUERY COMPLETED");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SDN QUERY FAILED WITH", e.getMessage());
		}

		return isonMsg;
	}

	public JsonArray doSDNScan(String fieldName, String fieldVal, JsonObject sdnParam) {
		Gson gson = new Gson();
		JsonArray i$hits = new JsonArray();
		try {

			String searchText = fieldVal;
			// #BVB00155 Starts 
			JsonArray sdnConfig = sdnParam.getAsJsonArray("sdnConfig"); 
			double totAlpha = sdnConfig.get(0).getAsJsonObject().get("score").getAsDouble(); 
			totAlpha = totAlpha * fieldVal.length(); 
			int tot31 = sdnConfig.get(1).getAsJsonObject().get("score").getAsInt(); 
			int tot21 = sdnConfig.get(2).getAsJsonObject().get("score").getAsInt();
			// #BVB00155 Ends 
			JsonArray totalAlpha = i$impactoUtil.sLdDTrn(searchText, 1, 1);
			JsonArray totalS3D1 = i$impactoUtil.sLdDTrn(searchText, 3, 1);
			JsonArray totalS2D1 = i$impactoUtil.sLdDTrn(searchText, 2, 1);
			JsonArray totalS3D1add = new JsonArray();
			JsonArray totalS2D1add = new JsonArray();
			JsonArray totalAlphaadd = new JsonArray();

			for (int i = 0; i < totalAlpha.size(); i++) {
				String i$runningStr = totalAlpha.get(i).getAsString();
				JsonObject i$runningObj = new JsonObject();
				JsonArray i$runningArr = new JsonArray();
				i$runningArr.add(i$runningStr);
				i$runningArr.add(0);
				i$runningObj.add("$ifNull", i$runningArr);
				totalAlphaadd.add(i$runningObj);

			}

			for (int i = 0; i < totalS3D1.size(); i++) {
				String i$runningStr = totalS3D1.get(i).getAsString();
				JsonObject i$runningObj = new JsonObject();
				JsonArray i$runningArr = new JsonArray();
				i$runningArr.add(i$runningStr);
				i$runningArr.add(0);
				i$runningObj.add("$ifNull", i$runningArr);

				totalS3D1add.add(i$runningObj);

			}

			for (int i = 0; i < totalS2D1.size(); i++) {
				String i$runningStr = totalS2D1.get(i).getAsString();
				JsonObject i$runningObj = new JsonObject();
				JsonArray i$runningArr = new JsonArray();
				i$runningArr.add(i$runningStr);
				i$runningArr.add(0);
				i$runningObj.add("$ifNull", i$runningArr);

				totalS2D1add.add(i$runningObj);

			}

			String totalAlphaStr = "{$addFields: {totalAlpha: {$add: " + gson.toJson(totalAlphaadd) + " } } }";
			String totalS3D1Str = "{$addFields: {totalS3D1: {$add: " + gson.toJson(totalS3D1add) + " } } }";
			String totalS2D1Str = "{$addFields: {totalS2D1: {$add: " + gson.toJson(totalS2D1add) + " } } }";
			String projection = "{ $project: { 'FieldName' : 1, 'Micron_ID' : 1, 'SdnListId' :1, 'Lang' :1 } }";
			String matchStr = "{'$match': {'$and' : [ {'$and': [{'totalAlpha': {'$gte': " +totAlpha + " } }, {'$or': [{'totalS3D1': {'$gte': "+ tot31+ " } }, {'totalS2D1': {'$gte': "+ tot21+ " } }] }]}, {'FieldName': '"+  fieldName +"'}] }}"; // BVB00155
			JsonArray i$AggParam = new JsonArray();
			i$AggParam.add(totalAlphaStr);
			i$AggParam.add(totalS3D1Str);
			i$AggParam.add(totalS2D1Str);
			i$AggParam.add(matchStr);
			i$AggParam.add(projection);

			i$hits = db$Ctrl.db$DoAggregate("ICOR_M_SDN_DET_MICRONS", i$AggParam);

			//
//			String query = "db.getCollection('ICOR_M_SDN_DET_MICRONS').aggregate([{$addFields: {totalAlpha: {$add: "
//					+ gson.toJson(totalAlphaadd) + " } } }, {$addFields: {totalS3D1: {$add: " + gson.toJson(totalS3D1add)
//					+ " } } }, {$addFields: {totalS2D1: {$add: " + gson.toJson(totalS2D1add)
//					+ " } } }, {'$match': {'$and': [{'totalAlpha': {'$gte': 3 } }, {'$or': [{'totalS3D1': {'$gte': 2 } }, {'totalS2D1': {'$gte': 3 } }] }] } }])";
//
//			logger.debug("query: " + query);

		} catch (Exception e) {
			e.printStackTrace();
		}

		// return isonMsg;
		return i$hits;
	}

	public IMacronController() {
		// Cons
	}
}
// #BVB00138 Ends
