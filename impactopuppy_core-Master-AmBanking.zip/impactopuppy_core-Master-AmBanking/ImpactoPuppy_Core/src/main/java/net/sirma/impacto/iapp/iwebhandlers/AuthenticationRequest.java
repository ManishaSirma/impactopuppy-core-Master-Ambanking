/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Baz 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Niegil 	| Jan 16,2019  | #00000002   | New Field Additions in Auth
      |0.1 Beta    | Niegil 	| Feb 06,2019  | #00000003   | TranID handling
      |0.2.1       | Vijay  	| Mar 17,2019  | #BVB00095   | Adding Biometrics For Authorization
      |0.3.15      | Vijay 	    | Jun 18, 2019 | #BVB00170   | Adding SrcID to the request
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iwebhandlers;


import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthenticationRequest {
	@NotNull(message = "Please provide User ID")
    private String username;
	@NotNull(message = "Please provide Password")
    private String password;
	//@NotNull(message = "Please provide first Name")
    private String InstIndetifier; // #00000002 Changes : Changed creditUnion to InstIndetifier - Institution Identifier  
    private String ipassCode;
    private String tranId;
    private String token;
    private String secCode;
    private String captchaID;
    private String sessionID; 
    private String clientApp; // #00000002 Add 
    private String ime;// #00000002 Add
    private String srcApiKey;// #00000002 Add
    private String sitekey;// #00000002 Add
    private String reqid; // #00000002 Add
    // #BVB00095 Starts
	private String iBio;
	private String SrcID; // #  BVB00170
	
	 
	// #BVB00170 Starts 
	public String getSrcID() {
		return SrcID;
	}

	public void setSrcID(String srcID) {
		SrcID = srcID;
	}
	// #BVB00170 Ends
	public String getiBio() {
		return iBio;
	}

	public void setiBio(String iBio) {
		this.iBio = iBio;
	}
	// #BVB00095 Ends
	// #00000003 Begins
    public String getTranID() {
		return tranId;
	}
	
	// #00000002 Begins
    public String getSitekey() {
		return sitekey;
	}
    public String getReqid() {
		return reqid;
	}
    public String getclientApp() {
		return clientApp;
	}
    public String getIme() {
		return ime;
	}
    public String getsrcApiKey() {
		return srcApiKey;
	}
   // #00000002 Ends
    
    public String getcaptchaID() {
		return captchaID;
	}
	public String getUsername() {
		return username;
	}
	
	public void setcaptchaID(String captchaID) {
		this.captchaID = captchaID;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getInstIndetifier() {
		return InstIndetifier; // #00000002 Changes
	}
	public void setInstIndetifier(String InstIndetifier) {
		this.InstIndetifier = InstIndetifier; // #00000002 Changes
	}
	public String getipassCode() {
		return ipassCode;
	}
	public void setipassCode(String ipassCode) {
		this.ipassCode = ipassCode;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getSecCode() {
		return secCode;
	}
	public void setSecCode(String secCode) {
		this.secCode = secCode;
	}
	
	 // #00000002 Begins
	public void setclientApp(String clientApp) {
		this.clientApp = clientApp;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public void setsrcApiKey(String srcApiKey) {
		this.srcApiKey = srcApiKey;
	}
	public void setSitekey(String sitekey) {
		this.sitekey = sitekey;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getSessionID() {
		return sessionID;
	}
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	
   // #00000002 Ends

  // #00000003 Begins
	 public void setTranID(String tranId) {
		 this.tranId = tranId;
		}
  // #00000003 Ends
	
}
//#00000001 Ends