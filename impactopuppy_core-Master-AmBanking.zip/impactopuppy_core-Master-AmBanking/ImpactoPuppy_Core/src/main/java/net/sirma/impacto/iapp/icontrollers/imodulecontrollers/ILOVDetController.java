/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.17       | Vijay 	| Jul 31, 2019 | #BVB00190   | Initial writing 
      |0.3.17       | Sindhu  	| June 12,2023 | #SRM00041   | Added code to handle lov call for salary range sorting 
      |0.3.17       | Sindhu  	| June 14,2023 | #SRM00042   | Added code to handle lov call for financial year sorting 

      ----------------------------------------------------------------------------------------------
*/
// #BVB00133 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ILOVDetController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(ILOVDetController.class);
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			JsonObject i$body = new JsonObject();
			String Coll_Name ;


			if (I$utils.$iStrFuzzyMatch(Scr, "OCRLOVDT") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = queryLovDetails(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "LABSSORT") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")||
					I$utils.$iStrFuzzyMatch(Scr, "LB2FIYER") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {  //#SRM00042 changes
				isonMsg = summaryLovDetails(isonMsg, isonMapJson);
			}
				else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject queryLovDetails(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject lovData = new JsonObject();
		int skip = 0;
		int limit = 50;
		try {
			String keyId = i$ResM.getBodyElementS(isonMsg, "keyId");

			// Get data from the db from ICOR_M_LOV_DETAILS
			filter.addProperty("keyId", keyId);
			JsonObject icorMLovDet = db$Ctrl.db$GetRow("ICOR_M_LOV_DETAILS", filter);
			if (!I$utils.$isNull(icorMLovDet)) {
				JsonArray lovIds = icorMLovDet.getAsJsonArray("lovIds");

				// Fetch data of each LOV
				for (int i = 0; i < lovIds.size(); i++) {
					JsonObject i$runningObj = lovIds.get(i).getAsJsonObject();
					filter = new JsonObject();
					filter.addProperty("Type", i$runningObj.get("lovId").getAsString());
					projection = new JsonObject();
					JsonArray projArr = new JsonArray();
					projArr = i$runningObj.get("projection").getAsJsonArray();
					for (int j = 0; j < projArr.size(); j++) {
						projection.addProperty(projArr.get(j).getAsString(), "1");
					}
					try {
						skip = i$runningObj.get("skip").getAsInt();
					} catch (Exception e) {
						skip = 0;
					}

					try {
						limit = i$runningObj.get("limit").getAsInt();
					} catch (Exception e) {
						limit = 50;
					}

					lovData.add(i$runningObj.get("lovId").getAsString(),
							db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_E_DATA", filter, projection, skip, limit));
				}

				// Attach default data
				lovData.add("icorMLovDet", icorMLovDet.get("defaultValues").getAsJsonArray());

				// frame the body
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", lovData);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOV DETAILS RETRIEVED SUCCESSFULLY");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID KEY ID PRESENTED");
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"FAILED WHILE FETCHING LOV DETAILS WITH " + e.getMessage());

		}
		// response sent
		return isonMsg;
	}
	// #SRM000041 Changes start
	public JsonObject summaryLovDetails(JsonObject isonMsg, JsonObject isonMapJson) {
		JsonObject i$body = isonMsg.getAsJsonObject("i-body");
		String Scr = i$ResM.getScreenID(isonMsg);
		try {
			JsonObject projection = new JsonObject();
			JsonObject filter = new JsonObject();
			String sort = "";
			int skip = 0;
			int limit = 0;
			Integer maxRow = 0;
			JsonObject sortData = null;
			try {
				String sortField = i$body.get("sort").getAsString();
				if(I$utils.$iStrFuzzyMatch(Scr, "LB2FIYER")) {
					sort = "{'"+sortField+"':-1}"; //SRM00042 Changes
				} else {
				sort = "{'"+sortField+"':1}";
				}
			} catch (Exception e) {
				sort = "{'_id':-1}";
			}
			String Coll_Name = isonMapJson.get("COLLNAME").getAsString();

			projection.addProperty("_id", 0); 
			if(I$utils.$iStrFuzzyMatch(Scr, "LABSSORT")) {
			filter.addProperty("Type", i$body.get("Type").getAsString());
			projection.addProperty("KeyId", 1);
			projection.addProperty("KeyDesc", 1);
			projection.addProperty("NsnSize", 1);
			} else if(I$utils.$iStrFuzzyMatch(Scr, "LB2FIYER")) { //#SRM00042 changes
				projection.addProperty("financialCycle", 1);
				projection.addProperty("financialStartDate", 1);
				projection.addProperty("financialEndDate", 1);
			}
			sortData = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, maxRow, filter, projection, skip, limit, sort);
			i$body.add("iRowData", sortData.get("i-body").getAsJsonArray());	
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOV DATA RETRIEVED SUCCESSFULLY");

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"FAILED WHILE FETCHING LOV DATA WITH " + e.getMessage());
		}
		return isonMsg;
	}
//#SRM000041 Changes end
	public ILOVDetController() {
		// Cons
	}
}
// #BVB00133 Ends
