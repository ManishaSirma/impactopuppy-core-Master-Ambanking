/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| May 5, 2019  | #00000001   | Initial writing
      |0.3.13      | Vijay 		| Jun 06, 2019 | #BVB00162   | Changing response type to Object
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICbsSettleInstr {
    private DBController db$Ctrl = new DBController();
    private Ioutils I$utils = new Ioutils();
    private Logger logger = LoggerFactory.getLogger(ICbsSettleInstr.class);


    //private String getMapValue(JsonArray JMapsArr,// #BVB00162
    private JsonObject getMapValue(JsonArray JMapsArr, 
        String sBranch,
        String sGrp,
        String sSGrp,
        String sAmb,
        String sCcycode,
        String sCustCat,
        String sTrn,
        String sMapType) {
        JsonObject JWrkObj = new JsonObject();
        try {
            /* The Priority is as below - CHW (X = Actual value)
             * --------------------------------------------------
             * BRN  |GRP  |SGRP  |AMB  |CCY  |CCAT  | TRN |
             * --------------------------------------------------
             *  X   | X   | X    | X   | X   | X    | CHW |
             *  X   | X   | X    | X   | X   | ALL  | CHW |	
             *  X   | X   | X    | X   | ALL | ALL  | CHW |	
             *  X   | X   | X    | ALL | ALL | ALL  | CHW |	
             *  X   | X   | ALL  | ALL | ALL | ALL  | CHW |	
             *  X   | ALL | ALL  | ALL | ALL | ALL  | CHW |	
             *  ALL | X   | X    | X   | X   | X    | CHW |
             *  ALL | X   | X    | X   | X   | ALL  | CHW |	
             *  ALL | X   | X    | X   | ALL | ALL  | CHW |	
             *  ALL | X   | X    | ALL | ALL | ALL  | CHW |	
             *  ALL | X   | ALL  | ALL | ALL | ALL  | CHW |	
             *  ALL | ALL | ALL  | ALL | ALL | ALL  | CHW |	
             *  ALL | ALL | ALL  | ALL | ALL | ALL  | CHW |	
             */


            // Loop 1 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), sBranch) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), sAmb) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), sCcycode) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), sCustCat) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                    //return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 2 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), sBranch) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), sAmb) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), sCcycode) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 3 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), sBranch) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), sAmb) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }


            // Loop 4 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), sBranch) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 5 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), sBranch) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 6 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), sBranch) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 7 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), sAmb) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), sCcycode) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), sCustCat) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 8 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), sAmb) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), sCcycode) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 9 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), sAmb) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }


            // Loop 10 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), sSGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 11 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), sGrp) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }

            // Loop 12 
            for (int i = 0; i < JMapsArr.size(); i++) {
                JWrkObj = JMapsArr.get(i).getAsJsonObject();
                if (
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("BranchID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("GroupID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("SubGroupID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("AmbID").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("ccyCode").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("custCat").getAsString(), "ALL") &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("trnCode").getAsString(), sTrn) &&
                    I$utils.$iStrFuzzyMatch(JWrkObj.get("mapType").getAsString(), sMapType)) {
                	//return JWrkObj.get("mapValue").getAsString();// #BVB00162
                	return JWrkObj;
                }
            }
            return null;
        } catch (Exception e) {
            logger.debug("getMapValue -->" + e.getMessage());
            return null;
        }
    }

    private JsonObject getJfilter(
        String sBranch,
        String sGrp,
        String sSGrp,
        String sAmb,
        String sCcycode,
        String sCustCat,
        String sTrn,
        String sMapType
    ) {
        try {
            JsonArray JBrnXArr = new JsonArray();
            JsonArray JBrnAllArr = new JsonArray();
            JsonArray JFinalArray = new JsonArray();
            JsonObject JWrkObj = new JsonObject();

            /* The Priority is as below - CHW (X = Actual value)
             * --------------------------------------------------
             * BRN  |GRP  |SGRP  |AMB  |CCY  |CCAT  | TRN |
             * --------------------------------------------------
             *  X   | X   | X    | X   | X   | X    | CHW |
             *  X   | X   | X    | X   | X   | ALL  | CHW |	
             *  X   | X   | X    | X   | ALL | ALL  | CHW |	
             *  X   | X   | X    | ALL | ALL | ALL  | CHW |	
             *  X   | X   | ALL  | ALL | ALL | ALL  | CHW |	
             *  X   | ALL | ALL  | ALL | ALL | ALL  | CHW |	
             *  ALL | X   | X    | X   | X   | X    | CHW |
             *  ALL | X   | X    | X   | X   | ALL  | CHW |	
             *  ALL | X   | X    | X   | ALL | ALL  | CHW |	
             *  ALL | X   | X    | ALL | ALL | ALL  | CHW |	
             *  ALL | X   | ALL  | ALL | ALL | ALL  | CHW |	
             *  ALL | ALL | ALL  | ALL | ALL | ALL  | CHW |	
             *  ALL | ALL | ALL  | ALL | ALL | ALL  | CHW |	
             */

            // Object 1 - X Type	
            JWrkObj.addProperty("BranchID", sBranch);
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", sAmb);
            JWrkObj.addProperty("ccyCode", sCcycode);
            JWrkObj.addProperty("custCat", sCustCat);
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnXArr.add(JWrkObj);

            // Object 2 - X Type
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", sBranch);
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", sAmb);
            JWrkObj.addProperty("ccyCode", sCcycode);
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnXArr.add(JWrkObj);

            // Object 3 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", sBranch);
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", sAmb);
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnXArr.add(JWrkObj);

            // Object 4 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", sBranch);
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", "ALL");
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnXArr.add(JWrkObj);

            // Object 5 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", sBranch);
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", "ALL");
            JWrkObj.addProperty("AmbID", "ALL");
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnXArr.add(JWrkObj);

            // Object 6 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", sBranch);
            JWrkObj.addProperty("GroupID", "ALL");
            JWrkObj.addProperty("SubGroupID", "ALL");
            JWrkObj.addProperty("AmbID", "ALL");
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnXArr.add(JWrkObj);


            // Object 7 - X Type
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", "ALL");
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", sAmb);
            JWrkObj.addProperty("ccyCode", sCcycode);
            JWrkObj.addProperty("custCat", sCustCat);
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnAllArr.add(JWrkObj);

            // Object 8 - X Type
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", "ALL");
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", sAmb);
            JWrkObj.addProperty("ccyCode", sCcycode);
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnAllArr.add(JWrkObj);

            // Object 9 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", "ALL");
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", sAmb);
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnAllArr.add(JWrkObj);

            // Object 10 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", "ALL");
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", sSGrp);
            JWrkObj.addProperty("AmbID", "ALL");
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnAllArr.add(JWrkObj);

            // Object 11 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", "ALL");
            JWrkObj.addProperty("GroupID", sGrp);
            JWrkObj.addProperty("SubGroupID", "ALL");
            JWrkObj.addProperty("AmbID", "ALL");
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnAllArr.add(JWrkObj);

            // Object 12 - X Type	
            JWrkObj = new JsonObject();
            JWrkObj.addProperty("BranchID", "ALL");
            JWrkObj.addProperty("GroupID", "ALL");
            JWrkObj.addProperty("SubGroupID", "ALL");
            JWrkObj.addProperty("AmbID", "ALL");
            JWrkObj.addProperty("ccyCode", "ALL");
            JWrkObj.addProperty("custCat", "ALL");
            JWrkObj.addProperty("trnCode", sTrn);
            JWrkObj.addProperty("mapType", sMapType);
            JBrnAllArr.add(JWrkObj);


            JWrkObj = new JsonObject();
            JWrkObj.add("$or", JBrnXArr);
            JFinalArray.add(JWrkObj);
            
            JWrkObj = new JsonObject();
            JWrkObj.add("$or", JBrnAllArr);
            JFinalArray.add(JWrkObj);

            JWrkObj = new JsonObject();
            JWrkObj.add("$or", JFinalArray);

            return JWrkObj;
        } catch (Exception e) {
            logger.debug("getJfilter -->" + e.getMessage());
            return null;
        }
    }

    public JsonObject getInstrMap(// #BVB00162
        String sBranch,
        String sGrp,
        String sSGrp,
        String sAmb,
        String sCcycode,
        String sCustCat,
        String sTrn,
        String sMapType
    ) {
        //String sMapValue = null;
    	JsonObject mapObject = new JsonObject();// #BVB00162
        JsonObject JFilter = new JsonObject();
        JsonObject JProject = new JsonObject();
        JsonArray JMapsArr = new JsonArray();
        try {
            if (I$utils.$iStrFuzzyMatch(sTrn, "ALL")) {
                logger.debug("Tran Code Cannot be Matched for ALL");
                return null;
            } else {

                JFilter = getJfilter(
                    sBranch,
                    sGrp,
                    sSGrp,
                    sAmb,
                    sCcycode,
                    sCustCat,
                    sTrn,
                    sMapType
                );
                JProject = new JsonObject();
                JProject.addProperty("_id", 1);
                JProject.addProperty("BranchID", 1);
                JProject.addProperty("GroupID", 1);
                JProject.addProperty("SubGroupID", 1);
                JProject.addProperty("AmbID", 1);
                JProject.addProperty("ccyCode", 1);
                JProject.addProperty("custCat", 1);
                JProject.addProperty("trnCode", 1);
                JProject.addProperty("mapType", 1);
                JProject.addProperty("mapValue", 1);
                JProject.addProperty("mapClass", 1);// #BVB00162

                JMapsArr = db$Ctrl.db$GetRows("ICOR_M_B2U_CBS_STTLE_INSTR", JFilter,JProject);

                mapObject = getMapValue(JMapsArr, sBranch,// #BVB00162
                    sGrp,
                    sSGrp,
                    sAmb,
                    sCcycode,
                    sCustCat,
                    sTrn,
                    sMapType);

                return mapObject;// #BVB00162
            }
        } catch (Exception e) {
            logger.debug("Failed to Get Settlement Instr " + e.getMessage());
            logger.debug("sBranch-->" + sBranch);
            logger.debug("sGrp-->" + sGrp);
            logger.debug("sSGrp-->" + sSGrp);
            logger.debug("sAmb-->" + sAmb);
            logger.debug("sCcycode-->" + sCcycode);
            logger.debug("sCustCat-->" + sCustCat);
            logger.debug("sTrn-->" + sTrn);
            logger.debug("sMapType-->" + sMapType);
            return null;
        }
    }
}