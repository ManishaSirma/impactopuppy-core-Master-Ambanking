/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins

package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.sirma.impacto.iapp.iconfig.PropLoader;
import net.sirma.impacto.iapp.iutils.Ioutils;

import org.apache.commons.codec.binary.Base64;
/**
 * HealthCheck to verify if Resources are up
 */
@Controller
public class HealthCheckController {
	private Ioutils I$utils = new Ioutils();

	private static final Logger logger = LoggerFactory.getLogger(HealthCheckController.class);

	@SuppressWarnings("resource")
	@RequestMapping(value = { "", "/health", }, method = RequestMethod.GET,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> home(Locale locale) {
		logger.info("Welcome home. The client locale is " + locale.toString());
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(new Date());
        String encodedBase64 = null;
        try {
        	ClassLoader classLoader = getClass().getClassLoader();
    		File originalFile = new File(classLoader.getResource("PuppyServerRunning2.gif").getFile());
    		FileInputStream fileInputStreamReader = new FileInputStream(originalFile);
            byte[] bytes = new byte[(int)originalFile.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(Base64.encodeBase64(bytes));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		
        String bse64img = "url('data:image/jpeg;base64,"+encodedBase64+"')";
        String majorVer = I$utils.$strValNullIf(PropLoader.env.getProperty("MajorVersion"), "");
		String minorVer = I$utils.$strValNullIf(PropLoader.env.getProperty("MinorVersion"), "");
		String coreVersion = majorVer.concat(" " + minorVer);
		String releaseDate = I$utils.$strValNullIf(PropLoader.env.getProperty("releaseDate"), "");
		String strHTML = "<html>\r\n" + 
				"<style>\r\n" + 
				"body, html {\r\n" + 
				"    height: 100%;\r\n" + 
				"    margin: 0;\r\n" + 
				"    background-color: lightblue;\r\n" +
				"}\r\n" + 
				"\r\n" + 
				".bgimg404 {\r\n" + 
				"    background-image: "+bse64img+";\r\n" + 
				"    height: 100% !important;\r\n" + 
				"    width:100% !important;\r\n" + 
				"    background-position: center;\r\n" + 
				"    background-size: cover;\r\n" + 
				"    position: fixed;\r\n" + 
				"    top:30px !important;\r\n" + 
				"    left:0px !important;\r\n" + 
				"    font-size: 50px;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				".topleft404 {\r\n" + 
				"    position: absolute;\r\n" + 
				"    top: 0;\r\n" + 
				"    left: 16px;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				".bottomleft404 {\r\n" + 
				"    position: absolute;\r\n" + 
				"    bottom: 0;\r\n" + 
				"    left: 16px;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				".middle404 {\r\n" + 
				"    position: absolute;\r\n" + 
				"    top: 50%;\r\n" + 
				"    left: 50%;\r\n" + 
				"    transform: translate(-50%, -50%);\r\n" + 
				"    text-align: center;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"hr404 {\r\n" + 
				"    margin: auto;\r\n" + 
				"    width: 40%;\r\n" + 
				"}\r\n" + 
				"</style>\r\n" + 
				"<body>\r\n" + 
				"<div class=\"bgimg404\">\r\n" + 
				"  <div class=\"topleft404\">\r\n" + 
				"    <p></p>\r\n" + 
				"  </div>\r\n" + 
				"  <div class=\"middle404\">\r\n" + 
				//"    <h3><font color=\"white\">Hurray!!! Bow Bow ::::</font></h3>\r\n" + 
				"    <h3>IMPACTO Core Server is Up and Running</font></h5>\r\n" +
				"    <p></p>\r\n" + 
				"    <h5>Release Date Time :"+releaseDate+"</font></h5>\r\n" + 
				"    <h5>Core Version :"+coreVersion+"</font></h5>\r\n" + 
				"    <p id=\"demo\" style=\"font-size:25px\"></p>\r\n" + 
				"  </div>\r\n" + 
				"  <div class=\"bottomleft\">\r\n" + 
				"    <p></p>\r\n" + 
				"  </div>\r\n" + 
				"</div>\r\n" + 
				"</body>\r\n" + 
				"</html>";
		return new ResponseEntity<String>(strHTML, HttpStatus.OK);
		
	}

}
//#00000001 Ends