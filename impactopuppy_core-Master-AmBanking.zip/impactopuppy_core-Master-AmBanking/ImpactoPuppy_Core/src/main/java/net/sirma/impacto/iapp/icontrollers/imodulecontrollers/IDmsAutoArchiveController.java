/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ---------------------------------------------------------------------------------------------- 
      |0.4 Beta    | Tarun      | Jul 29, 2021 | #TKS00006   | Added code for archive and unarchive folders.
      |0.4 Beta    | Pruthvi    | Jul 29, 2021 | #YPR00103   | Added code for Summary and Query operation changes
      |0.4 Beta    | Tarun      | Aug 3,  2021 | #TKS00007   | Added code for delete archive folders
      |0.4 Beta    | Sindhu     | Nov 25, 2022 | #SRM0011    | Handled code for unarchiving folder
      |0.4 Beta    | Madhura    | Dec 05, 2022 | #MSA00001   | Handled code for Only archive user can Un-Archive the folder
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder; // #MAQ00020 
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
//import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.iEmailService;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IDmsAutoArchiveController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IWorkspacesController.class);
//	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
//	private IgenericWorker igenericWorker = new IgenericWorker();
	private JsonObject i$Annotate = null;
//	private ISeqConsistencyController i$seqConsCtrl = new ISeqConsistencyController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		i$body = isonMsg.getAsJsonObject("i-body");
		String Coll_Name, L_Coll_Name;
		// JsonObject i$Annotate = null;

//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonObject projection = new JsonObject();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();

		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
		
//		projection.addProperty("privateKey", 1);
//		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
//		String privateKey = cParam.get("privateKey").getAsString();
//		
		try {
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;
			// #NYE00014 Rebuild IMatch if "dataSetFltr" Key is Present and Operation is Summary
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY"))
			{
				
				JsonObject j$DataFilter = get$FrmDataSetFilter(isonMsg);
				if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr")))
				{

					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,j$DataFilter.get("Invalid$Expr").getAsString() );
					return isonMsg;
				}
				// #NYE00015 Begin
				else if (j$DataFilter != null)
				{
					// Get Formated I-MATCH Dataset Filter
					i$Match = j$DataFilter;
				}
				// #NYE00015 End
			}
			
			try {
				if (hasRights) {
					

					if (i$Match == null) {
						JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
						i$Match = new JsonObject();
						try {
							// if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
							if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
									&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") // #MAQ00001
							)) {

								for (int i = 0; i < i$MatchMap.size(); i++) {
									// #BVB00183 Starts 
									 JsonElement matchElm = i$ResM.getBodyElement(isonMsg,i$MatchMap.get(i).getAsString());
									 if(!I$utils.$isNull(matchElm) ) { // #BVB00188 
									 if(matchElm.isJsonPrimitive()) {
										 i$Match.addProperty(i$MatchMap.get(i).getAsString(),
											i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
									 }else if(matchElm.isJsonArray()) { 
										 JsonArray matchArr = matchElm.getAsJsonArray();
										 String iMatchStr = "{'$in': ['"; 
										 for(int j =0; j< matchArr.size(); j++) {
											 if(j<matchArr.size()-1)
											 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"','"; 
											 else {
												 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"']}";
											 }
										 }
										 
										 i$Match.add(i$MatchMap.get(i).getAsString(), parser.parse(iMatchStr).getAsJsonObject()); 
										 
									 }
									 // #BVB00183 Ends
									 // #BVB00188 Starts 
									 }else {
										 isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
											return isonMsg;
									 }
									 // #BVB00188 Ends
								}
								;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
							} else {
								i$Match = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
							}
						} catch (Exception e) {
							logger.error("Error description : ", e);
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}"); // #MAQ00001
						}
						;

					}
					;

					// #BVB00005 Ends
					// #BVB00016 Starts
					if (i$ProjectionArray != null) {
						for (int i = 0; i < i$ProjectionArray.size(); i++) {
							i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
						}
					} else {

						JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
						if (i$ProjectionMap != null) {// #BVB00033
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
									for (int i = 0; i < i$ProjectionMap.size(); i++) {
										i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
									}
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
								} else {
									i$Projection = null;
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
								}
							} catch (Exception e) {
								e.printStackTrace();
								i$Projection = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
							}
							;
							// #BVB00033 Starts
						} else {
							i$Projection = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
						}
						// #BVB00033 Ends
						// i$Projection = new JsonObject();
					}
					// #BVB00016 Ends

					// #BVB00035 Starts
					projection = new JsonObject();
					projection.addProperty("privateKey", 1);
					JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
					String privateKey = cParam.get("privateKey").getAsString();
					JsonObject sfilter = new JsonObject();
					sfilter.addProperty("sessoinId", i$ResM.getClientSessionID(isonMsg));
					JsonObject sessionValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", gson.toJson(sfilter),
							gson.toJson(projection));

					// #BVB00035 Ends

					Integer i$MaxRow = -1;
					// #BVB00005 Starts
					JsonObject i$recordDetails = new JsonObject();
					JsonObject i$validateRes = new JsonObject();
					JsonObject i$ledgerCurVer = new JsonObject();
					// #BVB00005 Ends
					try {
						i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
					} catch (Exception e) {
						try {
							i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
						} catch (Exception ex) {
							i$MaxRow = -1;
						}
						;
					}
					;

					try {
						Coll_Name = isonMapJson.get("COLLNAME").getAsString();
					} catch (Exception e) {
						Coll_Name = null;
					}
					;

					if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
							|| (I$utils.$iStrBlank(gson.toJson(i$Match)))) { // #MAQ00003
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
						return isonMsg;
					}
					;

					try {
						L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
					} catch (Exception e) {
						L_Coll_Name = null;
					}
					;

					if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
						return isonMsg;
					}
					;

					try {
						// String ScrID = i$ResM.getScreenID(isonMsg); // #BVB00035
						String SOpr1 = i$ResM.getOpr1(isonMsg);
						String SOpr2 = i$ResM.getOpr2(isonMsg);
						String SOpr3 = i$ResM.getOpr3(isonMsg);
						// #MAQ00002 start
						try {
							i$body = isonMsg.getAsJsonObject("i-body");
						} catch (Exception e) {
							i$body = null;
						}
						// #MAQ00002 end
					
					
					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}"); // #BVB00035 changes ScrID to ScrId
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) { // #YPR00103 changes
							// Forwarding Request to DB Handler for SUMMARY
							logger.debug("Forwarding Request to DB Controller for Summary");
							// #MAQ00002 start
							isonMsg.add("i-body", i$body);
							int intPgNo, intRecs;
							try {
								intPgNo = i$body.get("intPgNo").getAsInt();
							} catch (Exception e) {
								intPgNo = 0;
							}
							try {
								intRecs = i$body.get("intRecs").getAsInt();
							} catch (Exception e) {
								intRecs = 0;
							}
							// #MAQ00013 starts
							String sort = "";
							try {
								String sortField = i$body.get("sort").getAsString();
								sort = "{'"+sortField+"':1}";
							} catch (Exception e) {
								sort = "{'_id':-1}";
							}
							// #MAQ00013 starts

							// #MAQ00004 starts
							if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {

								// #MAQ00009 starts
								int iRowCnt = 0;
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
								try {
									if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
										if (i$Match != null) {
											i$Match.addProperty("isCurrVer", "Y");
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										}
										// Added
										// Projection
										else
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, "{\"isCurrVer\"=\"Y\"}"); // #BVB00016

									} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
											|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
										if (i$Match != null)
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
										// Added Projection
										else
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
										// #MAQ00002 end
									}
								} catch (Exception e) {
								}
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

								i$body.addProperty("iRowCnt", iRowCnt);
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
								return isonMsg;
								// #MAQ00009 ends
							// #MAQ00014 starts
							} else if(I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
								// #MAQ00009 starts
								int iRowCnt = 0;
								JsonObject db$res = null;
								JsonArray db$res1 = null;
								
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
								try {
									if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
										JsonArray accWsArr = db$Ctrl.db$getDMSAccessWS();   
										if (i$Match != null) {
											i$Match.addProperty("isCurrVer", "Y");
											i$Match.add("workspaceId",parser.parse("{'$in':" + accWsArr + "}").getAsJsonObject());
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
											 db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
													i$Projection, intPgNo, intRecs, sort);								
										}
										// Added
										// Projection
										else {
											i$Match = new JsonObject();
											i$Match.addProperty("isCurrVer", "Y");
											i$Match.add("workspaceId",parser.parse("{'$in':" + accWsArr + "}").getAsJsonObject());
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
											db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
													i$Projection, intPgNo, intRecs, sort);// #BVB00016 Added//Projection
																							 
//											JsonArray Projec = new JsonArray();
//										     db$res1 = db$Ctrl.db$IDoczScopeAccess(L_Coll_Name,Projec); // //#TKS00001 
											
										}
									}  else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
										if (i$Match != null) {
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
											db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
													intPgNo, intRecs, sort);
										// Added Projection
											
										}
										else {
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
											db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
													i$Projection, intPgNo, intRecs, sort);
											
										}
										// #MAQ00002 end
									}
								} catch (Exception e) {
								}
								
								i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
								i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());	
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

								i$body.addProperty("iRowCnt", iRowCnt);
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
								return isonMsg;
								// #MAQ00009 ends
								
							}
							// #MAQ00014 ends
							// #MAQ00004 ends
							else {
								// #MAQ00005 code starts
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort)); // #BVB00016
									}

									else {
										i$Match = new JsonObject();
										i$Match.addProperty("isCurrVer", "Y");
										return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort));// #BVB00016 Added
																						// Projection
									}
								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null)
										return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
												intPgNo, intRecs, sort));// #BVB00016
																			// Added
																			// Projection
									else
										return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
												i$Projection, intPgNo, intRecs, sort));// #BVB00016

									// #MAQ00005 code ends
								} else {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
									return isonMsg;
								}
							}
						     }else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
							return isonMsg;
						}
						;
						
						I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrId, SOpr); // #BVB00035
						if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
							//#TKS00001 starts
							if (I$utils.$iStrFuzzyMatch(ScrId, "ODSAARFL") && I$utils.$iStrFuzzyMatch(SOpr, "ARCHIVE")) {
								try {
									i$body = isonMsg.getAsJsonObject("i-body");
									String archiveFolderId = i$body.get("folderId").getAsString();
									JsonObject fldrData = new JsonObject();
									JsonObject fldrFilter = new JsonObject();
									fldrFilter.addProperty("folderId", archiveFolderId);
									fldrFilter.addProperty("isCurrVer", "Y");
									JsonObject jFilter = new JsonObject();
									JsonObject proj = new JsonObject();
//									JsonObject fldrFilter = new JsonObject();
//									fldrFilter.addProperty("folderId" , folderId);
//									fldrFilter.addProperty("isCurrVer", "Y");
//									fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS" , fldrFilter);
//									if(!I$utils.$iStrFuzzyMatch(fldrData.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
//										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Only initiator can Archive the record");
//										 return isonMsg;
//									}
									fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS" , fldrFilter);
									String folderId = fldrData.get("folderIdPath").getAsString().split("/")[1];
									String workspaceId = fldrData.get("workspaceId").getAsString();
									//String archiveFolderId = i$body.get("folderId").getAsString();
									String flPath = "";
									JsonArray arrFilter = new JsonArray();
									JsonObject sbFldUpdate = new JsonObject();
									JsonObject queryFilter = new JsonObject();
									queryFilter.addProperty("workspaceId", workspaceId);
									queryFilter.addProperty("isCurrVer", "Y");
									JsonObject m$x = new JsonObject();
									JsonObject filter = new JsonObject();
									JsonArray fldrArr = new JsonArray();
									JsonObject fldData = new JsonObject();
									jFilter.addProperty("folderId", i$body.get("folderId").getAsString());
									jFilter.addProperty("parentFolderId", fldrData.get("parentFolderId").getAsString());
									jFilter.addProperty("Archive", "N");
									jFilter.addProperty("isCurrVer", "Y");
									proj.addProperty("folderId", 1);
									proj.addProperty("parentFolderId", 1);
									proj.addProperty("folderLevel", 1);
									proj.addProperty("workspaceId", 1);
							         fldData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS" , jFilter , proj);
							        String i$Doc = "{'folders.$[i].folders.$[j].folders.$[k].Archive': 'Y'}";
									String arrayFilters = "[{'i.folderId':'" + folderId + "'} , {'j.folderId':'" + fldrData.get("parentFolderId").getAsString() + "'} , {'k.folderId':'" + archiveFolderId + "'}]";
							        db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryFilter, "false", "N", arrayFilters);
									filter.addProperty("folderId", archiveFolderId);
									filter.addProperty("workspaceId", workspaceId);
									filter.addProperty("parentFolderId", fldrData.get("parentFolderId").getAsString());
									filter.addProperty("folderLevel", fldrData.get("folderLevel").getAsInt());
									filter.addProperty("isCurrVer", "Y");
									JsonObject folderData = new JsonObject();
									//String subFldrFilter = "{'$and':[{'folderIdPath':{'$regex':'"+workspaceId+"','$options':'i'}},{'folderIdPath':{'$regex':'"+folderId+"','$options':'i'}}]}";
									JsonObject subFldrUpdate = new JsonObject();
									subFldrUpdate.addProperty("isCurrVer", "N");
									subFldrUpdate.addProperty("Archive", "Y");
									subFldrUpdate.addProperty("errorMsg", "Records Successfully Archived");
									subFldrUpdate.addProperty("operation", "ARCHIVE");
									db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS" , gson.toJson(subFldrUpdate) , filter);
									//fldrArr = db$Ctrl.db$GetRows("ICOR_M_DMS_FOLDERS", subFldrFilter);
									filter.addProperty("isCurrVer" , "N");
									folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filter);
									folderData.remove("_id");
									folderData.addProperty("isCurrVer", "Y");
									folderData.addProperty("archivedBy", IResManipulator.iloggedUser.get());
									folderData.add("archivedOn" , i$ResM.adddate(new Date()));
									JsonObject fsUpdate = new JsonObject();
									JsonObject fsFilter = new JsonObject();
									JsonObject fs1 = new JsonObject();
									int iRowCnt = 0;
									//String subFldrFilter = "{'$and':[{'metadata.folderIdPath':{'$regex':'"+workspaceId+"','$options':'i'}},{'metadata.folderIdPath':{'$regex':'"+archiveFolderId+"','$options':'i'}}]}";
									String subFldrFilter = "{'metadata.parentFolderId':'"+archiveFolderId+"' , 'metadata.workspaceId':'"+workspaceId+"'}";
									fsUpdate.addProperty("metadata.isCurrVer" , "N");
									fsUpdate.addProperty("metadata.Archive", "Y");
									fs1 = db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , subFldrFilter);
									i$Match.addProperty("folderId", archiveFolderId);
									iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));
									if(iRowCnt == 0) {   // #SRM0011 changes
									db$Ctrl.db$InsertRow("ICOR_M_DMS_ARCHIVES" , gson.toJson(folderData));
									} else {
										JsonObject fltr = new JsonObject();
										fltr.addProperty("isCurrVer", "N");
										fltr.addProperty("folderId", archiveFolderId);
										fltr.addProperty("workspaceId", workspaceId);
										subFldrUpdate.addProperty("Archive", "Y");
										subFldrUpdate.addProperty("isCurrVer", "Y");
										subFldrUpdate.addProperty("errorMsg", "Records Successfully Archived");
										subFldrUpdate.addProperty("operation", "ARCHIVE");
										db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES",subFldrUpdate , fltr); //#SRM0011 changes
									}
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Folder Successfully Archived");
									db$Ctrl.db$logDmsHstry(isonMsg);
									return isonMsg;

								} catch (Exception excep) {
					                  isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Folder Is Not Archived");
					                  excep.printStackTrace();
					                  return isonMsg;
					                }
							}

							if (I$utils.$iStrFuzzyMatch(ScrId, "ODSAARFL") && I$utils.$iStrFuzzyMatch(SOpr, "UNARCHIVE")) {
								try {
									i$body = isonMsg.getAsJsonObject("i-body");
									String archiveFolderId = i$body.get("folderId").getAsString();
									JsonObject fldrFilter = new JsonObject();
									fldrFilter.addProperty("folderId", archiveFolderId);
									fldrFilter.addProperty("isCurrVer", "N");
									JsonObject fldrData = new JsonObject();
									fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS" , fldrFilter);
									String folderId = fldrData.get("folderIdPath").getAsString().split("/")[1];
									String workspaceId = fldrData.get("workspaceId").getAsString();
									//String archiveFolderId = i$body.get("archiveFolder").getAsString();
									JsonObject m$x = new JsonObject();
									JsonObject fltr = new JsonObject();
									fltr.addProperty("folderId", archiveFolderId);
									JsonObject filter = new JsonObject();
									//filter.addProperty("folderId", i$body.get("folderId").getAsString());
									filter.addProperty("workspaceId", fldrData.get("workspaceId").getAsString());
									//filter.addProperty("folderLevel", i$body.get("folderLevel").getAsInt());
									filter.addProperty("isCurrVer", "Y");
									JsonObject archFldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_ARCHIVES" ,fltr);
									
									//MSA00001 changes
									if(I$utils.$iStrFuzzyMatch(archFldrData.get("archivedBy").getAsString(), IResManipulator.iloggedUser.get())) 
									{
										JsonObject folderData = new JsonObject();
										JsonObject workspaceFilter = new JsonObject();
										JsonObject subFldrFilter = new JsonObject();
										JsonObject filArr = new JsonObject();
										JsonObject folderObject = new JsonObject();
								        String i$Doc = "{'folders.$[i].folders.$[j].folders.$[k].Archive': 'N'}";
										String arrayFilters = "[{'i.folderId':'" + folderId + "'} , {'j.folderId':'" + fldrData.get("parentFolderId").getAsString() + "'} , {'k.folderId':'" + archiveFolderId + "'}]";
										db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, filter, "false", "N", arrayFilters);
	//									workspaceFilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
	//									workspaceFilter.addProperty("isCurrVer", "Y");
										subFldrFilter.addProperty("folderId", archiveFolderId);
										subFldrFilter.addProperty("workspaceId", workspaceId);
										subFldrFilter.addProperty("isCurrVer", "N");
										JsonObject subFldrUpdate = new JsonObject();
										subFldrUpdate.addProperty("isCurrVer", "Y");
										subFldrUpdate.addProperty("Archive", "N");
										subFldrUpdate.addProperty("errorMsg", "Records Successfully UnArchived");
										subFldrUpdate.addProperty("operation", "UNARCHIVE");
										folderObject = db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS" , gson.toJson(subFldrUpdate) , subFldrFilter);
										subFldrUpdate.addProperty("isCurrVer", "N"); //#SRM0011 changes
	//									subFldrFilter.remove("isCurrVer");
										subFldrFilter.addProperty("isCurrVer", "Y");
										filArr = db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES" , gson.toJson(subFldrUpdate) , subFldrFilter);
										JsonObject fsUpdate = new JsonObject();
										JsonObject fsFilter = new JsonObject();
										fsFilter.addProperty("metadata.parentFolderId", archiveFolderId);
										fsFilter.addProperty("metadata.workspaceId", workspaceId);
										fsUpdate.addProperty("metadata.isCurrVer" , "Y");
										fsUpdate.addProperty("metadata.Archive", "N");
										db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , fsFilter);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Folder Successfully UnArchived");
										db$Ctrl.db$logDmsHstry(isonMsg);
									}
									else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only Archived User can UnArchive the Folder");
									}//MSA00001 changes
								} catch (Exception e) {
									e.printStackTrace();
								}
								return isonMsg;
							}
							if (I$utils.$iStrFuzzyMatch(ScrId, "ODSARRFL") && I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {//#TKS00007 starts
								i$body = isonMsg.getAsJsonObject("i-body");
								String folderId = i$body.get("folderId").getAsString();
								JsonObject fldrData = new JsonObject();
								JsonObject fldrFilter = new JsonObject();
								fldrFilter.addProperty("folderId" , folderId);
								fldrFilter.addProperty("isCurrVer", "Y");
								fldrFilter.addProperty("Archive", "Y");
								fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_ARCHIVES" , fldrFilter);
								if(!I$utils.$iStrFuzzyMatch(fldrData.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Only initiator can Delete the record");
									 return isonMsg;
								}
								String workspaceId = i$body.get("workspaceId").getAsString();
								JsonObject updateObj = new JsonObject();
								updateObj.addProperty("isCurrVer", "N");
								updateObj.addProperty("operation", "DELETE");
								updateObj.addProperty("errorMsg", "Records Successfully Deleted");
								db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES" , updateObj , fldrFilter);
								String subFldrFilter = "{'$and':[{'folderIdPath':{'$regex':'"+workspaceId+"','$options':'i'}},{'folderIdPath':{'$regex':'"+folderId+"','$options':'i'}}]}";
								JsonObject subFldrUpdate = new JsonObject();
								subFldrUpdate.addProperty("isCurrVer", "N");
								subFldrUpdate.addProperty("errorMsg", "Records Successfully Deleted");
								subFldrUpdate.addProperty("operation", "DELETE");
								db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS" , gson.toJson(subFldrUpdate) , subFldrFilter);
								subFldrFilter = "{'$and':[{'metadata.folderIdPath':{'$regex':'"+workspaceId+"','$options':'i'}},{'metadata.folderIdPath':{'$regex':'"+folderId+"','$options':'i'}}]}";
								JsonObject fsUpdate = new JsonObject();
								fsUpdate.addProperty("metadata.isCurrVer" , "N");
								db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , subFldrFilter);
					            JsonObject queryfilter = new JsonObject();
					            queryfilter.addProperty("workspaceId", workspaceId);
					            queryfilter.addProperty("isCurrVer","Y");
					            String flpath ;
					            String arrFilter;
					            String i$Doc;
								int level = i$body.get("folderLevel").getAsInt();
								if (level >= 2) {
						             flpath = "folders.$[].".repeat(level - 2) + "folders.$[j].folders";
						             arrFilter = "[{'j.folderId': '"+i$body.get("parentFolderId").getAsString()+"'}]";
						            }else {
						            	queryfilter.addProperty("folders.folderId", i$body.get("parentFolderId").getAsString());
						            	flpath = "folders.$.folders";
						            	arrFilter = "";
						            }

						             i$Doc = "{'"+flpath+"':{'folderId':'"+folderId+"'}}"; 
						            if(!I$utils.$iStrBlank(arrFilter)) {
						                db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "pull", arrFilter);
						            }else {
						                db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "pull");
						            }
						            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Folder Successfully Deleted");
									db$Ctrl.db$logDmsHstry(isonMsg);
									return isonMsg;
							}//#TKS00007 ends

						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
							return isonMsg;
						}
					} catch (Exception e) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
								e.getMessage().toString());
						e.printStackTrace();
						return isonMsg;
					}
				} else {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
					return isonMsg;
				}
			} catch (Exception excep) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
						excep.getMessage().toString());
				excep.printStackTrace();
				return isonMsg;
			}
		}

		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
	

	  // #YPR00094 Ends

	// #BVB00033 Starts
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		// JsonObject argJson = new JsonObject();

		try {
			IDmsAutoArchiveController i$genAppCon = new IDmsAutoArchiveController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			isonMsg = i$genAppCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			// Adding Pre Response Message Handler

			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}
	
	// #NYE00014 Begins
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg) {
		try {
			return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));

		} catch (Exception e) {
			logger.debug(" Error in get$FrmDataSetFilter -" + e.getMessage());
			return null;
		}
	}

	// #NYE00014 Ends

	// #BVB00033 Ends
	public IDmsAutoArchiveController() {
		// Cons
	}
}
// #00000001 Ends