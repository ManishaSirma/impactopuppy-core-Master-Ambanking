/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Jan 7, 2019  | #BVB00032   | Initial writing
      |0.2.2	   | bhuvi      | Jan 15,2019  | #BVB00033   | send email and message at the time of auth
      |0.2.1	   | Vijay      | Mar 28,2019  | #BVB00104   | Load CBS_E_DATA at the time of AUtho for Job Type
      |0.2.1	   | Vijay      | Apr 05,2019  | #BVB00111   | Branch data with user access restrictions
      |0.3.1.320   | BHUVI      | Jul 22,2019  | #BHUVI001   | Changes for Load CBS_E_DATA.
	  |0.4.1.371   | MAQ        | Aug 30,2019  | #MAQ000031  | ICP Type Record creation in CBS_E_DATA
	  |0.4.1.381   | MAQ        | Sep 05,2019  | #MAQ000032  | Added Email and SMS checker screen
	  |3.1.0.406   | Syed       | Oct 29, 2019 | #MAQ00049   | Generate Dummy values for PartnerScreen
	  |3.1.0.406   | Pappu      | May 18, 2022 | #PKY00071   | Handled check issuance and letter Request services
	  |3.1.0.406   | Pavithra   | Jul 25, 2023 | #PAV0005    | Handled Summary excel sheet generation
	  |3.1.0.406   | Pavithra   | Jul 25, 2023 | #PAV0006    | Summary data with export filter SKG00017
	  |3.1.0.406   | Sumit      | Aug 02, 2023 | #SKG00017   | Added code for preview the documents history reflecting multiple times 
	  |3.1.0.406   | Sumit      | Aug 09, 2023 | #SKG00020   |  Handled for delete folder of manual workspace is not reflecting in trash module 
	  |3.1.0.406   | Sumit      | Aug 11, 2023 | #SKG00021   | Handled for delete folder of manual workspace is not reflecting folder name & folder ID in trash module
	  |3.1.0.406   | Srikanth   | Sep 26, 2023 | #SRI00005   | Handled Summary CSV file generation
	  |3.1.0.406   | Srikanth   | Sep 26, 2023 | #SRI00008   | Added the filter for the Csv File 
	  |3.1.0.406   | Srikanth   | Nov 02, 2023 | #SRI00014   | handling the CifInfo part warning message to Error message
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
      
*/
// #BVB00032 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.io.ByteArrayOutputStream;
import java.io.StringWriter;
import java.util.Base64;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.opencsv.CSVWriter;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IfaceCompareController; // #MAQ000032
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IResPreFlightHandler {
	private Logger logger = LoggerFactory.getLogger(IResPreFlightHandler.class);
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	private IResManipulator i$ResM = new IResManipulator();
	private DBController db$Ctrl = new DBController();
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	private IEmailService i$Email = new IEmailService();
	private IDataValidator I$DataValidator = new IDataValidator();
	private ISmsService I$ISmsService = new ISmsService();
	private IWhatsupService I$WhatsupService = new IWhatsupService();

	JsonObject to$emailIds = new JsonObject();
	JsonObject $mobNum = new JsonObject();
	JsonObject $whatsappNumbers = new JsonObject();
	JsonObject to$emailIdsAlt = new JsonObject();
	JsonObject $mobNumAlt = new JsonObject();
	JsonObject whatsappNumbersAlt = new JsonObject();
	JsonObject commMode = new JsonObject();
	JsonObject JsonObjectEmailmode = new JsonObject();
	JsonObject cParam = new JsonObject();
	String countrycode;
	JsonObject $Doc = new JsonObject();

	public JsonObject processMsgHandler(JsonObject isonMsg) {

		try {

			String ScrId = i$ResM.getScreenID(isonMsg);
			String Opr3 = i$ResM.getOpr3(isonMsg);
			String SOpr = i$ResM.getOpr(isonMsg);
			String Srvcopr = i$ResM.getSrvcopr(isonMsg); // PKY00071 changes
			String SrvcName = i$ResM.getSrvcName(isonMsg); // PKY00071 changes
			i$ResM.getOpr1(isonMsg);
			i$ResM.getOpr2(isonMsg);
			i$ResM.getOpr3(isonMsg);
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String i$statMsg = i$ResM.getStatMsg(isonMsg);

			if (I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_SUCC)) {
				if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
					// #BVB00033 begins
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF") && I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {

						String StriKey;
						Gson gson = new Gson();
						JsonObject projection = new JsonObject();
						// JsonObject i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}",
						// "{\"issuerNo\"=1}");
						JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
						// JsonArray $Key= new JsonArray();
						JsonArray $Key = new JsonArray();
						JsonObject $mailKey = new JsonObject();
						JsonObject $phoneKey = new JsonObject();
						JsonObject $whatsAppKey = new JsonObject();

						JsonObjectEmailmode = cParam.get("iOtpCommMode").getAsJsonObject();
						countrycode = cParam.get("countryCode").getAsString();

						/*
						 * JsonObject $idKey= new JsonObject(); JsonObject $tokenKey= new JsonObject();
						 */
						if (i$body.has("WhtsAppNum") && i$body.has("IsdWhtsAppNum")) {
							$whatsappNumbers.addProperty("Whatsapp_Numbers1", i$body.get("IsdWhtsAppNum").getAsString()
									.concat(i$body.get("WhtsAppNum").getAsString()));

						} else {
							if (i$body.has("MobNum") && i$body.has("IsdMobNum")) {
								$whatsappNumbers.addProperty("Whatsapp_Numbers1", i$body.get("IsdMobNum").getAsString()
										.concat(i$body.get("MobNum").getAsString()));
							}
						}
						if (i$body.has("WhtsAppNumAlt") && i$body.has("IsdWhtsAppNumAlt")) {
							whatsappNumbersAlt.addProperty("Whatsapp_NumbersAlt1", i$body.get("IsdWhtsAppNumAlt")
									.getAsString().concat(i$body.get("WhtsAppNumAlt").getAsString()));
						}
						if (i$body.has("AlterEmpMail")) {
							to$emailIdsAlt.addProperty("EmailIdsAlt1", i$body.get("AlterEmpMail").getAsString());
						}
						if (i$body.has("AlterMobNum") && i$body.has("IsdAlterMobNum")) {
							$mobNumAlt.addProperty("Mob_NumbersAlt1", i$body.get("IsdAlterMobNum").getAsString()
									.concat(i$body.get("AlterMobNum").getAsString()));
						}
						if (i$body.has("EmpMail")) {
							to$emailIds.addProperty("toemailid1", i$body.get("EmpMail").getAsString());
						}
						if (i$body.has("MobNum") && i$body.has("IsdMobNum")) {
							$mobNum.addProperty("Mob_Number1",
									i$body.get("IsdMobNum").getAsString().concat(i$body.get("MobNum").getAsString()));
						}

						JsonObject Keyqueryfilter = new JsonObject();
						Keyqueryfilter.addProperty("Key_Mode", "UTK");
						Keyqueryfilter.addProperty("Key_Owner", i$body.get("userId").getAsString());

						JsonObject i$ParamKey = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", Keyqueryfilter);
						if (i$ParamKey == null) {
							String StrIssuer = cParam.get("issuerNo").getAsString();
							String StrSeqno = db$Ctrl.db$GetSeqFor("SEQ#IDTKN");
							String StrRandom = I$impactoUtil.generateRandomString(4);

							StriKey = StrIssuer + StrSeqno + StrRandom;
						} else {
							String isKeyAvilable = i$ParamKey.get("Key_Token").getAsString();
							StriKey = isKeyAvilable;
						}

						JsonObject queryfilter = new JsonObject();
						queryfilter.addProperty("userId", i$body.get("userId").getAsString());

						JsonObject i$found = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", queryfilter);

						generatekey(i$body, $Key, StriKey, isonMsg, $mailKey, $phoneKey, $whatsAppKey);
						if (!I$utils.$isNull(i$found)) {
							if (i$found.get("verNo").getAsInt() == 1) {
								processEmailNotification(i$body, $mailKey, StriKey, $Key, isonMsg);
								processSMSNotification(i$body, $phoneKey, StriKey, $Key, isonMsg);
								processWhtsappNotification(i$body, $whatsAppKey, StriKey, $Key, isonMsg);
							}
						}

						// return isonMsg = i$ResM.iHandleResStat(result, i$ResM.I_SUCC, "Email OTP Sent
						// Successfully ");
						// #BVB00033 ends
					}
					// #BVB00104 Starts
					else if (I$utils.$iStrFuzzyMatch(ScrId, "OB2UJOBR") && I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
						OASB2UJR_AUTH(isonMsg);
						// MAQ000031 starts
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "OB2UPRNT")) {
						OB2UPRNT_AUTH(isonMsg);
						// MAQ000031 ends
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "OB2DGUCS")) {//PAV Changes
						Gson gson = new Gson();
						JsonArray lremarksArr = new JsonArray();
						JsonObject lremarksObj = new JsonObject();
						JsonObject fObj1 = new JsonObject();
						JsonObject fObj2 = new JsonObject();
						JsonArray existingRemarks = new JsonArray();
						JsonArray existingRemarks1 = new JsonArray();
						JsonObject ftr1 = new JsonObject();
						ftr1.addProperty("key", i$body.get("key").getAsString());
						JsonObject res = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USER_STATUS_LEDGER", ftr1);
						if (i$body.has("remarks")) {
							lremarksObj.addProperty("User", res.get("authorizer").getAsString());
							lremarksObj.addProperty("Action", SOpr);
							lremarksObj.addProperty("Date", res.get("authorizedOnSrvDate").getAsString());
							lremarksObj.addProperty("Remarks", res.get("remarks").getAsString());
							lremarksArr.add(lremarksObj);
							existingRemarks1.add(lremarksObj);
							fObj1.add("WorkFlowRemarks", existingRemarks1);
							fObj1.add("WorkFlowLatestRemarks", lremarksArr);
							db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USER_STATUS", fObj1, ftr1);
							db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", fObj1, ftr1);
						}
						JsonObject existingRemarks2 = new JsonObject();
						existingRemarks = res.get("WorkFlowRemarks").getAsJsonArray();
						existingRemarks2.add("$each", existingRemarks);
						fObj2.add("WorkFlowRemarks", existingRemarks2);
						String i$CustomerIdDoc = gson.toJson(fObj2);
						db$Ctrl.db$UpdateRowOperator("ICOR_M_B2U_DIGI_USER_STATUS", i$CustomerIdDoc, ftr1, "true",
								"push");
						db$Ctrl.db$UpdateRowOperator("ICOR_M_B2U_DIGI_USERS", i$CustomerIdDoc, ftr1, "true",
								"push");
					}//PAV Changes ends
					// #BVB00104 Ends
				} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
					// #MAQ000032 starts
					if (I$utils.$iStrFuzzyMatch(ScrId, "OCKSMSCK")) {
						OCKSMSCK_CREATE(isonMsg);
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "OB2DGUCS")) {
						JsonObject ftr = new JsonObject();
						ftr.addProperty("key", i$body.get("key").getAsString());
						JsonObject res = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USER_STATUS_LEDGER", ftr);
						JsonArray remarksArr = new JsonArray();
						JsonObject remarksObj = new JsonObject();
						JsonObject fObj = new JsonObject();
						if (i$body.has("remarks")) {
							remarksObj.addProperty("User", res.get("initiator").getAsString());
							remarksObj.addProperty("Action", SOpr);
							remarksObj.addProperty("Date", res.get("initiatedOnSrvDate").getAsString());
							remarksObj.addProperty("Remarks", res.get("remarks").getAsString());
							remarksArr.add(remarksObj);
							fObj.add("WorkFlowRemarks", remarksArr);
							fObj.add("WorkFlowLatestRemarks", remarksArr);
							db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USER_STATUS_LEDGER", fObj, ftr);
							db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", fObj, ftr);
						}
					}

					else if (I$utils.$iStrFuzzyMatch(ScrId, "OCKEMLCK")) {
						OCKEMLCK_CREATE(isonMsg);
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "OCKFCECK")) {
						OCKFCECK_CREATE(isonMsg);
						// #MAQ00049 starts
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "OKYLCORG")) {
						OKYLCORG_CREATE(isonMsg);
						// #MAQ00049 ends
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD")
							&& I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "Y")) {
						foldrDocContainUpdt(isonMsg);// #YPR00091 Changes
						// createDmsHstRecs(isonMsg);// #TKS00014 Changes
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "FDMAPUPD")
							&& I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "N")) {
						updateContainDocs(isonMsg);// #YPR00091 Changes
						// createDmsHstRecs(isonMsg);// #TKS00014 Changes
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "FABFLUPD")) {
						autoFoldrDocContainUpdt(isonMsg);// #YPR00091 Changes
						// createDmsHstRecs(isonMsg);// #TKS00014 Changes
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRFL")) {
						ODSCRRFL_CREATE(isonMsg); // #YPR00088 Changes
						createDmsHstRecs(isonMsg);// #YPR00098 Changes
					}
					// #MAQ000032 ends
				} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
					// #BVB00111 Starts
					if (I$utils.$iStrFuzzyMatch(ScrId, "LABBDTRS")) {
//						isonMsg = LABBDTRS_QUERY(isonMsg);
						// #BVB00111 Ends
					}
					// PAV0006 starts
					else if (I$utils.$iStrFuzzyMatch(Opr3, "export") || (I$utils.$iStrFuzzyMatch(Opr3, "exportCsv"))) { // SRI00008
																														// changes
						isonMsg = exportSummaryData(isonMsg);
					}

					// PAV0006 ends
				} else if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
					if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRFL")) {
						ODSCRRFL_UPDATE(isonMsg); // #YPR00089 Changes
					}
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFAVRT")) {
						if (I$utils.$iStrFuzzyMatch(i$ResM.getOpr2(isonMsg), "UNFAVOURITE")) {
							isonMsg.get("i-body").getAsJsonObject().addProperty("errorMsg",
									"Successfully removed from favorites");
						} else {
							isonMsg.get("i-body").getAsJsonObject().addProperty("errorMsg",
									"Successfully added to favorites");
						}
					}
				} else if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
					if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRFL")) {
						ODSCRRFL_DELETE(isonMsg); // #YPR00090 Changes
					} else if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRDOC")) {
						foldrDocContainUpdt(isonMsg);// #YPR00091 Changes
					}

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {

				} else if ((I$utils.$iStrFuzzyMatch(Srvcopr, "LETTER_REQ")
						&& I$utils.$iStrFuzzyMatch(SrvcName, "REQUEST_FOR_LETTER_STMT"))
						|| I$utils.$iStrFuzzyMatch(Srvcopr, "CHEQUE_ISSUE")
								&& I$utils.$iStrFuzzyMatch(SrvcName, "CHEQUE_ISSUANCE_STMT")) { // PKY00071 changes
					chequeIssuance$LetterRequest(isonMsg);
				}


			} else if (I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_WRN)) {
				if (I$utils.$iStrFuzzyMatch(ScrId, "SABCIFID") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) { // SRI00014 Starts
					try {
						JsonObject fltr = new JsonObject();
						JsonObject projection = new JsonObject();
						JsonObject CustInfo = isonMsg.get("i-match").getAsJsonObject();
						fltr.addProperty("CustomerId", CustInfo.get("CustomerId").getAsString());
						projection.addProperty("CustomerDobDate", 1);
						JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr, projection);
						String CifDOB = cifData.get("CustomerDobDate").getAsString();
						String CusDOB = CustInfo.get("CustomerDobDate").getAsString();
						if (!I$utils.$iStrFuzzyMatch(CifDOB, CusDOB)) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID USERNAME OR DOB");
						}
					} catch (Exception e) {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID USERNAME OR DOB");
					} // SRI00014 Ends
				}
			} else if (I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_ERR)) {

			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());

		}

		return isonMsg;

	}

	// BVBCURR
	// Need to add code for removing the items from the object before sending out
	// the response

	public JsonObject $prepareResponse(JsonObject i$Annotate, JsonObject isonMsg) {

		// Calling Removing the Fields

		return isonMsg;

	};

	// BVBCURR

	public JsonObject processMsg(JsonObject i$Annotate, JsonObject isonMsg) {
		try {
			IResPreFlightHandler i$preRes = new IResPreFlightHandler();
			isonMsg = i$preRes.processMsgHandler(isonMsg);

			return isonMsg;

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}
		return isonMsg;
	}

	public IResPreFlightHandler() {
		// Constructor
	}

	// #BVB00033 begins
	public JsonObject processEmailNotification(JsonObject i$body, JsonObject $mailKey, String StriKey, JsonArray $Key,
			JsonObject isonMsg) {
		try {

			if (JsonObjectEmailmode.get("iSendMailOtp").getAsString().equalsIgnoreCase("Y")) {
				JsonObject argJsonPass = new JsonObject();
				JsonObject map$Data1 = new JsonObject();
				argJsonPass.add("toemailIds", to$emailIds);
				String getPass = IDataValidator.J$TempStorage.get().get("userPwd").getAsString();
				map$Data1.addProperty("FullName", i$body.get("name").getAsString());
				map$Data1.addProperty("password", getPass);
				map$Data1.addProperty("tmp$name", "TMPL#TT#AS#REGISTRATINSUCES");// #YPR00066 Changes
				argJsonPass.add("map$Data", map$Data1);
				i$Email.sendEmail(argJsonPass);

				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email OTP Sent Successfully ");
				///// end send password//
			}

			return isonMsg;
		} catch (Exception e) {
			{
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Email ");
			}
		}

	}

	public JsonObject processSMSNotification(JsonObject i$body, JsonObject $phoneKey, String StriKey, JsonArray $Key,
			JsonObject isonMsg) {
		try {
			//// send password in sms //

			if (JsonObjectEmailmode.get("iSendSmsOtp").getAsString().equalsIgnoreCase("Y")) {
				JsonObject argJsonPass = new JsonObject();
				JsonObject map$Data = new JsonObject();
				argJsonPass.add("mobile$numbers", $mobNum);
				String getPass = IDataValidator.J$TempStorage.get().get("userPwd").getAsString();
				map$Data.addProperty("FullName", i$body.get("name").getAsString());
				map$Data.addProperty("password", getPass);
				map$Data.addProperty("tmp$name", "TMPL#TT#AS#REGISTRATINSUCES"); // #YPR00066 Changes
				argJsonPass.add("map$Data", map$Data);
				I$ISmsService.sendSMS(argJsonPass);
				// I$WhatsupService.sendWhatsup(argJsonPass);

				/// end of send sms password///

			}

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Whtsapp Send Successfully ");

		} catch (Exception e) {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending SMS & Whtsapp ");
		}

	}

	public JsonObject processWhtsappNotification(JsonObject i$body, JsonObject $whatsAppKey, String StriKey,
			JsonArray $Key, JsonObject isonMsg) {
		try {
			IWhatsupService I$Whatsapp = new IWhatsupService();
			//// send whtsapp message password//
			if (JsonObjectEmailmode.get("iWhatsUpOtp").getAsString().equalsIgnoreCase("Y")) {

				JsonObject argJsonPass = new JsonObject();
				JsonObject map$Data = new JsonObject();
				argJsonPass.add("mobile$numbers", $whatsappNumbers);
				String getPass = IDataValidator.J$TempStorage.get().get("userPwd").getAsString();
				map$Data.addProperty("FullName", i$body.get("name").getAsString());
				map$Data.addProperty("password", getPass);// #YPR00066 Changes
				map$Data.addProperty("tmp$name", "TMPL#TT#AS#REGISTRATINSUCES"); // #YPR00066 Changes
				argJsonPass.add("map$Data", map$Data);
				I$Whatsapp.sendWhatsup(argJsonPass);

			} /// end of send password//

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Whtsapp Send Successfully ");

		} catch (Exception e) {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending SMS & Whtsapp ");
		}

	}

	public JsonObject generatekey(JsonObject i$body, JsonArray $Key, String StriKey, JsonObject isonMsg,
			JsonObject $mailKey, JsonObject $phoneKey, JsonObject $whatsAppKey) {
		try {
			JsonObject $idKey = new JsonObject();
			JsonObject $tokenKey = new JsonObject();

			if (i$body.has("userId")) {
				$idKey.addProperty("Key", i$body.get("userId").getAsString());
				$idKey.addProperty("Name", i$body.get("name").getAsString());
				$idKey.addProperty("Key_Mode", "UID");
				$idKey.add("EmailIds", to$emailIds);
				$idKey.add("Mob_Numbers", $mobNum);
				$idKey.add("Whatsapp_Numbers", $whatsappNumbers);
				$idKey.add("EmailIdsAlt", to$emailIdsAlt);
				$idKey.add("Mob_NumbersAlt", $mobNumAlt);
				$idKey.add("Whatsapp_NumbersAlt", whatsappNumbersAlt);
				$idKey.addProperty("Key_Owner", i$body.get("userId").getAsString());
				$idKey.addProperty("Key_Token", StriKey);
				$Key.add($idKey);
			}

			if (!StriKey.equals(null)) {
				$tokenKey.addProperty("Key", StriKey);
				$tokenKey.addProperty("Name", i$body.get("name").getAsString());
				$tokenKey.addProperty("Key_Mode", "UTK");
				$tokenKey.add("EmailIds", to$emailIds);
				$tokenKey.add("Mob_Numbers", $mobNum);
				$tokenKey.add("Whatsapp_Numbers", $whatsappNumbers);
				$tokenKey.add("EmailIdsAlt", to$emailIdsAlt);
				$tokenKey.add("Mob_NumbersAlt", $mobNumAlt);
				$tokenKey.add("Whatsapp_NumbersAlt", whatsappNumbersAlt);
				$tokenKey.addProperty("Key_Owner", i$body.get("userId").getAsString());
				$tokenKey.addProperty("Key_Token", StriKey);
				$Key.add($tokenKey);
			}

			if (i$body.has("WhtsAppNum") || i$body.has("MobNum")) {
				if (i$body.has("WhtsAppNum")) {
					$whatsAppKey.addProperty("Key",
							i$body.get("IsdWhtsAppNum").getAsString().concat(i$body.get("WhtsAppNum").getAsString()));
				} else {
					$whatsAppKey.addProperty("Key",
							i$body.get("IsdMobNum").getAsString().concat(i$body.get("MobNum").getAsString()));

				}
				$whatsAppKey.addProperty("Name", i$body.get("name").getAsString());
				$whatsAppKey.addProperty("Key_Mode", "UWA");
				$whatsAppKey.add("EmailIds", to$emailIds);
				$whatsAppKey.add("Mob_Numbers", $mobNum);
				$whatsAppKey.add("Whatsapp_Numbers", $whatsappNumbers);
				$whatsAppKey.add("EmailIdsAlt", to$emailIdsAlt);
				$whatsAppKey.add("Mob_NumbersAlt", $mobNumAlt);
				$whatsAppKey.add("Whatsapp_NumbersAlt", whatsappNumbersAlt);
				$whatsAppKey.addProperty("Key_Owner", i$body.get("userId").getAsString());
				$whatsAppKey.addProperty("Key_Token", StriKey);
				$Key.add($whatsAppKey);

			}

			if ((i$body.has("MobNum"))) {
				$phoneKey.addProperty("Key",
						i$body.get("IsdMobNum").getAsString().concat(i$body.get("MobNum").getAsString()));
				$phoneKey.addProperty("Name", i$body.get("name").getAsString());
				$phoneKey.addProperty("Key_Mode", "UMB");
				$phoneKey.add("EmailIds", to$emailIds);
				$phoneKey.add("Mob_Numbers", $mobNum);
				$phoneKey.add("Whatsapp_Numbers", $whatsappNumbers);
				$phoneKey.add("EmailIdsAlt", to$emailIdsAlt);
				$phoneKey.add("Mob_NumbersAlt", $mobNumAlt);
				$phoneKey.add("Whatsapp_NumbersAlt", whatsappNumbersAlt);
				$phoneKey.addProperty("Key_Owner", i$body.get("userId").getAsString());
				$phoneKey.addProperty("Key_Token", StriKey);
				$Key.add($phoneKey);

			}
			if (i$body.has("EmpMail")) {

				$mailKey.addProperty("Key", i$body.get("EmpMail").getAsString());
				$mailKey.addProperty("Name", i$body.get("name").getAsString());
				$mailKey.addProperty("Key_Mode", "UEM");
				$mailKey.add("EmailIds", to$emailIds);
				$mailKey.add("Mob_Numbers", $mobNum);
				$mailKey.add("Whatsapp_Numbers", $whatsappNumbers);
				$mailKey.add("EmailIdsAlt", to$emailIdsAlt);
				$mailKey.add("Mob_NumbersAlt", $mobNumAlt);
				$mailKey.add("Whatsapp_NumbersAlt", whatsappNumbersAlt);
				$mailKey.addProperty("Key_Owner", i$body.get("userId").getAsString());
				$mailKey.addProperty("Key_Token", StriKey);
				$Key.add($mailKey);
			}

			JsonObject filter = new JsonObject();
			filter.addProperty("userId", i$body.get("userId").getAsString());
			JsonObject i$ParamVer = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter);
			int getCurrVer = i$ParamVer.get("verNo").getAsInt();
			if (getCurrVer == 1) {
				db$Ctrl.db$InsertMany("ICOR_M_ECOMM_REPO", $Key);
			} else {

				JsonObject Filter = new JsonObject();
				Filter.addProperty("Key_Token", StriKey);

				$Doc.add("EmailIds", to$emailIds);
				$Doc.add("Mob_Numbers", $mobNum);
				$Doc.add("Whatsapp_Numbers", $whatsappNumbers);
				$Doc.add("EmailIdsAlt", to$emailIdsAlt);
				$Doc.add("Mob_NumbersAlt", $mobNumAlt);
				$Doc.add("Whatsapp_NumbersAlt", whatsappNumbersAlt);

				JsonObject UEM = new JsonObject();
				UEM.addProperty("Key_Mode", "UEM");
				UEM.addProperty("Key_Token", StriKey);
				JsonObject UEM1 = new JsonObject();
				UEM1.addProperty("Key", i$body.get("EmpMail").getAsString());

				JsonObject UMB = new JsonObject();
				UMB.addProperty("Key_Mode", "UMB");
				UMB.addProperty("Key_Token", StriKey);
				JsonObject UMB1 = new JsonObject();
				UMB1.addProperty("Key",
						i$body.get("IsdMobNum").getAsString().concat(i$body.get("MobNum").getAsString()));

				JsonObject UWA = new JsonObject();
				UWA.addProperty("Key_Mode", "UWA");
				UWA.addProperty("Key_Token", StriKey);

				JsonObject UWA1;
				if (i$body.has("WhtsAppNum")) {
					UWA1 = new JsonObject();
					UWA1.addProperty("Key",
							i$body.get("IsdWhtsAppNum").getAsString().concat(i$body.get("WhtsAppNum").getAsString()));
				} else {
					UWA1 = new JsonObject();
					UWA1.addProperty("Key",
							i$body.get("IsdMobNum").getAsString().concat(i$body.get("MobNum").getAsString()));

				}
				db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", $Doc, Filter, "true");
				db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", UEM1, UEM, "true");
				db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", UMB1, UMB, "true");
				db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", UWA1, UWA, "true");

			}

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Key genrerated Successfully");

		} catch (Exception e) {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Error in key genreration");
		}

	}

	// #BVB00033 ends

	// MAQ000031 starts

	public void OB2UPRNT_AUTH(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject i$Doc = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonArray fieldNames = new JsonArray();
			fieldNames.add("Printer_Type");
			fieldNames.add("Printer_Location");
			fieldNames.add("GCP_GRP");
			fieldNames.add("ICP_ID");
			String Coll_Name = "ICOR_M_CBS_E_DATA";
			filter.addProperty("KeyId", i$body.get("Printer_Id").getAsString());
			filter.addProperty("Type", "ICP");
			for (int i = 0; i < fieldNames.size(); i++) {
				String fieldName = fieldNames.get(i).getAsString();
				if (i$body.has(fieldName))
					i$Doc.addProperty(fieldName, i$body.get(fieldName).getAsString());
			}
			i$Doc.addProperty("KeyId", i$body.get("Printer_Id").getAsString());
			if (i$body.has("Printer_Desc"))
				i$Doc.addProperty("KeyDesc", i$body.get("Printer_Desc").getAsString());
			i$Doc.addProperty("Type", "ICP");
			if (i$body.has("active") && I$utils.$iStrFuzzyMatch(i$body.get("active").getAsString(), "A")) {
				i$Doc.addProperty("ImpactoAllowed", "Y");
			} else {
				i$Doc.addProperty("ImpactoAllowed", "N");
			}
			db$Ctrl.db$UpdateRow(Coll_Name, i$Doc, filter, "true");
		} catch (Exception e) {
			logger.debug("Failed in Record Creation of ICP Type: " + e.getMessage());
		}
	}
	// MAQ000031 ends

	// #MAQ000032 starts
	public void OCKFCECK_CREATE(JsonObject isonMsg) {
		try {
			IfaceCompareController face$Compare = new IfaceCompareController();
			if (isonMsg.getAsJsonObject("i-body").getAsJsonObject().has("errorMsg")) {
				isonMsg.getAsJsonObject("i-body").getAsJsonObject().remove("errorMsg");
			}
			face$Compare.Compare$Face(isonMsg);
			isonMsg.getAsJsonObject("i-body").getAsJsonObject().remove("img1");
			isonMsg.getAsJsonObject("i-body").getAsJsonObject().remove("img2");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// #MAQ00049 starts
	public void OKYLCORG_CREATE(JsonObject isonMsg) {
		try {

			String SiteKey = I$impactoUtil.generateRandomString(10);
			String APIKey = I$impactoUtil.generateRandomString(16);
			String pckgName = "PCKG" + I$impactoUtil.generateRandomString(4);

			JsonObject filter = new JsonObject();

			if (isonMsg.getAsJsonObject("i-body").getAsJsonObject().has("errorMsg")) {
				isonMsg.getAsJsonObject("i-body").getAsJsonObject().remove("errorMsg");
			}
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "License Successfully Generated");
			JsonObject i$Body = isonMsg.getAsJsonObject("i-body").getAsJsonObject();
			i$Body.addProperty("pckgName", pckgName);
			i$Body.addProperty("SiteKey", SiteKey);
			i$Body.addProperty("APIKey", APIKey);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$Body);
			JsonObject up$ = db$Ctrl.db$UpdateRow("ICOR_M_PARTNER_LICENSE",
					isonMsg.getAsJsonObject("i-body").getAsJsonObject(), filter);

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "License Generation Failed");
			logger.debug(e.getMessage());
		}
	}
	// #MAQ00049 ends

	public void OCKEMLCK_CREATE(JsonObject isonMsg) {
		try {
			IEmailService i$Email = new IEmailService();
			JsonObject map$Data = new JsonObject();
			if (isonMsg.getAsJsonObject("i-body").getAsJsonObject().has("errorMsg")) {
				isonMsg.getAsJsonObject("i-body").getAsJsonObject().remove("errorMsg");
			}
			JsonObject i$Body = isonMsg.getAsJsonObject("i-body").getAsJsonObject();
			map$Data.addProperty("tmp$name", "TMPL#SMSMAILCHK");

			JsonObject projection = new JsonObject();
			projection.addProperty("iOtpCommMode", 1);
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendMailOtp").getAsString(), "Y")) {
				JsonObject argJsonPass = new JsonObject();
				argJsonPass.add("toemailIds",
						i$ResM.getJsonObj("{\"toemailid1\":\"" + i$Body.get("emailId").getAsString() + "\"}"));
				map$Data.addProperty("iBody", i$Body.get("iBody").getAsString());
				argJsonPass.add("map$Data", map$Data);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Trigger Initiated");
				i$Email.sendEmail(argJsonPass);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Error in Sending Mail or Mail Service is disabled, Contact Adminstrator");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Email Trigger Failed");
			logger.debug(e.getMessage());
		}
	}

	public void OCKSMSCK_CREATE(JsonObject isonMsg) {
		try {
			ISmsService I$ISmsService = new ISmsService();
			JsonObject argJson = new JsonObject();
			if (isonMsg.getAsJsonObject("i-body").getAsJsonObject().has("errorMsg")) {
				isonMsg.getAsJsonObject("i-body").getAsJsonObject().remove("errorMsg");
			}
			JsonObject i$Body = isonMsg.getAsJsonObject("i-body").getAsJsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject $mobNum = new JsonObject();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendSmsOtp").getAsString(), "Y")) {
				if (i$Body.has("MobNum") && i$Body.has("IsdMobNum")) {
					$mobNum.addProperty("Mob_Number1",
							i$Body.get("IsdMobNum").getAsString().concat(i$Body.get("MobNum").getAsString()));
				}
				argJson.add("mobile$numbers", $mobNum);
				map$Data.addProperty("tmp$name", "TMPL#SMSMAILCHK");
				map$Data.addProperty("iBody", i$Body.get("iBody").getAsString());
				argJson.add("map$Data", map$Data);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Trigger Initiated");
				I$ISmsService.sendSMS(argJson);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Error in Sending Mail or Mail Service is disabled, Contact Adminstrator");
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SMS Trigger failed");
		}

	}
	// #MAQ000032 ends

	// #BVB00104 Starts
	public void OASB2UJR_AUTH(JsonObject isonMsg) {
		JsonArray i$DocArr = new JsonArray();
		JsonArray setterArr = new JsonArray();
		JsonObject setter = new JsonObject();
		JsonObject i$Doc = new JsonObject();
		try {
			JsonArray cbsEData = i$ResM.getBodyElementA(isonMsg, "cbsEData");
			String type = i$ResM.getBodyElementS(isonMsg, "jobrunType");// #BHUVI001 Added
			for (int i = 0; i < cbsEData.size(); i++) {
				setter = new JsonObject();
				i$Doc = new JsonObject();
				JsonObject i$runningObj = cbsEData.get(i).getAsJsonObject();
				setter.addProperty("KeyId", i$runningObj.get("KeyId").getAsString());
				setter.addProperty("Type", type);
				String ss = i$runningObj.get("ImpactoAllowed").getAsString();// #BHUVI001 Added
				i$Doc.addProperty("ImpactoAllowed", i$runningObj.get("ImpactoAllowed").getAsString());
				i$DocArr.add(i$Doc);
				setterArr.add(setter);
			}

			db$Ctrl.db$UpdateMany("ICOR_M_CBS_E_DATA", i$DocArr, setterArr, "true");

		} catch (Exception e) {

		}
	}

	// #BVB00104 Ends
	// #BVB00111 Starts
//	public JsonObject LABBDTRS_QUERY(JsonObject isonMsg) {
//		JsonArray branchWithRes = new JsonArray();
//		try {
//			JsonArray i$body = i$ResM.getBodyA(isonMsg);
//			// branchWithRes = i$body.deepCopy();
//			JsonArray allwBrns = db$Ctrl.getUserAllowedBrns(IResManipulator.iloggedUser.get());
//			for (int i = 0; i < allwBrns.size(); i++) {
//				JsonObject foundBranch = I$impactoUtil.objFromArrWithSearch(i$body, "BranchCode",
//						allwBrns.get(i).getAsString());
//				if (!I$utils.$isNull(foundBranch)) {
//					branchWithRes.add(foundBranch);
//				}
//			}
//			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, branchWithRes);
//			if (branchWithRes.size() > 0) {
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
//			} else {
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
//			}
//		} catch (Exception e) {
//			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED WITH: " + e.getMessage());
//		}
//		return isonMsg;
//	}

	// #BVB00111 Ends

	// PKY00071 starts
	public void chequeIssuance$LetterRequest(JsonObject isonMsg) {

		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject emailDataset$Data = new JsonObject();
		String keyE = new String();
		String keyM = new String();
		JsonObject argJson = new JsonObject();
		String SrvcName = i$ResM.getSrvcName(isonMsg);
		JsonObject i$body = i$ResM.getBody(isonMsg);
		if (I$utils.$iStrFuzzyMatch(SrvcName, "CHEQUE_ISSUANCE_STMT")) {
			filter.addProperty("datasetId", "Dataset_5675");
		}
		if (I$utils.$iStrFuzzyMatch(SrvcName, "REQUEST_FOR_LETTER_STMT")) {
			filter.addProperty("datasetId", "Dataset_5676");
		}
		projection.addProperty("userDetails", 1);
		projection.addProperty("sendEmail", 1);
		projection.addProperty("sendSms", 1);
		emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
		JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
		boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
		boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
		for (int i = 0; i < userDet.size(); i++) {
			try {
				if (sendEmail) {
					JsonObject jsonObject = userDet.get(i).getAsJsonObject();
					String Email = jsonObject.get("userEmailId").getAsString();
					keyE = keyE.concat(Email);
					if (i < userDet.size() - 1) {
						keyE = keyE.concat(",");
					}
				}
				if (sendSMS) {
					JsonObject jsonObject = userDet.get(i).getAsJsonObject();
					String SMS = jsonObject.get("userMobileNo").getAsString();
					keyM = keyM.concat(SMS);
					if (i < userDet.size() - 1) {
						keyM = keyM.concat(",");
					}
				}
			} catch (Exception e) {

			}
		}
		try {
			JsonObject map$Data = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(SrvcName, "CHEQUE_ISSUANCE_STMT")) {
				map$Data.addProperty("tmp$name", "TMPL#TT#CHEQUE#ISSUANCE#NOTIFICATION#MAIL");
				map$Data.addProperty("CustomerName", i$body.get("memberName").getAsString());
			}
			if (I$utils.$iStrFuzzyMatch(SrvcName, "REQUEST_FOR_LETTER_STMT")) {
				map$Data.addProperty("tmp$name", "TMPL#TT#REQ#FOR#LETTER#NOTIFICATION#MAIL");
				String type = i$body.get("type").getAsString();
				map$Data.addProperty("CustomerName", i$body.get("memberName").getAsString());
			}
			argJson.add("map$Data", map$Data);
			argJson.addProperty("key$Type", "notification");
			argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
			argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
			if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
			}
		} catch (Exception e) {
			logger.debug("Failed to send email and sms" + e.getMessage());
		}

	}
//PKY00071 ends

	public void createDmsHstRecs(JsonObject isonMsg) {
		try {
			Boolean logHstry = false;
			String ScrId = i$ResM.getScreenID(isonMsg);
			String SOpr = i$ResM.getOpr(isonMsg);
			String sSvr = i$ResM.getSrvcName(isonMsg);
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject hstRec = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRWS") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				hstRec.addProperty("historyId", i$body.get("workspaceId").getAsString());
				hstRec.addProperty("historyOn", "WORKSPACE");
				logHstry = true;
			} else if ((I$utils.$iStrFuzzyMatch(ScrId, "ODSCRRFL") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE"))
					|| (I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD")
							&& (i$body.has("historyOnFolder") && i$body.get("historyOnFolder").getAsBoolean()))) {
				hstRec.addProperty("historyId", i$body.get("folderId").getAsString());
				hstRec.addProperty("historyOn", "FOLDER");
				logHstry = true;
			} else if ((I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD")
					&& I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "Y"))
					|| (I$utils.$iStrFuzzyMatch(ScrId, "FABFLUPD")
							&& I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "N"))// SKG00017
					|| (I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && i$body.has("historyOnFile")
							&& i$body.get("historyOnFile").getAsBoolean())) {
				hstRec.addProperty("historyId", i$body.get("FileUrlToken").getAsString());
				hstRec.addProperty("historyOn", "FILE");
				if (i$body.has("logHistory") && i$body.get("logHistory").getAsBoolean()) // SKP00002 Changes
					logHstry = true;
			} else if ((i$body.has("folderId") && I$utils.$iStrFuzzyMatch(sSvr, "ImpactoSeqService"))
					|| (I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && i$body.has("folderId") && !i$body.has("dmsApi")
							&& I$utils.$iStrFuzzyMatch(i$body.get("DMSLDOC").getAsString(), "Y"))
					|| I$utils.$iStrFuzzyMatch(ScrId, "FABFLUPD")) {
				hstRec.addProperty("historyId", i$body.get("folderId").getAsString());
				hstRec.addProperty("historyOn", "FOLDER"); // #YPR00111 changes
				logHstry = true;
			}
			hstRec.addProperty("active", "A");
			hstRec.add("history", new JsonArray());
			logger.debug("*****************Inserting dmsId Document SRM1111************" + logHstry);
			db$Ctrl.db$InsertRow("fs.files", hstRec);// SKG00036
			if (logHstry) {
				logger.debug("***************** starting Inserting history logs SRM1111************" + logHstry);
				db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
	}

	public void createMultiDmsHstRecs(JsonObject isonMsg) {
		try {
			JsonObject hstRec = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			if (i$body.has("historyOnFolder") && i$body.get("historyOnFolder").getAsBoolean()) {
				hstRec.addProperty("historyId",
						i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString());
				hstRec.addProperty("historyOn", "Folder");
				hstRec.addProperty("active", "A");
				hstRec.add("history", new JsonArray());
				db$Ctrl.db$InsertRow("fs.files", hstRec);// SKG00036
				db$Ctrl.db$logDmsHstry(isonMsg);
			} else if (i$body.has("historyOnFile") && i$body.get("historyOnFile").getAsBoolean()) {
				JsonArray files = i$body.get("files").getAsJsonArray();
				for (int i = 0; i < files.size(); i++) {
					hstRec.addProperty("historyId", files.get(i).getAsJsonObject().get("FileUrlToken").getAsString());
					hstRec.addProperty("historyOn", "FILE");
					hstRec.addProperty("active", "A");
					hstRec.add("history", new JsonArray());
					db$Ctrl.db$InsertRow("fs.files", hstRec);// SKG00036
				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
	}

	public void ODSCRRFL_UPDATE(JsonObject isonMsg) {
		try {
			JsonObject queryfilter = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String flpath;
			String arrFilter;
			String i$Doc;
			queryfilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			if (i$body.get("folderLevel").getAsInt() >= 2) {
				flpath = "folders.$[].".repeat(i$body.get("folderLevel").getAsInt() - 1) + "folders.$[j].folderName";
				arrFilter = "[{'j.folderId': '" + i$body.get("folderId").getAsString() + "'}]";
			} else {
				queryfilter.addProperty("folders.folderId", i$body.get("folderId").getAsString());
				flpath = "folders.$.folderName";
				arrFilter = "";
			}
			i$Doc = "{'" + flpath + "':'" + i$body.get("folderName").getAsString() + "'}";
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
	}

	public void ODSCRRFL_DELETE(JsonObject isonMsg) {
		try {
			JsonObject queryfilter = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);

			String flpath;
			String arrFilter;
			String i$Doc;
			queryfilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			if (i$body.get("folderLevel").getAsInt() >= 2) {
				flpath = "folders.$[].".repeat(i$body.get("folderLevel").getAsInt() - 2) + "folders.$[j].folders";
				arrFilter = "[{'j.folderId': '" + i$body.get("parentFolderId").getAsString() + "'}]";
			} else {
				flpath = "folders";
				arrFilter = "";
			}
			i$Doc = "{'" + flpath + "':{'folderId':'" + i$body.get("folderId").getAsString() + "','folderName':'"
					+ i$body.get("folderName").getAsString() + "','workspaceId':'"
					+ i$body.get("workspaceId").getAsString() + "'," + "'folderLevel':'"
					+ i$body.get("folderLevel").getAsInt() + "','containDocs':"
					+ i$body.get("containDocs").getAsBoolean() + "}}";
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "pull", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "pull");
			}

		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
		trashFol(isonMsg);// SKG00020 changes
	}

	public void ODSCRRFL_CREATE(JsonObject isonMsg) {
		try {
			JsonObject queryfilter = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String flpath;
			String arrFilter;
			String i$Doc;
			queryfilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			if (i$body.get("folderLevel").getAsInt() >= 2) {
				flpath = "folders.$[].".repeat(i$body.get("folderLevel").getAsInt() - 2) + "folders.$[j].folders";
				arrFilter = "[{'j.folderId': '" + i$body.get("parentFolderId").getAsString() + "'}]";
			} else {
				flpath = "folders";
				arrFilter = "";
			}
			i$Doc = "{'" + flpath + "':{'folderId':'" + i$body.get("folderId").getAsString() + "','folderName':'"
					+ i$body.get("folderName").getAsString() + "','workspaceId':'"
					+ i$body.get("workspaceId").getAsString() + "'," + "'folderLevel':'"
					+ i$body.get("folderLevel").getAsInt() + "','containDocs':"
					+ i$body.get("containDocs").getAsBoolean() + ",'folders':[]}}";
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "push", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "push");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
	}

	public void foldrDocContainUpdt(JsonObject isonMsg) {
		try {
			JsonObject queryfilter = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String flpath;
			String arrFilter;
			String i$Doc;
//            Boolean DocContains = false;
			JsonObject folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS",
					"{'folderId': '" + i$body.get("parentFolderId").getAsString() + "','isCurrVer':'Y'}", "{}");
			queryfilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			if (folderData.get("folderLevel").getAsInt() >= 2) {
				flpath = "folders.$[].".repeat(folderData.get("folderLevel").getAsInt() - 1)
						+ "folders.$[j].containDocs";
				arrFilter = "[{'j.folderId': '" + i$body.get("parentFolderId").getAsString() + "'}]";
			} else {
				queryfilter.addProperty("folders.folderId", i$body.get("parentFolderId").getAsString());
				flpath = "folders.$.containDocs";
				arrFilter = "";
			}

			i$Doc = "{'" + flpath + "':" + folderData.get("containDocs").getAsBoolean() + "}";
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
	}

	public void updateContainDocs(JsonObject isonMsg) {
		try {
			JsonObject queryfilter = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String flpath;
			String arrFilter;
			String i$Doc;
//            Boolean DocContains = false;
			JsonObject folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", "{'folderId': '"
					+ i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString()
					+ "','isCurrVer':'Y'}", "{}");
			queryfilter.addProperty("workspaceId",
					i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			String parentFolderId = folderData.get("folderIdPath").getAsString().split("/")[1];
			String subFolderId = folderData.get("folderIdPath").getAsString().split("/")[2];
			String folderId = folderData.get("folderId").getAsString();
			flpath = "folders.$[i].folders.$[j].folders.$[k].containDocs";
			arrFilter = "[{'i.folderId': '" + parentFolderId + "'} , {'j.folderId': '" + subFolderId
					+ "'} , {'k.folderId': '" + folderId + "'}]";
			i$Doc = "{'" + flpath + "':" + folderData.get("containDocs").getAsBoolean() + "}";
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N");
			}
		} catch (Exception e) {

		}
	}

	public void autoFoldrDocContainUpdt(JsonObject isonMsg) {
		try {
			JsonObject queryfilter = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String flpath;
			String arrFilter;
			String i$Doc;
			String folder;
//            Boolean DocContains = false;
			JsonObject folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS",
					"{'folderId': '" + i$body.get("folderId").getAsString() + "','isCurrVer':'Y'}", "{}");
			queryfilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			folder = folderData.get("folderIdPath").getAsString().split("/")[1];
			String subFolder = folderData.get("folderIdPath").getAsString().split("/")[2];
			flpath = "folders.$[i].folders.$[j].folders.$[k].containDocs";
			arrFilter = "[{'i.folderId': '" + folder + "'} , {'j.folderId': '" + subFolder + "'} , {'k.folderId': '"
					+ folderData.get("folderId").getAsString() + "'}]";
			i$Doc = "{'" + flpath + "':" + folderData.get("containDocs").getAsBoolean() + "}";
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
	}

	// PAV0005 changes starts
	public JsonObject exportSummaryData(JsonObject isonMsg) {
		try {
			String Opr3 = i$ResM.getOpr3(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Opr3, "export")) {
				JsonArray projectionArr = isonMsg.get("i-projection").getAsJsonArray();
				JsonObject columnMappingData = isonMsg.get("i-body").getAsJsonObject().get("columnMapping")
						.getAsJsonObject();
				JsonObject exlattachmentData = new JsonObject();
				JsonParser parser = new JsonParser();
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sh = wb.createSheet("Sheet1");
				HSSFRow row = sh.createRow(0);
				HSSFFont i$font = wb.createFont();
				int rowCount = 0;
				String headings = "['Sl No',";
				Set<String> keys = null;
				JsonArray rowData = isonMsg.get("i-body").getAsJsonObject().get("iRowData").getAsJsonArray();
				int size1 = rowData.size();
				int keysCount = 0;
				int columnCount = 0;
				for (int i = 0; i < projectionArr.size(); i++) {
					try {
						if (columnCount == 0) {
							sh.setColumnWidth(columnCount, 2000);
							columnCount++;
						}
						if (columnCount >= 0) {
							sh.setColumnWidth(columnCount, 5000);
							columnCount++;
						}
						try {
							if (keysCount == 0) {
								headings = headings + "'"
										+ columnMappingData.get(projectionArr.get(i).getAsString()).getAsString() + "'";
								keysCount++;
							} else {
								headings = headings + "," + "'"
										+ columnMappingData.get(projectionArr.get(i).getAsString()).getAsString() + "'";
							}
//		            			 }
						} catch (Exception e) {
						}
					} catch (Exception e) {
					}
				}
				headings = headings + "]";
				JsonArray hds = parser.parse(headings).getAsJsonArray();
				HSSFCellStyle style = wb.createCellStyle();
				row.setRowStyle(style);
				for (int i = 0; i < hds.size(); i++) {
					try {
						i$font.setFontName(hds.get(i).getAsString());
						i$font.setColor(IndexedColors.BLACK.getIndex());
						i$font.setBold(true);
						row.createCell(i).setCellValue(hds.get(i).getAsString());
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				for (int i = 0; i < rowData.size(); i++) {
					try {
						JsonObject db$Doc = rowData.get(i).getAsJsonObject();
						int cellCount = 0;
						row = sh.createRow(++rowCount);
						for (int j = 0; j < projectionArr.size(); j++) {
							try {
								if (j == 0) {
									Cell cell = row.createCell(cellCount);
									cell.setCellValue(Integer.toString(i + 1));
									cellCount++;
								}
								if (j >= 0) {
									Cell cell = row.createCell(cellCount);
									String objProj = projectionArr.get(j).getAsString();
									if (objProj.contains(".")) {
										String strArr[] = objProj.split("\\.");
//										db$Doc.get(strArr[0]).getAsJsonObject().get(strArr[1]).getAsString();
										cell.setCellValue(
												db$Doc.get(strArr[0]).getAsJsonObject().get(strArr[1]).getAsString());
									} else {
										cell.setCellValue(db$Doc.get(projectionArr.get(j).getAsString()).getAsString());
									}
									cellCount++;
								}
							} catch (Exception e) {
								cellCount++;
								e.printStackTrace();
							}
						}

					} catch (Exception e) {

					}
				}
				wb.write(outputStream);
				byte[] exlBytes = outputStream.toByteArray();
				String base64String = Base64.getEncoder().encodeToString(exlBytes);
				System.out.println(base64String);
				exlattachmentData.addProperty("docType", "application/excel");
//				exlattachmentData.addProperty("fileName", "Excel Summary report" + ".xls"); 
				exlattachmentData.addProperty("template", base64String);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, exlattachmentData);
				return isonMsg;
			}
			// PAV0005 changes ends
			// SRI00005 changes Start
			else {
				try {
					JsonArray projectionArr = isonMsg.get("i-projection").getAsJsonArray();
					JsonObject columnMappingData = isonMsg.get("i-body").getAsJsonObject().get("columnMapping")
							.getAsJsonObject();
					JsonObject exlattachmentData = new JsonObject();
					JsonParser parser = new JsonParser();
					StringWriter csvStringWriter = new StringWriter();
					CSVWriter csvWriter = new CSVWriter(csvStringWriter);

					// Write CSV header
					String[] header = new String[projectionArr.size() + 1];
					header[0] = "Sl No";
					for (int i = 0; i < projectionArr.size(); i++) {
						try {
							header[i + 1] = columnMappingData.get(projectionArr.get(i).getAsString()).getAsString();
						} catch (Exception e) {
							e.printStackTrace();
						}

					}
					csvWriter.writeNext(header);

					JsonArray rowData = isonMsg.get("i-body").getAsJsonObject().get("iRowData").getAsJsonArray();

					for (int i = 0; i < rowData.size(); i++) {
						try {
							JsonObject db$Doc = rowData.get(i).getAsJsonObject();
							String[] row = new String[projectionArr.size() + 1];
							row[0] = Integer.toString(i + 1);
							for (int j = 0; j < projectionArr.size(); j++) {
								try {
									String objProj = projectionArr.get(j).getAsString();
									if (objProj.contains(".")) {
										String strArr[] = objProj.split("\\.");
										// Check if the JSON elements exist before accessing them
										if (db$Doc.has(strArr[0])
												&& db$Doc.get(strArr[0]).getAsJsonObject().has(strArr[1])) {
											row[j + 1] = db$Doc.get(strArr[0]).getAsJsonObject().get(strArr[1])
													.getAsString();
										} else {
											row[j + 1] = ""; // Set an empty string or some default value
										}
									} else {
										// Check if the JSON element exists before accessing it
										if (db$Doc.has(projectionArr.get(j).getAsString())) {
											row[j + 1] = db$Doc.get(projectionArr.get(j).getAsString()).getAsString();
										} else {
											row[j + 1] = ""; // Set an empty string or some default value
										}
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							csvWriter.writeNext(row);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					// Close the CSV writer
					// csvWriter.close();

					// Get CSV data as a string
					String csvData = csvStringWriter.toString();

					// Encode CSV data to base64
					String base64String = Base64.getEncoder().encodeToString(csvData.getBytes());

					exlattachmentData.addProperty("docType", "text/csv");
					// exlattachmentData.addProperty("fileName", "CSV Summary report" + ".csv");
					exlattachmentData.addProperty("template", base64String);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, exlattachmentData);

					// Add CSV data to the JSON object
//		        isonMsg.add("csvData", parser.parse(csvData));
					// isonMsg.addProperty("csvData", base64String);

					return isonMsg;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {

		}
		return isonMsg;
	}

	// SRI00005 changes Start
	// SKG00020 changes starts
	public void trashFol(JsonObject isonMsg) {
		try {
//			i$ResM.setGobalVals("delFldrFltr", i$runningQuery);

			JsonObject projection = new JsonObject();
			projection.addProperty("_id", 0);
			JsonObject filter = i$ResM.getGobalValJObj("delFldrFltr");
			filter.addProperty("isCurrVer", "N");
			filter.addProperty("recordStat", "D");
			filter.addProperty("operation", "DELETE");
			JsonObject appFld = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filter, projection);
			appFld.addProperty("docDel", "Y");
			appFld.addProperty("delItemId", appFld.get("folderId").getAsString());// SKG00021 changes
			appFld.addProperty("delItemName", appFld.get("folderName").getAsString());// SKG00021 changes
			appFld.addProperty("FileExtn", ".folder");// SKG00021 changes
			JsonObject res = db$Ctrl.db$InsertRow("ICOR_M_DMS_TRASH", appFld);
//			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Documents added to trash");
		} catch (Exception e) {
			e.printStackTrace();
		}

//		return isonMsg;
	}

}
// #BVB00032 Ends
//SKG00020 changes end
