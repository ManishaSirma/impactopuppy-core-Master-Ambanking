/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------    
      |3.2.5.446   | Pruthvi  	| Apr 27, 2020 | #YPR00014   | Initial Writing
      |0.4 Beta    | Tarun  	| Jun 17, 2021 | #TKS00001   | Adding CRUD for IDocz documents
      |0.4 Beta    | Tarun  	| Jun 24, 2021 | #TKS00002   | Added code for document update
      |0.4 Beta    | Pruthvi  	| Jun 30, 2021 | #YPR00094   | Added code for add documents through api
      |0.4 Beta    | Pruthvi  	| Jun 30, 2021 | #YPR00095   | Added code for Update documents through api 
      |0.4 Beta    | Pruthvi	| Jul 15, 2021 | #YPR00099   | Added to IDocz DMS history logger.
      |0.4 Beta    | Tarun  	| Jul 15, 2021 | #TKS00004   | Added code isCurrVer field in fs.files
      |0.4 Beta    | Pruthvi    | Jul 21, 2021 | #YPR00100   | Added to file key changes with password protection.
      |0.4 Beta    | Tarun      | Jul 29, 2021 | #TKS00005   | Added folderIdpAth in i$body
      |0.4 Beta    | Pruthvi    | Jul 30, 2021 | #YPR00104   | Added to file Antivirus Scanning chnages.
      |0.4 Beta    | Sushmita   | Sep 01, 2021 | #SKP00001   | Added code to handle the null folder details
      |0.5 Beta    | Pruthvi  	| Sep 23, 2021 | #YPR00111   | Added changes to add documents into kyc application folders
      |0.5 Beta    | Pruthvi  	| Sep 24, 2021 | #YPR00112   | Added changes to add all documents into one folder
      |0.5 Beta    | Tarun      | Sep 28, 2021 | #TKS00006   | Added function addTagsIndexing
      |0.5 Beta    | Tarun      | Nov 03, 2021 | #TKS00009   | Added code for OBDX document upload.
      |0.5 Beta    | Tarun      | Nov 18, 2021 | #TKS00010   | Added validation to add docs in post onboarding workspace.
      |0.5 Beta    | Tarun      | Nov 18, 2021 | #TKS00011   | Added code for keys updation in fs.files.
      |0.5 Beta    | Sushmita   | Dec 31, 2021 | #SKP00002   | Added changes for History Post-Onboarding
      |0.5 Beta    | Tarun      | Aug 30, 2022 | #TKS00012   | Added changes to add foldres of a particular id
      |0.5 Beta    | Tarun      | Sep 01, 2022 | #TKS00013   | Added code to add workspace id
      |0.5 Beta    | Tarun      | Sep 09, 2022 | #TKS00014   | Added code to add verNo and DMSLDOC
      |0.5 Beta    | Madhura    | Sep 27, 2022 | #MSA00001   | Added code for Deleting Document
      |0.5 Beta    | Madhura    | Nov 15, 2022 | #MSA00002   | Added code for Authorizing Document  
      |0.5 Beta    | Manikanta  | Nov 23, 2022 | #MVT00092	 | Added code to update remarks in dms folder collection
      |0.5 Beta    | Madhura    | Nov 24, 2022 | #MSA00003	 | Added code for deleting multiple documents
      |0.5 Beta	   | Manikanta  | Nov 25, 2022 | #MVT00094   | Added code to validate file name in dms folders collections
      |0.5 Beta    | Sindhu     | Dec 01, 2022 | #SRM00012   | Handled code to validate fileKey
      |0.5 Beta    | Sindhu     | Dec 05, 2022 | #SRM00013   | Handled code for single document viewing in favourites
      |0.5 Beta    | Madhura    | Dec 06, 2022 | #MSA00004	 | Added code for adding and removing password
      |0.5 Beta    | Sindhu     | Jan 19, 2023 | #SRM00021   | Handled code for updating the fileUrlToken in existing folder for FCIP
      |0.5 Beta    | Sindhu     | Jan 24, 2023 | #SRM00022   | Handled code for adding documents in autoworkspace
      |0.5 Beta    | Sindhu     | Feb 01, 2023 | #SRM00024   | Handled code for adding tags in DMS folders collection
      |0.5 Beta    | Sindhu     | Feb 07, 2023 | #SRM00025   | Added code for trash bin option and summary for the same
      |0.5 Beta    | Sindhu     | Feb 15, 2023 | #SRM00026   | Added code for document data modification
      |0.5 Beta    | Sindhu     | Feb 21, 2023 | #SRM00027   | Added code to add remarks field to the database
      |0.5 Beta    | Sindhu     | Mar 01, 2023 | #SRM00028   | Handled code to perform trash on multiple documents
      |0.5 Beta	   | Manikanta  | Mar 08, 2023 | #MVT00108   | Added code to Letter request folders
      |0.5 Beta	   | Sindhu     | Mar 16, 2023 | #SRM00030   | Handled code for delete, trash view and restore         
      |0.5 Beta	   | Sindhu     | Mar 20, 2023 | #SRM00033   | Handled code to restore the documents to the original position
      |0.5 Beta	   | Sindhu     | Apr 25, 2023 | #SRM00034   | Added code to add more filter validation for duplicate doc verification
      |0.5 Beta	   | Sumit      | Jun 01, 2023 | #SKG00005   | added code for password protected in favorite summary
      |0.5 Beta	   | Sumit      | Jun 02, 2023 | #SKG00006   | added code for remarks reflecting after verifying in search operation
      |0.5 Beta	   | Sumit      | Jun 02, 2023 | #SKG00007   | comment code because getting multiple documents at auto workspace
      |0.5 Beta	   | Sumit      | Jun 12, 2023 | #SKG00008   | added code for restore documents is  showing history
      |0.5 Beta	   | Sumit      | Jun 12, 2023 | #SKG00009   | added code for reset documents 
      |0.5 Beta	   | Sumit      | Jun 12, 2023 | #SKG00010   | Uncomment code for getting multiple documents at search 
      |0.5 Beta	   | Sumit      | Jun 28, 2023 | #SKG00011   | added code for authorizer & remark reflecting in favorite summary
      |0.5 Beta	   | Sumit      | Jun 28, 2023 | #SKG00014   | added code for password protected in edit option
      |0.5 Beta	   | Sumit      | Jun 28, 2023 | #SKG00015   | added code for tag value name changing
      |0.5 Beta	   | Pavithra   | Jul 31, 2023 | #PAV00006   | Handled containDocs field
      |0.5 Beta	   | Pavithra   | Aug 03, 2023 | #PAV00008   | Corrected Field name and added valid collection name
      |0.5 Beta	   | Sumit      | Aug 08, 2023 | #SKG00019   | Handled for delete documents of manual workspace is not reflecting in trash module 
      |0.5 Beta	   | Sumit      | Aug 11, 2023 | #SKG00021   | Handled for delete folder of manual workspace is not reflecting folder name & folder ID in trash module
      |0.5 Beta	   | Sumit      | Aug 19 2023  | #SKG00024   | Added code for Verifying history
      |0.5 Beta	   | Karthik    | Aug 24 2023  | #NK00004    | Added code for password protected for modify documents
      |0.5 Beta    | karthik    | Aug 25,2023  | #NK00005    | Added code for Forgot password feature
      |0.5 Beta    | karthik    | Aug 25,2023  | #NK00006    | Added code for Change password for Protected documents
      |0.5 Beta    | karthik    | Aug 28,2023  | #NK00008    | added validation for restoring the documents
      |0.5 Beta    | karthik    | Aug 31, 2023 | #NK00010    | Added code for restore password validation
      |0.5 Beta    | karthik    | Sep 13, 2023 | #NK00015    | added code for bug no 10106 and 10107
      |0.5 Beta	   | Sumit      | Sep 27, 2023 | #SKG00030   | added code for instead of cif id instead of name in Loan-webapplications shown
      |0.5 Beta	   | Sumit      | Oct 18, 2023 | #SKG00034   | added code for Created by not getting data in Search module
      |0.5 Beta	   | Sumit      | Oct 19, 2023 | #SKG00035   | added code for instead of email id username  need to fetch
      |0.5 Beta    | karthik    | Dec 01, 2023 | #NK00068    | added validations for user operation 
      |0.5 Beta    | karthik    | Dec 15, 2023 | #NK00069    | Added code for folder restore
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder; // #MAQ00020 
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import fi.solita.clamav.ClamAVClient;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IDocumentsController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private Ioutils I$Ioutils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IWorkspacesController.class);
	private IResPreFlightHandler i$resPre = new IResPreFlightHandler();

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private JsonObject i$Annotate = null;
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		i$body = isonMsg.getAsJsonObject("i-body");
		// JsonObject i$Annotate = null;

//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonObject projection = new JsonObject();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();

		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
		String DMSLDOC = "N";
		if (I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
			DMSLDOC = isonMsg.getAsJsonObject("i-body").get("DMSLDOC").getAsString();
		}

//		projection.addProperty("privateKey", 1);
//		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
//		String privateKey = cParam.get("privateKey").getAsString();
//		
		try {
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;
			try {
				if (hasRights) {
					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}"); // #BVB00035 changes ScrID to ScrId
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;
						I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrId, SOpr); // #BVB00035
						if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
							// #TKS00001 starts
							if (I$utils.$iStrFuzzyMatch(ScrId, "FDMFLUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(DMSLDOC, "Y")) {
								try {
									projection = new JsonObject();
									projection.addProperty("avScanningEnabled", 1);
									JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}",gson.toJson(projection));
									// #YPR00104 Starts
									if (I$utils.$iStrFuzzyMatch(cParam.get("avScanningEnabled").getAsString(), "Y")) {
										try {
											String scanResult = clamAVscan(i$body.get("I#FileData").getAsString());
											if (scanResult.contains("SCAN FAILED")) {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, scanResult);
												return isonMsg;
											}
										} catch (Exception e) {
											// pass
										}
									}
									// #YPR00104 Ends
									JsonObject updateFilter = new JsonObject();
									String parentFolderName = i$body.get("parentFolderName").getAsString();
									updateFilter.addProperty("folderId", i$body.get("parentFolderId").getAsString());
									updateFilter.addProperty("folderName", parentFolderName);
									updateFilter.addProperty("isCurrVer", "Y");
									updateFilter.addProperty("documents.sides.FileUrlToken",i$body.get("FileUrlToken").getAsString());

									JsonObject data = new JsonObject();
									if (!I$utils.$iStrBlank(i$body.get("FileUrlToken").getAsString())) {
										data.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"FileUrlToken is Missing");
										return isonMsg;
									}

									if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", updateFilter) > 0) { // #YPR00095 Changes
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Document Already exits with same " + i$body.get("FileUrlToken").getAsString());
										return isonMsg;
									}
									updateFilter.remove("documents.sides.FileUrlToken");
									JsonObject foldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", updateFilter);
									// #NK00068 starts
//									if (!(I$utils.$iStrFuzzyMatch(foldrData.get("initiator").getAsString(),IResManipulator.iloggedUser.get())) && (I$utils.$iStrFuzzyMatch(foldrData.get("workspaceId").getAsString(),"IWRKSP469371"))) {
//										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can add documents");
//										return isonMsg;
//									} // #NK00068 starts
									// #SKP00001 Starts
									if (foldrData == null) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"INVALID FOLDER DETAILS");
										return isonMsg;
									}
									// #SKP00001 Ends
									JsonArray docArray = foldrData.get("documents").getAsJsonArray();
									JsonObject side = new JsonObject();
									Boolean isPswrdPrctd = false;
									if (i$body.get("FileName").getAsString().contains(".")) {
										String fileName = I$utils.fetchValueFromJsonObj(i$body, "FileName", "");
										String[] tokens = fileName.split("\\.(?=[^\\.]+$)");
										side.addProperty("FileName", tokens[0]);
										data.addProperty("FileName", tokens[0]);
									} else {
										side.addProperty("FileName",I$utils.fetchValueFromJsonObj(i$body, "FileName", ""));
										data.addProperty("FileName",I$utils.fetchValueFromJsonObj(i$body, "FileName", ""));
									}

									side.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
									side.addProperty("FileExtn", I$utils.fetchValueFromJsonObj(i$body, "FileExtn", ""));
									side.addProperty("side", I$utils.fetchValueFromJsonObj(i$body, "DocSubGrpID2", ""));
									data.addProperty("FileSize", I$utils.fetchValueFromJsonObj(i$body, "FileSize", ""));
									JsonArray sides = new JsonArray();
									sides.add(side);

									data.addProperty("DocType",I$utils.fetchValueFromJsonObj(i$body, "DocParentGrpID1", ""));
									data.addProperty("LinkedCustNo",I$utils.fetchValueFromJsonObj(i$body, "LinkedCustNo", ""));
									if (!I$utils.$iStrBlank(I$utils.fetchValueFromJsonObj(i$body, "fileKey", ""))) { // #YPR00100 Starts
										isPswrdPrctd = true;
										i$body.addProperty("fileKey",I$impactoUtil.encrypt(i$body.get("fileKey").getAsString()));
									}else {
										i$body.addProperty("fileKey","");
									}
									data.addProperty("isPswrdPrctd", isPswrdPrctd);// #YPR00100 Ends
									data.addProperty("initiator", IResManipulator.iloggedUser.get());
									data.add("UpldSvrDateTime", i$ResM.adddate(new Date()));
									data.add("tags", i$body.get("tags").getAsJsonArray());//#TKS00016 changes
									data.addProperty("verNo", 1);
									data.add("sides", sides);
									data.add("remarks", i$body.get("remarks"));//#SRM00027 changes
									String i$Doc = "{'documents': " + data.getAsJsonObject() + "}";

									db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "false","push");

									if (!(foldrData.get("containDocs").getAsBoolean())) {

										i$Doc = "{'containDocs': true}";
										db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "false","N");

									}
									i$body.addProperty("isPswrdPrctd", isPswrdPrctd); // #YPR00100 Changes
									i$body.addProperty("folderIdPath", foldrData.get("folderIdPath").getAsString());// #TKS0006 changes
									i$body.addProperty("isCurrVer", "Y"); // #TKS00004 changes
									i$body.addProperty("Archive", "N");
									i$body.addProperty("verNo", 1);
									i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
//									i$body.add("sides", sides);
									i$resPre.createDmsHstRecs(isonMsg);
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Saved");
									return isonMsg;

								} catch (Exception e) {
									e.printStackTrace();
								}
							}

							if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRDOC") && I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
								try {
									i$body = isonMsg.getAsJsonObject("i-body");
                                    String fldId = i$body.get("parentFolderId").getAsString();
                                    JsonObject docFilter = new JsonObject();
									JsonObject doc = new JsonObject();
                                    // #MSA00003 starts
                                    JsonArray urlList = i$body.get("FileUrlToken").getAsJsonArray();
                                    JsonArray passProtectedDocs = new JsonArray();
                                    
                                    for (int i = 0; i < urlList.size(); i++) {
										String curToken = urlList.get(i).getAsString();
										docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'" + curToken + "'}}").getAsJsonObject());
										docFilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
										projection.addProperty("_id", 0);
										projection.addProperty("documents.$", 1);
										JsonObject docData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", docFilter,projection);
										JsonObject docElement = docData.get("documents").getAsJsonArray().get(0).getAsJsonObject();
										docElement.addProperty("docDel", "Y");
                                        doc.add("documents.$", docElement);
										
										db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", gson.toJson(doc), docFilter, "true","N");//#SRM00030 changes
										
//	                                    // MSA00001 starts
										if (!(fldId.startsWith("LN") || fldId.startsWith("FD") || fldId.startsWith("CP") || fldId.startsWith("FIP") || fldId.startsWith("TL") || fldId.startsWith("MP") || fldId.startsWith("MA")|| fldId.startsWith("ML")|| fldId.startsWith("LU"))) {
											if (!I$utils.$iStrFuzzyMatch( docData.get("documents").getAsJsonArray().get(0).getAsJsonObject().get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can Amend the record");
												return isonMsg;
											}
										}
										if(i$body.has("fileKey")) {
                                    		if (!db$Ctrl.db$DocPassVerify(isonMsg)) {
                								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");//#TKS00015 changes
                								return isonMsg;
                							}
                                    	}
										JsonObject fileData = db$Ctrl.db$GetRow("fs.files", "{'metadata.FileUrlToken':'" + curToken + "','metadata.isCurrVer':'Y'}");
										JsonObject mtdta = fileData.get("metadata").getAsJsonObject();
										if (mtdta.has("isPswrdPrctd") && urlList.size() > 1) {
											if (mtdta.get("isPswrdPrctd").getAsBoolean()) {
												passProtectedDocs.add(mtdta.get("FileName").getAsString());
												continue;
											}
										}
										i$body = isonMsg.getAsJsonObject("i-body");
										JsonObject filter = new JsonObject();
										filter.addProperty("folderId", i$body.get("parentFolderId").getAsString());
										filter.addProperty("isCurrVer", "Y");

										String i$Doc = "{'documents':{'FileUrlToken': " + curToken + "}}";
//										db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, filter, "false","pull");
										
										JsonObject fdata = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filter);
										// #TKS00004 changes
										JsonObject fsFilter = new JsonObject();
										fsFilter.addProperty("metadata.FileUrlToken", curToken);
										JsonObject fsUpdate = new JsonObject();
										fsUpdate.addProperty("metadata.isCurrVer", "N");
										db$Ctrl.db$UpdateRow("fs.files", fsUpdate, fsFilter);
										filter = new JsonObject();
										filter.addProperty("FileUrlToken", curToken);//#PAV00008 Changes
										filter.addProperty("isCurrVer", "Y");
										int iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_DMS_FAVOURITE", filter);//#PAV00008 Changes
										if(iRowCnt >= 1) {
											JsonObject updateObj = new JsonObject();
											updateObj.addProperty("isCurrVer", "N");
											db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE" , updateObj , filter);//#PAV00008 Changes
										}
										db$Ctrl.db$logDmsHstry(isonMsg); // #YPR00099 Changes
										int delDocCount = 0; //#PAV00006 changes starts 
										for(int j=0; j<fdata.get("documents").getAsJsonArray().size(); j++){
											try {//SKG00020 changes
												if(!I$utils.$iStrFuzzyMatch(fdata.get("documents").getAsJsonArray().get(j).getAsJsonObject().get("docDel").getAsString(), "Y")) {
													delDocCount++;//SKG00020 changes
													break;//SKG00020 changes
												}
											}catch(Exception e) {//SKG00020 changes
												delDocCount++;//SKG00020 changes
												break;//SKG00020 changes
											}
										}
//										if (fdata.get("documents").getAsJsonArray().size() == 0) {
										if (delDocCount == 0) {
											filter = new JsonObject();
											filter.addProperty("folderId", i$body.get("parentFolderId").getAsString());
											filter.addProperty("isCurrVer", "Y");
											i$Doc = "{'containDocs': false}";
											db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, filter, "false","N");
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Document Successfully Deleted");
//											return isonMsg; // SKG00019 changes
										} //#PAV00006 changes ends
										
									}// #MSA00003 ends
                                    if(passProtectedDocs.size() > 0) {
                                    	i$body.add("FileNames" , passProtectedDocs);
                            			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
                            			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "The below files are password protected , please remove passsword to ##opr## documents");
                                    }else
                                    	isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Document Successfully Deleted");
                                        trashOp(isonMsg);  //#SRM00025 changes
									return isonMsg;
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							// #TKS0002 starts
							if (I$utils.$iStrFuzzyMatch(ScrId, "ODSCRDOC") && I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
								try {
									i$body = isonMsg.getAsJsonObject("i-body");
									JsonObject docFilter = new JsonObject();

									docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'"+ i$body.get("FileUrlToken").getAsString() + "'}}").getAsJsonObject());

//							        docFilter.addProperty("workspaceId",i$body.get("workspaceId").getAsString());
									//projection.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'"+ i$body.get("FileUrlToken").getAsString() + "'}}").getAsJsonObject()); // #YPR00095 Starts
									projection.addProperty("documents.$", 1);
									
									JsonObject docData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", docFilter, projection);
									String initiator = docData.get("documents").getAsJsonArray().get(0).getAsJsonObject().get("initiator").getAsString();
									Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
							        Matcher mat = pattern.matcher(initiator);
							        if(mat.matches()) {
							        	JsonObject usrFltr = new JsonObject();
							        	JsonObject usrProjection = new JsonObject();
							        	usrFltr.addProperty("EmpMail", initiator);
							        	usrFltr.addProperty("active", "A");
							        	usrFltr.addProperty("authStat", "A");
							        	usrProjection.addProperty("userId" , 1);
							        	JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", usrFltr, usrProjection);
							        	if (!I$utils.$iStrFuzzyMatch(usrData.get("userId").getAsString(),IResManipulator.iloggedUser.get())) {
							        		isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can Amend the record");
											return isonMsg;
							        	}
							        }else {
										if (!I$utils.$iStrFuzzyMatch(docData.get("documents").getAsJsonArray().get(0).getAsJsonObject().get("initiator").getAsString(),IResManipulator.iloggedUser.get())) {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can Amend the record");
											return isonMsg;
										}
							        }
									String fileUrlToken = i$body.get("FileUrlToken").getAsString();
									JsonObject filter = new JsonObject();
									JsonObject doc = new JsonObject();
									JsonObject updateFilter = new JsonObject();
									JsonObject proj = new JsonObject();
									JsonObject elem = new JsonObject();
									JsonObject document = new JsonObject();
									JsonObject updSetDta = new JsonObject();
									String arrayFilter = null;

									// #YPR00095 Starts
									updateFilter.addProperty("folderId", i$body.get("folderId").getAsString());
									updateFilter.addProperty("isCurrVer", "Y");
									updateFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'" + fileUrlToken + "'}}").getAsJsonObject());
									proj.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'" + fileUrlToken + "'}}").getAsJsonObject());
									proj.addProperty("folderId", 1);
									proj.addProperty("containDocs", 1);
									proj.addProperty("workspaceId", 1);
									proj.addProperty("parentFolderId", 1);
									proj.addProperty("folderLevel", 1);
									proj.addProperty("folderName", 1);
									JsonObject foldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", updateFilter, proj);
									Integer MaxVer;
									MaxVer = foldrData.get("documents").getAsJsonArray().get(0).getAsJsonObject().get("verNo").getAsInt() + 1;
									document.addProperty("documents.$[i].verNo", MaxVer);
									// #YPR00100 Starts
									if (i$body.has("FileName")) {
										String fileName = i$body.get("FileName").getAsString();
										arrayFilter = "[{'j.FileUrlToken':'" + fileUrlToken + "'},{'i.FileUrlToken':'"+ fileUrlToken + "'}]";
										if (!i$body.has("fileKey")) {
											JsonObject mtdta = db$Ctrl.db$GetRow("fs.files","{'metadata.FileUrlToken':'" + fileUrlToken+ "','metadata.isCurrVer':'Y'}").get("metadata").getAsJsonObject();
											if (mtdta.has("isPswrdPrctd")) {
												if (mtdta.get("isPswrdPrctd").getAsBoolean()) {
													isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"File is Password Protected");
													return isonMsg;
												} else {
													document.addProperty("documents.$[i].FileName", fileName);
													document.addProperty("documents.$[].sides.$[j].FileName", fileName);
													updSetDta.addProperty("metadata.FileName", fileName);
												}
											} else {
												document.addProperty("documents.$[i].FileName", fileName);
												document.addProperty("documents.$[].sides.$[j].FileName", fileName);
												updSetDta.addProperty("metadata.FileName", fileName);
											}
										} else {
											if (db$Ctrl.db$DocPassVerify(isonMsg)) {
												document.addProperty("documents.$[i].FileName", fileName);
												document.addProperty("documents.$[].sides.$[j].FileName", fileName);
												updSetDta.addProperty("metadata.FileName", fileName);
											} else {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Incorrect File Password");
												return isonMsg;
											}
										}
									} else if (i$body.has("fileKey") && (i$body.has("setFileKey"))) {
										if (!I$utils.$iStrBlank(I$utils.fetchValueFromJsonObj(i$body, "fileKey", ""))&& i$body.get("setFileKey").getAsBoolean()) {
											document.addProperty("documents.$[i].isPswrdPrctd", true);
											updSetDta.addProperty("metadata.fileKey",I$impactoUtil.encrypt(i$body.get("fileKey").getAsString()));
											updSetDta.addProperty("metadata.isPswrdPrctd", true);
											arrayFilter = "[{'i.FileUrlToken':'" + fileUrlToken + "'}]";
											//MSA00004 starts
											db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_FOLDERS", gson.toJson(document),updateFilter, "false", "N", arrayFilter);
											filter.addProperty("metadata.FileUrlToken", fileUrlToken);
											filter.addProperty("metadata.isCurrVer", "Y");
											updSetDta.addProperty("metadata.verNo", MaxVer);
											db$Ctrl.db$UpdateRow("fs.files", updSetDta, filter, "false");																						
											try {//#SKG00005 starts
												filter = new JsonObject();
												filter.addProperty("FileUrlToken", fileUrlToken);
												 if(db$Ctrl.db$GetCountI("ICOR_M_DMS_FAVOURITE",filter) > 0) {
													 updSetDta.addProperty("isPswrdPrctd", true);
													 db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", updSetDta, filter, "false");
												 }}
												catch(Exception e) {
												}//	#SKG00005 end 										
											db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes

											if (i$body.has("setFileKey") && i$body.get("setFileKey").getAsBoolean()) {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Password Added Successfully");
											} else {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Document Successfully Updated");
											}
											//MSA00004 ends
										} else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Failed to set File Password");
											return isonMsg;
										}
									} else if (i$body.has("fileKey") && (i$body.has("remFileKey"))) {
										if (i$body.get("remFileKey").getAsBoolean()) {
											if (db$Ctrl.db$DocPassVerify(isonMsg)) { // #SRM00012 changes
												if (I$utils.$iStrFuzzyMatch(docData.get("documents").getAsJsonArray().get(0).getAsJsonObject().get("initiator").getAsString(),IResManipulator.iloggedUser.get())) {
													document.addProperty("documents.$[i].isPswrdPrctd", false);
													updSetDta.add("metadata.fileKey", null);
													updSetDta.addProperty("metadata.isPswrdPrctd", false);
													arrayFilter = "[{'i.FileUrlToken':'" + fileUrlToken + "'}]";
													//MSA00004 starts
													db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_FOLDERS",gson.toJson(document), updateFilter, "false", "N",arrayFilter);
													filter.addProperty("metadata.FileUrlToken", fileUrlToken);
													filter.addProperty("metadata.isCurrVer", "Y");
													updSetDta.addProperty("metadata.verNo", MaxVer);
													db$Ctrl.db$UpdateRow("fs.files", updSetDta, filter, "false");
													db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes
													if (i$body.has("remFileKey")&& i$body.get("remFileKey").getAsBoolean()) {
														isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Password Removed Successfully");
													} else {
														isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Document Successfully Updated");
													}
												} else {
													isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can remove file password");
													return isonMsg;
												}
											
										} else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Incorrect File Password");
											return isonMsg;
										}
									  }
										//MSA00004 ends
										//#NK00005 starts
									} else if (i$body.has("fileKey") && (i$body.has("UpdateFileKey"))) {
										try {
											if (!I$utils
													.$iStrBlank(I$utils.fetchValueFromJsonObj(i$body, "fileKey", ""))
													&& i$body.get("UpdateFileKey").getAsBoolean()) {
												document.addProperty("documents.$[i].isPswrdPrctd", true);
												updSetDta.addProperty("metadata.fileKey",
														I$impactoUtil.encrypt(i$body.get("fileKey").getAsString()));
												updSetDta.addProperty("metadata.isPswrdPrctd", true);
												arrayFilter = "[{'i.FileUrlToken':'" + fileUrlToken + "'}]";

												db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_FOLDERS", gson.toJson(document),
														updateFilter, "false", "N", arrayFilter);
												filter.addProperty("metadata.FileUrlToken", fileUrlToken);
												filter.addProperty("metadata.isCurrVer", "Y");
												updSetDta.addProperty("metadata.verNo", MaxVer);
												db$Ctrl.db$UpdateRow("fs.files", updSetDta, filter, "false");
												try {
													filter = new JsonObject();
													filter.addProperty("FileUrlToken", fileUrlToken);
													if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FAVOURITE", filter) > 0) {
														updSetDta.addProperty("isPswrdPrctd", true);
														db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", updSetDta, filter,
																"false");
													}
												} catch (Exception e) {
												}
												db$Ctrl.db$logDmsHstry(isonMsg);

												if (i$body.has("UpdateFileKey")
														&& i$body.get("UpdateFileKey").getAsBoolean()) {
													isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
															"Password Updated Successfully");
												} else {
													isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
															"Document Successfully Updated");
												}
											} else {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
														"Failed to Update File Password");
												return isonMsg;
											}
										} catch (Exception e) {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"Failed to Update File Password");
											return isonMsg;
										}
										//#NK00005 ends
										//#NK00006 Starts
									}else if (i$body.has("fileKey") && (i$body.has("ChangeFileKey"))) {
										try {
											if (i$body.has("fileKey")) {
												if (!db$Ctrl.db$DocPassVerify(isonMsg)) {
													isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
															"Incorrect File Password");
													return isonMsg;
												}
												try {
													if (!I$utils.$iStrBlank(
															I$utils.fetchValueFromJsonObj(i$body, "fileKey", ""))
															&& i$body.get("ChangeFileKey").getAsBoolean()) {
														document.addProperty("documents.$[i].isPswrdPrctd", true);
														updSetDta.addProperty("metadata.fileKey", I$impactoUtil
																.encrypt(i$body.get("NewfileKey").getAsString()));
														updSetDta.addProperty("metadata.isPswrdPrctd", true);
														arrayFilter = "[{'i.FileUrlToken':'" + fileUrlToken + "'}]";

														db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_FOLDERS",
																gson.toJson(document), updateFilter, "false", "N",
																arrayFilter);
														filter.addProperty("metadata.FileUrlToken", fileUrlToken);
														filter.addProperty("metadata.isCurrVer", "Y");
														updSetDta.addProperty("metadata.verNo", MaxVer);
														db$Ctrl.db$UpdateRow("fs.files", updSetDta, filter, "false");
														try {
															filter = new JsonObject();
															filter.addProperty("FileUrlToken", fileUrlToken);
															if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FAVOURITE",
																	filter) > 0) {
																updSetDta.addProperty("isPswrdPrctd", true);
																db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", updSetDta,
																		filter, "false");
															}
														} catch (Exception e) {
														}
														db$Ctrl.db$logDmsHstry(isonMsg);

														if (i$body.has("ChangeFileKey")
																&& i$body.get("ChangeFileKey").getAsBoolean()) {
															isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
																	"Password Changed Successfully");
														} else {
															isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
																	"Document Successfully Updated");
														}
													} else {
														isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
																"Failed to Change File Password");
														return isonMsg;
													}
												} catch (Exception e) {
													isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
															"Failed to Change File Password");
													return isonMsg;
												}

											}
										} catch (Exception e) {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"Failed to Change File Password");
											return isonMsg;
										}
										//#NK00006 ends
									} else {
                                            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"OPERATION NOT ALLOWED");
                                            return isonMsg;
                                       }
                                       // #YPR00100 Ends
									return isonMsg;
                                  
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Document Updation Failed");
									return isonMsg;
								}
								// #TKS0002 ends
							}
							// #TKS00001 ends
						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
							return isonMsg;
						}
					}
				} else {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
					return isonMsg;
				}
			} catch (Exception excep) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
						excep.getMessage().toString());
				excep.printStackTrace();
				return isonMsg;
			}
		}

		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};

	// #YPR00094 Ends

	// #BVB00033 Starts
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		// JsonObject argJson = new JsonObject();

		try {
			IDocumentsController i$genAppCon = new IDocumentsController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "DMSLDOC") && I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "delDoc")) {
				return delDocApi(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "FLMDUPDT") && I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "UPDATE")) {
				return docUpdate(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "ODSCRDOC")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "AUTH")) {
				return docAuth(isonMsg); //#MSA00002 changes
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "ODSFAVDC")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "QUERY")) {
				return docView(isonMsg);//#SRM00013 changes
			}
//			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "SDSTRASH")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "SUMMARY")) {
//				return trashView(isonMsg);//#SRM00025 changes
//			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "ODSMODUP")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "QUERY")) {
				return docModify(isonMsg);//#SRM00026 changes
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OFRFTARW")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "QUERY"))  {
				return folderRestore(isonMsg);//#SRM00030 changes
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "ODSRESTR")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "QUERY")) {
				return delRestore(isonMsg);//#SRM00030 changes
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "DOCRESET")&& I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "RESET")) {
				return docReset(isonMsg);//#SKG00009 changes
			}
//			if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "FABFLUPD") && I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "CREATE")) {
//				return docCreate(isonMsg);
//			}
//			if(I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "ODSTIDOC")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "CREATE")) {
//				return addTagsIndexes(isonMsg);
//			}
			isonMsg = i$genAppCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			// Adding Pre Response Message Handler

			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}
	 //#MSA00002  starts
	public JsonObject docAuth(JsonObject isonMsg) {
		JsonObject i$Body = isonMsg.getAsJsonObject("i-body");
		Gson gson = new GsonBuilder().serializeNulls().create();
		JsonObject docFilter = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject proj = new JsonObject();
		JsonObject i$proj = new JsonObject();
		JsonObject doc = new JsonObject();
		JsonObject i$doc = new JsonObject();
		String authorizer = IResManipulator.iloggedUser.get();
		String authoAt=I$Ioutils.$getISONowTo().replace("T", " ");
		
		docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'"+ i$Body.get("FileUrlToken").getAsString() + "'}}").getAsJsonObject());
		proj.addProperty("documents.$", 1);
		proj.addProperty("_id", 0);
		JsonObject i$Data = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", docFilter,proj);
		JsonObject data =i$Data.get("documents").getAsJsonArray().get(0).getAsJsonObject();
		if (!I$utils.$iStrFuzzyMatch(data.get("initiator").getAsString(),IResManipulator.iloggedUser.get())) {
			int verNo = data.get("verNo").getAsInt()+1;
			data.addProperty("verNo", verNo);
			data.addProperty("authorizer",authorizer);
			data.addProperty("authorizedAt",authoAt);
			data.addProperty("remarks", i$Body.get("remarks").getAsString());//#MVT00092 Changes
			doc.add("documents.$", data);
			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", gson.toJson(doc), docFilter, "false","N");
			//SKG00011 start
			JsonObject fltr = new JsonObject();
			JsonObject upObj = new JsonObject();
			fltr.addProperty("FileUrlToken", i$Body.get("FileUrlToken").getAsString());
			upObj.addProperty("authorizer",authorizer);
			upObj.addProperty("remarks", i$Body.get("remarks").getAsString());
			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FAVOURITE", gson.toJson(upObj), fltr, "false","N");
			// SKG00011 end
			filter.addProperty("metadata.FileUrlToken",i$Body.get("FileUrlToken").getAsString());
			i$proj.addProperty("metadata", 1);
			i$proj.addProperty("_id", 0); 
			JsonObject Data = db$Ctrl.db$GetRow("fs.files",filter,i$proj);
			JsonObject i$data =Data.get("metadata").getAsJsonObject();
			i$data.addProperty("authorizer",authorizer);
			i$data.addProperty("authorizedAt",authoAt);
			i$data.addProperty("verNo", verNo);
			i$data.addProperty("remarks", i$Body.get("remarks").getAsString());// #SKG00006
			i$doc.add("metadata", i$data);
			db$Ctrl.db$UpdateRowOperator("fs.files", gson.toJson(i$doc), filter, "false","N");
			i$Body.addProperty("authorizer",authorizer);
			i$Body.addProperty("authorizedAt",authoAt);	
			i$Body.addProperty("verNo",data.get("verNo").getAsInt());	
			
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Record Authorized Successfully");
		   }
		else {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Initiator and Authorizer can not be Same");
		}
		isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$Body);
		db$Ctrl.db$logDmsHstry(isonMsg);//SKG00024
		return isonMsg;
	}
	//#MSA00002  ends
	//#SRM00026 changes start
	public JsonObject docModify(JsonObject isonMsg) {
		try {
		JsonObject i$body = isonMsg.getAsJsonObject("i-body");
		JsonObject filter = new JsonObject();
		JsonObject fltr = new JsonObject();
		JsonObject proj = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject doc = new JsonObject();
		JsonObject i$doc = new JsonObject();
		int maxVer1;
		
		
		//#SKG00014 
		if(i$body.has("fileKey")) {
            if (!db$Ctrl.db$DocPassVerify(isonMsg)) {
                isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");//#TKS00015 changes
                return isonMsg;
            }else {
            	i$body.addProperty("key", true);//NK00004 changes
            	return isonMsg;
            }
        }//#SKG00014 
		Gson gson = new GsonBuilder().serializeNulls().create();
		String modifier = IResManipulator.iloggedUser.get();
		String modifiedAt=I$Ioutils.$getISONowTo().replace("T", " ");
		fltr.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'"+ i$body.get("FileUrlToken").getAsString() + "'}}").getAsJsonObject());
		projection.addProperty("documents.$", 1);
		projection.addProperty("_id", 0);
        filter.addProperty("metadata.FileUrlToken", i$body.get("FileUrlToken").getAsString());
	    i$Projection.addProperty("metadata", 1);
	    i$Projection.addProperty("_id", 0);
		JsonObject dataFsFiles = db$Ctrl.db$GetRow("fs.files", filter, i$Projection);
		//NK00068 starts
//		if (!(I$utils.$iStrFuzzyMatch(dataFsFiles.get("metadata").getAsJsonObject().get("initiator").getAsString(),IResManipulator.iloggedUser.get())) && (I$utils.$iStrFuzzyMatch(dataFsFiles.get("metadata").getAsJsonObject().get("workspaceId").getAsString(),"IWRKSP469371"))) {
//			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can amend records");
//			return isonMsg;
//		} //NK00068 ends
		JsonObject dataFolder = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", fltr, projection);
		JsonObject documents = dataFolder.get("documents").getAsJsonArray().get(0).getAsJsonObject();
		if (i$body.has("tags")) {
			i$doc.add("metadata.tags", i$body.get("tags").getAsJsonArray());
			documents.add("tags", i$body.get("tags").getAsJsonArray());
		} 
		if (i$body.has("FileName")) {
			i$doc.addProperty("metadata.FileName", i$body.get("FileName").getAsString());
			documents.addProperty("FileName", i$body.get("FileName").getAsString());
			documents.get("sides").getAsJsonArray().get(0).getAsJsonObject().addProperty("FileName", i$body.get("FileName").getAsString());
		}
		if (i$body.has("remarks")) {
			documents.addProperty("remarks", i$body.get("remarks").getAsString());
			i$doc.addProperty("metadata.remarks", i$body.get("remarks").getAsString());
		} 
//		docData = dataFolder.get("documents").getAsJsonArray().get(0).getAsJsonObject();
		documents.addProperty("verNo", documents.get("verNo").getAsInt() + 1);
		documents.add("UpldSvrDateTime", i$ResM.adddate(new Date()));
		documents.addProperty("modifier",modifier);
		documents.addProperty("modifiedAt",modifiedAt);
		doc.add("documents.$", documents);
		db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", gson.toJson(doc), fltr, "false","N");
		
		JsonObject i$data = dataFsFiles.get("metadata").getAsJsonObject();
		maxVer1 = i$data.get("verNo").getAsInt() + 1;
		i$doc.addProperty("metadata.verNo", maxVer1);
		i$doc.addProperty("metadata.modifier",modifier); 
		i$doc.addProperty("metadata.modifiedAt",modifiedAt);
		db$Ctrl.db$UpdateRowOperator("fs.files", gson.toJson(i$doc), filter, "false","N");
	
		JsonObject query = new JsonObject();
		query.addProperty("documents.FileUrlToken", i$body.get("FileUrlToken").getAsString());
		proj.addProperty("_id", 0);
		JsonObject fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", query, proj);// to retrieve the data
		i$body.addProperty("logHistory", true);
		isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
		db$Ctrl.db$logDmsHstry(isonMsg);
		
		if(fldrData == null) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Document cannot be modified");
			return isonMsg;
		} else {
		isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Document modified successfully");
		//isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,fldrData);//NK00004 changes
		return isonMsg;
		}
		}
		catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Document cannot be modified");
			return isonMsg;		}
//		//dms folder and fs.files
	} // #SRM00026 changes end
	//#SRM00013 changes start
	public JsonObject docView(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
			i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			String DocNo = i$body.get("LinkedCustNo").getAsString();
			JsonObject data = new JsonObject();
			JsonObject data1 = new JsonObject();
			filter.addProperty("metadata.LinkedCustNo", DocNo);
			data = db$Ctrl.db$GetRow("fs.files", filter);
			data1 = data.get("metadata").getAsJsonObject();
			if(data1 != null) {
				i$body.add("Data",data1);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"No such document number exist");
				return isonMsg;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}
	//#SRM00013 ends
	// #SRM00025 starts
	public JsonObject trashOp(JsonObject isonMsg) {
		try {		
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
            JsonObject filter = new JsonObject();
            JsonObject projection = new JsonObject();
            JsonArray urlList = i$body.get("FileUrlToken").getAsJsonArray(); //#SRM00028 changes starts
            
            for (int i = 0; i < urlList.size(); i++) { 
				String curToken = urlList.get(i).getAsString();
	            filter.addProperty("metadata.FileUrlToken", curToken);
	            filter.addProperty("metadata.isCurrVer", "N");
	            projection.addProperty("_id",0);
	            JsonObject updateObj = new JsonObject();
	            JsonObject appFld = db$Ctrl.db$GetRow("fs.files", filter, projection);
	            //appFld.get("metadata").getAsJsonObject().addProperty("initiator", IResManipulator.iloggedUser.get());
	            int MaxVer = appFld.get("metadata").getAsJsonObject().get("verNo").getAsInt() + 1;
	            updateObj.addProperty("metadata.initiator", IResManipulator.iloggedUser.get());
	            updateObj.addProperty("metadata.verNo", MaxVer);
	            updateObj.addProperty("metadata.docDel", "Y");
	    		//appFld.get("metadata").getAsJsonObject().addProperty("verNo", MaxVer); //#SRM00030 changes
	    		appFld.get("metadata").getAsJsonObject().addProperty("docDel", "Y"); //#SRM00030 changes
	    		filter.remove("metadata.isCurrVer");
	    		db$Ctrl.db$UpdateRow("fs.files", updateObj, filter);
	    		
	    		
	    		appFld.get("metadata").getAsJsonObject().addProperty("delItemId", appFld.get("metadata").getAsJsonObject().get("DocNo").getAsString());//SKG00021 changes
	    		appFld.get("metadata").getAsJsonObject().addProperty("delItemName", appFld.get("metadata").getAsJsonObject().get("FileName").getAsString());//SKG00021 changes

	    		db$Ctrl.db$InsertRow("ICOR_M_DMS_TRASH", appFld.get("metadata").getAsJsonObject()); 
            } // SRM00028 changes end

			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Documents added to trash");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}
	
//	public JsonObject trashView(JsonObject isonMsg) {
//		try {
//			String SOpr1 = i$ResM.getOpr1(isonMsg);
//			String SOpr2 = i$ResM.getOpr2(isonMsg);
//			Gson gson = new GsonBuilder().serializeNulls().create();
//			JsonObject i$Match = i$ResM.getMatch(isonMsg);
//			JsonObject i$Projection = new JsonObject();
//			JsonParser parser = new JsonParser();
//			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
//
//			if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
//				int iRowCnt = 0;
//				JsonObject db$res = null;
//				int intPgNo = 0;
//				int intRecs = 0;
//				String sort = "{'_id':-1}";
//				Integer i$MaxRow = -1;
//
//				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
//				i$Projection.addProperty("_id", 0);
//				try {
//					if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
//						if (i$Match != null) {
//							i$Match.addProperty("isCurrVer", "N");
//							i$Match.addProperty("docDel", "Y"); //#SRM00030 changes
//							iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_DMS_TRASH", isonMsg, gson.toJson(i$Match));
//							db$res = db$Ctrl.db$GetRows$Sort("ICOR_M_DMS_TRASH", isonMsg, i$MaxRow, i$Match,
//									i$Projection, intPgNo, intRecs, sort);
//							db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
//									i$Projection, intPgNo, intRecs, sort);
//						}
//						else {
//							i$Match = new JsonObject();
//							i$Match.addProperty("isCurrVer", "N");
//							i$Match.addProperty("docDel", "Y");
//							iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_DMS_TRASH", isonMsg, gson.toJson(i$Match));
//							db$res = db$Ctrl.db$GetRows$Sort("ICOR_M_DMS_TRASH", isonMsg, i$MaxRow, i$Match,
//									i$Projection, intPgNo, intRecs, sort);
//						}
//					}
//				} catch (Exception e) {
//				}
//				i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
//				i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");
//
//				i$body.addProperty("iRowCnt", iRowCnt);
//				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
//				return isonMsg;
//			}
//		} catch (Exception e) {
//		}
//
//		return isonMsg;
//	}
	// #SRM00025 changes end
	//#NK00069 starts
	public JsonObject getFolderIds(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			String FoldId = i$body.get("folderId").getAsString();
			String FoldLevel = i$body.get("folderLevel").getAsString();
			JsonObject restorefilter = new JsonObject();
			JsonArray foldIdArray = new JsonArray();
			restorefilter.addProperty("folderId", FoldId);
			restorefilter.addProperty("folderLevel", FoldLevel);
			JsonObject Foldres = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS_RESTORE", restorefilter);
			foldIdArray.add(FoldId);
			if (Foldres.has("folders")) {
				JsonArray subfolders = Foldres.getAsJsonArray("folders");
				for (int i = 0; i < subfolders.size(); i++) {
					JsonObject subfolder1 = subfolders.get(i).getAsJsonObject();
					foldIdArray.add(subfolder1.get("folderId").getAsString());
					if (subfolder1.has("folders")) {
						JsonArray subfolders2 = subfolder1.getAsJsonArray("folders");
						for (int j = 0; j < subfolders2.size(); j++) {
							JsonObject subfolder3 = subfolders2.get(j).getAsJsonObject();
							foldIdArray.add(subfolder3.get("folderId").getAsString());
						}
					}
				}
			}
			i$body.add("FolderIDs", foldIdArray);
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to fetch the folderIds");
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject folderRestore(JsonObject isonMsg) {
		try {
			Gson gson = new Gson();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
//			JsonObject up$ = new JsonObject();
			String FoldId = i$body.get("delItemId").getAsString();
			i$body.addProperty("folderId", FoldId);
			String FoldLevel = i$body.get("folderLevel").getAsString();
			
			JsonObject fav$update = getFolderIds(isonMsg);
			JsonArray foldIDs = fav$update.getAsJsonObject("i-body").get("FolderIDs").getAsJsonArray();
			for (int i = 0; i < foldIDs.size(); i++) {
				try {
					JsonObject filt1 = new JsonObject();
					filt1.addProperty("folderId", foldIDs.get(i).getAsString());
					filt1.addProperty("Favourites", "N");
					filt1.addProperty("FoldRestor", "Y");
					JsonObject res1 = db$Ctrl.db$GetRow("ICOR_M_DMS_FAVOURITE", filt1);
					if (!I$utils.$isNull(res1)) {
						JsonObject i$favourite = new JsonObject();
						i$favourite.addProperty("isCurrVer", "Y");
						i$favourite.addProperty("Favourites", "Y");
						i$favourite.addProperty("FoldRestor", "N");
						db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", i$favourite,filt1);
					}
					
					JsonObject filt = new JsonObject();   
					JsonObject res = new JsonObject();  
					filt.addProperty("folderId", foldIDs.get(i).getAsString());
					filt.addProperty("Archive", "N");
					filt.addProperty("isCurrVer", "N");
					filt.addProperty("FoldRestor", "Y");
					res = db$Ctrl.db$GetRow("ICOR_M_DMS_ARCHIVES", filt);
					if (!I$utils.$isNull(res)) {
						JsonObject i$Archive = new JsonObject();
						i$Archive.addProperty("Archive", "Y");
						i$Archive.addProperty("isCurrVer", "Y");
						i$Archive.addProperty("FoldRestor", "N");
						db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES", i$Archive, filt);
					}
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to restore the folder");
				}
			}
			JsonObject fold$Info = new JsonObject();
			fold$Info.addProperty("folderId", FoldId);
			fold$Info.addProperty("isCurrVer", "N");
			db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", fold$Info);
			JsonObject fold$Update = new JsonObject();
			fold$Update.addProperty("isCurrVer", "Y");
			db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS", fold$Update, fold$Info);
			
			JsonObject trash$filter = new JsonObject();
			trash$filter.addProperty("delItemId", FoldId);
			trash$filter.addProperty("docDel", "Y");
			trash$filter.addProperty("isCurrVer", "N");
			JsonObject Up$trash = new JsonObject();
			Up$trash.addProperty("docDel", "N");
			Up$trash.addProperty("isCurrVer", "Y");
			db$Ctrl.db$UpdateRow("ICOR_M_DMS_TRASH", Up$trash, trash$filter);
			
			JsonObject restorefilter = new JsonObject();
			restorefilter.addProperty("folderId", FoldId);
			restorefilter.addProperty("folderLevel", FoldLevel);
			JsonObject Foldres = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS_RESTORE", restorefilter);

			JsonObject queryfilter = new JsonObject();
			String flpath;
			String arrFilter;
			String i$Doc = null;
			queryfilter.addProperty("workspaceId", Foldres.get("workspaceId").getAsString());
			queryfilter.addProperty("isCurrVer", "Y");
			if (Integer.parseInt(Foldres.get("folderLevel").getAsString()) >= 2) {
				flpath = "folders.$[].".repeat(Integer.parseInt(Foldres.get("folderLevel").getAsString()) - 2) + "folders.$[j].folders";
				arrFilter = "[{'j.folderId': '" + i$body.get("parentFolderId").getAsString() + "'}]";
			} else {
				flpath = "folders";
				arrFilter = "";
			}
			JsonObject currObj = new JsonObject();
			JsonObject fold$insert = new JsonObject();
			if (Integer.parseInt(Foldres.get("folderLevel").getAsString()) >= 2) {
				
				fold$insert.addProperty("folderId", Foldres.get("folderId").getAsString());
				fold$insert.addProperty("folderName", Foldres.get("folderName").getAsString());
				fold$insert.addProperty("workspaceId", Foldres.get("workspaceId").getAsString());
				fold$insert.addProperty("folderLevel", Foldres.get("folderLevel").getAsString());
				fold$insert.addProperty("containDocs", Foldres.get("containDocs").getAsBoolean());
				if(Foldres.has("folders")) {
					fold$insert.add("folders", Foldres.get("folders").getAsJsonArray());
				}else {
					fold$insert.add("folders", new JsonArray());
				}				currObj.add(flpath, fold$insert);
				i$Doc = gson.toJson(currObj);
			} else {
				fold$insert.addProperty("folderId", Foldres.get("folderId").getAsString());
				fold$insert.addProperty("folderName", Foldres.get("folderName").getAsString());
				fold$insert.addProperty("workspaceId", Foldres.get("workspaceId").getAsString());
				fold$insert.addProperty("folderLevel", Foldres.get("folderLevel").getAsString());
				fold$insert.addProperty("containDocs", Foldres.get("containDocs").getAsBoolean());
				if(Foldres.has("folders")) {
					fold$insert.add("folders", Foldres.get("folders").getAsJsonArray());
				}else {
					fold$insert.add("folders", new JsonArray());
				}
				currObj.add(flpath, fold$insert);
				i$Doc = gson.toJson(currObj);
			}
			if (!I$utils.$iStrBlank(arrFilter)) {
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "push", arrFilter);
			} else {
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "push");
			}
			JsonObject restore = new JsonObject();
			restore.addProperty("folderId", FoldId);
			restore.addProperty("folderLevel",FoldLevel);
			db$Ctrl.db$Remove("ICOR_M_DMS_FOLDERS_RESTORE", restore);
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to restore the Folder");
			return isonMsg;
		}
		isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Folder Successfully Restored");
		return isonMsg;
	}
	//#NK00069 ends 
	//#SRM00030 changes start
	public JsonObject delRestore(JsonObject isonMsg) {
		try {
			//NK00010 starts
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			
			if(i$body.has("fileKey")) {
        		if (!db$Ctrl.db$docpassverifytrash(isonMsg)) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");//#TKS00015 changes
					return isonMsg;
				}else {
					i$body.addProperty("key", true);
	            	return isonMsg;
				}
        	}
			//NK00010 ends
			//#NK00076 starts
			String perentfolderid = i$body.get("parentFolderId").getAsString();
			String workspaceid = i$body.get("workspaceId").getAsString();
			JsonArray urlList = i$body.get("FileUrlToken").getAsJsonArray();
			Gson gson = new GsonBuilder().serializeNulls().create();
			for (int i=0; i<urlList.size(); i++) {
				try {
					JsonObject filter = new JsonObject();
					JsonParser parser = new JsonParser();
					// #NK00008 Starts
					filter.addProperty("FileUrlToken", urlList.get(i).getAsString());
					filter.addProperty("docDel", "Y");
					JsonObject res = db$Ctrl.db$GetRow("ICOR_M_DMS_TRASH", filter);
					if (!I$utils.$isNull(res)) {
						if (!I$utils.$iStrFuzzyMatch(res.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Only initiator can Restore the record");
							return isonMsg;
						}
					}// #NK00008 ends
					filter = new JsonObject(); 
					JsonObject projection = new JsonObject();
					String curToken = urlList.get(i).getAsString();
					JsonObject i$favorite = new JsonObject();
					JsonObject i$res = new JsonObject();
					i$favorite.addProperty("FileUrlToken", curToken);
					i$favorite.addProperty("isCurrVer", "N");
					i$favorite.addProperty("Favourites", "Y");
					i$res = db$Ctrl.db$GetRow("ICOR_M_DMS_FAVOURITE", i$favorite);
					if (!I$utils.$isNull(i$res)) {
						JsonObject i$update = new JsonObject();
						i$update.addProperty("isCurrVer", "Y");
						i$update.addProperty("Favourites", "Y");
						db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", i$update, i$favorite);
					}
					filter.addProperty("documents.docDel", "Y");
					filter.addProperty("workspaceId", workspaceid);
					filter.addProperty("folderId", perentfolderid);
					filter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'" + curToken + "'}}").getAsJsonObject());
					projection.addProperty("_id", 0);
					JsonObject appFld = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filter, projection);
					if (!I$utils.$isNull(appFld)) {
						JsonObject up$folder = new JsonObject();
						up$folder.addProperty("documents.$.docDel", "N");
						db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS", up$folder, filter);
					}
					int foldLevel = appFld.get("folderLevel").getAsInt();
					JsonObject sbFldUpdate = new JsonObject();
					JsonArray arrFilter = new JsonArray();
					JsonObject arrFltrObj = new JsonObject();
					if (foldLevel >= 2) {
						if (I$utils.$iStrFuzzyMatch(appFld.get("folderId").getAsString(), i$body.get("parentFolderId").getAsString())) {
							sbFldUpdate.addProperty("folders.$[].".repeat(foldLevel - 1) + "folders.$[a" + i + "].containDocs", true);
							arrFltrObj.addProperty("a" + i + ".folderId", appFld.get("folderId").getAsString());
						}
					} else {
						if (I$utils.$iStrFuzzyMatch(appFld.get("folderId").getAsString(), i$body.get("parentFolderId").getAsString())) {
							sbFldUpdate.addProperty("folders.$[i].containDocs", true);
							arrFltrObj.addProperty("i.folderId", appFld.get("folderId").getAsString());
						}
					}
					if (!I$utils.$isNull(arrFltrObj)) {
						arrFilter.add(arrFltrObj);
					}
					JsonObject workspaceFilter = new JsonObject();
					workspaceFilter.addProperty("workspaceId", workspaceid);
					workspaceFilter.addProperty("isCurrVer", "Y");
					db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", gson.toJson(sbFldUpdate), workspaceFilter, "false", "N", gson.toJson(arrFilter));
					JsonObject fs$filter = new JsonObject();
					JsonObject fsUpdate = new JsonObject();
					fs$filter.addProperty("metadata.FileUrlToken", curToken);
					fs$filter.addProperty("metadata.docDel", "Y");
					fsUpdate.addProperty("metadata.isCurrVer" , "Y");
					fsUpdate.addProperty("metadata.docDel", "N");
					db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , fs$filter);
					JsonObject trash$filter = new JsonObject();
					trash$filter.addProperty("FileUrlToken", curToken);
					trash$filter.addProperty("docDel", "Y");
					JsonObject up$trash = new JsonObject();
					up$trash.addProperty("docDel", "N");
					 db$Ctrl.db$UpdateRow("ICOR_M_DMS_TRASH" , up$trash, trash$filter);

					//#SKG00008 starts
						JsonObject filter2=new JsonObject();
						filter2.addProperty("historyId", curToken);
//						JsonObject filter1 = new JsonObject();
//						filter1.addProperty("metadata.FileUrlToken", curToken);
//						filter1.addProperty("historyId", curToken);
						JsonObject hisupt1=new JsonObject();
						hisupt1.addProperty("active", "A");
						db$Ctrl.db$UpdateRow("fs.files", hisupt1, filter2);//SKG00036
						//#SKG00008 end
				}catch(Exception e) {
					e.printStackTrace();
					logger.debug("Failed To Restore the Document for " + urlList.get(i).getAsString());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Failed To Restore the Document");
					return isonMsg;
				}
			}
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Document Successfully Restored");
            return isonMsg; //#NK00014 ends
			} catch (Exception e) {
				e.printStackTrace();
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Failed To Restore the Document");
				return isonMsg;
			}
		}
//			//#NK00015 Starts //#NK00076 ends
//			JsonObject doc$contains = new JsonObject();
//			doc$contains.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
//			doc$contains.addProperty("folders.folderId", i$body.get("parentFolderId").getAsString());
//			JsonObject up$doc = new JsonObject();
//			up$doc.addProperty("folders.$.containDocs", true);
//			db$Ctrl.db$UpdateRow("ICOR_M_DMS_WORKSPACES", up$doc, doc$contains);
//			up$doc = new JsonObject();
//			up$doc.addProperty("containDocs", true);
//			db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS", up$doc, doc$contains);
//			//#NK00015 ends
//            //NK00014 starts
//			for (int i = 0; i < urlList.size(); i++) {
//				try {
//				JsonParser parser = new JsonParser();
//				JsonObject res = new JsonObject();
//				JsonObject projection = new JsonObject();
//	            JsonObject filter = new JsonObject();
//				//#NK00008 Starts
//				filter.addProperty("FileUrlToken",urlList.get(i).getAsString());
//				filter.addProperty("docDel", "Y");
//				res = db$Ctrl.db$GetRow("ICOR_M_DMS_TRASH", filter);
//				if (!I$utils.$isNull(res)) {
//					if (!I$utils.$iStrFuzzyMatch(res.get("initiator").getAsString(),IResManipulator.iloggedUser.get())) {
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can Restore the record");
//						return isonMsg;
//					}
//				} 
//				filter = new JsonObject(); 
//				String curToken = urlList.get(i).getAsString();
//				filter.addProperty("documents.docDel", "Y");
//				filter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
//				filter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'" + curToken + "'}}").getAsJsonObject());
//				projection.addProperty("_id", 0);
//				JsonObject appFld = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filter, projection);
//				
//				
//				
//				JsonObject arrSearch = I$impactoUtil.objFromArrWithSearch(appFld.getAsJsonArray("documents"), "FileUrlToken", curToken);//#SRM00033
//				JsonArray appArr = appFld.get("documents").getAsJsonArray(); //#SRM00033
//				
//				JsonObject i$favorite = new JsonObject();
//				JsonObject i$res = new JsonObject();
//				i$favorite.addProperty("FileUrlToken", curToken);
//				i$favorite.addProperty("isCurrVer", "N");
//				i$favorite.addProperty("Favourites", "Y");
//				i$res = db$Ctrl.db$GetRow("ICOR_M_DMS_FAVOURITE", i$favorite);
//				if (!I$utils.$isNull(i$res)) {
//					JsonObject i$update = new JsonObject();
//					i$update.addProperty("isCurrVer", "Y");
//					i$update.addProperty("Favourites", "Y");
//					db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", i$update, i$favorite);
//				}
//				if (I$utils.$iStrFuzzyMatch(arrSearch.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
////					//Update docDel in folders collection
////					String workspaceId = i$body.get("workspaceId").getAsString();
////					String folderId = i$body.get("parentFolderId").getAsString();
////					Gson gson = new GsonBuilder().serializeNulls().create();
////					String subDocFilter = "{'$and':[{'folderIdPath':{'$regex':'"+workspaceId+"','$options':'i'}},{'folderIdPath':{'$regex':'"+folderId+"','$options':'i'}}]}";
//					JsonObject docFilter = new JsonObject();
//					docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'" + curToken + "'}}").getAsJsonObject());
//					docFilter.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
//					projection.addProperty("documents.$", 1);
//					JsonObject fsUpdate = new JsonObject();
//					JsonObject filter1 = new JsonObject();
//					JsonObject flt = new JsonObject();
//					JsonObject fltr = new JsonObject();
//					JsonObject tUpdate = new JsonObject();
//					JsonObject prjctn = new JsonObject();
//					JsonObject doc = new JsonObject();
//					arrSearch.addProperty("docDel", "N"); // #SRM00033 changes start
//					for (int j = 0; j < appArr.size(); j++) {
//						try {
//							JsonObject jdata = new JsonObject();
//							jdata = appArr.get(j).getAsJsonObject();
//							if (I$utils.$iStrFuzzyMatch(jdata.get("FileUrlToken").getAsString(), curToken)) {
//								appArr.remove(j);
//								break;
//							}
//						} catch (Exception e) {
//							e.printStackTrace();
//						}
//					}
//					appArr.add(arrSearch);
//					doc.add("documents", appArr); //#SRM00033 ends
//					
//					db$Ctrl.db$UpdateRow("ICOR_M_DMS_FOLDERS" , gson.toJson(doc) , filter, "true");                    
//					filter1.addProperty("metadata.FileUrlToken", curToken);
////					fsUpdate.addProperty("metadata.isCurrVer" , "Y");
////					fsUpdate.addProperty("metadata.docDel", "N");
//					fltr.addProperty("documents.FileUrlToken", curToken);
//					fltr.addProperty("documents.docDel", "N");
//					flt.addProperty("FileUrlToken", curToken);
//					tUpdate.addProperty("docDel", "N");
//					prjctn.addProperty("_id", 0);
//					
//					 db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , filter1);
//					 db$Ctrl.db$UpdateRow("ICOR_M_DMS_TRASH" , tUpdate, flt);
//					
//					//#SKG00008 starts
//					JsonObject filter2=new JsonObject();
//					filter1.addProperty("historyId", urlList.get(i).getAsString());
//					JsonObject hisupt1=new JsonObject();
//					hisupt1.addProperty("active", "A");
//					db$Ctrl.db$UpdateRow("fs.files", hisupt1, filter2);//SKG00036
//					//#SKG00008 end
//				
////					JsonObject resbody = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", fltr, prjctn);
//					
////					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
////							resbody);
//				}
//			}
//				}catch(Exception e) {
//				e.printStackTrace();
//				logger.debug("Failed To Restore the Document for " + urlList.get(i).getAsString());
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Failed To Restore the Document");
//				return isonMsg;
//			}
//			}
//			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Document Successfully Restored");
//            return isonMsg; //#NK00014 ends
//		} catch (Exception e) {
//			e.printStackTrace();
//			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Failed To Restore the Document");
//			return isonMsg;
//		}
//	}
	//#SRM00030 changes endtUpdate.addProperty("docDel", "N");
	//#TKS00012 starts
	public JsonObject createFolder(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
			i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonObject appFld = new JsonObject();
			String date = i$ResM.getOnlydate(new Date());
			String docName = i$body.get("FileName").getAsString();
			String folderName = docName.split("_")[0];
			filter.addProperty("folderId" , folderName);
			filter.addProperty("isCurrVer" , "Y");
			appFld = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filter);
			if(appFld != null) {
				i$body.addProperty("folderId", folderName);
				i$body.addProperty("parentFolderId" , appFld.get("parentFolderId").getAsString());
				i$body.addProperty("workspaceId" , appFld.get("workspaceId").getAsString());
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
				return isonMsg;
			}
			JsonObject folderData = new JsonObject();
			String parentFolderName = i$body.get("LinkedCustNo").getAsString();
//            String userId = IResManipulator.iloggedUser.get();//SKG00035
			folderData.addProperty("roleOrUserType", "");
			folderData.addProperty("scope", "public");
			folderData.addProperty("folderId", folderName);
			folderData.addProperty("folderName", folderName);
			folderData.addProperty("folderDesc", folderName);
			if (I$utils.$iStrFuzzyMatch(parentFolderName, "DKYM")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10276/IFLD10304");
				folderData.addProperty("parentFolderId", "IFLD10304");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DRKYM")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10278/IFLD10309");
				folderData.addProperty("parentFolderId", "IFLD10309");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DRKYML")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10279/IFLD10310");
				folderData.addProperty("parentFolderId", "IFLD10310");
			}  else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DFCIP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10271/IFLD10289");
				folderData.addProperty("parentFolderId", "IFLD10289");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DFIP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10273/IFLD10295");
				folderData.addProperty("parentFolderId", "IFLD10295");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DLINCU")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10280/IFLD10312");
				folderData.addProperty("parentFolderId", "IFLD10312");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DTHP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10274/IFLD10298");
				folderData.addProperty("parentFolderId", "IFLD10298");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DKYCC")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10285");
				folderData.addProperty("parentFolderId", "IFLD10285");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DSDNS")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10287");
				folderData.addProperty("parentFolderId", "IFLD10287");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DRP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10286");
				folderData.addProperty("parentFolderId", "IFLD10286");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DAMLT")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10284");
				folderData.addProperty("parentFolderId", "IFLD10284");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DLOANS")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10275/IFLD10301");
				folderData.addProperty("parentFolderId", "IFLD10301");
			} else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DFD")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10272/IFLD10292");
				folderData.addProperty("parentFolderId", "IFLD10292");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "DPAY")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10277/IFLD10307");
				folderData.addProperty("parentFolderId", "IFLD10307");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "AKYM")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10276/IFLD10303");
				folderData.addProperty("parentFolderId", "IFLD10303");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ARKYM")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10278/IFLD10309");
				folderData.addProperty("parentFolderId", "IFLD10309");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ARKYML")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10272/IFLD10290");
				folderData.addProperty("parentFolderId", "IFLD10290");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ATES")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10273/IFLD10293");
				folderData.addProperty("parentFolderId", "IFLD10293");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "AFCIP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10271/IFLD10288");
				folderData.addProperty("parentFolderId", "IFLD10288");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "AFIP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10273/IFLD10294");
				folderData.addProperty("parentFolderId", "IFLD10294");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ALINCU")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10280/IFLD10311");
				folderData.addProperty("parentFolderId", "IFLD10311");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ATHP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10274/IFLD10297");
				folderData.addProperty("parentFolderId", "IFLD10297");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "AKYCC")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10285");
				folderData.addProperty("parentFolderId", "IFLD10285");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ASDNS")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10287");
				folderData.addProperty("parentFolderId", "IFLD10287");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ARP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10286");
				folderData.addProperty("parentFolderId", "IFLD10286");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "AAMLT")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10284");
				folderData.addProperty("parentFolderId", "IFLD10284");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ALOANS")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10275/IFLD10300");
				folderData.addProperty("parentFolderId", "IFLD10300");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "AFD")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10272/IFLD10291");
				folderData.addProperty("parentFolderId", "IFLD10291");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "APAY")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10277/IFLD10306");
				folderData.addProperty("parentFolderId", "IFLD10306");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IKYM")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10276/IFLD10305");
				folderData.addProperty("parentFolderId", "IFLD10305");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IRKYM")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10278/IFLD10308");
				folderData.addProperty("parentFolderId", "IFLD10308");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IRKYML")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10272/IFLD10292");
				folderData.addProperty("parentFolderId", "IFLD10292");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ITES")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10273/IFLD10295");
				folderData.addProperty("parentFolderId", "IFLD10295");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IFCIP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10271/IFLD10290");
				folderData.addProperty("parentFolderId", "IFLD10290");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IFIP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10273/IFLD10296");
				folderData.addProperty("parentFolderId", "IFLD10296");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ILINCU")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10280/IFLD10313");
				folderData.addProperty("parentFolderId", "IFLD10313");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ITHP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10274/IFLD10299");
				folderData.addProperty("parentFolderId", "IFLD10299");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IKYCC")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10285");
				folderData.addProperty("parentFolderId", "IFLD10285");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ISDNS")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10279/IFLD10313");
				folderData.addProperty("parentFolderId", "IFLD10313");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IRP")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10287");
				folderData.addProperty("parentFolderId", "IFLD10287");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IAMLT")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10270/IFLD10284");
				folderData.addProperty("parentFolderId", "IFLD10284");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "ILOANS")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10275/IFLD10302");
				folderData.addProperty("parentFolderId", "IFLD10302");
			}else if (I$utils.$iStrFuzzyMatch(parentFolderName, "IFD")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10272/IFLD10293");
				folderData.addProperty("parentFolderId", "IFLD10293");
			} else if(I$utils.$iStrFuzzyMatch(parentFolderName, "DLTRREQ")) {	//#MVT00108 changes starts
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10281/IFLD10314");
				folderData.addProperty("parentFolderId", "IFLD10314");
			} else if(I$utils.$iStrFuzzyMatch(parentFolderName, "ILTRREQ")) {
				folderData.addProperty("workspaceId", "IWS10002");
				folderData.addProperty("folderIdPath", "IWS10002/IFLD10281/IFLD10315");
				folderData.addProperty("parentFolderId", "IFLD10315");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Error In Creating Folders");
				return isonMsg;
			} //#MVT00108 changes ends
			folderData.addProperty("folderLevel", 3);
			folderData.add("documents", new JsonArray());
			folderData.addProperty("containDocs", false);
			folderData.add("allowed$Roles", new JsonArray());
			folderData.add("allowed$Users", new JsonArray());
			folderData.addProperty("Archive", "N");
			folderData.addProperty("isCurrVer", "Y");
			folderData.addProperty("authStat", "A");
			folderData.addProperty("operation", "CREATE");
			folderData.addProperty("initiatedOnSrvDate",date);;
			folderData.addProperty("initiator", IResManipulator.iloggedUser.get());//SKG00034 changes
			folderData.addProperty("errorMsg", "Record Sucessfully Saved");
			folderData.addProperty("verNo", 1);
			db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS", folderData);
			JsonObject fldrData = new JsonObject();
			JsonObject query = new JsonObject();
			query.addProperty("workspaceId", folderData.get("workspaceId").getAsString());
			query.addProperty("isCurrVer", "Y");
			fldrData.addProperty("folderId", folderName);
			fldrData.addProperty("folderName", folderName);
			fldrData.addProperty("workspaceId", folderData.get("workspaceId").getAsString());
			fldrData.addProperty("folderLevel", 3);
			fldrData.addProperty("containDocs", false);
			fldrData.add("folders", new JsonArray());
			String folder = folderData.get("folderIdPath").getAsString().split("/")[1];
			String i$Doc = "{'folders.$[j].folders.$[i].folders':" + fldrData + "}";
			String arrayFilters = "[{'i.folderId':'" + folderData.get("parentFolderId").getAsString() + "'} , {'j.folderId':'" + folder + "'}]";
			db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, query, "false", "push", arrayFilters);
			i$body.addProperty("folderId", folderName);
			i$body.addProperty("parentFolderId" , folderData.get("parentFolderId").getAsString());
			i$body.addProperty("workspaceId" , folderData.get("workspaceId").getAsString());
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
			i$resPre.createDmsHstRecs(isonMsg);
		}catch(Exception e) {}
		return isonMsg;
	}
	
	
	//#TKS00012 ends
	public JsonObject docCreate(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
			JsonObject i$header = null;
			JsonParser parser = new JsonParser();
			JsonArray tags = new JsonArray();
			i$body = isonMsg.getAsJsonObject("i-body");
			i$header = isonMsg.getAsJsonObject("i-header");
			JsonObject projection = new JsonObject();
			projection = new JsonObject();
			projection.addProperty("avScanningEnabled", 1);
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}",gson.toJson(projection));
			// #YPR00104 Starts
			if (I$utils.$iStrFuzzyMatch(cParam.get("avScanningEnabled").getAsString(), "Y")) {
				try {
					String scanResult = clamAVscan(i$body.get("I#FileData").getAsString());
					if (scanResult.contains("SCAN FAILED")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, scanResult);
						return isonMsg;
					}
				} catch (Exception e) {
					e.printStackTrace();
					// pass
				}
			}
			// #YPR00104 End
			if(!i$body.has("parentFolderId") && I$utils.$iStrFuzzyMatch(i$header.get("screenid").getAsString(), "FABFLUPD"))
				isonMsg = createFolder(isonMsg);//#TKS00012 changes
			i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject updateFilter = new JsonObject();
			if(i$body.has("parentFolderId") && I$utils.$iStrFuzzyMatch(i$header.get("screenid").getAsString(), "FDMFLUPD")) {
				updateFilter.addProperty("folderId", i$body.get("parentFolderId").getAsString());
				updateFilter.addProperty("folderName", i$body.get("parentFolderName").getAsString()); //Revert
			}else {
				updateFilter.addProperty("folderId", i$body.get("folderId").getAsString());
				updateFilter.addProperty("folderName", i$body.get("folderId").getAsString());
			}
			
			updateFilter.addProperty("isCurrVer", "Y");
			updateFilter.addProperty("documents.sides.FileUrlToken",i$body.get("FileUrlToken").getAsString());
			//updateFilter.add("tags", i$body.get("tags").getAsJsonArray());//#SRM00024 changes 

			JsonObject data = new JsonObject();
			if (!I$utils.$iStrBlank(i$body.get("FileUrlToken").getAsString())) {
				data.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"FileUrlToken is Missing");
				return isonMsg;
			}

			if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", updateFilter) > 0) { // #YPR00095 Changes
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Document Already exists with same " + i$body.get("FileUrlToken").getAsString());
				return isonMsg;
			}
//			try {//#MVT00094 starts
//                JsonObject flter = new JsonObject();
//                String fileName = i$body.get("FileName").getAsString().split("\\.(?=[^\\.]+$)")[0];
//                flter.addProperty("folderId", i$body.get("folderId").getAsString());
//                flter.addProperty("folderName", i$body.get("folderId").getAsString());
//                flter.addProperty("isCurrVer", "Y");
//                flter.addProperty("documents.FileName", fileName);
//                if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", flter) > 0) {
//                    isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//                            "Document Already exists with same " + fileName);
//                    return isonMsg;
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
			try {//#MVT00094 starts
				JsonObject flter = new JsonObject();

				String fileName = i$body.get("FileName").getAsString().split("\\.(?=[^\\.]+$)")[0];
				String docSubGrpID1 = i$body.get("DocSubGrpID1").getAsString(); //#SRM00034 changes//#SKG00007 changes #SKG00010 
				if (i$body.has("folderId")) {
					flter.addProperty("folderId", i$body.get("folderId").getAsString());
					flter.addProperty("folderName", i$body.get("folderId").getAsString());
					flter.addProperty("parentFolderId",i$body.get("parentFolderId").getAsString());
					flter.addProperty("isCurrVer", "Y");
					flter.addProperty("documents.FileName", fileName);
					flter.addProperty("documents.DocSubGrpID1", docSubGrpID1);//#SRM00034 changes #SKG00007 changes #SKG00010 
				} else {       //#SRM00022 changes
					flter.addProperty("parentFolderId",i$body.get("parentFolderId").getAsString());
					flter.addProperty("isCurrVer", "Y");
					flter.addProperty("documents.FileName", fileName);
				}
				
				if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", flter) > 0) {
					JsonObject doc = new JsonObject();
					JsonArray sides = new JsonArray();
					JsonObject side = new JsonObject();
					JsonObject docFilter = new JsonObject();
					JsonObject projction = new JsonObject();
					
					docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileName':'"+ fileName + "'}}").getAsJsonObject());//SRM00021 changes
					docFilter.addProperty("folderId", i$body.get("folderId").getAsString());
					projction.addProperty("_id", 0);
					projction.addProperty("documents.$", 1);
					JsonObject data1 = new JsonObject();
					try {
						data1 = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", docFilter, projction);
					}catch(Exception e) {
						
					}
					if(data1 != null) {

						JsonObject foldrData = data1.get("documents").getAsJsonArray().get(0).getAsJsonObject();					
						side = foldrData.get("sides").getAsJsonArray().get(0).getAsJsonObject();
						side.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
						sides.add(side);
						foldrData.add("sides", sides);
						foldrData.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
						foldrData.addProperty("DocSubGrpID1", i$body.get("DocSubGrpID1").getAsString());//#SRM00034 changes #SKG00007 changes #SKG00010 
						doc.add("documents.$", foldrData);
						db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", gson.toJson(doc), docFilter, "true","N");
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Saved");
	                    return isonMsg;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}//#MVT00094 starts
			updateFilter.remove("documents.sides.FileUrlToken");
			JsonObject foldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", updateFilter);
			// #SKP00001 Starts
			if (foldrData == null) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"INVALID FOLDER DETAILS");
				return isonMsg;
			}
			// #SKP00001 Ends
//			JsonArray docArray = foldrData.get("documents").getAsJsonArray();
			JsonObject side = new JsonObject();
			Boolean isPswrdPrctd = false;
			if (i$body.get("FileName").getAsString().contains(".")) {
				String fileName = I$utils.fetchValueFromJsonObj(i$body, "FileName", "");
				String[] tokens = fileName.split("\\.(?=[^\\.]+$)");
				side.addProperty("FileName", tokens[0]);
				data.addProperty("FileName", tokens[0]);
			} else {
				side.addProperty("FileName",I$utils.fetchValueFromJsonObj(i$body, "FileName", ""));
				data.addProperty("FileName",I$utils.fetchValueFromJsonObj(i$body, "FileName", ""));
			}

			side.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
			side.addProperty("FileExtn", I$utils.fetchValueFromJsonObj(i$body, "FileExtn", ""));
			side.addProperty("side", I$utils.fetchValueFromJsonObj(i$body, "DocSubGrpID2", ""));
			data.addProperty("FileSize", I$utils.fetchValueFromJsonObj(i$body, "FileSize", ""));
			JsonArray sides = new JsonArray();
			sides.add(side);
			data.addProperty("DocType",I$utils.fetchValueFromJsonObj(i$body, "DocParentGrpID1", ""));
			data.addProperty("LinkedCustNo",I$utils.fetchValueFromJsonObj(i$body, "LinkedCustNo", ""));
			data.addProperty("IDOCS", "IDOCS" + I$utils.$igetRandonNum(999999));
			if (!I$utils.$iStrBlank(I$utils.fetchValueFromJsonObj(i$body, "fileKey", ""))) { // #YPR00100 Starts
				isPswrdPrctd = true;
				i$body.addProperty("fileKey",I$impactoUtil.encrypt(i$body.get("fileKey").getAsString()));
			}
			data.addProperty("isPswrdPrctd", isPswrdPrctd);// #YPR00100 Ends
			data.addProperty("initiator", IResManipulator.iloggedUser.get());

			//SKG00030 starts
//			String parentFolderName = i$body.get("LinkedCustNo").getAsString();
//			try {
//				if(I$utils.$iStrFuzzyMatch(parentFolderName, "ALOANS")) {
//					JsonObject filter=new JsonObject();
//					JsonObject cif=new JsonObject();
//					cif.addProperty("_id", 0);
//					cif.addProperty("CustomerFullName", 1);
//					filter.addProperty("CustomerId", IResManipulator.iloggedUser.get());
//					data = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, cif);
//					data.addProperty("initiator", data.get("CustomerFullName").getAsString());
//
//					
//				}else {
//					data.addProperty("initiator", IResManipulator.iloggedUser.get());
//				}
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
			//SKG00030 end
			
			data.add("UpldSvrDateTime", i$ResM.adddate(new Date()));
			tags.add(i$body.get("DocParentGrpID1").getAsString());//#SKG00015 start
			if(i$body.has("tags"))
				data.add("tags", tags);//#SKG00015 end
			data.addProperty("verNo", 1);
			data.add("remarks", i$body.get("remarks"));//#SRM00027 changes
			data.add("sides", sides);

			String i$Doc = "{'documents': " + data.getAsJsonObject() + "}";

			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "true","push");

			if (!(foldrData.get("containDocs").getAsBoolean())) {

				i$Doc = "{'containDocs': true}";
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "true","N");

			}
			i$body.addProperty("workspaceId", foldrData.get("workspaceId").getAsString());//#TKS00013 changes
			if(i$body.has("parentFolderId"))
				i$body.addProperty("parentFolderId", i$body.get("parentFolderId").getAsString());
			else
				i$body.addProperty("parentFolderId", i$body.get("folderId").getAsString());
			i$body.addProperty("isPswrdPrctd", isPswrdPrctd); // #YPR00100 Changes
			i$body.addProperty("folderIdPath", foldrData.get("folderIdPath").getAsString());// #TKS0006 changes
			if(!I$utils.$iStrFuzzyMatch(i$body.get("Key3").getAsString(), "")) {
				tags.add(foldrData.get("folderName").getAsString());
				i$body.add("tags", tags);
			}
			i$body.addProperty("isCurrVer", "Y"); // #TKS00004 changes
			i$body.addProperty("Archive", "N");
			i$body.addProperty("verNo", 1);//#TKS00014 changes
			i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
			if(i$body.has("parentFolderId") && I$utils.$iStrFuzzyMatch(i$header.get("screenid").getAsString(), "FDMFLUPD"))
				i$body.addProperty("DMSLDOC" , "Y");//#TKS00014 changes
			else
				i$body.addProperty("DMSLDOC" , "N");//#TKS00014 changes
//			i$body.addProperty("historyOnFile", true);
			i$body.remove("subFolderId");
//			i$body.add("sides", sides);
			logger.debug("*****************Creation of DMS history for the records SRM1111************"+ isonMsg);
			i$resPre.createDmsHstRecs(isonMsg);
			i$body.remove("historyOnFile");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Saved");
			
		}catch(Exception e) {
			e.printStackTrace();
			logger.debug("*****************Checking exception DMS history before upload SRM1111************"+ isonMsg);
		}
		return isonMsg;
	}
	
	public JsonObject multiDocCreate(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
//			JsonObject i$header = null;
//			JsonParser parser = new JsonParser();
			JsonArray tags = new JsonArray();
			JsonArray files = new JsonArray();
			i$body = isonMsg.getAsJsonObject("i-body");
			files = i$body.get("files").getAsJsonArray();
//			i$header = isonMsg.getAsJsonObject("i-header");
			JsonObject projection = new JsonObject();
			projection = new JsonObject();
			projection.addProperty("avScanningEnabled", 1);
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}",gson.toJson(projection));
			// #YPR00104 Starts
			for(int i = 0 ; i < files.size(); i++) {
				if (I$utils.$iStrFuzzyMatch(cParam.get("avScanningEnabled").getAsString(), "Y")) {
					try {
						String scanResult = clamAVscan(files.get(i).getAsJsonObject().get("I#FileData").getAsString());
						if (scanResult.contains("SCAN FAILED")) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, scanResult);
							return isonMsg;
						}
					} catch (Exception e) {
						// pass
					}
				}
				i$body = isonMsg.getAsJsonObject("i-body");
				JsonObject updateFilter = new JsonObject();
				updateFilter.addProperty("folderId", i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString());
				updateFilter.addProperty("folderName", i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key3").getAsString());
				updateFilter.addProperty("isCurrVer", "Y");
				updateFilter.addProperty("documents.sides.FileUrlToken",files.get(i).getAsJsonObject().get("FileUrlToken").getAsString());

				JsonObject data = new JsonObject();
				if (!I$utils.$iStrBlank(files.get(i).getAsJsonObject().get("FileUrlToken").getAsString())) {
					data.addProperty("FileUrlToken", files.get(i).getAsJsonObject().get("FileUrlToken").getAsString());
				} 
//				else {
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"FileUrlToken is Missing");
//					return isonMsg;
//				}

				if (db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", updateFilter) > 0) { // #YPR00095 Changes
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Document Already exists with same " + i$body.get("FileUrlToken").getAsString());
//					return isonMsg;
				}
				updateFilter.remove("documents.sides.FileUrlToken");
				JsonObject foldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", updateFilter);
				// #SKP00001 Starts
				if (foldrData == null) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"INVALID FOLDER DETAILS");
					return isonMsg;
				}
				// #SKP00001 Ends
//				JsonArray docArray = foldrData.get("documents").getAsJsonArray();
				JsonObject side = new JsonObject();
				Boolean isPswrdPrctd = false;
				if (files.get(i).getAsJsonObject().get("FileName").getAsString().contains(".")) {
					String fileName = I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "FileName", "");
					String[] tokens = fileName.split("\\.(?=[^\\.]+$)");
					side.addProperty("FileName", tokens[0]);
					data.addProperty("FileName", tokens[0]);
				} else {
					side.addProperty("FileName",I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "FileName", ""));
					data.addProperty("FileName",I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "FileName", ""));
				}

				side.addProperty("FileUrlToken", files.get(i).getAsJsonObject().get("FileUrlToken").getAsString());
				side.addProperty("FileExtn", I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "FileExtn", ""));
				side.addProperty("side", I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "DocSubGrpID2", ""));
				data.addProperty("FileSize", I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "FileSize", ""));
				JsonArray sides = new JsonArray();
				sides.add(side);
				data.addProperty("DocType",I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "DocParentGrpID1", ""));
				data.addProperty("LinkedCustNo",I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "DocNo", ""));
				if (!I$utils.$iStrBlank(I$utils.fetchValueFromJsonObj(files.get(i).getAsJsonObject(), "fileKey", ""))) { // #YPR00100 Starts
					isPswrdPrctd = true;
					i$body.addProperty("fileKey",I$impactoUtil.encrypt(files.get(i).getAsJsonObject().get("fileKey").getAsString()));
				}
				data.addProperty("isPswrdPrctd", isPswrdPrctd);// #YPR00100 Ends
				data.addProperty("initiator", IResManipulator.iloggedUser.get());
				data.add("UpldSvrDateTime", i$ResM.adddate(new Date()));
				data.addProperty("verNo", 1);
				if(!files.get(i).getAsJsonObject().has("tags")) {
					tags.add(foldrData.get("folderName").getAsString());
					data.add("tags", tags);
				}else {
					data.add("tags", files.get(i).getAsJsonObject().get("tags").getAsJsonArray());
				}
				if(!I$utils.$iStrBlank(files.get(i).getAsJsonObject().get("AddlFld1").getAsString())) {
					data.addProperty("remarks", files.get(i).getAsJsonObject().get("AddlFld1").getAsString());
				}
				data.add("sides", sides);

				String i$Doc = "{'documents': " + data.getAsJsonObject() + "}";

				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "true","push");

				if (!(foldrData.get("containDocs").getAsBoolean())) {

					i$Doc = "{'containDocs': true}";
					db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "true","N");

				}
				files.get(i).getAsJsonObject().addProperty("workspaceId", foldrData.get("workspaceId").getAsString());//#TKS00013 changes
				if(files.get(i).getAsJsonObject().has("parentFolderId"))
					files.get(i).getAsJsonObject().addProperty("parentFolderId", files.get(i).getAsJsonObject().get("parentFolderId").getAsString());
				else
					files.get(i).getAsJsonObject().addProperty("parentFolderId", files.get(0).getAsJsonObject().get("folderId").getAsString());
				files.get(i).getAsJsonObject().addProperty("isPswrdPrctd", isPswrdPrctd); // #YPR00100 Changes
				files.get(i).getAsJsonObject().addProperty("folderIdPath", foldrData.get("folderIdPath").getAsString());// #TKS0006 changes
				if(!I$utils.$iStrFuzzyMatch(files.get(i).getAsJsonObject().get("Key3").getAsString(), "")) {
					if(!files.get(i).getAsJsonObject().has("tags")) {
						tags.add(foldrData.get("folderName").getAsString());
						files.get(i).getAsJsonObject().add("tags", tags);
					}else {
						files.get(i).getAsJsonObject().add("tags", files.get(i).getAsJsonObject().get("tags").getAsJsonArray());
					}
					
				}
				files.get(i).getAsJsonObject().addProperty("isCurrVer", "Y"); // #TKS00004 changes-
				files.get(i).getAsJsonObject().addProperty("Archive", "N");
				files.get(i).getAsJsonObject().addProperty("verNo", 1);//#TKS00014 changes
				files.get(i).getAsJsonObject().addProperty("initiator", IResManipulator.iloggedUser.get());
				files.get(i).getAsJsonObject().remove("subFolderId");
			}
			i$body.addProperty("DMSLDOC", "N");
			i$body.addProperty("historyOnFile", true);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
			i$resPre.createMultiDmsHstRecs(isonMsg);
			i$body.remove("historyOnFile");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Saved");
			
		}catch(Exception e) {}
		return isonMsg;
	}
	
	public JsonObject createWorkspaceFldr(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
//			Gson gson = new GsonBuilder().serializeNulls().create();
			i$body = isonMsg.getAsJsonObject("i-body");
			String folderId = "";
			String i$Doc = "";
			String folderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key1").getAsString();
			String subFldrName =  i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key2").getAsString();
			String custFldrName =  i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key3").getAsString();
			for(int i = 0 ; i < i$body.get("files").getAsJsonArray().size() ; i++) {
				if(!I$utils.$iStrFuzzyMatch(subFldrName, i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key2").getAsString()) || !I$utils.$iStrFuzzyMatch(folderName, i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key1").getAsString()) || !I$utils.$iStrFuzzyMatch(custFldrName, i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key3").getAsString())) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please note the Project name and the Sub-Folder name should be same for this request");
					return isonMsg;
				}
			}
			JsonObject query = new JsonObject();
			query.addProperty("folderName", folderName);
			query.addProperty("isCurrVer", "Y");
			query.addProperty("workspaceId", "IWS10003");
			JsonObject fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", query);
			if(fldrData == null) {
				folderId = "IFLD100" + I$utils.$igetRandonNum(99);
				JsonObject folderData = new JsonObject();
				folderData.addProperty("folderId", folderId);
				folderData.addProperty("folderName", folderName);
				folderData.addProperty("folderDesc", folderName);
				folderData.addProperty("folderLevel", 1);
				folderData.addProperty("containDocs", false);
				folderData.add("folders", new JsonArray());
				query = new JsonObject();
				query.addProperty("workspaceId", "IWS10003");
				query.addProperty("isCurrVer", "Y");
				i$Doc = "{'folders': " + folderData.getAsJsonObject() + "}";
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, query, "false", "push");
			}
			query = new JsonObject();
			String subFolderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key2").getAsString();
			String subFolderId =  "";
			String arrayFilters = "";
			query.addProperty("folderName", subFolderName);
			query.addProperty("isCurrVer", "Y");
			query.addProperty("workspaceId", "IWS10003");
			String parentFolderName = "";
			JsonObject subFldrData =  db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", query);
			if(subFldrData != null) {
				parentFolderName = subFldrData.get("parentFolderName").getAsString();
			}
			if(subFldrData == null || !I$utils.$iStrFuzzyMatch(parentFolderName, folderName)) {
				subFolderId = "IFLD10" + I$utils.$igetRandonNum(9999);
				JsonObject subFolderData = new JsonObject();
				subFolderData.addProperty("folderId", subFolderId);
				subFolderData.addProperty("folderName", subFolderName);
				subFolderData.addProperty("folderDesc", subFolderName);
				subFolderData.addProperty("folderLevel", 2);
				subFolderData.addProperty("containDocs", false);
				subFolderData.add("folders", new JsonArray());
				i$Doc = "{'folders.$[i].folders':" + subFolderData + "}";
				if(fldrData == null)
					arrayFilters = "[{'i.folderId':'" + folderId + "'}]";
				else
					arrayFilters = "[{'i.folderId':'" + fldrData.get("folderId").getAsString() + "'}]";
				query = new JsonObject();
				query.addProperty("workspaceId", "IWS10003");
				query.addProperty("isCurrVer", "Y");
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, query, "false", "push", arrayFilters);
			}
			if(fldrData != null)
				i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().addProperty("folderId", fldrData.get("folderId").getAsString());
			else
				i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().addProperty("folderId", folderId);
			if(subFldrData == null || !I$utils.$iStrFuzzyMatch(parentFolderName, folderName))
				i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().addProperty("subFolderId", subFolderId);
			else
				i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().addProperty("subFolderId", subFldrData.get("folderId").getAsString());
				
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			createFldr(isonMsg);
		}catch(Exception e) {
		e.printStackTrace();
		}
		return isonMsg;
	}
	
	public void createFldr(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
//			Gson gson = new GsonBuilder().serializeNulls().create();
			i$body = isonMsg.getAsJsonObject("i-body");
			
			String date = i$ResM.getOnlydate(new Date());
			String folderId = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString();
			String folderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key1").getAsString();
			JsonObject foldrFilter = new JsonObject();
			foldrFilter.addProperty("folderId", folderId);
			foldrFilter.addProperty("folderName", folderName);
			foldrFilter.addProperty("workspaceId", "IWS10003");
			if(db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", foldrFilter) == 0) {
				String folderIdPath = "IWS10003" + "/" + folderId ;
				JsonObject folderData = new JsonObject();
				folderData.addProperty("roleOrUserType", "");
				folderData.addProperty("scope", "public");
				folderData.addProperty("folderId", folderId);
				folderData.addProperty("folderName", folderName);
				folderData.addProperty("folderDesc", folderName);
				folderData.addProperty("folderIdPath", folderIdPath);
				folderData.addProperty("folderLevel", 1);
				folderData.addProperty("workspaceId", "IWS10003");
				folderData.add("documents", new JsonArray());
				folderData.addProperty("containDocs", false);
				folderData.add("allowed$Roles", new JsonArray());
				folderData.add("allowed$Users", new JsonArray());
				folderData.addProperty("Archive", "N");
				folderData.addProperty("isCurrVer", "Y");
				folderData.addProperty("authStat", "A");
				folderData.addProperty("operation", "CREATE");
				folderData.addProperty("initiatedOnSrvDate",date);
				folderData.addProperty("initiator", IResManipulator.iloggedUser.get());//SKG00034 changes
				folderData.addProperty("errorMsg", "Record Sucessfully Saved");
				folderData.addProperty("verNo", 1);
				db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS", folderData);
			}
			
			String subFolderId = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("subFolderId").getAsString();
			String subFolderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key2").getAsString();
			foldrFilter = new JsonObject();
			foldrFilter.addProperty("folderId", subFolderId);
			foldrFilter.addProperty("folderName", subFolderName);
			foldrFilter.addProperty("workspaceId", "IWS10003");
			if(db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", foldrFilter) == 0) {
				String subFolderIdPath = "IWS10003" + "/" + folderId + "/" + subFolderId ;
				JsonObject subFolderData = new JsonObject();
				subFolderData.addProperty("roleOrUserType", "");
				subFolderData.addProperty("scope", "public");
				subFolderData.addProperty("folderId", subFolderId);
				subFolderData.addProperty("folderName", subFolderName);
				subFolderData.addProperty("folderDesc", subFolderName);
				subFolderData.addProperty("folderIdPath", subFolderIdPath);
				subFolderData.addProperty("parentFolderName", folderName);
				subFolderData.addProperty("folderLevel", 2);
				subFolderData.addProperty("workspaceId", "IWS10003");
				subFolderData.add("documents", new JsonArray());
				subFolderData.addProperty("containDocs", false);
				subFolderData.add("allowed$Roles", new JsonArray());
				subFolderData.add("allowed$Users", new JsonArray());
				subFolderData.addProperty("Archive", "N");
				subFolderData.addProperty("isCurrVer", "Y");
				subFolderData.addProperty("authStat", "A");
				subFolderData.addProperty("operation", "CREATE");
				subFolderData.addProperty("initiatedOnSrvDate",date);;
				subFolderData.addProperty("initiator", IResManipulator.iloggedUser.get());//SKG00034 changes
				subFolderData.addProperty("errorMsg", "Record Sucessfully Saved");
				subFolderData.addProperty("verNo", 1);
				db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS", subFolderData);
			}
			createCustomerFolder(isonMsg);
		}catch(Exception e) {
			
		}
	}

	public void createCustomerFolder(JsonObject isonMsg) {
		try {
			JsonObject i$body = null;
			i$body = isonMsg.getAsJsonObject("i-body");
			String date = i$ResM.getOnlydate(new Date());
			String folderId = "IFLD1" + I$utils.$igetRandonNum(99999);
			String projFolderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key1").getAsString();
			String folderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key3").getAsString();
			String parentFolderName = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("Key2").getAsString();
			String parentFolderId = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("folderId").getAsString();
			String subFolderId = i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().get("subFolderId").getAsString();
			String parentFlderName = "";
			String projFldrName = "";
			JsonObject fldrQuery = new JsonObject();
			fldrQuery.addProperty("folderName", folderName);
			fldrQuery.addProperty("isCurrVer", "Y");
			fldrQuery.addProperty("workspaceId", "IWS10003");
			JsonObject flderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", fldrQuery);
			if(flderData != null) {
				parentFlderName = flderData.get("parentFolderName").getAsString();
				projFldrName = flderData.get("projectFolderName").getAsString();
			}
			if(flderData == null || !I$utils.$iStrFuzzyMatch(parentFlderName, parentFolderName) || !I$utils.$iStrFuzzyMatch(projFolderName, projFldrName)) {
				String folderIdPath = "IWS10003" + "/" + parentFolderId + "/" + subFolderId ;
				JsonObject folderData = new JsonObject();
				folderData.addProperty("roleOrUserType", "");
				folderData.addProperty("scope", "public");
				folderData.addProperty("folderId", folderId);
				folderData.addProperty("folderName", folderName);
				folderData.addProperty("folderDesc", folderName);
				folderData.addProperty("folderIdPath", folderIdPath);
				folderData.addProperty("folderLevel", 3);
				folderData.addProperty("workspaceId", "IWS10003");
				folderData.addProperty("parentFolderId", subFolderId);
				folderData.addProperty("parentFolderName", parentFolderName);
				folderData.addProperty("projectFolderName", projFolderName);
				folderData.add("documents", new JsonArray());
				folderData.addProperty("containDocs", false);
				folderData.add("allowed$Roles", new JsonArray());
				folderData.add("allowed$Users", new JsonArray());
				folderData.addProperty("Archive", "N");
				folderData.addProperty("isCurrVer", "Y");
				folderData.addProperty("authStat", "A");
				folderData.addProperty("operation", "CREATE");
				folderData.addProperty("initiatedOnSrvDate",date);;
				folderData.addProperty("initiator", IResManipulator.iloggedUser.get());//SKG00034 changes
				folderData.addProperty("errorMsg", "Record Sucessfully Saved");
				folderData.addProperty("verNo", 1);
				db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS", folderData);
				JsonObject fldrData = new JsonObject();
				fldrData.addProperty("folderId", folderId);
				fldrData.addProperty("folderName", folderName);
				fldrData.addProperty("folderDesc", folderName);
				fldrData.addProperty("folderLevel", 3);
				fldrData.addProperty("containDocs", false);
				fldrData.add("folders", new JsonArray());
				JsonObject query = new JsonObject();
				query.addProperty("workspaceId", "IWS10003");
				query.addProperty("isCurrVer", "Y");
				String i$Doc = "{'folders.$[i].folders.$[j].folders':" + fldrData + "}";
				String arrayFilters = "[{'i.folderId':'" + parentFolderId + "'} , {'j.folderId':'" + subFolderId + "'}]";
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, query, "false", "push", arrayFilters);
				
			}
			if(flderData != null && I$utils.$iStrFuzzyMatch(parentFlderName, parentFolderName) && I$utils.$iStrFuzzyMatch(projFolderName, projFldrName))
				i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().addProperty("folderId", flderData.get("folderId").getAsString());
			else
				i$body.get("files").getAsJsonArray().get(0).getAsJsonObject().addProperty("folderId", folderId);
			i$body.addProperty("historyOnFolder", true);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			if(flderData == null)
				i$resPre.createMultiDmsHstRecs(isonMsg);
			i$body.remove("historyOnFolder");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			multiDocCreate(isonMsg);
		}catch(Exception e) {
			
		}
	}
	
	public JsonObject delDocApi(JsonObject isonMsg) {
		try {
			String docId = isonMsg.get("i-body").getAsJsonObject().get("FileUrlToken").getAsString();
//				JsonObject filter = new JsonObject();
			JsonObject doc = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject updateFilter = new JsonObject();
			JsonObject elem = new JsonObject();
			JsonObject document = new JsonObject();
			doc.addProperty("sides.FileUrlToken", docId);
			elem.add("$elemMatch", doc);
			document.add("documents", elem);
			argJson.addProperty("workspaceId", "IWS10003");
			JsonArray filter = new JsonArray();
			filter.add(document);
			filter.add(argJson);
			updateFilter.add("$and", filter);

			String i$Doc = "{'documents':{'FileUrlToken': " + docId + "}}";
			JsonObject folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", updateFilter);
			if (folderData == null) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"No Document exists with this FileUrlToken:" + docId);
				return isonMsg;
			}
			JsonObject folderFilter = new JsonObject();
			folderFilter.addProperty("folderId", folderData.get("folderId").getAsString());
			folderFilter.addProperty("isCurrVer", "Y");
			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, updateFilter, "false", "pull");
			// #TKS00004 changes
			JsonObject fsFilter = new JsonObject();
			fsFilter.addProperty("metadata.FileUrlToken",
					isonMsg.get("i-body").getAsJsonObject().get("FileUrlToken").getAsString());
			JsonObject fsUpdate = new JsonObject();
			fsUpdate.addProperty("metadata.isCurrVer", "N");
			db$Ctrl.db$UpdateRow("fs.files", fsUpdate, fsFilter);
			JsonObject fdata = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", folderFilter);
			if (fdata.get("documents").getAsJsonArray().size() == 0) {
				i$Doc = "{'containDocs': false}";
				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", i$Doc, folderFilter, "false", "N");
				String parentFolderId = fdata.get("folderIdPath").getAsString().split("/")[1];
				String subFolderId = fdata.get("folderIdPath").getAsString().split("/")[2];
				JsonObject queryfilter = new JsonObject();
				queryfilter.addProperty("workspaceId", "IWS10003");
				queryfilter.addProperty("isCurrVer", "Y");
				i$Doc = "{'folders.$[i].folders.$[j].folders.$[k].containDocs': false}";
				String arrayFilters = "[{'i.folderId':'" + parentFolderId + "'} , {'j.folderId':'" + subFolderId + "'} , {'k.folderId':'" + fdata.get("folderId").getAsString() + "'}]";
				db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_WORKSPACES", i$Doc, queryfilter, "false", "N", arrayFilters); // YPR00099
																											// Changes
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}
		isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Document Successfully Deleted");
		db$Ctrl.db$logDmsHstry(isonMsg);
		return isonMsg;
	}
	
	// #TKS00006 starts
	// #TKS00011 starts
	public JsonObject docUpdate(JsonObject isonMsg) {
		Gson gson = new GsonBuilder().serializeNulls().create();
		JsonObject ibody = new JsonObject();
//		JsonParser parser = new JsonParser();
		JsonObject filter = new JsonObject();
		ibody = i$ResM.getBody(isonMsg);
		String fileUrlToken = "";
		try {
			fileUrlToken = ibody.get("FileUrlToken").getAsString();
		} catch (Exception e) {
		}
		if (I$utils.$iStrBlank(ibody.get("FileUrlToken").getAsString())) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FileUrlToken is Missing");
			return isonMsg;
		}
		filter.addProperty("metadata.FileUrlToken", fileUrlToken);
		filter.addProperty("metadata.isCurrVer", "Y");
		filter.addProperty("metadata.LinkedCustNo", ibody.get("LinkedCustNo").getAsString());
		JsonObject updObj = new JsonObject();
		updObj.addProperty("metadata.Key1", ibody.get("cntCode").getAsString());
		updObj.addProperty("metadata.Key2", ibody.get("typeOfProduct").getAsString());
		updObj.addProperty("metadata.Key3", ibody.get("cif").getAsString());
		updObj.addProperty("metadata.Key4", ibody.get("accNos").getAsString());
		updObj.addProperty("metadata.Key5", ibody.get("applicationId").getAsString());
		updObj.addProperty("metadata.Key6", ibody.get("referenceNo").getAsString());
		db$Ctrl.db$UpdateRowOperator("fs.files", gson.toJson(updObj), filter, "false", "N");
		isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Document Successfully Updated");
		return isonMsg;
	}
	//#SKG00009 starts
	public JsonObject docReset(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject i$Body = isonMsg.getAsJsonObject("i-body");
		    try {
		    	String updateObj = "{'documents':{'FileUrlToken':{'$in':"+i$Body.get("FileUrlToken").getAsJsonArray()+"}}}";
			filter.addProperty("folderId", i$Body.get("folderId").getAsString());
			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", updateObj, filter, "false", "pull");
		} catch (Exception e) {
			e.printStackTrace();
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return isonMsg;	
	    }//#SKG00009 end

	// #TKS00011 ends
	public JsonObject addTagsIndexes(JsonObject isonMsg) {
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonArray tags = new JsonArray();
			JsonObject query = new JsonObject();
			query.addProperty("metadata.isCurrVer", "Y");
			query.addProperty("metadata.LinkedCustNo", ibody.get("LinkedCustNo").getAsString());
			JsonObject fileUrlTokenArray = new JsonObject();
			fileUrlTokenArray.add("$in", ibody.get("fileUrlTokenArr").getAsJsonArray());
			query.add("metadata.FileUrlToken", fileUrlTokenArray);
			JsonObject updateObj = new JsonObject();
			tags.add(ibody.get("LinkedCustNo").getAsString());
			tags.add(ibody.get("referenceNo").getAsString());
			tags.add(ibody.get("primaryDocId").getAsString());
			tags.add(ibody.get("dob").getAsString());
			tags.add(ibody.get("fullName").getAsString());
			tags.add(ibody.get("emailId").getAsString());
			tags.add(ibody.get("mobNo").getAsString());
			tags.add(ibody.get("dateCreated").getAsString());
			updateObj.add("metadata.tags", tags);
			String iDocW = "{'metadata.tags': " + tags + "}";
			db$Ctrl.db$UpdateRowOperator("fs.files", iDocW, query, "false", "N");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}

		return isonMsg;
	}
	// #TKS00006 ends

	public JsonObject getDocsCount(JsonObject isonMsg) {
		try {
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject(); 
			JsonArray arr = new JsonArray();
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject folderData = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonArray docsArr = new JsonArray();
			JsonArray fltkArr = new JsonArray();
			JsonArray failedDocs = new JsonArray();
			projection.addProperty("FileUrlToken", 1);
			String docNo = ibody.get("DocNo").getAsString();
			filter.addProperty("metadata.DocNo", docNo);
			filter.addProperty("metadata.isCurrVer", "Y");
			int successCount = db$Ctrl.db$GetCountI("fs.files" , filter);
			filter.remove("metadata.DocNo");
			filter.remove("metadata.isCurrVer");
			filter.addProperty("DocNo", docNo);
			filter.add("FileUrlId", null);
			arr = db$Ctrl.db$GetRows("ICOR_M_DMS_LOGGER" , gson.toJson(filter) , gson.toJson(projection));
			for(int i = 0 ; i < arr.size(); i++) {
				JsonObject runningObj = arr.get(i).getAsJsonObject();
				runningObj.remove("_id");
				fltkArr.add(runningObj.get("FileUrlToken").getAsString());
			}
			int failureCount = arr.size();
			if(arr.size() != 0) {
				filter.remove("DocNo");
				filter.remove("FileUrlId");
				filter.add("documents.FileUrlToken", parser.parse("{'$in':" + fltkArr + "}").getAsJsonObject());
				folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS" , filter);
				docsArr = folderData.get("documents").getAsJsonArray();
				for (int i = 0; i < docsArr.size(); i++) {
					JsonObject docData = new JsonObject();
					JsonObject runningObj = docsArr.get(i).getAsJsonObject();
					String fileUrlToken = runningObj.get("FileUrlToken").getAsString();
					if(fltkArr.contains(new JsonPrimitive(fileUrlToken))) {
						docData.addProperty("FileName", runningObj.get("FileName").getAsString());
						docData.addProperty("FileSize", runningObj.get("FileSize").getAsString());
						docData.addProperty("FileExtn", runningObj.get("sides").getAsJsonArray().get(0).getAsJsonObject().get("FileExtn").getAsString());
						failedDocs.add(docData);
					}
					
				}
			}
			
			ibody.addProperty("successDocs" , successCount);
			ibody.addProperty("failedDocs", failureCount);
			ibody.add("FailedDocsDetails", failedDocs);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, successCount + " Files successfully uploaded , " + failureCount + " Files Failed to upload");
		}catch(Exception e) {
			
		}
		return isonMsg;
	}
	
	// #NYE00014 Begins
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg) {
		try {
			return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));

		} catch (Exception e) {
			logger.debug(" Error in get$FrmDataSetFilter -" + e.getMessage());
			return null;
		}
	}

	// #NYE00014 Ends
	// #YPR00104 Starts
	public String clamAVscan(String IFileData) {
		String resp = null;
		try {
			byte[] fileDataBytes = I$impactoUtil.base64Decode(IFileData);
			ClamAVClient cl = new ClamAVClient("127.0.0.1", 3310, 5000);//7000 to 5000
			String r = new String(fileDataBytes, StandardCharsets.US_ASCII);
			if (r.startsWith("INSTREAM size limit exceeded.")) {
				resp = "Clamd size limit exceeded : " + r;
				return resp;
			} else {
				fileDataBytes = cl.scan(fileDataBytes);
				r = new String(fileDataBytes, StandardCharsets.US_ASCII);
				if (r.contains("OK") && !r.contains("FOUND")) {
					resp = "PASSED";
				} else if (!r.contains("OK") && r.contains("FOUND")) {
					resp = "SCAN FAILED , " + r;
				}
			}
			return resp;
		} catch (Exception e) {
			return resp;
		}
	}

	// #YPR00104 Starts
	// #BVB00033 Ends
	public IDocumentsController() {
		// Cons
	}
}
// #00000001 Ends