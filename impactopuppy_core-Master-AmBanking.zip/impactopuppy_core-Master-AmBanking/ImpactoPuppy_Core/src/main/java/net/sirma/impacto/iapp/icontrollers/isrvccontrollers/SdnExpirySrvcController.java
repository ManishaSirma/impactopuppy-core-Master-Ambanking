/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.14.283  | BHUVI 		| Jun 20, 2019 | #BHUVI001   |  Job for get all expired sdn 
      ----------------------------------------------------------------------------------------------
      
*/
// #BHUVI001 Starts

package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRepoController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.SdnExpiryController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class SdnExpirySrvcController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

 	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(SdnExpirySrvcController.class);
 	private SdnExpiryController i$sdnExpCtrl = new SdnExpiryController(); 
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SvrOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SvrName, "SdnExpiry") && I$utils.$iStrFuzzyMatch(SvrOpr, "CREATE")) {
				isonMsg = i$sdnExpCtrl.CreateSdnExpiry(isonMsg);
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.getMessage();
			return isonMsg;
		}
		return isonMsg;
	} 
	 
	public SdnExpirySrvcController() {
		// Constructor
	}

}
// #BHUVI001 Ends