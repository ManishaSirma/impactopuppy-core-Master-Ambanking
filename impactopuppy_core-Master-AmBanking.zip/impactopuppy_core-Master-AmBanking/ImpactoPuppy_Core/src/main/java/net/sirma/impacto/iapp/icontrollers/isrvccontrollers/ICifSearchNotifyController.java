/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Pruthvi	| Dec 06, 2021 | #YPR00127   | Initial writing
      |0.1 Beta    | Pruthvi	| Dec 10, 2021 | #YPR00128   | Added changes to get pending requests
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICifSearchNotifyController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private IEmailService i$Email = new IEmailService();
	private ISmsService i$SmsSrvc = new ISmsService();
	private Logger logger = LoggerFactory.getLogger(ICifSearchNotifyController.class);
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String sSOpr = i$ResM.getSrvcopr(isonMsg);
			String sSvr = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(sSvr, "CifSearchNotificService") && I$utils.$iStrFuzzyMatch(sSOpr, "sendReq")) {
				return sendAmbdsrReq(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(sSvr, "CifSearchNotificService")&& I$utils.$iStrFuzzyMatch(sSOpr, "getCustActn")) {
				return getCustActn(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(sSvr, "CifSearchNotificService")&& I$utils.$iStrFuzzyMatch(sSOpr, "getReqStatus")) {
				return getReqStatus(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(sSvr, "CifSearchNotificService")&& I$utils.$iStrFuzzyMatch(sSOpr, "getPendReqs")) { // #YPR00128 changes
				return getPendReqs(isonMsg);
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
		return null;
	}

	private JsonObject sendAmbdsrReq(JsonObject isonMsg) {
		try {
			String sSeqNm = i$ResM.getBodyElementS(isonMsg, "seqName");
			String reqId = db$Ctrl.db$GetSeqFor("SEQ#MQAMBREQID");
			String sTmplName = null;
			String sMsgAnnote = null;
			JsonObject i$Param = null;
			JsonObject argJson = new JsonObject();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");

			i$ResM.add2IsonBody(isonMsg, "requestId", reqId);

			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				sMsgAnnote = i$ResM.getBodyElementS(isonMsg, "Msg_Annotation");
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP", "{\"MSG_ANNOTATION\":\"" + sMsgAnnote + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#AMB#CIF#REQ";

			try {
				i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"iOtpCommMode\"=1}");
			} catch (Exception ex) {
				i$Param = null;
			}

			String custId = i$body.get("CustomerId").getAsString();
			JsonObject userCifnotificDet = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",
					"{\"CustomerId\":\"" + custId + "\"}");

			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("user", userCifnotificDet.get("CustomerFullName").getAsString());
//				map$Data.addProperty("ambName",IResManipulator.iloggedUser.get());
			map$Data.addProperty("ambName", i$body.get("ambdsrId").getAsString());
			map$Data.addProperty("tmp$name", sTmplName);
			argJson.addProperty("requestId", reqId);
			argJson.addProperty("CIF", custId);
			argJson.addProperty("ambdsrId", i$body.get("ambdsrId").getAsString());
			argJson.add("requestedTime", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("status", "Pending");
			argJson.addProperty("tranId", i$body.get("tranId").getAsString());
			db$Ctrl.db$InsertRow("ICOR_M_AMBASSADOR_REQUESTS", argJson);
			argJson.addProperty("tmplName", sTmplName);

			String sKeyE = userCifnotificDet.get("CustomerEmailId").getAsString();
			String sKeyM = userCifnotificDet.get("CustomerMobileIsdNo").getAsString()
					+ userCifnotificDet.get("CustomerMobileId").getAsString();

			argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
			argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + sKeyM + "\"}"));
			argJson.add("map$Data", map$Data);

			if (!I$utils.$iStrBlank(sKeyE) || !I$utils.$iStrBlank(sKeyM)) {
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				JsonObject i$resM = i$SmsSrvc.SendSMSWOThread(argJson);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resE), i$ResM.I_SUCC)
						|| I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resM), i$ResM.I_SUCC)) {
					argJson.remove("tmplName");
					argJson.remove("toemailIds");
					argJson.remove("mobile$numbers");
					argJson.remove("map$Data");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, argJson);
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "REQUEST SENT SUCCESSFULLY");
				} else {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Error in Sending Request or Notification Service is disabled");
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Email or MobileNum not found");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}

	};

	private JsonObject getCustActn(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			String actionPerformed = i$body.get("action").getAsString();
			String status = "Pending";
			JsonObject filter = new JsonObject();
			filter.addProperty("requestId", i$body.get("requestId").getAsString());
			JsonObject updateActnObj = new JsonObject();
			updateActnObj.addProperty("action", actionPerformed);
			updateActnObj.add("actionPerformedTime", i$ResM.adddate(new Date()).getAsJsonObject());
			if (I$utils.$iStrFuzzyMatch(actionPerformed, "approve")) {
				status = "Approved";
			} else if (I$utils.$iStrFuzzyMatch(actionPerformed, "reject")) {
				status = "Rejected";
			} else if (I$utils.$iStrFuzzyMatch(actionPerformed, "report")) {
				status = "Reported";
			}
			updateActnObj.addProperty("status", status);
			db$Ctrl.db$UpdateRow("ICOR_M_AMBASSADOR_REQUESTS", updateActnObj, filter);
			i$body.addProperty("status", status);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ACTION UPDATED SUCCESSFULLY");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}

	};
	
	private JsonObject getReqStatus(JsonObject isonMsg){
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			String custId = i$body.get("CIF").getAsString();
			JsonObject filter = new JsonObject();
			filter.addProperty("requestId", i$body.get("requestId").getAsString());
			filter.addProperty("CIF", custId);
			JsonObject ambReqObj = db$Ctrl.db$GetRow("ICOR_M_AMBASSADOR_REQUESTS",filter);
			String status = ambReqObj.get("status").getAsString();
			i$body.addProperty("status", status);
			i$body.addProperty("requestedTime", ambReqObj.get("requestedTime").getAsString());
			if(I$utils.$iStrFuzzyMatch(status,"Approved")) {
				JsonObject custData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA","{\"CustomerId\":\"" + custId + "\"}");
				i$body.add("customerData",custData);
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "STATUS RETRIEVED SUCCESSFULLY");
			
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
		
	}
	
	// #YPR00128  starts
	private JsonObject getPendReqs(JsonObject isonMsg){
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			String custId = i$body.get("CIF").getAsString();
			JsonObject filter = new JsonObject();
//			filter.addProperty("requestId", i$body.get("requestId").getAsString());
			JsonObject temp = new JsonObject();
			try {
			Date lsrDate = I$utils.changeDate(5, "SUB", "MM"); 
			temp.add("$gt", i$ResM.adddate(lsrDate).getAsJsonObject());
			}catch(Exception e) {}
			
			filter.addProperty("CIF", custId);
			filter.addProperty("status", "Pending");
			filter.add("requestedTime",temp );
			JsonArray custPenReqs = db$Ctrl.db$GetRows("ICOR_M_AMBASSADOR_REQUESTS",filter,new JsonObject());
			i$body.add("iRowData", custPenReqs);	
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORDS RETRIEVED SUCCESSFULLY");
			
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
		
	}
	// #YPR00128 Ends
}