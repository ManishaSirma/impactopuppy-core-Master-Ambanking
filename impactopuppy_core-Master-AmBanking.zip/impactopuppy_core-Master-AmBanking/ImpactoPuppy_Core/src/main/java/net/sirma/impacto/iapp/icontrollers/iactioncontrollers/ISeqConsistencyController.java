/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.6       | Vijay 		| Apr 17, 2019 | #BVB00120   | Initial writing for Maintaining Release and Lock Feature of Records
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB00120 Begins
package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ISeqConsistencyController {
	private Logger logger = LoggerFactory.getLogger(ISeqConsistencyController.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private DBController db$Ctrl = new DBController();

	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);

			if (I$utils.$iStrFuzzyMatch(Scr, "OIWSQECS") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = acquireRow(isonMsg);

			} else if (I$utils.$iStrFuzzyMatch(Scr, "OIWSQECS") && I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
				isonMsg = releaseRow(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}
		return isonMsg;
	}

	public JsonObject acquireRow(JsonObject isonMsg) {
		JsonObject ac$ = new JsonObject();
 		try {
			String CollName = i$ResM.getBodyElementS(isonMsg, "CollName"); //argJson.get("CollName").getAsString();
			JsonObject filter = i$ResM.getBodyElementO(isonMsg, "filter");//argJson.getAsJsonObject("filter");
			ac$ = db$Ctrl.db$AcqRow(CollName, filter);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
					i$ResM.getiStat(ac$));
			
//			if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(ac$), i$ResM.I_SUCC))
//				isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_SUCC, i$ResM.getMsgtext(ac$));
//			else
//				isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_ERR, i$ResM.getMsgtext(ac$));
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_ERR, "FAILED TO ACQUIRE ROW WITH:" + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject releaseRow(JsonObject isonMsg) {
		JsonObject rl$ = new JsonObject();
 		try {
 			// #BVB00167 Starts 
			// String CollName = i$ResM.getBodyElementS(isonMsg, "CollName"); //argJson.get("CollName").getAsString();
 			String ScrId = i$ResM.getBodyElementS(isonMsg, "ScrId");
 			// #BVB00167 Ends
			JsonObject filter = i$ResM.getBodyElementO(isonMsg, "filter");//argJson.getAsJsonObject("filter");
			rl$ = db$Ctrl.db$ReleaseRowS(ScrId, filter); // #BVB00167
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
					i$ResM.getiStat(rl$));
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"FAILED TO RELEASE ROW WITH:" + e.getMessage());
		}
		return isonMsg;
	}
	
	public JsonObject acquireRow(String CollName, JsonObject filter) {
		JsonObject isonMsg = new JsonObject();
		JsonParser parser = new JsonParser(); 
		
 		try {
 			isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
 			JsonObject ac$ = db$Ctrl.db$AcqRow(CollName, filter);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
					i$ResM.getiStat(ac$));
			
//			if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(ac$), i$ResM.I_SUCC))
//				isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_SUCC, i$ResM.getMsgtext(ac$));
//			else
//				isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_ERR, i$ResM.getMsgtext(ac$));
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_ERR, "FAILED TO ACQUIRE ROW WITH:" + e.getMessage());
		}
		return isonMsg;
	}
// #BVB00167 Commented Below Starts 
//	
//	public JsonObject releaseRow(String CollName, JsonObject filter) {
//		JsonObject isonMsg = new JsonObject();
//		JsonParser parser = new JsonParser(); 
//		
// 		try {
// 			isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
// 			JsonObject rl$ = db$Ctrl.db$ReleaseRow(CollName, filter);
//			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
//					i$ResM.getiStat(rl$));
//			
////			if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(ac$), i$ResM.I_SUCC))
////				isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_SUCC, i$ResM.getMsgtext(ac$));
////			else
////				isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_ERR, i$ResM.getMsgtext(ac$));
//		} catch (Exception e) {
//			isonMsg = i$ResM.iHandleResStat(isonMsg,  i$ResM.I_ERR, "FAILED TO ACQUIRE ROW WITH:" + e.getMessage());
//		}
//		return isonMsg;
//	}
// #BVB00167 Ends

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
 			isonMsg = processMsgHandler(isonMsg,isonheader, isonMapJson);
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());

		}
		return isonMsg;
	}

}

// #BVB00120 Ends