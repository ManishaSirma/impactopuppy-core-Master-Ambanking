package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;
/*
Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
Sirma Business Consulting India reserves all rights to this code . No part of this code should 
be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
take all reasonable precautions to protect the source code and documentation, and preserve its
confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
and permanent injunctive relief in addition to such remedies as may otherwise be available.

//But by the grace of God We are what we are, and his grace to us was not without effect. No, 
//We worked harder than all of them--yet not We, but the grace of God that was with us.
----------------------------------------------------------------------------------------------
|Version No  | Changed by | Date         | Change Tag  | Changes Done
----------------------------------------------------------------------------------------------
|1.0.0       | Nye 		| Jul 02, 2019  | #00000001   | Initial writing
|4.0.2.469   | Pruthvi 	| Feb 03, 2021  | #YPR00045   | Added OCR capabilities 
----------------------------------------------------------------------------------------------

*/

import java.io.ByteArrayInputStream;
import java.io.File;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.util.LoadLibs;

public class IOcrController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil i$Outils = new ImpactoUtil(); // #NYE00004
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	// **********************************************************************//
	
	//#YPR00045 Starts 
	
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String sSOpr = i$ResM.getSrvcopr(isonMsg);
			String sSvr = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(sSvr, "ImpactoOCRService")
					&& I$utils.$iStrFuzzyMatch(sSOpr, "doOCR")) {
				return perform$OCR(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	}
	
	public JsonObject perform$OCR(JsonObject isonMsg) {
		String baseString = "";
		JsonObject OCR_Data = new JsonObject();
		try {
			baseString = isonMsg.getAsJsonObject("i-body").get("I#FileData").getAsString();
			ByteArrayInputStream bis = new ByteArrayInputStream(Base64.decodeBase64(baseString.getBytes()));
			Tesseract tesseract = new Tesseract();
			File tessDataFolder = LoadLibs.extractTessResources("/tessdata");
	        if(!System.getProperty("os.name").equals("Linux")) {
	        	tesseract.setDatapath(tessDataFolder.getAbsolutePath());
	        } else {
				// For Linux
	        	// sudo apt-get install tesseract-ocr
	        	// TESSDATA_PREFIX=/tmp/tess4j/tessdata in .bashrc
	        	tesseract.setDatapath(System.getenv("TESSDATA_PREFIX"));
			    ImageIO.scanForPlugins();
	        }
			String ocrText = tesseract.doOCR(ImageIO.read(bis));
			OCR_Data.addProperty("ocrText", ocrText);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, OCR_Data);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OCR Completed Sucessfully");
			
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			}
		return isonMsg;
		}
	
	}
   //#YPR00045 Ends 

