/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Oct 5, 2018  | #BVB00005   | 1) Making i-Match available in DB
      |0.1 Beta    | Vijay 		| Nov 29, 2018 | #BVB00016   | Feature I-Projection added 
      |0.1 Beta    | Vijay 		| Dec 01, 2018 | #BVB00018   | Code for operations: Partial Save, QueryData, Confirm 
      |0.1 Beta    | Vijay 		| Dec 1, 2018  | #BVB00019   | Rights should not be checked for LOV Screen Id's 
      |0.1 Beta    | Vijay 		| Dec 9, 2018  | #BVB00022   | Made Collateral Rev maker checker, added functions for partial save, QueryData
      |0.1 Beta    | Vijay 		| Dec 11, 2018 | #BVB00027   | Moving QUERYMASTER to operation2 rather than in operation 
      |0.1.6       | Vijay 		| Dec 14, 2018 | #BVB00029   | Adding isonMsg to call DB Controller 
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

 import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ICollateralRevWorker;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class ICollateralRev {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
  	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(ICollateralRev.class);

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private ICollateralRevWorker iCollateralRevWorker = new ICollateralRevWorker();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		JsonObject i$Annotate = null;
		String Coll_Name, L_Coll_Name;
		Gson gson = new Gson();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);

		try {

			// #BVB00019 Starts
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;

			// if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr)) {
			if (hasRights) {

				// #BVB00019 Ends
				if (i$Match == null) {
					JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
					i$Match = new JsonObject();
					try {
						if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
							for (int i = 0; i < i$MatchMap.size(); i++) {

								i$Match.addProperty(i$MatchMap.get(i).getAsString(),
										i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
						} else {
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
						}
					} catch (Exception e) {
						e.printStackTrace();
						i$Match = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
					}
					;

				}
				;

				// #BVB00005 Ends
				// #BVB00016 Starts
				if (i$ProjectionArray != null) {
					for (int i = 0; i < i$ProjectionArray.size(); i++) {
						i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
					}
				} else {
					i$Projection = new JsonObject();
				}
				// #BVB00016 Ends

				Integer i$MaxRow = -1;
				// #BVB00005 Starts
				JsonObject i$recordDetails = new JsonObject();
				JsonObject i$validateRes = new JsonObject();
				JsonObject i$ledgerCurVer = new JsonObject();
				// #BVB00005 Ends
				try {
					i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
				} catch (Exception e) {
					try {
						i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
					} catch (Exception ex) {
						i$MaxRow = -1;
					}
					;
				}
				;

				try {
					Coll_Name = isonMapJson.get("COLLNAME").getAsString();
				} catch (Exception e) {
					Coll_Name = null;
				}
				;

				if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
						|| (I$utils.$iStrBlank(gson.toJson(i$Match)))
						|| I$utils.$iStrFuzzyMatch(gson.toJson(i$Match), "{}")) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
					return isonMsg;
				}
				;

				try {
					L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
				} catch (Exception e) {
					L_Coll_Name = null;
				}
				;

				if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
					return isonMsg;
				}
				;

				try {
					String ScrID = i$ResM.getScreenID(isonMsg);
					String SOpr1 = i$ResM.getOpr1(isonMsg);
					String SOpr2 = i$ResM.getOpr2(isonMsg);
					String SOpr3 = i$ResM.getOpr3(isonMsg);
					/*
					 * if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY") &&
					 * !I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ") && !I$utils.$iStrFuzzyMatch(SOpr,
					 * "QUERY")) {
					 */
					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrID + "_" + SOpr + "\"}");
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;
						i$body = isonMsg.getAsJsonObject("i-body");
					} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						// Forwarding Request to DB Handler for SUMMARY
						logger.debug("Forwarding Request to DB Controller for Summary");
						isonMsg.add("i-body", null);
						i$body = null;
						if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
							if (i$Match != null)
								return (db$Ctrl.db$GetSummRows(L_Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection)); // #BVB00016
																														// Added
																														// Projection
							else
								return (db$Ctrl.db$GetSummRows(L_Coll_Name, isonMsg, i$MaxRow, "{\"isCurrVer\"=\"Y\"}",
										i$Projection));// #BVB00016 Added Projection
						} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
							if (i$Match != null)
								return (db$Ctrl.db$GetSummRows(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection));// #BVB00016
																														// Added
																														// Projection
							else
								return (db$Ctrl.db$GetSummRows(Coll_Name, isonMsg, i$MaxRow, "{}", i$Projection));// #BVB00016
																													// Added
																													// Projection
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
							return isonMsg;
						}
					} /*
						 * else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ")) {
						 * 
						 * logger.debug("Forwarding Request to DB Controller for Query Accquire"); try {
						 * JsonObject u$pdate = null; i$ledgerCurVer.addProperty("errorMsg",
						 * "Record Sucessfully Retrieved"); db$Ctrl.db$AcqRow(L_Coll_Name, i$Match,
						 * isonMsg); isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg,
						 * i$ResM.I_BDYTAG, i$ledgerCurVer); isonMsg = i$ResM.iHandleResStat(isonMsg,
						 * i$ResM.I_SUCC,"Record Sucessfully Retrieved"); return isonMsg; } catch
						 * (Exception e) { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						 * "OPERATION FAILED"); return isonMsg; }
						 * 
						 * }
						 */ else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
						return isonMsg;
					}
					;
					I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
					if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {

						String collateralId = i$body.get("collateralId").getAsString();

						// #BVB00005 Starts
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$body", i$body);
						// Getting the validation data from DB
						// Getting data from Master
						JsonObject i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						JsonObject i$master = db$Ctrl.db$GetRow(Coll_Name, i$runningQuery.toString());
						if (i$master != null) {
							logger.debug("Master Records: " + i$master);
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									i$master);
						} else {
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									"{}");
						}
						// Getting all records of Ledger Except for Deleted Records
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						String ndD = "{\"$ne\":\"D\"}";
						JsonParser parser = new JsonParser();
						i$runningQuery.add("recordStat", parser.parse(ndD).getAsJsonObject());
						JsonArray i$Ledger = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("Ledger Records: " + i$Ledger);
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$Ledger",
								i$Ledger);

						// Getting records with isCurrVer:
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("isCurrVer", "Y");
						JsonArray i$ledgerCurrVer = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerCurrVer: " + i$ledgerCurrVer + " Count: " + i$ledgerCurrVer.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerCurrVer",
								i$ledgerCurrVer);

						// Getting records of Un-Auth
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("authStat", "U");
						JsonArray i$ledgerUnAuth = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerUnAuth: " + i$ledgerUnAuth + " Count: " + i$ledgerUnAuth.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerUnAuth",
								i$ledgerUnAuth);
						/*
						 * if(I$utils.$iStrFuzzyMatch(SOpr3, "CONFIRM")) {
						 * i$recordDetails.addProperty("confirmCompleted", true); }else {
						 * i$recordDetails.addProperty("confirmCompleted", false); }
						 */

						i$validateRes = iCollateralRevWorker.validateRequest(SOpr, SOpr1, SOpr2, i$recordDetails);
						if (i$validateRes.get("i-stat").getAsInt() > 0) {
							if (i$ledgerCurrVer.size() > 0)
								i$ledgerCurVer = i$ledgerCurrVer.get(0).getAsJsonObject();
							// #BVB00005 Ends

							// Forwarding Request to DB Handler for Insert
							if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr2, "")) {
								try {
									JsonObject u$pdate, m$x, up$ = null;
									i$ledgerCurVer = i$body.deepCopy();
									i$ledgerCurVer.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date 
									i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
									i$ledgerCurVer.addProperty("initiator", IResManipulator.iloggedUser.get());
 									// i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
									i$ledgerCurVer.addProperty("acquiredBy", "");
									i$ledgerCurVer.addProperty("authorizer", ""); 
									i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Saved");
									i$ledgerCurVer.remove("_id");
									i$runningQuery = new JsonObject();
									i$runningQuery = i$Match.deepCopy();
									i$runningQuery.addProperty("isCurrVer", "Y");
									// BVB 
									
									// up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
									up$ = db$Ctrl.db$UpdateRow(L_Coll_Name,isonMsg, i$ledgerCurVer, i$runningQuery);
									return up$;

								 
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							// Forwarding Request to DB Handler for UPDATE
							if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
								try {
									JsonObject u$pdate, m$x, up$ = null;

									if (i$ledgerUnAuth.size() == 0) {
										u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}", i$Match);
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {

											i$body.addProperty("isCurrVer", "Y");
											i$body.addProperty("authStat", "U");
											i$body.addProperty("recordStat", "O");
											i$body.addProperty("operation", SOpr.toUpperCase());
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											// i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
											i$body.addProperty("acquiredBy", "");
											i$body.addProperty("authorizer", "");
											i$body.addProperty("errorMsg", "Record Sucessfully Updated");
											i$body.add("authorizedOnSrvDate", null);
											m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
											Integer MaxVer = 0;
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
												MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
											}
											;
											i$body.addProperty("verNo", MaxVer + 1);
											// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
											// BVB  
											//up$ = db$Ctrl.db$InsertRow(L_Coll_Name, i$body);
											up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
											try { 
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												//JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;

											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;
										} else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"OPERATION FAILED #LUP0001");
											return isonMsg;
										}

									} else {

										i$ledgerCurVer = i$body.deepCopy();

										i$ledgerCurVer.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Updated");

										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();

										i$runningQuery = i$Match.deepCopy();
										i$runningQuery.addProperty("isCurrVer", "Y");
										// BVB
										// up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer, i$runningQuery);// #BVB00029
										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											// JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;

										// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
										return up$;

									}

								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00005 Starts
							// Forwarding Request to DB Handler for AUTH
							if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
								try {
									JsonObject u$pdate, m$x, up$ = null;
									// u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
									// i$Match);
									// if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
									// i$ledgerCurVer.addProperty("isCurrVer", "Y");
									i$ledgerCurVer.addProperty("authStat", "A");
									// i$ledgerCurVer.addProperty("recordStat", "O");
									i$ledgerCurVer.addProperty("remarks", i$ResM.getBodyElementS(i$body, "remarks"));
									i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
									i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
									i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
									// i$ledgerCurVer.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
									i$ledgerCurVer.addProperty("acquiredBy", "");
									i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Authorized");
									// i$body.addProperty("authBy", IResManipulator.iloggedUser.get());
									// i$body.add("authDate", i$ResM.adddate(new Date()));

									// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;

									// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
									try {
										JsonObject recIdObject = new JsonObject();
										// if (i$master != null) {
										if (I$utils.$isNull(i$ledgerCurVer)) {
											recIdObject = i$master.getAsJsonObject("_id");
										} else {
											recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
										}
										;
										// JsonObject re$ = i$releaseLock(recIdObject);
										db$Ctrl.db$ReleaseRow(recIdObject);
										// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id"))); //
										// Release Lock
									} catch (Exception ex) {
										// Eat Up
									}
									;

									i$ledgerCurVer.remove("_id");
									i$runningQuery = new JsonObject();

									i$runningQuery = i$Match.deepCopy();
									i$runningQuery.addProperty("isCurrVer", "Y");

									up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
									i$ledgerCurVer.remove("isCurrVer");
									// Updating/ Inserting data to Master
									i$runningQuery = new JsonObject();
									i$runningQuery = i$Match.deepCopy();
									
									// BVB 
									// up$ = db$Ctrl.db$UpdateRow(Coll_Name, i$ledgerCurVer, i$runningQuery, "true");
									up$ = db$Ctrl.db$UpdateRow(Coll_Name, isonMsg, i$ledgerCurVer, i$runningQuery, "true"); // #BVB00029

									return up$;
									/*
									 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									 * "OPERATION FAILED #LUP0001"); return isonMsg; }
									 */
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for CLOSE
							if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {
								try {
									JsonObject u$pdate, m$x, up$ = null;
									u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}", i$Match);
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
										i$body.addProperty("isCurrVer", "Y");
										i$body.addProperty("authStat", "U");
										i$body.addProperty("recordStat", "C");
										i$body.addProperty("operation", SOpr.toUpperCase());
										i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
										i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
										i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
										i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
										i$body.addProperty("authorizer", "");
										i$body.addProperty("errorMsg", "Record Sucessfully Closed");
										i$body.add("authorizedOnSrvDate", null);
										m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
										Integer MaxVer = 0;
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
											MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
										}
										;
										i$body.addProperty("verNo", MaxVer + 1);
										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
										// BVB 
										// up$ = db$Ctrl.db$InsertRow(L_Coll_Name, i$body);
										up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											// JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;
										// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
										return up$;
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												"OPERATION FAILED #LUP0001");
										return isonMsg;
									}
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for DELETE
							if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
								try {
									JsonObject u$pdate, m$x, up$ = null;
									/*
									 * u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
									 * i$Match); if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate),
									 * i$ResM.I_SUCC)) {
									 */
									i$ledgerCurVer.addProperty("isCurrVer", "N");
									i$ledgerCurVer.addProperty("authStat", "A");
									i$ledgerCurVer.addProperty("recordStat", "D");
									i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
									i$ledgerCurVer.addProperty("initiator", IResManipulator.iloggedUser.get());
									// i$ledgerCurVer.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
									i$ledgerCurVer.addProperty("acquiredBy", "");
									i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
									i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Deleted");
									i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date()));
									i$ledgerCurVer.addProperty("remarks", i$ResM.getBodyElementS(i$body, "remarks"));

									// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;

									try {
										JsonObject recIdObject = new JsonObject();
										// if (i$master != null) {
										if (I$utils.$isNull(i$ledgerCurVer)) {
											recIdObject = i$master.getAsJsonObject("_id");
										} else {
											recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
										}
										;
										// JsonObject re$ = i$releaseLock(recIdObject);
										db$Ctrl.db$ReleaseRow(recIdObject);
										// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id"))); //
										// Release Lock
									} catch (Exception ex) {
										// Eat Up
									}
									;
									i$ledgerCurVer.remove("_id");
									i$runningQuery = new JsonObject();

									i$runningQuery = i$Match.deepCopy();
									i$runningQuery.addProperty("isCurrVer", "Y");
									// BVB 
									 //up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
									up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer, i$runningQuery);// #BVB00029
									i$ledgerCurVer.remove("isCurrVer");
									i$runningQuery = new JsonObject();
									i$runningQuery = i$Match.deepCopy();
									if (i$master != null) {
										i$runningQuery.add("verNo", i$master.get("verNo"));
										u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"Y\"}",
												i$runningQuery);
									}

									return up$;
									/*
									 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									 * "OPERATION FAILED #LUP0001"); return isonMsg; }
									 */
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;


							// #BVB00027 Starts   
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SOpr2, "")) {
							// #BVB00027 Ends 
								try {
									JsonObject u$pdate, m$x, up$ = null;
									i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Retrieved");
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$ledgerCurVer);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Record Sucessfully Retrieved");
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;


							// #BVB00027 Starts   
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYMASTER")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SOpr2, "QUERYMASTER")) {
							// #BVB00027 Ends 
								try {
									JsonObject u$pdate, m$x, up$ = null;
									i$master.addProperty("errorMsg", "Record Sucessfully Retrieved");
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$master);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Record Sucessfully Retrieved");
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ")) {
								logger.debug("Forwarding Request to DB Controller for Query Accquire");
								try {
									JsonObject u$pdate, ac$ = null;
									// i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Retrieved");
//									if (i$master != null) {
//										ac$ = db$Ctrl.db$AcqRow(Coll_Name, i$Match);
//									} else {
										ac$ = db$Ctrl.db$AcqRow(L_Coll_Name, i$Match);

									//}
									;
									// if(i$ResM.getStatMsg(ac$))
									// i$ResM.getMsgtext(ac$)
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
											i$ResM.getiStat(ac$));

									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$ledgerCurVer);

									// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Record Sucessfully
									// Acquired");
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							if (I$utils.$iStrFuzzyMatch(SOpr, "RELEASELOCK")) {
								logger.debug("Forwarding Request to DB Controller for Query Accquire");
								try {
									JsonObject rl$ = new JsonObject();
//									JsonObject recIdObject = new JsonObject();
//									if (i$master != null) {
//										recIdObject = i$master.getAsJsonObject("_id");
//									} else {
//										recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
//									}
//									;
//									JsonObject re$ = i$releaseLock(recIdObject);
//									/*
//									 * String recID = i$ResM.convertId(recIdObject); JsonObject re$ =
//									 * db$Ctrl.db$ReleaseRow(recID);
//									 */
//									if (i$master != null) {
//										rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
//									} else {
//										rl$ = db$Ctrl.db$ReleaseRowS(L_Coll_Name, i$Match, IResManipulator.iloggedUser.get());
//
//									}
//									;
									rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
											i$ResM.getiStat(rl$));
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// #BVB00005 Ends
							
							// #BVB00022 Starts 
							if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr2, "CONFIRM")) {
								// Create the collection with projection and save the main data to master.

								// creating the collection
								// Create a dummy Collection from the given Collection ID
								JsonObject filter = new JsonObject();
								String runId = i$body.get("runId").getAsString();
								// String outCollName = "#CREVAL_" + runId;
								// String outCollName = "ICYCLE_" + collateralId; // BVB 
								String outCollName = "COLREV_" + collateralId; // BVB 
								
								filter.addProperty("RUNID", runId);
								JsonObject i$jobLogger = db$Ctrl.db$GetRow("IBRIDGE_S_JOB_LOGGER", filter);

								String collateralColName = i$jobLogger.get("COLLECTION_NAME").getAsString();

								JsonObject projection = new JsonObject();
								projection.addProperty("_id", 0);
								projection.addProperty("EXPOSURE_ID", 1);
								projection.addProperty("COLLATERAL_REF", 1);
								projection.addProperty("COLLATERAL_DESCRIPTION", 1);
								projection.addProperty("COLLATERAL_CATEGORY_ID", 1);
								projection.addProperty("COLLATERAL_VAL_INCEPTION", 1);
								projection.addProperty("COLLATERAL_CATEGORY_DESC", 1);
								projection.addProperty("COLLATERAL_START_DATE", 1);
								projection.addProperty("COLLATERAL_VAL_CURR", 1);

								JsonObject $cp = db$Ctrl.db$copyCollection(collateralColName, outCollName, filter,
										projection);

								if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($cp), "i-SUCC")) {

									logger.debug("Failed in Creating the Reval Collection ");
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
											"FAILED DURING REVAL COLLECTION CREATION");
									return isonMsg;
								} else {
									JsonObject in$ = new JsonObject();
									JsonObject m$x = new JsonObject();
									i$body.addProperty("collectionName", outCollName);
									i$body.addProperty("isCurrVer", "Y");
									i$body.addProperty("authStat", "U");
									i$body.addProperty("recordStat", "O");
									i$body.addProperty("operation", SOpr.toUpperCase());
									i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
									i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
									// i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
									i$body.addProperty("authorizer", "");
									i$body.addProperty("errorMsg", "CONFIRMATION SUCESSFULL");
									i$body.add("authorizedOnSrvDate", null);
									m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
									Integer MaxVer = 0;
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
										MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
									}
									;
									i$body.addProperty("verNo", MaxVer + 1);
									// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
									// BVB 
									// in$ = db$Ctrl.db$InsertRow(L_Coll_Name, i$body);
									in$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body);
									return in$;
								}

							}
							;

							if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYDATA")) {
								try {

									JsonObject filter = new JsonObject();
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									// String cycleCollectionName = icorMCycle.get("collectionName").getAsString();

									String i$collateralId = i$body.get("collateralId").getAsString();
									String collectionName = i$ledgerCurVer.get("collectionName").getAsString();

									JsonObject db$Result = db$Ctrl.db$GetSummRowsPg(collectionName, isonMsg, "{}",
											intPgNo, intRecs);

									return db$Result;

								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
								String collectionName = i$ledgerCurVer.get("collectionName").getAsString();

								JsonArray i$records = new JsonArray();
								i$records = i$body.getAsJsonArray("editedData");

								try {
									for (int i = 0; i < i$records.size(); i++) {
										JsonObject i$runningObj = new JsonObject();
										i$runningObj = i$records.get(i).getAsJsonObject();
										String idSearch = i$ResM.convertId(i$runningObj.get("_id").getAsJsonObject());
										JsonObject setter = new JsonObject();
										try {
											setter.addProperty("COLLATERAL_VAL_CURR",
													i$runningObj.get("COLLATERAL_VAL_CURR").getAsString());
										} catch (Exception e) {
											setter = null;
										}
										JsonObject $up = db$Ctrl.db$UpdateRowId(collectionName, setter, idSearch);

										logger.debug("$up: " + $up);

									}
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Data Saved Successfully");
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
											e.getMessage().toString());
									e.printStackTrace();
									return isonMsg;
								}
							}
							;	
							
							// #BVB00022 Ends

						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									i$validateRes.get("i-Msg").getAsString());
							return isonMsg;
						}
						;

					} else {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
						return isonMsg;
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
							e.getMessage().toString());
					e.printStackTrace();
					return isonMsg;
				}
			} else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
				return isonMsg;
			}

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
//
//	public JsonObject i$releaseLock(JsonObject recIdObject) {
//		try {
//			String recID = i$ResM.convertId(recIdObject);
//			return db$Ctrl.db$ReleaseRow(recID);
//		} catch (Exception e) {
//			return null;
//		}
//	}

	public ICollateralRev() {
		// Cons
	}
}
// #00000001 Ends
