/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.6       | Pappu      | Nov 21, 2022 | #PKY00080   | Initial writing
      ----------------------------------------------------------------------------------------------
      
*/
//#PKY00080 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import javax.print.event.PrintJobAdapter;
import javax.print.event.PrintJobEvent;

public class PrintingJobCompletionMonitor extends PrintJobAdapter {
	private boolean completed = false;

	@Override
	public void printDataTransferCompleted(PrintJobEvent pje) {
		signalCompletion();
	}

	@Override
	public void printJobCompleted(PrintJobEvent pje) {
		signalCompletion();
	}

	@Override
	public void printJobFailed(PrintJobEvent pje) {
		signalCompletion();
	}

	@Override
	public void printJobCanceled(PrintJobEvent pje) {
		signalCompletion();
	}

	@Override
	public void printJobNoMoreEvents(PrintJobEvent pje) {
		signalCompletion();
	}

	private void signalCompletion() {
		synchronized (PrintingJobCompletionMonitor.this) {
			completed = true;
			PrintingJobCompletionMonitor.this.notify();
		}
	}

	public synchronized void waitForJobCompletion() throws InterruptedException {
		while (!completed) {
			wait();
		}
	}
}
//#PKY00080 ends