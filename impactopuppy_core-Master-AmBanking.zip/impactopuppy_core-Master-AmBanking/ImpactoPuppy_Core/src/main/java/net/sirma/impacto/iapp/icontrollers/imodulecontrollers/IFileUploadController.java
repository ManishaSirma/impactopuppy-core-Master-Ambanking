/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Jan 15, 2019 | #BVB00039   | Initial writing
      |0.2.1       | Hasan 		| Feb 11, 2019 | #HAS00001   | Added forEach loop & if condition for processing CSV	file.
      |0.2.1       | Vijay 		| Feb 11, 2019 | #BVB00072   | PDF Upload 
      |0.2.1       | Hasan 		| Mar 04, 2019 | #HAS00002   | Adding fields which has XMLTag value.
      |0.2.1       | Vijay 		| Mar 16, 2019 | #BVB00094   | SDN CSV File Upload issues
      |0.2.1       | Vijay  	| Mar 16, 2019 | #BVB00095   | Saving SDN List Type to SDN upload data
      |0.2.1       | Vijay  	| Mar 17, 2019 | #BVB00099   | Error Code Handling 
      |0.2.1       | Vijay  	| Apr 29, 2019 | #BVB00134   | Adding Soundex, Metaphone3 and NYSIIS
      |0.3.8       | Vijay  	| May 14, 2019 | #BVB00152   | SDN new Logical Flow
      |0.3.15      | Vijay  	| Jun 17, 2019 | #BVB00168   | HTML File Upload Changes  
      |0.3.17      | Vijay  	| Jul 08, 2019 | #BVB00179   | Changes for Cumulative Upload 
      |3.1.2.419   | Hasan 		| NOV 26, 2019 | #HAS00003   | Added code for HTML file process
      |3.1.2.419   | Manikanta  | Jan 18, 2022 | #MVT00026   | Added code to update full name in xml
      |3.1.2.419   | Manikanta  | Jan 18, 2022 | #MVT00027   | Added code to update full name in CSV
      |3.1.2.419   | Manikanta  | Jan 18, 2022 | #MVT00028   | Added code for repeat nodes in xml
      ----------------------------------------------------------------------------------------------
*/
// #BVB00039 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.zip.ZipInputStream;

import org.apache.commons.codec.language.Nysiis;
import org.apache.commons.codec.language.Soundex;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.underscore.lodash.U;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ialgo.iMetaphone3;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
//import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.iEmailService;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class IFileUploadController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IFileUploadController.class);
	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private IgenericWorker igenericWorker = new IgenericWorker();
	private JsonObject i$Annotate = new JsonObject();
	private IMacronController i$ImacroCtrl = new IMacronController();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		// JsonObject i$Annotate = null;
		String Coll_Name, L_Coll_Name;
		Gson gson = new Gson();
		JsonObject projection = new JsonObject();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
		try {

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		// JsonObject argJson = new JsonObject();

		try {
			IFileUploadController i$FileUplCon = new IFileUploadController(); // Need to change in every controller
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			isonMsg = i$FileUplCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			// Adding Pre Response Message Handler

			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}

	public ZipInputStream getZipContent(byte[] zipData) {
		// byte[] zipFileBytes;
		ZipInputStream zis;
		try {
			// zipFileBytes= Files.readAllBytes(path);
			ByteArrayInputStream bis = new ByteArrayInputStream(zipData);
			zis = new ZipInputStream(bis);

		} catch (Exception e) {
			zis = null;
		}

		return zis;
	}

	// #BVB00099 Starts
	// public JsonObject fileToCSV(String collName, JsonObject argJson,
	// BufferedReader br) throws IOException {

	public JsonObject fileToCSV(String collName, JsonObject argJson, BufferedReader br) throws IOException {
		String i$Msg = "";
		JsonObject i$res = new JsonObject();
		// #BVB00099 Ends
		JsonObject mapJson = new JsonObject();
		JsonObject i$lobj = new JsonObject();
		JsonObject i$lobjMacron = new JsonObject();
		JsonArray i$lineArr = new JsonArray();
		JsonArray i$lineMacronArr = new JsonArray();
		JsonArray i$lineMacronFilterArr = new JsonArray();
		JsonArray insertData = new JsonArray();
		Gson gson = new Gson();
		// #BVB00099 Starts
		int countOfRec = 0;
		int countOfUpload = 0;
		// #BVB00134 Starts
		Soundex soundex = new Soundex();
		Nysiis nysiis = new Nysiis();
		iMetaphone3 metaphone3 = new iMetaphone3();
		JsonObject filter = new JsonObject();
		// #BVB00134 Ends
		try {
			JsonArray fieldMapping = argJson.getAsJsonArray("fieldMapping");
			String SdnListId = argJson.get("SdnListId").getAsString();
			// Get fields req for Macros from icor_c_sdn_param

			filter.addProperty("PARAM", "MacroReqFields");
			JsonArray macroReqArr = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");

			// #BVB00099 Ends
			for (int j = 0; j < fieldMapping.size(); j++) {
				JsonObject i$runningObj = fieldMapping.get(j).getAsJsonObject();
				if (!I$utils.$iStrFuzzyMatch(i$runningObj.get("MappingFieldNo").getAsString(), "")) { // #HAS00001 Added
					mapJson.addProperty(i$runningObj.get("MappingFieldNo").getAsString(),
							i$runningObj.get("FieldName").getAsString());
				}

			}

			filter.addProperty("PARAM", "PhoneticReqFields");
			JsonArray phonReqFlds = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");

			String line = br.readLine(); // Reads 1 line
			// Construct the Field Names
			// String FldNames[] = new String[n];
			JsonArray FldNames = new JsonArray();
			JsonArray FldKeys = new JsonArray(); // #BVB00094
//			for (int j = 1; j <= mapJson.size(); j++) {									//#HAS00001 Commented
//	//			FldNames.add(mapJson.get("FIELD" + j).getAsString());
//					FldNames.add(mapJson.get( Integer.toString(j)).getAsString());					
//			}
			// #HAS00001 Start
			for (Object key : mapJson.keySet()) {
				// based on you key types
				String keyStr = (String) key;
				FldNames.add(mapJson.get(keyStr).getAsString());
				FldKeys.add(keyStr); // #BVB00094
			}
			// #HAS00001 Ends
			// #BVB00179 Starts 
			// Moving the existing records to History Collection

			JsonObject icorMSDN = argJson.getAsJsonObject("icorMSDN");
			String cummulativeAll = "N";
			try {
				cummulativeAll = icorMSDN.get("CumulativeData").getAsString();
			} catch (Exception e) {
				cummulativeAll = "N";
			}
			if (I$utils.$iStrFuzzyMatch(cummulativeAll, "Y")) {
				// Delete the records
				filter = new JsonObject();
				filter.addProperty("SdnListId", SdnListId);
				db$Ctrl.db$Remove("ICOR_M_SDN_DETAIL", filter);
				db$Ctrl.db$Remove("ICOR_M_SDN_DET_MICRONS", filter);
			}
			// #BVB00179 Ends
			while (line != null) {
				String[] temp = line.split(",");
				for (int m = 0; m < FldNames.size(); m++) {
					try {
						// String i$runningStr = temp[m].trim().replace("\"", ""); // #BVB00094
						// COmmented
						String i$runningFldName = FldNames.get(m).getAsString();
						String i$runningStr = temp[FldKeys.get(m).getAsInt() - 1].trim().replace("\"", ""); // #BVB00094
						// #BVB00134 Starts
						i$lobj.addProperty(i$runningFldName, i$runningStr);
						if (I$utils.isInArray(phonReqFlds, i$runningFldName)) {
							i$lobj.addProperty("_S_" + i$runningFldName, soundex.soundex(i$runningStr));
							i$lobj.addProperty("_N_" + i$runningFldName, nysiis.encode(i$runningStr));
							metaphone3.SetWord(i$runningStr);
							metaphone3.Encode();
							i$lobj.addProperty("_M_" + i$runningFldName, metaphone3.GetMetaph());
						}
						// #BVB00134 Ends
					} catch (Exception e) {
						i$lobj.addProperty(FldNames.get(m).getAsString(), "NA");
					}
				}//#MVT00027 starts
				if (!I$utils.isInArray(FldNames, "FullName")) {
					String fName, mName, lName;
					StringBuilder finalName = new StringBuilder();
					if (i$lobj.has("FName")) {
						fName = i$lobj.get("FName").getAsString();
						finalName.append(fName);
					}
					if (i$lobj.has("MName")) {
						mName = i$lobj.get("MName").getAsString();
						finalName.append(" " + mName);
					}
					if (i$lobj.has("LName")) {
						lName = i$lobj.get("LName").getAsString();
						finalName.append(" " + lName);
					}
					String fullName = finalName.toString();
					i$lobj.addProperty("FullName", fullName);
					i$lobj.addProperty("_S_" + "FullName", soundex.soundex(fullName));
					i$lobj.addProperty("_N_" + "FullName", nysiis.encode(fullName));
					metaphone3.SetWord(fullName);
					metaphone3.Encode();
					i$lobj.addProperty("_M_" + "FullName", metaphone3.GetMetaph());
				}//#MVT00027 ends
				i$lobj.addProperty("SdnListId", SdnListId);
				try {
					// JsonObject macronFilter = new JsonObject();
					i$lobjMacron = i$ImacroCtrl.loadSdnMac(i$lobj, macroReqArr);
					filter = new JsonObject();
					filter.addProperty("Micron_ID", i$lobjMacron.get("Micron_ID").getAsString());
					filter.addProperty("FieldName", i$lobjMacron.get("FieldName").getAsString());
					i$lineMacronFilterArr.add(filter);
					i$lineMacronArr.add(i$lobjMacron);
//					//macronFilter = 
				} catch (Exception e) {

				}

				i$lineArr.add(i$lobj);
				// i$lobj = null;
				i$lobj = new JsonObject();
				i$lobjMacron = new JsonObject();
				filter = new JsonObject();
				/*
				 * if (i$lineArr.size() != 0 && i$lineArr.size() % 200 == 0) { i$lineArr = null;
				 * i$lineArr = new JsonArray(); }
				 */
				countOfRec++;
				line = br.readLine(); // Reads another line per iteration
				if (countOfRec % 200 == 0) {

					try {
						// insert(insertData);
						db$Ctrl.db$InsertMany(collName, i$lineArr);
						countOfUpload = countOfUpload + i$lineArr.size();
						db$Ctrl.db$UpdateMany("ICOR_M_SDN_DET_MICRONS", i$lineMacronArr, i$lineMacronFilterArr, "true");
						i$lineArr = new JsonArray();
						i$lineMacronArr = new JsonArray();
						i$lineMacronFilterArr = new JsonArray();
					} catch (Exception e) {

					}

				}

			}
			insertData = new JsonArray();
			// int size = i$lineArr.size();
			// for (int i = 0; i < size; i++) {
			// insertData.add(i$lineArr.get(i));
			// if (i % 200 == 0) {
			try {
				// insert(insertData);
				db$Ctrl.db$InsertMany(collName, i$lineArr);
				countOfUpload = countOfUpload + i$lineArr.size();
			} catch (Exception e) {

			}
			insertData = new JsonArray();
			// } else if (i == size - 1) {
//					try {
//						// insert(insertData);
//						db$Ctrl.db$InsertMany(collName, insertData);
//						countOfUpload = countOfUpload + insertData.size();
//					} catch (Exception e) {
//
//					}
//					insertData = new JsonArray();
			// }

			// }
			//

			// insertData = new JsonArray();
			// size = i$lineMacronArr.size();
			// for (int i = 0; i < size; i++) {
			// insertData.add(i$lineMacronArr.get(i));
			// if (i % 200 == 0) {
			try {
				// UpdateMany
				db$Ctrl.db$UpdateMany("ICOR_M_SDN_DET_MICRONS", i$lineMacronArr, i$lineMacronFilterArr, "true");

				// insert(insertData);
				// db$Ctrl.db$InsertMany(collName, insertData);
				// countOfUpload = countOfUpload + insertData.size();
			} catch (Exception e) {

			}
			insertData = new JsonArray();
			// } else if (i == size - 1) {
//					try {
//						db$Ctrl.db$UpdateMany(collName, i$lineMacronArr, i$lineMacronFilterArr, "true");
//						// insert(insertData);
//						// db$Ctrl.db$InsertMany(collName, insertData);
//						// countOfUpload = countOfUpload + insertData.size();
//					} catch (Exception e) {
//
//					}
//					insertData = new JsonArray();
			// }

			// }

		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed in Converting File to CSV " + e.getMessage());
			i$Msg = "Failed in Converting File to CSV " + e.getMessage();
		}
		// #BVB00099 Starts
		i$res.addProperty("i$Msg", i$Msg);
		i$res.addProperty("countOfRec", countOfRec);
		i$res.addProperty("countOfUpload", countOfUpload);

		return i$res;
		// #BVB00099 Ends
	}

	public JsonObject processCSVContent(String collName, InputStream contentsIn, JsonObject argJson) {
		String i$Msg = "";
		JsonObject i$res = new JsonObject();

		try {
			// JsonArray fieldMapper= argJson.getAsJsonArray("fieldMapper");
			BufferedReader bfReader = new BufferedReader(new InputStreamReader(contentsIn));
			i$res = fileToCSV(collName, argJson, bfReader);
			contentsIn.close();
		} catch (Exception e) {
			// e.printStackTrace();
			logger.info("Failed in Process CSV Content with: " + e.getMessage());
			i$Msg = "Failed in Process CSV Content with: " + e.getMessage();
		}

		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$res.addProperty("i-stat", "1"); // #NYE00021
			i$res.addProperty("i-Msg", "ALL GOOD");// #NYE00021
		} else {
			i$res.addProperty("i-stat", "0");// #NYE00021
			i$res.addProperty("i-Msg", i$Msg);// #NYE00021
		}

		return i$res;
	}

	public JsonObject xmlParser(ZipInputStream zipIn) {
		String result = "";
		String i$Msg = "";
		JsonObject i$res = new JsonObject();
		try {
			BufferedReader bfReader = new BufferedReader(new InputStreamReader(zipIn));
			String content = org.apache.commons.io.IOUtils.toString(bfReader);
			result = U.xmlToJson(content);
		} catch (Exception e) {
			logger.debug("Failed in xmlParser: " + e.getMessage());
			result = null;
			i$Msg = "Failed in xmlParser: + " + e.getMessage();
		}
		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$res.addProperty("i-stat", "1"); // #NYE00021
			i$res.addProperty("i-Msg", "ALL GOOD");// #NYE00021
			i$res.addProperty("result", result);
		} else {
			i$res.addProperty("i-stat", "0");// #NYE00021
			i$res.addProperty("i-Msg", i$Msg);// #NYE00021
			i$res.addProperty("result", "");// #NYE00021
		}
		return i$res;
	}

	/**
	 * Need to convert the return type of this
	 * 
	 * @param collName
	 * @param zipIn
	 * @param sdnDetail
	 * @throws IOException
	 */

	public JsonObject processXMLContent(String collName, ZipInputStream zipIn, JsonObject argJson) throws IOException {
		String i$Msg = "";
		JsonObject i$res = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject i$lobjMacron = new JsonObject();
		JsonArray i$lineMacronArr = new JsonArray();
		JsonArray i$lineMacronFilterArr = new JsonArray();
		int countOfRec = 0;
		int countOfUpload = 0;
		try {
			filter.addProperty("PARAM", "MacroReqFields");
			JsonArray macroReqArr = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");

			// String xmlJsonContent = xmlParser(zipIn);
			JsonObject smlToJsonRes = xmlParser(zipIn);
			if (smlToJsonRes.get("i-stat").getAsInt() > 0) {

				// Success came back
				String xmlJsonContent = smlToJsonRes.get("result").getAsString();
				JsonParser parser = new JsonParser();
				JsonObject parent = parser.parse(xmlJsonContent).getAsJsonObject();
				JsonObject sdnDetail = argJson.getAsJsonObject("sdnDetail");
				JsonArray entryA = getArray(parent, sdnDetail);
				JsonArray NewFieldMapper = new JsonArray(); // HAS00002 Added
				JsonArray FieldMapper = sdnDetail.getAsJsonArray("Field_Mapper");
				String SdnListId = argJson.get("SdnListId").getAsString();
				// HAS00002 Start
				for (int j = 0; j < FieldMapper.size(); j++) {
					JsonObject i$runningObj = FieldMapper.get(j).getAsJsonObject();
					if (!I$utils.$iStrFuzzyMatch(i$runningObj.get("XMLTag").getAsString(), "")) {
						NewFieldMapper.add(i$runningObj);
					}
				}
				// HAS00002 End
				// #BVB00179 Starts 
				JsonObject icorMSDN = argJson.getAsJsonObject("icorMSDN");
				String cummulativeAll = "Y";
				try {
					cummulativeAll = icorMSDN.get("CumulativeData").getAsString();
				} catch (Exception e) {
					cummulativeAll = "Y";
				}
				if (I$utils.$iStrFuzzyMatch(cummulativeAll, "N")) {
					// Delete the records
					filter = new JsonObject();
					filter.addProperty("SdnListId", SdnListId);
					db$Ctrl.db$Remove("ICOR_M_SDN_DETAIL", filter);
					db$Ctrl.db$Remove("ICOR_M_SDN_DET_MICRONS", filter);
				}
				// #BVB00179 Ends
				logger.info("Size of the array: " + entryA.size());
				JsonArray finalData = new JsonArray();
				// getVariables(argJson);
				JsonObject iRunningTemp = new JsonObject();
				for (int i = 0; i < entryA.size(); i++) {
					try {
						iRunningTemp = new JsonObject();
						JsonObject i$runningObj = entryA.get(i).getAsJsonObject();
						iRunningTemp = getValues(NewFieldMapper, i$runningObj); // HAS00002 Added
						iRunningTemp.addProperty("SdnListId", SdnListId);
						try {
							// i$ImacroCtrl.loadSdnMac(iRunningTemp, macroReqArr);
							i$lobjMacron = i$ImacroCtrl.loadSdnMac(iRunningTemp, macroReqArr);
							filter = new JsonObject();
							filter.addProperty("Micron_ID", i$lobjMacron.get("Micron_ID").getAsString());
							filter.addProperty("FieldName", i$lobjMacron.get("FieldName").getAsString());
							i$lineMacronFilterArr.add(filter);
							i$lineMacronArr.add(i$lobjMacron);
						} catch (Exception e) {
							// need to add logger for failed insertions
						}
						finalData.add(iRunningTemp);
					} catch (Exception e) {
						logger.debug("Failed while processing Upload for a record");
					}

					countOfRec++;
					if (countOfRec % 200 == 0) {
						try {
							// insert(insertData);
							db$Ctrl.db$InsertMany(collName, finalData);
							countOfUpload = countOfUpload + finalData.size();
							db$Ctrl.db$UpdateMany("ICOR_M_SDN_DET_MICRONS", i$lineMacronArr, i$lineMacronFilterArr,
									"true");
							finalData = new JsonArray();
							i$lineMacronArr = new JsonArray();
							i$lineMacronFilterArr = new JsonArray();
						} catch (Exception e) {

						}

					}
				}
				JsonArray insertData = new JsonArray();
				int size = finalData.size();
//				for (int i = 0; i < size; i++) {
//					insertData.add(finalData.get(i));
//					if (i % 200 == 0 || i == size - 1) {
				try {
					// insert(insertData);
					db$Ctrl.db$InsertMany(collName, finalData);
					countOfUpload = countOfUpload + finalData.size();
					db$Ctrl.db$UpdateMany("ICOR_M_SDN_DET_MICRONS", i$lineMacronArr, i$lineMacronFilterArr, "true");
				} catch (Exception e) {

				}
				insertData = new JsonArray();
				// }
				// }
			} else {
				i$Msg = smlToJsonRes.get("i-Msg").getAsString();
			}
		} catch (Exception e) {
			logger.debug("Failed in Process XML Content: " + e.getMessage());
			i$Msg = "Failed in Process XML Content: " + e.getMessage();
		}

		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$res.addProperty("i-stat", "1"); // #NYE00021
			i$res.addProperty("i-Msg", "ALL GOOD");// #NYE00021
		} else {
			i$res.addProperty("i-stat", "0");// #NYE00021
			i$res.addProperty("i-Msg", i$Msg);// #NYE00021
		}

		return i$res;
	}

	public JsonArray getArray(JsonObject input, JsonObject sdnDetails) {
		JsonArray arrayOfItems = new JsonArray();
		JsonObject inp = new JsonObject();	//#MVT00028 Changes starts
		JsonArray arrayOfItem = new JsonArray();
		try {
			JsonArray parentId = sdnDetails.get("parentNode").getAsJsonArray();
			input = input.getAsJsonObject(parentId.get(0).getAsString());
			for (int i = 0; i < parentId.size(); i++) {
				try {
					inp = input.getAsJsonObject(parentId.get(i).getAsString());
					String[] repeat = sdnDetails.get("repeatNode").getAsString().split(",");
					for (int j = 0; j < repeat.length; j++) {
						try {
							arrayOfItem = inp.getAsJsonArray(repeat[j]);
							arrayOfItems.addAll(arrayOfItem);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					arrayOfItems = null;
				}	//#MVT00028 Changes ends
			}
			;
		} catch (Exception e) {
			arrayOfItems = null;
		}
		return arrayOfItems;
	}

	public JsonObject getValues(JsonArray fieldMapping, JsonObject input) {
		// JsonArray response = new JsonArray();
		JsonObject respRunning = new JsonObject();
		String currVal = "";
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		// #BVB00134 Starts
		Soundex soundex = new Soundex();
		Nysiis nysiis = new Nysiis();
		iMetaphone3 metaphone3 = new iMetaphone3();
		JsonObject filter = new JsonObject();
		// #BVB00134 Ends
		try {
			// JsonArray fieldMapping = argJson.getAsJsonArray("Field_Mapper");
			respRunning = new JsonObject();
			filter.addProperty("PARAM", "PhoneticReqFields");
			JsonArray phonReqFlds = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");

			for (int i = 0; i < fieldMapping.size(); i++) {

				JsonObject i$runningObj = new JsonObject();
				i$runningObj = fieldMapping.get(i).getAsJsonObject();
				String fieldName = i$runningObj.get("FieldName").getAsString();

				String xmlTag = i$runningObj.get("XMLTag").getAsString();

				String[] xmlTags = xmlTag.split("\\.");
				if (xmlTags.length == 0) {
					xmlTags = new String[1];
					xmlTags[0] = xmlTag;
				}
				// int size = xmlTags.length;
				currVal = getDataFromObject(xmlTags, input);
				// respRunning.addProperty(fieldName, currVal);

				try {
					JsonArray currValA = parser.parse(currVal).getAsJsonArray();
					respRunning.add(fieldName, currValA);
				} catch (Exception e) {
					try {
						JsonObject currValO = parser.parse(currVal).getAsJsonObject();
						respRunning.add(fieldName, currValO);
					} catch (Exception ec) {
						respRunning.addProperty(fieldName, currVal);
						// #BVB00134 Starts
						if (I$utils.isInArray(phonReqFlds, fieldName)) {
							respRunning.addProperty("_S_" + fieldName, soundex.soundex(currVal));
							respRunning.addProperty("_N_" + fieldName, nysiis.encode(currVal));
							metaphone3.SetWord(currVal);
							metaphone3.Encode();
							respRunning.addProperty("_M_" + fieldName, metaphone3.GetMetaph());
						}
						// #BVB00134 Ends
					}
				}
				/*
				 * respRunning.addProperty("XMLTag", xmlTag); respRunning.add(property, value);
				 */

			}//#MVT00026 starts
			if (!respRunning.has("FullName")) {
				String fName, mName, lName;
				StringBuilder finalName = new StringBuilder();
				if (respRunning.has("FName")) {
					fName = respRunning.get("FName").getAsString();
					finalName.append(fName + " ");
				}
				if (respRunning.has("MName")) {
					mName = respRunning.get("MName").getAsString();
					finalName.append(mName + " ");
				}
				if (respRunning.has("LName")) {
					lName = respRunning.get("LName").getAsString();
					finalName.append(lName);
				}
				String fullName = finalName.toString();
				respRunning.addProperty("FullName", fullName);
				respRunning.addProperty("_S_" + "FullName", soundex.soundex(fullName));
				respRunning.addProperty("_N_" + "FullName", nysiis.encode(fullName));
				metaphone3.SetWord(fullName);
				metaphone3.Encode();
				respRunning.addProperty("_M_" + "FullName", metaphone3.GetMetaph());
			}//#MVT00026 ends
		} catch (Exception e) {
			e.printStackTrace();
			respRunning = null;
		}

		return respRunning;
	}

	public String getDataFromObject(String[] xmlTags, JsonObject input) {
		String currVal = "";
		Gson gson = new Gson();
		try {
			int size = xmlTags.length;
			for (int i = 0; i < xmlTags.length; i++) {
				String i$runningS = xmlTags[i];

				if (i != size - 1) {

					// if ($iStrFuzzyMatch(i$runningS, "[]")) {
					if (input.get(i$runningS).isJsonArray()) {
						// input.get(i$runningS.substring(0, i$runningS.length() - 2)).getAsJsonArray();
						JsonArray i$runningArr = new JsonArray();
						i$runningArr = input.get(i$runningS).getAsJsonArray();
						JsonArray collectingData = new JsonArray();
						for (int j = 0; j < i$runningArr.size(); j++) {
							collectingData.add(getDataFromObject(refineArrayS(xmlTags, i + 1),
									i$runningArr.get(j).getAsJsonObject()));
						}
						currVal = gson.toJson(collectingData);
						break;
						// Get data from Sub Array
					} else {
						// Get Data from the Object
						try {
							currVal = getDataFromObject(refineArrayS(xmlTags, i + 1),
									input.getAsJsonObject(i$runningS));
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
					}

				} else {
					try {
						currVal = input.get(i$runningS).getAsString();
					} catch (Exception e) {
						// e.printStackTrace();
						// logger.debug(":i$runningS" + i$runningS + " " + i + " " +
						// e.getMessage() );
						currVal = "";
					}

				}

			}

		} catch (Exception e) {
			// e.printStackTrace();
			// Eat Up
			currVal = "";
		}
		return currVal;
	}

	public String[] refineArrayS(String[] inArray, int startIndex) {
		int size = inArray.length;
		String[] res = Arrays.copyOfRange(inArray, startIndex, size);

		return res;

	}

	// #BVB00072 Starts
	public JsonObject processPDFContent(JsonObject argJson, InputStream contentsIn) {
		String pdfText = "";
		JsonObject setter = new JsonObject();
		JsonObject filter = new JsonObject();
		String i$Msg = "";
		JsonObject i$res = new JsonObject();

		try {
			String collName = argJson.get("collName").getAsString();
			String SdnListId = argJson.get("SdnListId").getAsString();
			PDDocument document = PDDocument.load(contentsIn);

			// Instantiate PDFTextStripper class
			PDFTextStripper pdfStripper = new PDFTextStripper();

			// Retrieving text from PDF document
			pdfText = pdfStripper.getText(document);
			logger.debug("Length: " + pdfText.length());
			document.close();
			setter.addProperty("content", pdfText);
			setter.addProperty("SdnListId", SdnListId);

			filter.addProperty("SdnListId", SdnListId);
			db$Ctrl.db$UpdateRow(collName, setter, filter, "true");

		} catch (Exception e) {
			logger.debug("Failed in Process Msg: " + e.getMessage());
			i$Msg = "Failed in Process Msg: " + e.getMessage();
		}

		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$res.addProperty("i-stat", "1"); // #NYE00021
			i$res.addProperty("i-Msg", "ALL GOOD");// #NYE00021
		} else {
			i$res.addProperty("i-stat", "0");// #NYE00021
			i$res.addProperty("i-Msg", i$Msg);// #NYE00021
		}

		return i$res;
	}

	// #BVB00072 Ends
	public void processJSONContent(JsonObject argJson, InputStream contentsIn) {
		try {
			BufferedReader bfReader = new BufferedReader(new InputStreamReader(contentsIn));
			String content = org.apache.commons.io.IOUtils.toString(bfReader);
			String collName = argJson.get("collName").getAsString();
			JsonParser parser = new JsonParser();
			JsonArray finalData = parser.parse(content).getAsJsonArray();

			JsonArray insertData = new JsonArray();
			int size = finalData.size();
			for (int i = 0; i < size; i++) {
				insertData.add(finalData.get(i));
				if (i % 200 == 0 || i == size - 1) {
					try {
						// insert(insertData);
						db$Ctrl.db$InsertMany(collName, insertData);
					} catch (Exception e) {

					}
					insertData = new JsonArray();
				}
			}

			logger.debug("Completed JSON insertion sucessfully");
		} catch (Exception e) {
			logger.debug("Failed while inserting into DB with: " + e.getMessage());
			e.printStackTrace();

		}
	}

// #BVB00168 Starts 
	public JsonObject processHTMLContent(JsonObject argJson) {
		String i$Msg = "";
		JsonObject i$res = new JsonObject();
		JsonArray headersArr = new JsonArray();
		JsonObject icorMSDN = new JsonObject();
		JsonArray fieldMapping = new JsonArray();
		JsonObject filter = new JsonObject();
		JsonObject i$lobjMacron = new JsonObject();
		JsonArray i$lineMacronArr = new JsonArray();
		JsonArray i$lineMacronFilterArr = new JsonArray();
		JsonArray i$lineArr = new JsonArray();
		int countOfRec = 0;
		int countOfUpload = 0;
		String SdnListId = "";
		Soundex soundex = new Soundex();
		Nysiis nysiis = new Nysiis();
		iMetaphone3 metaphone3 = new iMetaphone3();
		try {
			String fileContent = argJson.get("fileContent").getAsString();
			icorMSDN = argJson.getAsJsonObject("icorMSDN");
			SdnListId = icorMSDN.get("Sdn_List_Id").getAsString();
			filter.addProperty("PARAM", "MacroReqFields");
			JsonArray macroReqArr = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");

			filter = new JsonObject();
			filter.addProperty("PARAM", "PhoneticReqFields");
			JsonArray phonReqFlds = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");

			Document doc = Jsoup.parse(fileContent);
			Elements rows = doc.select("tr");
			Elements headers = null;
			if(rows.select("th").size()>0) {				//#HAS00003 Added
				 headers = rows.select("th");	
			}else if(rows.get(0).select("tr").size() > 0){
				 headers = rows.get(0).select("tr").select("div");
			};			
			fieldMapping = icorMSDN.get("Field_Mapper").getAsJsonArray();
			for (Element header : headers) {
				// headersArr.add(header.text());
				headersArr.add(I$impactoUtil.objFromArrWithSearch(fieldMapping, "Tag", header.text()));
				// JsonObject filedMap = I$impactoUtil.objFromArrWithSearch(fieldMapping, "Tag",
				// header.text());
			}
			JsonObject i$lobj = new JsonObject();
			JsonArray dataArr = new JsonArray();
			for (Element row : rows) {				
				Elements columns = null;
				try {
					if(row.select("td").select("div").size()>0) {			//#HAS00003 Added
						 columns = row.select("td").select("div");
					}else {
						 columns = row.select("td");					
					}					
				}catch(Exception e) {
					 columns = row.select("td");
				}
				int i = 0;
				i$lobj = new JsonObject();
				for (Element column : columns) {
					try {
						String i$runningFldName = headersArr.get(i).getAsJsonObject().get("FieldName").getAsString();
						String i$runningStr = column.text();
						i$lobj.addProperty(i$runningFldName, i$runningStr);
						if (I$utils.isInArray(phonReqFlds, i$runningFldName)) {
							i$lobj.addProperty("_S_" + i$runningFldName, soundex.soundex(i$runningStr));
							i$lobj.addProperty("_N_" + i$runningFldName, nysiis.encode(i$runningStr));
							metaphone3.SetWord(i$runningStr);
							metaphone3.Encode();
							i$lobj.addProperty("_M_" + i$runningFldName, metaphone3.GetMetaph());
						}						
					}catch(Exception e) {}
					i++;
				}
				if (I$utils.$isNull(i$lobj)) {
					continue;
				}
				i$lobj.addProperty("SdnListId", SdnListId);
				try {
					// JsonObject macronFilter = new JsonObject();
					i$lobjMacron = i$ImacroCtrl.loadSdnMac(i$lobj, macroReqArr);
					filter = new JsonObject();
					filter.addProperty("Micron_ID", i$lobjMacron.get("Micron_ID").getAsString());
					filter.addProperty("FieldName", i$lobjMacron.get("FieldName").getAsString());
					i$lineMacronFilterArr.add(filter);
					i$lineMacronArr.add(i$lobjMacron);
//					//macronFilter = 
				} catch (Exception e) {

				}

				i$lineArr.add(i$lobj);
				// i$lobj = null;
				i$lobj = new JsonObject();
				i$lobjMacron = new JsonObject();
				filter = new JsonObject();
				/*
				 * if (i$lineArr.size() != 0 && i$lineArr.size() % 200 == 0) { i$lineArr = null;
				 * i$lineArr = new JsonArray(); }
				 */
				countOfRec++;
				if (countOfRec % 200 == 0) {

					try {
						// insert(insertData);
						db$Ctrl.db$InsertMany("ICOR_M_SDN_DETAIL", i$lineArr);
						countOfUpload = countOfUpload + i$lineArr.size();
						db$Ctrl.db$UpdateMany("ICOR_M_SDN_DET_MICRONS", i$lineMacronArr, i$lineMacronFilterArr, "true");
						i$lineArr = new JsonArray();
						i$lineMacronArr = new JsonArray();
						i$lineMacronFilterArr = new JsonArray();
					} catch (Exception e) {

					}

				}
				// dataArr.add(rowObj);
				// logger.debug();
			}

			try {
				// insert(insertData);
				if (i$lineArr.size() > 0)

				{
					db$Ctrl.db$InsertMany("ICOR_M_SDN_DETAIL", i$lineArr);
				}
				countOfUpload = countOfUpload + i$lineArr.size();
			} catch (Exception e) {

			}

			try {
				// UpdateMany
				if (i$lineMacronArr.size() > 0) {
					db$Ctrl.db$UpdateMany("ICOR_M_SDN_DET_MICRONS", i$lineMacronArr, i$lineMacronFilterArr, "true");
				}

			} catch (Exception e) {

			}

			// db$Ctrl.db$InsertMany("ICOR_M_SDN_DETAILS1", dataArr);
		} catch (Exception e) {
			i$Msg = "Failed in Uploading From Web: " + e.getMessage();
		}
		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$res.addProperty("i-stat", "1"); // #NYE00021
			i$res.addProperty("i-Msg", "ALL GOOD");// #NYE00021
		} else {
			i$res.addProperty("i-stat", "0");// #NYE00021
			i$res.addProperty("i-Msg", i$Msg);// #NYE00021
		}

		return i$res;

	}
// #BVB00168 Ends


}