/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.7       | Vijay 		| May 05, 2019 | #BVB00131   | Initial writing
      |2.3.1       | Vijay 		| Sep 24, 2019 | #BVB00213   | Query Executor for Oracle
      |2.3.1       | Syed 		| Oct 09, 2019 | #MAQ00046   | Added condition to neglect values
      |2.3.1       | Pappu      | Jun 03, 2021 | #PKY00015   | Added  condition to execute aggregateArray Query.
      |2.3.1       | Sindhu     | Aug 10, 2023 | #SRM00055   | Handled for getting the analytics in backoffice.
      ----------------------------------------------------------------------------------------------
*/
// #BVB00131 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IQueryExecutor {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IQueryExecutor.class);
	private ICoreSysReqFwderController i$coreReq = new ICoreSysReqFwderController();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OCRQRYEX") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = executeQueryHandler(isonMsg); // #BVB00213 
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}

		} catch (Exception e) {

		}
		return isonMsg;
	}
// #BVB00213 Starts 
	public JsonObject executeQueryHandler(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			// Get Enquiry id and get the fields
			String enquiryType = i$ResM.getBodyElementS(isonMsg, "enquiryType");
			filter.addProperty("enquiryType", enquiryType);
			JsonObject icorMEnquiry = db$Ctrl.db$GetRow("ICOR_M_ENQUIRY", filter);
			// Check if mode is Mongo or Oracle
			String mode = i$ResM.getStrfromObj(icorMEnquiry, "mode");
			if (I$utils.$iStrFuzzyMatch(mode, i$ResM.I_MONGO) || I$utils.$iStrFuzzyMatch(mode, "")) {
				isonMsg = executeQuery(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(mode, i$ResM.I_ORACLE)) {
				isonMsg = executeOracleQuery(isonMsg, icorMEnquiry);
			}

		} catch (Exception e) {

		}
		return isonMsg;
	}

	public JsonObject executeOracleQuery(JsonObject isonMsg, JsonObject icorMEnquiry) {
		try {
			JsonParser parserM = new JsonParser(); 

			// Get the query and create trnData (By default only one field will be there
			// always )
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonArray filedsDetails = icorMEnquiry.getAsJsonArray("filedsDetails");
			String query = icorMEnquiry.get("query").getAsString();
			JsonObject trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			String fieldNames = "";
			for (int i = 0; i < filedsDetails.size(); i++) {
				JsonObject i$runningObj = filedsDetails.get(i).getAsJsonObject();
				if (I$utils.$iStrFuzzyMatch(fieldNames, "")) {
					fieldNames = i$ResM.getStrfromObj(i$runningObj, "fieldName");
				} else {
					fieldNames = fieldNames + ", " + i$ResM.getStrfromObj(i$runningObj, "fieldName");
				}
			}

			// Get formatter String
			trnData.addProperty("fieldNames", fieldNames);
			query = i$impactoUtil.getFormattedTmpl(query, trnData);

			trnData.addProperty("query", query);
			trnData.addProperty("branch", icorMEnquiry.get("branch").getAsString());
			i$body.add("trnData", trnData);
			
			i$body.addProperty("trnCd", "QueryExecutor");
			i$body.addProperty("trnOpr", "QUERY"); 
				
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body); 
			isonMsg = i$coreReq.coreReqFwd(isonMsg);
			
			// Get the reps Body 
			String respBody = i$ResM.getBodyElementS(isonMsg, "sXmlBody");
			// parse the body 
			JsonObject respBodyObj = i$impactoUtil.xmlParser(respBody);
			
			
			// Create the new structure required 
			JsonArray i$resp = new JsonArray();
			JsonArray respArr = new JsonArray();
			JsonObject queryData = i$ResM.getObjfromObj(i$ResM.getObjfromObj(i$ResM.getObjfromObj(respBodyObj, "FCUBS_RES_ENV"), "FCUBS_BODY"),"QUERY_DATA");
			if(queryData.has("REC")) {
			if(queryData.get("REC").isJsonArray()) { 
			respArr =  i$ResM.getArrfromObj(queryData,"REC");
			}else {
				respArr.add(i$ResM.getObjfromObj(queryData, "REC"));
			}
			for(int i=0; i<respArr.size(); i++) {
				JsonObject i$runningObj = respArr.get(i).getAsJsonObject(); 
				
 				Set<Entry<String, JsonElement>> entrySet = i$runningObj.entrySet();
 				JsonArray i$runInrArr = new JsonArray(); 
				for (Map.Entry<String, JsonElement> entry : entrySet) {
					
					JsonObject runningenqObj = i$impactoUtil.objFromArrWithSearch(filedsDetails, "fieldName", entry.getKey());
					// #MAQ00046 Starts
					try {
						JsonArray neglectValues = new JsonArray();
						if(runningenqObj.has("neglectValues"))
							neglectValues = runningenqObj.get("neglectValues").getAsJsonArray();
						if(!I$utils.$isNullOrEmpty(runningenqObj) && 
								!I$utils.isInArray(neglectValues, i$ResM.getStrfromObj(i$runningObj, entry.getKey()))){
						runningenqObj.addProperty("fieldValue", i$ResM.getStrfromObj(i$runningObj, entry.getKey()));
						runningenqObj.addProperty("fieldName", entry.getKey());
						i$runInrArr.add(runningenqObj);
						}
					} catch (Exception e) {
						
					} // #MAQ00046 Ends
				}
				i$resp.add(i$runInrArr);
			}
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resp);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Query Execution SUCCESS");
			}else {
				isonMsg =i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject()); 
				 
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO DATA FOUND");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Query Execution Failed", e.getMessage());
		}
		return isonMsg;
	}
	// #BVB00213 Ends
	public JsonObject executeQuery(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonArray i$res = new JsonArray();
		JsonObject i$resO = new JsonObject();
		JsonArray i$AggParam = new JsonArray();
		try {
			String projectionS = "{}";
			String CollName = "";
			String filterS = "{}";
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String queryId = i$ResM.getBodyElementS(isonMsg, "queryId");
			filter.addProperty("queryId", queryId);
			int skip = 0;
			int limit = 0;
			JsonObject queryInp = db$Ctrl.db$GetRow("ICOR_M_QUERY_INPUTTER", filter);
			String type = queryInp.get("type").getAsString();
			//#PKY00015 Starts
            try {  
            	CollName = queryInp.get("CollName").getAsString();
            }catch(Exception e) {
            	
            }
            //#PKY00015 Ends
			try {
				filterS = queryInp.get("filterS").getAsString();
			} catch (Exception e) {
				// Eat up
			}

			try {
				projectionS = queryInp.get("projectionS").getAsString();
			} catch (Exception e) {
				// Eat up
			}

			try {
				skip = queryInp.get("skip").getAsInt();
			} catch (Exception e) {
				// Eat Up
			}

			try {
				limit = queryInp.get("limit").getAsInt();
			} catch (Exception e) {
				// Eat Up
			}

			if (I$utils.$iStrFuzzyMatch(type, "Query")) {
				i$res = db$Ctrl.db$GetSummRowsArray(CollName, filterS, projectionS, skip, limit);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			} else if (I$utils.$iStrFuzzyMatch(type, "Count")) {
				i$resO.addProperty("count", db$Ctrl.db$GetCountI(CollName, filter));
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resO);
			} else if (I$utils.$iStrFuzzyMatch(type, "AGG")) {
				JsonArray options = queryInp.getAsJsonArray("options");
				for (int i = 0; i < options.size(); i++) {
					i$AggParam.add(i$impactoUtil.getFormattedTmpl(options.get(i).getAsString(), i$body));
				}
				i$res = db$Ctrl.db$DoAggregate(CollName, i$AggParam);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			}//#PKY00015 Starts
			else if(I$utils.$iStrFuzzyMatch(type, "AGGARRAY")) 
			{
				JsonArray aggQueries = queryInp.getAsJsonArray("aggQueries");
				int foldercount = 0;
				JsonArray currRes = new JsonArray();
				JsonArray resArr = new JsonArray();				
				JsonObject storeFolderCount = new JsonObject();
				for (int i = 0; i < aggQueries.size(); i++) 
				{
					try {
						JsonObject currObj = aggQueries.get(i).getAsJsonObject();
						JsonArray options = currObj.getAsJsonArray("query");
						CollName = currObj.get("CollName").getAsString();
						i$AggParam = new JsonArray();
						for (int j = 0; j < options.size(); j++) {
							try {
							i$AggParam.add(i$impactoUtil.getFormattedTmpl(options.get(j).getAsString(), i$body));
							} catch (Exception e) {
								logger.debug("****check-in aggregate****");
								logger.debug(e.getMessage());

							}
						}
						currRes = db$Ctrl.db$DoAggregate(CollName, i$AggParam);
						i$res.addAll(currRes);
						
					}catch(Exception e) {
						
					}					
				}
				if(!I$utils.$iStrFuzzyMatch(queryId, "IDOCXAUTODOCSCOUNT")) {
//					i$res.addAll(currRes);   //#SRM00055 changes
				}
				else if (I$utils.$iStrFuzzyMatch(queryId, "IDOCXAUTODOCSCOUNT")){
					i$res.add(storeFolderCount);
				}
				else {
					foldercount += Integer.parseInt(currRes.get(0).getAsJsonObject().get("count").getAsString());
				storeFolderCount.addProperty("count", foldercount);
				resArr.add(currRes.get(0).getAsJsonObject()); // #SRM00055 changes
				i$res.add(storeFolderCount);
				}
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			}//#PKY00015 Ends

			i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Query Executed Sucessfully");
		} catch (Exception e) {
			e.printStackTrace();
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Query Execution Failed", e.getMessage());
		}
		return isonMsg;
	}
}
// #BVB00131 Ends