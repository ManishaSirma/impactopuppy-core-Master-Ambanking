/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by 	| Date         | Change Tag   | Changes Done
      ----------------------------------------------------------------------------------------------
      1.0.0.1      | Manikanta      | 19-Jul-2022  | #MVT00064    | Initial writing
      1.0.0.1      | Samadhan       | 02-Aug-2022  | #SRP00078    | Added Code for Risk Profiling Case management
      1.0.0.1      | Madhura		| 03-Aug-2022  | #MSA00001	  | Added Code to handle AML summary page validations
      1.0.0.1	   | Madhura	    | 09-Aug-2022  | #MSA00002	  | Added Code to handle Risk Scanning summary page validations
      1.0.0.1      | Manikanta      | 07-Sep-2022  | #MVT00078    | Added code to handle dashBoard individual records
      1.0.0.1      | Sindhu         | 30-Jun-2023  | #SRM00045    | Added code to handle 'ALL' transaction from fxube and digiApp
      1.0.0.1	   | Pavithra       | 13-Jul-2023  | #PAV00002    | Added code to handle AML Type field in AML transaction
      1.0.0.1      | Sindhu         | 27-Jul-2023  | #SRM00051    | Added code to handle the decimal and comma separator for transaction amount field
      1.0.0.1      | Pavithra       | 08-Aug-2023  | #PAV00011    | Handled Transfer type 
      1.0.0.1      | Pavithra       | 11-Aug-2023  | #PAV00013    | Handled FunctionName 
      1.0.0.1      | Pavithra       | 06-Nov-2023  | #PAV00021    | Added code for Moving Records to Case Management RIsk Profiling and AML Transaction  Summary
      1.0.0.1      | Pavithra       | 20-Nov-2023  | #PAV00024    | Added code for Moving Records to Case Management KYM Checks Summary
      1.0.0.1      | Pavithra       | 04-Dec-2023  | #PAV00028    | Added code for Saving comments and Documents, Closing and Reopening of Case Management AML Transaction, Risk Profiling and KYM Checks
      ----------------------------------------------------------------------------------------------
      
*/

package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.springframework.http.HttpStatus;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
//#MVT00064 starts
public class ICaseManagementController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

    private GenericAppController i$genAppCtrl = new GenericAppController();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private DBController dbctr = new DBController();
	private IEmailService mail = new IEmailService();
	private ImpactoUtil I$Imputils = new ImpactoUtil();//#PAV00021 Changes

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String sOpr = i$ResM.getOpr(isonMsg);
			String scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(scr, "OB2AMLFN") && I$utils.$iStrFuzzyMatch(sOpr, "UPDATE")) {
				isonMsg = amlManagement(isonMsg);
			} else if ((I$utils.$iStrFuzzyMatch(scr, "OB2AMLFN") || I$utils.$iStrFuzzyMatch(scr, "OB2SDNFN") || I$utils.$iStrFuzzyMatch(scr, "OB2RIKFN")) && I$utils.$iStrFuzzyMatch(sOpr, "RELEASE_TASK")) {
				isonMsg = releaseHoldApk(isonMsg);
			} else if ((I$utils.$iStrFuzzyMatch(scr, "OB2AMLFN") || I$utils.$iStrFuzzyMatch(scr, "OB2SDNFN") || I$utils.$iStrFuzzyMatch(scr, "OB2RIKFN")) && I$utils.$iStrFuzzyMatch(sOpr, "ACQUIRE_TASK")) {
				isonMsg = acquireApk(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(scr, "SB2AMLFN") && I$utils.$iStrFuzzyMatch(sOpr, "SUMMARY")) {
                isonMsg = amlSummaryDetails(isonMsg);
            } else if (I$utils.$iStrFuzzyMatch(scr, "OB2SDNFN") && I$utils.$iStrFuzzyMatch(sOpr, "UPDATE")) {
				isonMsg = sdnCaseManagement(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(scr, "SB2SDNFN") && I$utils.$iStrFuzzyMatch(sOpr, "SUMMARY")) {
                isonMsg = sdnSummaryDetails(isonMsg);
            } else if (I$utils.$iStrFuzzyMatch(scr, "OB2RIKFN") && I$utils.$iStrFuzzyMatch(sOpr, "UPDATE")) {//#SRP00078 Starts
				isonMsg = riskCaseManagement(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(scr, "SB2RIKFN") && I$utils.$iStrFuzzyMatch(sOpr, "SUMMARY")) {
                isonMsg = riskProfilingSummaryDetails(isonMsg);//#SRP00078 Ends
            }else if(I$utils.$iStrFuzzyMatch(scr, "SB2CSDFN") && I$utils.$iStrFuzzyMatch(sOpr, "SUMMARY")) {  //#MVT00078 Changes
                isonMsg = dashBoardFunction(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(scr, "OASAMLCK") && I$utils.$iStrFuzzyMatch(sOpr, "SUMMARY")) { // #SRM00045																												// changes
				isonMsg = amlCheckFlexCubeCreate(isonMsg, isonMapJson);
			}else if(I$utils.$iStrFuzzyMatch(scr, "OB2CMRPS") && I$utils.$iStrFuzzyMatch(sOpr, "CREATE"))//#PAV00021 Changes Starts
			{
				isonMsg = moveToCaseManagementRiskProfiling(isonMsg);
			}
			else if(I$utils.$iStrFuzzyMatch(scr, "OB2CMATS") && I$utils.$iStrFuzzyMatch(sOpr, "CREATE"))
			{
				isonMsg = moveToCaseManagementAMLTransaction(isonMsg);
			}//#PAV00021 Changes ends
			else if(I$utils.$iStrFuzzyMatch(scr, "OB2CMKCS") && I$utils.$iStrFuzzyMatch(sOpr, "CREATE"))//#PAV00024 Changes Starts
			{
				isonMsg = moveToCaseManagementKYMChecks(isonMsg);
			}//#PAV00024 Changes Ends
//			else if ((I$utils.$iStrFuzzyMatch(scr, "OB2CAMTR") || I$utils.$iStrFuzzyMatch(scr, "OB2CAMRP") || I$utils.$iStrFuzzyMatch(scr, "OB2CAMKY"))&& I$utils.$iStrFuzzyMatch(sOpr, "UPDATE"))//#PAV00028 Changes Starts
//			{
//				isonMsg =movedCaseMangaementOprs (isonMsg,isonMapJson);
//			}
//			else if ((I$utils.$iStrFuzzyMatch(scr, "OB2CAMTR") || I$utils.$iStrFuzzyMatch(scr, "OB2CAMRP") || I$utils.$iStrFuzzyMatch(scr, "OB2CAMKY"))&& I$utils.$iStrFuzzyMatch(sOpr, "CLOSE"))
//			{
//				isonMsg =closeCaseManagementOprs (isonMsg,isonMapJson);
//			}
//			else if ((I$utils.$iStrFuzzyMatch(scr, "OB2CAMTR") || I$utils.$iStrFuzzyMatch(scr, "OB2CAMRP") || I$utils.$iStrFuzzyMatch(scr, "OB2CAMKY"))&& I$utils.$iStrFuzzyMatch(sOpr, "REOPEN"))
//			{
//				isonMsg =reopenCaseManagementOprs (isonMsg,isonMapJson);
//			}//#PAV00028 Changes Ends
			else if ((I$utils.$iStrFuzzyMatch(scr, "OB2CMATS") || I$utils.$iStrFuzzyMatch(scr, "OB2CMRPS") || I$utils.$iStrFuzzyMatch(scr, "OB2CMKCS"))&& I$utils.$iStrFuzzyMatch(sOpr, "UPDATE"))//#PAV00028 Changes Starts
			{
				isonMsg =movedCaseMangaementOprs (isonMsg,isonMapJson);
			}
			else if ((I$utils.$iStrFuzzyMatch(scr,"OB2CMATS") || I$utils.$iStrFuzzyMatch(scr, "OB2CMRPS") || I$utils.$iStrFuzzyMatch(scr, "OB2CMKCS"))&& I$utils.$iStrFuzzyMatch(sOpr, "CLOSE"))
			{
				isonMsg =closeCaseManagementOprs (isonMsg,isonMapJson);
			}
			else if ((I$utils.$iStrFuzzyMatch(scr, "OB2CMATS") || I$utils.$iStrFuzzyMatch(scr, "OB2CMRPS") || I$utils.$iStrFuzzyMatch(scr, "OB2CMKCS"))&& I$utils.$iStrFuzzyMatch(sOpr, "REOPEN"))
			{
				isonMsg =reopenCaseManagementOprs (isonMsg,isonMapJson);
			}//#PAV00028 Changes Ends
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Not Allowed", e.getMessage().toString());
			return isonMsg;
		}
		return isonMsg;
	}
	//#MVT00078 starts
    public JsonObject dashBoardFunction(JsonObject isonMsg) {
        try {
            JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
            String scanType = ibody.get("type").getAsString();
            JsonObject projection = new JsonObject();
            JsonObject scanObject = new JsonObject();
            JsonObject res$blder = new JsonObject();
            JsonArray scanData = new JsonArray();
            int totalAppls = 0;
           
            JsonObject j$DataFilter = i$genAppCtrl.get$FrmDataSetFilter(isonMsg);
            if (I$utils.$iStrFuzzyMatch(scanType, "RISK SCAN")) {
                projection.addProperty("INDIVIDUAL_WEIGHT", 0);
                totalAppls = dbctr.db$GetCountI("ICOR_M_EXIT_RISK_SCAN", j$DataFilter);
                scanObject = dbctr.db$GetRow("ICOR_M_EXIT_RISK_SCAN", j$DataFilter, projection).getAsJsonObject();
                scanData.add(scanObject);
                res$blder.add("PaginatedApplicationsInQueue", scanData);
                res$blder.addProperty("TotalApplsInQueue", totalAppls);
                isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
            }
            if (I$utils.$iStrFuzzyMatch(scanType, "SDN SCAN")) {
                projection.addProperty("webScan", 0);
                projection.addProperty("ScanDetailsLatest", 0);
                projection.addProperty("searchFields", 0);
                totalAppls = dbctr.db$GetCountI("ICOR_M_SDN_SCAN", j$DataFilter);
                scanObject = dbctr.db$GetRow("ICOR_M_SDN_SCAN", j$DataFilter, projection).getAsJsonObject();
                scanData.add(scanObject);
                res$blder.add("PaginatedApplicationsInQueue", scanData);
                res$blder.addProperty("TotalApplsInQueue", totalAppls);
                isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
            }
            if (I$utils.$iStrFuzzyMatch(scanType, "AML SCAN")) {
                totalAppls = dbctr.db$GetCountI("ICOR_M_AML_CHECKS", j$DataFilter);
                scanObject = dbctr.db$GetRow("ICOR_M_AML_CHECKS", j$DataFilter).getAsJsonObject();
                scanData.add(scanObject);
                res$blder.add("PaginatedApplicationsInQueue", scanData);
                res$blder.addProperty("TotalApplsInQueue", totalAppls);
                isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
            }
        } catch (Exception e) {
            return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Failed",
                    e.getMessage().toString());
        }
        return isonMsg;
    }
    //#MVT00078 ends
	public JsonObject amlCheckFlexCubeCreate(JsonObject isonMsg, JsonObject isonMapJson) { // #SRM00045 changes start
		try {
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonArray userData = new JsonArray();
			JsonObject sort = new JsonObject();
//			JsonObject amountObj = new JsonObject();
			JsonObject updateObj = new JsonObject();
			JsonArray userData1 = new JsonArray();

			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			String Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			String tt = ibody.get("transferType").getAsString().toUpperCase();// #PAV00011 Changes

			projection.addProperty("_id", 0);
			sort.addProperty("_id", -1);
			if (I$utils.$iStrFuzzyMatch(tt, "All")) {
				filter.addProperty("CustomerNo", ibody.get("CustomerNo").getAsString());
			} else {
				filter.addProperty("TransferType", tt);
				filter.addProperty("CustomerNo", ibody.get("CustomerNo").getAsString());
			}
			userData = dbctr.db$GetRows$Sort(Coll_Name, filter, projection, sort);
			JsonArray userMOdFunName = new JsonArray(); // #PAV00002 changes starts
			for (int i = 0; i < userData.size(); i++) {
				try {
					JsonObject db = userData.get(i).getAsJsonObject();
//						String funName = db.get("FunctionName").getAsString();
					String funName = null;// #PAV00013 Changes
					try {
						funName = db.get("FunctionName").getAsString();
					} catch (Exception e) {
						funName = null;// #PAV00013 Changes
					}
					if (I$utils.$iStrFuzzyMatch(funName, "fn_getCustYearlyAMLCheck")) {
						db.addProperty("FunctionName", "Yearly");
					} else if (I$utils.$iStrFuzzyMatch(funName, "fn_getCustMonthlyAMLCheck")) {
						db.addProperty("FunctionName", "Monthly");
					} else if (I$utils.$iStrFuzzyMatch(funName, "fn_getCustDailyAMLCheck")) {
						db.addProperty("FunctionName", "Daily");
					}
//			            userMOdFunName.add(db);
//			            amountObj = userData.get(i).getAsJsonObject();//#SRM00051 changes starts
					if (db.has("TransactionAmount") || db.has("Amount")) {
						double number = 0;
						try {
							number = db.get("TransactionAmount").getAsDouble();
						} catch (Exception e) {
							number = db.get("Amount").getAsDouble();
						}
						String amountCom = null;
						if (number > 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");
							amountCom = formatter.format(d1);
						} else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");
							amountCom = formatter.format(d1);
						}
//	                        JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", update$Data, filter1, "true");
						if (db.has("TransactionAmount")) {
							updateObj.addProperty("TransactionAmount", amountCom);
							db.addProperty("TransactionAmount", amountCom);
						} else {
							updateObj.addProperty("Amount", amountCom);
							db.addProperty("TransactionAmount", amountCom);
						}
						JsonObject db$Res = dbctr.db$UpdateRow(Coll_Name, updateObj, filter);
//							userData1 = dbctr.db$GetRows$Sort(Coll_Name, filter, projection, sort);
					}
					userMOdFunName.add(db);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
//			userData1=userMOdFunName; //#PAV00002 changes ends
//			userData1.add(userMOdFunName);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, userMOdFunName); // #SRM00051
																											// changes
																											// end

		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	} // #SRM00045 changes end
	
	public JsonObject riskCaseManagement(JsonObject isonMsg) { //#SRP00078 Starts
		try {
		String status = null;
		JsonObject flter = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject argJson = new JsonObject();
		JsonObject risk$Object = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject update$Object = new JsonObject();
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		filter.addProperty("ScanId", ibody.get("ScanId").getAsString());
		filter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
		JsonObject riskData = dbctr.db$GetRow("ICOR_M_EXIT_RISK_SCAN", filter);
		JsonObject arg$Json = dbctr.db$GetRow("ICOR_M_IM_BPM",
				"{\"WORKFLOWID\":\"" + "RISK_PROFILING_CASE_MANAGEMENT_WORKFLOW" + "\"}");
		JsonObject control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
		JsonObject stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
		JsonObject stgName = stg$LfeCycle.get("1").getAsJsonObject();
		try {
			status = riskData.get("status").getAsString();
		} catch (Exception e) {
			status = "initiated";
		}
		if(I$utils.$iStrFuzzyMatch(status, "Hold")){
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"The Operation Cannot be perform because the application is on Hold");
			return isonMsg;
		}
		if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE") || I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")) {
			try {
				flter.addProperty("userId", ibody.get("userId").getAsString());
				projection.addProperty("_id", 0);
				projection.addProperty("roles", 1);
				projection.addProperty("userId", 1);
				projection.addProperty("EmpMail", 1);
				JsonObject userData = dbctr.db$GetRow("ICOR_M_USER_PRF", flter, projection).getAsJsonObject();
				if (!I$utils.$iExistsInArrayJ(userData.get("roles").getAsJsonArray(), "SUPER_ROLE")) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "User do not have access for this Queue");
					return isonMsg;
				}
				risk$Object.addProperty("customerId", riskData.get("CustomerId").getAsString());
				risk$Object.addProperty("customerName", riskData.get("CustomerFullName").getAsString());
				risk$Object.addProperty("modelClass", riskData.get("MODEL_CLASS").getAsString());
				risk$Object.addProperty("modelColour", riskData.get("MODEL_COLOR").getAsString());
				risk$Object.addProperty("modelRating", riskData.get("MODEL_RATING").getAsString());
				risk$Object.addProperty("modelValue", riskData.get("MODEL_VALUE").getAsString());
				risk$Object.addProperty("initiateDate", riskData.get("initiatedTime").getAsString());
				if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE")) {
					risk$Object.addProperty("tmp$name", "TMPL#TT#ESCALATE#RISK#ALERT#MAIL");
				} else if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")) {
					risk$Object.addProperty("tmp$name", "TMPL#TT#REFERUSER#RISK#ALERT#MAIL");
				}
				try {
					String mailId = userData.get("EmpMail").getAsString();
					argJson.add("map$Data", risk$Object);
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + mailId + "\"}"));
					mail.SendEmailWOThread(argJson);
				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Your Email Id on User Profile Maintenance Screen.");
				}
				update$Object.addProperty("status", ibody.get("status").getAsString());
				update$Object.addProperty("remarks", ibody.get("remarks").getAsString());
				update$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
				update$Object.addProperty("TaskAssignedTo", userData.get("userId").getAsString());
				update$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
				update$Object.addProperty("lastActionAt",
						new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
				dbctr.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN", update$Object, filter, "true");
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			try {
				if (I$utils.$iStrFuzzyMatch(status, "ESCALATE")
						|| I$utils.$iStrFuzzyMatch(status, "REFER_USER")) {
					if (!I$utils.$iStrFuzzyMatch(riskData.get("TaskAssignedTo").getAsString(), IResManipulator.iloggedUser.get())) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								IResManipulator.iloggedUser.get()+ " This User Does Not Have Access for this Application. ");
						return isonMsg;
					}
				}			
				update$Object.addProperty("status", ibody.get("status").getAsString());
				update$Object.addProperty("remarks", ibody.get("remarks").getAsString());
				update$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
				update$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
				update$Object.addProperty("lastActionAt",
						new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
				dbctr.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN", update$Object, filter, "true");
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	} catch (Exception e) {
		i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "The Operation Failed");
	}
		return isonMsg;
	}//#SRP00078 Ends

	public JsonObject sdnCaseManagement(JsonObject isonMsg) {
		try {
			String status = null;
			JsonObject flter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject sdn$Object = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject update$Object = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			filter.addProperty("ScanId", ibody.get("ScanId").getAsString());
			JsonObject sdnData = dbctr.db$GetRow("ICOR_M_SDN_SCAN", filter);

			JsonObject arg$Json = dbctr.db$GetRow("ICOR_M_IM_BPM",
					"{\"WORKFLOWID\":\"" + "SDN_CASE_MANAGEMENT_WORKFLOW" + "\"}");
			JsonObject control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			JsonObject stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
			JsonObject stgName = stg$LfeCycle.get("1").getAsJsonObject();
			try {
				status = sdnData.get("status").getAsString();
			} catch (Exception e) {
				status = "initiated";
			}
			if(I$utils.$iStrFuzzyMatch(status, "Hold")){
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"The Operation Cannot be perform because the application is on Hold");
				return isonMsg;
			}
			if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE") || I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")) {
				try {
					flter.addProperty("userId", ibody.get("userId").getAsString());
					projection.addProperty("_id", 0);
					projection.addProperty("roles", 1);
					projection.addProperty("userId", 1);
					projection.addProperty("EmpMail", 1);
					JsonObject userData = dbctr.db$GetRow("ICOR_M_USER_PRF", flter, projection).getAsJsonObject();
					if (!I$utils.$iExistsInArrayJ(userData.get("roles").getAsJsonArray(), "SUPER_ROLE")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "User do not have access for this Queue");
						return isonMsg;
					}
					
					sdn$Object.addProperty("scanDate", sdnData.get("ScanDtTime").getAsString());
					sdn$Object.addProperty("customerId", sdnData.get("CustomerId").getAsString());
					sdn$Object.addProperty("finYear", sdnData.get("financialYear").getAsString());
					sdn$Object.addProperty("periodCode", sdnData.get("peroidCode").getAsString());
					sdn$Object.addProperty("alertGrade", sdnData.get("ScanResultsF").getAsJsonObject().get("MaxGrade").getAsString());
					sdn$Object.addProperty("alertList", sdnData.get("ScanResultsF").getAsJsonObject().get("AlertLists").getAsString());
					sdn$Object.addProperty("alertPercent", sdnData.get("ScanResultsF").getAsJsonObject().get("MaxPercent").getAsString());
					if(I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE")) {
						sdn$Object.addProperty("tmp$name", "TMPL#TT#ESCALATE#SDN#ALERT#MAIL");
					} else if(I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")){
						sdn$Object.addProperty("tmp$name", "TMPL#TT#REFERUSER#SDN#ALERT#MAIL");
					}
					try {
						String mailId = userData.get("EmpMail").getAsString();
						argJson.add("map$Data", sdn$Object);
						argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + mailId + "\"}"));
						mail.SendEmailWOThread(argJson);
					} catch (Exception e) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Your Email Id on User Profile Maintenance Screen.");
					}
					update$Object.addProperty("status", ibody.get("status").getAsString());
					update$Object.addProperty("remarks", ibody.get("remarks").getAsString());
					update$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					update$Object.addProperty("TaskAssignedTo", userData.get("userId").getAsString());
					update$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
					update$Object.addProperty("lastActionAt",
							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
					dbctr.db$UpdateRow("ICOR_M_SDN_SCAN", update$Object, filter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				try {
					if (I$utils.$iStrFuzzyMatch(status, "ESCALATE")
							|| I$utils.$iStrFuzzyMatch(status, "REFER_USER")) {
						if (!I$utils.$iStrFuzzyMatch(sdnData.get("TaskAssignedTo").getAsString(), IResManipulator.iloggedUser.get())) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									IResManipulator.iloggedUser.get()+ " This User Does Not Have Access for this Application. ");
							return isonMsg;
						}
					}			
					update$Object.addProperty("status", ibody.get("status").getAsString());
					update$Object.addProperty("remarks", ibody.get("remarks").getAsString());
					update$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					update$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
					update$Object.addProperty("lastActionAt",
							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
					dbctr.db$UpdateRow("ICOR_M_SDN_SCAN", update$Object, filter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "The Operation Failed");
		}
		return isonMsg;
	}

	public JsonObject sdnSummaryDetails(JsonObject isonMsg) {
		try {
			int intPgNo, intRecs;
			String results = null;
			String sort = "{'_id':-1}";
			JsonArray result = new JsonArray();
			JsonObject proj = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject filter = new JsonObject();
			JsonArray result$Array = new JsonArray();
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			try {
				intPgNo = ibody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = ibody.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 20;
			}
			result.add("High");
			result.add("Critical");
			result.add("Significant");
			results = "{'$in': " + result.getAsJsonArray() + " }";
			filter.addProperty("peroidCode", ibody.get("peroidCode").getAsString());
			filter.add("ScanResultsF.MaxGrade", parser.parse(results).getAsJsonObject());
			filter.addProperty("financialYear", ibody.get("financialYear").getAsString());
			proj.addProperty("_id", 0);
			proj.addProperty("ScanId", 1);
			proj.addProperty("status", 1);
			proj.addProperty("ScanType", 1);
			proj.addProperty("CustomerId", 1);
			proj.addProperty("peroidCode", 1);
			proj.addProperty("ScanResultsF", 1);
			proj.addProperty("searchFields", 1);
			proj.addProperty("applicationId", 1);
			proj.addProperty("financialYear", 1);
			proj.addProperty("TaskAssignedTo", 1);
			proj.addProperty("WorkFlowStatus", 1);

			JsonArray dbSDNData = dbctr.db$GetSummRowsArray("ICOR_M_SDN_SCAN", gson.toJson(filter), proj, intPgNo,
					intRecs, sort);
			for(int i=0;i<dbSDNData.size();i++) {
				JsonObject sdnObject = new JsonObject();
				
				sdnObject = dbSDNData.get(i).getAsJsonObject();
				if (sdnObject.has("status") && (I$utils.$iStrFuzzyMatch(sdnObject.get("status").getAsString(), "ESCALATE")
								|| I$utils.$iStrFuzzyMatch(sdnObject.get("status").getAsString(), "REFER_USER"))) {
					if (!I$utils.$iStrFuzzyMatch(sdnObject.get("TaskAssignedTo").getAsString(),
							IResManipulator.iloggedUser.get())) {
						continue;
					}
				}
				result$Array.add(sdnObject);
			}
			ibody.add("iRowData", result$Array);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", ibody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Retrieved Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject releaseHoldApk(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject release$Object = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			if(ibody.has("ScanId")&&!ibody.has("type")) {//#SRP00078 Starts
				try {
					filter.addProperty("ScanId", ibody.get("ScanId").getAsString());
					filter.addProperty("MODEL_CLASS", ibody.get("MODEL_CLASS").getAsString());
					filter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
					JsonObject dbriskData = dbctr.db$GetRow("ICOR_M_EXIT_RISK_SCAN", filter);

					if (I$utils.$iStrFuzzyMatch(dbriskData.get("status").getAsString(), "Hold")) {
						if (!I$utils.$iStrFuzzyMatch(dbriskData.get("lastActionBy").getAsString(),
								IResManipulator.iloggedUser.get())) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"Reviewer Cannot Release The Application");
						}
						release$Object.addProperty("status", "initaited");
						release$Object.addProperty("ReleasedBy", IResManipulator.iloggedUser.get());
						release$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
						release$Object.addProperty("lastActionAt",
								new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
										.format(Calendar.getInstance().getTime()));
						dbctr.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN", release$Object, filter, "true");
						i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Released Successfully");
						return isonMsg;
					} else {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Release Functionality Will Work Only For Hold Applications.");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}//#SRP00078 Ends
			else if(ibody.has("type")&&ibody.has("ScanId")) {
				try {
					filter.addProperty("ScanId", ibody.get("ScanId").getAsString());
					JsonObject dbSDNData = dbctr.db$GetRow("ICOR_M_SDN_SCAN", filter);

					if (I$utils.$iStrFuzzyMatch(dbSDNData.get("status").getAsString(), "Hold")) {
						if (!I$utils.$iStrFuzzyMatch(dbSDNData.get("lastActionBy").getAsString(),
								IResManipulator.iloggedUser.get())) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"Reviewer Cannot Release The Application");
						}
						release$Object.addProperty("status", "initaited");
						release$Object.addProperty("ReleasedBy", IResManipulator.iloggedUser.get());
						release$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
						release$Object.addProperty("lastActionAt",
								new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
										.format(Calendar.getInstance().getTime()));
						dbctr.db$UpdateRow("ICOR_M_SDN_SCAN", release$Object, filter, "true");
						i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Released Successfully");
						return isonMsg;
					} else {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Release Functionality Will Work Only For Hold Applications.");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if(ibody.has("FunctionNmae")) {
				try {
					String funcName = ibody.get("FunctionNmae").getAsString();
//					if (funcName.equals("fn_getCustYearlyAMLCheck")) {
//						ibody.addProperty("FunctionNmae", "Yearly");
//		            } else if (funcName.equals("fn_getCustMonthlyAMLCheck")) {
//		            	ibody.addProperty("FunctionNmae", "Monthly");
//		            } else if (funcName.equals("fn_getCustDailyAMLCheck")) {
//		            	ibody.addProperty("FunctionNmae", "Daily");
//		            }
					filter.addProperty("FunctionNmae", funcName);
					filter.addProperty("CustomerNo", ibody.get("CustomerNo").getAsString());
					filter.addProperty("CustomerAccNo", ibody.get("CustomerAccNo").getAsString());
					JsonObject dbAMLData = dbctr.db$GetRow("ICOR_M_AML_CHECKS", filter);

					if (I$utils.$iStrFuzzyMatch("Hold", dbAMLData.get("status").getAsString())) {
						if (!I$utils.$iStrFuzzyMatch(dbAMLData.get("lastActionBy").getAsString(),
								IResManipulator.iloggedUser.get())) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Reviewer Cannot Release The Application");
						}
						release$Object.addProperty("ReleasedBy", IResManipulator.iloggedUser.get());
						release$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
						release$Object.addProperty("lastActionAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
						release$Object.addProperty("status", "initaited");
						dbctr.db$UpdateRow("ICOR_M_AML_CHECKS", release$Object, filter, "true");
						i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Released Successfully");
					} else {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Release Functionality Will Work Only For Hold Applications.");
					}
				}catch(Exception e) {
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Failed");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}
	
	public JsonObject acquireApk(JsonObject isonMsg) {
		try {
			String istateMsg = null;
			String workflowId = null;
			String functionName = null;
			JsonObject flter = new JsonObject();
			JsonObject i$aqrs = new JsonObject();
			JsonObject ires$stat = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			workflowId = ibody.get("WorkFlowId").getAsString();
			JsonObject arg$Json = dbctr.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workflowId + "\"}");
			JsonObject controlJson = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			String reCollName = controlJson.get("RECCOLLNAME").getAsString();

			if (I$utils.$iStrFuzzyMatch(workflowId, "AML_CASE_MANAGEMENT_WORKFLOW")) {
				try {
					functionName = ibody.get("FunctionNmae").getAsString();
//					if (functionName.equals("fn_getCustYearlyAMLCheck")) {
//						ibody.addProperty("FunctionNmae", "Yearly");
//					} else if (functionName.equals("fn_getCustMonthlyAMLCheck")) {
//						ibody.addProperty("FunctionNmae", "Monthly");
//					} else if (functionName.equals("fn_getCustDailyAMLCheck")) {
//						ibody.addProperty("FunctionNmae", "Daily");
//					}
					flter.addProperty("FunctionNmae", functionName);
					flter.addProperty("CustomerNo", ibody.get("CustomerNo").getAsString());
					flter.addProperty("CustomerAccNo", ibody.get("CustomerAccNo").getAsString());
					i$aqrs = dbctr.db$AcqRow(reCollName, flter);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if (I$utils.$iStrFuzzyMatch(workflowId, "RISK_PROFILING_CASE_MANAGEMENT_WORKFLOW")) {//#SRP00078 Starts
				try {
					flter.addProperty("ScanId", ibody.get("ScanId").getAsString());
					flter.addProperty("MODEL_CLASS", ibody.get("MODEL_CLASS").getAsString());

					i$aqrs = dbctr.db$AcqRow(reCollName, flter);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}//#SRP00078 Ends
			else if (I$utils.$iStrFuzzyMatch(workflowId, "SDN_CASE_MANAGEMENT_WORKFLOW")) {
				try {
					flter.addProperty("ScanId", ibody.get("ScanId").getAsString());
					
					i$aqrs = dbctr.db$AcqRow(reCollName, flter);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			try {
				ires$stat = i$aqrs.get("i-stat").getAsJsonObject();
				istateMsg = ires$stat.get("i-statMsg").getAsString();
				if (I$utils.$iStrFuzzyMatch(istateMsg, "i-ERROR")) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							ires$stat.get("i-error").getAsJsonObject().get("msgtext").getAsString());
				} else
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Acquired Successfully");
			} catch (Exception e) {
				istateMsg = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject amlManagement(JsonObject isonMsg) {
		try {
			String functionName = null;
			JsonObject flter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject aml$Object = new JsonObject();
			JsonObject control$Json = new JsonObject();
			JsonObject stg$LfeCycle = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			functionName = ibody.get("FunctionNmae").getAsString();
//			if (functionName.equals("fn_getCustYearlyAMLCheck")) {
//				ibody.addProperty("FunctionNmae", "Yearly");
//	        } else if (functionName.equals("fn_getCustMonthlyAMLCheck")) {
//	        	ibody.addProperty("FunctionNmae", "Monthly");
//	        } else if (functionName.equals("fn_getCustDailyAMLCheck")) {
//	        	ibody.addProperty("FunctionNmae", "Daily");
//	        }
			
			flter.addProperty("CustomerAccNo", ibody.get("CustomerAccNo").getAsString());
			flter.addProperty("CustomerNo", ibody.get("CustomerNo").getAsString());
			flter.addProperty("FunctionNmae", functionName);
			JsonObject dbAMLData = dbctr.db$GetRow("ICOR_M_AML_CHECKS", flter);
			JsonObject arg$Json = dbctr.db$GetRow("ICOR_M_IM_BPM",
					"{\"WORKFLOWID\":\"" + "AML_CASE_MANAGEMENT_WORKFLOW" + "\"}");
			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
			JsonObject stgName = stg$LfeCycle.get("1").getAsJsonObject();
			
			// To check hold applications
			if (I$utils.$iStrFuzzyMatch(dbAMLData.get("status").getAsString(), "Hold")) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"The Operation Cannot be perform because the application is on Hold");
				return isonMsg;
			}
			if (!I$utils.$iStrFuzzyMatch(dbAMLData.get("amlCheck").getAsString(), "Y")
					&& !I$utils.$iStrFuzzyMatch(dbAMLData.get("isCurrVer").getAsString(), "Y")) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid application");
				return isonMsg;
			}
			// To handle escalate functionality
			if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE") || I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")) {
				try {
					JsonObject updat$Object = new JsonObject();
					JsonObject projection = new JsonObject();
					JsonObject argJson = new JsonObject();
					
					projection.addProperty("_id", 0);
					projection.addProperty("name", 1);
					projection.addProperty("roles", 1);
					projection.addProperty("userId", 1);
					projection.addProperty("EmpMail", 1);
					filter.addProperty("userId", ibody.get("userId").getAsString());
					JsonObject userData = dbctr.db$GetRow("ICOR_M_USER_PRF", filter, projection).getAsJsonObject();
					
					if (!I$utils.$iExistsInArrayJ(userData.get("roles").getAsJsonArray(), "SUPER_ROLE")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "User do not have access for this Queue");
						return isonMsg;
					}
					aml$Object.addProperty("USER", userData.get("name").getAsString());
//					aml$Object.addProperty("tmp$name", "TMPL#TT#ESCALATE#AML#ALERT#MAIL");
					aml$Object.addProperty("Branch", dbAMLData.get("Branch").getAsString());
					aml$Object.addProperty("amlCheck", dbAMLData.get("amlCheck").getAsString());
					aml$Object.addProperty("MemberNo", dbAMLData.get("CustomerNo").getAsString());
					aml$Object.addProperty("TransactionAmount", dbAMLData.get("Amount").getAsString());
					aml$Object.addProperty("MemberAccNo", dbAMLData.get("CustomerAccNo").getAsString());
					aml$Object.addProperty("FunctionNmae", dbAMLData.get("FunctionNmae").getAsString());
					aml$Object.addProperty("AMLCreatedDate", dbAMLData.get("CreatedDate").getAsString());
					if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE")) {
						aml$Object.addProperty("tmp$name", "TMPL#TT#ESCALATE#AML#ALERT#MAIL");
					} else if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")) {
						aml$Object.addProperty("tmp$name", "TMPL#TT#REFERUSER#AML#ALERT#MAIL");
					}
					try {
						String mailId = userData.get("EmpMail").getAsString();
						argJson.add("map$Data", aml$Object);
						argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + mailId + "\"}"));
						mail.SendEmailWOThread(argJson);
					} catch (Exception e) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Your Email Id on User Profile Maintenance Screen.");
					}
					updat$Object.addProperty("status", ibody.get("status").getAsString());
					updat$Object.addProperty("remarks", ibody.get("remarks").getAsString());
					updat$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					updat$Object.addProperty("TaskAssignedTo", userData.get("userId").getAsString());
					updat$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
					updat$Object.addProperty("lastActionAt",
							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
					dbctr.db$UpdateRow("ICOR_M_AML_CHECKS", updat$Object, flter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			// To handle Refer User functionality
/*			else if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Refer User")) {
				try {
					JsonObject updat$Object = new JsonObject();
					JsonObject projection = new JsonObject();
					JsonObject argJson = new JsonObject();

					projection.addProperty("_id", 0);
					projection.addProperty("name", 1);
					projection.addProperty("roles", 1);
					projection.addProperty("userId", 1);
					projection.addProperty("EmpMail", 1);
					filter.addProperty("userId", ibody.get("userId").getAsString());
					JsonObject userData = dbctr.db$GetRow("ICOR_M_USER_PRF", filter, projection).getAsJsonObject();
					JsonArray roles = userData.get("roles").getAsJsonArray();
					if (!I$utils.$iExistsInArrayJ(roles, "SUPER_ROLE")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "no access");
						return isonMsg;
					}
					aml$Object.addProperty("USER", userData.get("name").getAsString());
					aml$Object.addProperty("tmp$name", "TMPL#TT#REFERUSER#AML#ALERT#MAIL");
					aml$Object.addProperty("Branch", dbAMLData.get("Branch").getAsString());
					aml$Object.addProperty("amlCheck", dbAMLData.get("amlCheck").getAsString());
					aml$Object.addProperty("MemberNo", dbAMLData.get("CustomerNo").getAsString());
					aml$Object.addProperty("AMLCreatedDate", dbAMLData.get("CreatedDate").getAsString());
					aml$Object.addProperty("FunctionNmae", dbAMLData.get("FunctionNmae").getAsString());
					aml$Object.addProperty("MemberAccNo", dbAMLData.get("CustomerAccNo").getAsString());
					aml$Object.addProperty("TransactionAmount", dbAMLData.get("Amount").getAsString());
					argJson.add("map$Data", aml$Object);
					argJson.add("toemailIds",
							i$ResM.getJsonObj("{\"toemailid1\":\"" + userData.get("EmpMail").getAsString() + "\"}"));
					mail.SendEmailWOThread(argJson);

					updat$Object.addProperty("status", ibody.get("status").getAsString());
					updat$Object.addProperty("remarks", ibody.get("remarks").getAsString());
					updat$Object.addProperty("ReferedTo", userData.get("name").getAsString());
					updat$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					updat$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
					updat$Object.addProperty("lastActionAt",
							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
					dbctr.db$UpdateRow("ICOR_M_AML_CHECKS", updat$Object, flter, "true");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}*/
			else{
				try {
					JsonObject updat$Object = new JsonObject();
					
					if (I$utils.$iStrFuzzyMatch(dbAMLData.get("status").getAsString(), "ESCALATE")
							|| I$utils.$iStrFuzzyMatch(dbAMLData.get("status").getAsString(), "REFER_USER")) {
						if (!I$utils.$iStrFuzzyMatch(dbAMLData.get("TaskAssignedTo").getAsString(), IResManipulator.iloggedUser.get())) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, IResManipulator.iloggedUser.get()
									+ " This User Does Not Have Access for this Application. ");
							return isonMsg;
						}
					}
					updat$Object.addProperty("status", ibody.get("status").getAsString());
					updat$Object.addProperty("remarks", ibody.get("remarks").getAsString());
					updat$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					updat$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
					updat$Object.addProperty("lastActionAt",
							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
					dbctr.db$UpdateRow("ICOR_M_AML_CHECKS", updat$Object, flter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Failed");
			return isonMsg;
		}
		return isonMsg;
	}
	public JsonObject amlSummaryDetails(JsonObject isonMsg) {
		try {
           String status = null;
			Gson gson = new Gson();
           JsonObject filter = new JsonObject();
           JsonArray row$Data = new JsonArray();
           JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
           
           int intPgNo, intRecs;
           String sort = "{'_id':-1}";
			try {
				intPgNo = ibody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = ibody.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 50;
			}
            
//           JsonArray dbAMLData = new JsonArray();
           String amlCheck = ibody.get("amlCheck").getAsString();
           JsonObject projection = new JsonObject();
           filter.addProperty("amlCheck", amlCheck);
           filter.addProperty("isCurrVer", "Y");
           projection.addProperty("_id", 0);
           JsonObject dbRes = dbctr.db$GetRows$Sort("ICOR_M_AML_CHECKS", filter, projection, intPgNo, intRecs, sort);
           JsonArray dbAMLData = dbRes.getAsJsonArray("i-body");
//           dbAMLData = dbctr.db$GetSummRowsArray("ICOR_M_AML_CHECKS", gson.toJson(filter), projection,
//					intPgNo, intRecs, sort);  fn_getCustYearlyAMLCheck
            for (int i = 0; i < dbAMLData.size(); i++) {
                try {
                	 String funName = "";
                    JsonObject db = dbAMLData.get(i).getAsJsonObject();
                    try {
                        funName = db.get("FunctionName").getAsString();
                    } catch(Exception e) {
                        funName = db.get("FunctionNmae").getAsString();
                    }
                    if (funName.equals("fn_getCustYearlyAMLCheck")) {
                        db.addProperty("FunctionNmae", "Yearly");
                    } else if (funName.equals("fn_getCustMonthlyAMLCheck")) {
                        db.addProperty("FunctionNmae", "Monthly");
                    } else if (funName.equals("fn_getCustDailyAMLCheck")) {
                        db.addProperty("FunctionNmae", "Daily");
                    }
                    //#MSA00001 changes starts
                    if (db.has("status") && (I$utils.$iStrFuzzyMatch(db.get("status").getAsString(), "ESCALATE")
                            || I$utils.$iStrFuzzyMatch(db.get("status").getAsString(), "REFER_USER"))) {
                        if (!I$utils.$iStrFuzzyMatch(db.get("TaskAssignedTo").getAsString(),
                                IResManipulator.iloggedUser.get())) {
                            continue;
                        }
                    }
                    row$Data.add(db);
                    //#MSA00001 changes ends
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
           ibody.add("iRowData", row$Data);
           isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", ibody);
           isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Retrieved Successfully");
           return isonMsg;
       } catch (Exception e) {
           isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Record Found");
       }
       return isonMsg;
    }
	public JsonObject riskProfilingSummaryDetails(JsonObject isonMsg) {//#SRP00078 Starts
        JsonObject iBody = isonMsg.get("i-body").getAsJsonObject();
        JsonArray dbRiskData=new JsonArray();
        JsonArray row$Data = new JsonArray();
        JsonArray invidualArray = new JsonArray();
        JsonObject data=new JsonObject();
        try {
        	String modelClass = iBody.get("MODEL_CLASS").getAsString();
            JsonObject filter = new JsonObject();
            JsonObject projection = new JsonObject();
            filter.addProperty("MODEL_CLASS", modelClass);
            projection.addProperty("_id", 0);
            dbRiskData = dbctr.db$GetRows("ICOR_M_EXIT_RISK_SCAN", filter, projection);
            for (int i = 0; i < dbRiskData.size(); i++) {
                JsonObject db = dbRiskData.get(i).getAsJsonObject();
                JsonArray individualWeight=db.get("INDIVIDUAL_WEIGHT").getAsJsonArray();
                for (int j = 0; j < individualWeight.size(); j++) {
                	data = new JsonObject();
                     data = individualWeight.get(j).getAsJsonObject();
                    String dataFormulaId=data.get("dataFormulaId").getAsString();
                    int value=data.get("value").getAsInt();
                    if(value > 0) {
                    	data = new JsonObject();
                    	data.addProperty("dataFormulaId", dataFormulaId);
                    	data.addProperty("value", value);
                    	invidualArray.add(data);
                        //db.add("INDIVIDUAL_WEIGHT", data);
                        //dbRiskData.add(db.toString());
                    }
				}//#MSA00002 changes starts
                if (db.has("status") && (I$utils.$iStrFuzzyMatch(db.get("status").getAsString(), "ESCALATE")
                        || I$utils.$iStrFuzzyMatch(db.get("status").getAsString(), "REFER_USER"))) {
                    if (!I$utils.$iStrFuzzyMatch(db.get("TaskAssignedTo").getAsString(),
                            IResManipulator.iloggedUser.get())) {
                        continue;
                    }
                }
                db.add("INDIVIDUAL_WEIGHT", invidualArray);
                row$Data.add(db);
            }
//            dbRiskData.add("INDIVIDUAL_WEIGHT",data);
            iBody.add("iRowData", row$Data);	//#MSA00002 changes ends
            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", iBody);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Retrieved Successfully");
            return isonMsg;
           // projection.addProperty("amlCheck", 1);
        }catch(Exception e) {
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Record Found");
        }
		return isonMsg;
	}//#SRP00078 Ends
	public JsonObject moveToCaseManagementRiskProfiling(JsonObject isonMsg)//#PAV00021 Changes starts
	{
		try{
		    int iRowCnt = 0;
	    	String uniCaseManId = I$Imputils.generateRandomKey(6);
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter = new JsonObject();
			JsonObject filter1= new JsonObject();
			filter1.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			filter.addProperty("CaseManagementId", uniCaseManId);
			filter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			filter.addProperty("ScanId", ibody.get("ScanId").getAsString());
			filter.addProperty("ModelClass", ibody.get("ModelClass").getAsString());
			filter.addProperty("Status", "OPEN");
			filter.addProperty("isCurrVer", "Y");
			filter.addProperty("recordStat", "O");
			filter.addProperty("initiator", IResManipulator.iloggedUser.get());
			filter.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
			iRowCnt = dbctr.db$GetCountI("ICOR_M_CASE_MANAGEMENT_RISK_PROFILING", filter1 );
			try {
				if(iRowCnt!=0) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Already Exists");
					return isonMsg;
				}
				isonMsg = dbctr.db$InsertRow("ICOR_M_CASE_MANAGEMENT_RISK_PROFILING",filter);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Shared to Case Management");
			}catch(Exception e) {
				e.printStackTrace();
			}
		}catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Record Found");
		}
		return isonMsg;
	}
	
	public JsonObject moveToCaseManagementAMLTransaction(JsonObject isonMsg)
	{
		try{
			int iRowCnt = 0;
	    	String uniCaseManId = I$Imputils.generateRandomKey(6);
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter1= new JsonObject();
			filter1.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			JsonObject filter = new JsonObject();
			filter.addProperty("CaseManagementId", uniCaseManId);
			filter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			filter.addProperty("CustomerAccNo", ibody.get("CustomerAccNo").getAsString());
			filter.addProperty("Branch", ibody.get("Branch").getAsString());
			filter.addProperty("Amount", ibody.get("Amount").getAsString());
			filter.addProperty("TransferType", ibody.get("TransferType").getAsString());
			filter.addProperty("FunctionName", ibody.get("FunctionName").getAsString());
			filter.addProperty("Status", "OPEN");
			filter.addProperty("isCurrVer", "Y");
			filter.addProperty("recordStat", "O");
			filter.addProperty("initiator", IResManipulator.iloggedUser.get());
			filter.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
			iRowCnt = dbctr.db$GetCountI("ICOR_M_CASE_MANAGEMENT_AML_TRANSACTION", filter1 );
			try {
				if(iRowCnt!=0) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Already Exists");
					return isonMsg;
				}
				isonMsg = dbctr.db$InsertRow("ICOR_M_CASE_MANAGEMENT_AML_TRANSACTION",filter);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Shared to Case Management");
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Record Found");
		}
		return isonMsg;
	}//#PAV00021 Changes ends
	public JsonObject moveToCaseManagementKYMChecks(JsonObject isonMsg)//#PAV00024 Changes Starts
	{
		try{
			int iRowCnt = 0;
	    	String uniCaseManId = I$Imputils.generateRandomKey(6);
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter1= new JsonObject();
			filter1.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			JsonObject filter = new JsonObject();
			filter.addProperty("CaseManagementId", uniCaseManId);
			filter.addProperty("JobId", ibody.get("uniqueId").getAsString());
			filter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			filter.addProperty("CustomerName", ibody.get("CustomerName").getAsString());
			filter.addProperty("initiatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
			filter.addProperty("initiator", IResManipulator.iloggedUser.get());
			filter.addProperty("Status", "OPEN");
			filter.addProperty("isCurrVer", "Y");
			filter.addProperty("recordStat", "O");
			iRowCnt = dbctr.db$GetCountI("ICOR_M_CASE_MANAGEMENT_KYM_CHECK", filter1 );
			try {
				if(iRowCnt!=0) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Already Exists");
					return isonMsg;
				}
				isonMsg = dbctr.db$InsertRow("ICOR_M_CASE_MANAGEMENT_KYM_CHECK",filter);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Shared to Case Management");
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Record Found");
		}
		return isonMsg;
	}//#PAV00024 Changes Ends

	public JsonObject movedCaseMangaementOprs(JsonObject isonMsg, JsonObject isonMapJson) {// #PAV00028 Changes Starts
		try {
			Gson gson = new Gson();
			JsonObject $ibody = isonMsg.get("i-body").getAsJsonObject();
			String memId = $ibody.get("memberId").getAsString();
			JsonObject filter = new JsonObject();
			filter.addProperty("CustomerId", memId);
			String Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			JsonObject i$Doc = new JsonObject();
			try {
				if ($ibody.has("comment")) {
					JsonArray latestArr = new JsonArray();
					JsonObject latestObj = new JsonObject();
					JsonObject prj = new JsonObject();
					prj.addProperty("Comment", $ibody.get("comment").getAsString());
					prj.addProperty("initiatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
					prj.addProperty("initiator", IResManipulator.iloggedUser.get());
					latestArr.add(prj);
					latestObj.add("$each", latestArr);
					i$Doc.add("Comments", latestObj);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if ($ibody.has("documents")) {
					JsonObject latestObj = new JsonObject();
					JsonObject documents = $ibody.get("documents").getAsJsonObject();
					JsonArray documentDetails = documents.get("documentDetails").getAsJsonArray();
					latestObj.add("$each", documentDetails);
					i$Doc.add("documents.documentDetails", latestObj);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			String i$CustomerIdDoc = gson.toJson(i$Doc);
			dbctr.db$UpdateRowOperator(Coll_Name, i$CustomerIdDoc, filter, "true", "push");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Saved");

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid Request");
		}
		return isonMsg;
	}
	
	public JsonObject closeCaseManagementOprs(JsonObject isonMsg, JsonObject isonMapJson) {
		try {
			Gson gson = new Gson();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter1 = new JsonObject();
			filter1.addProperty("CustomerId", ibody.get("memberId").getAsString());
			JsonObject prj = new JsonObject();
			JsonObject prj1 = new JsonObject();
			JsonObject i$Doc = new JsonObject();
			String Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			prj.addProperty("isCurrVer", "N");
			prj.addProperty("recordStat", "C");
			prj.addProperty("Status", "CLOSED");
			prj.addProperty("closingInitiatedBy", IResManipulator.iloggedUser.get());
			prj.add("closinginitiatedOnSrvDate", i$ResM.adddate(new Date()));
			try {
				try {

					if (ibody.has("comment")) {
						JsonArray latestArr = new JsonArray();
						JsonObject latestObj = new JsonObject();
						prj1.addProperty("Comment", ibody.get("comment").getAsString());
						prj1.addProperty("initiatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
						prj1.addProperty("initiator", IResManipulator.iloggedUser.get());
						latestArr.add(prj1);
						latestObj.add("$each", latestArr);
						i$Doc.add("Comments", latestObj);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				try {
					if (ibody.has("documents")) {
						JsonObject latestObj = new JsonObject();
						JsonObject documents = ibody.get("documents").getAsJsonObject();
						JsonArray documentDetails = documents.get("documentDetails").getAsJsonArray();
						latestObj.add("$each", documentDetails);
						i$Doc.add("documents.documentDetails", latestObj);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				String i$CustomerIdDoc = gson.toJson(i$Doc);
				dbctr.db$UpdateRowOperator(Coll_Name, i$CustomerIdDoc, filter1, "true", "push");
			} catch (Exception e) {
				e.printStackTrace();
			}
			dbctr.db$UpdateRow(Coll_Name, prj, filter1);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Closed");

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record was not Closed");
		}
		return isonMsg;
	}

	public JsonObject reopenCaseManagementOprs(JsonObject isonMsg, JsonObject isonMapJson) {
		try {
			Gson gson = new Gson();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter1 = new JsonObject();
			filter1.addProperty("CustomerId", ibody.get("memberId").getAsString());
			JsonObject prj = new JsonObject();
			JsonObject prj1 = new JsonObject();
			JsonObject i$Doc = new JsonObject();
			String Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			prj.addProperty("isCurrVer", "Y");
			prj.addProperty("recordStat", "O");
			prj.addProperty("Status", "OPEN");
			prj.addProperty("reOpenedBy", IResManipulator.iloggedUser.get());
			prj.add("reOpeneddOnSrvDate", i$ResM.adddate(new Date()));
			try {
				try {

					if (ibody.has("comment")) {
						JsonArray latestArr = new JsonArray();
						JsonObject latestObj = new JsonObject();
						prj1.addProperty("Comment", ibody.get("comment").getAsString());
						prj1.addProperty("initiatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
						prj1.addProperty("initiator", IResManipulator.iloggedUser.get());
						latestArr.add(prj1);
						latestObj.add("$each", latestArr);
						i$Doc.add("Comments", latestObj);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				try {
					if (ibody.has("documents")) {
						JsonObject latestObj = new JsonObject();
						JsonObject documents = ibody.get("documents").getAsJsonObject();
						JsonArray documentDetails = documents.get("documentDetails").getAsJsonArray();
						latestObj.add("$each", documentDetails);
						i$Doc.add("documents.documentDetails", latestObj);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				String i$CustomerIdDoc = gson.toJson(i$Doc);
				dbctr.db$UpdateRowOperator(Coll_Name, i$CustomerIdDoc, filter1, "true", "push");
			} catch (Exception e) {
				e.printStackTrace();
			}
			dbctr.db$UpdateRow(Coll_Name, prj, filter1);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully ReOpened");

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record was not ReOpened");
		}
		return isonMsg;
	}// #PAV00028 Changes Ends
}
//#MVT00064 ends