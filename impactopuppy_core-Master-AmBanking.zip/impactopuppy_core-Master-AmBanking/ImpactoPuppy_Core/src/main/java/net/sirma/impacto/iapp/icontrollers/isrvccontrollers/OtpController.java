/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Jan 09 2019  | #00000001   | Initial writing
      |0.1 Beta    | Baz 		| Jan 18 2019  | #00000002   | SMS Module Changes
      |0.1 Beta    | Niegil 	| Feb 04 2019  | #NYE00003   | Re-Org oF code
      |0.1 Beta    | Niegil 	| Feb 14 2019  | #NYE00004   | Access ID Validation
      |0.1 Beta    | Niegil 	| Feb 16 2019  | #NYE00005   | BUGID:000081 - OTP not validated Fixed 
      |0.2.1       | Vijay 	    | Mar 12 2019  | #BVB00093   | Invalid User Check
      |0.1 Beta    | Syed 	    | Feb 09 2021  | #MAQ10101   | Added Bypass for OTP
      |0.1 Beta    | Pruthvi 	| Feb 10 2021  | #YPR00050   | Added OTP to applied Email
      |0.1 Beta    | Pruthvi 	| Feb 23 2021  | #YPR00053   | Added notification to send verification Link
      |0.1 Beta    | Pruthvi 	| Mar 25 2021  | #YPR00064   | Added OTP srvc for forgot pass validation
      |0.3 Beta    | Pruthvi 	| Apr 12 2021  | #YPR00071   | Added Notification of reminders 
      |0.3 Beta    | Pruthvi 	| May 08 2021  | #YPR00075   | Added Notification for Incomplete Appln Job
      |0.3 Beta    | Pruthvi 	| May 08 2021  | #YPR00077   | Added Notification for initialDep pending
      |4.1 Beta    | Pappu      | May 24 2021  | #PKY00013   | Added new MSG service for DatasetId
      |4.2 Beta    | Pappu      | May 25 2021  | #PKY00014   | Added new Pending Verification reminder service for datasetId
      |4.2 Beta    | Pappu      | Jun 22 2021  | #PKY00016   | Added condition for fixed deposit SMS_TRIGGER
      |4.3         | Syed       | Jun 23 2021  | #MAQ00122   | Added code for verifyotp max count 3
      |4.4         | Sushmita   | Jun 30 2021  | #SKP0001    | Added code for verifyotp after success
      |4.4         | Pappu      | Aug 02 2021  | #PKY00035   | Added condition to validate age for FCIP, FIP, TATIL, AND LINCU and In-complete tatil application
      |4.4         | Sushmita   | Aug 18 2021  | #SKP00002   | Added code for FD Notification Template Mapping
      |4.4         | Samadhan   | Aug 24 2021  | #SRP00015   | Added code for map sms and Email triggered for FCIP
      |4.4 Beta    | Pappu      | Sep 01 2021  | #PKY00045   | handled sendgrid API
      |4.4         | Tarun      | Sep 03 2021  | #TKS00001   | Added code for validation of modes for otp.
      |4.4 Beta    | Samadhan   | sep 08, 2021 | #SRP00021   | Added Code for To send Email to multiple Recepient
      |4.4         | Pappu      | Sep 14,2021  | #PKY00046   | handled success notification for loan and LOc
      |4.4         | Tarun      | Sep 21,2021  | #TKS00004   | added code to handle loan in-complete application.
      |4.4         | Pappu      | Sep 22,2021  | #PKY00047   | handled tatil incomplete application.
      |4.4         | Samadhan   | Oct 05,2021  | #SRP00028   | handled success notification for Lincu application
      |4.4         | Pappu      | Oct 06, 2021 | #PKY00051   | Handled Reminder notification before terminating the loan appln
      |4.4         | Pappu      | Oct 07, 2021 | #PKY00052   | Handled Fip appln success notification 
      |4.4         | Pappu      | oct 02, 2021 | #PKY00057   | handling to send pending appln review notifician to tecu officier for Lincu, FD, and Health plan Module
	  |4.4         | Pappu      | oct 03, 2021 | #PKY00058   | handling to send pending appln review notifician to insurance Team for FIP and FCIP module
	  |4.4         | Pappu      | nov 12, 2021 | #PKY00060   | handled tatil appln success notification
	  |4.4         | Pappu      | nov 23, 2021 | #PKY00062   | handled loan reminder notification condition and and improved the condition
	  |4.4         | Samadhan   | Dec 02, 2021 | #SRP00040   | Handled FCIP age Condtion
	  |4.4		   | Manikanta  | Dec 13, 2021 | #MVT00025	 | Added code for FCIP age limit
      |4.4         | Pappu      | dec 16, 2021 | #PKY00066   | handled tatil application reminder notification
      |4.4 		   | Manikanta  | Feb 16, 2022 | #MVT00034	 | Added code for tatil age limit
      |4.4         | Samadhan   | Mar 18, 2022 | #SRP00053   | Added Code for IntialFD Amount
      |4.4         | Samadhan   | Mar 30, 2022 | #SRP00055   | Code change for Tatil isCurVer
      |4.4         | Sushmita   | Aug 30, 2022 | #SKP00003   | Handled back office digi check 
      |4.4         | Sushmita   | Sep 01, 2022 | #SKP00004   | Handled Digi reset otp different scenarios
      |4.4		   | Manikanta  | Jan 06, 2022 | #MVT00096	 | Added code for loan application and payroll applications
      |4.4		   | Manikanta  | Feb 09, 2023 | #MVT00105   | Added code to handle category 50 for member register
      |4.4		   | Sindhu R   | May 02, 2023 | #SRM00036   | Added code to validate IMBAccess field
      |4.4		   | Sindhu R   | May 16, 2023 | #SRM00037   | Added error message for IMBAccess validation
      |4.4	       | Manikanta  | Jul 04, 2023 | #MVT00126   | Added code to IMB access from flexcube
      |4.4		   | Pavithra   | Jul 11, 2023 | #PAV00001   | Removing digi check validations
      |4.4 		   | Manikanta  | Jul 18, 2023 | #MVT00130   | Added code for to handle imb access only for digi app
      |4.4 		   | Srikanth   | oct 19, 2023 | #SRI00012   | Added code for to handle phone Number EmailID mask
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class OtpController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private static DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil imp$utils = new ImpactoUtil();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IFuncSrvcController i$Func = new IFuncSrvcController();

	private IResManipulator i$ResM = new IResManipulator();
	private IEmailService i$Email = new IEmailService();
	private ISmsService i$SmsSrvc = new ISmsService();
	private Logger logger = LoggerFactory.getLogger(OtpController.class); // #NYE00003 - Change Class Name
	// **********************************************************************//

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			String SOpr = i$ResM.getOpr(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);

			if (I$utils.$iStrFuzzyMatch(SrvOpr, "sendOTP")) {
				return sendOTP(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "sendOTP#")) {
				return sendOTPRAW(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "sendOTPAE")) {// #YPR00050 Changes
				return sendAppOTP(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "sendOTPPC")) {// #YPR00064 Changes
				return sendFpassOTP(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "verifyOTP")) {
				return verifyOTP(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "incAppRem")) { // #YPR00075 Changes
				return inCompleteAppRem(i$body, isonMsg, "");
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "initDepRem")) { // #YPR00077 Changes
				return intialDepositRem(i$body, isonMsg, "");
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "sendOTPDS")) { // #PKY00013 Changes
				return sendOTPDataSet(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "verfRemDS")) { // #PKY00014 Changes
				return pendingVerfRem(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "applnTermRem")) { // #PKY00051 changes
				return loanApplnTerminationReminder(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "tatilApplnReminder")) { //// PKY00066 changes
				return tatilApplnReminder(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "cifCheck")) { //// SKP00004 changes
				return sendOTP(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "sendEmail")) { //// SKP00004 changes
				return sendStatusEmail(i$body, isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "onBoardApplnReminder")) { // MSA00065 changes
				return onBoardApplnReminder(isonMsg);
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg;
		}
		return null;
	};

	public JsonObject sendOTPRAW(JsonObject argJson, JsonObject isonMsg) {
		try {

			String sOptMaint = "iOtpCommMode_" + i$ResM.getClientApp(isonMsg);
			String sTmplName = null;
			String sMsgAnnote = null;
			new JsonObject();
			System.getProperty("line.separator");
			// argJson.get("Mode").getAsString();

			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				// sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg);
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
						"{\"MSG_ANNOTATION\":\"" + i$ResM.getBodyElementS(isonMsg, "Msg_Annotation") + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#OTP";

			// Generate the sec key and otp and store in otp validator
			argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));
			argJson.addProperty("iotp", Integer.toString(imp$utils.generateRandom(10005, 99999)));
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("otp$verified", false);
			argJson.addProperty("tmplName", sTmplName);
			db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);

			String sKeyE = i$ResM.getBodyElementS(isonMsg, "KeyE");
			String sKeyM = i$ResM.getBodyElementS(isonMsg, "KeyM");

			if (!I$utils.$iStrBlank(sKeyE)) {
				argJson.addProperty("Key", sKeyE);
				sendEmailRaw(argJson, isonMsg.deepCopy());
				logger.debug("Send Email SuccessFull");
			}
			;

			if (!I$utils.$iStrBlank(sKeyM)) {
				argJson.addProperty("Key", sKeyM);
				sendSMSRaw(argJson, isonMsg.deepCopy());
				logger.debug("Send SMS SuccessFull");
			}
			;
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP Service Triggered Sucessfully");
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending OTP or OTP Service is disabled", "Contact Adminstrator");

		}
	};

	private JsonObject sendSMSRaw(JsonObject argJson, JsonObject isonMsg) {
		try {

			JsonObject Mob$No = new JsonObject();

			Mob$No.addProperty("Name", "User");
			Mob$No.addProperty("Key", i$ResM.getBodyElementS(isonMsg, "KeyM"));

			argJson.addProperty("key$Type", "otp");
			argJson.add("mobile$numbers",
					i$ResM.getJsonObj("{\"Mob_Number1\":\"" + Mob$No.get("Key").getAsString() + "\"}")); // #NYE00003
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("otp", argJson.get("iotp").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
			argJson.add("map$Data", map$Data);
			JsonObject i$resBody = new JsonObject();

			i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

			// Forward to Otp Service
			JsonObject i$res = i$SmsSrvc.SendSMSWOThread(argJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS OTP Sent Successfully ");
			} else {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			}
			return isonMsg;

		} catch (Exception e) {
			logger.debug("Error in Sending SMS");
			logger.debug(e.getLocalizedMessage());
			return isonMsg;
		}

	};

	private JsonObject sendEmailRaw(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonObject email$Details = new JsonObject();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			email$Details.addProperty("Key", i$ResM.getBodyElementS(isonMsg, "KeyE"));
			email$Details.addProperty("Name", "User");
			argJson.addProperty("key$Type", "otp");
			argJson.add("toemailIds",
					i$ResM.getJsonObj("{\"toemailid1\":\"" + email$Details.get("Key").getAsString() + "\"}")); // #NYE00003
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("user", email$Details.get("Name").getAsString());
			map$Data.addProperty("otp", argJson.get("iotp").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());

			try {
				JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
						"{ Template_ID: \"" + argJson.get("tmplName").getAsString() + "\" }");
				if (i$emailtmpl.has("getKeysFrmBody")) {
					JsonArray Keys = i$emailtmpl.get("getKeysFrmBody").getAsJsonArray();
					for (int k = 0; k < Keys.size(); k++) {
						String key = Keys.get(k).getAsString();
						map$Data.addProperty(key, i$ResM.getStrfromObj(i$body, key));
					}
				}
			} catch (Exception e) {
				// Eat up
			}
			argJson.add("map$Data", map$Data);
			JsonObject i$resBody = new JsonObject();
			i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

			JsonObject i$res = i$Email.SendEmailWOThread(argJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email OTP Sent Successfully ");
			} else {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			}
			return isonMsg;

		} catch (Exception e) {
			logger.debug("Error in Sending Email");
			logger.debug(e.getLocalizedMessage());
			return isonMsg;
		}

	};

	// #YPR00050 Starts
	public JsonObject sendAppOTP(JsonObject argJson, JsonObject isonMsg) {
		try {

			String sOptMaint = "iOtpCommMode_" + i$ResM.getClientApp(isonMsg);
			String sTmplName = null;
			String sMsgAnnote = null;
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			System.getProperty("line.separator");
			Boolean verifyApp = false;
			try {
				verifyApp = i$body.get("verifyApp").getAsBoolean();
			} catch (Exception e) {
			}

			filter.addProperty("applicationId", i$ResM.getBodyElementS(isonMsg, "applicationId"));
//			if (!verifyApp) {
//				filter.addProperty("WorkFlowStatus", "INITIAL DEPOSIT APPLICATION");
//				filter.addProperty("paymentStatus", "Payment Due");
//			}
			filter.addProperty("isCurrVer", "Y");

			projection.addProperty("contactDetails.emailId", 1);
			projection.addProperty("contactDetails.mobileISD", 1);
			projection.addProperty("contactDetails.mobileNumber", 1);
			projection.addProperty("personalInfo", 1);
			projection.addProperty("DcStatus", 1);
			projection.addProperty("_id", 0);

			JsonObject appData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter, projection);
			if (I$utils.$isNull(appData))
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid Application Id");
			if (I$utils.$iStrFuzzyMatch(appData.get("DcStatus").getAsString(), "Completed")) {
				try {
					if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
						// sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg);
						sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
								"{\"MSG_ANNOTATION\":\"" + i$ResM.getBodyElementS(isonMsg, "Msg_Annotation") + "\"}",
								"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
					} else
						sTmplName = "TMPL#OTP";

					// Generate the sec key and otp and store in otp validator
					argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));
					argJson.addProperty("iotp", Integer.toString(imp$utils.generateRandom(10005, 99999)));
					argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
					argJson.addProperty("otp$verified", false);
					argJson.addProperty("tmplName", sTmplName);
					db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);

					JsonObject map$Data = new JsonObject();
					map$Data.addProperty("user",
							appData.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
									+ appData.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
					map$Data.addProperty("otp", argJson.get("iotp").getAsString());
					map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
					try {
						JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
								"{ Template_ID: \"" + argJson.get("tmplName").getAsString() + "\" }");
						if (i$emailtmpl.has("getKeysFrmBody")) {
							JsonArray Keys = i$emailtmpl.get("getKeysFrmBody").getAsJsonArray();
							for (int k = 0; k < Keys.size(); k++) {
								String key = Keys.get(k).getAsString();
								map$Data.addProperty(key, i$ResM.getStrfromObj(i$body, key));
							}
						}
					} catch (Exception e) {
						// Eat up
					}
					argJson.add("map$Data", map$Data);

//			String sKeyE =  i$ResM.getBodyElementS(isonMsg, "KeyE");
					String sKeyE = appData.get("contactDetails").getAsJsonObject().get("emailId").getAsString();
					String sKeyM = appData.get("contactDetails").getAsJsonObject().get("mobileISD").getAsString()
							+ appData.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString();
//			String sKeyM =  i$ResM.getBodyElementS(isonMsg, "KeyM");

					argJson.addProperty("key$Type", "otp");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + sKeyM + "\"}"));

					JsonObject i$resBody = new JsonObject();
					i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

					if (!I$utils.$iStrBlank(sKeyE) || !I$utils.$iStrBlank(sKeyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
						JsonObject i$resM = i$SmsSrvc.SendSMSWOThread(argJson);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resE), i$ResM.I_SUCC)
								|| I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resM), i$ResM.I_SUCC)) {
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
									"OTP Service Triggered Sucessfully");
						} else {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"Error in Sending OTP or OTP Service is disabled");
						}
					} else {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Error in Sending OTP or OTP Service is disabled");
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug(e.getLocalizedMessage());
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, e.getMessage());
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Kindly note, The application still is in Incomplete stage. Please complete it to upload the Payment Receipt");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending OTP or OTP Service is disabled", "Contact Adminstrator");

		}
	};
	// #YPR00050 Ends

	// #YPR00053 Starts
	public JsonObject sendDeepLnk(JsonObject isonMsg) {
		try {

			String sOptMaint = "iOtpCommMode_" + i$ResM.getClientApp(isonMsg);
			String sTmplName = null;
			String sMsgAnnote = null;
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject projection = new JsonObject();
			System.getProperty("line.separator");
			String appId = i$ResM.getBodyElementS(isonMsg, "applicationId");

			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				// sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg);
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
						"{\"MSG_ANNOTATION\":\"" + i$ResM.getBodyElementS(isonMsg, "Msg_Annotation") + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#WEB#PORTAL#APPSUBMIT#NOTIFICATION";

			argJson.addProperty("applicationId", appId);
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("tmplName", sTmplName);
			db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);

			filter.addProperty("applicationId", appId);
			projection.addProperty("contactDetails.emailId", 1);
			projection.addProperty("contactDetails.mobileISD", 1);
			projection.addProperty("contactDetails.mobileNumber", 1);
			projection.addProperty("personalInfo", 1);
			projection.addProperty("_id", 0);

			JsonObject appData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter, projection);

			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("user", appData.get("personalInfo").getAsJsonObject().get("firstName").getAsString()
					+ " " + appData.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
			map$Data.addProperty("applicationId", appId);
			map$Data.addProperty("tmp$name", sTmplName);
			try {
				JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
						"{ Template_ID: \"" + argJson.get("tmplName").getAsString() + "\" }");
				if (i$emailtmpl.has("getKeysFrmBody")) {
					JsonArray Keys = i$emailtmpl.get("getKeysFrmBody").getAsJsonArray();
					for (int k = 0; k < Keys.size(); k++) {
						String key = Keys.get(k).getAsString();
						map$Data.addProperty(key, i$ResM.getStrfromObj(i$body, key));
					}
				}
			} catch (Exception e) {
				// Eat up
			}
			argJson.add("map$Data", map$Data);

//			String sKeyE =  i$ResM.getBodyElementS(isonMsg, "KeyE");
			String sKeyE = appData.get("contactDetails").getAsJsonObject().get("emailId").getAsString();
			String sKeyM = appData.get("contactDetails").getAsJsonObject().get("mobileISD").getAsString()
					+ appData.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString();
//			String sKeyM =  i$ResM.getBodyElementS(isonMsg, "KeyM");

			argJson.addProperty("key$Type", "notification");
			argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
			argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + sKeyM + "\"}"));

			JsonObject i$resBody = new JsonObject();
			i$resBody = i$body;
			i$resBody.addProperty("Notification", "Verification Link Sent Successfully");

			if (!I$utils.$iStrBlank(sKeyE) || !I$utils.$iStrBlank(sKeyM)) {
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				JsonObject i$resM = i$SmsSrvc.SendSMSWOThread(argJson);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resE), i$ResM.I_SUCC)
						|| I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resM), i$ResM.I_SUCC)) {
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
							"APPLICATION SUBMITTED SUCCESSFULLY");
				} else {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Error in Sending Verification Link or Notification Service is disabled");
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Error in Sending Verification Link or Notification Service is disabled");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending OTP or OTP Service is disabled", "Contact Adminstrator");

		}
	};
	// #YPR00053 Ends

	// #YPR00071 Starts
	public void sendNotificFN(JsonObject app$Json, String TmplName) {
		try {

			String sTmplName = null;
			String sMsgAnnote = null;
//			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject projection = new JsonObject();
			System.getProperty("line.separator");
			String appId = app$Json.get("applicationId").getAsString();

			if (app$Json.has("Msg_Annotation")) {
				// sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg);
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
						"{\"MSG_ANNOTATION\":\"" + app$Json.get("Msg_Annotation").getAsString() + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = TmplName;

			argJson.addProperty("applicationId", appId);
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("tmplName", sTmplName);
//			db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);

			JsonObject appData = new JsonObject(); // #PKY00016 starts
			JsonObject map$Data = new JsonObject();
			String sKeyE = new String();
			String sKeyM = new String();
			String WorkFlowId;

			try {
				WorkFlowId = app$Json.get("WorkFlowId").getAsString();
			} catch (Exception e) {
				WorkFlowId = "IMPACTO_CIF_WFLW_NEW";
			}

			if ((I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_FIXED_DEPOSIT_WORKFLOW"))) {
				filter.addProperty("applicationId", appId);
				projection.addProperty("trnData.custNo", 1);
				// #SKP00002 starts
				projection.addProperty("trnData.tenor", 1);
				projection.addProperty("trnData.initialTDAmt", 1);
				projection.addProperty("trnData.dateOfIssue", 1);
				projection.addProperty("trnData.acCls", 1); // #PKY00045 changes
				// #SKP00002 ends
				projection.addProperty("_id", 0);
				JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_B2U_FD_APPLICATION", filter, projection);
				JsonObject trnData = db$Data.get("trnData").getAsJsonObject();
				String cumtomerNo = db$Data.get("trnData").getAsJsonObject().get("custNo").getAsString();
				appData = db$Ctrl.cbsCifData(cumtomerNo, "");
				String fullName = appData.get("CustomerFullName").getAsString();
				map$Data.addProperty("FullName", fullName);
				map$Data.addProperty("custNo", appData.get("CustomerId").getAsString()); // MSA00017 changes
				if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#SUCCESS#FD#NOTIFICATION#MAIL")) { // #PKY00057 starts
					// #SKP00002 starts
					map$Data.addProperty("tenor",
							trnData.get("acCls").getAsString() + " - " + trnData.get("tenor").getAsString()); // #PKY00045
																												// changes
					String intialAmount = trnData.get("initialTDAmt").getAsString();// #SRP00053 starts
					double amount = Double.parseDouble(intialAmount);
					String initialTDAmt = String.format("%,.2f", amount);
					map$Data.addProperty("initialTDAmt", initialTDAmt);// #SRP00053 Ends
					map$Data.addProperty("StartDate", trnData.get("dateOfIssue").getAsString());
					// #SKP00002 ends
					map$Data.addProperty("applicationId", appId);
					map$Data.addProperty("tmp$name", sTmplName);
					sKeyE = appData.get("CustomerEmailId").getAsString();
					sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
							+ appData.get("CustomerMobileId").getAsString();
					// #PKY00045 starts
					try {
						if (app$Json.has("attachment")) {
							argJson.add("attachment", app$Json.get("attachment").getAsJsonArray());
						}
					} catch (Exception e) {
					}
					// #PKY00045 ends

				} else if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#FD#VERIFICATION#PENDING")) {
					filter = new JsonObject();
					projection = new JsonObject();
					map$Data.addProperty("fullName", fullName);
					map$Data.addProperty("tmp$name", sTmplName);
					filter.addProperty("datasetId", "Dataset_5672");
					projection.addProperty("userDetails", 1);
					projection.addProperty("sendEmail", 1);
					projection.addProperty("sendSms", 1);
					appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
					JsonArray userDet = appData.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(appData.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(appData.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								sKeyE = sKeyE.concat(Email);
								if (i < userDet.size() - 1) {
									sKeyE = sKeyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								sKeyM = sKeyM.concat(SMS);
								if (i < userDet.size() - 1) {
									sKeyM = sKeyM.concat(",");
								}
							}
						} catch (Exception e) {

						}
					}

				} // #PKY00057 ends

			} else if ((I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_FIP_WORKFLOW"))) { // #PKY00052 starts
				filter.addProperty("applicationId", appId);
				projection.addProperty("fipEnrolment", 1);
				projection.addProperty("applicationId", 1);
				JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_B2U_FIP_APPLICATION", filter, projection);
				appData = db$Ctrl.cbsCifData(
						db$Data.get("fipEnrolment").getAsJsonObject().get("membershipNo").getAsString(), "");
				String fullName = appData.get("CustomerFullName").getAsString();
				map$Data.addProperty("FullName", fullName);
				if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#SUCCESS#FIP#NOTIFICATION#MAIL")) {
					String memNo = db$Data.get("fipEnrolment").getAsJsonObject().get("membershipNo").getAsString();
//						memNo=memNo.replaceAll(memNo.substring(0 , 3), "***");
					map$Data.addProperty("cif", memNo);
					map$Data.addProperty("applicationId", db$Data.get("applicationId").getAsString());
					map$Data.addProperty("tmp$name", sTmplName);
					sKeyE = appData.get("CustomerEmailId").getAsString();
					sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
							+ appData.get("CustomerMobileId").getAsString(); // #PKY00052 ends
				} else if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#FIP#VERIFICATION#PENDING")) {
					filter = new JsonObject();
					projection = new JsonObject();
					map$Data.addProperty("fullName", fullName);
					map$Data.addProperty("tmp$name", sTmplName);
					filter.addProperty("datasetId", "Dataset_5674");
					projection.addProperty("userDetails", 1);
					projection.addProperty("sendEmail", 1);
					projection.addProperty("sendSms", 1);
					appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
					JsonArray userDet = appData.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(appData.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(appData.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								sKeyE = sKeyE.concat(Email);
								if (i < userDet.size() - 1) {
									sKeyE = sKeyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								sKeyM = sKeyM.concat(SMS);
								if (i < userDet.size() - 1) {
									sKeyM = sKeyM.concat(",");
								}
							}
						} catch (Exception e) {

						}
					}

				}

			} else if ((I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_LEAD_WRKFLOW"))) { // #PKY00046 starts
				filter.addProperty("applicationId", appId);
				projection.addProperty("cif", 1);
				projection.addProperty("applicationId", 1);
				projection.addProperty("CustomerFullName", 1);
				projection.addProperty("_id", 0);
				// #SRP00023 Starts
				projection.addProperty("extraDetails", 1);
				projection.addProperty("loanDetails", 1);
				// #SRP00023 Ends
				JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_LD_LEAD_APPLICATIONS", filter, projection);
				appData = db$Ctrl.cbsCifData(db$Data.get("cif").getAsString(), "");
				map$Data.addProperty("FullName", db$Data.get("CustomerFullName").getAsString());
				map$Data.addProperty("applicationId", db$Data.get("applicationId").getAsString());
				map$Data.addProperty("cif", db$Data.get("cif").getAsString());
				map$Data.addProperty("tmp$name", sTmplName);
				// #SRP00023 Starts
				try {
					if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#LOAN#VERIFICATION#PENDING")) {
						map$Data.addProperty("Application ID", db$Data.get("applicationId").getAsString());
						map$Data.addProperty("Member Number", db$Data.get("cif").getAsString());
						map$Data.addProperty("Member Name", db$Data.get("CustomerFullName").getAsString());
						JsonObject extraDetails = db$Data.get("extraDetails").getAsJsonObject();
						JsonObject loanDetails = db$Data.get("loanDetails").getAsJsonObject();
						map$Data.addProperty("Loan Officer", extraDetails.get("loanOfficer").getAsString());
						map$Data.addProperty("Preferred Branch", loanDetails.get("loanBranch").getAsString());
						projection = new JsonObject();
						filter = new JsonObject();
						filter.addProperty("datasetId", "Dataset_5669");
						projection.addProperty("userDetails", 1);
						projection.addProperty("sendEmail", 1);
						projection.addProperty("sendSms", 1);
						appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
						JsonArray userDet = appData.get("userDetails").getAsJsonArray();
						boolean sendSMS = I$utils.$iStrFuzzyMatch(appData.get("sendSms").getAsString(), "Y");
						boolean sendEmail = I$utils.$iStrFuzzyMatch(appData.get("sendEmail").getAsString(), "Y");
						for (int i = 0; i < userDet.size(); i++) {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								sKeyE = sKeyE.concat(Email);
								if (i < userDet.size() - 1) {
									sKeyE = sKeyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								sKeyM = sKeyM.concat(SMS);
								if (i < userDet.size() - 1) {
									sKeyM = sKeyM.concat(",");
								}
							}
						}
					} else {
						sKeyE = appData.get("CustomerEmailId").getAsString();
						sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
								+ appData.get("CustomerMobileId").getAsString();
					}
				} catch (Exception e) {
				}
				try {// #MVT00096 begins
					if (app$Json.has("attachment")) {
						argJson.add("attachment", app$Json.get("attachment").getAsJsonArray());
					}
				} catch (Exception e) {
				} // #MVT00096 ends
				// #SRP00023 Ends
//				 sKeyE = appData.get("CustomerEmailId").getAsString();
//				 sKeyM = appData.get("CustomerMobileIsdNo").getAsString() + appData.get("CustomerMobileId").getAsString();  //#PKY00046 ends  
			} else if ((I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_TATIL_INSURANCE_WORKFLOW"))) { // #PKY00060 starts
				filter.addProperty("applicationId", appId);
				projection.addProperty("custInfo", 1);
				JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_B2U_TATIL_APPLICATION", filter, projection);
				String fullName = db$Data.get("custInfo").getAsJsonObject().get("CustomerFullName").getAsString();
				String cumtomerNo = db$Data.get("custInfo").getAsJsonObject().get("CustomerId").getAsString();
				map$Data.addProperty("FullName", fullName);

				if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#SUCCESS#TATIL#NOTIFICATION#MAIL")) {
					appData = db$Ctrl.cbsCifData(cumtomerNo, "");
//	                	cumtomerNo=cumtomerNo.replaceAll(cumtomerNo.substring(0 , 3), "***");
					map$Data.addProperty("applicationId", appId);
					map$Data.addProperty("cif", cumtomerNo);
					map$Data.addProperty("tmp$name", sTmplName);
					sKeyE = appData.get("CustomerEmailId").getAsString();
					sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
							+ appData.get("CustomerMobileId").getAsString(); // #PKY00060 ends

				} else if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#TATIL#VERIFICATION#PENDING")) { // #PKY00057
																										// starts
					filter = new JsonObject();
					projection = new JsonObject();
					map$Data.addProperty("fullName", fullName);
					map$Data.addProperty("tmp$name", sTmplName);
					filter.addProperty("datasetId", "Dataset_5673");
					projection.addProperty("userDetails", 1);
					projection.addProperty("sendEmail", 1);
					projection.addProperty("sendSms", 1);
					appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
					JsonArray userDet = appData.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(appData.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(appData.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								sKeyE = sKeyE.concat(Email);
								if (i < userDet.size() - 1) {
									sKeyE = sKeyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								sKeyM = sKeyM.concat(SMS);
								if (i < userDet.size() - 1) {
									sKeyM = sKeyM.concat(",");
								}
							}
						} catch (Exception e) {

						}
					}
				}

				// #PKY00057 ends
				// #MVT00096 begins
			} else if (I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_PAYROLL_WORKFLOW")) {
				try {// MSA00017 starts
					if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#SUCCESS#BACKTO#TECU#NOTIFICATION#MAIL")) {
						filter.addProperty("applicationId", appId);
						projection.addProperty("custNo", 1);
						JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_PAYROLL_CIF_FT_COLL", filter, projection);
						appData = db$Ctrl.cbsCifData(db$Data.get("custNo").getAsString(), "");

						sKeyE = appData.get("CustomerEmailId").getAsString();
						sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
								+ appData.get("CustomerMobileId").getAsString();
						map$Data.addProperty("applicationId", appId);
						map$Data.addProperty("tmp$name", sTmplName);
						map$Data.addProperty("custNo", appData.get("CustomerId").getAsString());
						map$Data.addProperty("memName", appData.get("CustomerFullName").getAsString());// MSA00017 ends
					}
				} catch (Exception e) {
					logger.debug(e.getMessage());
				}
			} // #MVT00096 ends
				// MSA00017 starts
			else if (I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_RE_KYC_WRKFLOW_LITE")) {
				try {
					JsonObject fltr = new JsonObject();
					if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#SUCCESS#MY#INFORMATION#NOTIFICATION#MAIL")) {
						filter.addProperty("applicationId", appId);
						projection.addProperty("contactDetails.CIF", 1);
						JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_B2U_RE_KYC_LITE_APPS", filter, projection);
						String cif = db$Data.get("contactDetails").getAsJsonObject().get("CIF").getAsString();
						fltr.addProperty("CustomerId", cif);
//						appData =db$Ctrl.cbsCifData(db$Data.get("custNo").getAsString(),"");
						appData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
						sKeyE = appData.get("CustomerEmailId").getAsString();
						sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
								+ appData.get("CustomerMobileId").getAsString();
						map$Data.addProperty("applicationId", appId);
						map$Data.addProperty("tmp$name", sTmplName);
						map$Data.addProperty("custNo", appData.get("CustomerId").getAsString());
						map$Data.addProperty("memName", appData.get("CustomerFullName").getAsString());
					}
				} catch (Exception e) {
					logger.debug(e.getMessage());
				}

			} // MSA00017 ends
			else if ((I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_CHERRY_PICKS_WORKFLOW"))) { // #SRP00015 Starts
				filter.addProperty("applicationId", appId);
				projection.addProperty("fcipData", 1);
				JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_B2U_FCIP_APPLICATION", filter, projection);
				JsonObject fcipData = db$Data.get("fcipData").getAsJsonObject();
				String cumtomerNo = db$Data.get("fcipData").getAsJsonObject().get("memberNumber").getAsString();
				String fullName = db$Data.get("fcipData").getAsJsonObject().get("firstName").getAsString() + " "
						+ db$Data.get("fcipData").getAsJsonObject().get("middleName").getAsString() + " "
						+ db$Data.get("fcipData").getAsJsonObject().get("lastName").getAsString();
				map$Data.addProperty("FullName", fullName);
				if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#FCIP#SUCC")) { // #PKY00058 starts
					appData = db$Ctrl.cbsCifData(cumtomerNo, "");
//	                	cumtomerNo=cumtomerNo.replaceAll(cumtomerNo.substring(0 , 3), "***");
					map$Data.addProperty("applicationId", appId);
					map$Data.addProperty("cif", fcipData.get("memberNumber").getAsString());
					map$Data.addProperty("CIF", cumtomerNo);
					map$Data.addProperty("tmp$name", sTmplName);
					sKeyE = appData.get("CustomerEmailId").getAsString();
					sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
							+ appData.get("CustomerMobileId").getAsString(); // #SRP00015 Ends
				} else if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#FCIP#VERIFICATION#PENDING")) {
					filter = new JsonObject();
					projection = new JsonObject();
					map$Data.addProperty("fullName", fullName);
					map$Data.addProperty("tmp$name", sTmplName);
					filter.addProperty("datasetId", "Dataset_5672");
					projection.addProperty("userDetails", 1);
					projection.addProperty("sendEmail", 1);
					projection.addProperty("sendSms", 1);
					appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
					JsonArray userDet = appData.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(appData.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(appData.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								sKeyE = sKeyE.concat(Email);
								if (i < userDet.size() - 1) {
									sKeyE = sKeyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								sKeyM = sKeyM.concat(SMS);
								if (i < userDet.size() - 1) {
									sKeyM = sKeyM.concat(",");
								}
							}
						} catch (Exception e) {

						}
					}
				} // #PKY00058 ends
			} else if ((I$utils.$iStrFuzzyMatch(WorkFlowId, "IMPACTO_LINCU_WORKFLOW"))) { // SRP00028 Starts

				filter.addProperty("applicationId", appId);
				projection.addProperty("fcbl", 1);
				projection.addProperty("memberNo", 1);
				projection.addProperty("applicationId", 1);
				JsonObject db$Data = db$Ctrl.db$GetRow("ICOR_C_B2U_LINCU_APPLICATION", filter, projection);
				JsonObject fcbl = db$Data.get("fcbl").getAsJsonObject();
				String fullName = db$Data.get("fcbl").getAsJsonObject().get("firstName").getAsString() + " "
						+ db$Data.get("fcbl").getAsJsonObject().get("middleName").getAsString() + " "
						+ db$Data.get("fcbl").getAsJsonObject().get("lastName").getAsString();
				if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#SUCCESS#LINCU#NOTIFICATION#MAIL")) { // #PKY00057 starts
					appData = db$Ctrl.cbsCifData(db$Data.get("memberNo").getAsString(), "");
					String memNo = db$Data.get("memberNo").getAsString();
//						memNo=memNo.replaceAll(memNo.substring(0 , 3), "***");
					map$Data.addProperty("fullName", fullName);
					map$Data.addProperty("cif", db$Data.get("memberNo").getAsString());
					map$Data.addProperty("CIF", memNo);
					map$Data.addProperty("ApplicationId", db$Data.get("applicationId").getAsString());
					map$Data.addProperty("tmp$name", sTmplName);
					sKeyE = appData.get("CustomerEmailId").getAsString();
					sKeyM = appData.get("CustomerMobileIsdNo").getAsString()
							+ appData.get("CustomerMobileId").getAsString(); // #SRP00028 Ends
				} else if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#LINCU#VERIFICATION#PENDING")) {
					filter = new JsonObject();
					projection = new JsonObject();
					map$Data.addProperty("fullName", fullName);
					map$Data.addProperty("tmp$name", sTmplName);
					filter.addProperty("datasetId", "Dataset_5671");
					projection.addProperty("userDetails", 1);
					projection.addProperty("sendEmail", 1);
					projection.addProperty("sendSms", 1);
					appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
					JsonArray userDet = appData.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(appData.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(appData.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								sKeyE = sKeyE.concat(Email);
								if (i < userDet.size() - 1) {
									sKeyE = sKeyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								sKeyM = sKeyM.concat(SMS);
								if (i < userDet.size() - 1) {
									sKeyM = sKeyM.concat(",");
								}
							}
						} catch (Exception e) {

						}
					}
				} // #PKY00057 ends
			} else {
				filter.addProperty("applicationId", appId);
				projection.addProperty("contactDetails.emailId", 1);
				projection.addProperty("contactDetails.mobileISD", 1);
				projection.addProperty("contactDetails.mobileNumber", 1);
				projection.addProperty("contactDetails.branch", 1);
				projection.addProperty("personalInfo", 1);
				projection.addProperty("cunaInsurance", 1);
				projection.addProperty("_id", 0);
				appData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter, projection);
				map$Data.addProperty("FullName",
						appData.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
								+ appData.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
				map$Data.addProperty("applicationId", appId);
				map$Data.addProperty("tmp$name", sTmplName);
				map$Data.addProperty("Application ID", appId);
				map$Data.addProperty("Applicant's Name",
						appData.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
								+ appData.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
				map$Data.addProperty("Branch code",
						appData.get("contactDetails").getAsJsonObject().get("branch").getAsString());

				// #SRP00021 Starts
				try {
					if (I$utils.$iStrFuzzyMatch(TmplName, "TMPL#TT#VERIFICATION#PENDING")) {
						projection = new JsonObject();
						filter = new JsonObject();
						filter.addProperty("datasetId", "Dataset_5668");
						projection.addProperty("userDetails", 1);
						appData = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
						JsonArray userDet = appData.get("userDetails").getAsJsonArray();
						for (int i = 0; i < userDet.size(); i++) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							sKeyE = sKeyE.concat(Email);
							sKeyM = sKeyM.concat(SMS);
							if (i < userDet.size() - 1) {
								sKeyE = sKeyE.concat(",");
								sKeyM = sKeyM.concat(",");
							}
						}
					} else {
						sKeyE = appData.get("contactDetails").getAsJsonObject().get("emailId").getAsString();
						sKeyM = appData.get("contactDetails").getAsJsonObject().get("mobileISD").getAsString()
								+ appData.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString();
					}
				} catch (Exception e) {
				} // #SRP00021 Ends
			} // #PKY00016 ends

			try {
				JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
						"{ Template_ID: \"" + argJson.get("tmplName").getAsString() + "\" }");
				if (i$emailtmpl.has("getKeysFrmBody")) {
//					JsonArray Keys = i$emailtmpl.get("getKeysFrmBody").getAsJsonArray();
//					for (int k = 0; k < Keys.size(); k++) {
//						String key = Keys.get(k).getAsString();
//						map$Data.addProperty(key, i$ResM.getStrfromObj(i$body, key));
//					}
				}
			} catch (Exception e) {
				// Eat up
			}
			argJson.add("map$Data", map$Data);

//			String sKeyE =  i$ResM.getBodyElementS(isonMsg, "KeyE");
//			String sKeyM =  i$ResM.getBodyElementS(isonMsg, "KeyM");

			argJson.addProperty("key$Type", "notification");
			argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
			argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + sKeyM + "\"}"));

//			JsonObject i$resBody = new JsonObject();
//			i$resBody = i$body;
//			i$resBody.addProperty("Notification", "Verification Link Sent Successfully");

			if (!I$utils.$iStrBlank(sKeyE) || !I$utils.$iStrBlank(sKeyM)) {
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				JsonObject i$resM = i$SmsSrvc.SendSMSWOThread(argJson);
//				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resE), i$ResM.I_SUCC)
//						|| I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resM), i$ResM.I_SUCC)) {
//					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
//					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION SUBMITTED SUCCESSFULLY");
//				} else {
//					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//							"Error in Sending Verification Link or Notification Service is disabled");
//				}
			} else {
//				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Error in Sending Verification Link or Notification Service is disabled");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
//			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending OTP or OTP Service is disabled","Contact Adminstrator");

		}
	};
	// #YPR00071 Ends

	// #YPR00075 Starts
	public JsonObject inCompleteAppRem(JsonObject argJson, JsonObject isonMsg, String TmplName) {
		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
		int inCompleteAppReminderInDays = cParam.get("inCompleteAppReminderInDays").getAsInt();
		int terminateApplnInDays = cParam.get("terminateApplnInDays").getAsInt();
		Gson gson = new GsonBuilder().serializeNulls().create();
		try {
			JsonObject Qfilter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonArray dateCond = new JsonArray();
			for (int i = inCompleteAppReminderInDays; i < terminateApplnInDays
					|| i == inCompleteAppReminderInDays; i = i + inCompleteAppReminderInDays) {
				try {
					JsonObject runningObj = new JsonObject();
					Date grtrDate = I$utils.changeDate(i, "SUB", "D");
					Date lsrDate = I$utils.changeDate(i - 1, "SUB", "D");
					String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
					JsonObject temp = new JsonObject();
					temp.add("$gte", iso$date);
					runningObj.add("createdAt", temp);
					iso$date = Ioutils.dateFromatter(lsrDateS);
					temp.add("$lt", iso$date);
					runningObj.add("createdAt", temp);
					dateCond.add(runningObj);
				} catch (Exception e) {
				}
			}
			Qfilter.add("$or", dateCond);
			Qfilter.addProperty("isCurrVer", "Y");
			Qfilter.addProperty("DcStatus", "In-Complete");
			projection.addProperty("applicationId", 1);
			projection.addProperty("createdAt", 1);
			projection.addProperty("_id", 0);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_C_B2U_CIF_APPLICATION", Qfilter, projection);
			isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation", "TECU_INCAPP_REM");
			isonMsg.getAsJsonObject("i-body").add("inCompApplnsNotified", i$Body);
			isonMsg.getAsJsonObject("i-body").addProperty("filterUsed", gson.toJson(Qfilter).replace("$", "#"));
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject app$Json = i$Body.get(i).getAsJsonObject();
					sendReminders(app$Json, isonMsg, TmplName);
				} catch (Exception e) {
				}
			}
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "TECU_INCAPP_REM Notification Successfully Sent");
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage() + "Error in Sending TECU_INCAPP_REM Notification");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending TECU_INCAPP_REM Notification");
		}
	}
	// #YPR00075 Ends

	// #YPR00077 Starts
	public JsonObject intialDepositRem(JsonObject argJson, JsonObject isonMsg, String TmplName) {
		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
		int intialDepositReminderInDays = cParam.get("intialDepositReminderInDays").getAsInt();
		try {
			JsonObject Qfilter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonParser parser = new JsonParser();
			Gson gson = new GsonBuilder().serializeNulls().create();
			Date grtrDate = I$utils.changeDate(intialDepositReminderInDays, "SUB", "D");
			Date lsrDate = I$utils.changeDate(intialDepositReminderInDays - 1, "SUB", "D");
			String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
			JsonObject temp = new JsonObject();
			temp.add("$gte", iso$date);
			Qfilter.add("ModifiedAt", temp);
			iso$date = Ioutils.dateFromatter(lsrDateS);
			temp.add("$lt", iso$date);
			Qfilter.add("ModifiedAt", temp);
			Qfilter.addProperty("CurrentStageName", "INITIAL DEPOSIT APPLICATION");
			Qfilter.addProperty("paymentStatus", "Payment Due");
			Qfilter.addProperty("isCurrVer", "Y");
			projection.addProperty("applicationId", 1);
			projection.addProperty("ModifiedAt", 1);
			projection.addProperty("_id", 0);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_IBM_PROCESS", Qfilter, projection);
			isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation", "TECU_INITDPT_PENDING");
			isonMsg.getAsJsonObject("i-body").add("depositPendingAppsNotified", i$Body);
			isonMsg.getAsJsonObject("i-body").addProperty("filterUsed", gson.toJson(Qfilter).replace("$", "#"));
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject app$Json = i$Body.get(i).getAsJsonObject();
					sendReminders(app$Json, isonMsg, "");
				} catch (Exception e) {
				}
			}
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "TECU_INCAPP_REM Notification Successfully Sent");
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage() + "Error in Sending TECU_INCAPP_REM Notification");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending TECU_INCAPP_REM Notification");
		}
	}
	// #YPR00077 Ends

	// #YPR00076 Starts
	public JsonObject sendReminders(JsonObject app$Json, JsonObject isonMsg, String TmplName) {
		JsonObject i$resE = new JsonObject();
		JsonObject i$resM = new JsonObject();
		try {

			String sTmplName = null;
			String sMsgAnnote = null;
//			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject map$Data = new JsonObject();
			String sKeyE = null;
			String sKeyM = null;
			System.getProperty("line.separator");
			String appId = app$Json.get("applicationId").getAsString();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}");
			int totalStgNo = cParam.get("totalOnBoardingStages").getAsInt();
			int currStgNo = 0;
			try {
			currStgNo = app$Json.get("currStgNo").getAsInt() + 1;
			}catch(Exception e) {
				e.printStackTrace();
			}
			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
						"{\"MSG_ANNOTATION\":\"" + i$ResM.getBody(isonMsg).get("Msg_Annotation").getAsString() + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = TmplName;
			// PKY00051 starts
			if (app$Json.has("WORKFLOWID")&& I$utils.$iStrFuzzyMatch(app$Json.get("WORKFLOWID").getAsString(), "IMPACTO_LEAD_WRKFLOW")) {
				sKeyE = app$Json.get("emailId").getAsString();
				sKeyM = app$Json.get("mobNo").getAsString();
				map$Data.addProperty("tmp$name", sTmplName);
				map$Data.addProperty("cif", app$Json.get("cif").getAsString());
				argJson.add("map$Data", map$Data);
				// PKY00051 ends
				// PKY00066 starts
			} else if (app$Json.has("WORKFLOWID") && I$utils.$iStrFuzzyMatch(app$Json.get("WORKFLOWID").getAsString(),
					"IMPACTO_TATIL_INSURANCE_WORKFLOW")) {
				sKeyE = app$Json.get("emailId").getAsString();
				sKeyM = app$Json.get("mobNo").getAsString();
				map$Data.addProperty("tmp$name", sTmplName);
				map$Data.addProperty("MemberName", app$Json.get("MemberName").getAsString());
				argJson.add("map$Data", map$Data);
				// PKY00066 ends
			}else if (app$Json.has("WORKFLOWID") && I$utils.$iStrFuzzyMatch(app$Json.get("WORKFLOWID").getAsString(),"IMPACTO_CIF_WFLW_NEW")) {
				try {
					sKeyE = app$Json.get("emailId").getAsString();
					sKeyM = app$Json.get("mobNo").getAsString();
					map$Data.addProperty("tmp$name", sTmplName);
					map$Data.addProperty("currStgNo",currStgNo );
					map$Data.addProperty("totalStgNo",totalStgNo );
					map$Data.addProperty("applicationId",appId );
					argJson.add("map$Data", map$Data);
				}catch(Exception e) {
				}
				// PKY00066 ends
			} 
			else {
				argJson.addProperty("applicationId", appId);
				argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
				argJson.addProperty("tmplName", sTmplName);
//				db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);

				filter.addProperty("applicationId", appId);
				projection.addProperty("contactDetails", 1);
				projection.addProperty("personalInfo", 1);
				projection.addProperty("_id", 0);

				JsonObject appData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter, projection);

				map$Data.addProperty("FullName",
						appData.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
								+ appData.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
				map$Data.addProperty("applicationId", appId);
				map$Data.addProperty("tmp$name", sTmplName);
				try {
					JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
							"{ Template_ID: \"" + argJson.get("tmplName").getAsString() + "\" }");
					if (i$emailtmpl.has("getKeysFrmBody")) {
//						JsonArray Keys = i$emailtmpl.get("getKeysFrmBody").getAsJsonArray();
//						for (int k = 0; k < Keys.size(); k++) {
//							String key = Keys.get(k).getAsString();
//							map$Data.addProperty(key, i$ResM.getStrfromObj(i$body, key));
//						}
					}
				} catch (Exception e) {
					// Eat up
				}
				argJson.add("map$Data", map$Data);

//				String sKeyE =  i$ResM.getBodyElementS(isonMsg, "KeyE");
				sKeyE = appData.get("contactDetails").getAsJsonObject().get("emailId").getAsString();
				sKeyM = appData.get("contactDetails").getAsJsonObject().get("mobileISD").getAsString()
						+ appData.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString();
//				String sKeyM =  i$ResM.getBodyElementS(isonMsg, "KeyM");
			}
			argJson.addProperty("key$Type", "notification");
			argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
			argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + sKeyM + "\"}"));

//			JsonObject i$resBody = new JsonObject();
//			i$resBody = i$body;
//			i$resBody.addProperty("Notification", "Intitial Depsoit Pending Reminder sent Successfully");

			if (!I$utils.$iStrBlank(sKeyE) || !I$utils.$iStrBlank(sKeyM)) {
				i$resE = i$Email.SendEmailWOThread(argJson);
				i$resM = i$SmsSrvc.SendSMSWOThread(argJson);
//				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resE), i$ResM.I_SUCC)
//						|| I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resM), i$ResM.I_SUCC)) {
//					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$ResM.getiStat(i$resE));
////					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "NOTIFICATION TRIGGERED SUCCESSFULLY");
//				} else {
////					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Error in Sending Notification or Notification Service is disabled");
//				}
			} else {
//				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Error in Sending Notification or Notification Service is disabled");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());

		}
		return i$resE;
	}
	// #YPR00076 Ends

	// #YPR00064 Starts
	public JsonObject sendFpassOTP(JsonObject argJson, JsonObject isonMsg) {
		;
		IEmailService i$Email = new IEmailService();
		JsonObject i$body = isonMsg.getAsJsonObject("i-body");
		isonMsg.add("i-header", isonMsg.getAsJsonObject("i-header"));

		try {
			String username = i$body.get("username").getAsString();
			username = i$impactoUtil.decryptPkey(username);
			JsonObject i$resE = new JsonObject();
			JsonObject i$resM = new JsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject to$emailIds = new JsonObject();
			JsonObject $mobNum = new JsonObject();
			JsonObject $whatsappNumbers = new JsonObject();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();
			IResManipulator.iloggedUser.set(username);
			JsonObject Jfilter = new JsonObject();
			Jfilter.addProperty("userId", username);
			JsonObject icorMUserPrf = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", Jfilter.toString());

			// Generate the sec key and otp and store in otp validator
			argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));
			argJson.addProperty("iotp", Integer.toString(imp$utils.generateRandom(10005, 99999)));
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("otp$verified", false);
			argJson.addProperty("tmplName", "TMPL#PASOTP");
			db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendMailOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("EmpMail")) {
					to$emailIds.addProperty("toemailid1", icorMUserPrf.get("EmpMail").getAsString());
					argJson.add("toemailIds", to$emailIds);
					map$Data.addProperty("user", icorMUserPrf.get("name").getAsString());
					map$Data.addProperty("tmp$name", "TMPL#PASOTP");
					map$Data.addProperty("otp", argJson.get("iotp").getAsString());
					argJson.add("map$Data", map$Data);
//					i$Email.sendEmail(argJson);
					i$resE = i$Email.SendEmailWOThread(argJson);

				}
			}

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendSmsOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("MobNum") && icorMUserPrf.has("IsdMobNum")) {
					$mobNum.addProperty("Mob_Number1", icorMUserPrf.get("IsdMobNum").getAsString()
							.concat(icorMUserPrf.get("MobNum").getAsString()));
				}
				argJson.add("mobile$numbers", $mobNum);
				map$Data.addProperty("user", icorMUserPrf.get("name").getAsString());
				map$Data.addProperty("tmp$name", "TMPL#PASOTP");
				map$Data.addProperty("otp", argJson.get("iotp").getAsString());
				argJson.add("map$Data", map$Data);
//				I$ISmsService.sendSMS(argJson);
				i$resM = i$SmsSrvc.SendSMSWOThread(argJson);

			}
			JsonObject i$resBody = new JsonObject();
			i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resE), i$ResM.I_SUCC)
					|| I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$resM), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP Service Triggered Sucessfully");
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Error in Sending OTP or OTP Service is disabled");
			}

//			if (I$utils.$iStrFuzzyMatch(commMode.get("iWhatsUpOtp").getAsString(), "Y")) {
//				if (icorMUserPrf.has("WhtsAppNum") && icorMUserPrf.has("IsdWhtsAppNum")) {
//					$whatsappNumbers.addProperty("Whatsapp_Numbers1", icorMUserPrf.get("IsdWhtsAppNum").getAsString()
//							.concat(icorMUserPrf.get("WhtsAppNum").getAsString()));
//				} else {
//					if (icorMUserPrf.has("MobNum") && icorMUserPrf.has("IsdMobNum")) {
//						$whatsappNumbers.addProperty("Whatsapp_Numbers1", icorMUserPrf.get("IsdMobNum").getAsString()
//								.concat(icorMUserPrf.get("MobNum").getAsString()));
//					}
//				}
//				argJson.add("mobile$numbers", $whatsappNumbers);
//				map$Data.addProperty("user", icorMUserPrf.get("name").getAsString());
//				map$Data.addProperty("tmp$name", "TMPL#PASCHNG");
//				argJson.add("map$Data", map$Data);
//				I$Whatsapp.sendWhatsup(argJson);
//
//			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending OTP or OTP Service is disabled", "Contact Adminstrator");

		}

	}
	// #YPR00064 Ends

	private JsonObject getWhatsappNumber(String Mode, String Key) {
		try {

			if (I$utils.$iStrFuzzyMatch(Mode.substring(1, 3), "ID"))
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "WA\", Key_Owner: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");
			else if (I$utils.$iStrFuzzyMatch(Mode.substring(1, 3), "TK"))
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "WA\", Key_Token: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");
			else
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "WA\", Key: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return null;
		}
	};

	private JsonObject getMobNumber(String Mode, String Key) {
		try {
			// Logic is slightly different here to pick the Primary MobNo
			if (I$utils.$iStrFuzzyMatch(Mode.substring(1, 3), "ID"))
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "MB\", Key_Owner: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");
			else if (I$utils.$iStrFuzzyMatch(Mode.substring(1, 3), "TK"))
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "MB\", Key_Token: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");
			else
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "MB\", Key: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return null;
		}
	};

	@SuppressWarnings("null")
	public JsonObject sendOTP(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonObject iconfig = isonMsg.getAsJsonObject("i-config"); // #MVT00130 changes begins
			String scrId = iconfig.get("SrcID").getAsString();

			// JsonObject sParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{ system: \"" +
			// "SYSTEM_PARAMS" + "\" }");
			argJson.addProperty("Key", argJson.get("Key").getAsString()); // Key have to be Encrypted always
			JsonObject i$Param = null;
			JsonObject i$Resp = null;
			String sEMsg = "";
			String sOptMaint = "iOtpCommMode_" + i$ResM.getClientApp(isonMsg);
			// #NYE00003 Begins
			String sTmplName = null;
			String sMsgAnnote = null;
			String imbAccess = null;
			JsonObject jBdy = new JsonObject();
			String eol = System.getProperty("line.separator");
			String sMode = argJson.get("Mode").getAsString();
			Boolean registered = false;
			// Boolean digiCheck = false;
			// Boolean cifdigiCheck = false;
			try {
				registered = argJson.get("reg").getAsBoolean();
			} catch (Exception e) {
			}
			// Check if Record Exists
			// #BVB00093 Starts
			if (I$utils.$iStrFuzzyMatch(sMode, "UID")) {
				if (!db$Ctrl.isUserValid(argJson.get("Key").getAsString())) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid or Unknown User ID");
				}
			}
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}"); // PKY00047 changes
			// TKS00001 starts
			try {
				if (I$utils.$iStrFuzzyMatch(sMode, "CID") || I$utils.$iStrFuzzyMatch(sMode, "CIF")
						|| I$utils.$iStrFuzzyMatch(sMode, "CDB") || I$utils.$iStrFuzzyMatch(sMode, "FCIP")
						|| I$utils.$iStrFuzzyMatch(sMode, "FIP") || I$utils.$iStrFuzzyMatch(sMode, "TATIL")
						|| I$utils.$iStrFuzzyMatch(sMode, "TATIL_INC")) {
					JsonObject info = new JsonObject();
					JsonObject fltr = new JsonObject();
					JsonObject digifltr = new JsonObject();
					fltr.addProperty("Key_Mode", "CEM");
					fltr.addProperty("Key_Owner", argJson.get("Key").getAsString());
					info = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", fltr);
					JsonObject fltr1 = new JsonObject();
					fltr1.addProperty("CustomerId", argJson.get("Key").getAsString());
					JsonObject cifInfo = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr1);
					imbAccess = cifInfo.get("Imbaccess").getAsString();
					// #MVT00126 begins
					if (I$utils.$iStrFuzzyMatch(sMode, "CDB")) {
						JsonArray funcDetails = new JsonArray();
						JsonObject funObject = new JsonObject();

						funObject.addProperty("funcName", "GET_CIF_IMB_ACCESS");
						funObject.addProperty("p_member", isonMsg.getAsJsonObject("i-body").get("Key").getAsString());
						funcDetails.add(funObject);
						isonMsg.getAsJsonObject("i-body").add("funcDetails", funcDetails);
						JsonObject functionData = i$Func.exeCallOrcl(isonMsg);
						JsonObject funcRes = functionData.getAsJsonObject("i-body").getAsJsonArray("funcRes").get(0)
								.getAsJsonObject();
						imbAccess = funcRes.getAsJsonObject("GET_CIF_IMB_ACCESS").get("l_data").getAsString();
					} // #MVT00126 ends
						// SKP00004 Starts #MVT00130 changes
					if (!I$utils.$iStrFuzzyMatch(scrId, "TecuDigiApp")
							|| (!I$utils.$iStrFuzzyMatch(imbAccess, "N") && !I$utils.$iStrFuzzyMatch(imbAccess, ""))) // #SRM00036
																														// changes
					{
						try {
							digifltr.addProperty("key", argJson.get("Key").getAsString());
							JsonObject digiInfo = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", digifltr);
							String SrvOpr = i$ResM.getSrvcopr(isonMsg);
//							try {	//#PAV00001 changes starts
//								digiCheck = info.get("digiCheck").getAsBoolean();
//							} catch (Exception e) {
//							}
//							if (I$utils.$iStrFuzzyMatch(SrvOpr, "cifCheck")) {
//								if (digiInfo == null && !digiCheck) {
//									return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//											"It seems you are not enrolled to use this services.Please contact Bank support Administrator for enrollment process");
//								} else if (digiInfo == null && digiCheck) {
//									return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//											"It seems you are not enrolled to use this services.Please contact Bank support Administrator for back office enrollment.");
//								}
//							}
						} catch (Exception e) {
						}
						// SKP00004 Ends
						if (I$utils.$iStrBlank(info.get("Key").getAsString())
								|| (!info.get("Key").getAsString().contains("@"))) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"We are unable to process your transaction, "
											+ "please contact any branch and provide an updated email address.");
						}
//					if (cifInfo.has("digiCheck")) {
//						try {
//							cifdigiCheck = cifInfo.get("digiCheck").getAsBoolean();
//						} catch (Exception e) {
//						}
//						if (!cifdigiCheck) {
//							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//									"Please enroll for Mobile Banking or contact TECU support for enrollment."); // SKP00003
//																													// Changes
//						}
//					} //#PAV00001 changes ends
					} else {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Please Enroll in Internet & Mobile Banking to continue."); // SRM000037 Changes
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (I$utils.$iStrFuzzyMatch(sMode, "CID") || I$utils.$iStrFuzzyMatch(sMode, "CIF")
						|| I$utils.$iStrFuzzyMatch(sMode, "CDB") || I$utils.$iStrFuzzyMatch(sMode, "FCIP")
						|| I$utils.$iStrFuzzyMatch(sMode, "FIP") || I$utils.$iStrFuzzyMatch(sMode, "TATIL")
						|| I$utils.$iStrFuzzyMatch(sMode, "TATIL_INC")) {
					JsonObject info = new JsonObject();
					JsonObject fltr = new JsonObject();
					fltr.addProperty("Key_Mode", "CMB");
					fltr.addProperty("Key_Owner", argJson.get("Key").getAsString());
					info = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", fltr);
					String mobNum = info.get("Key").getAsString();
					if (I$utils.$iStrBlank(mobNum) || mobNum.length() < 7) {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"We are unable to process your transaction, "
										+ "please contact any branch and provide an updated mobile number.");
					}
				}
			} catch (Exception e) {
			}
			// TKS00001 ends
			// #BVB00093 Ends
			// #NYE00004 Begins
			// Send otp with Date of Birth
			if (I$utils.$iStrFuzzyMatch(sMode, "CDB")) {
				try {
					String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
					if (I$utils.$iStrBlank(imecd)) {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid IMEI");
					}
					JsonObject i$CustDet = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",
							"{'CustomerId':'" + argJson.get("Key").getAsString() + "','CustomerDobDate':'"
									+ argJson.get("dob").getAsString() + "'}");
					// #MVT00105 changes begins
//					if (!I$utils.$iStrFuzzyMatch(i$CustDet.get("CustomerCategory").getAsString(), "50")) {
//						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//								"The system will allow only to login to members with customer category as 50. Kindly contact TECU Credit Union for further details.");
//					} // #MVT00105 changes ends
					if (!I$utils.$isNull(i$CustDet)) {
						JsonObject digiUser = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS",
								"{'key':'" + argJson.get("Key").getAsString() + "'}");
						if (I$utils.$isNull(digiUser)) {
							sMode = "CID";
							argJson.addProperty("Mode", "CID");
						} else {
							String SrvOpr = i$ResM.getSrvcopr(isonMsg);
							if (!I$utils.$iStrFuzzyMatch(SrvOpr, "cifCheck")) {
								if (registered) {
									sMode = "CID";
									argJson.addProperty("Mode", "CID");
								} else
									return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
											"Member is already registered");
							} else {
								argJson.addProperty("Mode", "CID");
							}
						}
					} else
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Invalid or Unknown Member or Customer ID");
				} catch (Exception e) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
							"Failed to send OTP with " + e.getMessage());
				}
				;
				// Send otp with IMEI
			} else if (I$utils.$iStrFuzzyMatch(sMode, "FCIP") || I$utils.$iStrFuzzyMatch(sMode, "FIP")
					|| I$utils.$iStrFuzzyMatch(sMode, "TATIL") || I$utils.$iStrFuzzyMatch(sMode, "TATIL_INC")
					|| I$utils.$iStrFuzzyMatch(sMode, "LOAN_INC")) { // #PKY00035 starts
				try {
					JsonObject i$CustDet = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",
							"{'CustomerId':'" + argJson.get("Key").getAsString() + "'}");
					if (!I$utils.$isNull(i$CustDet)) {
						String customerDob = i$CustDet.get("CustomerDobDate").getAsString();
						Date date = new Date();
						String currDate = I$utils.changeDateFormat(date, "yyyy-MM-dd");
						int ageInDays = I$utils.getDateDifference(customerDob, currDate, "yyy-MM-dd");
						double age = (double) ageInDays / 365;
						if (I$utils.$iStrFuzzyMatch(sMode, "FCIP")) {
							if (age >= 18 && age <= 59) { // #SRP00040 Changes //#MVT00025 Changes
								sMode = "CID";
								argJson.addProperty("Mode", "CID");
							} else {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"Member is not eligible for this process");
							}
						} else if (I$utils.$iStrFuzzyMatch(sMode, "FIP")) {
							if (age > 18 && age < 76) {
								sMode = "CID";
								argJson.addProperty("Mode", "CID");
							} else {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"Member is not eligible for this process");
							}
						} else if (I$utils.$iStrFuzzyMatch(sMode, "TATIL_INC")) { // PKY00047 starts
							try {
								JsonObject tatilDetails = db$Ctrl.db$GetRow("ICOR_C_B2U_TATIL_APPLICATION",
										"{'custInfo.CustomerId':'" + argJson.get("Key").getAsString()
												+ "','isCurrVer':'Y','DcStatus':'In-Complete'}");
								if (cParam.get("tatilIncApplnChecker").getAsInt() > I$utils
										.getDateDifference(
												I$utils.changeDateFormatS(tatilDetails.get("createdAt").getAsString(),
														"MMM dd, yyyy, h:mm:ss a", "yyyy-MM-dd"),
												currDate, "yyyy-MM-dd")) {
									sMode = "CID";
									argJson.addProperty("Mode", "CID");
								} else {
									return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
											"No incomplete records found for this Customer ID");
								}
							} catch (Exception e) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"No incomplete records found for this Customer ID");
							} // PKY00047 ends
						} else if (I$utils.$iStrFuzzyMatch(sMode, "LOAN_INC")) {// #TKS00004 starts
							try {
								JsonObject loanDetails = db$Ctrl.db$GetRow("ICOR_C_LD_LEAD_APPLICATIONS",
										"{'cif':'" + argJson.get("Key").getAsString()
												+ "','isCurrVer':'Y','DcStatus':'In-Complete'}");
								if (!I$utils.$isNull(loanDetails)) {
									sMode = "CID";
									argJson.addProperty("Mode", "CID");
								} else {
									return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
											"No incomplete records found for this Customer ID");
								}
							} catch (Exception e) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"No incomplete records found for this Customer ID");
							} // #TKS00004 ends
						} else if (I$utils.$iStrFuzzyMatch(sMode, "TATIL")) {
							try {
								if (age >= 18 && age <= 60) {// #MVT00034 Changes
									sMode = "CID";
									argJson.addProperty("Mode", "CID");
								} else {
									return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
											"Member is not eligible for this process");
								}
							} catch (Exception e) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"Member is not eligible for this process");
							}

						}
					} else {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Invalid or Unknown Member or Customer ID");
					}
				} catch (Exception e) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Failed to send OTP with " + e.getMessage()); // #PKY00035 ends
				}
			} else if (I$utils.$iStrFuzzyMatch(sMode, "CIM")) {
				try {
					JsonObject userRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS",
							"{'key':'" + argJson.get("Key").getAsString() + "'}");
					if (!I$utils.$isNull(userRec)) {
						if (I$utils.$iStrFuzzyMatch(userRec.get("imei").getAsString(),
								i$ResM.getConfigElementS(isonMsg, "imecd"))) {
							sMode = "CID";
							argJson.addProperty("Mode", "CID");
						} else {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"Member is registered with some other device. Please Reregister with new device");
						}
					} else
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Invalid or Unknown Member or Customer ID");
				} catch (Exception e) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
							"Failed to send OTP with " + e.getMessage());
				}
				;
			} else if (db$Ctrl.db$GetRowCnt("ICOR_M_ECOMM_REPO",
					"{ Key_Mode: \"" + sMode + "\", Key_Owner: \"" + argJson.get("Key").getAsString() + "\"  }") < 1) {

				if (I$utils.$iStrFuzzyMatch(sMode.substring(0, 1), "U"))
					sEMsg = "Invalid or Unknown User ID";
				else if (I$utils.$iStrFuzzyMatch(sMode.substring(0, 1), "C"))
					sEMsg = "Invalid or Unknown Member or Customer ID";
				else if (I$utils.$iStrFuzzyMatch(sMode.substring(0, 1), "T"))
					sEMsg = "Invalid or Unknown Token";
				else
					sEMsg = "Invalid or Unknown Access ID";
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, sEMsg);
			}
			// #NYE00004 Ends

			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				sMsgAnnote = i$ResM.getBodyElementS(isonMsg, "Msg_Annotation");
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP", "{\"MSG_ANNOTATION\":\"" + sMsgAnnote + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#OTP";

			try {
				i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"iOtpCommMode\"=1}");
			} catch (Exception ex) {
				i$Param = null;
			}

			JsonObject i$SrcParam = null;
			try {
				i$SrcParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"" + sOptMaint + "\":1}");
			} catch (Exception E) {
				i$SrcParam = null;
			}
			;

			// Generate the sec key and otp and store in otp validator
			argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));
			// argJson.addProperty("iotp", imp$utils.generateRandom(10005, 99999));
			argJson.addProperty("iotp", Integer.toString(imp$utils.generateRandom(10005, 99999)));
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("otp$verified", false);
			argJson.addProperty("tmplName", sTmplName);
			db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);
			// #NYE00003 Ends

			JsonObject email$cnfdb = new JsonObject(); // #NYE00003 Adds

			if (i$Param != null || argJson.has("iOtpCommMode") || i$SrcParam != null) {

				// #NYE00003 Changes Begin - Revamped the Logic and Removed the old Code .
				if (argJson.has("iOtpCommMode")) {
					// Overriding the OTP maintenance
					email$cnfdb = argJson.get("iOtpCommMode").getAsJsonObject();
				} else if (i$SrcParam != null && i$SrcParam.has(sOptMaint)) {
					email$cnfdb = i$SrcParam.get(sOptMaint).getAsJsonObject();
				} else {
					email$cnfdb = i$Param.get("iOtpCommMode").getAsJsonObject();
				}
				int iSend = 0;
				int iFailSend = 0;
				String sMedia = "";
				String sFailedText = "";
				if (I$utils.$strValNullIf(email$cnfdb.get("iSendSmsOtp").getAsString(), "").equals("Y")) {
					i$Resp = sendSMS(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp)) {
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
						iFailSend++;
					}
					iSend++;
					sMedia = sMedia + "SMS:";
				}
				;

				if (I$utils.$strValNullIf(email$cnfdb.get("iSendMailOtp").getAsString(), "").equals("Y")) {
					i$Resp = sendEmail(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp)) {
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
						iFailSend++;
					}
					iSend++;
					sMedia = sMedia + "EMAIL:";
				}
				;
				if (I$utils.$strValNullIf(email$cnfdb.get("iWhatsUpOtp").getAsString(), "").equals("Y")) {
					i$Resp = sendWhatsup(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp))
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
					iSend++;
					sMedia = sMedia + "WHATSAPP:";
				}
				// SRI00012 starts
				// JsonObject i$CustDet = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",
				// "{'CustomerId':'" + argJson.get("Key").getAsString()+"'}");
				String mobNumber = null;
				String EmailAddres = null;
				try {
					// JsonObject temp = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",
					// "{'CustomerMobileId':'" + argJson.getAsJsonObject("mobile$numbers"));
					JsonObject fltr1 = new JsonObject();
					fltr1.addProperty("CustomerId", argJson.get("Key").getAsString());
					JsonObject temp = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr1);
					mobNumber = temp.get("CustomerMobileId").getAsString();
					EmailAddres = temp.get("CustomerEmailId").getAsString();
					int numAsterisks = Math.min(mobNumber.length() - 4, mobNumber.length());
					mobNumber = "*".repeat(numAsterisks) + mobNumber.substring(mobNumber.length() - 4);
					// String EmailAddress =
					// temp.getAsJsonObject("toemailIds").get("toemailid1").getAsJsonArray().get(0).getAsString();
					String[] parts = EmailAddres.split("@");
					if (parts.length == 2) {
						String username = parts[0];
						String domain = parts[1];
						if (username.length() > 3) {
							int numAsterisks1 = username.length() - 3;
							String maskedUsername = username.substring(0, 3) + "*".repeat(numAsterisks1);
							EmailAddres = maskedUsername + "@" + domain;
						} else {
							char[] charArr = username.toCharArray();
							StringBuilder maskedData = new StringBuilder();
							int i = 0;
							while (charArr.length > 1 && i < charArr.length - 1) {
								maskedData = maskedData.append(charArr[i]);
								i++;
							}
							maskedData = maskedData.append("*");
							String maskedUsername = maskedData.toString();
							EmailAddres = maskedUsername + "@" + domain;
						}
						mobNumber = mobNumber + "/" + EmailAddres;
//								temp.getAsJsonArray("SMS").get(0);
					}
				} catch (Exception e) {
					e.getMessage();
				}
				// SRI00012 ends
				if (iSend < 1) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Otp Service is Disabled",
							"Contact Adminstrator");
				} else {
					if (I$utils.$iStrBlank(sFailedText)) {
						jBdy.addProperty("iSecKey", argJson.get("iSecKey").getAsString());
						jBdy.addProperty("mobEmailKey", mobNumber); // SRI00012 changes
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBdy);
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
								"OTP Triggered Successfully Via :" + sMedia);
					} else {
						if (iSend - iFailSend == 0) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"OTP Triggered Failed with " + eol + sFailedText);

						} else {
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
									argJson.get("iSecKey").getAsString());
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_WRN,
									"OTP Triggered Successfully  Via :" + sMedia + " with warnings " + eol
											+ sFailedText);
						}
					}
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Otp Service is Disabled",
						"Contact Adminstrator");
			}
			// #NYE00003 Changes End
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending OTP or OTP Service is disabled", "Contact Adminstrator");

		}
	};

	private JsonObject sendSMS(JsonObject argJson, JsonObject isonMsg) {
		try {

			JsonObject Mob$No = getMobNumber(argJson.get("Mode").getAsString(), argJson.get("Key").getAsString());

			if (Mob$No == null) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Unable to Retrive Number");
			}
			;
			argJson.addProperty("key$Type", "otp");
			argJson.add("mobile$numbers",
					i$ResM.getJsonObj("{\"Mob_Number1\":\"" + Mob$No.get("Key").getAsString() + "\"}")); // #NYE00003
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("otp", argJson.get("iotp").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
			argJson.add("map$Data", map$Data);
			JsonObject i$resBody = new JsonObject();

			i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

			// Forward to Otp Service
			// JsonObject i$res = i$SmsSrvc.SendSMSWOThread(argJson);
			// isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			// isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
			// i$resBody);
			// return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS OTP Sent
			// Successfully ");

			JsonObject i$res = i$SmsSrvc.SendSMSWOThread(argJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS OTP Sent Successfully ");
			} else {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			}
			return isonMsg;

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending SMS ");
		}

	};

	private JsonObject sendStatusEmail(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonObject fltr = new JsonObject();
			String cif = "";
			if (argJson.has("cif"))
				cif = argJson.get("cif").getAsString();
			String accountNo = argJson.get("accountNo").getAsString();
			String branch = argJson.get("branch").getAsString();
			if (branch.equals(""))
				branch = accountNo.substring(0, 3);
			if (argJson.has("cif"))
				fltr.addProperty("CustomerId", cif);
			JsonObject custDetails = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
			String custEmailId = custDetails.get("CustomerEmailId").getAsString();
			Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
			Matcher mat = pattern.matcher(custEmailId);
			if (mat.matches()) {
				fltr.remove("CustomerId");
				fltr.addProperty("accountNo", accountNo);
				fltr.addProperty("branch", branch);
				JsonObject pdfDetails = db$Ctrl.db$GetRow("ICOR_C_FCUBS_STATEMENT", fltr);
				String pdfBase64 = pdfDetails.get("statementPdf").getAsString();
				JsonObject attachmentData = new JsonObject();
				attachmentData.addProperty("docType", "application/pdf");
				attachmentData.addProperty("fileName", "Status Report" + ".pdf");
				attachmentData.addProperty("template", pdfBase64);
				JsonObject map$Data = new JsonObject();
				JsonArray attachment = new JsonArray();
				map$Data.addProperty("tmp$name", "TMPL#TT#LNCA#FLEXCUBE#TRANSACTIONS#STATUS#REPORT#MAIL");
				map$Data.addProperty("cif", argJson.get("cif").getAsString());
				map$Data.addProperty("module", argJson.get("module").getAsString());
				map$Data.addProperty("branch", branch);
				map$Data.addProperty("accountNo", argJson.get("accountNo").getAsString());
				map$Data.addProperty("fromDate", argJson.get("fromDate").getAsString());
				map$Data.addProperty("toDate", argJson.get("toDate").getAsString());
				argJson.add("map$Data", map$Data);
				argJson.addProperty("key$Type", "notification");
				argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + custEmailId + "\"}"));
				attachment.add(attachmentData);
				argJson.add("attachment", attachment);
				if (!I$utils.$iStrBlank(custEmailId)) {
					JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
					JsonObject i$body = new JsonObject();
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Sent Successfully ");
				}
			}
		} catch (Exception e) {

		}
		return isonMsg;
	}

	private JsonObject sendEmail(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonObject email$Details = getEmailIds(argJson.get("Mode").getAsString(), argJson.get("Key").getAsString());
			if (email$Details == null) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Unable to Retrive Email ID");
			}
			;
			argJson.addProperty("key$Type", "otp");
			argJson.add("toemailIds",
					i$ResM.getJsonObj("{\"toemailid1\":\"" + email$Details.get("Key").getAsString() + "\"}")); // #NYE00003
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("user", email$Details.get("Name").getAsString());
			map$Data.addProperty("otp", argJson.get("iotp").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
			argJson.add("map$Data", map$Data);

			JsonObject i$resBody = new JsonObject();
			i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

			JsonObject i$res = i$Email.SendEmailWOThread(argJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email OTP Sent Successfully ");
			} else {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			}
			return isonMsg;

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Email ");
		}

	};

	// MAQ10101 starts
//	public JsonObject verifyOTP(JsonObject argJson, JsonObject isonMsg) {
//		try {
//
//			if ((argJson.has("otp"))
//					&& db$Ctrl.db$GetRowCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
//							+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }") > 0) { // #NYE00005
//																											// corrected
//																											// the
//																											// condition
//				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP VERIFIED SUCCESSFULY");
//			} else {
//				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "INVALID OTP");
//			}
//		} catch (Exception e) {
//			logger.debug(e.getLocalizedMessage());
//			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Verifying OTP ");
//		}
//	};

	public JsonObject verifyOTP(JsonObject argJson, JsonObject isonMsg) {
		try {
			Boolean otpBypass = false;
			JsonObject i$Param = null;
			try {
				i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"otpBypass\"=1}");
				otpBypass = i$Param.get("otpBypass").getAsBoolean();
			} catch (Exception ex) {
			}
			if (I$utils.$iStrFuzzyMatch(argJson.get("otp").getAsString(), "121212") && otpBypass == true) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP VERIFIED SUCCESSFULY");
			}
			if ((argJson.has("otp"))
					&& db$Ctrl.db$GetOtpCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
							+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }") > 0) { // #SKP0001
																											// corrected
																											// the
																											// condition
				db$Ctrl.db$Remove("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
						+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }");
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP VERIFIED SUCCESSFULY");
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "INVALID OTP");
			}
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Verifying OTP ");
		}
	};

	public boolean verify$OTP(JsonObject argJson) { // #NYE00003 Changes
		try {
			Boolean otpBypass = false;
			JsonObject i$Param = null;
			try {
				i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"otpBypass\"=1}");
				otpBypass = i$Param.get("otpBypass").getAsBoolean();
			} catch (Exception ex) {
			}
			if (I$utils.$iStrFuzzyMatch(argJson.get("otp").getAsString(), "121212") && otpBypass == true) {
				return true;
			}
			if ((argJson.has("otp"))
					&& db$Ctrl.db$GetOtpCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
							+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }") > 0) { // #SKP0001
																											// corrected
																											// the
																											// condition
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return false;
		}
	};

	public boolean verifyOTP(String iSecKey, String otp) {
		try {
			Boolean otpBypass = false;
			JsonObject i$Param = null;
			try {
				i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"otpBypass\"=1}");
				otpBypass = i$Param.get("otpBypass").getAsBoolean();
			} catch (Exception ex) {
			}
			if (I$utils.$iStrFuzzyMatch(otp, "121212") && otpBypass == true) {
				return true;
			}
			if (!I$utils.$iStrBlank(otp) && db$Ctrl.db$GetOtpCnt("ICOR_S_IOTP_VALIDATOR",
					"{ iotp: \"" + otp + "\" , iSecKey: \"" + iSecKey + "\" }") > 0) { // #MAQ00122 // corrected the
																						// condition
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return false;
		}
	};

//	public boolean verify$OTP(JsonObject argJson) { // #NYE00003 Changes
//		try {
//
//			if ((argJson.has("otp"))
//					&& db$Ctrl.db$GetRowCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
//							+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }") > 0) { // #NYE00005
//																											// corrected
//																											// the
//																											// condition
//				return true;
//			} else {
//				return false;
//			}
//		} catch (Exception e) {
//			logger.debug(e.getLocalizedMessage());
//			return false;
//		}
//	};

//	public boolean verifyOTP(String iSecKey, String otp) {
//		try {
//			if (!I$utils.$iStrBlank(otp)
//					&& db$Ctrl.db$GetRowCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + otp
//							+ "\" , iSecKey: \"" + iSecKey + "\" }") > 0) { // #NYE00005 // corrected the condition
//				return true; 
//			} else {
//				return false;
//			}
//		} catch (Exception e) {
//			logger.debug(e.getLocalizedMessage());
//			return false;
//		}
//	};
	// MAQ10101 ends

	private JsonObject sendWhatsup(JsonObject argJson, JsonObject isonMsg) {
		try {
			// Logic is slightly different here to pick the Primary WhatsappNo
			JsonObject Mob$No = getWhatsappNumber(argJson.get("Mode").getAsString(), argJson.get("Key").getAsString()); // #NYE00003

			argJson.add("mobile$numbers",
					i$ResM.getJsonObj("{\"Mob_Number1\":\"" + Mob$No.get("Key").getAsString() + "\"}")); // #NYE00003
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("otp", argJson.get("iotp").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
			argJson.add("map$Data", map$Data);
			// argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));

			JsonObject i$resBody = new JsonObject();
			i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

			// Forward to Otp Service
			IWhatsupService I$Whp = new IWhatsupService();
			I$Whp.sendWhatsup(argJson);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Whatsup OTP Sent Successfully ");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Whatsup ");
		}

	};

	private JsonObject getEmailIds(String Mode, String Key) {
		try {
			// Logic is slightly different here to pick the Primary ID
			if (I$utils.$iStrFuzzyMatch(Mode.substring(1, 3), "ID"))
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "EM\", Key_Owner: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");
			else if (I$utils.$iStrFuzzyMatch(Mode.substring(1, 3), "TK"))
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "EM\", Key_Token: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");
			else
				return db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
						"{ Key_Mode: \"" + Mode.substring(0, 1) + "EM\", Key: \"" + Key + "\"  }",
						"{\"Key\":1, \"Name\":1 }");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return null;
		}
	};

	// PKY00013 Starts
	public JsonObject sendOTPDataSet(JsonObject isonMsg) {
		try {

			String sTmplName = null;
			new JsonObject();
			System.getProperty("line.separator");
			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				// sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg);
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
						"{\"MSG_ANNOTATION\":\"" + i$ResM.getBodyElementS(isonMsg, "Msg_Annotation") + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#OTP";

			JsonObject filter = new JsonObject();
			JsonObject body$Details = isonMsg.get("i-body").getAsJsonObject();
			filter.addProperty("datasetId", body$Details.get("datasetId").getAsString());
			JsonObject datasetDetails = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter);
			String checkEmail = datasetDetails.get("sendEmail").getAsString();
			String checkSms = datasetDetails.get("sendSms").getAsString();
			JsonArray userDetails = datasetDetails.getAsJsonArray("userDetails");

			for (int i = 0; i < userDetails.size(); i++) {

				JsonObject userDetail = userDetails.get(i).getAsJsonObject();
				userDetail.addProperty("tmplName", sTmplName);

				JsonObject argJson = new JsonObject();
				JsonObject map$Data = new JsonObject();

				map$Data.addProperty("user", userDetail.get("userName").getAsString());
				map$Data.addProperty("tmp$name", userDetail.get("tmplName").getAsString());
				argJson.add("map$Data", map$Data);

				if (checkEmail.equalsIgnoreCase("Y")
						&& !I$utils.$iStrBlank(userDetail.get("userEmailId").getAsString())) {

					argJson.add("toemailIds", i$ResM
							.getJsonObj("{\"toemailid1\":\"" + userDetail.get("userEmailId").getAsString() + "\"}"));
					JsonObject i$res = i$Email.SendEmailWOThread(argJson);
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
						logger.debug("Send Email SuccessFull");
					}

				}

				if (checkSms.equalsIgnoreCase("Y")
						&& !I$utils.$iStrBlank(userDetail.get("userMobileNo").getAsString())) {

					argJson.add("mobile$numbers", i$ResM
							.getJsonObj("{\"Mob_Number1\":\"" + userDetail.get("userMobileNo").getAsString() + "\"}"));
					JsonObject i$res = i$SmsSrvc.SendSMSWOThread(argJson);
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
						logger.debug("Send SMS SuccessFull");
					}
				}
				;

			}
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Message Service Triggered Sucessfully");
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending Message or Message Service is disabled", "Contact Adminstrator");

		}
	};
	// PKY00013 Ends

	// PKY00014 Starts
	public JsonObject pendingVerfRem(JsonObject isonMsg) {
		try {
			String sTmplName = null;
			new JsonObject();
			System.getProperty("line.separator");
			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				// sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg);
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP",
						"{\"MSG_ANNOTATION\":\"" + i$ResM.getBodyElementS(isonMsg, "Msg_Annotation") + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#OTP";

			JsonObject filter = new JsonObject();
			JsonObject body$Details = isonMsg.get("i-body").getAsJsonObject();
			filter.addProperty("datasetId", body$Details.get("datasetId").getAsString());
			JsonObject datasetDetails = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter);
			String checkEmail = datasetDetails.get("sendEmail").getAsString();
			String checkSms = datasetDetails.get("sendSms").getAsString();
			JsonArray userDetails = datasetDetails.getAsJsonArray("userDetails");

			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			int inCompleteAppReminderInDays = cParam.get("pendingVerificationReminderInDays").getAsInt();
			JsonObject Qfilter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonArray stage$Name = new JsonArray();
			JsonParser parser = new JsonParser();
			Gson gson = new GsonBuilder().serializeNulls().create();
			Date grtrDate = I$utils.changeDate(inCompleteAppReminderInDays, "SUB", "D");
			Date lsrDate = I$utils.changeDate(inCompleteAppReminderInDays - 1, "SUB", "D");
			String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
			JsonObject temp = new JsonObject();
			temp.add("$gte", iso$date);
			Qfilter.add("ModifiedAt", temp);
			iso$date = Ioutils.dateFromatter(lsrDateS);
			temp.add("$lt", iso$date);
			Qfilter.add("ModifiedAt", temp);
			stage$Name.add("APPROVE APPLICATION");
			stage$Name.add("ENRICHMENT");
			stage$Name.add("INITIAL DEPOSIT APPLICATION");
			stage$Name.add("OSV APPLICATION");
			stage$Name.add("VERIFY APPLICATION");
			JsonObject curr$Stage = new JsonObject();
			curr$Stage.add("$in", stage$Name);
			Qfilter.add("CurrentStageName", curr$Stage);
			Qfilter.addProperty("isCurrVer", "Y");
			JsonArray FQfilter = new JsonArray();
			FQfilter.add(Qfilter);
			projection.addProperty("applicationId", 1);
			projection.addProperty("ModifiedAt", 1);
			projection.addProperty("contactDetails.branch", 1);
			projection.addProperty("applicantName", 1);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_IBM_PROCESS", Qfilter, projection);

			if (i$Body.size() > 0) {
				try {
					for (int j = 0; j < i$Body.size(); j++) {
						try {
							JsonObject document = i$Body.get(j).getAsJsonObject();
							String aplId = document.get("applicationId").getAsString();
							JsonObject contact$Details = document.get("contactDetails").getAsJsonObject();
							String branch = contact$Details.get("branch").getAsString();
							String applicantName = document.get("applicantName").getAsString();

							for (int i = 0; i < userDetails.size(); i++) {
								try {
									JsonObject userDetail = userDetails.get(i).getAsJsonObject();
									userDetail.addProperty("tmplName", sTmplName);
									JsonObject argJson = new JsonObject();
									JsonObject map$Data = new JsonObject();
									map$Data.addProperty("user", userDetail.get("userName").getAsString());
									map$Data.addProperty("tmp$name", userDetail.get("tmplName").getAsString());
									map$Data.addProperty("Application ID", aplId);
									map$Data.addProperty("Branch code", branch);
									map$Data.addProperty("Applicant's Name", applicantName);
									argJson.add("map$Data", map$Data);

									if (checkEmail.equalsIgnoreCase("Y")
											&& !I$utils.$iStrBlank(userDetail.get("userEmailId").getAsString())) {
										;
										argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\""
												+ userDetail.get("userEmailId").getAsString() + "\"}"));
										JsonObject i$res = i$Email.SendEmailWOThread(argJson);
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
											logger.debug("Send Email SuccessFull");
										}
									}
									if (checkSms.equalsIgnoreCase("Y")
											&& !I$utils.$iStrBlank(userDetail.get("userMobileNo").getAsString())) {
										argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\""
												+ userDetail.get("userMobileNo").getAsString() + "\"}"));
										JsonObject i$res = i$SmsSrvc.SendSMSWOThread(argJson);
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
											logger.debug("Send SMS SuccessFull");
										}
									}
									;
								} catch (Exception e) {
									e.printStackTrace();
									logger.debug(e.getLocalizedMessage());
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
							logger.debug(e.getLocalizedMessage());
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug(e.getLocalizedMessage());
				}

			}
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Message Service Triggered Sucessfully");
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending Message or Message Service is disabled", "Contact Adminstrator");

		}
	}

	// PKY00014 Ends
	// PKY00051 starts
	// PKY00062 starts
	public JsonObject loanApplnTerminationReminder(JsonObject isonMsg) {
		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
		JsonArray ReminderDays = cParam.get("leadApplnTermRem").getAsJsonArray();
		int finalDays = 0;
		JsonObject Qfilter = new JsonObject();
		JsonObject projection = new JsonObject();
		for (int i = 0; i < ReminderDays.size(); i++) {
			try {
				JsonObject reminderterm = ReminderDays.get(i).getAsJsonObject();
				JsonArray fltr = new JsonArray();
				JsonArray filter = new JsonArray();
				JsonObject filter2 = new JsonObject();
				Set<String> keys = reminderterm.keySet();
				for (String reminderDet : keys) {
					JsonObject Qfilter2 = new JsonObject();
					JsonObject temp = new JsonObject();
					try {
						if (reminderDet.contains("CL")) {
							if (reminderDet.equalsIgnoreCase("firstCLReminderInDays")) {
								finalDays = reminderterm.get("firstCLReminderInDays").getAsInt();
								filter.add("CL01");
								filter.add("CL02");
								filter.add("CL03");
							} else if (reminderDet.equalsIgnoreCase("secondCLReminderInDays")) {
								finalDays = reminderterm.get("secondCLReminderInDays").getAsInt();
							} else if (reminderDet.equalsIgnoreCase("thirdCLReminderInDays")) {
								finalDays = reminderterm.get("thirdCLReminderInDays").getAsInt();
							}

						} else if (reminderDet.contains("VL")) {
							if (reminderDet.equalsIgnoreCase("firstVLReminderInDays")) {
								finalDays = reminderterm.get("firstVLReminderInDays").getAsInt();
								filter.add("VL01");
								filter.add("VL02");
								filter.add("VL03");
							} else if (reminderDet.equalsIgnoreCase("secondVLReminderInDays")) {
								finalDays = reminderterm.get("secondVLReminderInDays").getAsInt();
							} else if (reminderDet.equalsIgnoreCase("thirdVLReminderInDays")) {
								finalDays = reminderterm.get("thirdVLReminderInDays").getAsInt();
							}

						} else if (reminderDet.contains("ML")) {
							if (reminderDet.equalsIgnoreCase("firstMLReminderInDays")) {
								finalDays = reminderterm.get("firstMLReminderInDays").getAsInt();
								filter.add("ML01");
								filter.add("ML02");
								filter.add("ML03");
								filter.add("ML04");
								filter.add("ML05");
								filter.add("ML06");
								filter.add("ML07");
								filter.add("ML08");
								filter.add("ML09");
								filter.add("ML10");
								filter.add("ML21");
							} else if (reminderDet.equalsIgnoreCase("secondMLReminderInDays")) {
								finalDays = reminderterm.get("secondMLReminderInDays").getAsInt();
							} else if (reminderDet.equalsIgnoreCase("thirdMLReminderInDays")) {
								finalDays = reminderterm.get("thirdMLReminderInDays").getAsInt();
							}
						}
						Date grtrDate = I$utils.changeDate(finalDays, "SUB", "D");
						Date lsrDate = I$utils.changeDate(finalDays - 1, "SUB", "D");
						String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
						String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
						JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
						temp.add("$gte", iso$date);
						Qfilter2.add("ModifiedAt", temp);
						iso$date = Ioutils.dateFromatter(lsrDateS);
						temp.add("$lt", iso$date);
						Qfilter2.add("ModifiedAt", temp);
						filter2.add("$in", filter);
						fltr.add(Qfilter2);
						Qfilter.add("loanDetails.loanType", filter2);
						JsonObject currStg = new JsonObject();
						currStg.addProperty("$ne", "COMPLETE APPLICATION");
						Qfilter.add("WorkFlowStatus", currStg);
						JsonObject neTer = new JsonObject();
						neTer.addProperty("$ne", "T_TERMINATE");
						Qfilter.add("RecordStat", neTer);
						Qfilter.addProperty("isCurrVer", "Y");
						Qfilter.add("$or", fltr);
					} catch (Exception e) {
					}
				}
				try {
					projection.addProperty("applicationId", 1);
					projection.addProperty("cif", 1);
					projection.addProperty("createdAt", 1);
					projection.addProperty("_id", 0);
					JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_C_LD_LEAD_APPLICATIONS", Qfilter, projection);
					isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation", "TECU_REMINDER_APPLN_TERM");
					for (int J = 0; J < i$Body.size(); J++) {
						try {
							JsonObject app$Json = i$Body.get(J).getAsJsonObject();
							isonMsg.getAsJsonObject("i-body").addProperty("cif", app$Json.get("cif").getAsString());
							app$Json.addProperty("WORKFLOWID", "IMPACTO_LEAD_WRKFLOW");
							JsonObject filter3 = new JsonObject();
							JsonObject projection1 = new JsonObject();
							filter3.addProperty("datasetId", "Dataset_5670");
							projection1.addProperty("userDetails", 1);
							JsonObject dataSet$Row = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter3, projection1);
							JsonArray userDetails = dataSet$Row.get("userDetails").getAsJsonArray();
							for (int k = 0; k < userDetails.size(); k++) {
								try {
									JsonObject user$Details = userDetails.get(k).getAsJsonObject();
									app$Json.addProperty("emailId", user$Details.get("userEmailId").getAsString());
									app$Json.addProperty("mobNo", user$Details.get("userMobileNo").getAsString());
									sendReminders(app$Json, isonMsg, "");
								} catch (Exception e) {

								}
							}

						} catch (Exception e) {
						}
					}

				} catch (Exception e) {
					logger.debug(e.getLocalizedMessage()
							+ "Error in loan application termination reminder sending notification");
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Error in sending loan application termination reminder notification");
				}

			} catch (Exception e) {

			}

		}

		return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Loan application termination reminder successfully sent");
	}
	// PKY00062 ends
	// PKY00051 ends

	// PKY00066 starts
	public JsonObject tatilApplnReminder(JsonObject isonMsg) {
		try {
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			JsonArray ReminderDays = cParam.get("tatilApplnReminder").getAsJsonArray();
			JsonObject projection = new JsonObject();
			for (int i = 0; i < ReminderDays.size(); i++) {
				JsonObject Qfilter = new JsonObject();
				JsonObject Qfilter2 = new JsonObject();
				JsonObject temp = new JsonObject();
				JsonArray fltr = new JsonArray();
				try {
					int reminderlnInDays = 0;
					JsonObject Reminder$Days = ReminderDays.get(i).getAsJsonObject();
					if (Reminder$Days.has("firstTatilApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("firstTatilApplnReminderInDays").getAsInt();
					} else if (Reminder$Days.has("secondTatilApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("secondTatilApplnReminderInDays").getAsInt();
					} else if (Reminder$Days.has("thirdTatilApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("thirdTatilApplnReminderInDays").getAsInt();
					} else if (Reminder$Days.has("fourthTatilApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("fourthTatilApplnReminderInDays").getAsInt();
					} else if (Reminder$Days.has("fifthTatilApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("fifthTatilApplnReminderInDays").getAsInt();
					}
					Date grtrDate = I$utils.changeDate(reminderlnInDays, "SUB", "D");
					Date lsrDate = I$utils.changeDate(reminderlnInDays - 1, "SUB", "D");
					String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
					temp.add("$gte", iso$date);
					Qfilter2.add("createdAt", temp);
					iso$date = Ioutils.dateFromatter(lsrDateS);
					temp.add("$lt", iso$date);
					Qfilter2.add("createdAt", temp);
					fltr.add(Qfilter2);
					Qfilter.addProperty("DcStatus", "In-Complete");
					JsonObject neTer = new JsonObject();
					neTer.addProperty("$ne", "T_TERMINATE");
					Qfilter.add("RecordStat", neTer);
					// Qfilter.addProperty("isCurrVer", "Y");//#SRP00055 changes
					Qfilter.add("$or", fltr);

					projection.addProperty("custInfo", 1);
					projection.addProperty("applicationId", 1);
					projection.addProperty("_id", 0);
					;
					JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_C_B2U_TATIL_APPLICATION", Qfilter, projection);
					if (Reminder$Days.has("fifthTatilApplnReminderInDays")) {
						isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation","TECU_TATIL_INCAPPLN_REMINDER_ON21THDAY");
					} else {
						isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation","TECU_TATIL_INCAPPLN_REMINDER_EVERY5DAYS");
					}
					for (int j = 0; j < i$Body.size(); j++) {
						try {
							JsonObject argjson = new JsonObject();
							JsonObject app$Json = i$Body.get(j).getAsJsonObject();
							argjson.addProperty("WORKFLOWID", "IMPACTO_TATIL_INSURANCE_WORKFLOW");
							argjson.addProperty("applicationId", app$Json.get("applicationId").getAsString());
							argjson.addProperty("MemberName",app$Json.get("custInfo").getAsJsonObject().get("CustomerFullName").getAsString());
							argjson.addProperty("emailId",app$Json.get("custInfo").getAsJsonObject().get("CustomerEmailId").getAsString());
							argjson.addProperty("mobNo",app$Json.get("custInfo").getAsJsonObject().get("CustomerMobileIsdNo").getAsString()
											+ app$Json.get("custInfo").getAsJsonObject().get("CustomerMobileId")
													.getAsString());
							sendReminders(argjson, isonMsg, "");
						} catch (Exception e) {
							logger.debug(e.getLocalizedMessage() + "Error in fetching data from tatil application");
						}
					}
				} catch (Exception e) {
				}
			}
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage() + "Error in sending tatil application reminder notification");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in sending tatil application reminder notification");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Tatil application reminder successfully sent");
	}// PKY00066 ends
		// MSA00063 starts
	public JsonObject onBoardApplnReminder(JsonObject isonMsg) {
		try {
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			JsonArray ReminderDays = cParam.get("onBoardApplnReminder").getAsJsonArray();
			JsonObject projection = new JsonObject();
			JsonObject updateData = new JsonObject();
			JsonObject exlattachmentData = new JsonObject();

			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sh = wb.createSheet("Sheet1");
			HSSFRow row = sh.createRow(0);
			HSSFFont i$font = wb.createFont();
			sh.setColumnWidth(0, 6000);
			sh.setColumnWidth(1, 6000);
			sh.setColumnWidth(2, 6000);
			sh.setColumnWidth(3, 6000);
			sh.setColumnWidth(4, 6000);
			sh.setColumnWidth(5, 6000);
			sh.setColumnWidth(6, 6000);
			sh.setColumnWidth(7, 6000);
			HSSFCellStyle style = wb.createCellStyle();
			row.setRowStyle(style);
			int rowCount = 0;
			String[] headings = { "ApplicationId", "FirstName", "LastName", "Email", "MobileNo", "No.of Reminder",
					"Last Reminder Sent ", "Application Created At" };

			for (int m = 0; m < headings.length; m++) {
				row.createCell(m).setCellValue(headings[m]);
				i$font.setFontName(headings[m]);
				i$font.setColor(IndexedColors.BLACK.getIndex());
				i$font.setBold(true);
			}
			for (int i = 0; i < ReminderDays.size(); i++) {
				JsonObject Qfilter = new JsonObject();
				JsonObject Qfilter2 = new JsonObject();
				JsonObject temp = new JsonObject();
				JsonArray fltr = new JsonArray();
				try {
					int reminderlnInDays = 0;
					JsonObject Reminder$Days = ReminderDays.get(i).getAsJsonObject();
					if (Reminder$Days.has("firstOnBoardApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("firstOnBoardApplnReminderInDays").getAsInt();
						updateData.addProperty("reminderType", "firstReminder");
						updateData.addProperty("noOfReminder", 1);
					} else if (Reminder$Days.has("secondOnBoardApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("secondOnBoardApplnReminderInDays").getAsInt();
						updateData.addProperty("reminderType", "secondReminder");
						updateData.addProperty("noOfReminder", 2);
					} else if (Reminder$Days.has("thirdOnBoardApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("thirdOnBoardApplnReminderInDays").getAsInt();
						updateData.addProperty("reminderType", "thirdReminder");
						updateData.addProperty("noOfReminder", 3);
					} else if (Reminder$Days.has("fourthOnBoardApplnReminderInDays")) {
						reminderlnInDays = Reminder$Days.get("fourthOnBoardApplnReminderInDays").getAsInt();
						updateData.addProperty("reminderType", "fourthReminder");
						updateData.addProperty("noOfReminder", 4);
					}
					Date grtrDate = I$utils.changeDate(reminderlnInDays, "SUB", "D");
					Date lsrDate = I$utils.changeDate(reminderlnInDays - 1, "SUB", "D");
					String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
					temp.add("$gte", iso$date);
					Qfilter2.add("createdAt", temp);
					iso$date = Ioutils.dateFromatter(lsrDateS);
					temp.add("$lt", iso$date);
					Qfilter2.add("createdAt", temp);
					fltr.add(Qfilter2);
					Qfilter.addProperty("DcStatus", "In-Complete");
					JsonObject neTer = new JsonObject();
					neTer.addProperty("$ne", "T_TERMINATE");
					Qfilter.add("RecordStat", neTer);
					Qfilter.add("$or", fltr);

					projection.addProperty("contactDetails", 1);
					projection.addProperty("applicationId", 1);
					projection.addProperty("personalInfo", 1);
					projection.addProperty("createdAt",1);
					projection.addProperty("currStgNo",1);
					projection.addProperty("_id", 0);
					JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_C_B2U_CIF_APPLICATION", Qfilter, projection);
					if (Reminder$Days.has("firstOnBoardApplnReminderInDays")) {
						isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation",
								"TECU_CIF_INCAPPLN_REMINDER_ON15THDAY");
					} else if (Reminder$Days.has("secondOnBoardApplnReminderInDays")) {
						isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation",
								"TECU_CIF_INCAPPLN_REMINDER_ON30THDAY");
					} else if (Reminder$Days.has("thirdOnBoardApplnReminderInDays")) {
						isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation",
								"TECU_CIF_INCAPPLN_REMINDER_ON45THDAY");
					} else if (Reminder$Days.has("fourthOnBoardApplnReminderInDays")) {
						isonMsg.getAsJsonObject("i-body").addProperty("Msg_Annotation",
								"TECU_CIF_INCAPPLN_REMINDER_ON60THDAY");
					}
					for (int j = 0; j < i$Body.size(); j++) {
						try {
							JsonObject argjson = new JsonObject();
							JsonObject app$Json = i$Body.get(j).getAsJsonObject();
							argjson.addProperty("WORKFLOWID", "IMPACTO_CIF_WFLW_NEW");
							argjson.addProperty("applicationId", app$Json.get("applicationId").getAsString());
							try {
								argjson.addProperty("emailId",app$Json.get("contactDetails").getAsJsonObject().get("emailId").getAsString());
							}catch(Exception e) {
								argjson.addProperty("emailId","");
							}
							try {
								argjson.addProperty("mobNo", app$Json.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString());
							}catch(Exception e) {
								argjson.addProperty("mobNo","");
							}
							try {
								argjson.addProperty("currStgNo", app$Json.get("currStgNo").getAsString());
							}catch(Exception e) {
								argjson.addProperty("currStgNo","");
							}
							JsonObject msg = sendReminders(argjson, isonMsg, "");
							JsonObject cifUpdateData = new JsonObject();
							String reminderStatus = updateData.get("reminderType").getAsString() + "Sent";
							String reminderAt = updateData.get("reminderType").getAsString() + "SentAt";
							JsonObject fltrI = new JsonObject();
							fltrI.addProperty("applicationId", app$Json.get("applicationId").getAsString());
							if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(msg), i$ResM.I_SUCC)) {
								cifUpdateData.addProperty(reminderStatus, true);
								cifUpdateData.addProperty(reminderAt, I$utils.$getISONow());
								cifUpdateData.addProperty("noOfReminder", updateData.get("noOfReminder").getAsInt());
							} else {
								cifUpdateData.addProperty(reminderStatus, false);
								cifUpdateData.addProperty(reminderAt, I$utils.$getISONow());
							}
							db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION", cifUpdateData, fltrI);
							if (Reminder$Days.has("fourthOnBoardApplnReminderInDays")) {
								cifUpdateData.addProperty("WorkFlowId", "IMPACTO_CIF_WFLW_NEW_HIDDEN");
							}
							db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", cifUpdateData, fltrI);

							try {
								try {
									cifUpdateData.addProperty("applicationId",app$Json.get("applicationId").getAsString());
								} catch (Exception e) {
									cifUpdateData.addProperty("applicationId", "");
								}
								try {
									cifUpdateData.addProperty("emailId", app$Json.get("contactDetails").getAsJsonObject().get("emailId").getAsString());
								} catch (Exception e) {
									cifUpdateData.addProperty("emailId", "");
								}
								try {
									cifUpdateData.addProperty("mobNo", app$Json.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString());
								} catch (Exception e) {
									cifUpdateData.addProperty("mobNo", "");
								}
								try {
									cifUpdateData.addProperty("FirstName", app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString());
								} catch (Exception e) {
									cifUpdateData.addProperty("FirstName", "");
								}
								try {
									cifUpdateData.addProperty("LastName", app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
								} catch (Exception e) {
									cifUpdateData.addProperty("LastName", "");
								}
								cifUpdateData.addProperty("lastReminderAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
								try {
									cifUpdateData.addProperty("applCreatedAt", app$Json.get("createdAt").getAsString());
								} catch (Exception e) {
									cifUpdateData.addProperty("applCreatedAt", "");
								}
								cifUpdateData.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
							} catch (Exception e) {
								e.printStackTrace();
							}
							JsonObject fetchedData = db$Ctrl.db$GetRow("ICOR_M_CIF_REMINDER_REPORT", fltrI);
							if (I$utils.$isNull(fetchedData)) {
								db$Ctrl.db$InsertRow("ICOR_M_CIF_REMINDER_REPORT", cifUpdateData);
							} else {
								db$Ctrl.db$UpdateRow("ICOR_M_CIF_REMINDER_REPORT", cifUpdateData, fltrI);
							}

						} catch (Exception e) {
							logger.debug(e.getLocalizedMessage()
									+ "Error in fetching data from pending On-Board application");
						}
					}
//					//report generation
				} catch (Exception e) {
					logger.debug(e.getLocalizedMessage() + "Error in fetching data from pending On-Board application");
				}
			}
			JsonArray reportData = db$Ctrl.db$GetRows("ICOR_M_CIF_REMINDER_REPORT", "{}");
			if (reportData.size() > 0) {
				for (int s = 0; s < reportData.size(); s++) {
					String slNo = null, applNo = null, frstName = null, lastName = null, mail = null, mobno = null,
							noRem = null, lastRem = null, createAt = null;
					try {
						JsonObject currObj = reportData.get(s).getAsJsonObject();
						try {
							applNo = currObj.get("applicationId").getAsString();
						} catch (Exception e) {
						}
						try {
							frstName = currObj.get("FirstName").getAsString();
						} catch (Exception e) {
						}
						try {
							lastName = currObj.get("LastName").getAsString();
						} catch (Exception e) {
						}
						try {
							mail = currObj.get("emailId").getAsString();
						} catch (Exception e) {
						}
						try {
							mobno = currObj.get("mobNo").getAsString();
						} catch (Exception e) {
						}
						try {
							noRem = currObj.get("noOfReminder").getAsString();
						} catch (Exception e) {
						}
						try {
							lastRem = currObj.get("lastReminderAt").getAsString();
						} catch (Exception e) {
						}
						try {
							createAt = currObj.get("applCreatedAt").getAsString();
						} catch (Exception e) {
						}
						row = sh.createRow(++rowCount);
//					Cell cell1 = row.createCell(0);
//					cell1.setCellValue(slNo);
						Cell cell0 = row.createCell(0);
						cell0.setCellValue(applNo);
						Cell cell1 = row.createCell(1);
						cell1.setCellValue(frstName);
						Cell cell2 = row.createCell(2);
						cell2.setCellValue(lastName);
						Cell cell3 = row.createCell(3);
						cell3.setCellValue(mail);
						Cell cell4 = row.createCell(4);
						cell4.setCellValue(mobno);
						Cell cell5 = row.createCell(5);
						cell5.setCellValue(noRem);
						Cell cell6 = row.createCell(6);
						cell6.setCellValue(lastRem);
						Cell cell7 = row.createCell(7);
						cell7.setCellValue(createAt);
					} catch (Exception e) {

					}
				}
			}
			wb.write(outputStream);
			byte[] exlBytes = outputStream.toByteArray();
			String base64String = Base64.getEncoder().encodeToString(exlBytes);
			System.out.println(base64String);
			exlattachmentData.addProperty("docType", "application/excel");
			exlattachmentData.addProperty("fileName", "Pending Member On-Board Applications Report" + ".xls");
			exlattachmentData.addProperty("template", base64String);

			JsonObject dataSetFilter = new JsonObject();
			JsonObject datasetProjection = new JsonObject();
			JsonObject emailDataset$Data = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
			dataSetFilter.addProperty("datasetId", "Dataset_0516");
			datasetProjection.addProperty("userDetails", 1);
			datasetProjection.addProperty("sendEmail", 1);
			datasetProjection.addProperty("sendSms", 1);
			emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
			if (!I$utils.$isNull(emailDataset$Data)) {
				JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
				boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
				boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
				for (int j = 0; j < userDet.size(); j++) {
					try {
						if (sendEmail) {
							JsonObject jsonObject = userDet.get(j).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							keyE = keyE.concat(Email);
							if (j < userDet.size() - 1) {
								keyE = keyE.concat(",");
							}
						}
						if (sendSMS) {
							JsonObject jsonObject = userDet.get(j).getAsJsonObject();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							keyM = keyM.concat(SMS);
							if (j < userDet.size() - 1) {
								keyM = keyM.concat(",");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					JsonArray attachment = new JsonArray();
					map$Data.addProperty("tmp$name", "TMPL#CIF#PENDING#ONBOARD#REPORT");
					argJson.add("map$Data", map$Data);
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					attachment.add(exlattachmentData);
					argJson.add("attachment", attachment);
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage() + "");
		}
		return isonMsg;
	}// MSA00063 ends

	private void getAsString() {
		// TODO Auto-generated method stub

	};

}

//#00000001 Ends