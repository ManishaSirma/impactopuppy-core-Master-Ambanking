/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Pruthvi 	| Jan 29, 2021 | #00000001   | Initial writing
      |0.1 Beta    | Pruthvi 	| Jan 29, 2021 | #YPR00044   | API calls to DMS on different operations
      |0.1 Beta    | Pruthvi 	| Mar 09, 2021 | #YPR00057   | API calls to DMS Delete Operation
      |0.1 Beta    | Pruthvi 	| Mar 19, 2021 | #YPR00058   | API calls to DMS for download Operation
      |0.1 Beta    | Pruthvi 	| May 12, 2021 | #YPR00078   | Added Creation of SubFolder structure
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;


import java.util.concurrent.TimeUnit;


import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.*;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.*;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.Request.Builder;

public class ILogicalDocController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil i$Outils = new ImpactoUtil(); // #NYE00004

	// **********************************************************************//

	//#YPR00044 Starts
	public JsonObject processMsg(JsonObject isonMsg) {
		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC) && I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-body").get("seqName").getAsString(), "SEQ#CIFAPPL")) {// #YPR0004 changes
				return crtFoldr(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "FDMFLUPD") && I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "CREATE")) {
				if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-body").get("DMSLDOC").getAsString(), "Y")) {
					return upldDocmnt(isonMsg);
				}
			} else if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "LDCFLDLD") && I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "CREATE")){
				return dnldDocmnt(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "DMSLDOC")&& I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "delDoc")) {
				return delDocmnt(isonMsg);
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

	private JsonObject crtFoldr(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		String Id = "";
		String extUrl = "";
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson(); 
		JsonParser parser = new JsonParser(); 
		JsonObject i$res = new JsonObject(); 
		JsonArray hits = new JsonArray();
		JsonObject reqObj = new JsonObject();
		String resBody = ""; 
		String reqBodyS = "";
		
		try {
			filter.addProperty("trnCd", "CreateFolderInLDoc");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
			reqObj = argJson.get("reqBody").getAsJsonObject();
			reqObj.addProperty("name", isonMsg.getAsJsonObject("i-body").get("seqNo").getAsString());

//			Id = isonMsg.getAsJsonObject("i-body").get("seqNo").getAsString().replaceAll( "[^\\d]", "" );
//			reqObj.addProperty("id",Long.parseLong(Id));
			
			
			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
			        .readTimeout(120, TimeUnit.SECONDS).build();
			MediaType mediaType  = null;
			String authorizationHeader = null;
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
//			try {
////				String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
////				String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//				String username = reqBodyObj.get("user").getAsString();
//				String password = reqBodyObj.get("pass").getAsString();
//				
//				authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			
			RequestBody reqBody = null;			
			try {
				reqBodyS = gson.toJson(reqObj);
				reqBody = RequestBody.create(mediaType,reqBodyS);
			} catch (Exception Ex) {
				// No Body
				// reqBody = null;
				reqBody = RequestBody.create(null, new byte[0]);  
			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString());  
			ReqBldr.post(reqBody);
//			ReqBldr.addHeader("Authorization", authorizationHeader);
			for (String headerK : headersObj.keySet()) {
				String headerVal = headersObj.get(headerK).getAsString();
				ReqBldr.addHeader(headerK, headerVal);
			}			
			
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
			resBody= response.body().string(); 
			JResp = parser.parse(resBody).getAsJsonObject();
			JResp.addProperty("seqNo", isonMsg.getAsJsonObject("i-body").get("seqNo").getAsString());
			db$Ctrl.db$InsertRow("ICOR_M_LDOC_FLDR_DATA", JResp);
//			crtSubFoldrs(isonMsg); // #YPR00078 Changes
			
			argJson = new JsonObject(); 
			reqBody = null;  
	        System.gc(); 
//			if (JResp.has("resBody") && !I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) {
//			if (!I$utils.$iStrFuzzyMatch(resBody, "")) {
//				transactionId = JResp.get("resBody").getAsString();
//				i$res.add("CreateFolderInLDoc", parser.parse(resBody).getAsJsonArray());
//			} else { 
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "Something Went Wrong");
//			}
//			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			return isonMsg;

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
	};
	
	// #YPR00078 Starts
		
	private String crtSubFoldrs(JsonObject isonMsg,JsonObject folderDetails) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();;
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson(); 
		JsonParser parser = new JsonParser(); 
		JsonObject reqObj = new JsonObject();
		String resBody = ""; 
		String reqBodyS = "";
		
		try {
			filter.addProperty("trnCd", "CreateSubFoldersInLDoc");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			JResp.addProperty("seqNo", folderDetails.get("seqNo").getAsString());
			int parentId = db$Ctrl.db$GetRow("ICOR_M_LDOC_FLDR_DATA", JResp).getAsJsonObject().get("id").getAsInt(); // #YPR00079 Changes
			JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
			reqObj.addProperty("parentId", parentId);
//			JsonArray subFldrs = argJson.get("subFoldersList").getAsJsonArray();
//			for(int i=0;i<subFldrs.size();i++) {
			reqObj.addProperty("name",folderDetails.get("name").getAsString());

//			Id = isonMsg.getAsJsonObject("i-body").get("seqNo").getAsString().replaceAll( "[^\\d]", "" );
//			reqObj.addProperty("id",Long.parseLong(Id));
			
			
			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
			        .readTimeout(120, TimeUnit.SECONDS).build();
			MediaType mediaType  = null;
			String authorizationHeader = null;
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
//			try {
////				String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
////				String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//				String username = reqBodyObj.get("user").getAsString();
//				String password = reqBodyObj.get("pass").getAsString();
//				
//				authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			
			RequestBody reqBody = null;			
			try {
				reqBodyS = gson.toJson(reqObj);
				reqBody = RequestBody.create(mediaType,reqBodyS);
			} catch (Exception Ex) {
				// No Body
				// reqBody = null;
				reqBody = RequestBody.create(null, new byte[0]);  
			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString());  
			ReqBldr.post(reqBody);
//			ReqBldr.addHeader("Authorization", authorizationHeader);
			for (String headerK : headersObj.keySet()) {
				String headerVal = headersObj.get(headerK).getAsString();
				ReqBldr.addHeader(headerK, headerVal);
			}			
			
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
			resBody= response.body().string(); 
			JResp = parser.parse(resBody).getAsJsonObject();
			JResp.addProperty("seqNo", folderDetails.get("seqNo").getAsString());
			db$Ctrl.db$InsertRow("ICOR_M_LDOC_FLDR_DATA", JResp);
			
			reqBody = null;  
	        System.gc(); 
//			}
//			if (JResp.has("resBody") && !I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) {
//			if (!I$utils.$iStrFuzzyMatch(resBody, "")) {
//				transactionId = JResp.get("resBody").getAsString();
//				i$res.add("CreateFolderInLDoc", parser.parse(resBody).getAsJsonArray());
//			} else { 
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "Something Went Wrong");
//			}
//			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			return JResp.get("id").getAsString();

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return null;
		}
	};
	// #YPR00078 Ends
	
	private JsonObject upldDocmnt(JsonObject isonMsg) {
			JsonObject argJson = new JsonObject();
			JsonObject folderData = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject LdfoldFilter = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String resBody = "";
			String folderId = "";
			String docGroup = "";
			String docType = "";
			String folderName = "";
			
			try {
				try {
					//  #YPR00079 Starts
					try {
					docGroup = i$body.get("DocParentGrpID1").getAsString();
					docType = i$body.get("DocSubGrpID1").getAsString();
					}catch(Exception e) {
						//pass
					}
//				folderId = crtSubFoldrs(isonMsg);					
					
				LdfoldFilter.addProperty("seqNo", i$body.get("LinkedCustNo").getAsString());
				String subFoldProj = "{'_id': 0, 'subFoldersConfig': {'$elemMatch': {'docGroup': '" + docGroup +"','docType':'" + docType +"'}}}";
				folderName = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", "{'PARAM':'IDocZ_FolderStruc'}",subFoldProj).get("subFoldersConfig").getAsJsonArray().get(0).getAsJsonObject().get("name").getAsString();
				LdfoldFilter.addProperty("name",folderName);
				
				folderData = db$Ctrl.db$GetRow("ICOR_M_LDOC_FLDR_DATA", LdfoldFilter);
				
			    if (I$utils.$isNull(folderData)) {
			    	folderId = crtSubFoldrs(isonMsg,LdfoldFilter);
			    }else {
			    	folderId = folderData.get("id").getAsString();
			    }
				}catch(Exception e) {
					//pass
				}
			//  #YPR00079 Ends
				
				filter.addProperty("trnCd", "UploadDocumentInLDoc");
				argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
				JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
				
//				OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
//				        .readTimeout(120, TimeUnit.SECONDS).build();
				OkHttpClient client = new OkHttpClient().newBuilder().build();
				MediaType mediaType  = null; 
				String authorizationHeader = null;
				
				try {
					mediaType = MediaType.parse(argJson.get("mediaType").getAsString());
				} catch (Exception e) {
					e.printStackTrace();
				}
//				try {
////					String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
////					String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//					String username = reqBodyObj.get("user").getAsString();
//					String password = reqBodyObj.get("pass").getAsString();
//					
//					authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//				}catch(Exception e) {
//					e.printStackTrace();
//				}
				
				RequestBody reqBody = null;
				String baseFileData = i$body.get("I#FileData").getAsString();
				byte[] decoded_FData = Base64.decodeBase64(baseFileData.getBytes());
//				isonMsg.remove("filedata");
				String filename = isonMsg.getAsJsonObject("i-body").get("FileName").getAsString();
				
				try {
					 okhttp3.MultipartBody.Builder body = new MultipartBody.Builder();
					 body.setType(MultipartBody.FORM);
					 body.addFormDataPart("filedata",filename,RequestBody.create(MediaType.parse("application/octet-stream"),decoded_FData));
//					for (String headerK : reqBodyObj.keySet()) {
//						String headerVal = reqBodyObj.get(headerK).getAsString();	
						body.addFormDataPart("folderId", folderId);
						body.addFormDataPart("filename", filename);
						body.addFormDataPart("release","true");
						body.addFormDataPart("language","en");
//							}
					 reqBody =  body.build();
					
				  } catch (Exception Ex) {
					// reqBody = null;
					reqBody = RequestBody.create(null, new byte[0]);  
				}
				
				Builder ReqBldr = new Request.Builder();
				ReqBldr.url(argJson.get("extUrl").getAsString());  
				ReqBldr.post(reqBody);
//				ReqBldr.addHeader("Authorization", authorizationHeader);
				for (String headerK : headersObj.keySet()) {
					String headerVal = headersObj.get(headerK).getAsString();
					ReqBldr.addHeader(headerK, headerVal);
				}			
				Request request = ReqBldr.build();
				Response response = client.newCall(request).execute();			
				resBody= response.body().string(); 		
				
				argJson = new JsonObject(); 
				reqBody = null;  
		        System.gc();
		        
		        i$body.addProperty("docId",resBody);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//				if (JResp.has("resBody") && !I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) {
//				if (!I$utils.$iStrFuzzyMatch(resBody, "")) {
////					transactionId = JResp.get("resBody").getAsString();
////					i$res.add("CreateFolderInLDoc", parser.parse(resBody).getAsJsonArray());
//				} else { 
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "Something Went Wrong");
//				}
//				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
				return isonMsg;

			} catch (Exception e) {
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
				e.printStackTrace();
				return isonMsg;
			}
	};
	
	// #YPR00058  starts

	private JsonObject dnldDocmnt(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		
		try {
			filter.addProperty("metadata.FileUrlToken", isonMsg.getAsJsonObject("i-body").get("FileUrlToken").getAsString());
			JsonObject fileMeta = db$Ctrl.db$GetRow("fs.files",filter).get("metadata").getAsJsonObject();
			String docId = fileMeta.get("docId").getAsString();
			filter.remove("metadata.FileUrlToken");
			
			
			filter.addProperty("trnCd", "DownloadDocumentInLDoc");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
			
			
//			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
//	        .readTimeout(120, TimeUnit.SECONDS).build();
	         OkHttpClient client = new OkHttpClient().newBuilder().build();
//			MediaType mediaType  = null;
//			String authorizationHeader = null;
//			try {
//				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
//			} catch (Exception e) {
//				 
//			}
//			try {
////				String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
////				String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//				String username = reqBodyObj.get("user").getAsString();
//				String password = reqBodyObj.get("pass").getAsString();
//				
//				authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			
			RequestBody reqBody = null;			
//			try {
//				reqBodyS = gson.toJson(reqObj);
//				reqBody = RequestBody.create(mediaType,reqBodyS);
//			} catch (Exception Ex) {
//				// No Body
//				// reqBody = null;
//				reqBody = RequestBody.create(null, new byte[0]);  
//			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString()+docId);
			ReqBldr.get();
//			ReqBldr.addHeader("Authorization", authorizationHeader);
			for (String headerK : headersObj.keySet()) {
				String headerVal = headersObj.get(headerK).getAsString();
				ReqBldr.addHeader(headerK, headerVal);
			}			
			
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
//			resBody= response.body().string(); 
			
			String encoded_FData = Base64.encodeBase64String(response.body().bytes());
			
			argJson = new JsonObject(); 
			reqBody = null;  
	        System.gc(); 
	        
	        
			fileMeta.addProperty("FileUrlToken",isonMsg.getAsJsonObject("i-body").get("FileUrlToken").getAsString());
			fileMeta.addProperty("FileContent", encoded_FData);
			fileMeta.addProperty("tranId",isonMsg.getAsJsonObject("i-body").get("tranId").getAsString());

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, fileMeta);

			return isonMsg;
			

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
};
//#YPR00058 Ends
	
    // #YPR00057  starts
	private JsonObject delDocmnt(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		String id = "";
		Gson gson = new Gson(); 
		JsonObject reqObj = new JsonObject();
		String reqBodyS = "";
		String resBody = "";
		
		
		try {
			filter.addProperty("metadata.FileUrlToken", isonMsg.getAsJsonObject("i-body").get("FileUrlToken").getAsString());
			JsonObject fileMeta = db$Ctrl.db$GetRow("fs.files",filter);
			id = fileMeta.get("metadata").getAsJsonObject().get("docId").getAsString();
			filter.remove("metadata.FileUrlToken");
			filter.addProperty("trnCd", "DeleteDocumentInLDoc");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			
			JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
			reqObj = argJson.get("reqBody").getAsJsonObject();
			reqObj.addProperty("docId", id);

//			Id = isonMsg.getAsJsonObject("i-body").get("seqNo").getAsString().replaceAll( "[^\\d]", "" );
//			reqObj.addProperty("id",Long.parseLong(Id));
			
//			isonMsg.getAsJsonObject("i-body").remove("imgData");


			
			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
			        .readTimeout(120, TimeUnit.SECONDS).build();
			MediaType mediaType  = null;
			String authorizationHeader = null;
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
//			try {
//				String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
//				String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//				String username = reqBodyObj.get("user").getAsString();
//				String password = reqBodyObj.get("pass").getAsString();
//				
//				authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			
			RequestBody reqBody = null;			
			try {
				reqBodyS = gson.toJson(reqObj);
				reqBody = RequestBody.create(mediaType,reqBodyS);
			} catch (Exception Ex) {
				// No Body
				// reqBody = null;
				reqBody = RequestBody.create(null, new byte[0]);  
			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString()+Integer.parseInt(id));  
			ReqBldr.delete(reqBody);
//			ReqBldr.addHeader("Authorization", authorizationHeader);
			for (String headerK : headersObj.keySet()) {
				String headerVal = headersObj.get(headerK).getAsString();
				ReqBldr.addHeader(headerK, headerVal);
			}			
			
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
			resBody= response.body().string(); 
			
			argJson = new JsonObject(); 
			reqBody = null;  
	        System.gc(); 
//			if (JResp.has("resBody") && !I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) {
//			if (!I$utils.$iStrFuzzyMatch(resBody, "")) {
////				transactionId = JResp.get("resBody").getAsString();
//				i$res.add("CreateFolderInLDoc", parser.parse(resBody).getAsJsonArray());
//			} else { 
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "Something Went Wrong");
//			}
//			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			return isonMsg;
			
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
	}
	// #YPR00057  starts
	
	private String srchbyFileNme(String fileName) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson(); 
		JsonParser parser = new JsonParser(); 

		JsonObject reqObj = new JsonObject();
		String resBody = ""; 
		String reqBodyS = "";
		
		try {
			filter.addProperty("trnCd", "SearchByFileNameInLDoc");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			
			JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
			reqObj = argJson.get("reqBody").getAsJsonObject();
			reqObj.addProperty("filename", fileName);
			
			
			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
			        .readTimeout(120, TimeUnit.SECONDS).build();
			MediaType mediaType  = null;
			String authorizationHeader = null;
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
//			try {
////				String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
////				String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//				String username = reqBodyObj.get("user").getAsString();
//				String password = reqBodyObj.get("pass").getAsString();
//				
//				authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			
			RequestBody reqBody = null;			
			try {
				reqBodyS = gson.toJson(reqObj);
				reqBody = RequestBody.create(mediaType,reqBodyS);
			} catch (Exception Ex) {
				// No Body
				// reqBody = null;
				reqBody = RequestBody.create(null, new byte[0]);  
			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString()+fileName);  
			ReqBldr.get();
//			ReqBldr.addHeader("Authorization", authorizationHeader);
			for (String headerK : headersObj.keySet()) {
				String headerVal = headersObj.get(headerK).getAsString();
				ReqBldr.addHeader(headerK, headerVal);
			}			
			
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
			resBody= response.body().string(); 
			JResp = parser.parse(resBody).getAsJsonArray().get(0).getAsJsonObject();
//			JResp.addProperty("seqNo", isonMsg.getAsJsonObject("i-body").get("seqNo").getAsString());
//			db$Ctrl.db$InsertRow("ICOR_M_LDOC_FLDR_DATA", JResp);
			
			argJson = new JsonObject(); 
			reqBody = null;  
	        System.gc(); 
//			if (JResp.has("resBody") && !I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) {
//			if (!I$utils.$iStrFuzzyMatch(resBody, "")) {
////				transactionId = JResp.get("resBody").getAsString();
//				i$res.add("CreateFolderInLDoc", parser.parse(resBody).getAsJsonArray());
//			} else { 
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "Something Went Wrong");
//			}
//			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			return (JResp.get("id").getAsString());
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	
	
	private JsonObject getDocument(String docId) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson(); 
		JsonParser parser = new JsonParser(); 

		JsonObject reqObj = new JsonObject();
		String resBody = ""; 
		String reqBodyS = "";
		
		try {
			filter.addProperty("trnCd", "getDocumentInLDoc");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			
			JsonObject headersObj = argJson.get("headerTags").getAsJsonObject();
			reqObj = argJson.get("reqBody").getAsJsonObject();
			reqObj.addProperty("docId", docId);
			
			
			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
			        .readTimeout(120, TimeUnit.SECONDS).build();
			MediaType mediaType  = null;
			String authorizationHeader = null;
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
//			try {
////				String username = i$impactoUtil.decrypt(reqBodyObj.get("user").getAsString());
////				String password = i$impactoUtil.decrypt(reqBodyObj.get("pass").getAsString());
//				String username = reqBodyObj.get("user").getAsString();
//				String password = reqBodyObj.get("pass").getAsString();
//				
//				authorizationHeader = i$impactoUtil.generateBasicAuth(username, password);
//			}catch(Exception e) {
//				e.printStackTrace();
//			}
//			
			RequestBody reqBody = null;			
			try {
				reqBodyS = gson.toJson(reqObj);
				reqBody = RequestBody.create(mediaType,reqBodyS);
			} catch (Exception Ex) {
				// No Body
				// reqBody = null;
				reqBody = RequestBody.create(null, new byte[0]);  
			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString()+docId);
			ReqBldr.get();
//			ReqBldr.addHeader("Authorization", authorizationHeader);
			for (String headerK : headersObj.keySet()) {
				String headerVal = headersObj.get(headerK).getAsString();
				ReqBldr.addHeader(headerK, headerVal);
			}			
			
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
			resBody= response.body().string(); 
			JResp = parser.parse(resBody).getAsJsonObject();
			
			argJson = new JsonObject(); 
			reqBody = null;  
	        System.gc(); 

			return (JResp);
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public ILogicalDocController() {
		// constructor
	}
}
//#YPR00044 Ends