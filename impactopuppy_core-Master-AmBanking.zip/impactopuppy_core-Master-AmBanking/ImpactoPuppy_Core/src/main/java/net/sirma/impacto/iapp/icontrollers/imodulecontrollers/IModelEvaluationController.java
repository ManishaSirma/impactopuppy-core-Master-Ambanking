/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 08, 2019 | #BVB00052   | Initial writing
      |0.2.1       | Vijay 		| Feb 12, 2019 | #BVB00056   | Added Query and Response format Changed for Scanning
      |0.2.1       | Vijay 		| Mar 06, 2019 | #BVB00086   | MODEL_CLASS and Color Code in response of Risk Scan
      |0.3.6       | Vijay 		| Apr 15, 2019 | #BVB00116   | modelType will now come from Request unlike previous hard coding
      |0.3.6       | Samadhan   | mar 10, 2022 | #SRP00051   | Added code Update ScanId
      |0.3.6	   | Manikanta  | May 25, 2022 | #MVT00058   | Added code for risc profiling of existing customer
      |0.3.6       | Samadhan   | Jul 05, 2022 | #SRP00075   | Added Code For Risk Profiling Alert And Notification
      |0.3.6	   | Manikanta  | Jul 12, 2022 | #MVT00063   | Added code for risk profile rule engine
      |0.3.6 	   | Manikanta  | Sep 13, 2022 | #MVT00076   | Added code to handle description in response
      |0.3.6       | Manikanta  | Sep 19, 2022 | #MVT00077   | Added code To Handle Projections
      |0.3.6       | Pavithra   | Sep 27, 2023 | #PAV00017   | Handled Changes of 12 parameters of KYC_AML Changes
      |0.3.6       | Pavithra   | Oct 06, 2023 | #PAV00019   | Risk Profiling job optimization changes
      ----------------------------------------------------------------------------------------------
*/
// #BVB00050 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;

public class IModelEvaluationController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IModelEvaluationController.class);
	private ISdnScanWorker i$sdnScanWorker = new ISdnScanWorker();
	private Ioutils I$Ioutils = new Ioutils();
	private IEmailService i$Email = new IEmailService();
	private ISmsService I$ISmsService = new ISmsService();
	
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OB2EVALM") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = evaluateModel(isonMsg);
				// #BVB00056 Starts
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OB2EVALM") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = RiskQuery(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "RISK_REPORT")) {//#SRP00075 Starts
				isonMsg = riskProfilingReport(isonMsg);//#SRP00075 Ends
			}
			// #BVB00056 Ends
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject evaluateModel(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject i$body = new JsonObject();
		JsonObject projection = new JsonObject();
		double finalValue = 0.0;
		JsonObject i$rating = new JsonObject();
		String i$scoreId = "";
		JsonObject i$score = new JsonObject();
		int i$ratingValue = 0;
		JsonArray i$indvidualWeights = new JsonArray();
		JsonObject i$res = new JsonObject();
		JsonObject i$dataSheet = new JsonObject();
		String referenceNo = "";
		String applicationId = "";
		String modelType = ""; // #BVB00116
		JsonObject i$scoreModel = new JsonObject(); 
		try {
			i$body = i$ResM.getBody(isonMsg);
			i$dataSheet = i$ResM.getBodyElementO(isonMsg, "dataSheet");
			referenceNo = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			applicationId = i$ResM.getBodyElementS(isonMsg, "applicationId");
			modelType = i$ResM.getBodyElementS(isonMsg, "modelType");// #BVB00116
			
			filter.addProperty("riskMapName", modelType);	//#MVT00063 Changes starts
			filter.addProperty("authStat", "A");
			JsonObject risk$MapDetails = db$Ctrl.db$GetRow("ICOR_M_RISk_MATRIX", filter);
			// dataSheetRunId = i$ResM.getBodyElementS(isonMsg, "dataSheetRunId");

//			filter = new JsonObject();
//			filter.addProperty("typeOfDisclosure", "QL");
//			JsonObject icorMScoreQL = db$Ctrl.db$GetRow("ICOR_M_SCORE_MODEL", filter);
//
//			filter = new JsonObject();
//			filter.addProperty("typeOfDisclosure", "QN");
//			JsonObject icorMScoreQN = db$Ctrl.db$GetRow("ICOR_M_SCORE_MODEL", filter);

			filter = new JsonObject();
			// filter.addProperty("modelType", "RP");// #BVB00116
			//filter.addProperty("modelType", modelType); // #BVB00116
//			filter.addProperty("rankModelID", "RANK004");//riskmapdetails .get (rankmodelid)
			filter.addProperty("rankModelID", risk$MapDetails.get("rankModelID").getAsString());
			JsonObject icorMRank = db$Ctrl.db$GetRow("ICOR_M_RANK_MODEL", filter);

			/*
			 * filter = new JsonObject(); filter.addProperty("", ""); // TO DO i$dataSheet =
			 * db$Ctrl.db$GetRow(dataSheetRunId, gson.toJson(filter));
			 */
			projection.addProperty("preDefVal", 1); //#MVT00077 Changes
			JsonObject i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);
			// Code for Model Based
			String modelValue = i$ResM.getBodyElementS(isonMsg, "value");
			// Get the Model Data from ICOR_M_IFRS_DATA_MODEL Collection
			JsonObject icorMDataModel = new JsonObject();
			filter = new JsonObject();
			// filter.addProperty("modelId", modelValue);
//			filter.addProperty("modelType", modelType); // #BVB00116
//			filter.addProperty("modelId", "TECURISKMODEL");//
			filter.addProperty("modelId", risk$MapDetails.get("modelId").getAsString());	//#MVT00063 Changes ends
			icorMDataModel = db$Ctrl.db$GetRow("ICOR_M_DATA_MODEL", filter);
			// Based on the fields involved in data model collecting all details to do the
			// weighted average
			JsonArray i$weights = icorMDataModel.get("weights").getAsJsonArray();

			for (int k = 0; k < i$weights.size(); k++) {
				JsonObject i$runningObjWeights = i$weights.get(k).getAsJsonObject();
				JsonArray i$subWeights = new JsonArray();
				i$subWeights = i$runningObjWeights.getAsJsonArray("subWeights");

				for (int l = 0; l < i$subWeights.size(); l++) {
					JsonObject i$runningObjSub = new JsonObject();
					i$runningObjSub = i$subWeights.get(l).getAsJsonObject();
					String i$dataFormulaId = i$runningObjSub.get("dataFormulaId").getAsString();
					filter = new JsonObject();
					filter.addProperty("dataFormulaId", i$dataFormulaId);
					double i$subWeight = i$runningObjSub.get("weight").getAsDouble();
					JsonObject icorMDataFormula = db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA", filter);

					JsonArray i$resultant = icorMDataFormula.getAsJsonArray("resultant");
					String i$typeOfDisclosure = icorMDataFormula.get("typeOfDisclosure").getAsString();

					if (I$utils.$iStrFuzzyMatch(i$typeOfDisclosure, "QN")) {

						// replace formula with actual data

						JsonArray i$valueFormula = i$impactoUtil.replaceFormula(i$resultant, i$dataSheet,
								i$Param.get("preDefVal").getAsJsonArray());

						// Evaluate the infix with data

						finalValue = i$impactoUtil.evaluateInfix(i$valueFormula,
								i$Param.get("preDefVal").getAsJsonArray());
						// get the rating of the value came above

						icorMDataFormula.addProperty("value", finalValue);
						i$rating = i$impactoUtil.getRating(icorMDataFormula);

						// get the Score ID defined at the formula level and get the ratingValue
						// defined
						// at SCOREID level

						i$scoreId = icorMDataFormula.get("scoreId").getAsString();
						filter = new JsonObject(); 
						filter.addProperty("scoreId", i$scoreId);
						i$scoreModel = db$Ctrl.db$GetRow("ICOR_M_SCORE_MODEL", filter);
						i$scoreModel.addProperty("value", i$rating.get("rating").getAsString());
						i$score = i$impactoUtil.getScore(i$scoreModel);
						i$ratingValue = i$score.get("ratingValue").getAsInt();

					} else {
						icorMDataFormula.addProperty("value", i$dataSheet.get(i$dataFormulaId).getAsString());
						i$rating = i$impactoUtil.getRating(icorMDataFormula);

						// get the Score ID defined at the formula level and get the ratingValue
						// defined
						// at SCOREID level

						i$scoreId = icorMDataFormula.get("scoreId").getAsString();

						filter = new JsonObject(); 
						filter.addProperty("scoreId", i$scoreId);
						i$scoreModel = db$Ctrl.db$GetRow("ICOR_M_SCORE_MODEL", filter);
						i$scoreModel.addProperty("value", i$rating.get("rating").getAsString());
						//icorMScoreQL.addProperty("value", i$rating.get("rating").getAsString());
						i$score = i$impactoUtil.getScore(i$scoreModel);
						i$ratingValue = i$score.get("ratingValue").getAsInt();
					}

					double finalWeight = (i$ratingValue * i$subWeight) / 100;
					JsonObject i$runningIndWe = new JsonObject();
					i$runningIndWe.addProperty("dataFormulaId", i$dataFormulaId);
					i$runningIndWe.addProperty("weight", i$subWeight);
					i$runningIndWe.addProperty("value", finalWeight);
					i$indvidualWeights.add(i$runningIndWe);

				}

			}

			// get the final value from i$indvidualWeights
			finalValue = 0;
			for (int m = 0; m < i$indvidualWeights.size(); m++) {
				finalValue = finalValue + i$indvidualWeights.get(m).getAsJsonObject().get("value").getAsInt();
			}

			icorMRank.addProperty("value", I$utils.round(finalValue, 2));

			// icorMRank.addProperty("value", i$ratingValue);
			JsonObject i$rank = i$impactoUtil.getRank(icorMRank);

			// Get finalValue and rating from i$rank

			i$res = new JsonObject();
			i$res.addProperty("applicationId", applicationId);
			i$res.addProperty("referenceNo", referenceNo);
			// #BVB00056 Starts
			i$res.addProperty("ScanType", "RiskProfiling");
			i$res.addProperty("ScanId", i$impactoUtil.generateRandomKey());
			// #BVB00056 Ends
			double roundedFinalVal = I$utils.round(finalValue, 2);
			i$res.addProperty("MODEL_VALUE", roundedFinalVal);
			i$res.addProperty("MODEL_RATING", i$rank.get("rating").getAsString());
			// #BVB00086 starts
			String scoreClass ;
			if (I$utils.$iStrFuzzyMatch(modelType, "TECU_RP")){
				scoreClass = i$sdnScanWorker.scoreClass("TECU_RP", roundedFinalVal);
				if (scoreClass.equals("High")) {
					i$res.addProperty("MODEL_COLOR", "Light Red");
		 		} else if (scoreClass.equals("Medium")) {
					i$res.addProperty("MODEL_COLOR", "Light Yellow");
				} else if (scoreClass.equals("Low")) {
					i$res.addProperty("MODEL_COLOR", "Light Green");
				}
			} else {
				scoreClass = i$sdnScanWorker.scoreClass("DEDUP", roundedFinalVal);
				i$res.addProperty("MODEL_COLOR", i$sdnScanWorker.colorCode(scoreClass));
			}
			i$res.addProperty("MODEL_CLASS", scoreClass); 
			// #BVB00086 Ends
			i$res.add("INDIVIDUAL_WEIGHT", i$indvidualWeights);
			filter = new JsonObject();//#SRP00051 Starts
			filter.addProperty("applicationId", applicationId);
			db$Ctrl.db$UpdateRow("ICOR_M_RISK_SCAN", i$res,filter,"true");//#SRP00051 Ends

			// #BVB00056 Starts
			JsonObject i$resF = new JsonObject();
			i$resF.addProperty("ScanType", i$res.get("ScanType").getAsString());
			i$resF.addProperty("ScanId", i$res.get("ScanId").getAsString());

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resF);
			// #BVB00056 Ends

		} catch (Exception e) {
			logger.debug("Failed in Risk Profiling with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed in During Model Eval");
		}

		return isonMsg;
	}
	//#MVT00058 starts
	public JsonObject evaluateExistingCustomer(JsonObject isonMsg) {
		JsonObject i$res = new JsonObject();
		try {
			JsonObject filter = new JsonObject(); //PAV00019 Changes
			JsonObject i$body = new JsonObject();
			JsonObject projection = new JsonObject();
			double finalValue = 0.0;
			JsonObject i$rating = new JsonObject();
			String i$scoreId = "";
			JsonObject i$score = new JsonObject();
			int i$ratingValue = 0;
			JsonArray i$indvidualWeights = new JsonArray();
			JsonObject i$dataSheet = new JsonObject();
			String customerFullName = "";
			String customerId = "";
			String modelType = "";
			JsonObject i$scoreModel = new JsonObject(); 
			i$body = i$ResM.getBody(isonMsg);
			i$dataSheet = i$ResM.getBodyElementO(isonMsg, "dataSheet");
			customerFullName = i$ResM.getBodyElementS(isonMsg, "CustomerFullName");
			customerId = i$ResM.getBodyElementS(isonMsg, "CustomerId");
			modelType = i$ResM.getBodyElementS(isonMsg, "modelType");
			
			filter.addProperty("riskMapName", modelType);	//#MVT00063 Changes starts
			filter.addProperty("authStat", "A");
			JsonObject risk$MapDetails = db$Ctrl.db$GetRow("ICOR_M_RISk_MATRIX", filter);

			filter = new JsonObject();
//			filter.addProperty("modelType", modelType);
			filter.addProperty("rankModelID", risk$MapDetails.get("rankModelID").getAsString());
			JsonObject icorMRank = db$Ctrl.db$GetRow("ICOR_M_RANK_MODEL", filter);

			projection.addProperty("preDefVal", 1);
			JsonObject i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);
			// Code for Model Based
			String modelValue = i$ResM.getBodyElementS(isonMsg, "value");
			// Get the Model Data from ICOR_M_IFRS_DATA_MODEL Collection
			JsonObject icorMDataModel = new JsonObject();
			filter = new JsonObject();
			// filter.addProperty("modelId", modelValue);
//			filter.addProperty("modelType", modelType); // #BVB00116
			filter.addProperty("modelId", risk$MapDetails.get("modelId").getAsString());	//#MVT00063 Changes ends
			icorMDataModel = db$Ctrl.db$GetRow("ICOR_M_DATA_MODEL", filter);
			String tWeight=icorMDataModel.get("qnWeight").getAsString();//#PAV00017 Changes
			// Based on the fields involved in data model collecting all details to do the
			// weighted average
			JsonArray i$weights = icorMDataModel.get("weights").getAsJsonArray();

			for (int k = 0; k < i$weights.size(); k++) {
				try {
				JsonObject i$runningObjWeights = i$weights.get(k).getAsJsonObject();
				JsonArray i$subWeights = new JsonArray();
				i$subWeights = i$runningObjWeights.getAsJsonArray("subWeights");

				for (int l = 0; l < i$subWeights.size(); l++) {
					try {
					JsonObject i$runningObjSub = new JsonObject();
					i$runningObjSub = i$subWeights.get(l).getAsJsonObject();
					String i$dataFormulaId = i$runningObjSub.get("dataFormulaId").getAsString();
					filter = new JsonObject();
					filter.addProperty("dataFormulaId", i$dataFormulaId);
					double i$subWeight = i$runningObjSub.get("weight").getAsDouble();
					JsonObject icorMDataFormula = db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA", filter);

					JsonArray i$resultant = icorMDataFormula.getAsJsonArray("resultant");
					String i$typeOfDisclosure = icorMDataFormula.get("typeOfDisclosure").getAsString();

					if (I$utils.$iStrFuzzyMatch(i$typeOfDisclosure, "QN")) {

						// replace formula with actual data

						JsonArray i$valueFormula = i$impactoUtil.replaceFormula(i$resultant, i$dataSheet,
								i$Param.get("preDefVal").getAsJsonArray());

						// Evaluate the infix with data

						finalValue = i$impactoUtil.evaluateInfix(i$valueFormula,
								i$Param.get("preDefVal").getAsJsonArray());
						// get the rating of the value came above

						icorMDataFormula.addProperty("value", finalValue);
						i$rating = i$impactoUtil.getRating(icorMDataFormula);

						// get the Score ID defined at the formula level and get the ratingValue
						// defined
						// at SCOREID level

						i$scoreId = icorMDataFormula.get("scoreId").getAsString();
						filter = new JsonObject(); 
						filter.addProperty("scoreId", i$scoreId);
						i$scoreModel = db$Ctrl.db$GetRow("ICOR_M_SCORE_MODEL", filter);
						i$scoreModel.addProperty("value", i$rating.get("rating").getAsString());
						i$score = i$impactoUtil.getScore(i$scoreModel);
						i$ratingValue = i$score.get("ratingValue").getAsInt();

					} else {
						icorMDataFormula.addProperty("value", i$dataSheet.get(i$dataFormulaId).getAsString());
						i$rating = i$impactoUtil.getRating(icorMDataFormula);

						// get the Score ID defined at the formula level and get the ratingValue
						// defined
						// at SCOREID level

						i$scoreId = icorMDataFormula.get("scoreId").getAsString();

						filter = new JsonObject(); 
						filter.addProperty("scoreId", i$scoreId);
						i$scoreModel = db$Ctrl.db$GetRow("ICOR_M_SCORE_MODEL", filter);
						i$scoreModel.addProperty("value", i$rating.get("rating").getAsString());
						//icorMScoreQL.addProperty("value", i$rating.get("rating").getAsString());
						i$score = i$impactoUtil.getScore(i$scoreModel);
						i$ratingValue = i$score.get("ratingValue").getAsInt();
					}

					//double finalWeight = (i$ratingValue * i$subWeight) / 100;
					double finalWeight = i$ratingValue;//#PAV00017 Changes
					JsonObject i$runningIndWe = new JsonObject();
					i$runningIndWe.addProperty("dataFormulaId", i$dataFormulaId);
					i$runningIndWe.addProperty("weight", i$subWeight);
					i$runningIndWe.addProperty("value", finalWeight);
					i$runningIndWe.addProperty("Description", i$dataSheet.get(i$dataFormulaId).getAsString());	//#MVT00076 Changes 
					i$indvidualWeights.add(i$runningIndWe);
				}catch(Exception e) {
					e.printStackTrace();
				}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
				
			}

			// get the final value from i$indvidualWeights
			finalValue = 0;
			for (int m = 0; m < i$indvidualWeights.size(); m++) {
				finalValue = finalValue + i$indvidualWeights.get(m).getAsJsonObject().get("value").getAsInt();
			}
			icorMRank.addProperty("value", I$utils.round(finalValue, 2));
			// icorMRank.addProperty("value", i$ratingValue);
			JsonObject i$rank = i$impactoUtil.getRank(icorMRank);

			// Get finalValue and rating from i$rank
			i$res = new JsonObject();
			i$res.addProperty("CustomerFullName", customerFullName);
			i$res.addProperty("CustomerId", customerId);
			i$res.addProperty("ScanType", "RiskProfiling");
			double roundedFinalVal = I$utils.round(finalValue, 2);
			i$res.addProperty("MODEL_VALUE", roundedFinalVal);
			i$res.addProperty("MODEL_RATING", i$rank.get("rating").getAsString());
			String scoreClass ;
			if (I$utils.$iStrFuzzyMatch(modelType, "TECU_RP")){
				scoreClass = i$sdnScanWorker.scoreClass("TECU_RP", roundedFinalVal);
				if (scoreClass.equals("High")) {
					i$res.addProperty("MODEL_COLOR", "Light Red");
		 		} else if (scoreClass.equals("Medium")) {
					i$res.addProperty("MODEL_COLOR", "Light Yellow");
				} else if (scoreClass.equals("Low")) {
					i$res.addProperty("MODEL_COLOR", "Light Green");
				}
			} else {
				scoreClass = i$sdnScanWorker.scoreClass("DEDUP", roundedFinalVal);
				i$res.addProperty("MODEL_COLOR", i$sdnScanWorker.colorCode(scoreClass));
			}
			i$res.addProperty("CompletedTime", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			i$res.addProperty("MODEL_CLASS", scoreClass); 
			i$res.add("INDIVIDUAL_WEIGHT", i$indvidualWeights);
			i$res.addProperty("totalWeight", tWeight);//#PAV00017 Changes
/*			filter = new JsonObject();//#SRP00051 Starts
			filter.addProperty("CustomerId", customerId);
			db$Ctrl.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN", i$res,filter,"true");//#SRP00051 Ends

			JsonObject i$resF = new JsonObject();
			i$resF.addProperty("ScanType", i$res.get("ScanType").getAsString());
			i$resF.addProperty("ScanId", i$res.get("ScanId").getAsString());

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resF);*/

		} catch (Exception e) {
			logger.debug("Failed in Risk Profiling with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed in During Model Eval");
		}

		return i$res;
	}//#MVT00058 ends
	// #BVB00056 Starts
	public JsonObject RiskQuery(JsonObject isonMsg) {
		JsonObject icorMRisk = new JsonObject();
		JsonObject filter = new JsonObject();
		try {

			String ScanId = i$ResM.getBodyElementS(isonMsg, "ScanId");
			filter.addProperty("ScanId", ScanId);

			icorMRisk = db$Ctrl.db$GetRow("ICOR_M_RISK_SCAN", filter);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorMRisk);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
		} catch (Exception e) {
			// TODO: handle exception
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
		}

		return isonMsg;

	}
	private JsonObject riskProfilingReport(JsonObject isonMsg) {//#SRP00075 Starts
		try {
			JsonObject date = new JsonObject();
			JsonObject preFilter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonArray preFilter2 = new JsonArray();
			JsonObject projection = new JsonObject();
			JsonObject ScanId=new JsonObject();
			//JsonObject modelClass=new JsonObject();
			JsonObject filter2=new JsonObject();
			JsonObject projection1=new JsonObject();
			JsonObject attachmentData = new JsonObject();
			Date grtrDate = I$utils.changeDate(1, "SUB", "D");
			Date lsrDate = I$utils.changeDate(0, "SUB", "D");
			String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
			date.add("$gt", iso$date);
			preFilter.add("initiatedTime", date);
			//preFilter.add("ScanId", ScanId);
			iso$date = Ioutils.dateFromatter(lsrDateS);
			date.add("$lte", iso$date);
			preFilter.add("initiatedTime", date);
			preFilter2.add(preFilter);
			filter.add("$or", preFilter2);
			//filter2.add("ScanId", ScanId);
			filter2.addProperty("MODEL_CLASS", "High");
			projection.addProperty("initiatedTime", 1);
			projection.addProperty("RiscProfiling.High", 1);
			projection.addProperty("RiscProfiling.Low", 1);
			projection.addProperty("RiscProfiling.Medium", 1);
			projection.addProperty("TotalScannedRecordsCount", 1);
			//projection.addProperty("amlCheck", 1);
			projection.addProperty("_id", 0);
			projection1.addProperty("CustomerId", 1);
			projection1.addProperty("_id", 0);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_M_EXIT_RISK_SCAN_LOG", filter, projection);
			JsonArray i$Body1=db$Ctrl.db$GetRows("ICOR_M_EXIT_RISK_SCAN", filter2, projection1);
			i$Body.get(0).getAsJsonObject().addProperty("CustomerId" , i$Body1.get(0).getAsJsonObject().get("CustomerId").getAsString());
			int size = i$Body.size();
			StringBuilder pdf$Content = new StringBuilder();
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject db$Doc = i$Body.get(i).getAsJsonObject();
					JsonObject projectionKeys=new JsonObject();
					projectionKeys.addProperty("Risk Profiling Date", db$Doc.get("initiatedTime").getAsString());
					projectionKeys.addProperty("Total No of Scanned Records", db$Doc.get("TotalScannedRecordsCount").getAsString());
					projectionKeys.addProperty("Risk Level High", db$Doc.get("RiscProfiling").getAsJsonObject().get("High").getAsString());
					projectionKeys.addProperty("Risk Level Medium", db$Doc.get("RiscProfiling").getAsJsonObject().get("Medium").getAsString());
					projectionKeys.addProperty("Risk Level Low", db$Doc.get("RiscProfiling").getAsJsonObject().get("Low").getAsString());
					projectionKeys.addProperty("CustomerId", db$Doc.get("CustomerId").getAsString());
					Set<String> keys = projectionKeys.keySet();
					for (String key : keys) {
						try {
							String val = projectionKeys.get(key).getAsString();
							pdf$Content = pdf$Content.append(key + " : " + val + "\n");
						} catch (Exception e) {
						}
					}
					pdf$Content.append("\n");
				} catch (Exception e) {
				}
			}
			if(pdf$Content.length() <= 0) {
				pdf$Content.append("No Record found.");
			}
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
			PdfWriter.getInstance(document, byteArrayOutputStream);
			document.open();
			Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
			Paragraph para = new Paragraph(pdf$Content.toString(), font);
			para.setLeading(0, 1);
//			 Chunk glue = new Chunk(new VerticalPositionMark());
			PdfPTable table = new PdfPTable(1);
			table.setWidthPercentage(95);
			PdfPCell cell = new PdfPCell();
			// cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell.setBorderColor(BaseColor.DARK_GRAY);
			// PdfPCell cell2 = new PdfPCell();
			Font font2 = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
		//	i$ResM.getdateTime(new Date());
			Paragraph para2 = new Paragraph("Alert For Risk Profiling", font2);
			Paragraph para3 = new Paragraph();
			para3.setFont(font);
			// para3.add("ref : ");
			// para3.add(refNo+"\n");
			para3.add("Risk Profiling Run Date : ");//#SRP00072 Changes
//			para3.add(new Phrase(DateTime.now().toString("MMM dd, YYYY hh:mm:ss")));
			para3.add(new Phrase(I$Ioutils.$getISONow().replace("T", ", ").replace("Z", "")));
			Paragraph para4 = new Paragraph("  ", font);
			para3.setAlignment(Element.ALIGN_RIGHT);
			para2.setAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(50);
			cell.setPadding(5);
			cell.setPaddingTop(10);
			cell.setVerticalAlignment(Element.ALIGN_LEFT);
			cell.addElement(para2);
			cell.addElement(para3);
			cell.addElement(para4);
			cell.addElement(para);
//			cell.setTextAlignment(TextAlignment.CENTER);
			// cell.setHorizontalAlignment(0);
//			 cell.addElement(para2);
			table.addCell(cell);
			document.add(table);
			document.close();
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
			attachmentData.addProperty("docType", "application/pdf");
			attachmentData.addProperty("fileName", "Risk Profiling report" + ".pdf");
			attachmentData.addProperty("template", base64Str);
			JsonObject dataSetFilter = new JsonObject();
			JsonObject datasetProjection = new JsonObject();
			JsonObject emailDataset$Data = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
			dataSetFilter.addProperty("datasetId", "Dataset_5679");
			datasetProjection.addProperty("userDetails", 1);
			datasetProjection.addProperty("sendEmail", 1);
			datasetProjection.addProperty("sendSms", 1);
			emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
			if (!I$utils.$isNull(emailDataset$Data)) {
				JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
				boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
				boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
				for (int i = 0; i < userDet.size(); i++) {
					try {
						if (sendEmail) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							keyE = keyE.concat(Email);
							if (i < userDet.size() - 1) {
								keyE = keyE.concat(",");
							}
						}
						if (sendSMS) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							keyM = keyM.concat(SMS);
							if (i < userDet.size() - 1) {
								keyM = keyM.concat(",");
							}
						}
					} catch (Exception e) {
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					JsonArray attachment = new JsonArray();
					map$Data.addProperty("tmp$name", "TMPL#TT#RISK#PROFILING#ALERT#MAIL");
					int siz = i$Body.size();
					for (int i = 0; i < i$Body.size(); i++) {
						try {
							JsonObject db$Docs = i$Body.get(i).getAsJsonObject();
					        map$Data.addProperty("TotalScannedRecordsCount", db$Docs.get("TotalScannedRecordsCount").getAsString());
					        map$Data.addProperty("High", db$Docs.get("RiscProfiling").getAsJsonObject().get("High").getAsString());
					        map$Data.addProperty("Medium", db$Docs.get("RiscProfiling").getAsJsonObject().get("Medium").getAsString());
					        map$Data.addProperty("Low", db$Docs.get("RiscProfiling").getAsJsonObject().get("Low").getAsString());
						}catch(Exception e) {}
					}
					argJson.add("map$Data", map$Data);
					argJson.addProperty("key$Type", "notification");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					attachment.add(attachmentData);
					argJson.add("attachment", attachment);
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
						JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
			}
		} catch (Exception e) {
			logger.debug("Error in sending Risk Profiling Alert Notification");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in sending Risk Profiling Alert Notification");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
		
	}//#SRP00075 Ends

	// #BVB00056 Ends
	public IModelEvaluationController() {
		// Cons
	}
}
// #BVB00050 Ends
