/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Valla 		| Jan 09, 2019 | #00000001   | Initial writing
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Jan 17, 2019 | #00000002   | Thread Implementation
      |0.3.15      | Vijay 	    | Jun 20, 2019 | #BVB00173   | Handling of + in the mobile number and capturing SID from Twilio
      |0.4.1.381   | MAQ        | Sep 05,2019  | #MAQ000033  | Failed SMS code fixed
      |0.1 Beta    | Pruthvi    | Mar 09,2021  | #YPR00056   | Added SMS service validations
      |0.1 Beta    | Devraj     | Mar 18,2021  | #DVJ00044   | Retrieving the smssettings from db
      |0.4 Beta    | Pruthvi    | Jun 01,2021  | #YPR00083   | Added SMS service validations on tecu regions
      |0.1 Beta    | Pruthvi    | Jul 07,2021  | #MAQ00131   | Added success msg when SMS disabled
      |0.1 Beta    | Samadhan   | Sep 13,2021  | #SRP00021   | Added Code for Sending SMS to Multiple recipient.
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icommunication.isms;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;


//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicAWSCredentials;
//import com.amazonaws.regions.Regions;
//import com.amazonaws.services.sns.AmazonSNS;
//import com.amazonaws.services.sns.AmazonSNSClient;
//import com.amazonaws.services.sns.model.MessageAttributeValue;
//import com.amazonaws.services.sns.model.PublishRequest;
//import com.amazonaws.services.sns.model.PublishResult;



public class ISmsService {
	private DBController db$Ctrl = new DBController();
	private ImpactoUtil imp$utils = new ImpactoUtil(); 
	private Logger logger = LoggerFactory.getLogger(ISmsService.class);
	private IResManipulator i$ResM = new IResManipulator();
	private JsonObject JSMSArgJson = new JsonObject();
	private Ioutils I$utils = new Ioutils(); 
	
	
	@SuppressWarnings("unused")
	public  void sendSMS(JsonObject argJson) throws TwilioRestException {
		JsonObject statusMsg = new JsonObject();
		try
		{
			argJson.add("globals", i$ResM.getAllGobal());
		    JSMSArgJson = argJson;
	    	triggerSMSThread.start();
	    	
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

		
	};
	
	//00000002 begins
	Thread triggerSMSThread = new Thread(new Runnable(){
	    @Override
		public void run() {
	    	i$ResM.setAllGlobal(JSMSArgJson.getAsJsonObject("globals"));
	    	SendSMSWOThread(JSMSArgJson); 
	    }
	}); //00000002 ends
	
	public JsonObject SendSMSWOThread(JsonObject JSMSArgJson) {

    	String msgBody  = ""; 
    	String mobilenumber = ""; 
    	Boolean smsEnabled = true; // #MAQ00131
    	JsonParser parser = new JsonParser();
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();  
    	try {
    		
    		//#MAQ000033 starts
    		// Check if IPIsAllowed or not.
			// #DVJ00044 Starts
//		 	JsonObject icorCParam = i$ResM.getGobalValJObj("icorCParam");
    		JsonObject icorCParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", 
    				"{'smssettings'=1, 'iOtpSystemValidations'=1, "
    				+ "{'smsEnabled'=1}}"); // #MAQ00131 
			JsonObject sms$cnfdb = icorCParam.get("smssettings").getAsJsonObject();
			JsonObject sysValidations = icorCParam.get("iOtpSystemValidations").getAsJsonObject();
			 // #MAQ00131 starts
			if(icorCParam.has("smsEnabled"))
				smsEnabled = icorCParam.get("smsEnabled").getAsBoolean();
			 // #MAQ00131 ends
			// #DVJ00044 Ends
			
    		JsonObject sms$logger = new JsonObject();
    		JsonObject statusMsg = new JsonObject();
    		//#MAQ000033 ends 
    		
			if (imp$utils.isValIp(sysValidations) && smsEnabled) { //#MAQ00131 changes
    			try {
//    				if (sms$cnfdb.has("AmazonSNSApi")
//    						&& I$utils.$iStrFuzzyMatch(sms$cnfdb.get("AmazonSNSApi").getAsString(), "1")) {    					
//    					JsonObject smsSettings = sms$cnfdb.get("AmazonSNSSettings").getAsJsonObject();
//    					BasicAWSCredentials basicAwsCredentials = new BasicAWSCredentials(smsSettings.get("accessKey").getAsString(),smsSettings.get("secretKey").getAsString());
//    					String Region ;
//    					if(smsSettings.has("smsRegion")) {
//    						Region = smsSettings.get("smsRegion").getAsString();
//    					} else {
//    						Region = "us-west-2";
//    					}
//
//    					AmazonSNS snsClient = AmazonSNSClient
//    					                      .builder()
//    					                      .withRegion(Region)
//    					                      .withCredentials(new AWSStaticCredentialsProvider(basicAwsCredentials))
//    					                      .build();
//    					
//						// read the template form db
//						JsonObject template$Data = JSMSArgJson.get("map$Data").getAsJsonObject();
//						JsonObject i$smsltmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
//								"{ Template_ID: \"" + template$Data.get("tmp$name").getAsString() + "\" }");
//						String message = getFormattedTmpl(i$smsltmpl.get("Sms_Subject").getAsString(), template$Data);
//						
//						
//						// Build a filter for the MessageList
//						JsonObject mob$numbers = JSMSArgJson.get("mobile$numbers").getAsJsonObject();
//			
//						String phoneNumber = mob$numbers.get("Mob_Number1").getAsString();
//						// #BVB00173 Starts 
//						if(!phoneNumber.contains("+") ) {
//							phoneNumber = "+" + phoneNumber;
//						}
//						// #BVB00173 Ends
//    			        
//    			        
//    			        Map<String, MessageAttributeValue> smsAttributes =
//    			                new HashMap<String, MessageAttributeValue>();
//    			        smsAttributes.put("AWS.SNS.SMS.SenderID", new MessageAttributeValue()
//    			                .withStringValue(smsSettings.get("mySenderID").getAsString()) //The sender ID shown on the device.
//    			                .withDataType("String"));
//    			        smsAttributes.put("AWS.SNS.SMS.MaxPrice", new MessageAttributeValue()
//    			                .withStringValue(smsSettings.get("maxPrice").getAsString()) //Sets the max price to 0.50 USD.
//    			                .withDataType("Number"));
//    			        smsAttributes.put("AWS.SNS.SMS.SMSType", new MessageAttributeValue()
//    			                .withStringValue(smsSettings.get("SMSType").getAsString()) //Sets the type to promotional.
//    			                .withDataType("String"));
//    			        
//    			        sms$logger.addProperty("CommunicationMode", "SMS");
//						sms$logger.addProperty("CommunicationAPI", "AWS");
//						sms$logger.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
//						sms$logger.addProperty("CommunicationBody", message);
//						sms$logger.addProperty("Mobile Number", phoneNumber);
//						sms$logger.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
//						sms$logger.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());
//						
//    			        PublishResult result = snsClient.publish(new PublishRequest()
//    			                .withMessage(message)
//    			                .withPhoneNumber(phoneNumber)
//    			                .withMessageAttributes(smsAttributes));
//    			        
//						// Building Logger Json Object
//    			        if(I$utils.$iStrFuzzyMatch(Integer.toString(result.getSdkHttpMetadata().getHttpStatusCode()) , "200")) {
//							sms$logger.addProperty("SID", result.toString()); // #BVB00173 
//							statusMsg.addProperty("i_SUCC", "SMS Successfully Sent");
//			
//							sms$logger.add("StatusMsg", statusMsg);
//							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Successfully Sent");
//						} else {
//							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SMS Sending Failed ");
//							sms$logger.addProperty("StatusMsg", "SMS Sending Failed ");
//						}
//						// log details to logger
//						db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger);
//   				} else 
    				if (sms$cnfdb.has("TwilioApi")
    						&& I$utils.$iStrFuzzyMatch(sms$cnfdb.get("TwilioApi").getAsString(), "1")) {    					
    					JsonObject smsSettings = sms$cnfdb.get("TwilioApiSettings").getAsJsonObject();
						// Instantiate twilio adapter
						TwilioRestClient client = new TwilioRestClient(smsSettings.get("Account SID").getAsString(),
								smsSettings.get("Auth Token").getAsString());
			
						// Build a filter for the MessageList
						JsonObject mob$numbers = JSMSArgJson.get("mobile$numbers").getAsJsonObject();
			
						JsonObject template$Data = JSMSArgJson.get("map$Data").getAsJsonObject();
						mobilenumber = mob$numbers.get("Mob_Number1").getAsString();
						// read the template form db
						JsonObject i$smsltmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
								"{ Template_ID: \"" + template$Data.get("tmp$name").getAsString() + "\" }");
			
						msgBody = getFormattedTmpl(i$smsltmpl.get("Sms_Subject").getAsString(), template$Data);
			
						// Building Logger Json Object						
						sms$logger.addProperty("CommunicationMode", "SMS");
						sms$logger.addProperty("CommunicationAPI", "Twilio");
						sms$logger.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
						sms$logger.addProperty("CommunicationBody", msgBody);
						sms$logger.addProperty("Mobile Number", mobilenumber);
						sms$logger.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
						sms$logger.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());
			
						// #SRP00021 Starts
						try {
							// Trigger the otp sending
							MessageFactory messageFactory = client.getAccount().getMessageFactory();
							String msgSids = "";
							String[] mobilenumbers = mobilenumber.split(",");
							for (int i = 0; i < mobilenumbers.length; i++) {
								if (!mobilenumbers[i].contains("+")) {
									mobilenumbers[i] = "+" + mobilenumbers[i];
								}
								List<NameValuePair> params = new ArrayList<NameValuePair>();
								params.add(new BasicNameValuePair("Body", msgBody));
								String mobNum = mobilenumbers[i];
								params.add(new BasicNameValuePair("To", mobNum));// Add real number here
								// #YPR00083 Starts
								if (mobNum.matches("^(\\+1868)[0-9]{7}$")) {
									params.add(new BasicNameValuePair("From",
											smsSettings.get("Carrier NumberT").getAsString()));
								} else {
									params.add(new BasicNameValuePair("From",
											smsSettings.get("Carrier Number").getAsString()));
								}
								// #YPR00083 Ends
								Message message = messageFactory.create(params);
								msgSids = msgSids + message.getSid() + ",";
							}
							sms$logger.addProperty("SID", msgSids);
						} catch (Exception e) {
						} // #SRP00021 Ends
						 // #BVB00173 
						statusMsg.addProperty("i_SUCC", "SMS Successfully Sent");
		
						sms$logger.add("StatusMsg", statusMsg);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Successfully Sent");
						// log details to logger
						db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger);
    				}
	
				} catch (Exception e) {
					//#MAQ000033 starts
	//				statusMsg.addProperty("i_ERROR", "Email Sent Failed");
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SMS Sending Failed "+ e.getMessage());
					sms$logger.addProperty("StatusMsg", "SMS Sending Failed " + e.getMessage());
					//#MAQ000033 ends
					db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger);
	
					e.printStackTrace();
	
				}
    		// #MAQ00131 starts
			} else if (!smsEnabled){
				sms$logger.addProperty("CommunicationMode", "SMS");
				sms$logger.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
				sms$logger.addProperty("CommunicationBody", msgBody);
				sms$logger.addProperty("Mobile Number", mobilenumber);
				sms$logger.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
				sms$logger.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());
				sms$logger.addProperty("StatusMsg", "SMS settings disabled, default success msg shown");
				//#MAQ000033 ends
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Successfully Sent via Impacto");
				db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger); 
			}  // #MAQ00131 ends
			else {
				//#MAQ000033 starts
//				statusMsg.addProperty("i_ERROR", "Email Sent Failed");
				sms$logger.addProperty("CommunicationMode", "SMS");
				sms$logger.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
				sms$logger.addProperty("CommunicationBody", msgBody);
				sms$logger.addProperty("Mobile Number", mobilenumber);
				sms$logger.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
				sms$logger.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());

				sms$logger.addProperty("StatusMsg", "IP Address Validation Failed");
				//#MAQ000033 ends
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SMS Service Disabled. Contact Admin");
				db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger); 
				 
			}
    	} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SMS sending failed with: " + e.getMessage());
			
		}
    	return isonMsg; 
	

	}
	
	@SuppressWarnings("unused")
	private String getFormattedTmpl(String sTmpl, JsonObject J$vals) {
		try {
			Map<String, Object> attributes = new HashMap<String, Object>();
			Set<Entry<String, JsonElement>> entrySet = J$vals.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = "#" + entry.getKey() + "#";
				strVal = J$vals.get(entry.getKey()).getAsString();
				sTmpl = sTmpl.replaceAll(strKey, strVal);
			}
		} catch (Exception ex) {

		}
		return sTmpl;
	}

	public ISmsService() {
		super();
		// TODO Auto-generated constructor stub
	}
}
//#00000001 Ends