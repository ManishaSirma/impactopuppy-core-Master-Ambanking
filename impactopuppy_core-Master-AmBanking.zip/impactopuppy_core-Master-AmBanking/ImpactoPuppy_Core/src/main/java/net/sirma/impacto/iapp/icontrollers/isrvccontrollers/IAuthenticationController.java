/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Syed 		| Feb 4,  2021  | #MAQ00098   | Initial writing
      |0.1 Beta    | Pruthvi 	| Feb 8,  2021  | #YPR00047   | Added returning Incomplete Application changes
      |0.1 Beta    | Pruthvi 	| Feb 11, 2021  | #YPR00049   | Added returning Completed Application & login   
      |0.1 Beta    | Pappu 	    | Jul 22, 2021  | #PKY00027   | Added AddressForCorrespondence, Customer firstName and lastName for cifAuthorize
      |0.1 Beta    | Sushmita   | Aug 16, 2021  | #SKP00001   | Added code for Tatil incomplete application 
      |0.1 Beta    | Tarun      | Sep 21, 2021  | #TKS00004   | Added code for Loan incomplete application 
      |0.1 Beta    | Pappu      | Sep 28, 2021  | #PKY00049   | Handled second time digiApp registration with changed and same imei
      |0.1 Bets	   | Manikanta  | Dec 07, 2021  | #MVT00021   | Added code for Digi re register Updating mpin
      |0.1 Beta    | Samadhan   | Dec 14, 2021  | #SRP00042   | Added Code for IMB Integrationss
      |0.1 Beta    | Sushmita   | Apr 25, 2022  | #SKP00002   | Handled mpin issue and added new service to check if cif registered
      |0.1 Beta    | Sushmita   | May 05, 2022  | #SKP00003   | added new screen to unlinked Devices
      |0.1 Beta    | Sushmita   | Aug 30, 2022  | #SKP00004   | Added code for reset service in digiap 
      |0.1 Beta    | Tarun      | Oct 3, 2022   | #TKS00019   | Added code for reset imecd in digiap
      |0.1 Beta    | Manikanta  | Feb 21, 2023  | #MVT00106   | Added code to update mpin date and to send reset mpin alert error
      |0.1 Beta	   | Manikanta  | Feb 28, 2023  | #MVT00108   | Added code to handle maximum login attempts	
      |0.1 Beta	   | Sindhu     | May 02, 2023  | #SRM00035   | Added code to validate specific customerCategory numbers
      |0.1 Beta	   | Manikanta  | May 09, 2023  | #MVT00114   | Added code to change error message for digi login
      |0.1 Beta	   | Manikanta  | May 15, 2023  | #MVT00115   | Added code to validate mpin while updating imecd#MVT00116
      |0.1 Beta	   | Manikanta  | May 22, 2023  | #MVT00116   | Added code to update sessionId and imecd in db
      |0.1 Beta	   | Manikanta  | May 01, 2023  | #MVT00122   | Added code to handle failed login attemppts and reset mpin
      |0.1 Beta    | Manikanta  | Jun 12, 2023  | #MVT00123   | Added code to handle incomplete applications issues
      |0.1 Beta    | Manikanta  | Jul 04, 2023  | #MVT00126   | Added code to Customer category from flexcube
      |0.1 Beta    | Manikanta  | Jul 17, 2023  | #MVT00129   | Added code to send email for customer not having category access
      |0.1 Beta    | Manikanta  | Nov 07, 2023  | #PAV00029   | Added code to updatestatus for Digi user
      |0.1 Beta    | Pavithra   | Dec 21, 2023  | #PAV00034   | Handled code changes required while activating digi user from backoffice
----------------------------------------------------------------------------------------------
      
*/
// #MAQ00098 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.*;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ialgo.RSAAsymetricCrypt;
import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.*;

public class IAuthenticationController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil Im$utils = new ImpactoUtil();
	private Logger logger = LoggerFactory.getLogger(IAuthenticationController.class);
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private OtpController otpCtrl = new OtpController();
	private IEmailService i$Email = new IEmailService();
	private GenericAppController i$generic = new GenericAppController();
	private IFuncSrvcController i$FunC = new IFuncSrvcController();
	private RSAAsymetricCrypt I$Crypt = new RSAAsymetricCrypt();
	private static RSAAsymetricCrypt rsaAsymCrypt = new RSAAsymetricCrypt();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String scrOpr = i$ResM.getOpr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			logger.info("WelCome to Customer Login Controller");
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "LOGIN")) {
				isonMsg = guestLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "MEM_LOGIN")) {
				isonMsg = memberLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "INC_LOGIN")) {
				isonMsg = inCompletedUserLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "INCTATIL_LOGIN")) {
				isonMsg = inCompletedTatilUserLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "INCLOAN_LOGIN")) {
				isonMsg = inCompletedLoanUserLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "CAP_LOGIN")) {
				isonMsg = appCompletedUserLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_REGISTER")) {
				isonMsg = digiRegister(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_LOGIN")) {
				isonMsg = digiLogin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_REREGISTER")) {
				isonMsg = digiReRegister(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_MPIN")) {
				isonMsg = setMPin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGIRESET_MPIN")) {
				isonMsg = resetMPin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGIRESET_IME")) {
				isonMsg = resetIMECD(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "CIF_AUTH")) {
				isonMsg = cifAuthorize(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_IMEI")) { // SKP00002 changes
				isonMsg = digiImeiCheck(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OARMIMEI")) { // SKP00003 changes
				isonMsg = unlinkedDevice(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "VALIDATION")) { // #SRP00042 start
				isonMsg = sessionValidation(isonMsg); // #SRP00042 Ends
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SvrName, "OABSECQU")) {
				isonMsg = updateSecurityQns(isonMsg); // MSA00036 changes
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SvrName, "OABSECQU")) {
				isonMsg = digiUserDetails(isonMsg); // MSA00036 changes
			} else if (I$utils.$iStrFuzzyMatch(scrOpr, "QUERY") && I$utils.$iStrFuzzyMatch(Scr, "OABSEQUS")) {
				isonMsg = digiQueryUserDetails(isonMsg); // MSA00036 changes
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "VALIDATE") && I$utils.$iStrFuzzyMatch(SvrName, "OABRTCNT")) {
				isonMsg = digiSecurityCount(isonMsg); // MSA00038 changes
			} else if (I$utils.$iStrFuzzyMatch(scrOpr, "SUMMARY") && I$utils.$iStrFuzzyMatch(Scr, "OABDGCIF")) {
				isonMsg = i$generic.processMsgHandler(isonMsg, isonheader, isonMapJson); // MSA00039 changes
			} else if (I$utils.$iStrFuzzyMatch(scrOpr, "UPDATE") && I$utils.$iStrFuzzyMatch(Scr, "OABDGCIF")) {
				isonMsg = backOfficeProcess(isonMsg); // MSA00039 changes
			} else if (I$utils.$iStrFuzzyMatch(scrOpr, "UPDATESTATUS") && I$utils.$iStrFuzzyMatch(Scr, "OABDGCIF")) {
				isonMsg = digiUserStatusUpdate(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_UPDATESECURITYQUESTIONS")) {
				isonMsg = digiUpdateSecurityQuestions(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNHANDLED OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNHANDLED OPERATION",
					e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};

	public JsonObject digiRegister(JsonObject isonMsg) {
		String key = "";
		JsonObject filter = new JsonObject();
		JsonObject i$bdyResp = new JsonObject();
		JsonObject $phoneKey = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		JsonObject iconfig = isonMsg.getAsJsonObject("i-config");
		JsonObject updtUser = new JsonObject();
		JsonObject respBody = new JsonObject();
		try {

			// check for OTP . verify
			String iSecKey = iBody.get("iSecKey").getAsString();
			// String otp = iBody.get("otp").getAsString();
			String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
			if (I$utils.$iStrBlank(imecd))
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID IMEI");

			key = i$ResM.getBodyElementS(isonMsg, "key");
			key = key.toLowerCase();
			String dob = iBody.get("dob").getAsString();
			JsonObject cifFilter = new JsonObject();
			JsonObject CparamInfo = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}");
			cifFilter.addProperty("CustomerId", key);
			JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", cifFilter);
			JsonArray fullExceptAccess = CparamInfo.get("exceptMemberCategory").getAsJsonArray();
//			if (I$utils.$iStrBlank(key)) {
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
//			} else {}

			IResManipulator.iloggedUser.set(key);
			// If pre-authenticated, get the email id or key Id and check in the DB
			filter.addProperty("key", key);
			filter.addProperty("dob", dob); // PKY00049 changes
			JsonObject userRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter);

			String mpin = null;
			String msalt = null;
			String sessionId = null; // #MVT00119 changes begins
			// SKP00002 changes Starts
			try {
				mpin = iBody.get("mpin").getAsString();
				msalt = i$impactoUtil.getSalt(30);
				sessionId = i$ResM.getClientSessionID(isonMsg);
				mpin = i$impactoUtil.generateSecurePassword(mpin, msalt);
			} catch (Exception e) {
			}
			// SKP00002 changes Ends
			// #MVT00106 changes begins
			Gson gson = new Gson();
			SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
			Date orDate = new Date();
			int countActivate = 0;
			String date = cntDate.format(orDate);
			JsonObject dtime = i$ResM.adddate(new Date());
			JsonArray pinUpdatedArr = new JsonArray();
			pinUpdatedArr.add(date);
			if (!I$utils.$isNull(userRec)) { // PKY00049 starts
//				if(!I$utils.$iStrFuzzyMatch(imecd, userRec.get("imei").getAsString())){
//					JsonObject updateData = new JsonObject();
//					updateData.addProperty("imei", imecd);
//					updateData.addProperty("mpin", mpin);  //SKP00002 changes
//					updateData.addProperty("msalt", msalt);//SKP00002 changes
//					updateData.addProperty("sessionID", sessionId);
//					updateData.addProperty("logoutStatus", false);
//					updateData.addProperty("pinUpdatedDate", date);
//					db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS",updateData, filter);
//				}
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Member is already registered, Please login to continue");
				// PKY00049 ends
			} else if (I$utils.$isNull(userRec)) {
				userRec = new JsonObject();
				// store pin in mpass
				userRec.addProperty("msalt", msalt);
				userRec.addProperty("mpin", mpin);
				// Store the rec to DB
				userRec.addProperty("dob", dob);
				userRec.addProperty("imei", imecd);
				userRec.addProperty("key", key);
				userRec.addProperty("noOfActivatedAccount", countActivate);
				userRec.addProperty("memberName", cifData.get("CustomerFullName").getAsString());
				userRec.addProperty("memberCategory", cifData.get("CustomerCategory").getAsString());
				if (I$utils.isInArray(fullExceptAccess, cifData.get("CustomerCategory").getAsString())) {
					userRec.addProperty("memberCategoryDesc", "Staff");
				} else {
					userRec.addProperty("memberCategoryDesc", "Non-Staff");
				}
				userRec.addProperty("pinUpdatedDate", date);
				userRec.add("pinUpdatedDateArr", pinUpdatedArr);
				userRec.add("registeredAt", i$ResM.adddate(new Date()).getAsJsonObject());
				userRec.addProperty("sessionID", sessionId);
				userRec.addProperty("active", "A");
				userRec.addProperty("activeStatus", "Active");
				try {
					if (iconfig.has("ipAddress")) {
						userRec.addProperty("ipAddress", iconfig.get("ipAddress").getAsString());
					} else {
						userRec.addProperty("ipAddress", "");
					}
				} catch (Exception e) {
					userRec.addProperty("ipAddress", " ");
				}
				userRec.addProperty("logoutStatus", false);// #MVT00119 changes ends
				isonMsg = db$Ctrl.db$InsertRow("ICOR_M_B2U_DIGI_USERS", userRec);

				try {// MSA00036 starts
					JsonObject secDtl = new JsonObject();
					if (iBody.has("securityDetails")
							&& !I$utils.$isNull(iBody.get("securityDetails").getAsJsonObject())) {
						Set<String> keys = iBody.get("securityDetails").getAsJsonObject().keySet();
						for (String key_1 : keys) {
							iBody.get("securityDetails").getAsJsonObject().get(key_1).getAsJsonObject()
									.addProperty("pvtKey", i$ResM.getGobalValStr("deCryptKey"));
						}
						secDtl.add("securityDetails", iBody.get("securityDetails").getAsJsonObject());
						secDtl.addProperty("securityQuestionAnswered", "Y");
						secDtl.addProperty("securityQuestionsReset", "N");// 28m24
					} else {
						secDtl.addProperty("securityQuestionAnswered", "N");
					}
					updtUser = db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", secDtl, filter);
				} catch (Exception e) {
				} // MSA00036 ends
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(updtUser), "i-SUCC")) {
					respBody.addProperty("registrationStatus", true);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, respBody);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "REGISTRATION SUCCESSFUL");
				} else {
					respBody.addProperty("registrationStatus", false);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, respBody);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register");
				}
				return isonMsg;
			} // #MVT00106 changes ends
			JsonObject cust$Det = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", "{'CustomerId':'" + key + "'}",
					"{'_id':0,'CustomerFullName':1,'CustomerMobileIsdNo':1,'CustomerMobileId':1,'CustomerSig':1,'CustomerImg':1,'CustomerEmailId':1}");

			// Create EComm Repo removed
			// create token and return
			String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
					Charset.defaultCharset());
			int expirationInMinutes = 1 * 6000 * 24;
			String jwtToken = net.sirma.impacto.iapp.iutils.JwtUtils.generateHMACToken(key, "", secret,
					expirationInMinutes);
			i$bdyResp.addProperty("key", key);
			i$bdyResp.addProperty("token", jwtToken);
			JsonArray accountData = new JsonArray();
			try {
				accountData = db$Ctrl.db$getAccounts(key);
			} catch (Exception e) {
			}
			i$bdyResp.add("accountData", accountData);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
					i$impactoUtil.mergeJsonObject(i$bdyResp, cust$Det));
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "REGISTRATION SUCCESSFUL");
			logUserLogin(isonMsg);
		} catch (Exception e) {
			logger.debug(e.getMessage());
			respBody.addProperty("registrationStatus", false);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, respBody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	// send otp for digiReRegister(same with some key) and mpin(normal send CIF)
	public JsonObject digiReRegister(JsonObject isonMsg) {
		String key = "";
		JsonObject filter = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		try {
			// check for OTP . verify
			String iSecKey = iBody.get("iSecKey").getAsString();
			String otp = iBody.get("otp").getAsString();
			String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
			if (I$utils.$iStrBlank(imecd))
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID IMEI");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else { // #MVT00021 Changes starts
				String mpin = iBody.get("mpin").getAsString();
				String msalt = i$impactoUtil.getSalt(30);
				mpin = i$impactoUtil.generateSecurePassword(mpin, msalt);
				filter.addProperty("key", key);
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS",
						"{'imei':'" + imecd + "', 'mpin':'" + mpin + "', 'msalt':'" + msalt + "'}", filter);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "New Device Registration Successful");
			} // #MVT00021 Changes ends
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	// SKP00002 Starts
	public JsonObject digiImeiCheck(JsonObject isonMsg) {
		String key = "";
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		try {
			// check for OTP . verify
			key = iBody.get("key").getAsString();
			String dob = iBody.get("dob").getAsString();
			filter.addProperty("dob", dob);
			filter.addProperty("key", key);
			projection.addProperty("dob", 1);
			projection.addProperty("key", 1);
			projection.addProperty("imei", 1);
			JsonObject userDetails = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter, projection);

			if (I$utils.$isNull(userDetails)) {
				JsonObject custdetails = new JsonObject();
				custdetails.addProperty("register", false);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", custdetails);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "THE CIF IS NOT REGISTERED");
			} else {
				JsonObject custdetails = new JsonObject();
				custdetails.addProperty("imei", userDetails.get("imei").getAsString());
				custdetails.addProperty("register", true);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", custdetails);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "CIF IS REGISTERED");

			}
		} catch (Exception e) {
			JsonObject custdetails = new JsonObject();
			custdetails.addProperty("register", false);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", custdetails);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "THE CIF IS NOT REGISTERED");
			logger.debug(e.getMessage());

		}
		return isonMsg;
	}
	// SKP00002 Ends

	// SKP00003 Starts
	public JsonObject unlinkedDevice(JsonObject isonMsg) {
		String key = "";
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		try {
			// check for OTP . verify
			key = iBody.get("key").getAsString();
			filter.addProperty("key", key);
			projection.addProperty("key", 1);
			projection.addProperty("imei", 1);
			JsonObject userDetails = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter, projection);

			if (I$utils.$isNull(userDetails)) {
				JsonObject custdetails = new JsonObject();
				custdetails.addProperty("register", false);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", custdetails);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "THE CIF IS NOT REGISTERED");
			} else {
				JsonObject custdetails = new JsonObject();
				JsonObject setter = new JsonObject();
				setter.addProperty("imei", "");
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", setter, filter, "true");
				custdetails.addProperty("register", false);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", custdetails);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "CIF IS ALREADY REGISTERED");

			}
		} catch (Exception e) {
			JsonObject custdetails = new JsonObject();
			custdetails.addProperty("register", false);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", custdetails);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "THE CIF IS NOT REGISTERED");
			logger.debug(e.getMessage());

		}
		return isonMsg;
	}

	// SKP00003 Ends
	public JsonObject setMPin(JsonObject isonMsg) {
		String key = "";
		JsonObject filter = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		try {
			// check for OTP . verify
			String iSecKey = iBody.get("iSecKey").getAsString();
			String otp = iBody.get("otp").getAsString();
			String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
			if (I$utils.$iStrBlank(imecd))
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID IMEI");
			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				filter.addProperty("key", key);
				JsonObject userRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter);
				if (I$utils.$iStrFuzzyMatch(userRec.get("imei").getAsString(), imecd)) {
					String mpin = iBody.get("mpin").getAsString();
					mpin = i$impactoUtil.generateSecurePassword(mpin, userRec.get("msalt").getAsString());
					db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", "{'mpin':'" + mpin + "'}", filter);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "New MPIN set successfully");
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Member is registered with some other device. Please Login with new device");

				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	// SKP00004 Starts

	public JsonObject resetMPin(JsonObject isonMsg) {
		Gson gson = new Gson();
		String key = "";
		JsonObject filter = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		try {
			// check for OTP . verify
			String iSecKey = iBody.get("iSecKey").getAsString();
			// String otp = iBody.get("otp").getAsString();
			String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
			if (I$utils.$iStrBlank(imecd))
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID IMEI");
			key = i$ResM.getBodyElementS(isonMsg, "key");
//			if (otpCtrl.verifyOTP(iSecKey, otp)) {
//				
//			} else {
//				key = "";
//			}
			key = key.toLowerCase();
//			if (I$utils.$iStrBlank(key)) {
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
//			} else {
//				
//			}//#MVT00122 changes begins

			filter.addProperty("key", key);
			JsonObject userRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter);
//			JsonObject securityQuestion = userRec.get("securityDetails").getAsJsonObject();
//
//			String iBodyQuestion = iBody.get("securityDetails").getAsJsonObject().get("question").getAsString();
//			String iBodyAnswer = iBody.get("securityDetails").getAsJsonObject().get("answer").getAsString();
//			Set<String> keys = securityQuestion.keySet();
//			for (String key_1 : keys) {
//				try {
//					JsonObject runnObj = securityQuestion.get(key_1).getAsJsonObject();
//					String runnQuestion = runnObj.get("question").getAsString();
//					String runnAnswer = runnObj.get("answer").getAsString();
//					String pvtKey = runnObj.get("pvtKey").getAsString();
//					if (I$utils.$iStrFuzzyMatch(runnQuestion, iBodyQuestion)) {
//						String iBodyAnswerDecrypt = i$impactoUtil.decryptPkey(iBodyAnswer);// present decrypted ans
//						String dbdcryptAns = I$Crypt.decryptText(runnAnswer, pvtKey); // db decrypted ans
//						if (I$utils.$iStrFuzzyMatch(iBodyAnswerDecrypt, dbdcryptAns)) {
			JsonObject body = new JsonObject();
			String mpin = iBody.get("mpin").getAsString();
			SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
			Date orDate = new Date();
			String date = cntDate.format(orDate);
			mpin = i$impactoUtil.generateSecurePassword(mpin, userRec.get("msalt").getAsString());
			body.addProperty("mpin", mpin);
			body.addProperty("imei", imecd);
			body.addProperty("noOfFailedLogins", 0);
			body.addProperty("pinUpdatedDate", date);// #MVT00106 changes ends
			JsonArray existingPinUpdatedDates = new JsonArray();
			JsonObject fObj2 = new JsonObject();
			JsonObject existingPinUpdatedDates2 = new JsonObject();
			existingPinUpdatedDates.add(date);
			existingPinUpdatedDates2.add("$each", existingPinUpdatedDates);
			fObj2.add("pinUpdatedDateArr", existingPinUpdatedDates2);
			String i$CustomerIdDoc = gson.toJson(fObj2);
			db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", body, filter);// #MVT00122 changes ends
			db$Ctrl.db$UpdateRowOperator("ICOR_M_B2U_DIGI_USERS", i$CustomerIdDoc, filter, "false", "push");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, body);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "MPIN RESET SUCCESSFUL");
//						} else {
//							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Enter Valid Answer");
//						}
//					} else {
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Enter Valid Question");
//					}
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//			if(quesCount <=0) {
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Enter Valid Question");
//			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed To Reset mpin ");
		}
		return isonMsg;
	}

	// SKP00004 Ends
	// TKS00019 starts
	public JsonObject resetIMECD(JsonObject isonMsg) {
		try { // #MVT00115 changes begins
			JsonObject filter = new JsonObject();
			JsonObject doc = new JsonObject();
			JsonObject iBody = isonMsg.getAsJsonObject("i-body");
			String cif = iBody.get("key").getAsString();
			filter.addProperty("key", cif);

			JsonObject UserPrf = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter); // #BVB00034
			String userPassDecrypt = iBody.get("mpin").getAsString();
			userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt, UserPrf.get("msalt").getAsString());
			if (!I$utils.$iStrFuzzyMatch(userPassDecrypt, UserPrf.get("mpin").getAsString())) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid Credentials");
				return isonMsg;
			} // #MVT00115 changes ends

			String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
			doc.addProperty("imei", imecd);
			doc.addProperty("noOfFailedLogins", 0);// #MVT00122 changes
			doc.addProperty("sessionID", i$ResM.getConfigElementS(isonMsg, "sessionID"));
			db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", doc, filter);
			digiLogin(isonMsg);// #MVT00115 changes ends
			// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "IMECD RESET
			// SUCCESSFUL");
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update" + e.getMessage());
		}
		return isonMsg;
	}

	// TKS00019 ends
	public JsonObject digiLogin(JsonObject isonMsg) {
		String key = "";
		int failedAttempts = 0;
		JsonObject i$bdyResp = new JsonObject();
		JsonObject fltr = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		Boolean isAuthenticated = false;
		try {// #MVT00108 changes begins
			fltr.addProperty("CustomerId", iBody.get("key").getAsString()); // #SRM00035 changes begin
			JsonObject CparamInfo = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}");
			JsonObject cifInfo = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
			key = iBody.get("key").getAsString();
			JsonObject digiUserData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", "{'key': '" + key + "'}");
			if (I$utils.$isNull(cifInfo)) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid/Unknown Customer ID");
			} else {
				try {
					if (I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionsReset").getAsString(), "Y")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Update Security Questions");
						return isonMsg;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				String custCat = cifInfo.get("CustomerCategory").getAsString();
				JsonArray fullAccess = CparamInfo.get("fullAccessDigiApp").getAsJsonArray();
				JsonArray fullExceptAccess = CparamInfo.get("exceptMemberCategory").getAsJsonArray();
				JsonArray noAccess = CparamInfo.get("noAccessDigiApp").getAsJsonArray();
				try { // #MVT00126 begins
					JsonObject categoryObj = new JsonObject();
					JsonArray funcDetails = new JsonArray();
					JsonObject funObject = new JsonObject();
					JsonObject jbdy = new JsonObject();

					funObject.addProperty("funcName", "GET_CIF_CATEGORY");
					funObject.addProperty("p_member", iBody.get("key").getAsString());
					funcDetails.add(funObject);
					jbdy.add("funcDetails", funcDetails);
					categoryObj.add("i-body", jbdy);
					JsonObject functionData = i$FunC.exeCallOrcl(categoryObj);
					JsonObject funcRes = functionData.getAsJsonObject("i-body").getAsJsonArray("funcRes").get(0)
							.getAsJsonObject();
					custCat = funcRes.getAsJsonObject("GET_CIF_CATEGORY").get("l_data").getAsString();
				} catch (Exception e) {
					e.getMessage();
				} // #MVT00126 ends
				if (digiUserData.has("active")
						&& I$utils.$iStrFuzzyMatch(digiUserData.get("active").getAsString(), "A")) {
					if (I$utils.isInArray(fullAccess, custCat) || I$utils.isInArray(fullExceptAccess, custCat)) { // #SRM00035
																													// changes
																													// end
																													// //#MVT00122
																													// changes
																													// begins
//					int failedAttempts = iBody.get("noOfFailedLogins").getAsInt();

						String loginMode = iBody.get("Mode").getAsString();
						key = iBody.get("key").getAsString();
						String imecd = i$ResM.getConfigElementS(isonMsg, "imecd");
						JsonObject UserPrf = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", "{'key': '" + key + "'}"); // #BVB00034
						// #MVT00114 changes begins
						if (I$utils.$isNull(UserPrf)) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"It looks like you are not registered on the system, please complete the registration process first before login");
						}
						if (UserPrf.has("noOfFailedLogins")) {
							failedAttempts = UserPrf.get("noOfFailedLogins").getAsInt();
						}
						if (failedAttempts >= 3) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"Too many invalid login attempts, please reset the mpin password to continue");
							return isonMsg;
						} // #MVT00108 changes ends
						if (I$utils.$iStrFuzzyMatch(loginMode, "M")) {
							try {
								String userPassDecrypt = iBody.get("mpin").getAsString();
								userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt,
										UserPrf.get("msalt").getAsString());
								if (I$utils.$iStrFuzzyMatch(userPassDecrypt, UserPrf.get("mpin").getAsString())) {
									isAuthenticated = true;
									failedAttempts = 0;
								} else {
									failedAttempts++;
								}
							} catch (Exception e) {
								return isonMsg;
							} // #MVT00114 changes ends
						} // #MVT00106 changes begins
						try {
							projection.addProperty("passwordResetDays", 1);
							JsonArray jDateArr = new JsonArray();
							jDateArr = UserPrf.get("pinUpdatedDate").getAsJsonArray();
//						String jDate = UserPrf.get("pinUpdatedDate").getAsString();
							String jDate = jDateArr.get(0).getAsString();
							JsonObject days = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);
							int noOfDays = days.get("passwordResetDays").getAsInt();
							Date lsrDate = I$utils.changeDate(noOfDays, "SUB", "D");
							String edate = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd");

							SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
							Date checkDate = format.parse(edate);
							Date lastUodatedDate = format.parse(jDate);
							if (lastUodatedDate.compareTo(checkDate) < 0) {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"It Seems Like You Have Not Changed Your mpin From Last Six Months Please Reset Your mpin");
								return isonMsg;
							}
						} catch (Exception e) {
							logger.debug(e.getMessage() + "Error While Checking mpin Updated Date");
						}
						// #MVT00106 changes ends
//			else if (I$utils.$iStrFuzzyMatch(loginMode, "P")) {
//				String userPassDecrypt = iBody.get("pass").getAsString();
//				userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt, UserPrf.get("salt").getAsString());
//				if (I$utils.$iStrFuzzyMatch(userPassDecrypt, UserPrf.get("pass").getAsString())) {
//					isAuthenticated = true;
//				}
//			}			
						if (!I$utils.$iStrFuzzyMatch(imecd, UserPrf.get("imei").getAsString())) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"Member is already registered with other device. Do you still wish to login with this device?");
							return isonMsg;
						}
						// #MVT00116 begins
						JsonObject filtr = new JsonObject();
						JsonObject updateObject = new JsonObject();
						filtr.addProperty("imei", imecd);
						filtr.addProperty("key", key);
						JsonObject c_fltr = new JsonObject();
						c_fltr.addProperty("privateKey", "SIRMASIRMASIRMAS");
						JsonArray exceptMemCat = db$Ctrl.db$GetRow("ICOR_C_PARAM", c_fltr).get("exceptMemberCategory")
								.getAsJsonArray();
//					exceptMemCat.add("30");
//					exceptMemCat.add("80");
//					exceptMemCat.add("90");
						updateObject.addProperty("sessionID", i$ResM.getClientSessionID(isonMsg));
						updateObject.addProperty("logoutStatus", false);// #MVT00119 changes
						updateObject.addProperty("noOfFailedLogins", failedAttempts);// #MVT00119 changes
						updateObject.add("lastActiveAt", i$ResM.adddate(new Date()));
						db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updateObject, filtr); // #MVT00122 changes ends
						// #MVT00116 ends
						if (isAuthenticated) {
							JsonObject userRec = new JsonObject();
							userRec.addProperty("key", key);
							userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
							String sessionId = i$ResM.getClientSessionID(isonMsg);
							userRec.addProperty("sessionId", sessionId);

							// Create token and share it back
							String secret = IOUtils.toString(
									getClass().getClassLoader().getResourceAsStream("secret.key"),
									Charset.defaultCharset());
							int expirationInMinutes = 1 * 6000 * 24;
							String token = net.sirma.impacto.iapp.iutils.JwtUtils.generateHMACToken(
									i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
							i$bdyResp.addProperty("key", key);
							// #DVJ00013 Ends
							i$bdyResp.addProperty("token", token);
							JsonObject cust$Det = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",
									"{'CustomerId':'" + key + "'}",
									"{'_id':0,'CustomerFullName':1,'CustomerMobileIsdNo':1,'CustomerMobileId':1,'CustomerSig':1,'CustomerImg':1,'CustomerEmailId':1}");
							JsonArray accountData = new JsonArray();
							try {
								accountData = db$Ctrl.db$getAccounts(key);
							} catch (Exception e) {
							}
							i$bdyResp.add("accountData", accountData);

							JsonObject fltr_1 = new JsonObject();// MSA00036 starts
							fltr_1.addProperty("key", key);
							JsonObject userData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", fltr_1);
							if (userData.has("securityQuestionAnswered")) {
								i$bdyResp.addProperty("securityQuestionAnswered",
										userData.get("securityQuestionAnswered").getAsString());
								if (I$utils.$iStrFuzzyMatch(userData.get("securityQuestionAnswered").getAsString(), "Y")
										&& userData.has("securityDetails")) {
									i$bdyResp.add("securityDetails", userData.get("securityDetails").getAsJsonObject());
								}
							} else {
								i$bdyResp.addProperty("securityQuestionAnswered", "N");
							}
							// MSA00036 ends
							if (userData.has("securityQuestionAnswered")) {
								JsonObject securityDetal = userData.get("securityDetails").getAsJsonObject();
								Set<String> keys = securityDetal.keySet();
								for (String key_1 : keys) {
									try {
										JsonObject runnObj = securityDetal.get(key_1).getAsJsonObject();
										if (!runnObj.has("pvtKey")) {
											i$bdyResp.addProperty("securityQuestionAnswered", "N");
											i$bdyResp.remove("securityDetails");
										}
									} catch (Exception e) {
										i$bdyResp.addProperty("securityQuestionAnswered", "N");
										i$bdyResp.remove("securityDetails");
									}

								}
							}
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
									i$impactoUtil.mergeJsonObject(i$bdyResp, cust$Det));
							if (I$utils.isInArray(exceptMemCat, custCat)) {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"Prepare to revolutionize your financial experience – our game-changing TECH-U E-Services Mobile App is coming soon!");
							}
							logUserLogin(isonMsg);
							IResManipulator.iloggedUser.set(key);
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid Credentials." + " You have "
									+ (3 - failedAttempts) + " attempt/attempts left");
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Prepare to revolutionize your financial experience – our game-changing TECH-U E-Services Mobile App is coming soon!");
						}

					} else if (I$utils.isInArray(noAccess, custCat)) { // #MVT00129 begins
//			        return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Cannot Provide Access for Customer Category "
//					+ custCat + ". Kindly contact TECU Credit Union for Further Details.");
						JsonObject emailObj = new JsonObject();
						JsonObject map$Data = new JsonObject();
						JsonObject mailDet = new JsonObject();

						mailDet.addProperty("toemailid1", cifInfo.get("CustomerEmailId").getAsString());
						map$Data.addProperty("tmp$name", "TMPL#CATEGORYACCESS");
						emailObj.add("map$Data", map$Data);
						emailObj.add("toemailIds", mailDet);
						JsonObject i$res = i$Email.SendEmailWOThread(emailObj);
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Please contact us at 800-TECU (8328) or visit one of our branch for further assistance.");
					} // #MVT00129 ends
				} else {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"You have been locked out of your account. Please contact us at 800-TECU (8328) or visit one of our branches for further assistance.");

				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Login with " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject cifAuthorize(JsonObject isonMsg) {
		String key = "";
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		try {
			// check for OTP . verify
			String iSecKey = iBody.get("iSecKey").getAsString();
			String otp = iBody.get("otp").getAsString();
			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				JsonObject cust$Det = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", "{'CustomerId':'" + key + "'}",
						"{'_id':0,'CustomerFullName':1,'CustomerMobileIsdNo':1,'CustomerMobileId':1,'CustomerSig':1,'CustomerImg':1,'CustomerEmailId':1,'AddressForCorrespondence1':1,'AddressForCorrespondence2':1,'AddressForCorrespondence3':1,'AddressForCorrespondence4':1,'CustomerFirstName':1,'CustomerLastName':1}"); // #PKY00027
																																																																																// changes
				JsonArray accountData = new JsonArray();
				try {
					accountData = db$Ctrl.db$getAccounts(key);
				} catch (Exception e) {
				}
				cust$Det.add("accountData", accountData);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, cust$Det);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject guestLogin(JsonObject isonMsg) {
		String key = "";
		JsonObject i$bdyResp = new JsonObject();
		try {
			// check for OTP . verify
			String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
			String otp = i$ResM.getBodyElementS(isonMsg, "otp");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				JsonObject userRec = new JsonObject();
				userRec.addProperty("key", key);
				userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
				String sessionId = i$ResM.getClientSessionID(isonMsg);
				userRec.addProperty("sessionId", sessionId);
				// #DVJ00013 Ends
				db$Ctrl.db$InsertRow("ICOR_M_WEBPORTAL_USERS", userRec);

				// Create token and share it back
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				int expirationInMinutes = 1 * 6000 * 24;
				String token = net.sirma.impacto.iapp.iutils.JwtUtils
						.generateHMACToken(i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
				i$bdyResp.addProperty("key", key);
				// #DVJ00013 Ends
				i$bdyResp.addProperty("token", token);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$bdyResp);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
				logUserLogin(isonMsg);
				IResManipulator.iloggedUser.set(key);
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject memberLogin(JsonObject isonMsg) {
		String key = "";
		JsonObject i$bdyResp = new JsonObject();
		JsonObject filter = new JsonObject();
		try {
			// check for OTP . verify
			String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
			String otp = i$ResM.getBodyElementS(isonMsg, "otp");
			String Key_Mode = i$ResM.getBodyElementS(isonMsg, "Key_Mode");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else if (I$utils.$iStrBlank(Key_Mode)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID MODE");
			} else {

				filter.addProperty("Key_Mode", Key_Mode);
				filter.addProperty("Key", key); // #NYE00001

				JsonObject icorMEcomRepo = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", filter);
				String cif = icorMEcomRepo.get("Key_Owner").getAsString();
				JsonObject userRec = new JsonObject();
				userRec.addProperty("key", cif);
				userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
				String sessionId = i$ResM.getClientSessionID(isonMsg);
				userRec.addProperty("sessionId", sessionId);
				// #DVJ00013 Ends
				db$Ctrl.db$InsertRow("ICOR_M_WEBPORTAL_USERS", userRec);

				// Create token and share it back
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				int expirationInMinutes = 1 * 6000 * 24;
				String token = net.sirma.impacto.iapp.iutils.JwtUtils
						.generateHMACToken(i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
				i$bdyResp.addProperty("key", cif);
				// #DVJ00013 Ends
				i$bdyResp.addProperty("token", token);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$bdyResp);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
				logUserLogin(isonMsg);
				IResManipulator.iloggedUser.set(cif);
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	private JsonObject logUserLogin(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject setter = new JsonObject();
		try {
			// #DVJ00015 Starts
			filter.addProperty("userId", i$ResM.getBodyElementS(isonMsg, "key"));
//			db$Ctrl.db$Remove("ICOR_S_SESSION_VALIDATOR", filter);
			db$Ctrl.db$Remove("ICOR_S_TOKEN_VALIDATOR", filter);

			// Add to Session Validator
			filter = new JsonObject();
			filter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId"));
			setter.addProperty("userId", i$ResM.getBodyElementS(isonMsg, "key"));
			setter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId"));
			setter.add("lastActivityAt", i$ResM.addDateTime(new Date()));
			db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", setter, filter, "true");

			// Add Token to Token validator
			setter.addProperty("token", i$ResM.getBodyElementS(isonMsg, "token"));
			setter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId")); // #BVB00065

//			JsonObject up$ = db$Ctrl.db$UpdateRow("ICOR_S_TOKEN_VALIDATOR", setter, filter, "true");
			JsonObject in$ = db$Ctrl.db$InsertRow("ICOR_S_TOKEN_VALIDATOR", setter);
			// JsonObject in$ = db$Ctrl.db$InsertRow("ICOR_S_USER_ACT_LOG",
			// icorMPresentUsers);
			return in$;
			// #DVJ00015 Ends
		} catch (Exception e) {
			logger.debug("Failed while logging Wser Login with:" + e.getMessage());
			return null;
		}

	}

	// #YPR00047 starts
	private JsonObject inCompletedUserLogin(JsonObject isonMsg) {
		String key = "";
		JsonObject i$bdyResp = new JsonObject();
		JsonObject inCompApplctn = new JsonObject();
		try {
			// check for OTP . verify
			String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
			String otp = i$ResM.getBodyElementS(isonMsg, "otp");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
			key = key.toLowerCase(); // #MVT00123 changes
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				JsonObject userRec = new JsonObject();
				userRec.addProperty("key", key);
				userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
				String sessionId = i$ResM.getClientSessionID(isonMsg);
				userRec.addProperty("sessionId", sessionId);
				// #DVJ00013 Ends
				db$Ctrl.db$InsertRow("ICOR_M_WEBPORTAL_USERS", userRec);

				// Create token and share it back
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				int expirationInMinutes = 1 * 6000 * 24;
				String token = net.sirma.impacto.iapp.iutils.JwtUtils
						.generateHMACToken(i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
				i$bdyResp.addProperty("key", key);
				// #DVJ00013 Ends
				i$bdyResp.addProperty("token", token);

				try {
					inCompApplctn = (JsonObject) db$Ctrl.db$GetRows$Sort("ICOR_C_B2U_CIF_APPLICATION",
							"{\"contactDetails.emailId\":\"" + i$ResM.getBodyElementS(isonMsg, "key")
									+ "\", \"DcStatus\" : \"In-Complete\", \"isCurrVer\":\"Y\"}",
							"{'createdAt':-1}").get(0); // #MVT00123 changes
					i$bdyResp.add("inCompletedApplication", inCompApplctn);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$bdyResp);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
					logUserLogin(isonMsg);
					IResManipulator.iloggedUser.set(key);
				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"USER DON'T HAVE ANY UNFINISHED APPLICATIONS");
				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	// #YPR00047 Ends
	// #SKP00001 Starts
	private JsonObject inCompletedTatilUserLogin(JsonObject isonMsg) {
		String key = "";
		JsonObject i$bdyResp = new JsonObject();
		JsonObject inCompApplctn = new JsonObject();
		try {
			// check for OTP . verify
			String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
			String otp = i$ResM.getBodyElementS(isonMsg, "otp");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
//			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				JsonObject userRec = new JsonObject();
				userRec.addProperty("key", key);
				userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
				String sessionId = i$ResM.getClientSessionID(isonMsg);
				userRec.addProperty("sessionId", sessionId);
				// #DVJ00013 Ends
//				db$Ctrl.db$InsertRow("ICOR_M_WEBPORTAL_USERS", userRec);					

				// Create token and share it back
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				int expirationInMinutes = 1 * 6000 * 24;
				String token = net.sirma.impacto.iapp.iutils.JwtUtils
						.generateHMACToken(i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
				i$bdyResp.addProperty("key", key);
				// #DVJ00013 Ends
				i$bdyResp.addProperty("token", token);

				try {
					inCompApplctn = (JsonObject) db$Ctrl.db$GetRows$Sort("ICOR_C_B2U_TATIL_APPLICATION",
							"{\"custInfo.CustomerId\":\"" + key
									+ "\", \"DcStatus\" : \"In-Complete\", \"isCurrVer\":\"Y\"}",
							"{'createdAt':-1}").get(0);
					i$bdyResp.add("inCompletedApplication", inCompApplctn);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$bdyResp);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
					logUserLogin(isonMsg);
					IResManipulator.iloggedUser.set(key);
				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"USER DON'T HAVE ANY UNFINISHED APPLICATIONS");
				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	// #SKP00001 Ends
	private JsonObject sessionValidation(JsonObject isonMsg) { // #SRP00042 Starts changes
		JsonObject i$body = isonMsg.get("i-body").getAsJsonObject();
		JsonArray funcDetail = i$body.get("funcDetails").getAsJsonArray();
		try {
			JsonObject res;
			if (funcDetail.get(0).getAsJsonObject().get("funcName").getAsString().toLowerCase()
					.contains("get_token_info")) {
				res = i$FunC.exeCallOrcl(isonMsg);
				JsonObject ibody = res.get("i-body").getAsJsonObject();
				JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
				JsonObject functionobject = funcRes.get(0).getAsJsonObject().get("get_token_info").getAsJsonObject();
				String op_output = functionobject.get("op_output").getAsString();
				if (op_output != null && !I$utils.$iStrBlank(functionobject.get("op_output").getAsString())) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SESSIONID VERIFICATION SUCCESSFULL");
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID SESSIONID");
				}

			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID SESSIONID");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID SESSIONID");
		}
		return isonMsg;
	}// #SRP00042 Ends changes
		// #TKS00004 Starts

	private JsonObject inCompletedLoanUserLogin(JsonObject isonMsg) {
		String key = "";
		JsonObject i$bdyResp = new JsonObject();
		JsonObject inCompApplctn = new JsonObject();
		try {
			// check for OTP . verify
			String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
			String otp = i$ResM.getBodyElementS(isonMsg, "otp");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
//			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				JsonObject userRec = new JsonObject();
				userRec.addProperty("key", key);
				userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
				String sessionId = i$ResM.getClientSessionID(isonMsg);
				userRec.addProperty("sessionId", sessionId);
				// #DVJ00013 Ends
//				db$Ctrl.db$InsertRow("ICOR_M_WEBPORTAL_USERS", userRec);					

				// Create token and share it back
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				int expirationInMinutes = 1 * 6000 * 24;
				String token = net.sirma.impacto.iapp.iutils.JwtUtils
						.generateHMACToken(i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
				i$bdyResp.addProperty("key", key);
				// #DVJ00013 Ends
				i$bdyResp.addProperty("token", token);

				try {
					inCompApplctn = (JsonObject) db$Ctrl.db$GetRows$Sort("ICOR_C_LD_LEAD_APPLICATIONS",
							"{\"cif\":\"" + key + "\", \"DcStatus\" : \"In-Complete\", \"isCurrVer\":\"Y\"}",
							"{'createdAt':-1}").get(0);
					i$bdyResp.add("inCompletedApplication", inCompApplctn);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$bdyResp);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "VERIFICATION SUCCESSFUL");
					logUserLogin(isonMsg);
					IResManipulator.iloggedUser.set(key);
				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"USER DON'T HAVE ANY UNFINISHED APPLICATIONS");
				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}

	// #TKS00004 ends
	// #YPR00049 starts
	private JsonObject appCompletedUserLogin(JsonObject isonMsg) {
		String key = "";
		JsonObject i$bdyResp = new JsonObject();
		JsonObject inCompApplctn = new JsonObject();
		try {
			// check for OTP . verify
			String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
			String otp = i$ResM.getBodyElementS(isonMsg, "otp");

			if (otpCtrl.verifyOTP(iSecKey, otp)) {
				key = i$ResM.getBodyElementS(isonMsg, "key");
			} else {
				key = "";
			}
//			key = key.toLowerCase();
			if (I$utils.$iStrBlank(key)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
			} else {
				JsonObject userRec = new JsonObject();
				userRec.addProperty("key", key);
				userRec.add("loggedInAt", i$ResM.adddate(new Date()).getAsJsonObject());
				String sessionId = i$ResM.getClientSessionID(isonMsg);
				userRec.addProperty("sessionId", sessionId);
				// #DVJ00013 Ends
				db$Ctrl.db$InsertRow("ICOR_M_WEBPORTAL_USERS", userRec);

				// Create token and share it back
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				int expirationInMinutes = 1 * 6000 * 24;
				String token = net.sirma.impacto.iapp.iutils.JwtUtils
						.generateHMACToken(i$ResM.getStrfromObj(userRec, "key"), "", secret, expirationInMinutes);
				i$bdyResp.addProperty("key", key);
				// #DVJ00013 Ends
				i$bdyResp.addProperty("token", token);

//				String emlId = i$ResM.getBodyElementS(isonMsg, "emailId");
				inCompApplctn = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION",
						"{\"applicationId\":\"" + key + "\", \"DcStatus\" : {'$eq':'Completed'}, \"isCurrVer\":\"Y\"}");
				if (inCompApplctn == null) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID USER DATA");
				} else {
					i$bdyResp.add("inCompletedApplication", inCompApplctn);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$bdyResp);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
							"VERIFICATION SUCCESSFUL & APPLICATION RETRIEVED SUCCESSFULLY");
					logUserLogin(isonMsg);
					IResManipulator.iloggedUser.set(key);
				}
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Register with " + e.getMessage());
		}
		return isonMsg;
	}// #YPR00049 Ends
		// MSA00036 starts

	private JsonObject updateSecurityQns(JsonObject isonMsg) {
		try {
			String key = i$ResM.getBodyElementS(isonMsg, "key");
			JsonObject fltr = new JsonObject();
			JsonObject userRec = new JsonObject();
			JsonObject iBody = isonMsg.get("i-body").getAsJsonObject();
			fltr.addProperty("key", key);
			JsonObject userData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", fltr);
			if (!I$utils.$isNull(userData)) {
//				JsonObject securityDetl = i$ResM.getBodyElementO(isonMsg, "securityDetails");

				if (iBody.has("securityDetails") && !I$utils.$isNull(iBody.get("securityDetails").getAsJsonObject())) {
					Set<String> keys = iBody.get("securityDetails").getAsJsonObject().keySet();
					for (String key_1 : keys) {
						iBody.get("securityDetails").getAsJsonObject().get(key_1).getAsJsonObject()
								.addProperty("pvtKey", i$ResM.getGobalValStr("deCryptKey"));
					}
					userRec.add("securityDetails", iBody.get("securityDetails").getAsJsonObject());
					userRec.addProperty("securityQuestionAnswered", "Y");
					userRec.addProperty("securityQuestionsReset", "N");// PAV Changes
				} else {
					userRec.addProperty("securityQuestionAnswered", "N");
				}
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", userRec, fltr);
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USER_STATUS", userRec, fltr);
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USER_STATUS_LEDGER", userRec, fltr);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Security Answers Updated Successfully");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid or Unknown User Id");
			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update Security Answers");
		}
		return isonMsg;
	}// MSA00036 ends
		// MSA00036 starts

	private JsonObject digiUserDetails(JsonObject isonMsg) {
		try {
			String scrOpr3 = i$ResM.getOpr3(isonMsg);
			String key = i$ResM.getBodyElementS(isonMsg, "key");
			JsonObject fltr = new JsonObject();
			JsonObject securityFltr = new JsonObject();
			securityFltr.addProperty("customerId", key);
			fltr.addProperty("key", key);
			JsonObject userData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", fltr);
			int min = 1;
			int max = 5;
			Random randomNo = new Random();
			int randInt = randomNo.nextInt(max) + min;
			String questionNo = "question" + randInt;
			JsonObject secureDtl = new JsonObject();
			JsonObject filter = new JsonObject();
			filter.addProperty("privateKey", "SIRMASIRMASIRMAS");
			JsonObject cParamData = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter);

			if (I$utils.$iStrFuzzyMatch(scrOpr3, "CHANGE")) {
				JsonObject validate = new JsonObject();
				JsonObject securityRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_SECURITY_CHECK", securityFltr);
				if (securityRec.get("retryCount").getAsInt() <= cParamData.get("digiSQRetryCount").getAsInt()) {

					if ((!securityRec.has("changeCount")) || (securityRec.has("changeCount") && securityRec
							.get("changeCount").getAsInt() < cParamData.get("digiSQChangeCount").getAsInt())) {
						if (userData.has("securityDetails")
								&& !I$utils.$isNull(userData.get("securityDetails").getAsJsonObject())) {
							try {
								secureDtl = userData.get("securityDetails").getAsJsonObject().get(questionNo)
										.getAsJsonObject();
							} catch (Exception e) {
								secureDtl = userData.get("securityDetails").getAsJsonObject().get("question1")
										.getAsJsonObject();
							}
							if (secureDtl.has("pvtKey")) {
								String decrypt = I$Crypt.decryptText(secureDtl.get("answer").getAsString(),
										secureDtl.get("pvtKey").getAsString());
								String publicKey = i$ResM.getGobalValStr("enCryptKey");
								String encTextpub = rsaAsymCrypt.encryptText(decrypt, publicKey);

								JsonObject securityDetailsObj = new JsonObject();
								JsonObject securityDetailsFinalObj = new JsonObject();
								securityDetailsObj.addProperty("question", secureDtl.get("question").getAsString());
								securityDetailsObj.addProperty("answer", encTextpub);
								securityDetailsFinalObj.add("securityDetails", securityDetailsObj);
								int finalchngCount = 0;
								try {
									finalchngCount = securityRec.get("changeCount").getAsInt() + 1;
								} catch (Exception e) {
									finalchngCount = cParamData.get("digiSQChangeCount").getAsInt();
								}
//							int finalRetryCount = securityRec.get("retryCount").getAsInt()+1;
								JsonObject insertData = new JsonObject();
								JsonObject filter$1 = new JsonObject();
								filter$1.addProperty("customerId", key);
								insertData.addProperty("changeCount", finalchngCount);
//								insertData.addProperty("retryCountBeforeQueChange",securityRec.get("retryCount").getAsInt());
								insertData.addProperty("retryCount", 1);
								insertData.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
								db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_SECURITY_CHECK", insertData, filter$1);

								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
										securityDetailsFinalObj);
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
										"Record Successfully Retrieved");
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"Please Update Security Details");
							}
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Security Details");
						}
					} else {
//					JsonObject updateDoc = new JsonObject();
//					updateDoc.addProperty("active", "I");
//					db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updateDoc, filter);
						validate.addProperty("validationResult", "Fail");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"You Have Already Exceeded the Change Question Limit");
					}
				} else {
					validate.addProperty("validationResult", "Fail");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"You have been locked out of your account. Please contact us at 800-TECU (8328) or visit one of our branches for further assistance.");
				}
			} else {
				if (userData.has("securityDetails")
						&& !I$utils.$isNull(userData.get("securityDetails").getAsJsonObject())) {
					try {
						secureDtl = userData.get("securityDetails").getAsJsonObject().get(questionNo).getAsJsonObject();
					} catch (Exception e) {
						secureDtl = userData.get("securityDetails").getAsJsonObject().get("question1")
								.getAsJsonObject();
					}
					if (secureDtl.has("pvtKey")) {
						String decrypt = I$Crypt.decryptText(secureDtl.get("answer").getAsString(),
								secureDtl.get("pvtKey").getAsString());
						String publicKey = i$ResM.getGobalValStr("enCryptKey");
						String encTextpub = rsaAsymCrypt.encryptText(decrypt, publicKey);

						JsonObject securityDetailsObj = new JsonObject();
						JsonObject securityDetailsFinalObj = new JsonObject();
						securityDetailsObj.addProperty("question", secureDtl.get("question").getAsString());
						securityDetailsObj.addProperty("answer", encTextpub);
						securityDetailsFinalObj.add("securityDetails", securityDetailsObj);
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
								securityDetailsFinalObj);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Retrieved");
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Security Details");
					}
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Security Details");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}// MSA00036 ends
		// MSA00037 starts

	private JsonObject digiQueryUserDetails(JsonObject isonMsg) {
		String key = i$ResM.getBodyElementS(isonMsg, "key");
		JsonObject fltr = new JsonObject();
		fltr.addProperty("key", key);
		JsonObject userData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", fltr);
		if (userData.has("securityDetails") && !I$utils.$isNull(userData.get("securityDetails").getAsJsonObject())) {
			JsonObject securityDetails = userData.get("securityDetails").getAsJsonObject();
			JsonObject securityFinalDetails = new JsonObject();
			Set<String> keys = securityDetails.keySet();
			for (String key_1 : keys) {
				JsonObject runnObj = securityDetails.get(key_1).getAsJsonObject();
				if (runnObj.has("pvtKey")) {
					String decrypt = I$Crypt.decryptText(runnObj.get("answer").getAsString(),
							runnObj.get("pvtKey").getAsString());
					String publicKey = i$ResM.getGobalValStr("enCryptKey");
					String encTextpub = rsaAsymCrypt.encryptText(decrypt, publicKey);
					securityDetails.get(key_1).getAsJsonObject().remove("pvtKey");
					securityDetails.get(key_1).getAsJsonObject().addProperty("answer", encTextpub);
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Security Details");
				}
				securityFinalDetails.add("securityDetails", securityDetails);
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, securityFinalDetails);
		} else {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Security Details");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Retrieved");
	}// MSA00037 ends
		// MSA00038 starts

	private JsonObject digiSecurityCount(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject fltr = new JsonObject();
			JsonObject fltr$ = new JsonObject();
			JsonObject validate = new JsonObject();
			JsonObject iBody = isonMsg.getAsJsonObject("i-body");
			filter.addProperty("key", iBody.get("customerId").getAsString());
			fltr$.addProperty("customerId", iBody.get("customerId").getAsString());
			fltr.addProperty("privateKey", "SIRMASIRMASIRMAS");
			JsonObject userRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter);
			JsonObject securityQuestion = userRec.get("securityDetails").getAsJsonObject();
			JsonObject securityRec = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_SECURITY_CHECK", fltr$);
			JsonObject cParamData = db$Ctrl.db$GetRow("ICOR_C_PARAM", fltr);

			if ((I$utils.$isNull(securityRec)) || (!I$utils.$isNull(securityRec)
					&& securityRec.get("retryCount").getAsInt() < cParamData.get("digiSQRetryCount").getAsInt())) {
				String iBodyAnswer = iBody.get("securityDetails").getAsJsonObject().get("answer").getAsString();
				String iBodyQuestion = iBody.get("securityDetails").getAsJsonObject().get("question").getAsString();

				Set<String> keys = securityQuestion.keySet();
				boolean checkAnswer = false;
				for (String key_1 : keys) {
					try {
						JsonObject runnObj = securityQuestion.get(key_1).getAsJsonObject();
						String runnQuestion = runnObj.get("question").getAsString();
						String runnAnswer = runnObj.get("answer").getAsString();
						String pvtKey = runnObj.get("pvtKey").getAsString();
						if (I$utils.$iStrFuzzyMatch(runnQuestion, iBodyQuestion)) {
							String iBodyAnswerDecrypt = i$impactoUtil.decryptPkey(iBodyAnswer);// present decrypted ans
							String dbdcryptAns = I$Crypt.decryptText(runnAnswer, pvtKey); // db decrypted ans
							if (I$utils.$iStrFuzzyMatch(iBodyAnswerDecrypt, dbdcryptAns)) {
								checkAnswer = true;
								db$Ctrl.db$Remove("ICOR_M_B2U_DIGI_SECURITY_CHECK", fltr$);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				if (!checkAnswer) {
					JsonObject insertData = new JsonObject();
					insertData.addProperty("customerId", iBody.get("customerId").getAsString());
					int retryCount = 0;
//					int changeCount = 0;
					if (I$utils.$isNull(securityRec)) {
						retryCount = 1;
					} else if (!I$utils.$isNull(securityRec) && securityRec.has("retryCount")) {
						retryCount = securityRec.get("retryCount").getAsInt() + 1;
					}
//					&& securityRec.get("retryCount").getAsInt() <= cParamData.get("digiSQRetryCount").getAsInt()
					insertData.addProperty("retryCount", retryCount);
//					insertData.addProperty("changeCount", changeCount);
					insertData.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
					int leftAttempt = cParamData.get("digiSQRetryCount").getAsInt() - retryCount;//////
					db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_SECURITY_CHECK", insertData, filter, "true");
					validate.addProperty("validationResult", "Fail");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
					if (leftAttempt > 0) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"Please input correct answer. You Have left with " + leftAttempt + " more Attempt(s)");
					} else {
						JsonObject updateDoc = new JsonObject();
						updateDoc.addProperty("active", "I");
						updateDoc.addProperty("activeStatus", "Inactive");
						updateDoc.add("deactivatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
						db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updateDoc, filter);
						validate.addProperty("validationResult", "Fail");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"You have been locked out of your account. Please contact us at 800-TECU (8328) or visit one of our branches for further assistance.");
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "You have been locked out of your account. Please contact us at 800-TECU (8328) or visit one of our branches for further assistance.");
					}
				} else {
					validate.addProperty("validationResult", "Success");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Security Details Validated Successfully.");
				}
			} else {
//				JsonObject updateDoc = new JsonObject();
//				updateDoc.addProperty("active", "I");
//				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updateDoc, filter);
				validate.addProperty("validationResult", "Fail");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"You have been locked out of your account. Please contact us at 800-TECU (8328) or visit one of our branches for further assistance.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;

	}// MSA00038 ends
		// MSA00039 changes starts

	private JsonObject backOfficeProcess(JsonObject isonMsg) {
		try {
			JsonObject iBody = isonMsg.getAsJsonObject("i-body");
			String digiCustNo = iBody.get("digiCustomerId").getAsString();
			String activeStatus = iBody.get("customerActiveStatus").getAsString();
			JsonObject filter = new JsonObject();
			filter.addProperty("key", digiCustNo);
			JsonObject fltr = new JsonObject();
			fltr.addProperty("customerId", digiCustNo);
//			int noOfActivated = 0 ;
			int noOfActivated = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filter).get("noOfActivatedAccount")
					.getAsInt();
			JsonObject updatedata = new JsonObject();
			JsonObject activation = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(activeStatus, "false")) {
				updatedata.addProperty("active", "A");
				updatedata.addProperty("activeStatus", "Active");
				updatedata.addProperty("noOfActivatedAccount", noOfActivated + 1);
				updatedata.add("lastActivatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updatedata, filter);
				updatedata.remove("active");// PAV00034 Changes Starts
				updatedata.remove("noOfActivatedAccount");
				updatedata.remove("lastActivatedAt");
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USER_STATUS", updatedata, filter);
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USER_STATUS_LEDGER", updatedata, filter);
				;// PAV00034 Changes Ends

				db$Ctrl.db$Remove("ICOR_M_B2U_DIGI_SECURITY_CHECK", fltr);
				activation.addProperty("activationResult", "Success");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, activation);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Account Activated Successfully");
			} else if (I$utils.$iStrFuzzyMatch(activeStatus, "true")) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Already Account is in Activate Status");
			} else {
				activation.addProperty("activationResult", "Fails");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, activation);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Activate Account");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isonMsg;
	}// MSA00039 changes ends

	private JsonObject digiUserStatusUpdate(JsonObject isonMsg) {// #PAV00029 Changes Starts
		try {
			JsonObject filter = new JsonObject();
			JsonObject updatedata = new JsonObject();
			JsonObject iBody = isonMsg.getAsJsonObject("i-body");
			JsonObject argJson = new JsonObject();
			filter.addProperty("key", iBody.get("digiCustomerId").getAsString());
			if ((iBody.has("securityQuestionsReset"))// PAV Changes
					&& (I$utils.$iStrFuzzyMatch(iBody.get("securityQuestionsReset").getAsString(), "Y"))) {
				JsonObject filter1 = new JsonObject();
				JsonObject prjctn = new JsonObject();
				JsonObject map$Data = new JsonObject();
				String sKeyE = "";

				updatedata.addProperty("securityDetails", (String) null);
				updatedata.addProperty("securityQuestionAnswered", "N");
				updatedata.addProperty("securityQuestionsReset", iBody.get("securityQuestionsReset").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updatedata, filter);

				prjctn.addProperty("CustomerFullName", 1);
				prjctn.addProperty("CustomerEmailId", 1);
				filter1.addProperty("CustomerId", iBody.get("digiCustomerId").getAsString());
				JsonObject CifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter1, prjctn);
				map$Data.addProperty("Member Full Name", CifData.get("CustomerFullName").getAsString());
				sKeyE = sKeyE.concat(CifData.get("CustomerEmailId").getAsString());
				map$Data.addProperty("tmp$name", "TECU#CIF#DIGILOGIN#REMINDER#SECURITYQUESTIONSRESET");
				argJson.add("map$Data", map$Data);
				argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);

			} // PAV Changes
			else if (iBody.has("customerActiveStatus")) {
				updatedata.addProperty("activeStatus", iBody.get("customerActiveStatus").getAsString());
				updatedata.addProperty("active", iBody.get("active").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updatedata, filter);
			}
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Status Updated Successfully");

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Status was not Updated");
		}
		return isonMsg;
	}// #PAV00029 changes ends
//	private JsonObject digiUpdateSecurityQuestions(JsonObject isonMsg) {//SBCID1179 Changes
//		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
//		String key = "";
//		key = iBody.get("key").getAsString();
//		JsonObject res = new JsonObject();
//		JsonObject digiUserData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", "{'key': '" + key + "'}");
//		if (I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionsReset").getAsString(), "N")&&I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionAnswered").getAsString(), "Y") ) {
//			res.addProperty("securityQuestionsReset",digiUserData.get("securityQuestionsReset").getAsString() );
//			res.addProperty("securityQuestionAnswered",digiUserData.get("securityQuestionAnswered").getAsString() );
//			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body",res );
//		}
//		return isonMsg;
//	}

	private JsonObject digiUpdateSecurityQuestions(JsonObject isonMsg) {// SBCID1179 Changes
		JsonObject argJson = new JsonObject();
		JsonObject map$Data = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject prjctn = new JsonObject();
		// String key = "";
		JsonObject iBody = isonMsg.getAsJsonObject("i-body");
		JsonObject digiUserData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS",
				"{'key': '" + iBody.get("key").getAsString() + "'}");
		// key = iBody.get("key").getAsString();
		prjctn.addProperty("CustomerFullName", 1);
		filter.addProperty("CustomerId", iBody.get("key").getAsString());
		JsonObject CifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, prjctn);
		JsonObject dataSetFilter = new JsonObject();
		JsonObject datasetProjection = new JsonObject();
		JsonObject emailDataset$Data = new JsonObject();
		JsonObject res = new JsonObject();
		String keyE = new String();
		dataSetFilter.addProperty("datasetId", "Dataset_5999");
		datasetProjection.addProperty("userDetails", 1);
		datasetProjection.addProperty("sendEmail", 1);
		datasetProjection.addProperty("sendSms", 1);
		emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
		if (!I$utils.$isNull(emailDataset$Data)) {
			JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
			boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
			for (int i1 = 0; i1 < userDet.size(); i1++) {
				try {
					if (sendEmail) {
						JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
						String Email = jsonObject.get("userEmailId").getAsString();
						keyE = keyE.concat(Email);
						if (i1 < userDet.size() - 1) {
							keyE = keyE.concat(",");
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionsReset").getAsString(), "N")
				&& I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionAnswered").getAsString(), "Y")) {
			try {
				map$Data.addProperty("Member Full Name", CifData.get("CustomerFullName").getAsString());
				map$Data.addProperty("CIFID", iBody.get("key").getAsString());
				map$Data.addProperty("tmp$name", "TECU#CIF#DIGILOGIN#UPDATE#SECURITYQUESTIONS");
				argJson.add("map$Data", map$Data);
				argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
			} catch (Exception e) {
				logger.debug("Failed to send email" + e.getMessage());
			}
			res.addProperty("securityQuestionsReset",digiUserData.get("securityQuestionsReset").getAsString() );
			res.addProperty("securityQuestionAnswered",digiUserData.get("securityQuestionAnswered").getAsString() );
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body",res );
		}else if (I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionsReset").getAsString(), "Y")
				&& I$utils.$iStrFuzzyMatch(digiUserData.get("securityQuestionAnswered").getAsString(), "N")){
			try {
			res.addProperty("securityQuestionsReset",digiUserData.get("securityQuestionsReset").getAsString() );
			res.addProperty("securityQuestionAnswered",digiUserData.get("securityQuestionAnswered").getAsString() );
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body",res );
			} catch (Exception e) {
				logger.debug("Failed to send email" + e.getMessage());
			}
		}
		return isonMsg;
	}
}
// #MAQ00098 Ends 