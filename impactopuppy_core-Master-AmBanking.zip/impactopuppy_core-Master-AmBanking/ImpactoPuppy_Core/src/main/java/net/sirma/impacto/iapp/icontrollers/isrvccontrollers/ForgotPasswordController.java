/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by     | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1 	   | Bhuvi 		    | Feb 24, 2019 | #BHU00001   | Initial writing
      |0.3.14.283  | Syed 		    | Jun 11, 2019 | #MAQ00018   | Password History
      |0.3.16.327  | Bhuvi 		    | Jul 29, 2019 | #BHUVI002   |  Send Notification on change Password
      |0.1 Beta    | Pruthvi 		| Jul 29, 2019 | #YPR00065   |  Validation on Forgot Pass
      ----------------------------------------------------------------------------------------------
      
*/

package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

import net.sirma.impacto.iapp.ialgo.RSAAsymetricCrypt;
import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;

public class ForgotPasswordController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	RSAAsymetricCrypt i$RSAAsy = new RSAAsymetricCrypt();
	private IpinController I$pinController = new IpinController();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private RSAAsymetricCrypt i$RSA = new RSAAsymetricCrypt();
	private OtpController otpCtrl = new OtpController();
//	private JsonObject isonMsg = new JsonObject();
	private IpasscodeController i$Pass = new IpasscodeController();
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// #00000001 START
	private static final Logger logger = LoggerFactory.getLogger(ForgotPasswordController.class);

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "setChangedPassword")) {
				
                 // #YPR00065 Starts
//				if (!I$utils.$iStrFuzzyMatch(i$ResM.getBodyElementS(isonMsg, "forgetPass"),"N")) {
					boolean verified = false;

					try {			
						String iSecKey = i$ResM.getBodyElementS(isonMsg, "iSecKey");
						String otp = i$impactoUtil.decryptPkey(i$ResM.getBodyElementS(isonMsg, "ipassCode"));
						
						if (!I$utils.$iStrBlank(otp)
								&& db$Ctrl.db$GetRowCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + otp
										+ "\" , iSecKey: \"" + iSecKey + "\" }") > 0) { // #NYE00005 // corrected the condition
							verified = true;
						} else {
							verified = false;
						}
						if (!verified) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
						} else {
							isonMsg = setChangedPassword(isonMsg);
						}
					
				}catch (Exception e) {
					logger.debug(e.getLocalizedMessage());
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Verifying OTP ");
				}
//			}else {
//				isonMsg = setChangedPassword(isonMsg);
//				}
					// #YPR00065 Ends
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};

	private JsonObject setChangedPassword(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			isonMsg.add("i-header", isonMsg.getAsJsonObject("i-header"));
			String username = i$impactoUtil.decryptPkey(i$body.get("username").getAsString());
//			String ipassCode = i$impactoUtil.decryptPkey(i$body.get("ipassCode").getAsString());
			IResManipulator.iloggedUser.set(username);// #NYE00048
			String CollName = ("ICOR_M_USER_PRF");
			JsonObject Jfilter = new JsonObject();
			Jfilter.addProperty("userId", username);
			JsonObject icorMUserPrf = db$Ctrl.db$GetRow(CollName, Jfilter.toString());

			if (icorMUserPrf == null) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER NOT FOUND");
				return isonMsg;
			}
			String sLogipassCodeReq = null; 
			String sLoginCapReq = null;

			try {
				sLogipassCodeReq = i$ResM.getGobalValJObj("srcJson").get("LoginipassCode").getAsString();
			} catch (Exception E) {
				sLogipassCodeReq = "Y";
			}
			;
			try {
				sLoginCapReq = i$ResM.getGobalValJObj("srcJson").get("LoginCaptcha").getAsString();
			} catch (Exception E) {
				sLoginCapReq = "Y";
			}

//			if (I$utils.$iStrFuzzyMatch(sLogipassCodeReq, "Y")) { // #NYE00048 Comments
//				try {
//					if (!i$Pass.Verify$PassCode(ipassCode)) {
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//								"ACCESS RESTRICTION - INVALID OR ALREADY USED PASSCODE");
//						return isonMsg;
//					}
//				} catch (Exception Ex) {
//
//					Ex.printStackTrace();
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//							"ACCESS RESTRICTION - INVALID OR UNKNOWN USER KEY");
//					return isonMsg;
//				}
//			}
//			;

			if (I$utils.$iStrFuzzyMatch(sLoginCapReq, "Y")) // #00000003 Changes for Src Validations
			{
				try {
					String secCode = i$body.get("secCode").getAsString();
					String captchaID = i$body.get("captchaID").getAsString();
					if (I$utils.$iStrBlank(secCode) || I$utils.$iStrBlank(captchaID)
							|| db$Ctrl.db$GetRowCnt("ICOR_S_CAPTCHA_VALIDATOR",
									"{ secCode: \"" + secCode + "\", captchaID: \"" + captchaID + "\" }") < 1) {
						if (I$utils.$iStrFuzzyMatch(secCode, "")) {

							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"AUTHENTICATION FAILED : INVALID CAPTCHA");
							return isonMsg;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "AUTHENTICATION FAILED : INVALID CAPTCHA");
					return isonMsg;
				}
			}
			;
			
			String StrPass = i$RSA.decryptText(i$body.get("newPassword").getAsString());
			//MAQ00018 starts
			JsonObject i$PassHist = db$Ctrl.db$GetRow("ICOR_M_PASSWORD_HISTORY", "{'userId': "+username +"}","{'_id':0}");
			JsonObject J$userdet = db$Ctrl.db$GetRow("ICOR_M_PWD_PLCY", "{}");			 
			Boolean passMatch = i$impactoUtil.checkPassHist(StrPass, i$PassHist, J$userdet);
			
			if(passMatch == true) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "This Password has already been used");
				return isonMsg;
			}
			//MAQ00018 ends
			//MAQ00019 starts
			Boolean passPolicyMet = i$impactoUtil.checkPassPolicy(StrPass, J$userdet);
			
			if(passPolicyMet == false) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg.get("i-body").getAsJsonObject(),"policy",J$userdet);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
						i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Password does not meet Policy Requirements");
				return isonMsg;
			}
			//MAQ00019 ends
			String StrGetSalt = i$impactoUtil.getSalt(30);
			String StrEncrytPass = i$impactoUtil.generateSecurePassword(StrPass, StrGetSalt);
			db$Ctrl.db$StorePassHist(StrGetSalt,StrEncrytPass,i$PassHist,username); // #MAQ00018

			JsonObject i$Doc = new JsonObject();
			i$Doc.addProperty("userPwd", StrEncrytPass);
			i$Doc.addProperty("salt", StrGetSalt);
			i$Doc.addProperty("ForcePasswordChange", "N");
			i$Doc.add("LastPasswordChange", i$ResM.adddate(new Date()));

			db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF", i$Doc, Jfilter, "true");
			db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF_LEDGER", i$Doc, Jfilter, "true");

			sendNotification(icorMUserPrf);// #BHUVI002
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PASSWORD CHANGED SUCESSFULLY");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}

		return isonMsg;

	}
	// #00000001 END

	// #BHUVI002 Start

	public void sendNotification(JsonObject icorMUserPrf)
	{
		ISmsService I$ISmsService = new ISmsService();
		IWhatsupService I$Whatsapp = new IWhatsupService();
		IEmailService i$Email = new IEmailService();

		try {
			JsonObject argJson = new JsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject to$emailIds = new JsonObject();
			JsonObject $mobNum = new JsonObject();
			JsonObject $whatsappNumbers = new JsonObject();
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendMailOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("EmpMail")) {
					to$emailIds.addProperty("toemailid1", icorMUserPrf.get("EmpMail").getAsString());
					argJson.add("toemailIds", to$emailIds);
					map$Data.addProperty("FullName", icorMUserPrf.get("name").getAsString());
					map$Data.addProperty("tmp$name", "TMPL#TT#AS#PSWDCHNGESUCES");//#YPR00066 Changes
					argJson.add("map$Data", map$Data);
					i$Email.sendEmail(argJson);

				}
			}

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendSmsOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("MobNum") && icorMUserPrf.has("IsdMobNum")) {
					$mobNum.addProperty("Mob_Number1", icorMUserPrf.get("IsdMobNum").getAsString()
							.concat(icorMUserPrf.get("MobNum").getAsString()));
				}
				argJson.add("mobile$numbers", $mobNum);
				map$Data.addProperty("FullName", icorMUserPrf.get("name").getAsString());
				map$Data.addProperty("tmp$name", "TMPL#TT#AS#PSWDCHNGESUCES");//#YPR00066 Changes
				argJson.add("map$Data", map$Data);
				I$ISmsService.sendSMS(argJson);

			}

			if (I$utils.$iStrFuzzyMatch(commMode.get("iWhatsUpOtp").getAsString(), "Y")) {
				if (icorMUserPrf.has("WhtsAppNum") && icorMUserPrf.has("IsdWhtsAppNum")) {
					$whatsappNumbers.addProperty("Whatsapp_Numbers1", icorMUserPrf.get("IsdWhtsAppNum").getAsString()
							.concat(icorMUserPrf.get("WhtsAppNum").getAsString()));
				} else {
					if (icorMUserPrf.has("MobNum") && icorMUserPrf.has("IsdMobNum")) {
						$whatsappNumbers.addProperty("Whatsapp_Numbers1", icorMUserPrf.get("IsdMobNum").getAsString()
								.concat(icorMUserPrf.get("MobNum").getAsString()));
					}
				}
				argJson.add("mobile$numbers", $whatsappNumbers);
				map$Data.addProperty("FullName", icorMUserPrf.get("name").getAsString());
				map$Data.addProperty("tmp$name", "TMPL#TT#AS#PSWDCHNGESUCES");//#YPR00066 Changes
				argJson.add("map$Data", map$Data);
				I$Whatsapp.sendWhatsup(argJson);

			}

		} catch (Exception e) {
			e.getMessage();
		}
		// #BHUVI002 Ends
	}
}
