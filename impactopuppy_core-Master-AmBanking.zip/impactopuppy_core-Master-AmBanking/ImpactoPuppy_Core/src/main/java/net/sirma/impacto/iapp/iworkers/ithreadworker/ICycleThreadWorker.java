/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Baz 		| Oct 08, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Dec 10, 2018  | #BVB00026   | Added functions to handle -- iPortfolioClassification, iBucketization, iPDCalculation, iLgdAssignement, iEclCalculation
      |0.2.1	   | Syed 		| Jan 09, 2019  | #MAQ00001   | Added changes to fix iEclCalculation
      |0.2.1	   | Syed 		| Jan 09, 2019  | #MAQ00002   | Changed 'EXPOSURERID' to 'EXPOSURERID'
      |0.2.1       | Syed       | Jan 17,2019   | #MAQ00003   | Added Corp Changes to ICycle(Vijay)
      |0.2.1       | Syed       | Jan 28,2019   | #MAQ00004   | Added projection in ECL for Charts            
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iworkers.ithreadworker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
//import net.sirma.impacto.iapp.icontrollers.iworkers.ithreadworker;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil; // #MAQ00003
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICycleThreadWorker {
	private Logger logger = LoggerFactory.getLogger(ICycleThreadWorker.class);
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil I$impcatoUtil = new ImpactoUtil(); // #MAQ00003

	// #BVB00026 Starts
	public void i$PortfolioClassification(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		String L_Coll_Name = "";
		String outCollName = "";
		Gson gson = new Gson();
		String errMsg = "";
		String cycleId = "";
		try {
			isonMsg = argJson.get("isonMsg").getAsJsonObject();
			i$body = isonMsg.getAsJsonObject("i-body");
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();

			// Get the master details of Run ID:

			JsonObject i$exposureRun = new JsonObject();
			filter = new JsonObject();
			filter = new JsonObject();
			String runId = i$body.get("exposureRunID").getAsString();

			filter.addProperty("RUNID", runId);
			i$exposureRun = db$Ctrl.db$GetRow("IBRIDGE_S_JOB_LOGGER", gson.toJson(filter));
			String runCollName = i$exposureRun.get("COLLECTION_NAME").getAsString();
			cycleId = i$body.get("cycleId").getAsString();
			outCollName = "ICYCLE_" + "EX_" + cycleId;

			// Create a dummy Collection from the given Collection ID
			filter = new JsonObject();
			projection = new JsonObject();
			JsonObject $cp = db$Ctrl.db$copyCollection(runCollName, outCollName, filter, projection);

			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($cp), "i-SUCC")) {

				logger.debug("Failed in Creating the ICycle Collection ");
				errMsg = "FAILED DURING ICYCLE COLLECTION CREATION";
				return;

				// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
				// "FAILED DURING ICYCLE COLLECTION CREATION");
				// return isonMsg;
			} else {

				filter = new JsonObject();
				filter.addProperty("cycleId", cycleId);
				setter = new JsonObject();
				setter.addProperty("collectionName", outCollName);
				JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);

			}
			;

			filter.addProperty("INDEXCOlNAME", "EXPOSURE_ID");
			// iFilter.addProperty("INDEXCOlNAME", "EXPOSURE_ID");
			db$Ctrl.db$createIndex(outCollName, filter.toString());

			// Initialize Portfolio Classification

			// Get the rules that needs to be executed from DB
			filter = new JsonObject();
			filter.addProperty("ruleId", i$body.get("portclassrule").getAsString());

			JsonObject icorMRule = db$Ctrl.db$GetRow("ICOR_M_RULES", gson.toJson(filter));

			JsonArray i$rules = icorMRule.get("mongoRules").getAsJsonArray();
			for (int i = 0; i < i$rules.size(); i++) {
				try {
					JsonObject i$runningRule = i$rules.get(i).getAsJsonObject();
					String ruleFilter = i$runningRule.get("ruleFilter").getAsString();
					String set = i$runningRule.get("set").getAsString();
					ruleFilter = ruleFilter.replace('#', '$');
					db$Ctrl.db$UpdateRow(outCollName, set, ruleFilter);
				} catch (Exception e) {
					//
				}
			}
			// Create a new Column here

			errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			// Eat Up
			errMsg = "FAILED WHILE PERFORMING PORTFOLIO CLASSIFICATION " + e.getMessage();
			return;
		} finally {

			// Came here --> Portfolio Classification Completed
			filter = new JsonObject();
			filter.addProperty("cycleId", i$body.get("cycleId").getAsString());

			setter = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
				setter.addProperty("nextStageStatus", "Completed");
			} else {
				setter.addProperty("nextStageStatus", "Failed");
			}
			setter.addProperty("errMsg", errMsg);
			setter.addProperty("collectionName", outCollName);
			JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);

		}
	}

	public void i$Bucketization(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		// JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		JsonObject icorMCycle = new JsonObject();
		JsonObject projection = new JsonObject(); // #MAQ00003
		String collectionName = "";
		String L_Coll_Name = "";
		Gson gson = new Gson();
		String errMsg = "";
		// #MAQ00003 starts
		int i$limit = 0;
		int i$ThreadNo = 0;
		JsonArray i$exposures = new JsonArray();
		// #MAQ00003 ends
		try {
			isonMsg = argJson.get("isonMsg").getAsJsonObject();

			i$body = isonMsg.getAsJsonObject("i-body");
			collectionName = argJson.get("collectionName").getAsString();
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();
			icorMCycle = argJson.get("icorMCycle").getAsJsonObject();
			String outCollName = icorMCycle.get("collectionName").getAsString();
//			 // #MAQ00003 start
//			i$limit = argJson.get("i$limit").getAsInt();
//			i$ThreadNo = argJson.get("i$ThreadNo").getAsInt();
//
//			projection.addProperty("_id", 0);
//			projection.addProperty("EXPOSURE_ID", 1);
//			projection.addProperty("EXPOSURE_PORTFOLIO_FINAL", 1);
//			projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
//			 // #MAQ00003 end  
			// Get the rules that needs to be executed from DB
			filter = new JsonObject();
			filter.addProperty("ruleId", icorMCycle.get("bucketrule").getAsString());

//			JsonArray icorMRuleArr = db$Ctrl.db$GetSummRowsArray("ICOR_M_RULES", gson.toJson(filter), projection, i$ThreadNo, i$limit); // #MAQ00003
//			JsonObject icorMRule = icorMRuleArr.getAsJsonObject();
			JsonObject icorMRule = db$Ctrl.db$GetRow("ICOR_M_RULES", gson.toJson(filter));

			JsonArray i$rules = icorMRule.get("mongoRules").getAsJsonArray();
			for (int i = 0; i < i$rules.size(); i++) {

				JsonObject i$runningRule = i$rules.get(i).getAsJsonObject();
				String ruleFilter = i$runningRule.get("ruleFilter").getAsString();
				String set = i$runningRule.get("set").getAsString();
				ruleFilter = ruleFilter.replace('#', '$');

				db$Ctrl.db$UpdateRow(collectionName, set, ruleFilter);
			}
			errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			errMsg = "FAILED WHILE PERFORMING BUCKETIZATION " + e.getMessage();

		} finally {
			// Came here --> Portfolio Classification Successful
			filter = new JsonObject();
			filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
			// #MAQ00003 start
			icorMCycle = db$Ctrl.db$GetRow(L_Coll_Name, filter);
			setter = new JsonObject();
			setter.addProperty("noOfExecutedThreads", icorMCycle.get("noOfExecutedThreads").getAsInt() + 1);
			if ((icorMCycle.get("noOfThreads").getAsInt() - 1) == icorMCycle.get("noOfExecutedThreads").getAsInt()) {
				if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
					setter.addProperty("nextStageStatus", "Completed");
				} else {
					setter.addProperty("nextStageStatus", "Failed");
				}
			}
			setter.addProperty("i$ThreadStatus." + i$ThreadNo, errMsg);
			// #MAQ00003 end
			JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);

		}

	}

	public void i$PDCalculation(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		// JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		JsonObject icorMCycle = new JsonObject();
		String collectionName = "";
		String L_Coll_Name = "";
		Gson gson = new Gson();
		String errMsg = "";
		// MAQ00003 start
		JsonObject projection = new JsonObject();
		int i$ThreadNo = 0;
		int i$limit = 0;
		double finalValue = 0.0;
		// MAQ00003 end
		try {
			isonMsg = argJson.get("isonMsg").getAsJsonObject();

			i$body = isonMsg.getAsJsonObject("i-body");
			collectionName = argJson.get("collectionName").getAsString();
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();
			// MAQ00003 start
			// icorMCycle = argJson.get("icorMCycle").getAsJsonObject();
			i$ThreadNo = argJson.get("i$ThreadNo").getAsInt();
			// i$limit = argJson.get("i$limit").getAsInt();

			projection.addProperty("_id", 0);
			projection.addProperty("EXPOSURE_ID", 1);
			projection.addProperty("EXPOSURE_PORTFOLIO", 1);
			projection.addProperty("EXPOSURE_PORTFOLIO_FINAL", 1);
			projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
			projection.addProperty("BORROWER_ID", 1);
			// MAQ00003 end
			icorMCycle = argJson.get("icorMCycle").getAsJsonObject();

			collectionName = icorMCycle.get("collectionName").getAsString();
			String pdManualId = null, macroMapId = null;
			String pdMode = icorMCycle.get("pdMode").getAsString();
			if (pdMode.equalsIgnoreCase("M")) {
				pdManualId = icorMCycle.get("pdMapId").getAsString();
			} else {
				pdManualId = null;
			}
			try {
				macroMapId = icorMCycle.get("macroMapId").getAsString();
			} catch (Exception e) {
				macroMapId = "32843274"; // BVB Y?!
			}

			JsonObject iCore$MacroInput = new JsonObject();
			filter = new JsonObject();
			// filter.addProperty("mapId", pdManualId);

			// Apply Macro Economic Calculated value to Impacto calculated PD.
			JsonObject mFilter = new JsonObject();
			mFilter.addProperty("mapId", macroMapId);
			iCore$MacroInput = db$Ctrl.db$GetRow("ICOR_M_IFRS_MACROECO", gson.toJson(mFilter));
			double i$macroFValue = 0.00;
			try {
				i$macroFValue = (iCore$MacroInput.get("pdMacroValue").getAsDouble());
			} catch (Exception e) {
				i$macroFValue = 1;
			}

			// Get for the SIC

			// Get for the Borrower Employer

			// Get for the Borrower

			// Fire PD Rules --> Get the PD rule from Master. From that for portfolio,
			// bucket combination fire UpdateMany

			if (I$utils.$iStrFuzzyMatch(pdMode, "M")) {
				JsonObject icorMPdInput = new JsonObject();

				filter = new JsonObject();
				filter.addProperty("mapId", pdManualId);

				icorMPdInput = db$Ctrl.db$GetRow("ICOR_M_IFRS_PDINPUT", gson.toJson(filter));

				String[] bucket = { "bucket1", "bucket2", "bucket3" };

				for (int i = 0; i < bucket.length; i++) {
					JsonArray bucketDetails = new JsonArray();
					bucketDetails = icorMPdInput.get(bucket[i]).getAsJsonArray();
					// Fire rule for the Bucket to PD

					for (int j = 0; j < bucketDetails.size(); j++) {
						JsonObject i$runningObj = bucketDetails.get(j).getAsJsonObject();
						setter = new JsonObject();

						// BVB
						double i$finalPD = 0;
						i$finalPD = i$runningObj.get("pdPerc").getAsDouble() * i$macroFValue;

						if (i$finalPD > 100) {
							i$finalPD = 100;
						} else if (i$finalPD < 0) {
							i$finalPD = 0;
						}

						// BVB

						setter.addProperty("PD", i$finalPD);
						setter.addProperty("PD_FINAL", i$finalPD);

						filter = new JsonObject();
						String value = "";
						if (I$utils.$iStrFuzzyMatch(bucket[i], "bucket1")) {
							value = "BUCKET 1";
						} else if (I$utils.$iStrFuzzyMatch(bucket[i], "bucket2")) {
							value = "BUCKET 2";
						} else if (I$utils.$iStrFuzzyMatch(bucket[i], "bucket3")) {
							value = "BUCKET 3";
						}
						filter.addProperty("BUCKETIZATION", value);
						filter.addProperty("EXPOSURE_PORTFOLIO", i$runningObj.get("portId").getAsString());

						db$Ctrl.db$UpdateRow(collectionName, setter, filter);

					}
				}

			} else if (I$utils.$iStrFuzzyMatch(pdMode, "A")) {

				JsonObject aggFilter = new JsonObject();

				aggFilter.addProperty("OUTCOLL", collectionName);
				aggFilter.addProperty("Query",
						"{$addFields:{\"PD\": { $cond: [ { $eq: [ \"$NO_OF_PAYMENT_SCH\", 0] }, 0.00,{ $divide: [  \"$NOS_LATE30\", \"$NO_OF_PAYMENT_SCH\" ]}]}}}");
				db$Ctrl.db$UpdateWNewFld(collectionName, aggFilter.toString());
			}

			// Apply Borrower Employer (Absolute Value) Value to PD

			errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			errMsg = "FAILED WHILE PERFORMING PD Assignment " + e.getMessage();

		} finally {
			// Came here --> Portfolio Classification Successful
			filter = new JsonObject();
			filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
			setter = new JsonObject();

			if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
				setter.addProperty("nextStageStatus", "Completed");
			} else {
				setter.addProperty("nextStageStatus", "Failed");
			}
			setter.addProperty("errMsg", errMsg);
			JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);

		}

	}

	public void i$LgdAssignement(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		JsonObject icorMCycle = new JsonObject();
		String collectionName = "";
		String L_Coll_Name = "";
		String exposureId = "";
		String errMsg = "";
		String collRevColName = "";
		// MAQ00003 start
		String i$bucket = "";
		String i$portfolio = "";
		// MAQ00003 end
		int i$ThreadNo = 0;
		double uncoveredAmount = 0;
		JsonArray i$exposures = new JsonArray();
		double outSPrincAmount = 0;
		double outSIntAmount = 0;
		double totalOutSAmount = 0;
		double collectionProtPer = 0;
		double collectionProtValue = 0;
		double LGD = 0;
		int count = 0;
		int i$limit = 0;
		try {
			isonMsg = argJson.get("isonMsg").getAsJsonObject();

			i$body = isonMsg.getAsJsonObject("i-body");
			collectionName = argJson.get("collectionName").getAsString();
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();
			icorMCycle = argJson.get("icorMCycle").getAsJsonObject();
			i$ThreadNo = argJson.get("i$ThreadNo").getAsInt();
			collRevColName = argJson.get("collRevColName").getAsString();
			i$limit = argJson.get("i$limit").getAsInt();

			projection.addProperty("_id", 0);
			projection.addProperty("EXPOSURE_ID", 1);
			projection.addProperty("PRINCIPAL_AT_POINT_IN_TIME", 1);
			projection.addProperty("MAIN_INT_AT_POINT_IN_TIME", 1);
			projection.addProperty("COLLECTION_PROTECTION", 1);
			projection.addProperty("BUCKETIZATION_FINAL", 1); // MAQ00003
			projection.addProperty("EXPOSURE_PORTFOLIO_FINAL", 1);

			i$exposures = db$Ctrl.db$GetSummRowsArray(collectionName, filter, projection, i$ThreadNo, i$limit);

			count = i$exposures.size();

			for (int i = 0; i < count; i++) {

				try {
					setter = new JsonObject();
					JsonObject i$runningObj = i$exposures.get(i).getAsJsonObject();
					exposureId = i$runningObj.get("EXPOSURE_ID").getAsString();
					outSPrincAmount = i$runningObj.get("PRINCIPAL_AT_POINT_IN_TIME").getAsDouble();
					outSIntAmount = i$runningObj.get("MAIN_INT_AT_POINT_IN_TIME").getAsDouble();
					i$bucket = i$runningObj.get("BUCKETIZATION_FINAL").getAsString(); // MAQ00003
					i$portfolio = i$runningObj.get("EXPOSURE_PORTFOLIO_FINAL").getAsString();// MAQ00003

					// Getting Outstanding Loan Amount from the Exposure Collection
					totalOutSAmount = outSPrincAmount + outSIntAmount;

					// Getting the Collateral Re-evaluation from the Map ID from ICycleMappiing
					// This comes in Direct Value
					// JsonObject i$reval = i$collRevHash.get(i)
					filter = new JsonObject();
					filter.addProperty("EXPOSURE_ID", exposureId);// MAQ00005
					JsonObject i$collRev = db$Ctrl.db$GetRow(collRevColName, filter);

					// Calculate the Uncovered amount of the Loan at this point of Time

					try {
						uncoveredAmount = totalOutSAmount - i$collRev.get("COLLATERAL_VAL_CURR").getAsDouble();
						setter.addProperty("COLLATERAL_PROTECTION", i$collRev.get("COLLATERAL_VAL_CURR").getAsDouble());

					} catch (Exception e) {

						try {

							uncoveredAmount = totalOutSAmount - i$collRev.get("COLLATERAL_VAL_INCEPTION").getAsDouble();
							setter.addProperty("COLLATERAL_VAL_CURR",
									i$collRev.get("COLLATERAL_VAL_INCEPTION").getAsDouble());

							setter.addProperty("COLLATERAL_PROTECTION", 0);

						} catch (Exception ex) {
							uncoveredAmount = totalOutSAmount; // Have to check this.
							setter.addProperty("COLLATERAL_VAL_CURR", 0);

							setter.addProperty("COLLATERAL_PROTECTION", 0);
						}
					}

					if (uncoveredAmount < 0) { // MAQ00003
						uncoveredAmount = 0;
					}

					// Getting the Collection Protection From the Map ID From ICycleMapping
					// This comes in Percentage
					try {
						setter.addProperty("COLLECTION_PROTECTION_PER", I$utils.round(collectionProtPer, 2)); // MAQ00003
					} catch (Exception e) {
						logger.debug("Failed while getting the Collection protection from the Exposure collection");
						collectionProtPer = 0; // Have to check this
					}
					;
					setter.addProperty("COLLECTION_PROTECTION_PER", collectionProtPer);
					// Calculate amount that can be retrieved -- Collection Protection Value

					collectionProtValue = (uncoveredAmount * collectionProtPer) / 100;

					// LGD Is (exposure - collectionValue )*100 / Outstanding Loan Amount
					try {
						if (totalOutSAmount > 0) {
							LGD = ((uncoveredAmount - collectionProtValue) * 100) / totalOutSAmount;
						} else {
							LGD = 0;
						}
					} catch (Exception e) {
						e.printStackTrace();
						LGD = 0;
					}
				} catch (Exception e) {
					e.printStackTrace();
					outSPrincAmount = 0;
					outSIntAmount = 0;
					totalOutSAmount = 0;
					collectionProtPer = 0;
					collectionProtValue = 0;
					LGD = 0;
				}
				// MAQ00003 start
				setter.addProperty("UNCOVERED_AMOUNT", I$utils.round(uncoveredAmount, 2));
				setter.addProperty("COLLECTION_PROTECTION", I$utils.round(collectionProtValue, 2));
				setter.addProperty("TOTAL_OUTS_AMOUNT", I$utils.round(totalOutSAmount, 2));
				setter.addProperty("LGD", I$utils.round(LGD, 2));
				setter.addProperty("LGD_FINAL", I$utils.round(LGD, 2));
				// MAQ00003 end
				filter = new JsonObject();
				filter.addProperty("EXPOSURE_ID", exposureId);
				db$Ctrl.db$UpdateRow(collectionName, setter, filter);
			}
			;

			errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			errMsg = "FAILED WHILE PERFORMING LGD ASSIGNMENT" + e.getMessage();

		} finally {
			// Feeding number of threads to Master Table
			filter = new JsonObject();
			filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
			// JsonArray i$ThreadStatus = icorMCycle.getAsJsonArray("i$ThreadStatus");
			icorMCycle = db$Ctrl.db$GetRow(L_Coll_Name, filter);
			setter = new JsonObject();
			setter.addProperty("noOfExecutedThreads", icorMCycle.get("noOfExecutedThreads").getAsInt() + 1);
			if ((icorMCycle.get("noOfThreads").getAsInt() - 1) == icorMCycle.get("noOfExecutedThreads").getAsInt()) {
				if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
					setter.addProperty("nextStageStatus", "Completed");
				} else {
					setter.addProperty("nextStageStatus", "Failed");
				}
			}
			setter.addProperty("i$ThreadStatus." + i$ThreadNo, errMsg);
			JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);
		}

	}

	public void i$ReBucketization(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		// JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		JsonObject icorMCycle = new JsonObject();
		String collectionName = "";
		String L_Coll_Name = "";
		Gson gson = new Gson();
		String errMsg = "";
		try {
			isonMsg = argJson.get("isonMsg").getAsJsonObject();

			i$body = isonMsg.getAsJsonObject("i-body");
			collectionName = argJson.get("collectionName").getAsString();
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();
			icorMCycle = argJson.get("icorMCycle").getAsJsonObject();

			filter = new JsonObject();
			filter.addProperty("ruleId", icorMCycle.get("rebucketrule").getAsString());

			JsonObject icorMRule = db$Ctrl.db$GetRow("ICOR_M_RULES", gson.toJson(filter));

			JsonArray i$rules = icorMRule.get("mongoRules").getAsJsonArray();
			for (int i = 0; i < i$rules.size(); i++) {

				JsonObject i$runningRule = i$rules.get(i).getAsJsonObject();
				String ruleFilter = i$runningRule.get("ruleFilter").getAsString();
				String set = i$runningRule.get("set").getAsString();
				ruleFilter = ruleFilter.replace('#', '$');

				db$Ctrl.db$UpdateRow(collectionName, set, ruleFilter);

			}

			errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			errMsg = "FAILED WHILE PERFORMING RE-BUCKETIZATION " + e.getMessage();

		} finally {
			// Came here --> Portfolio Classification Successful
			filter = new JsonObject();
			filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
			setter = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
				setter.addProperty("nextStageStatus", "Completed");
			} else {
				setter.addProperty("nextStageStatus", "Failed");
			}
			setter.addProperty("errMsg", errMsg);

			JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);

		}

	}

	public void i$EclClaculation(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		String collectionName = "";
		String lendScheduleColl = "";
		String iCyclescheduleColl = "";
		String L_Coll_Name = "";
		int i$ThreadNo = 0;
		int i$limit = 0;
		JsonObject icorMCycle = new JsonObject();

		JsonObject i$runningSchOut = new JsonObject();
		String errMsg = "";
		Gson gson = new Gson();
		JsonArray i$scheduleOut = new JsonArray();

		try {
			isonMsg = argJson.get("isonMsg").getAsJsonObject();

			i$body = isonMsg.getAsJsonObject("i-body");
			collectionName = argJson.get("collectionName").getAsString();
			i$ThreadNo = argJson.get("i$ThreadNo").getAsInt();
			lendScheduleColl = argJson.get("lendScheduleColl").getAsString();
			iCyclescheduleColl = argJson.get("iCyclescheduleColl").getAsString();
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();
			i$limit = argJson.get("i$limit").getAsInt();

			if (!I$utils.$iStrFuzzyMatch(collectionName, "") && !I$utils.$iStrFuzzyMatch(lendScheduleColl, "")
					&& !I$utils.$iStrFuzzyMatch(iCyclescheduleColl, "")) {

				projection.addProperty("_id", 0);
				projection.addProperty("EXPOSURE_ID", 1);
				projection.addProperty("BUCKETIZATION", 1);
				projection.addProperty("INTEREST_PROFIT_RATE", 1);
				projection.addProperty("LGD", 1);
				projection.addProperty("PD", 1);
				projection.addProperty("EXPOSURE_PRODUCT", 1);
				projection.addProperty("EXPOSURE_PORTFOLIO", 1);
				projection.addProperty("EXPOSURE_PRODUCT", 1);
				projection.addProperty("EXPOSURE_PRODUCT_CATEGORY", 1);
				projection.addProperty("REBUCKETIZATION", 1);
				projection.addProperty("BUCKETIZATION_FINAL", 1);
				projection.addProperty("LGD_FINAL", 1);
				projection.addProperty("PD_FINAL", 1);
				projection.addProperty("EXPOSURE_PORTFOLIO_FINAL", 1);
				projection.addProperty("REBUCKETIZATION_FINAL", 1);
				
				// #MAQ00004 start
				projection.addProperty("EXPOSURE_TYPE_ID", 1);
				projection.addProperty("EXPOSURE_ENTITY_VALUE", 1);
				projection.addProperty("EXPOSURE_PORTFOLIO_FINAL", 1);
				projection.addProperty("BUCKETIZATION", 1);
				projection.addProperty("REBUCKETIZATION_FINAL", 1);
				// #MAQ00004 end


				JsonArray i$exposures = db$Ctrl.db$GetSummRowsArray(collectionName, filter, projection, i$ThreadNo,
						i$limit);
				if (i$exposures != null) {
					for (int i = 0; i < i$exposures.size(); i++) {

						try {
							// Pull each exposure related schedules based on Bucket of the Exposure
							JsonObject i$runningObj = i$exposures.get(i).getAsJsonObject();
							String i$exposureId = i$runningObj.get("EXPOSURE_ID").getAsString();
							String i$exposureBucket = i$runningObj.get("BUCKETIZATION_FINAL").getAsString();
							double i$interestRate = i$runningObj.get("INTEREST_PROFIT_RATE").getAsDouble();
							double i$lgd = i$runningObj.get("LGD_FINAL").getAsDouble();
							double i$pd = i$runningObj.get("PD_FINAL").getAsDouble();

							// BVB Below needs to be changed based on the formula change and the date, due
							// validation
							// Getting the schedules related to Exposure
							String strAggQuery = "";

							// #MAQ00001 start
							if (I$utils.$iStrFuzzyMatch(i$exposureBucket, "BUCKET 1")) {
								strAggQuery = "{$expr: {$gt: ['$AMOUNTTOBEPAID', '$SETTLEDAMOUNT']}, 'EXPOSURE_ID':'" // #MAQ00002
										+ i$exposureId + "', 'SCHEDULESTARTDATE':{$gte:'" + I$utils.getDate()
										+ " 00:00:00.0', $lte:'" + I$utils.getDateOneYear()
										+ " 00:00:00.0'},'ELEMENTNAME':{$in: ['PRINCIPAL','MAIN_INT']}}";
							} else if (I$utils.$iStrFuzzyMatch(i$exposureBucket, "BUCKET 2")) {
								strAggQuery = "{$expr: {$gt: ['$AMOUNTTOBEPAID', '$SETTLEDAMOUNT']}, 'EXPOSURE_ID':'" // #MAQ00002
										+ i$exposureId
										+ "','ELEMENTNAME':'PRINCIPAL','ELEMENTNAME':{$in: ['PRINCIPAL','MAIN_INT']} }";
							} else if (I$utils.$iStrFuzzyMatch(i$exposureBucket, "BUCKET 3")) {
								strAggQuery = "{$expr: {$gt: ['$AMOUNTTOBEPAID', '$SETTLEDAMOUNT']}, 'EXPOSURE_ID':'" // #MAQ00002
										+ i$exposureId
										+ "','ELEMENTNAME':'PRINCIPAL', 'ELEMENTNAME':{$in: ['PRINCIPAL']} }";
							}
							;
							// #MAQ00001 end

							projection = new JsonObject();
							projection.addProperty("_id", 0);
							projection.addProperty("AMOUNTTOBEPAID", 1);
							projection.addProperty("SETTLEDAMOUNT", 1);
							projection.addProperty("SCHEDULESTARTDATE", 1);

							/*
							 * JsonObject aggFilter = new JsonObject(); aggFilter.addProperty("Query",
							 * strAggQuery); aggFilter.addProperty("projection", gson.toJson(projection));
							 */

							JsonArray i$schedules = db$Ctrl.db$getRowAgg(lendScheduleColl, strAggQuery, projection);

							// int i$schedulesCount = db$Ctrl.db$GetCountI(lendScheduleColl, filter);

							// JsonArray i$schedules = db$Ctrl.db$GetRows(lendScheduleColl, filter,
							// projection);

							// BVB Till here for getting records

							// Now loop the schedules on the formula to calculate the PIT_EAD
							for (int j = 0; j < i$schedules.size(); j++) {

								try {
									JsonObject i$runningSchedule = i$schedules.get(j).getAsJsonObject();
									i$runningSchOut = new JsonObject();

									double i$pitEad = 1;
									double i$amountToBePaid = i$runningSchedule.get("AMOUNTTOBEPAID").getAsDouble();
									double i$settledAmount = i$runningSchedule.get("SETTLEDAMOUNT").getAsDouble();
									String i$scheduleDate = i$runningSchedule.get("SCHEDULESTARTDATE").getAsString();
									// PIT_EAD Calculation
									if (I$utils.$iStrFuzzyMatch(i$exposureBucket, "BUCKET 1")
											|| I$utils.$iStrFuzzyMatch(i$exposureBucket, "BUCKET 2"))
										i$pitEad = i$amountToBePaid / Math.pow((1 + (i$interestRate / 100)), j);
									else {
										i$pitEad = i$amountToBePaid;
									}

									// ECL Calculation is PIT_EAD * LGD * PD

									double i$ecl = i$pitEad * i$lgd * i$pd;
									i$ecl = i$ecl / 10000; // MAQ00001
									
									i$runningSchOut.addProperty("EXPOSURE_ID", i$exposureId); // #MAQ00002
									i$runningSchOut.addProperty("EXPOSURE_PRODUCT",
											i$runningObj.get("EXPOSURE_PRODUCT").getAsString());
									// #MAQ00004 start
									i$runningSchOut.addProperty("EXPOSURE_PRODUCT_CATEGORY",
											i$runningObj.get("EXPOSURE_PRODUCT_CATEGORY").getAsString());
									i$runningSchOut.addProperty("EXPOSURE_TYPE_ID",
											i$runningObj.get("EXPOSURE_TYPE_ID").getAsString());
									i$runningSchOut.addProperty("EXPOSURE_ENTITY_VALUE",
											i$runningObj.get("EXPOSURE_ENTITY_VALUE").getAsString());
									i$runningSchOut.addProperty("EXPOSURE_PORTFOLIO",
											i$runningObj.get("EXPOSURE_PORTFOLIO").getAsString());
									i$runningSchOut.addProperty("BUCKETIZATION_FINAL",
											i$runningObj.get("BUCKETIZATION_FINAL").getAsString());
									i$runningSchOut.addProperty("EXPOSURE_PORTFOLIO_FINAL",
											i$runningObj.get("EXPOSURE_PORTFOLIO_FINAL").getAsString());
									// #MAQ00004 end
									i$runningSchOut.addProperty("PD", i$runningObj.get("PD_FINAL").getAsDouble());
									i$runningSchOut.addProperty("BUCKETIZATION", i$exposureBucket);
									i$runningSchOut.addProperty("EXPOSURE_PRODUCT",
											i$runningObj.get("EXPOSURE_PRODUCT").getAsString());
									i$runningSchOut.addProperty("EXPOSURE_PRODUCT_CATEGORY",
											i$runningObj.get("EXPOSURE_PRODUCT_CATEGORY").getAsString());
									i$runningSchOut.addProperty("AMOUNTTOBEPAID", i$amountToBePaid);
									i$runningSchOut.addProperty("SETTLEDAMOUNT", i$settledAmount);
									i$runningSchOut.addProperty("SCHEDULEDUEDATE", i$scheduleDate);
									i$runningSchOut.addProperty("REBUCKETIZATION",
											i$runningObj.get("REBUCKETIZATION_FINAL").getAsString());
									i$runningSchOut.addProperty("INTEREST_PROFIT_RATE", i$interestRate);
									i$runningSchOut.addProperty("amountToBePaid", i$amountToBePaid);
									i$runningSchOut.addProperty("PIT_EAD", i$pitEad);
									// MAQ00001 start
									i$runningSchOut.addProperty("LGD", i$lgd);
									i$runningSchOut.addProperty("PD", i$pd);
									i$runningSchOut.addProperty("ECL", I$utils.round(i$ecl, 2));
									i$runningSchOut.addProperty("ECL_USER", "");
									i$runningSchOut.addProperty("ECL_MANAGEMENT", "");
									i$runningSchOut.addProperty("ECL_FINAL", I$utils.round(i$ecl, 2));
									// MAQ00001 end
									i$scheduleOut.add(i$runningSchOut);
								} catch (Exception e) {
									// Eat Up
									i$runningSchOut.addProperty("EXPOSURE_ID", i$exposureId); // #MAQ00002
									i$runningSchOut.addProperty("SCHEDULEDUEDATE",
											i$runningObj.get("SCHEDULEDUEDATE").getAsString());
									i$runningSchOut.addProperty("ECL", 0);

									i$scheduleOut.add(i$runningSchOut);

								}
							}
// 							#MAQ00001 start
							if (i != 0 && i % 100 == 0) {
//								// Commit the messages
								if (!I$utils.$isNull(i$scheduleOut)) {
									db$Ctrl.db$InsertMany(iCyclescheduleColl, i$scheduleOut);
									i$scheduleOut = new JsonArray();
								}							
 							} // #MAQ00001 end
							// Store the content for bulk insertion based on exposure
						} catch (Exception ex) {
							// Eat Up
						}

					}
				}
				errMsg = "";
			} else {
				errMsg = "NO EXPOSURES FOUND";
			}

		} catch (Exception e) {
			e.printStackTrace();
			errMsg = "FAILED IN THREAD: " + i$ThreadNo + " with error: " + e.getMessage();
		} finally {
			// Feeding number of threads to Master Table
			try {
				filter = new JsonObject();
				filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
				// JsonArray i$ThreadStatus = icorMCycle.getAsJsonArray("i$ThreadStatus");
				icorMCycle = db$Ctrl.db$GetRow(L_Coll_Name, filter);
				setter = new JsonObject();
				setter.addProperty("noOfExecutedThreads", icorMCycle.get("noOfExecutedThreads").getAsInt() + 1);
				setter.addProperty("iCyclescheduleColl", iCyclescheduleColl);

				if ((icorMCycle.get("noOfThreads").getAsInt() - 1) == icorMCycle.get("noOfExecutedThreads")
						.getAsInt()) {
					if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
						setter.addProperty("nextStageStatus", "Completed");
					} else {
						setter.addProperty("nextStageStatus", "Failed");
					}
				}
				setter.addProperty("i$ThreadStatus." + i$ThreadNo, errMsg);
				JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);
			} catch (Exception ex) {
				filter = new JsonObject();
				filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
				// JsonArray i$ThreadStatus = icorMCycle.getAsJsonArray("i$ThreadStatus");
				setter = new JsonObject();
				errMsg = "Failed with: " + ex.getMessage();
				setter.addProperty("i$ThreadStatus." + i$ThreadNo, errMsg);
				JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);
			}
		}

	}

	// #BVB00026 Ends
}
// #00000001 Ends
