/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |1.0.0       | Nye 		| Jul 02, 2019  | #00000001   | Initial writing
      |1.0.0       | Nye 		| Jul 05, 2019  | #00000002   | Handled Detection Failure 
      |0.3.17      | Vijay 		| Jul 20, 2019  | #BVB00187   | Empty images check 
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.Map;
import java.util.Map.Entry;

import org.openimaj.feature.FloatFV;
import org.openimaj.feature.FloatFVComparison;
import org.openimaj.image.FImage;
import org.openimaj.image.ImageUtilities;
import org.openimaj.image.processing.face.detection.HaarCascadeDetector;
import org.openimaj.image.processing.face.detection.keypoints.FKEFaceDetector;
import org.openimaj.image.processing.face.detection.keypoints.KEDetectedFace;
import org.openimaj.image.processing.face.feature.FacePatchFeature;
import org.openimaj.image.processing.face.feature.FacePatchFeature.Extractor;
import org.openimaj.image.processing.face.feature.comparison.FaceFVComparator;
import org.openimaj.image.processing.face.similarity.FaceSimilarityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.codec.binary.Base64;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.iiocontrollers.IFileController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class IfaceCompareController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil(); // #NYE00001
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IfaceCompareController.class); // Nye- Change Class Name
	private DBController db$Ctrl = new DBController();
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	private IFileController i$fileCtrl = new IFileController();
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String sSOpr = i$ResM.getSrvcopr(isonMsg);
			String sSvr = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(sSvr, "ImpactoFaceCompareService")
					&& I$utils.$iStrFuzzyMatch(sSOpr, "Compare")) {
				return Compare$Face(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
		return null;
	}

	public JsonObject CompareFaceAPI(JsonObject isonMsg) {
		try {

		} catch (Exception e) {
			// TODO: handle exception
		}

		return isonMsg;
	}

	public JsonObject Compare$Face(JsonObject isonMsg) {
		try {
			// first, we convert two images
			// byte[] bytes1 =
			// Base64.decodeBase64(isonMsg.get(i$ResM.I_BDYTAG).getAsJsonObject().get("img1").getAsString());
			// byte[] bytes2 =
			// Base64.decodeBase64(isonMsg.get(i$ResM.I_BDYTAG).getAsJsonObject().get("img2").getAsString());

			String faceMatchType = i$ResM.getBodyElementS(isonMsg, "faceMatchType");
			faceMatchType = i$ResM.getBodyElementS(isonMsg, "faceMatchType");

			byte[] bytes1 = I$impactoUtil
					.base64Decode(isonMsg.get(i$ResM.I_BDYTAG).getAsJsonObject().get("img1").getAsString());
			byte[] bytes2 = I$impactoUtil
					.base64Decode(isonMsg.get(i$ResM.I_BDYTAG).getAsJsonObject().get("img2").getAsString());
			double FScore = 0;
			double bestScore = Double.MAX_VALUE;
			if (!I$impactoUtil.isObjectEmpty(bytes1) && !I$impactoUtil.isObjectEmpty(bytes2)) { // #BVB00187
				if (!I$utils.$iStrFuzzyMatch(faceMatchType, "E")) {
					FImage image1 = ImageUtilities.readF(new ByteArrayInputStream(bytes1));
					FImage image2 = ImageUtilities.readF(new ByteArrayInputStream(bytes2));
					final HaarCascadeDetector detector = HaarCascadeDetector.BuiltInCascade.frontalface_alt2.load();
					final FKEFaceDetector kedetector = new FKEFaceDetector(detector);
					final Extractor extractor = new FacePatchFeature.Extractor();
					final FaceFVComparator<FacePatchFeature, FloatFV> comparator = new FaceFVComparator<FacePatchFeature, FloatFV>(
							FloatFVComparison.EUCLIDEAN);
					final FaceSimilarityEngine<KEDetectedFace, FacePatchFeature, FImage> engine = new FaceSimilarityEngine<KEDetectedFace, FacePatchFeature, FImage>(
							kedetector, extractor, comparator);

					engine.setQuery(image1, "image1");
					engine.setTest(image2, "image2");
					engine.performTest();
					for (final Entry<String, Map<String, Double>> e : engine.getSimilarityDictionary().entrySet()) {
						for (final Entry<String, Double> matches : e.getValue().entrySet()) {
							if (matches.getValue() < bestScore) {
								bestScore = matches.getValue();
								bestScore = (double) Math.round(bestScore * 100d) / 100d;
							}
						}
					}
				} else {
					JsonObject filter = new JsonObject();
					JsonParser parser = new JsonParser();
					filter.addProperty("trnCd", "FACE_MATCH");
					JsonObject argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
					String face1 = i$ResM.getBodyElementS(isonMsg, "img1");
					String face2 = i$ResM.getBodyElementS(isonMsg, "img2");
					File sourceFile1 = i$fileCtrl.createFile(face1);
					File sourceFile2 = i$fileCtrl.createFile(face2);
					argJson.addProperty("unqCommID", I$impactoUtil.generateRandomKey());

					RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
							.addFormDataPart("selfie", "image.png",
									RequestBody.create(MediaType.parse("image/png"), sourceFile1))
							.addFormDataPart("id_card", "image.png",
									RequestBody.create(MediaType.parse("image/png"), sourceFile2))
							.build();

					argJson.add("reqBody", new JsonObject());

					JsonObject JResp = I$EWSLnchr.ILaunchReq(argJson, requestBody);
					if (I$utils.$iStrFuzzyMatch(JResp.get("resCode").getAsString(), "200")) {
						JResp = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
						String statusCode = i$ResM.getStrfromObjWithDefault(JResp, "status_code", "400");
						if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {
							bestScore = JResp.getAsJsonObject("data").get("confidence").getAsDouble();
						} else {
							bestScore = 0;
						}
						bestScore = 100d - bestScore;
					}else {
						bestScore = -1; 
					}
				}
				// #00000002 Begins
				if (bestScore == Double.MAX_VALUE || bestScore < 0) {
					JsonObject objBdy = new JsonObject();
					objBdy.addProperty("Match-Confidence", 0);
					objBdy.addProperty("Alert-Type", "No Match/Vague");
					objBdy.addProperty("img1", i$ResM.getBodyElementS(isonMsg, "img1"));
					objBdy.addProperty("img2", i$ResM.getBodyElementS(isonMsg, "img2"));
					isonMsg.add(i$ResM.I_BDYTAG, objBdy);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Face Compare Completed Sucessfully");
					return isonMsg;
				}
				;

				// #00000002 Ends
				FScore = 100.00d - bestScore;
				FScore = (double) Math.round(FScore * 100d) / 100d;
				logger.debug("Match is " + bestScore);
				JsonObject objBdy = new JsonObject();
				objBdy.addProperty("Match-Confidence", FScore);

				String sAlert = "";
				if (FScore >= 80.00)
					sAlert = "Perfect";
				else if (FScore >= 67.00 && FScore < 80.00)
					sAlert = "High";
				else if (FScore >= 37.00 && FScore < 67.00)
					sAlert = "Medium";
				else if (FScore >= 18.00 && FScore < 37.00)
					sAlert = "Low";
				else if (FScore >= 7.00 && FScore < 18.00)
					sAlert = "Very Low";
				else
					sAlert = "No Match/Vague";
				objBdy.addProperty("Alert-Type", sAlert);
				objBdy.addProperty("img1", i$ResM.getBodyElementS(isonMsg, "img1"));
				objBdy.addProperty("img2", i$ResM.getBodyElementS(isonMsg, "img2"));
				isonMsg.add(i$ResM.I_BDYTAG, objBdy);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Face Compare Completed Sucessfully");
				return isonMsg;
			}
			// #BVB00187 Starts
			else {
				JsonObject objBdy = new JsonObject();
				objBdy.addProperty("Match-Confidence", -777);
				objBdy.addProperty("Alert-Type", "Failed");
				isonMsg.add(i$ResM.I_BDYTAG, objBdy);
				objBdy.addProperty("img1", i$ResM.getBodyElementS(isonMsg, "img1"));
				objBdy.addProperty("img2", i$ResM.getBodyElementS(isonMsg, "img2"));
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Images cannot be Empty");
				return isonMsg;
			}
			// #BVB00187 Ends
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			JsonObject objBdy = new JsonObject();
			objBdy.addProperty("Match-Confidence", -999);
			objBdy.addProperty("Alert-Type", "Failed");
			isonMsg.add(i$ResM.I_BDYTAG, objBdy);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"iFaces Match Failed with Error.." + es.getMessage());
			return isonMsg;
		}
	}
}