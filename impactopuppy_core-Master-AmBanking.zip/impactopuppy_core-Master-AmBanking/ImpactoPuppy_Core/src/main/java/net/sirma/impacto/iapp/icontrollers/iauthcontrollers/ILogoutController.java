/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Jan 30, 2019 | #BVB00046   | Initial writing
      |0.3.6       | Vijay 		| Apr 17, 2019 | #BVB00118   | Clearing Record Locks during Logout, New Function for Logout with single UserId input
      |0.3.6	   | Manikanta  | May 24, 2023 | #MVT00118   | Added code For digi app logout
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.iauthcontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ILogoutController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(ILogoutController.class); // Nye- Change Class Name
																							// always
	// **********************************************************************//

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();

			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "IMPACTOAUTH") && I$utils.$iStrFuzzyMatch(SOpr, "LOGOUT")) {
				// return uploadFile2Dms(isonMsg);
				isonMsg = logUserLogout(isonMsg);

			} else if (I$utils.$iStrFuzzyMatch(Scr, "DGLOGOUT") && I$utils.$iStrFuzzyMatch(SOpr, "LOGOUT")) {//#MVT00118 changes
				isonMsg = digiLogout(isonMsg);

			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};
	//#MVT00118 Begins
	private JsonObject digiLogout(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			
			String sessionId = i$ResM.getGobalValStr("sessionId");
			JsonObject iConfig = i$ResM.getGobalValJObj("i-config");
			if (I$utils.$iStrFuzzyMatch(iConfig.get("SrcID").getAsString(), "TecuDigiAppIOS")
					|| I$utils.$iStrFuzzyMatch(iConfig.get("SrcID").getAsString(), "TecuDigiApp")) {
				try {
					JsonObject object = new JsonObject();
					filter.addProperty("sessionId", sessionId);
					filter.addProperty("userId", IResManipulator.iloggedUser.get());
					db$Ctrl.db$Remove("ICOR_S_SESSION_VALIDATOR", filter);

					filter = new JsonObject();
					filter.addProperty("sessionID", sessionId);
					filter.addProperty("imei", iConfig.get("imecd").getAsString());
					object.addProperty("sessionID", "");
					object.addProperty("logoutStatus", true);//#MVT00119 changes
					JsonObject res = db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", object, filter);
//					JsonObject res = db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", "{$unset:{'sessionID':''}}", filter);
					
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(res), i$ResM.I_SUCC)) {
						i$body.addProperty("status", "LOGGED OUT SUCCESSFULLY");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOGGED OUT SUCCESSFULLY");
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOGOUT FAILED");
					}
//					String strAggQuery = "";
//					JsonArray i$schedules = db$Ctrl.db$getRowAgg("ICOR_M_B2U_DIGI_USERS", strAggQuery, projection);
				} catch (Exception e) {
					logger.debug(e.getMessage());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOGOUT FAILED");
				}
			}
		} catch(Exception e) {
			logger.debug(e.getMessage());
		}
		return isonMsg;
	}
	//#MVT00118 ends
	private JsonObject logUserLogout(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject i$body = new JsonObject();
		try {

			String sessionId = i$ResM.getGobalValStr("sessionId");
			
			// #BVB00118 Starts 
			// Delete all the Acquires for this user Id :
			filter = new JsonObject();
			filter.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
			db$Ctrl.db$Remove("ICOR_M_ID_ACQ", filter);
			// #BVB00118 Ends
			// Clear the session
			filter.addProperty("sessionId", sessionId);
			db$Ctrl.db$Remove("ICOR_S_SESSION_VALIDATOR", filter);
			filter = new JsonObject();
			filter.addProperty("userId", IResManipulator.iloggedUser.get());
			JsonObject rm$ = db$Ctrl.db$Remove("ICOR_S_TOKEN_VALIDATOR", filter);
			/*
			 * // Update the status of the the current session to Inactive
			 * setter.addProperty("status", "I"); setter.add("endDate", i$ResM.adddate(new
			 * Date())); JsonObject up$ = db$Ctrl.db$UpdateRow("ICOR_S_USER_ACT_LOG",
			 * setter, filter);
			 */

			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(rm$), i$ResM.I_SUCC)) {
				i$body = setter.deepCopy();

				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOGGED OUT SUCCESSFULLY");

			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOGOUT FAILED");

			}

			return isonMsg;
		} catch (Exception e) {
			logger.debug("Failed while logging Wser Login with:" + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOGOUT FAILED");
			return isonMsg;
		}

	}
	// #BVB00118 Starts 
	public JsonObject logUserLogout(String userId) {
		JsonObject filter = new JsonObject();
 		JsonObject i$body = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		try {

			// Delete all the Acquires for this user Id :
			filter = new JsonObject();
			filter.addProperty("acquiredBy", userId);
			db$Ctrl.db$Remove("ICOR_M_ID_ACQ", filter);

			// Clear the session
			filter = new JsonObject(); 
			filter.addProperty("userId", userId);
			db$Ctrl.db$Remove("ICOR_S_SESSION_VALIDATOR", filter);
			filter = new JsonObject();
			filter.addProperty("userId", userId);
			JsonObject rm$ = db$Ctrl.db$Remove("ICOR_S_TOKEN_VALIDATOR", filter);
			/*
			 * // Update the status of the the current session to Inactive
			 * setter.addProperty("status", "I"); setter.add("endDate", i$ResM.adddate(new
			 * Date())); JsonObject up$ = db$Ctrl.db$UpdateRow("ICOR_S_USER_ACT_LOG",
			 * setter, filter);
			 */
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(rm$), i$ResM.I_SUCC)) {
 				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOGGED OUT SUCCESSFULLY");

			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOGOUT FAILED WITH:" + i$ResM.getMsgtext(rm$));
			}
			return isonMsg;
		} catch (Exception e) {
			logger.debug("Failed while logging Wser Login with:" + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "LOGOUT FAILED");
			return isonMsg;
		}
	}
	// #BVB00118 Ends
	public ILogoutController() {
		// Constructor
	}

}

// #00000001 Ends