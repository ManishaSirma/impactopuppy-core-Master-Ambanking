/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Feb 25, 2019 | #BVB00073   | Initial writing
      |0.3.6       | Vijay 		| Apr 17, 2019 | #BVB00117   | Improvement Code for Clearing User
      |0.3.14.283  | RK		 		| Jun 28, 2019 | #ERK00001   | Restricting Current User Session Clearing.
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB00073 Begins
package net.sirma.impacto.iapp.icontrollers.iauthcontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ClearUserController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(ClearUserController.class); // Nye- Change Class Name
																								// always
	private ILogoutController i$iLogOutC = new ILogoutController(); 
	// **********************************************************************//

 	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			// OASCLRUS
			if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = db$Ctrl.getLoggedInUsers(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
				ClearUserHandler(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};

	public JsonObject getLoggedInUsers(JsonObject isonMsg) {
		JsonArray loggedInList = new JsonArray();
		String filter = "";
		JsonObject projection = new JsonObject();

		try {
			filter = "{'userId':{$exists:true}}";
			projection.addProperty("userId", "1");
			projection.addProperty("createdAt", "1");
			projection.addProperty("lastActivityAt", "1");
			loggedInList = db$Ctrl.db$GetRows("ICOR_S_SESSION_VALIDATOR", filter, projection);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, loggedInList);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOGGED IN USERS FETCHED SUCESSFULLY");

		} catch (Exception e) {
			logger.debug("Failed in Fetching Logged In users with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "FAILED WHILE FETCHING LOGGED IN USERS");
		}

		return isonMsg;
	}

	public JsonObject ClearUserHandler(JsonObject isonMsg) {
		try {
			String mode = i$ResM.getBodyElementS(isonMsg, "mode");
			if (I$utils.$iStrFuzzyMatch(mode, "L")) {
				JsonArray userId = i$ResM.getBodyElementA(isonMsg, "userId");
				for (int i = 0; i < userId.size(); i++) {
					// #ERK00001 Begins
					if (I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(),userId.get(i).getAsString())) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CURRENT USER SESSION CANNOT BE CLEAR");
					} else {
						clearOneUser(userId.get(i).getAsString());
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "USER CLEARED SUCESSFULLY");
					}
					// #ERK00001 Ends
				}
				// JsonObject i$res = clearOneUser(userId);

				/*
				 * if (i$res.get("i-stat").getAsInt() > 0) { isonMsg =
				 * i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "USER CLEARED SUCESSFULLY"); }
				 * else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
				 * i$res.get("i-stat").getAsString()); }
				 */
			} else if (I$utils.$iStrFuzzyMatch(mode, "A")) {
				JsonArray loggedInUsers = i$ResM.getBodyA(db$Ctrl.getLoggedInUsers(isonMsg));
				for (int i = 0; i < loggedInUsers.size(); i++) {
					JsonObject i$runningObj = loggedInUsers.get(i).getAsJsonObject();
					clearOneUser(i$runningObj.get("userId").getAsString());
				}

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "USERS CLEARED SUCESSFULLY");
			}
		} catch (Exception e) {
			logger.debug("Failed during Clearing of Users with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER CLEARING FAILED");
		}

		return isonMsg;
	}

	public JsonObject clearOneUser(String userId) {
		// JsonObject filter = new JsonObject();
		JsonObject i$res = new JsonObject();

		try {
// #BVB00117 Starts 
			// Call Logout of the user : 
			
			// #ERK00001 Begins
			if (!I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(),userId)) {
				i$res = i$iLogOutC.logUserLogout(userId);
			}
			// #ERK00001 Ends
			
//			String userId = i$ResM.getBodyElementS(isonMsg, "userId");
//			Clear the session
//			filter.addProperty("userId", userId);
//
//			// Getting Session Details
//			JsonObject sessionDetails = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", filter);
//
//			db$Ctrl.db$Remove("ICOR_S_SESSION_VALIDATOR", filter);
//			JsonObject rm$ = db$Ctrl.db$Remove("ICOR_S_TOKEN_VALIDATOR", filter);
//			// Need to clear all Acquired tasks to this guy
//
//			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(rm$), i$ResM.I_SUCC)) {
//				i$res.addProperty("i-stat", 1);
//				i$res.addProperty("i-Msg", "ALL GOOD");
//
//			} else {
//				i$res.addProperty("i-stat", 0);
//				i$res.addProperty("i-Msg", i$ResM.getMsgtext(rm$));
//
//			}

			// #BVB00117 Ends
		} catch (Exception e) {
			// #BVB00117 Starts 
			i$res = i$ResM.iHandleResStat(i$res, i$ResM.I_ERR, "CLEAR USER FAILED with:" + e.getMessage());
			// i$res.addProperty("i-stat", 0);
			// i$res.addProperty("i-Msg", "FAILED WHILE CLEARING THE USER WITH: " + e.getMessage());
			// #BVB00117 Ends
		}
		return i$res;

	}

	public ClearUserController() {
		// Constructor
	}
}

// #BVB00073 Ends