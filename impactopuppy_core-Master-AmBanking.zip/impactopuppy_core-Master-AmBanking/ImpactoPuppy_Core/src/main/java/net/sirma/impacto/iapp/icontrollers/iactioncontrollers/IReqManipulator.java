/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Jan 7, 2019  | #BVB00032   | Initial writing
      |0.2.1       | Vijay 		| Jan 9, 2019  | #BVB00035   | Encryption Decryption based on Maintenance
      |0.2.1       | Vijay 		| Jan 16, 2019 | #BVB00036   | Encryption and Decryption with RSA
      |0.2.1       | Bhuvi      | Jan 15, 2019 | #BHU00001   | Generate Password for user 
      |0.2.1       | Vijay      | Feb 23, 2019 | #BVB00069   | User Self Edit and Authorization Validations
      |0.2.1       | Bhuvi      | Feb 24, 2019 | #BHUVI002   | Add fileds in user creations
      |0.2.1       | Bhuvi      | Feb 27,2019  | #BHUVI003   | Update status if user inactive any other user 
      |1.0 Beta    | MAQ        | Mar 08, 2019 | #MAQ00001   | Moved from helper to iactionController,  
      														   Added Validation for Changing Role/Function active field
      |0.3.1	   | MAQ        | Apr 02, 2019 | #MAQ00002   | Added Validation for modifying self Access
      |0.3.4.214   | MAQ        | Apr 10, 2019 | #MAQ00011   | Modifying self Access will be based on DB Maintenance
      |0.3.11.262  | Syed 		| May 28, 2019 | #MAQ00014   | Changing modifyAccess function according to framework
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB00032 Begins
package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ialgo.RSAAsymetricCrypt;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IReqManipulator {
	private Logger logger = LoggerFactory.getLogger(IReqManipulator.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private DBController db$Ctrl = new DBController();
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	RSAAsymetricCrypt i$RSAAsy = new RSAAsymetricCrypt();

	public JsonObject processMsgHandler(JsonObject argJson) {

		try {
			JsonObject isonMsg = argJson.getAsJsonObject("isonMsg");

			String ScrId = i$ResM.getScreenID(isonMsg);
			String SOpr = i$ResM.getOpr(isonMsg);

			String SOpr1 = i$ResM.getOpr1(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			String SOpr3 = i$ResM.getOpr3(isonMsg);

			JsonObject i$body = i$ResM.getBody(isonMsg);

			if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				// #MAQ00002 code starts
				try {
					// #MAQ00014 starts
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFUNAC") || I$utils.$iStrFuzzyMatch(ScrId, "OASQUEUE")) {
						argJson = modifyAccess(argJson);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(argJson.getAsJsonObject("isonMsg")),
								i$ResM.I_ERR)) {
							return argJson;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Modify Access Validation : " + e.getMessage());
					// #MAQ00014 ends
				}
				// #MAQ00002 code ends

				if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) {

					// #BVB00069 Starts
					if (I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(),
							i$body.get("userId").getAsString())) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Self Editing not allowed");
					}
					// #BVB00069 Ends
					// BHUVI002 Starts
					i$body.addProperty("cummulativeLogin", 0);
					i$body.addProperty("successiveLogin", 0);
					i$body.addProperty("lockedStatus", 0);
					i$body.add("LastPasswordChange", i$ResM.adddate(new Date()));
					i$body.add("lastLogin", i$ResM.adddate(new Date()));
					// BHUVI002 Ends

				}

				if (I$utils.$iStrFuzzyMatch(ScrId, "OIFHSMES")) {
					double i$pdMacroValue = 1;
					try {

						JsonArray i$mVal = i$body.get("mVal").getAsJsonArray();
						for (int i = 0; i < i$mVal.size(); i++) {
							try {
								JsonObject i$runningValue = i$mVal.get(i).getAsJsonObject();
								double featureValue = i$runningValue.get("featureValue").getAsDouble();
								i$pdMacroValue = i$pdMacroValue - (featureValue / 100);
							} catch (Exception e) {
								// Eat Up
							}
						}

						i$pdMacroValue = I$utils.$roundTwoDouble(i$pdMacroValue);
						i$body.addProperty("pdMacroValue", i$pdMacroValue);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Processed Sucessfully");

					} catch (Exception e) {
						e.printStackTrace();
						i$pdMacroValue = 0;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, e.getMessage());
					}

				}
				;

			} else if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
				// #BVB00069 Starts
				if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) {

					if (I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(),
							i$body.get("userId").getAsString())) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Self Editing not allowed");
					}

				}
				;
				// #BVB00069 Ends

				// #MAQ00001 starts
				try {
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSRRL")) {
						JsonObject filter = new JsonObject();
						if (i$body.has("roleId")) {

							String roleId = i$body.get("roleId").getAsString();
							filter.addProperty("roleId", roleId);
//							filter.addProperty("active", "A");
							filter.addProperty("isCurrVer", "Y");
							JsonObject roleInfo = db$Ctrl.db$GetRow("ICOR_M_USER_RL_PRF_LEDGER", filter);
							String dbActive = roleInfo.get("active").getAsString();
							String reqActive = i$body.get("active").getAsString();
							if (I$utils.$iStrFuzzyMatch(reqActive, "I") && I$utils.$iStrFuzzyMatch(dbActive, "A")) {

								String sMatchFilter = "{\"active\":\"A\",\"roles\":{\"$in\":[\"" + roleId + "\"]}}";
								int count = db$Ctrl.db$GetRowCnt("ICOR_M_USER_PRF", sMatchFilter);
								if (count >= 1) {

									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Role is actively in use");
									argJson.add("isonMsg", isonMsg);
									return argJson;
								}
							}
						}

					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Validation of Active to Inactive Role with: " + e.getMessage());
				}

				try {
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFUNAC")) {
						JsonObject filter = new JsonObject();
						if (i$body.has("roleId")) {

							String funcAccId = i$body.get("funcAccId").getAsString();
							filter.addProperty("funcAccId", funcAccId);
//							filter.addProperty("active", "A");
							filter.addProperty("isCurrVer", "Y");
							JsonObject funcInfo = db$Ctrl.db$GetRow("ICOR_M_FUNC_ACC_LEDGER", filter);
							String dbActive = funcInfo.get("active").getAsString();
							String reqActive = i$body.get("active").getAsString();
							if (I$utils.$iStrFuzzyMatch(reqActive, "I") && I$utils.$iStrFuzzyMatch(dbActive, "A")) {

								String roleId = i$body.get("roleId").getAsString();
								filter = new JsonObject();
								filter.addProperty("roleId", roleId);
								filter.addProperty("active", "A");
								int count = db$Ctrl.db$GetRowCnt("ICOR_M_USER_RL_PRF", filter);
								if (count >= 1) {

									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
											"FunctionAccessId is actively in use");
									argJson.add("isonMsg", isonMsg);
									return argJson;
								}

							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Validation of Active to Inactive Function with: " + e.getMessage());
				}
				// #MAQ00001 ends

				// #MAQ00002 code starts
				// #MAQ00014 starts
				try {
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFUNAC") || I$utils.$iStrFuzzyMatch(ScrId, "OASQUEUE")) {
						argJson = modifyAccess(argJson);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(argJson.getAsJsonObject("isonMsg")),
								i$ResM.I_ERR)) {
							return argJson;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Validation of Active to Inactive Function with: " + e.getMessage());
				}
				// #MAQ00014 ends
				// #MAQ00002 code ends

				// #BHUVI003 Starts
				if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) {
					try {
						if (i$body.get("active").getAsString().equalsIgnoreCase("I")
								&& i$body.get("lockedStatus").getAsInt() == 0) {
							i$body.addProperty("lockedStatus", 4);
							i$body.add("LastPasswordChange", i$ResM.adddate(new Date()));
							i$body.add("lastLogin", i$ResM.adddate(new Date()));
						} else {
							i$body.addProperty("cummulativeLogin", 0);
							i$body.addProperty("successiveLogin", 0);
							i$body.addProperty("lockedStatus", 0);
							i$body.add("LastPasswordChange", i$ResM.adddate(new Date()));
							i$body.add("lastLogin", i$ResM.adddate(new Date()));
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				// BHUVI003 End
				if (I$utils.$iStrFuzzyMatch(ScrId, "OIFHSMES")) {
					double i$pdMacroValue = 1;
					try {

						JsonArray i$mVal = i$body.get("mVal").getAsJsonArray();
						for (int i = 0; i < i$mVal.size(); i++) {
							try {
								JsonObject i$runningValue = i$mVal.get(i).getAsJsonObject();
								double featureValue = i$runningValue.get("featureValue").getAsDouble();
								i$pdMacroValue = i$pdMacroValue - (featureValue / 100);
							} catch (Exception e) {
								// Eat Up
							}
						}

						i$pdMacroValue = I$utils.$roundTwoDouble(i$pdMacroValue);
						i$body.addProperty("pdMacroValue", i$pdMacroValue);

					} catch (Exception e) {
						e.printStackTrace();
						i$pdMacroValue = 0;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, e.getMessage());
					}

				}
				;

			} else if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
				// #MAQ00002 code starts
				// #MAQ00014 starts
				try {
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFUNAC") || I$utils.$iStrFuzzyMatch(ScrId, "OASQUEUE")) {
						argJson = modifyAccess(argJson);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(argJson.getAsJsonObject("isonMsg")),
								i$ResM.I_ERR)) {
							return argJson;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Modify Access Validation : " + e.getMessage());
				}
				// #MAQ00014 ends
				// #MAQ00002 code ends
				// #BHU00001 begin
				if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) {

					// #BVB00069 Starts
					if (I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(),
							i$body.get("userId").getAsString())) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Self Editing not allowed");
					}
					// #BVB00069 Ends

					try {
						JsonObject i$recordDetails = argJson.get("i$recordDetails").getAsJsonObject();
						JsonObject imaster = i$recordDetails.get("i$master").getAsJsonObject();
						if (I$utils.$isNull(imaster)) {
							String StrPass = I$impactoUtil.getAlphaNumericId(7);
							String StrGetSalt = I$impactoUtil.getSalt(30);
							String StrEncrytPass = I$impactoUtil.generateSecurePassword(StrPass, StrGetSalt);
							i$body.addProperty("userPwd", StrEncrytPass);
							i$body.addProperty("salt", StrGetSalt);
							i$body.addProperty("ForcePasswordChange", "Y");
							i$body.add("LastPasswordChange", i$ResM.adddate(new Date()));
							i$body.add("lastLogin", i$ResM.adddate(new Date()));
							IDataValidator.J$TempStorage.get().addProperty("userPwd", StrPass);

						} else {
							i$body.add("LastPasswordChange", i$ResM.adddate(new Date()));
							i$body.add("lastLogin", i$ResM.adddate(new Date()));
						}

						// J$TempStorage.addProperty("userPwd", StrPass);

						// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "J$TempStorage",
						// J$TempStorage);
						// #BVB00036 ends

					} catch (Exception e) {
						e.printStackTrace();
						logger.debug("Failed in Encrypting the password with: " + e.getMessage());
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, e.getMessage());

					}
				} // #BHU00001 ends

			} else if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {
				// #MAQ00002 code starts
				// #MAQ00014 starts
				try {
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFUNAC") || I$utils.$iStrFuzzyMatch(ScrId, "OASQUEUE")) {
						argJson = modifyAccess(argJson);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(argJson.getAsJsonObject("isonMsg")),
								i$ResM.I_ERR)) {
							return argJson;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Modify Access Validation : " + e.getMessage());
				}
				// #MAQ00014 ends
				// #MAQ00002 code ends

			} else if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
				// #MAQ00002 code starts
				// #MAQ00014 starts
				try {
					if (I$utils.$iStrFuzzyMatch(ScrId, "OASFUNAC") || I$utils.$iStrFuzzyMatch(ScrId, "OASQUEUE")) {
						argJson = modifyAccess(argJson);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(argJson.getAsJsonObject("isonMsg")),
								i$ResM.I_ERR)) {
							return argJson;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.debug("Failed in Modify Access Validation : " + e.getMessage());
				}
				// #MAQ00014 ends
				// #MAQ00002 code ends

			} else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {

			}

			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Processed Sucessfully");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			argJson.add("isonMsg", isonMsg);

		} catch (Exception e) {
			e.printStackTrace();
			argJson = null;
		}

		return argJson;

	}

	// #BVB00035 Starts
	@SuppressWarnings("null")
	public JsonObject $decryptRequest(JsonObject argJson) {
		JsonArray i$AnnoteFlds = null;
		// JsonObject i$DecryptRes = new JsonObject();
		String i$decrypt = "";
		// Gson gson = new Gson();
		JsonArray deCurrVal = new JsonArray();
		JsonObject i$Annotate = argJson.get("i$Annotate").getAsJsonObject();
		JsonObject isonMsg = argJson.get("isonMsg").getAsJsonObject();
		JsonObject i$body = i$ResM.getBody(isonMsg);
		String key = argJson.get("privateKey").getAsString();

		// #BVB00036 Starts
		byte[] privateKeyB = I$impactoUtil.base64Decode(key);
		PrivateKey privateKey = null;
		try {
			privateKey = i$RSAAsy.getPrivate(privateKeyB, 1);
		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed in getting Private Key with: " + e.getMessage());
		}
		// #BVB00036 Ends
		String ScrId = i$ResM.getScreenID(isonMsg);
		String SOpr = i$ResM.getOpr(isonMsg);

		String SOpr1 = i$ResM.getOpr1(isonMsg);
		String SOpr2 = i$ResM.getOpr2(isonMsg);
		String SOpr3 = i$ResM.getOpr3(isonMsg);

		try {
			i$AnnoteFlds = i$Annotate.getAsJsonArray("FIELDS");
		} catch (Exception e) {
			i$AnnoteFlds = null;
		}
		;
		String iAnnotbyPass;
		try {
			iAnnotbyPass = i$Annotate.get("BYPASS").getAsString();
		} catch (Exception e) {
			iAnnotbyPass = "N";
		}
		;
		if (!I$utils.$iStrFuzzyMatch(iAnnotbyPass, "Y")) {

			// Populating Required List
			Collection<String> decryptReqFlds = new ArrayList<String>();
			// JsonArray decryptReqFlds = new JsonArray();

			decryptReqFlds = $getDecyptReqFields(i$AnnoteFlds);

			for (Iterator<String> decryptReqFld = decryptReqFlds.iterator(); decryptReqFld.hasNext();) {
				String CurrField = decryptReqFld.next();
				String CurrVal = "";
				JsonArray CurrValA = new JsonArray();
				JsonObject CurrValO = new JsonObject();

				for (int k = 0; k < i$AnnoteFlds.size(); k++) {
					JsonObject i$runningObj = i$AnnoteFlds.get(k).getAsJsonObject();
					if (I$utils.$iStrFuzzyMatch(i$runningObj.get("FIELDNAME").getAsString(), CurrField)) {
						// Validate Data Type

						if (I$utils.$iStrFuzzyMatch(i$runningObj.get("FIELDTYPE").getAsString(), "Array")) {

							CurrValA = i$body.getAsJsonArray(CurrField);

							try {
								main: {
									if (I$utils.$iStrFuzzyMatch(i$runningObj.get("FIELDDATATYPE").getAsString(),
											"OBJECT")) {

										CurrValO = i$body.getAsJsonObject(CurrField);
										JsonObject argJsonDup = new JsonObject();
										JsonObject isonMsgDup = new JsonObject();
										isonMsgDup = isonMsg.deepCopy();
										argJsonDup = argJson.deepCopy();
										isonMsgDup.add("i-body", CurrValO);
										argJsonDup.add("isonMsg", isonMsgDup);
										CurrValO = $objectDecrypt(argJsonDup);
										// i$body.add(CurrField, $decryptRequest(argJsonDup));

									} else {
										deCurrVal = new JsonArray();
										for (int j = 0; j < CurrValA.size(); j++) {
											i$decrypt = $stringDecrypt(i$runningObj, CurrField,
													CurrValA.get(j).getAsString(), privateKey); // #BVB00036 Starts
											deCurrVal.add(i$decrypt);
										}
										// CurrVal = gson.toJson(deCurrVal);
										i$body.add(CurrField, deCurrVal);

									}
								}
							} catch (Exception e) {
								// i$Msg = "INVALID VALUES FOR FIELD " + CurrField;

							}

						} else if (I$utils.$iStrFuzzyMatch(i$runningObj.get("FIELDTYPE").getAsString(), "OBJECT")) {
							CurrValO = i$body.getAsJsonObject(CurrField);
							JsonObject argJsonDup = new JsonObject();
							JsonObject isonMsgDup = new JsonObject();
							isonMsgDup = isonMsg.deepCopy();
							argJsonDup = argJson.deepCopy();
							isonMsgDup.add("i-body", CurrValO);
							argJsonDup.add("isonMsg", isonMsgDup);
							CurrValO = $objectDecrypt(argJsonDup);
							// i$body.add(CurrField, $decryptRequest(argJsonDup));

							// CurrVal = $objectDecrypt(jfld, CurrField, CurrVal, key);
						} else {

							CurrVal = i$body.get(CurrField).getAsString();
							CurrVal = $stringDecrypt(i$runningObj, CurrField, CurrVal, privateKey);// #BVB00036 Starts
							i$body.addProperty(CurrField, CurrVal);
						}

					}

				}

			}
		}

		isonMsg.add("i-body", i$body);
		argJson.add("isonMsg", isonMsg);

		return argJson;

	};

	// #MAQ00014 starts
	public JsonObject modifyAccess(JsonObject argJson) {

		JsonObject isonMsg = argJson.getAsJsonObject("isonMsg");

		String ScrId = i$ResM.getScreenID(isonMsg);
		String SOpr = i$ResM.getOpr(isonMsg);

		String SOpr1 = i$ResM.getOpr1(isonMsg);
		String SOpr2 = i$ResM.getOpr2(isonMsg);
		String SOpr3 = i$ResM.getOpr3(isonMsg);

		JsonObject i$body = i$ResM.getBody(isonMsg);

		String selfModifyAccess = db$Ctrl.getSelfModifyAccess(ScrId);

		// #MAQ00002 code starts
		try {

			if (I$utils.$iStrFuzzyMatch(selfModifyAccess, "N")) { // #MAQ00011

				if (I$utils.$iStrFuzzyMatch(i$body.get("roleOrUser").getAsString(), "R")) {
					String userId = IResManipulator.iloggedUser.get();
					JsonObject filter = new JsonObject();
					filter.addProperty("userId", userId);
					JsonObject projection = new JsonObject();
					projection.addProperty("roles", 1);
					projection.addProperty("_id", 0);
					JsonObject res = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter, projection);
					if (res.has("roles")) {
						JsonArray currUserRoles = res.get("roles").getAsJsonArray();
						String roleId = i$body.get("roleId").getAsString();

						if (I$utils.$iExistsInArrayJ(currUserRoles, roleId)) {

							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "User cannot modify his own Access");
							argJson.add("isonMsg", isonMsg);

						}
					}
				}
				if (I$utils.$iStrFuzzyMatch(i$body.get("roleOrUser").getAsString(), "U")) {
					String userId = IResManipulator.iloggedUser.get();
					String reqUserId = i$body.get("userId").getAsString();
					if (I$utils.$iStrFuzzyMatch(reqUserId, userId)) {

						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "User cannot modify his own Access");
						argJson.add("isonMsg", isonMsg);

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Modify Access Validation : " + e.getMessage());
		}
		// #MAQ00002 code ends
		return argJson;
	}
	// #MAQ00014 ends

	public String $decryptRequest_custom(JsonObject i$Annotate, JsonObject i$body, String ScrID, String SrvOpr,
			String key) {
		JsonArray i$AnnoteFlds = null;
		// JsonObject i$DecryptRes = new JsonObject();

		// String i$decrypt = "";
		// Gson gson = new Gson();
		// JsonArray deCurrVal = new JsonArray();

		try {
			i$AnnoteFlds = i$Annotate.getAsJsonArray("FIELDS");
		} catch (Exception e) {
			i$AnnoteFlds = null;
		}
		;

		// Populating Required List
		Collection<String> decryptReqFlds = new ArrayList<String>();

		decryptReqFlds = $getDecyptReqFields(i$AnnoteFlds);

		return null;

	};

	// public JsonObject $objectDecrypt(JsonObject jfld, JsonObject i$body, String
	// CurrField, JsonObject CurrVal, String key) {
	public JsonObject $objectDecrypt(JsonObject argJson) {

		JsonObject i$body = new JsonObject();
		JsonObject isonMsg = new JsonObject();

		try {
			// JsonObject currVal = i$ResM.str2Json(CurrVal);
			isonMsg = argJson.getAsJsonObject("isonMsg");
			i$body = i$ResM.getBody(isonMsg);

			// i$res = $decryptRequest_custom(jfld, i$body, currVal, "", "", key);
			argJson = $decryptRequest(argJson);
			isonMsg = argJson.getAsJsonObject("isonMsg");
			i$body = i$ResM.getBody(isonMsg);

		} catch (Exception e) {
			e.printStackTrace();
			i$body = null;
		}
		return i$body;
	}

	public String $stringDecrypt(JsonObject jfld, String CurrField, String CurrVal, String key) {
		// JsonObject i$res = new JsonObject();
		String decryptVal = "";
		try {
			decryptVal = I$impactoUtil.decrypt(CurrVal, key);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed with: " + e.getMessage());
			decryptVal = null;
		}
		return decryptVal;

	}

	public String $stringDecrypt(JsonObject jfld, String CurrField, String CurrVal, PrivateKey key) {
		// JsonObject i$res = new JsonObject();
		String decryptVal = "";
		try {
			// decryptVal = I$impactoUtil.decrypt(CurrVal, key); // #BVB00036 Commented

			decryptVal = i$RSAAsy.decryptText(CurrVal, key);// #BVB00036

		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed with: " + e.getMessage());
			decryptVal = null;
		}
		return decryptVal;

	}

	public Collection<String> $getDecyptReqFields(JsonArray i$AnnoteFlds) {
		Collection<String> decryptReqFlds = new ArrayList<String>();
		for (int i = 0; i < i$AnnoteFlds.size(); i++) {
			JsonObject jfld = i$AnnoteFlds.get(i).getAsJsonObject();
			// Adding Mandatory List
			try {
				if ((I$utils.$iStrFuzzyMatch(jfld.get("DECRYPTREQ").getAsString(), "1"))
						&& (decryptReqFlds == null || !decryptReqFlds.contains(jfld.get("FIELDNAME").getAsString()))) {
					decryptReqFlds.add(jfld.get("FIELDNAME").getAsString());
				}
				;

			} catch (Exception e) {
				// Eat Up
			}

			try {

				if (jfld.get("FIELDS").getAsJsonArray() != null) {
					JsonArray i$AnnoteFldsRun = jfld.get("FIELDS").getAsJsonArray();
					decryptReqFlds.addAll($getDecyptReqFields(i$AnnoteFldsRun));
				}
			} catch (Exception e) {
				// Eat Up
			}

		}
		;
		return decryptReqFlds;

	}

	// #BVB00035 Ends
	public JsonObject processMsg(JsonObject argJson) {
		try {
			IReqManipulator i$reqManipulator = new IReqManipulator();
			argJson = $decryptRequest(argJson);
			argJson = i$reqManipulator.processMsgHandler(argJson);
			return argJson;
		} catch (Exception e) {
			e.printStackTrace();
			argJson = null;

		}
		return argJson;
	}

	public IReqManipulator() {
		// Constructor
	}

}
// #BVB00032 Ends