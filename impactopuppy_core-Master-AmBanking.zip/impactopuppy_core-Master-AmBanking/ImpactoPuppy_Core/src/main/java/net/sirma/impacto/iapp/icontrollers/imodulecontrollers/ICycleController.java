/*      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Oct 21, 2018 | #BVB00009   | Initial writing
      |0.1 Beta    | Vijay 		| Nov 29, 2018 | #BVB00016   | Feature I-Projection added 
      |0.1 Beta    | Vijay 		| Dec 1, 2018  | #BVB00019   | Rights should not be checked for LOV Screen Id's 
      |0.1 Beta    | Vijay 		| Dec 9, 2018  | #BVB00023   | Added code from Bucketization till ECL 
      |0.1 Beta    | Vijay 		| Dec 11, 2018 | #BVB00027   | Moving QUERYMASTER to operation2 rather than in operation
      |0.1 Beta    | Vijay 		| Dec 16, 2018 | #BVB00030   | Issue with Sandbox query for ICYCLE Query operation. 
      |0.1 Beta    | Syed, RK	| Dec 18, 2018 | #MAQ00001   | Adding Desc field operation.
      |0.1 Beta    | Syed, RK	| Dec 18, 2018 | #MAQ00002   | Interchange stepper PD and LGD 
      |0.2.1	   | Syed		| Jan 09, 2018 | #MAQ00003   | Added changes for ECL Calculation 
      |0.2.1	   | Syed		| Jan 09, 2018 | #MAQ00004   | Changed 'EXPOSURERID' to 'EXPOSURE_ID'
      |0.2.1       | Syed       | Jan 17,2019  | #MAQ00005   | Added Corp Changes to ICycle(Vijay)    
	  |0.2.1       | Syed       | Jan 21,2019  | #MAQ00006   | Changed Icycle Query db call to db$getRowAgg()
	  |0.2.1       | Syed       | Jan 24,2019  | #MAQ00007   | Added Icycle chart code from IBridge 	  
      |0.3.14      | VIjay  	| Jun 10, 2019 | #BVB00164   | NoSqlInjection Correction Changes
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ICycleWorker; // #MAQ00003
//import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class ICycleController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private Logger logger = LoggerFactory.getLogger(ICycleController.class); // Nye- Change Class Name
																							// always
	private IDataValidator I$DataValidator = new IDataValidator();
	private ICycleWorker ICycleWorker = new ICycleWorker();  // #MAQ00003
//	private IgenericWorker igenericWorker = new IgenericWorker(); // BVB Danger
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		JsonObject i$Annotate = null;
		String Coll_Name, L_Coll_Name;
		Gson gson = new Gson();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);

		// #BVB00005 Starts
		JsonObject i$recordDetails = new JsonObject();
		JsonObject i$validateRes = new JsonObject();
		JsonObject i$ledgerCurVer = new JsonObject();
		// #BVB00005 Ends

		try {

			// #BVB00019 Starts
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;

			// if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr)) {
			if (hasRights) {

				// #BVB00019 Ends
				if (i$Match == null) {
					JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
					i$Match = new JsonObject();
					try {
						if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
							for (int i = 0; i < i$MatchMap.size(); i++) {

								i$Match.addProperty(i$MatchMap.get(i).getAsString(),
										i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
						} else {
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
						}
					} catch (Exception e) {
						e.printStackTrace();
						i$Match = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
					}
					;

				}
				;

				// #BVB00005 Ends
				// #BVB00016 Starts
				if (i$ProjectionArray != null) {
					for (int i = 0; i < i$ProjectionArray.size(); i++) {
						i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
					}
				} else {
					i$Projection = new JsonObject();
				}
				// #BVB00016 Ends

				Integer i$MaxRow = -1;

				try {
					i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
				} catch (Exception e) {
					try {
						i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
					} catch (Exception ex) {
						i$MaxRow = -1;
					}
					;
				}
				;

				try {
					Coll_Name = isonMapJson.get("COLLNAME").getAsString();
				} catch (Exception e) {
					Coll_Name = null;
				}
				;

				if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
						|| (I$utils.$iStrBlank(gson.toJson(i$Match)))
						|| I$utils.$iStrFuzzyMatch(gson.toJson(i$Match), "{}")) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
					return isonMsg;
				}
				;

				try {
					L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
				} catch (Exception e) {
					L_Coll_Name = null;
				}
				;

				if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
					return isonMsg;
				}
				;

				try {
					String ScrID = i$ResM.getScreenID(isonMsg);
					String SOpr1 = i$ResM.getOpr1(isonMsg);
					String SOpr2 = i$ResM.getOpr2(isonMsg);
					String SOpr3 = i$ResM.getOpr3(isonMsg);
					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrID + "_" + SOpr + "\"}");
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;
						i$body = isonMsg.getAsJsonObject("i-body");
					} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						// Forwarding Request to DB Handler for SUMMARY
						logger.debug("Forwarding Request to DB Controller for Summary");
						isonMsg.add("i-body", null);
						i$body = null;
						if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
							if (i$Match != null)
								return (db$Ctrl.db$GetSummRows(L_Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection)); // #BVB00016
																														// Added
																														// Projection
							else
								return (db$Ctrl.db$GetSummRows(L_Coll_Name, isonMsg, i$MaxRow, "{\"isCurrVer\"=\"Y\"}",
										i$Projection)); // #BVB00016 Added Projection
						} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
							if (i$Match != null)
								return (db$Ctrl.db$GetSummRows(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection)); // #BVB00016
																														// Added
																														// Projection
							else
								return (db$Ctrl.db$GetSummRows(Coll_Name, isonMsg, i$MaxRow, "{}", i$Projection)); // #BVB00016
																													// Added
																													// Projection
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
							return isonMsg;
						}
					}

					/*
					 * else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ")) {
					 * 
					 * logger.debug("Forwarding Request to DB Controller for Query Accquire"); try {
					 * JsonObject u$pdate = null; i$ledgerCurVer.addProperty("errorMsg",
					 * "Record Sucessfully Retrieved"); db$Ctrl.db$AcqRow(L_Coll_Name, i$Match,
					 * isonMsg); isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg,
					 * i$ResM.I_BDYTAG, i$ledgerCurVer); isonMsg = i$ResM.iHandleResStat(isonMsg,
					 * i$ResM.I_SUCC,"Record Sucessfully Retrieved"); return isonMsg; } catch
					 * (Exception e) { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					 * "OPERATION FAILED"); return isonMsg; }
					 * 
					 * }
					 */ else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
						return isonMsg;
					}
					;
					I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
					if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
						// BVB Danger Starts

						// #BVB00005 Starts
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$body", i$body);
						// Getting the validation data from DB
						// Getting data from Master
						JsonObject i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						JsonObject i$master = db$Ctrl.db$GetRow(Coll_Name, i$runningQuery.toString());
						if (i$master != null) {
							logger.debug("Master Records: " + i$master);
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									i$master);
						} else {
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									"{}");
						}
						// Getting all records of Ledger Except for Deleted Records
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						String ndD = "{\"$ne\":\"D\"}";
						JsonParser parser = new JsonParser();
						i$runningQuery.add("recordStat", parser.parse(ndD).getAsJsonObject());
						JsonArray i$Ledger = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("Ledger Records: " + i$Ledger);
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$Ledger",
								i$Ledger);

						// Getting records with isCurrVer:
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("isCurrVer", "Y");
						JsonArray i$ledgerCurrVer = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerCurrVer: " + i$ledgerCurrVer + " Count: " + i$ledgerCurrVer.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerCurrVer",
								i$ledgerCurrVer);

						// Getting records of Un-Auth
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("authStat", "U");
						JsonArray i$ledgerUnAuth = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerUnAuth: " + i$ledgerUnAuth + " Count: " + i$ledgerUnAuth.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerUnAuth",
								i$ledgerUnAuth);

						i$validateRes = ICycleWorker.validateRequest(SOpr, SOpr1, SOpr2, i$recordDetails); // #BVB00021  // #MAQ00003
						if (i$validateRes.get("i-stat").getAsInt() > 0) {
							if (i$ledgerCurrVer.size() > 0)
								i$ledgerCurVer = i$ledgerCurrVer.get(0).getAsJsonObject();
							// #BVB00005 Ends
							// Forwarding Request to DB Handler for Insert

							// BVB Danger Ends

							JsonObject icorMCycle = new JsonObject();
							// icorMCycle = db$Ctrl.db$GetRow(Coll_Name, gson.toJson(i$Match)); // Danger 
							icorMCycle = db$Ctrl.db$GetRow(L_Coll_Name, gson.toJson(i$Match)); // Danger
							// #BVB00027 Starts
							// MAQ00005 start
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYMASTER")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
								if(I$utils.$iStrFuzzyMatch(SOpr2, "QUERYMASTER")&&(i$master != null)) {
								// #BVB00027 Ends
									try {											
										i$master.addProperty("errorMsg", "Record Sucessfully Retrieved");
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												 i$master);
												//icorMCycle);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Record Sucessfully Retrieved");
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}

								} else {
									try {
										// JsonObject u$pdate, m$x, up$ = null;
										icorMCycle.addProperty("errorMsg", "Record Sucessfully Retrieved");
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												// i$master);
												icorMCycle); 
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Record Sucessfully Retrieved");
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
									//MAQ00005 end
							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "iCycleMapping")) {
								// Save data to master
								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
									// Save the data to Master

									JsonObject in$ = new JsonObject();
									try {
										i$body.addProperty("isCurrVer", "Y");
										i$body.addProperty("authStat", "U");
										i$body.addProperty("recordStat", "O");
										i$body.addProperty("operation", SOpr.toUpperCase());
										i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
										i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
										i$body.addProperty("currentStage", SOpr1);
										i$body.addProperty("currentStageStatus", "Completed");
										i$body.addProperty("nextStage", "PortfolioClassification");
										i$body.addProperty("nextStageStatus", "WIP");
										// i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
										i$body.addProperty("authorizer", "");
										i$body.addProperty("errorMsg", "ICYCLE CREATED SUCESSFULLY");
										i$body.add("authorizedOnSrvDate", null);
										in$ = db$Ctrl.db$InsertRow(L_Coll_Name, i$body); // Danger

										// Moving the code to Thread
										// #MAQ00005 start
										JsonObject filter = new JsonObject();
										int i$exposuresCount = 0;
										try {
											i$exposuresCount = db$Ctrl.db$GetCountI(L_Coll_Name, gson.toJson(filter));
										} catch (Exception e) {
											i$exposuresCount = 0;
										}

										// double i$noOfIter = Math.ceil(i$exposuresCount / 1000);
										double i$noOfIter = Math.ceil(i$exposuresCount / i$exposuresCount);

										// Feeding number of threads to Master Table
										filter = new JsonObject();
										filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
										JsonObject setter = new JsonObject();
										setter.addProperty("noOfThreads", i$noOfIter);
										setter.addProperty("noOfExecutedThreads", 0);
										
										for (int k = 0; k < i$noOfIter; k++) {
										// #MAQ00005 end
	
											// Going to Create Args for Worker Thread
											
											
											// First create the object and call threading
	
											// Going to Create Args for Worker Thread
											JsonObject jWrkArgs = new JsonObject();
											jWrkArgs.add("isonMsg", isonMsg);
											jWrkArgs.addProperty("i$ThreadNo", 0);
											jWrkArgs.addProperty("L_Coll_Name", L_Coll_Name); // Danger
	
											logger.debug(
													"************************************************************************************");
											logger.debug("Starting Thread " + Integer.toString(0));
											logger.debug("------------");
											logger.debug("Params ");
											logger.debug("------------");
	
											logger.debug("2.ITHRIDNO--> " + Integer.toString(0) + " Of " + 0);
	
											logger.debug("------------");
											logger.debug(
													"************************************************************************************");
											// Forwarding request to threads
											IThreadController IThread$worker = new IThreadController(jWrkArgs);
											Thread t = new Thread(IThread$worker);
											// threads Started
											t.start();
										}
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$body);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Portfolio Classification Initiated");
										return isonMsg;
									} catch (Exception e) {
										e.printStackTrace();
										JsonObject filter = new JsonObject();
										filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
										JsonObject setter = new JsonObject();
										setter.addProperty("nextStageStatus", "Failed");
										setter.addProperty("currentStageStatus", "Failed");

										JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}

									// Call the Rule Controller to invoke the rules. ICycle ID needs to be sent
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {

									// Get Exposure Run, Hist, Cashflow run, Hist, Collateral Run, Casa Run Ids from
									// Job logger
									String mode = i$ResM.getBodyElementS(isonMsg, "mode");
									String runIdField = ""; // #BVB00030
									String descField = "";	// #MAQ00001 

									if (I$utils.$iStrFuzzyMatch(mode, "PROD")) {
										// Get data from job logger
										Coll_Name = "IBRIDGE_S_JOB_LOGGER"; 
										runIdField = "RUNID"; // #BVB00030
										descField = "DESC";	// #MAQ00001		 
									} else {
										// Get data from Sandbox collections
										Coll_Name = "IBRIDGE_S_SANDBOX_LOGGER";
										runIdField = "SANDBOXRUNID"; 	// #BVB00030
										descField = "SANDBOXDESC";	// #MAQ00001
									}
									;

									JsonObject flter = new JsonObject();

									String exposuretype = i$ResM.getBodyElementS(isonMsg, "exposuretype");

									flter.addProperty("EXPOSURE_TYPE", exposuretype);
									flter.addProperty("STATUS", "CONFIRMED");

									JsonObject projection = new JsonObject();
									// projection.addProperty("RUNID", 1);
									projection.addProperty(runIdField, 1); // #BVB00030
									projection.addProperty(descField, 1); // #MAQ00001
									projection.addProperty("SRVCNAME", 1);
									projection.addProperty("_id", 0);

									JsonArray i$jobLogger = db$Ctrl.db$GetRows(Coll_Name, gson.toJson(flter),
											gson.toJson(projection));
									JsonObject filter = new JsonObject();
									// #MAQ00001 begins
									JsonArray idDesc = new JsonArray();
									idDesc.add(runIdField);
									idDesc.add(descField);
									// #MAQ00001 ends
									if (i$jobLogger != null) {
										filter.addProperty("SRVCNAME", "LENDING$EXPOSURE");
										i$body.add("exposureRunID", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$jobLogger, filter), idDesc)); 	// #MAQ00001

										filter.addProperty("SRVCNAME", "LENDING$EXPOSURE$LIQ");
										i$body.add("exposureHistRunID", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$jobLogger, filter), idDesc)); 	// #MAQ00001

										filter.addProperty("SRVCNAME", "LENDING$SCHEDULE");
										i$body.add("exposureCashflowRunID", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$jobLogger, filter), idDesc));	// #MAQ00001

										filter.addProperty("SRVCNAME", "LENDING$SCHEDULE$HIST");
										i$body.add("exposureCashflowHistRunID", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$jobLogger, filter), idDesc));	// #MAQ00001

										filter.addProperty("SRVCNAME", "COLLATERAL$ENTITY");
										i$body.add("collateralRunId", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$jobLogger, filter), idDesc));	// #MAQ00001
									}
									flter.addProperty("EXPOSURE_TYPE", "COLLATERAL");
									flter.addProperty("STATUS", "CONFIRMED");

									JsonObject collprojection = new JsonObject();
									collprojection.addProperty(runIdField, 1);
									collprojection.addProperty(descField, 1); 	// #MAQ00001
									collprojection.addProperty("SRVCNAME", 1);
									collprojection.addProperty("_id", 0);

									JsonArray icoll$jobLogger = db$Ctrl.db$GetRows(Coll_Name, gson.toJson(flter),
											gson.toJson(projection));
									// pulling COlleteral Entiry
									if (icoll$jobLogger != null) {
										filter.addProperty("SRVCNAME", "COLLATERAL$ENTITY");
										i$body.add("collateralRunId", impactoUtil.createArrayS(
												impactoUtil.filterArrayO(icoll$jobLogger, filter), idDesc)); 	// #MAQ00001
									}
									/*
									 * filter.addProperty("SRVCNAME", "LENDING$SCHEDULE");
									 * i$body.add("LENDING$SCHEDULE",impactoUtil.filterArrayO(i$jobLogger, filter));
									 */

									// Add code for Macro Economical Features
									filter = new JsonObject();
									filter.addProperty("active", "A");

									projection = new JsonObject();
									projection.addProperty("mapId", 1);
									projection.addProperty("mDesc", 1);

									projection.addProperty("mapDesc", 1);
									projection.addProperty("_id", 0);
									// #MAQ00001 begins
									JsonArray idDescMap = new JsonArray();
									idDescMap.add("mapId");
									idDescMap.add("mDesc");
									// #MAQ00001 ends

									JsonArray i$macroEco = db$Ctrl.db$GetRows("ICOR_M_IFRS_MACROECO",
											gson.toJson(filter), gson.toJson(projection));
									if (i$macroEco != null)
										i$body.add("macroMapId", impactoUtil.createArrayS(i$macroEco, idDescMap)); 	// #MAQ00001

									// Add code for PD Manual

									// #MAQ00001 begins
									JsonArray idDescPD = new JsonArray();
									idDescPD.add("mapId");
									idDescPD.add("mapDesc");
									projection.addProperty("mapDesc", 1);
									// #MAQ00001 ends
									
									JsonArray i$pdInput = db$Ctrl.db$GetRows("ICOR_M_IFRS_PDINPUT", gson.toJson(filter),
											gson.toJson(projection));
									if (i$pdInput != null)
										i$body.add("pdMapId", impactoUtil.createArrayS(i$pdInput, idDescPD)); 	// #MAQ00001

									// Getting All records of Rules

									projection = new JsonObject();
									projection.addProperty("ruleId", 1);
									projection.addProperty("ruleClass", 1);
									projection.addProperty("ruleDesc", 1); 	// #MAQ00001
									projection.addProperty("_id", 0);

									// #MAQ00001 begins
									JsonArray idDescRule = new JsonArray();
									idDescRule.add("ruleId");
									idDescRule.add("ruleDesc");
									// #MAQ00001 ends

									JsonArray i$rules = db$Ctrl.db$GetRows("ICOR_M_RULES", "{}",
											gson.toJson(projection)); // Creating
																		// a
																		// Filter

									filter = new JsonObject();

									// Add code for Portifolio Classification
									if (i$rules != null) {
										filter.addProperty("ruleClass", "Portfolio Classification");
										i$body.add("portclassrule", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$rules, filter), idDescRule));	// #MAQ00001

										// Add code for Bucketization

										filter.addProperty("ruleClass", "Bucketization");
										i$body.add("bucketrule", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$rules, filter), idDescRule));	// #MAQ00001

										// Add code for PD Rules

										filter.addProperty("ruleClass", "Probability Of Default");
										i$body.add("pdRuleId", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$rules, filter), idDescRule));	// #MAQ00001

										// Re-Bucketization Rules
										filter.addProperty("ruleClass", "Re-Bucketization Management Rule");
										i$body.add("rebucketrule", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$rules, filter), idDescRule));	// #MAQ00001

										// PD Management Rule
										filter.addProperty("ruleClass", "Probability of Default Management Rule");
										i$body.add("pdmangrule", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$rules, filter), idDescRule));	// #MAQ00001
										// Macro Economic Features Rules
										filter.addProperty("ruleClass", "Macro Economical Feature Rule");
										i$body.add("macroRuleId", impactoUtil
												.createArrayS(impactoUtil.filterArrayO(i$rules, filter), idDescRule));

									}

									i$body.addProperty("mode", mode);
									i$body.addProperty("exposuretype", i$ResM.getBodyElementS(isonMsg, "exposuretype"));
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$body);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Record Sucessfully Retrieved");
								}
								;

							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "PORTFOLIOCLASSIFICATION")) {
								// Save the data that is sent by the Front end First.

								// Final Save needs to be done which will initiate Bucketization
								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
									JsonObject filter = new JsonObject();

									filter = new JsonObject();
									filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									JsonObject setter = new JsonObject();
									setter.addProperty("currentStage", SOpr1);
									setter.addProperty("currentStageStatus", "Completed");
									setter.addProperty("nextStage", "BUCKETIZATION");
									setter.addProperty("nextStageStatus", "WIP");

									JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

									String collectionName = icorMCycle.get("collectionName").getAsString();

									// Moving the code to Thread
									// #MAQ00005 start
									filter = new JsonObject();
									int i$exposuresCount = 0;
									try {
										i$exposuresCount = db$Ctrl.db$GetCountI(collectionName, gson.toJson(filter));
									} catch (Exception e) {
										i$exposuresCount = 0;
									}

									// double i$noOfIter = Math.ceil(i$exposuresCount / 1000);
									double i$noOfIter = Math.ceil(i$exposuresCount / i$exposuresCount);

									// Feeding number of threads to Master Table
									filter = new JsonObject();
									filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									setter = new JsonObject();
									setter.addProperty("noOfThreads", i$noOfIter);
									setter.addProperty("noOfExecutedThreads", 0);

									up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger

									for (int k = 0; k < i$noOfIter; k++) {
									// #MAQ00005 end

									// Going to Create Args for Worker Thread
										JsonObject jWrkArgs = new JsonObject();
										jWrkArgs.add("isonMsg", isonMsg);
										jWrkArgs.addProperty("collectionName", collectionName);
										jWrkArgs.addProperty("i$limit", 0);										
										jWrkArgs.addProperty("i$ThreadNo", 0);
										jWrkArgs.addProperty("L_Coll_Name", L_Coll_Name); // Danger 
										jWrkArgs.add("icorMCycle", icorMCycle);
	
										logger.debug(
												"************************************************************************************");
										logger.debug("Starting Thread " + Integer.toString(0));
										logger.debug("------------");
										logger.debug("Params ");
										logger.debug("------------");
	
										logger.debug("2.ITHRIDNO--> " + Integer.toString(0) + " Of " + 0);
	
										logger.debug("------------");
										logger.debug(
												"************************************************************************************");
										// Forwarding request to threads
										IThreadController IThread$worker = new IThreadController(jWrkArgs);
										Thread t = new Thread(IThread$worker);
										// threads Started
										t.start();
									}

									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$body);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "BUCKETIZATION INITIATED");

									return isonMsg;
								}

								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonObject projection = new JsonObject();

									// EXPOSURE_ID, EXPOSURE_PRODUCT, EXPOSURE_AMT_AT_INCEPTION, "Amount
									// Disbursed", EXPOSURE_AMT_AT_POINT,"Value Date",
									// MATURITY_DATE, CURRENT_OVERDUE_DAYS , "RULE APPLIED"
									
									// #MAQ00005 start
									projection.addProperty("EXPOSURE_ID", 1); 
									projection.addProperty("BORROWER_ID", 1);
									projection.addProperty("BORROWER_TYPE", 1);
									// #MAQ00005 end
									projection.addProperty("EXPOSURE_PRODUCT", 1);
									projection.addProperty("EXPOSURE_AMT_AT_INCEPTION", 1);
									projection.addProperty("EXPOSURE_AMT_AT_POINT", 1);
									projection.addProperty("INCEPTION_DATE", 1);
									projection.addProperty("MATURITY_DATE", 1);
									projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
									// #MAQ00006 Start
									projection.addProperty("EXPOSURE_PORTFOLIO", "$EXPOSURE_PORTFOLIO");
									// #MAQ00005 start
									projection.addProperty("EXPOSURE_PORTFOLIO_USER", "$EXPOSURE_PORTFOLIO_USER");
									projection.addProperty("EXPOSURE_PORTFOLIO_MANAGEMENT", "$EXPOSURE_PORTFOLIO_MANAGEMENT");
									// #MAQ00005 end
									JsonObject db$Result = db$Ctrl.db$getRowAgg(cycleCollectionName,projection, intPgNo, intRecs);									
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$Result.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$Result.getAsJsonObject("i-stat"));
									return isonMsg; 
									// #MAQ00006 End
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonArray i$records = new JsonArray();
									i$records = i$body.getAsJsonArray("editedData");

									try {
										for (int i = 0; i < i$records.size(); i++) {
											JsonObject i$runningObj = new JsonObject();
											i$runningObj = i$records.get(i).getAsJsonObject();
											String idSearch = i$ResM
													.convertId(i$runningObj.get("_id").getAsJsonObject());
											JsonObject setter = new JsonObject();
										
											// #MAQ00005 start
//											try {
//												setter.addProperty("IMPACTO_PORTFOLIO",
//														i$runningObj.get("IMPACTO_PORTFOLIO").getAsString());
//											
//											} catch (Exception e) {
//												setter = null;
//											}
											
											try {
												setter.addProperty("EXPOSURE_PORTFOLIO_USER",
													i$runningObj.get("EXPOSURE_PORTFOLIO_USER").getAsString());
											} catch (Exception e) {
												setter = null;
											}
											try {
												setter.addProperty("EXPOSURE_PORTFOLIO_MANAGEMENT", i$runningObj
														.get("EXPOSURE_PORTFOLIO_MANAGEMENT").getAsString());
											} catch (Exception e) {
												setter = null;
											}

											// Priority of Management > User > Impacto Calculated PD Value

											// Building object for priority pick up.

											JsonArray priorityInArr = new JsonArray();
											JsonObject priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("EXPOSURE_PORTFOLIO_MANAGEMENT").getAsString());
											priorityInObj.addProperty("priority", 3);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("EXPOSURE_PORTFOLIO_USER").getAsString());
											priorityInObj.addProperty("priority", 2);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("EXPOSURE_PORTFOLIO").getAsString());
											priorityInObj.addProperty("priority", 1);
											priorityInArr.add(priorityInObj);

											JsonObject i$finalValue = I$utils.getHighPriorityValue(priorityInArr);

											if (i$finalValue != null) {

												setter.addProperty("EXPOSURE_PORTFOLIO_FINAL",
														i$finalValue.get("value").getAsString());
											} else {
												setter.addProperty("EXPOSURE_PORTFOLIO_FINAL",
														i$runningObj.get("EXPOSURE_PORTFOLIO").getAsString());
											}
											// #MAQ00005 end
											JsonObject $up = db$Ctrl.db$UpdateRowId(cycleCollectionName, setter,
													idSearch);

											logger.debug("$up: " + $up);

										}
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Data Saved Successfully");
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								// Getting the Count
								if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
									JsonObject filter = new JsonObject();
									String outCollName = icorMCycle.get("collectionName").getAsString();

									return db$Ctrl.db$GetCount(outCollName, isonMsg, "{}");
									/*
									 * isonMsg = i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC,
									 * "RECORD RETRIEVED SUCCESSFULLY"); isonMsg =
									 * i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
									 * 
									 * return isonMsg;
									 */
								}

							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "BUCKETIZATION")) {

								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonObject projection = new JsonObject();

									projection.addProperty("EXPOSURE_ID", 1);
									projection.addProperty("BORROWER_ID", 1);
									projection.addProperty("BORROWER_TYPE", 1);
									projection.addProperty("EXPOSURE_PRODUCT", 1);
									projection.addProperty("EXPOSURE_AMT_AT_INCEPTION", 1);
									projection.addProperty("EXPOSURE_AMT_AT_POINT", 1);
									projection.addProperty("INCEPTION_DATE", 1);
									projection.addProperty("MATURITY_DATE", 1);
									projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
									projection.addProperty("EXPOSURE_PORTFOLIO", 1);
									// #MAQ00006 Start
									projection.addProperty("BUCKETIZATION", "$BUCKETIZATION");
									// #MAQ00005 start
									projection.addProperty("BUCKETIZATION_USER", "$BUCKETIZATION_USER");
									projection.addProperty("BUCKETIZATION_MANAGEMENT", "$BUCKETIZATION_MANAGEMENT");
									// #MAQ00005 end
									JsonObject db$Result = db$Ctrl.db$getRowAgg(cycleCollectionName,projection, intPgNo, intRecs);									
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$Result.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$Result.getAsJsonObject("i-stat"));
									return isonMsg; 
									// #MAQ00006 End
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonArray i$records = new JsonArray();
									i$records = i$body.getAsJsonArray("editedData");

									try {
										for (int i = 0; i < i$records.size(); i++) {
											JsonObject i$runningObj = new JsonObject();
											i$runningObj = i$records.get(i).getAsJsonObject();
											String idSearch = i$ResM
													.convertId(i$runningObj.get("_id").getAsJsonObject());
											JsonObject setter = new JsonObject();

											try {
												 
												setter.addProperty("BUCKETIZATION_USER",
														i$runningObj.get("BUCKETIZATION_USER").getAsString());
											} catch (Exception e) {

											}
											try {
												setter.addProperty("BUCKETIZATION_MANAGEMENT",
														i$runningObj.get("BUCKETIZATION_MANAGEMENT").getAsString());

											} catch (Exception e) {

											}
											
											 
											// #MAQ00005 start	
											// Priority of Management > User > Impacto Calculated PD Value

											// Building object for priority pick up.

											
											JsonArray priorityInArr = new JsonArray();
											JsonObject priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("BUCKETIZATION_MANAGEMENT").getAsString());
											priorityInObj.addProperty("priority", 3);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("BUCKETIZATION_USER").getAsString());
											priorityInObj.addProperty("priority", 2);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("BUCKETIZATION").getAsString());
											priorityInObj.addProperty("priority", 1);
											priorityInArr.add(priorityInObj);

											JsonObject i$finalValue = I$utils.getHighPriorityValue(priorityInArr);

											if (i$finalValue != null) {

												setter.addProperty("BUCKETIZATION_FINAL",
														i$finalValue.get("value").getAsString());
											} else {
												setter.addProperty("BUCKETIZATION_FINAL",
														i$runningObj.get("BUCKETIZATION").getAsString());
											}
											// #MAQ00005 end
						
											JsonObject $up = db$Ctrl.db$UpdateRowId(cycleCollectionName, setter,
													idSearch);

											logger.debug("$up: " + $up);

										}
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Data Saved Successfully");
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {

									try {
										JsonObject filter = new JsonObject();
										JsonObject setter = new JsonObject();
										filter = new JsonObject();
										filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
										setter = new JsonObject();
										setter.addProperty("currentStage", SOpr1);
										setter.addProperty("currentStageStatus", "Completed");
										setter.addProperty("nextStage", "LGDASSIGNMENT"); 
										setter.addProperty("nextStageStatus", "WIP");
										JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 
										JsonObject projection = new JsonObject();
										// This will have to happen for all the Loans Existing in the Exposure
										// Collection
										String collectionName = icorMCycle.get("collectionName").getAsString();

										projection.addProperty("EXPOSURE_ID", 1);
										// projection.addProperty("EXPOSURE_TYPE_ID", 1);
										// projection.addProperty("INCEPTION_DATE", 1);
										// projection.addProperty("EXPOSURE_CCY", 1);
										projection.addProperty("EXPOSURE_AMT_AT_INCEPTION", 1);
										projection.addProperty("EXPOSURE_AMT_AT_POINT", 1);
										projection.addProperty("EXPOSURE_PRODUCT", 1);
										projection.addProperty("PRINCIPAL_AT_POINT_IN_TIME", 1);
										projection.addProperty("MAIN_INT_AT_POINT_IN_TIME", 1);
										projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
										projection.addProperty("EXPOSURE_PORTFOLIO", 1);
										projection.addProperty("BUCKETIZATION", 1);

										// Getting COllection Details of Collateral Revaluation
										String collateralRevMapId = icorMCycle.get("collateralRevMapId").getAsString();
										filter = new JsonObject();
										filter.addProperty("collateralId", collateralRevMapId);
										JsonObject i$icorMCollRev = db$Ctrl.db$GetRow("ICOR_M_IFRS_COLLREVALUTION",
												filter);
										String collRevColName = i$icorMCollRev.get("collectionName").getAsString();
										// projection = new JsonObject();

										// Getting Collection Protection Details
										String collectionProtMapId = icorMCycle.get("collectionProtMapId")
												.getAsString();
										filter = new JsonObject();
										filter.addProperty("mapId", collectionProtMapId);
										JsonObject i$icorMCollProt = db$Ctrl.db$GetRow("ICOR_M_IFRS_HISTORPRO", filter);

										// Updating the collection protection to Exposure

										String[] bucket = { "bucket1", "bucket2", "bucket3" };

										for (int i = 0; i < bucket.length; i++) {
											JsonArray bucketDetails = new JsonArray();
											bucketDetails = i$icorMCollProt.get(bucket[i]).getAsJsonArray();
											// Fire rule for the Bucket to PD

											for (int j = 0; j < bucketDetails.size(); j++) {
												JsonObject i$runningObj = bucketDetails.get(j).getAsJsonObject();
												setter = new JsonObject();
												try {
													setter.addProperty("COLLECTION_PROTECTION",
															i$runningObj.get("collPer").getAsDouble());
												} catch (Exception e) {
													setter.addProperty("COLLECTION_PROTECTION", 0.01);
												}

												filter = new JsonObject();
												String value = "";
												if (I$utils.$iStrFuzzyMatch(bucket[i], "bucket1"))
													value = "BUCKET 1";
												else if (I$utils.$iStrFuzzyMatch(bucket[i], "bucket2"))
													value = "BUCKET 2";
												else if (I$utils.$iStrFuzzyMatch(bucket[i], "bucket3"))
													value = "BUCKET 3";
												// double vLGD = 0.00;
												filter.addProperty("BUCKETIZATION", value);
												try {
													filter.addProperty("EXPOSURE_PORTFOLIO",
															i$runningObj.get("portId").getAsString());
												} catch (Exception e) {
													// vLGD = (100 - 50) / 100;
													filter.addProperty("EXPOSURE_PORTFOLIO", "UNKNOW CLASSIFICATION");
												}
												db$Ctrl.db$UpdateRow(collectionName, setter, filter);

											}
										}

										filter = new JsonObject();
										int i$exposuresCount = 0;
										try {
											i$exposuresCount = db$Ctrl.db$GetCountI(collectionName,
													gson.toJson(filter));
										} catch (Exception e) {
											i$exposuresCount = 0;
										}

										// double i$noOfIter = Math.ceil(i$exposuresCount / 1000);
										double i$noOfIter = Math.ceil(i$exposuresCount / i$exposuresCount);

										// Feeding number of threads to Master Table
										filter = new JsonObject();
										filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
										setter = new JsonObject();
										setter.addProperty("noOfThreads", i$noOfIter);
										setter.addProperty("noOfExecutedThreads", 0);

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

										for (int k = 0; k < i$noOfIter; k++) {
											JsonObject jWrkArgs = new JsonObject();
											jWrkArgs.addProperty("collectionName", collectionName);
											jWrkArgs.addProperty("i$ThreadNo", k);
											jWrkArgs.addProperty("i$limit", i$exposuresCount);
											jWrkArgs.addProperty("collRevColName", collRevColName);
											jWrkArgs.addProperty("L_Coll_Name", L_Coll_Name); // Danger 
											jWrkArgs.addProperty("icorMCycle", collRevColName);
											jWrkArgs.add("isonMsg", isonMsg);
											jWrkArgs.add("icorMCycle", icorMCycle);

											logger.debug(
													"************************************************************************************");
											logger.debug("Starting Thread " + Integer.toString(k));
											logger.debug("------------");
											logger.debug("Params ");
											logger.debug("------------");

											logger.debug("2.ITHRIDNO--> " + Integer.toString(k) + " Of "
													+ Integer.toString(5));

											logger.debug("------------");
											logger.debug(
													"************************************************************************************");
											// Forwarding request to threads
											IThreadController IThread$worker = new IThreadController(jWrkArgs);
											Thread t = new Thread(IThread$worker);
											// threads Started
											t.start();

										}

										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$body);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"LGD ASSIGNMENT INITIATED");

										return isonMsg;

									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}
								}

								// Getting the Count
								else if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
									JsonObject filter = new JsonObject();
									String outCollName = icorMCycle.get("collectionName").getAsString();

									return db$Ctrl.db$GetCount(outCollName, isonMsg, "{}");

								}

							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "PDASSIGNMENT")) {
								// Save the data that is sent by the Front end First.

								// PD Assignment got completed will have to store the data and kick-off LGD
								// Calculation now
								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
									JsonObject filter = new JsonObject();

									// JsonObject sFilter = new JsonObject();

									String collectionName = icorMCycle.get("collectionName").getAsString();

									// sFilter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									JsonObject setter = new JsonObject();
									setter.addProperty("currentStage", SOpr1);
									setter.addProperty("currentStageStatus", "Completed");
									setter.addProperty("nextStage", "REBUCKETIZATION");  
									setter.addProperty("nextStageStatus", "WIP");

									JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

									// Moving Code to threading
									// #MAQ00005 start 
									filter = new JsonObject();
									int i$exposuresCount = 0;
									try {
										i$exposuresCount = db$Ctrl.db$GetCountI(collectionName, gson.toJson(filter));
									} catch (Exception e) {
										i$exposuresCount = 0;
									}

									// double i$noOfIter = Math.ceil(i$exposuresCount / 1000);
									double i$noOfIter = Math.ceil(i$exposuresCount / i$exposuresCount);

									// Feeding number of threads to Master Table
									filter = new JsonObject();
									filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									setter = new JsonObject();
									setter.addProperty("noOfThreads", i$noOfIter);
									setter.addProperty("noOfExecutedThreads", 0);

									up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger

									for (int k = 0; k < i$noOfIter; k++) {
									// MAQ00005 end
									
										// Going to Create Args for Worker Thread
										JsonObject jWrkArgs = new JsonObject();
										jWrkArgs.add("isonMsg", isonMsg);
										jWrkArgs.addProperty("collectionName", collectionName);
										jWrkArgs.addProperty("i$ThreadNo", 0);
										jWrkArgs.addProperty("L_Coll_Name", L_Coll_Name); // Danger 
										jWrkArgs.add("icorMCycle", icorMCycle);
	
										logger.debug(
												"************************************************************************************");
										logger.debug("Starting Thread " + Integer.toString(0));
										logger.debug("------------");
										logger.debug("Params ");
										logger.debug("------------");
	
										logger.debug("2.ITHRIDNO--> " + Integer.toString(0) + " Of " + 0);
	
										logger.debug("------------");
										logger.debug(
												"************************************************************************************");
										// Forwarding request to threads
										IThreadController IThread$worker = new IThreadController(jWrkArgs);
										Thread t = new Thread(IThread$worker);
										// threads Started
										t.start();
									}
									
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"RE_BUCKETIZATION Initiated");

									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$body);

									return isonMsg;
								}

								else if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonObject projection = new JsonObject();
									projection.addProperty("EXPOSURE_ID", 1);
									projection.addProperty("BORROWER_TYPE", 1);
									projection.addProperty("EXPOSURE_PRODUCT", 1);
									projection.addProperty("EXPOSURE_AMT_AT_INCEPTION", 1);
									projection.addProperty("EXPOSURE_AMT_AT_POINT", 1);
									projection.addProperty("INCEPTION_DATE", 1);
									projection.addProperty("MATURITY_DATE", 1);
									projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
									projection.addProperty("EXPOSURE_PORTFOLIO", 1);
									projection.addProperty("BUCKETIZATION", 1);
									// #MAQ00006 Start
									projection.addProperty("PD", "$PD");
									// #MAQ00005 start
									projection.addProperty("PD_USER", "$PD_USER");
									projection.addProperty("PD_MANAGEMENT", "$PD_MANAGEMENT");
									// #MAQ00005 end
									JsonObject db$Result = db$Ctrl.db$getRowAgg(cycleCollectionName,projection, intPgNo, intRecs);									
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$Result.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$Result.getAsJsonObject("i-stat"));
									return isonMsg;
									// #MAQ00006 End
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonArray i$records = new JsonArray();
									i$records = i$body.getAsJsonArray("editedData");

									try {
										for (int i = 0; i < i$records.size(); i++) {
											JsonObject i$runningObj = new JsonObject();
											i$runningObj = i$records.get(i).getAsJsonObject();
											String idSearch = i$ResM
													.convertId(i$runningObj.get("_id").getAsJsonObject());
											JsonObject setter = new JsonObject();
//											try {
//												setter.addProperty("EXPOSURE_PORTFOLIO",
//														i$runningObj.get("EXPOSURE_PORTFOLIO").getAsString());
//
//											} catch (Exception e) {
//
//											}
											/*
											 * try { setter.addProperty("BUCKETIZATION",
											 * i$runningObj.get("BUCKETIZATION").getAsString());
											 * 
											 * } catch (Exception e) {
											 * 
											 * }
											 */

											/*
											 * try { setter.addProperty("CURRENT_OVERDUE_DAYS",
											 * i$runningObj.get("CURRENT_OVERDUE_DAYS").getAsString());
											 * 
											 * } catch (Exception e) {
											 * 
											 * }
											 */
											try {
												setter.addProperty("PD_USER",
														i$runningObj.get("PD_USER").getAsString());

											} catch (Exception e) {

											}
											try {
												setter.addProperty("PD_MANAGEMENT",
														i$runningObj.get("PD_MANAGEMENT").getAsString());

											} catch (Exception e) {

											}

											// Priority of Management > User > Impacto Calculated PD Value

											// Building object for priority pick up.

											JsonArray priorityInArr = new JsonArray();
											JsonObject priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("PD_MANAGEMENT").getAsString());
											priorityInObj.addProperty("priority", 3);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("PD_USER").getAsString());
											priorityInObj.addProperty("priority", 2);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value", i$runningObj.get("PD").getAsString());
											priorityInObj.addProperty("priority", 1);
											priorityInArr.add(priorityInObj);

											JsonObject i$finalValue = I$utils.getHighPriorityValue(priorityInArr);

											if (i$finalValue != null) {

												setter.addProperty("PD_FINAL", i$finalValue.get("value").getAsString());
											} else {
												setter.addProperty("PD_FINAL", i$runningObj.get("PD").getAsString());
											}

											JsonObject $up = db$Ctrl.db$UpdateRowId(cycleCollectionName, setter,
													idSearch);

											logger.debug("$up: " + $up);

										}
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Data Saved Successfully");
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								// Getting the Count
								if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
									// JsonObject filter = new JsonObject();
									String outCollName = icorMCycle.get("collectionName").getAsString();

									// JsonObject responseJson = db$Ctrl.db$GetCount(outCollName, "{}");
									return db$Ctrl.db$GetCount(outCollName, isonMsg, "{}");
									/*
									 * isonMsg = i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC,
									 * "RECORD RETRIEVED SUCCESSFULLY"); isonMsg =
									 * i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
									 * 
									 * return isonMsg;
									 */
								}

							}
							// #BVB00023 Starts
							else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "LGDASSIGNMENT")) {
								// I Think this is LGD Assignment
								// Save the data that is sent by the Front end First.

								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
									JsonObject filter = new JsonObject();
									String collectionName = icorMCycle.get("collectionName").getAsString();
									// Update the Master-->
									filter = new JsonObject();
									filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									JsonObject setter = new JsonObject();
									setter.addProperty("currentStage", SOpr1);
									setter.addProperty("currentStageStatus", "Completed");
									setter.addProperty("nextStage", "PDASSIGNMENT"); 
									setter.addProperty("nextStageStatus", "WIP");

									JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

									// Moving Code to threading
									// MAQ00005 start
									filter = new JsonObject();
									int i$exposuresCount = 0;
									try {
										i$exposuresCount = db$Ctrl.db$GetCountI(collectionName, gson.toJson(filter));
									} catch (Exception e) {
										i$exposuresCount = 0;
									}

									// double i$noOfIter = Math.ceil(i$exposuresCount / 1000);
									double i$noOfIter = Math.ceil(i$exposuresCount / i$exposuresCount);

									// Feeding number of threads to Master Table
									filter = new JsonObject();
									filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
									setter = new JsonObject();
									setter.addProperty("noOfThreads", i$noOfIter);
									setter.addProperty("noOfExecutedThreads", 0);

									up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger

									for (int k = 0; k < i$noOfIter; k++) {
									// MAQ00005 end
										// Going to Create Args for Worker Thread
										JsonObject jWrkArgs = new JsonObject();
										jWrkArgs.add("isonMsg", isonMsg);
										jWrkArgs.addProperty("collectionName", collectionName);
										jWrkArgs.addProperty("i$ThreadNo", k);
										jWrkArgs.addProperty("i$limit", i$exposuresCount);
										jWrkArgs.addProperty("L_Coll_Name", L_Coll_Name); // Danger 
										jWrkArgs.add("icorMCycle", icorMCycle);
		
										logger.debug(
												"************************************************************************************");
										logger.debug("Starting Thread " + Integer.toString(0));
										logger.debug("------------");
										logger.debug("Params ");
										logger.debug("------------");
		
										logger.debug("2.ITHRIDNO--> " + Integer.toString(0) + " Of " + 0);
		
										logger.debug("------------");
										logger.debug(
												"************************************************************************************");
										// Forwarding request to threads
										IThreadController IThread$worker = new IThreadController(jWrkArgs);
										Thread t = new Thread(IThread$worker);
										// threads Started
										t.start();
									}

									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PD Assignement Initiated");

									return isonMsg;
								}								

								else if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonObject projection = new JsonObject();

									projection.addProperty("EXPOSURE_ID", 1);
									projection.addProperty("BORROWER_ID", 1);
									projection.addProperty("BORROWER_TYPE", 1);
									
									projection.addProperty("EXPOSURE_PRODUCT", 1);
									projection.addProperty("EXPOSURE_AMT_AT_INCEPTION", 1);
									projection.addProperty("EXPOSURE_AMT_AT_POINT", 1);
									projection.addProperty("INCEPTION_DATE", 1);
									projection.addProperty("MATURITY_DATE", 1);
									projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
									projection.addProperty("EXPOSURE_PORTFOLIO_FINAL", 1);
									projection.addProperty("BUCKETIZATION_FINAL", 1);
									//projection.addProperty("PD_MODEL", 1);
									projection.addProperty("COLLATERAL_PROTECTION", 1); // This is pending
									projection.addProperty("COLLECTION_PROTECTION_PER", 1);
									projection.addProperty("COLLECTION_PROTECTION", 1);
									// #MAQ00006 Start
									projection.addProperty("LGD", "$LGD");
									// #MAQ00005 start
									projection.addProperty("LGD_USER", "$LGD_USER");
									projection.addProperty("LGD_MANAGEMENT", "$LGD_MANAGEMENT");
									// #MAQ00005 end
									JsonObject db$Result = db$Ctrl.db$getRowAgg(cycleCollectionName,projection, intPgNo, intRecs);									
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$Result.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$Result.getAsJsonObject("i-stat"));
									return isonMsg;
									// #MAQ00006 End
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonArray i$records = new JsonArray();
									i$records = i$body.getAsJsonArray("editedData");

									try {
										for (int i = 0; i < i$records.size(); i++) {
											JsonObject i$runningObj = new JsonObject();
											i$runningObj = i$records.get(i).getAsJsonObject();
											String idSearch = i$ResM
													.convertId(i$runningObj.get("_id").getAsJsonObject());
											JsonObject setter = new JsonObject();
//											try {
//												setter.addProperty("LGD", i$runningObj.get("LGD").getAsDouble());
//
//											} catch (Exception e) {
//
//											}
//											try {
//												setter.addProperty("COLLECTION_PROTECTION",
//														i$runningObj.get("COLLECTION_PROTECTION").getAsDouble());
//
//											} catch (Exception e) {
//
//											}
//											try {
//												setter.addProperty("COLLATERAL_PROTECTION",
//														i$runningObj.get("COLLATERAL_PROTECTION").getAsDouble());
//
//											} catch (Exception e) {
//
//											}
											try {
												setter.addProperty("LGD_USER",
														i$runningObj.get("LGD_USER").getAsDouble());

											} catch (Exception e) {

											}

											try {
												setter.addProperty("LGD_MANAGEMENT",
														i$runningObj.get("LGD_MANAGEMENT").getAsDouble());

											} catch (Exception e) {

											}
											
											// Priority of Management > User > Impacto Calculated PD Value

											// Building object for priority pick up.

											JsonArray priorityInArr = new JsonArray();
											JsonObject priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("LGD_MANAGEMENT").getAsString());
											priorityInObj.addProperty("priority", 3);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("LGD_USER").getAsString());
											priorityInObj.addProperty("priority", 2);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value", i$runningObj.get("LGD").getAsString());
											priorityInObj.addProperty("priority", 1);
											priorityInArr.add(priorityInObj);

											JsonObject i$finalValue = I$utils.getHighPriorityValue(priorityInArr);

											if (i$finalValue != null) {

												setter.addProperty("LGD_FINAL",
														i$finalValue.get("value").getAsString());
											} else {
												setter.addProperty("LGD_FINAL", i$runningObj.get("LGD").getAsString());
											}


											JsonObject $up = db$Ctrl.db$UpdateRowId(cycleCollectionName, setter,
													idSearch);

											logger.debug("$up: " + $up);

										}
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Data Saved Successfully");
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								// Getting the Count
								if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
									JsonObject filter = new JsonObject();
									String outCollName = icorMCycle.get("collectionName").getAsString();

									return db$Ctrl.db$GetCount(outCollName, isonMsg, "{}");
									// JsonObject responseJson = db$Ctrl.db$GetCount(outCollName, "{}");
									/*
									 * isonMsg = i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC,
									 * "RECORD RETRIEVED SUCCESSFULLY"); isonMsg =
									 * i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
									 * 
									 * return isonMsg;
									 */

								}

							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "REBUCKETIZATION")) {
								// Save the data that is sent by the Front end First.
								// Final Save needs to be done which will initiate ECL Calculation

								// Creating New Create for ECL Calculation

								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
									try {
										JsonObject filter = new JsonObject();
										JsonObject setter = new JsonObject();
										JsonObject projection = new JsonObject();
										String cycleId = i$body.get("cycleId").getAsString(); 
										filter = new JsonObject();
										filter.addProperty("cycleId", cycleId);
										setter = new JsonObject();
										setter.addProperty("currentStage", SOpr1);
										setter.addProperty("currentStageStatus", "Completed");
										setter.addProperty("nextStage", "ECL CALCULATION");
										setter.addProperty("nextStageStatus", "WIP");
										JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

										filter = new JsonObject();
										filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
										JsonObject iCorMCycle = db$Ctrl.db$GetRow(L_Coll_Name, gson.toJson(filter));

										String collectionName = iCorMCycle.get("collectionName").getAsString();
										String lendScheduleRunId = icorMCycle.get("exposureCashflowRunID")
												.getAsString();
										String lendScheduleColl = "#IETL%" + lendScheduleRunId;
										
										// Adding code to create Index on Schedule Collection 
										filter.addProperty("INDEXCOlNAME", "EXPOSURE_ID"); //  #MAQ00004
										db$Ctrl.db$createIndex(lendScheduleColl, filter.toString());
										
										// Create Index on lendScheduleColl selected

										// Create Empty collection with specific fields of Schedule Run Id
										// Need to decide on what all fields are required.
										String iCyclescheduleColl = "ICYCLE_SC_" + cycleId;


										// Loop over all the entities of collectionName
										// Implementing Pagination
										filter = new JsonObject();
										int i$exposuresCount = 0;
										try {
											i$exposuresCount = db$Ctrl.db$GetCountI(collectionName,
													gson.toJson(filter));
										} catch (Exception e) {
											i$exposuresCount = 0;
										}

										// double i$noOfIter = Math.ceil(i$exposuresCount / 1000);
										double i$noOfIter = Math.ceil(i$exposuresCount / i$exposuresCount);
										// Feeding number of threads to Master Table
										filter = new JsonObject();
										filter.addProperty("cycleId", i$body.get("cycleId").getAsString());
										setter = new JsonObject();
										setter.addProperty("noOfThreads", i$noOfIter);
										setter.addProperty("noOfExecutedThreads", 0);

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter); // Danger 

										for (int k = 0; k < i$noOfIter; k++) {
											// JsonArray i$exposures = db$Ctrl.db$GetRows(collectionName, projection);
											filter = new JsonObject();

											// Moving the code to Thread
											// First create the object and call threading

											// Going to Create Args for Worker Thread
											JsonObject jWrkArgs = new JsonObject();
											jWrkArgs.add("isonMsg", isonMsg);
											jWrkArgs.addProperty("collectionName", collectionName);
											jWrkArgs.addProperty("i$ThreadNo", k);
											jWrkArgs.addProperty("i$limit", i$exposuresCount);
											jWrkArgs.addProperty("lendScheduleColl", lendScheduleColl);
											jWrkArgs.addProperty("iCyclescheduleColl", iCyclescheduleColl);
											jWrkArgs.addProperty("L_Coll_Name", L_Coll_Name); // Danger 

											logger.debug(
													"************************************************************************************");
											logger.debug("Starting Thread " + Integer.toString(k));
											logger.debug("------------");
											logger.debug("Params ");
											logger.debug("------------");

											logger.debug("2.ITHRIDNO--> " + Integer.toString(k) + " Of " + i$noOfIter);

											logger.debug("------------");
											logger.debug(
													"************************************************************************************");
											// Forwarding request to threads
											IThreadController IThread$worker = new IThreadController(jWrkArgs);
											Thread t = new Thread(IThread$worker);
											// threads Started
											t.start();

										}

										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$body);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"ECL Calculation INITIATED");

										return isonMsg;
										
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								else if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonObject projection = new JsonObject();
									projection.addProperty("EXPOSURE_ID", 1);
									projection.addProperty("BORROWER_ID", 1);
									projection.addProperty("BORROWER_TYPE", 1);									
									projection.addProperty("EXPOSURE_PRODUCT", 1);
									projection.addProperty("EXPOSURE_AMT_AT_INCEPTION", 1);
									projection.addProperty("EXPOSURE_AMT_AT_POINT", 1);
									projection.addProperty("INCEPTION_DATE", 1);
									projection.addProperty("MATURITY_DATE", 1);
									projection.addProperty("CURRENT_OVERDUE_DAYS", 1);
									projection.addProperty("EXPOSURE_PORTFOLIO", 1);
									projection.addProperty("BUCKETIZATION", 1);
									projection.addProperty("PD", 1);
									projection.addProperty("COLLATERAL_PROTECTION", 1); // This is pending
									projection.addProperty("COLLECTION_PROTECTION_PER", 1);
									projection.addProperty("COLLECTION_PROTECTION", 1);
									projection.addProperty("LGD", 1);
									// #MAQ00006 Start
									projection.addProperty("REBUCKETIZATION", "$REBUCKETIZATION");
									// #MAQ00005 start
									projection.addProperty("REBUCKETIZATION_USER", "$REBUCKETIZATION_USER");
									// #MAQ00005 end
									JsonObject db$Result = db$Ctrl.db$getRowAgg(cycleCollectionName,projection, intPgNo, intRecs);									
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$Result.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$Result.getAsJsonObject("i-stat"));
									return isonMsg;
									// #MAQ00006 End
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonArray i$records = new JsonArray();
									i$records = i$body.getAsJsonArray("editedData");

									try {
										for (int i = 0; i < i$records.size(); i++) {
											JsonObject i$runningObj = new JsonObject();
											i$runningObj = i$records.get(i).getAsJsonObject();
											String idSearch = i$ResM
													.convertId(i$runningObj.get("_id").getAsJsonObject());
											JsonObject setter = new JsonObject();
											/*
											 * try { setter.addProperty("EXPOSURE_PORTFOLIO",
											 * i$runningObj.get("EXPOSURE_PORTFOLIO").getAsString());
											 * 
											 * } catch (Exception e) {
											 * 
											 * } try { setter.addProperty("BUCKETIZATION",
											 * i$runningObj.get("BUCKETIZATION").getAsString());
											 * 
											 * } catch (Exception e) {
											 * 
											 * }
											 */

//											try {
//												setter.addProperty("REBUCKETIZATION",
//														i$runningObj.get("REBUCKETIZATION").getAsString());
//
//											} catch (Exception e) {
//
//											}

											/*
											 * try { setter.addProperty("CURRENT_OVERDUE_DAYS",
											 * i$runningObj.get("CURRENT_OVERDUE_DAYS").getAsString());
											 * 
											 * } catch (Exception e) {
											 * 
											 * }
											 */
											try {
												setter.addProperty("REBUCKETIZATION_USER",
														i$runningObj.get("REBUCKETIZATION_USER").getAsString());

											} catch (Exception e) {

											}
											
											// Priority of Management > User > Impacto Calculated PD Value

											// Building object for priority pick up.

											JsonArray priorityInArr = new JsonArray();
											JsonObject priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("REBUCKETIZATION_USER").getAsString());
											priorityInObj.addProperty("priority", 3);
											priorityInArr.add(priorityInObj);

											priorityInObj = new JsonObject();
											priorityInObj.addProperty("value",
													i$runningObj.get("REBUCKETIZATION").getAsString());
											priorityInObj.addProperty("priority", 2);
											priorityInArr.add(priorityInObj);

											JsonObject i$finalValue = I$utils.getHighPriorityValue(priorityInArr);

											if (i$finalValue != null) {

												setter.addProperty("REBUCKETIZATION_FINAL",
														i$finalValue.get("value").getAsString());
											} else {
												setter.addProperty("REBUCKETIZATION_FINAL",
														i$runningObj.get("REBUCKETIZATION").getAsString());
											}

											JsonObject $up = db$Ctrl.db$UpdateRowId(cycleCollectionName, setter,
													idSearch);

											logger.debug("$up: " + $up);

										}
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Data Saved Successfully");
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								// Getting the Count
								if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
									JsonObject filter = new JsonObject();
									String outCollName = icorMCycle.get("collectionName").getAsString();

									// JsonObject responseJson = db$Ctrl.db$GetCount(outCollName, "{}");
									return db$Ctrl.db$GetCount(outCollName, isonMsg, "{}");
									/*
									 * isonMsg = i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC,
									 * "RECORD RETRIEVED SUCCESSFULLY"); isonMsg =
									 * i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
									 * 
									 * return isonMsg;
									 */
								}

							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
									&& I$utils.$iStrFuzzyMatch(SOpr1, "ECLCALCULATION")) {
								// Final Save needs to be done which will initiate ECL Calculation
								if (I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
									// Not sure what to do here !!
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Next Stepper in Progress"); //To avoid show stopper #MAQ00002 
									
								} else if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERY")) {
									int intPgNo = i$body.get("intPgNo").getAsInt();
									int intRecs = i$body.get("intRecs").getAsInt();
									String iCyclescheduleColl = icorMCycle.get("iCyclescheduleColl").getAsString();
									JsonObject projection = new JsonObject();
									projection.addProperty("EXPOSURE_ID", 1); //  #MAQ00004
									projection.addProperty("EXPOSURE_PRODUCT", 1);
									projection.addProperty("EXPOSURE_PORTFOLIO", 1);
									projection.addProperty("PD", 1);
									projection.addProperty("BUCKETIZATION", 1);
									projection.addProperty("PRDCODE", 1);
									projection.addProperty("PRDCATEGORY", 1);
									projection.addProperty("AMOUNTTOBEPAID", 1);
									projection.addProperty("SETTLEDAMOUNT", 1);
									// projection.addProperty("LGD", 1);
									projection.addProperty("SCHEDULEDUEDATE", 1);
									// #MAQ00006 Start
									projection.addProperty("ECL", "$ECL");
									JsonObject db$Result = db$Ctrl.db$getRowAgg(iCyclescheduleColl,projection, intPgNo, intRecs);									
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$Result.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$Result.getAsJsonObject("i-stat"));
									return isonMsg;
									// #MAQ00006 End
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "PARTIALSAVE")) {
									String cycleCollectionName = icorMCycle.get("collectionName").getAsString();
									JsonArray i$records = new JsonArray();
									i$records = i$body.getAsJsonArray("editedData");

									try {
										for (int i = 0; i < i$records.size(); i++) {
											JsonObject i$runningObj = new JsonObject();
											i$runningObj = i$records.get(i).getAsJsonObject();
											String idSearch = i$ResM
													.convertId(i$runningObj.get("_id").getAsJsonObject());
											JsonObject setter = new JsonObject();
											try {
												setter.addProperty("EXPOSURE_PORTFOLIO",
														i$runningObj.get("EXPOSURE_PORTFOLIO").getAsString());

											} catch (Exception e) {

											}
											try {
												setter.addProperty("BUCKETIZATION",
														i$runningObj.get("BUCKETIZATION").getAsString());

											} catch (Exception e) {

											}
											try {
												setter.addProperty("CURRENT_OVERDUE_DAYS",
														i$runningObj.get("CURRENT_OVERDUE_DAYS").getAsString());

											} catch (Exception e) {

											}
											JsonObject $up = db$Ctrl.db$UpdateRowId(cycleCollectionName, setter,
													idSearch);

											logger.debug("$up: " + $up);

										}
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Data Saved Successfully");
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
												e.getMessage().toString());
										e.printStackTrace();
										return isonMsg;
									}

								}

								// Getting the Count
								if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
									JsonObject filter = new JsonObject();
									String outCollName = icorMCycle.get("collectionName").getAsString();
									return db$Ctrl.db$GetCount(outCollName, isonMsg, "{}");
									/*
									 * JsonObject responseJson = db$Ctrl.db$GetCount(outCollName, "{}"); isonMsg =
									 * i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC,
									 * "RECORD RETRIEVED SUCCESSFULLY"); isonMsg =
									 * i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
									 * 
									 * return isonMsg;
									 */

								}

							// #MAQ00007 Start
							} else if (I$utils.$iStrFuzzyMatch(SOpr, "CHART$MASTER")) {
								try {
									JsonObject c$Filter = new JsonObject();
									JsonObject projection = new JsonObject();

									String cycleCollectionName = icorMCycle.get("iCyclescheduleColl").getAsString();
									String iCycleCharts = "ICOR_M_ICYCLE_CHART_TYPE";
									c$Filter.addProperty("CHART_TYPE", i$body.get("CHARTNAME").getAsString());
									projection.addProperty("_id",0);
									JsonObject db$Result = db$Ctrl.db$GetRow(iCycleCharts, c$Filter.toString(), projection.toString());
									
									//cycleCollectionName = "#ICYCLE%" + cycleCollectionName;
									
									
									JsonObject db$chartData = db$Ctrl.db$GetAggregate(cycleCollectionName,db$Result.toString() );
									icorMCycle.addProperty("errorMsg", "Record Sucessfully Retrieved");
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$chartData.getAsJsonArray("i-body"));
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, db$chartData.getAsJsonObject("i-stat"));
									return isonMsg;
									
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
								// #MAQ00007 End

							} // BVB Danger

							// #BVB00023 Ends
						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
							return isonMsg;
						}
					} else {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
						return isonMsg;
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
							e.getMessage().toString());
					e.printStackTrace();
					return isonMsg;
				}
			} else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
				return isonMsg;
			}

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
//
//	public JsonObject i$releaseLock(JsonObject recIdObject) {
//		try {
//			String recID = i$ResM.convertId(recIdObject);
//			return db$Ctrl.db$ReleaseRow(recID);
//		} catch (Exception e) {
//			return null;
//		}
//	}

	public ICycleController() {
		// Constructor()
	}
}