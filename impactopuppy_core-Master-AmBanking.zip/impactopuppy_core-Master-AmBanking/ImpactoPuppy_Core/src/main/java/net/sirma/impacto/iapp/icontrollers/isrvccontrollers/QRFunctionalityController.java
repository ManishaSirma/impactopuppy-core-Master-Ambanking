/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Srikanth 	| Dec 4, 2023  | #SRI00025   | Initial writing
      |0.1 Beta    | Srikanth 	| Dec 8, 2023  | #SRI00025   | code handled For the QR Scan Transaction 
      ----------------------------------------------------------------------------------------------
      
*/
//#SRI00025 Starts 
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.util.Date;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

//#SRI00025 Begins
public class QRFunctionalityController {

	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private DBController db$Ctrl = new DBController();
	private IDmsController dms$Ctrl = new IDmsController();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String SOpr1 = i$ResM.getOpr1(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			String SOpr3 = i$ResM.getOpr3(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OABQRSCD") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "Member_Id_Proof")) {
				isonMsg = qrCifScan(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABQCDCW") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "Request_CD_CW")) {
				isonMsg = qrReqCD$CW(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABQCDCW") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "Request_CD_CW")) {
				isonMsg = qrReqQueryCD$CW(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABQCDCW") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "Request_CIF")) {
				isonMsg = qrReqQueryCIF(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABQCDCW") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "Request_MPIN")) {
				isonMsg = qrReqMPIN(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABQCDCW") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "Decline_MPIN")) {
				isonMsg = qrDeclineMPIN(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
		}
		return isonMsg;
	}

	public JsonObject qrCifScan(JsonObject isonMsg) {
		JsonObject fltr = new JsonObject();
		JsonArray customerDataArray = new JsonArray();
		JsonObject sideData = new JsonObject();
		String fileContent = new String();
		String fileName = new String();
		JsonObject customerData = new JsonObject();
		
		boolean isDocumentProcessed = false;
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			fltr.addProperty("CustomerId", i$body.get("cifId").getAsString());
			JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
			
			if (I$utils.$isNull(cifData)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MEMBER ID");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, cifData);
			} else {
				String customerImg = cifData.get("CustomerImg").getAsString();
				sideData.addProperty("customerImg", customerImg);
				customerDataArray.add(sideData);
				sideData = new JsonObject();
				String customerSig = cifData.get("CustomerSig").getAsString();
				sideData.addProperty("customerSig", customerSig);
				customerDataArray.add(sideData);
			}
			JsonObject applnData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION",
					"{\"cbsDetails.CIF_CREATION.CIF\":\"" + i$body.get("cifId").getAsString() + "\"}");
			
			if (!I$utils.$isNull(applnData)) {
				JsonObject document = applnData.getAsJsonObject("documents");
				if (!I$utils.$isNull(document)) {
					JsonArray documentData = applnData.getAsJsonObject("documents").getAsJsonArray("documentDetails");
					for (int i = 0; i < documentData.size() && !isDocumentProcessed; i++) {
						try {
							JsonObject documentObject = documentData.get(i).getAsJsonObject();
							String idType = documentObject.get("idType").getAsString();
							if ("Primary Document".equalsIgnoreCase(idType)
									|| "Secondary Document".equalsIgnoreCase(idType) && !isDocumentProcessed) {
								JsonArray sidesArray = documentObject.getAsJsonArray("sides");
								if (sidesArray.size() == 2) {
									for (int j = 0; j < sidesArray.size(); j++) {
										try {
											sideData = new JsonObject();
											JsonObject sideObject = sidesArray.get(j).getAsJsonObject();
											i$body.addProperty("FileUrlToken",
													sideObject.get("FileUrlToken").getAsString());
											isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg,
													i$ResM.I_BDYTAG, i$body);
											isonMsg = dms$Ctrl.downloadFileDms(isonMsg);
											i$body = isonMsg.getAsJsonObject("i-body");
											int sideNumber = Integer.parseInt(sideObject.get("side").getAsString());
											if (sideNumber == 1) {
												fileName = "frontSide";
											} else if (sideNumber == 2) {
												fileName = "backSide";
											} else {
												fileName = "unknownSide";
											}
											fileContent = i$body.get("FileContent").getAsString();
											sideData.addProperty(fileName, fileContent);
											customerDataArray.add(sideData);
										} catch (Exception e) {
											e.printStackTrace();
										}
									}
									isDocumentProcessed = true;
								} else if (sidesArray.size() == 1) {
									sideData = new JsonObject();
									JsonObject sideObject = sidesArray.get(0).getAsJsonObject();
									i$body.addProperty("FileUrlToken", sideObject.get("FileUrlToken").getAsString());
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "i-body", i$body);
									isonMsg = dms$Ctrl.downloadFileDms(isonMsg);
									i$body = isonMsg.getAsJsonObject("i-body");
									fileName = i$body.get("DocParentGrpID1").getAsString();
									fileContent = i$body.get("FileContent").getAsString();
									sideData.addProperty(fileName, fileContent);
									customerDataArray.add(sideData);
								}
//						customerData.add("customerDataArray", customerDataArray);
							}
//					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, customerData);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
			customerData.add("customerDataArray", customerDataArray);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, customerData);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject qrReqCD$CW(JsonObject isonMsg) {
		try {
			JsonObject res = new JsonObject();
			JsonObject Data = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			
			Data.addProperty("CIF", i$body.get("cifId").getAsString());
			Data.addProperty("AmbId", i$body.get("ambassadorId").getAsString());
			Data.addProperty("TransactionType", i$body.get("transactionType").getAsString());
			Data.addProperty("Amount", i$body.get("amount").getAsString());
			Data.addProperty("referenceId", i$body.get("referenceId").getAsString());
			Data.add("createdAt", i$ResM.addDateTime(new Date()));
			Data.addProperty("isCurrVer", "Y");
			Data.addProperty("initiator", IResManipulator.iloggedUser.get());
//			Data.addProperty("pendingTrn", "Y");
			
			if (IResManipulator.iloggedUser.get().equals(i$body.get("ambassadorId").getAsString())) {
				Data.addProperty("status", "Active");
				db$Ctrl.db$InsertRow("ICOR_C_QR_SCANNER_DATA", Data);
				res.addProperty("status", Data.get("status").getAsString());
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res);
				return isonMsg;
			} else {
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN AMBASSDOR ID");
				return isonMsg;
			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
		}
		return isonMsg;
	}

	public JsonObject qrReqQueryCD$CW(JsonObject isonMsg) {
		try {
			JsonObject result = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject fltr = new JsonObject();
			
			fltr.addProperty("referenceId", i$body.get("referenceId").getAsString());
			JsonObject data = db$Ctrl.db$GetRow("ICOR_C_QR_SCANNER_DATA", fltr);
			if (I$utils.$isNull(data)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "INVALID OR UNKNOWN REFERENCE ID");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result);
			} else {
				result.addProperty("status", data.get("status").getAsString());
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result);
			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
		}
		return isonMsg;
	}

	public JsonObject qrReqQueryCIF(JsonObject isonMsg) {
		try {
			JsonObject result1 = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject fltr = new JsonObject();
			fltr.addProperty("status", "Active");
			fltr.addProperty("CIF", i$body.get("cifId").getAsString());
			JsonObject data1 = db$Ctrl.db$GetRow("ICOR_C_QR_SCANNER_DATA", fltr);
			if (I$utils.$isNull(data1)) {
				result1.addProperty("pendingTrn","N");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result1);
			} else {
				result1.addProperty("cifId", data1.get("CIF").getAsString());
				result1.addProperty("ambId", data1.get("AmbId").getAsString());
				result1.addProperty("amount", data1.get("Amount").getAsString());
				result1.addProperty("transactionType", data1.get("TransactionType").getAsString());
				result1.addProperty("referenceId", data1.get("referenceId").getAsString());
				result1.addProperty("status", data1.get("status").getAsString());
				if(I$utils.$iStrFuzzyMatch (data1.get("status").getAsString(),"Active")) {
					result1.addProperty("pendingTrn","Y");
				}else {
				result1.addProperty("pendingTrn","N");
				}
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject qrReqMPIN(JsonObject isonMsg) {
		JsonObject result1 = new JsonObject();
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject fltr = new JsonObject();
		JsonObject fltr1 = new JsonObject();
		fltr1.addProperty("key", i$body.get("cifId").getAsString());
		String userPassDecrypt = new String();
		try {
			fltr.addProperty("CIF", i$body.get("cifId").getAsString());
			fltr.addProperty("referenceId", i$body.get("referenceId").getAsString());
			fltr1.addProperty("key", i$body.get("cifId").getAsString());
			JsonObject data1 = db$Ctrl.db$GetRow("ICOR_C_QR_SCANNER_DATA", fltr);
			if (I$utils.$isNull(data1)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN REFERENCE ID");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result1);
			} else {
				userPassDecrypt = i$body.get("mpin").getAsString();
				JsonObject digiUserData = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", fltr1);
				userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt,
						digiUserData.get("msalt").getAsString());
				if (I$utils.$iStrFuzzyMatch(userPassDecrypt, digiUserData.get("mpin").getAsString())) {
					JsonObject updateData = new JsonObject();
					updateData.addProperty("status", "Completed");
					db$Ctrl.db$UpdateRow("ICOR_C_QR_SCANNER_DATA", updateData, fltr);
					result1.addProperty("status", updateData.get("status").getAsString());
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result1);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Transaction Completed");
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid MPIN");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result1);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject qrDeclineMPIN(JsonObject isonMsg) {
		JsonObject fltr = new JsonObject();
		JsonObject result = new JsonObject();
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			fltr.addProperty("CIF", i$body.get("cifId").getAsString());
			fltr.addProperty("referenceId", i$body.get("referenceId").getAsString());
			
			if (I$utils.$iStrFuzzyMatch("Decline", i$body.get("memberResponse").getAsString())) {
				JsonObject updateData = new JsonObject();
				updateData.addProperty("status", "Rejected");
				db$Ctrl.db$UpdateRow("ICOR_C_QR_SCANNER_DATA", updateData, fltr);
				result.addProperty("status", updateData.get("status").getAsString());
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, result);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Transaction Rejected");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}
}
// //#SRI00025 Ends 