/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      1.0.0.1      | Pappu      | 10-Jan-2022  | #PKY00068    | Initial writing
      1.0.0.1	   | Manikanta  | 05-Jul-2022  | #MVT00064	  | Added code to handle refer DC functionality
      ----------------------------------------------------------------------------------------------
      
*/
//#PKY00068 starts
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRepoController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IKycCheckViewController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

		private Ioutils I$utils = new Ioutils();
		private IResManipulator i$ResM = new IResManipulator();
		private static final Logger logger = LoggerFactory.getLogger(ICifSdnScanController.class);
		private IRepoController i$irepoCtrl = new IRepoController();
		private DBController db$Ctrl = new DBController();
		private Ioutils i$outis = new Ioutils();
		private ImpactoUtil I$Imputils = new ImpactoUtil();
		private SdnScanController I$sdn = new SdnScanController();
		
		public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		    try {
		        String screenId = i$ResM.getScreenID(isonMsg);
		        String operation = i$ResM.getOpr(isonMsg);
		        if (I$utils.$iStrFuzzyMatch(screenId, "OB2KCKSD") && I$utils.$iStrFuzzyMatch(operation, "QUERY")) {
		            isonMsg = viewKycCheckDetails(isonMsg);
		        } else {
		            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
		        }
		    } catch (Exception e) {
		        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
		        e.printStackTrace();
		        return isonMsg;
		    }
		    return isonMsg;
		}
		
		public JsonObject viewKycCheckDetails(JsonObject isonMsg) {
		    JsonObject i$body = i$ResM.getBody(isonMsg);
		    JsonArray db$res = new JsonArray();
		    JsonObject projection = new JsonObject();
		    JsonObject filter = new JsonObject();
		    JsonObject sort = new JsonObject();
		    String CustomerId = null, referenceNo = null;
		    int sort1 = 0;
		    try {
		        CustomerId = i$body.get("CustomerId").getAsString();
		    } catch (Exception e) {
		        CustomerId = "";
		    }
		    try {
		        referenceNo = i$body.get("referenceNo").getAsString();
		    } catch (Exception e) {
		        referenceNo = "";
		    }
		    try {
		        sort = i$body.get("sort").getAsJsonObject();
		    } catch (Exception e) {
		        sort1 = -1;
		    }

		    JsonArray i$ProjectionMap = i$ResM.getProjection(isonMsg);
		    if (i$ProjectionMap != null) {
		        for (int i = 0; i < i$ProjectionMap.size(); i++) {
		            projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
		        }
		    }
		    if (!i$outis.$iStrBlank(CustomerId) && !i$outis.$iStrBlank(referenceNo)) {
		        filter.addProperty("CustomerId", CustomerId);
		        filter.addProperty("referenceNo", referenceNo);
		        sort.addProperty("_id", sort1);
		        JsonObject MemberScan = new JsonObject();
		        JsonObject JointPartner = new JsonObject();
		        JsonObject SpouseNameScan = new JsonObject();
		        JsonObject NomineeScan = new JsonObject();
		        JsonObject ClicoBenScan = new JsonObject();
		        JsonObject CunaBenScan = new JsonObject();
		        db$res = db$Ctrl.db$GetRows$Sort("ICOR_M_SDN_SCAN", filter, projection, sort);
		        i$body.add("MemberScan", MemberScan);
                i$body.add("JointPartner", JointPartner);
                i$body.add("SpouseNameScan", SpouseNameScan);
                i$body.add("NomineeScan", NomineeScan);
                i$body.add("ClicoBenScan", ClicoBenScan);
                i$body.add("CunaBenScan", CunaBenScan);
		        for (int i = 0; i < db$res.size(); i++) {
					try {
						JsonObject db$Obj = db$res.get(i).getAsJsonObject();
						if (db$Obj.has("ScanType") && !i$outis.$iStrBlank(db$Obj.get("ScanType").getAsString())) {	//#MVT00064 Changes starts
							JsonObject fltr = new JsonObject();
							fltr.addProperty("memberId", i$body.get("CustomerId").getAsString());
							JsonObject dbKYCData = db$Ctrl.db$GetRow("ZKYC_" + db$Obj.get("ScanType").getAsString()
									+ "_" + i$body.get("uniqueId").getAsString(), fltr);
							String status = dbKYCData.get("status").getAsString();
							String iRoles = db$Ctrl.getRoles();
							if (I$utils.$iStrFuzzyMatch(status, "REFER_DC")) {
								if (!db$Ctrl.db$hasQuOprRights(IResManipulator.iloggedUser.get(), "IMPACTO_CIF_SDNSCAN_WORKFLOW",
										dbKYCData.get("QueueStage").getAsString(), status,
										iRoles)) {
									i$body.addProperty(db$Obj.get("ScanType").getAsString(), "You Dont have access this application is in queue");
									continue;
								}
							}
							i$body.add(db$Obj.get("ScanType").getAsString(), db$Obj);
						}
					} catch (Exception e) {
					}
		        }//#MVT00064 Changes ends
		        isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);

		    } else {
		        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CustomerId or referenceNo not found");
		        return isonMsg;
		    }
		    isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");
		    return isonMsg;

		}
		
	public IKycCheckViewController() {
		// Constructor
	}
}
//#PKY00068 ends
