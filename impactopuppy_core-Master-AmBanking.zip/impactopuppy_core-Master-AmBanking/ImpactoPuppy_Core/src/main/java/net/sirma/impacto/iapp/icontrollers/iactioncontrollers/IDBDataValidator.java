/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Feb 22, 2019 | #00000001   | Initial writing
      |0.1 Beta    | Vijay  	| Mar 11, 2019 | #BVB00091   | Replaced depreciated Count function with latest version
      |0.1 Beta    | Vijay  	| Mar 11, 2019 | #BVB00092   | Converted Nested Objects to Single Object before Creating match String
      |0.3.17      | Vijay  	| Aug 17, 2019 | #BVB00202   | Adding Pre Validations to handle pre check up conditions for certain records.
      |0.3.17.348  | Syed	  	| Aug 16, 2019 | #MAQ00027   | Removing Temporary record after execution
      |3.2.2.443   | Syed	  	| Jan 13, 2019 | #MAQ00052   | Adding prevalidation query condition
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IDBDataValidator {
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$ImpactoUtil = new ImpactoUtil();
	private Logger logger = LoggerFactory.getLogger(IDBDataValidator.class); // #00000003- Change Class
	private IResManipulator i$ResM = new IResManipulator();

	private String getFormattedMatchStr(JsonObject J$vals, String sMatchStr) {
		try {
			J$vals = i$ImpactoUtil.nestedObjToSinObj(J$vals); // #BVB00092
			Set<Entry<String, JsonElement>> entrySet = J$vals.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = "#IMP~~~X#" + entry.getKey() + "#IMP~~~X#";
				if (sMatchStr.indexOf(strKey) != -1) {
					strVal = J$vals.get(entry.getKey()).getAsString();
					strVal = strVal.replace("\'", "\\\\'");
					sMatchStr = sMatchStr.replaceAll(strKey, strVal);
				}
			}
		} catch (Exception ex) {

		}
		return sMatchStr;
	};

	@SuppressWarnings("null")
	public JsonObject $validateDB_isonAnnote(JsonObject i$Annotate, JsonObject i$body, String ScrID, String SrvOpr) {

		JsonObject JResult = new JsonObject();
		JsonObject JMsgObj = new JsonObject();
		// #MAQ00027 starts
		JsonObject i$filter = new JsonObject();
		JsonObject currImpacatocreatedAt = i$ResM.addDateTime(new Date());
		// #MAQ00027 ends
		
		try {
			JResult.addProperty("i-stat", 1);

			// Going to Post Temp Cache Record
			JsonObject JTmpCache = i$body;
			if (i$Annotate.has("SELFUNQKEY")) { 
				// Adding the Current LoggedIn User ID
				JTmpCache.addProperty("currImpactoLoggedUserId", IResManipulator.iloggedUser.get());
				// Adding the Current LoggedIn User ID
				JTmpCache.addProperty("currImpactosessionID",
						i$ResM.getGobalValJObj("JSessionDets").get("sessionId").getAsString());
				// Created Date
				JTmpCache.add("currImpacatocreatedAt", currImpacatocreatedAt); // #MAQ00027
				String sSelfMatch = getFormattedMatchStr(JTmpCache, i$Annotate.get("SELFUNQKEY").getAsString());
				i$filter = new JsonParser().parse(sSelfMatch).getAsJsonObject(); // #MAQ00027
				db$Ctrl.db$UpdateRow("ICOR_T_REC_CACHE", JTmpCache, i$filter, "true");
			}

			if (i$Annotate.has("VALIDATOR") && i$Annotate.get("VALIDATOR").getAsJsonObject().has("VALDBCONDS")) {
				JsonArray JArrConds = i$Annotate.get("VALIDATOR").getAsJsonObject().get("VALDBCONDS").getAsJsonArray();
				int ErrCnt = 0;
				for (int i = 0; i < JArrConds.size(); i++) {
					boolean preConditionsValid = true; // #BVB00202
					// Getting All Details
					JsonObject jfld = JArrConds.get(i).getAsJsonObject();
					String sCollName = jfld.get("DESTCOLLNAME").getAsString();
					String sMatchFilter = jfld.get("MATCHFLTR").getAsString();
					String sRecCntval = jfld.get("RECCNTVAL").getAsString();
					Integer iRecCnt = jfld.get("RECCNT").getAsInt();
					String sErrMsg = jfld.get("FAILMESSAGE").getAsString();

					// Going to Prepare the Match String
					sMatchFilter = getFormattedMatchStr(JTmpCache, sMatchFilter);
					// #BVB00202 Starts
					if (jfld.has("PREVALIDATIONS")) {
						// #MAQ00052 starts
						String prevalidMode = i$ResM.getStrfromObj(jfld, "PREVALIDATIONSMODE");
						if (I$utils.$iStrFuzzyMatch(prevalidMode, "QUERY")) {
							JsonObject preValObj = jfld.get("PREVALIDATIONS").getAsJsonObject();
							String preCollName = preValObj.get("PREDESTCOLLNAME").getAsString();
							String preMatchFilter = preValObj.get("PREMATCHFLTR").getAsString();
							String preRecCntval = preValObj.get("PRERECCNTVAL").getAsString();
							Integer preRecCnt = preValObj.get("PRERECCNT").getAsInt();
							
							preMatchFilter = getFormattedMatchStr(JTmpCache, preMatchFilter);	
							
							int iRCnt = db$Ctrl.db$GetCountI(preCollName, preMatchFilter);
							
							if (I$utils.$iStrFuzzyMatch(preRecCntval, "=")) {
		                        if (iRCnt == preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, "==")) {
		                        if (iRCnt == preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, ">=")) {
		                        if (iRCnt >= preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, "<=")) {
		                        if (iRCnt <= preRecCnt) {
		                           preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, "<")) {
		                        if (iRCnt < preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, ">")) {
		                        if (iRCnt > preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, "<>")) {
		                        if (iRCnt != preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else if (I$utils.$iStrFuzzyMatch(preRecCntval, "!=")) {
		                        if (iRCnt != preRecCnt) {
		                            preConditionsValid = false;
		                        }
		                    } else {
		                       preConditionsValid = false;
		                    }
						} else {
							// #MAQ00052 ends
							if (!i$ImpactoUtil.verifyObjectConditions(i$body, jfld.getAsJsonObject("PREVALIDATIONS"))) {
								preConditionsValid = false;
							}
						}
					}
					
					if(preConditionsValid) {
                    	// #BVB00202 Ends
                    // Going for the DB Match Calls
                    // int iRCnt = db$Ctrl.db$GetRowCnt(sCollName, sMatchFilter); // #BVB00091 Commented
                    int iRCnt = db$Ctrl.db$GetCountI(sCollName, sMatchFilter); // #BVB00091
                    // Validate the Matches
                    if (I$utils.$iStrFuzzyMatch(sRecCntval, "=")) {
                        if (iRCnt == iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, "==")) {
                        if (iRCnt == iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, ">=")) {
                        if (iRCnt >= iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, "<=")) {
                        if (iRCnt <= iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, "<")) {
                        if (iRCnt < iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, ">")) {
                        if (iRCnt > iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, "<>")) {
                        if (iRCnt != iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else if (I$utils.$iStrFuzzyMatch(sRecCntval, "!=")) {
                        if (iRCnt != iRecCnt) {
                            ++ErrCnt;
                            JResult.addProperty("i-stat", 0);
                            JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                        }
                    } else {
                        ++ErrCnt;
                        JResult.addProperty("i-stat", 0);
                        JMsgObj.addProperty("Error_" + org.apache.commons.lang.StringUtils.leftPad(String.valueOf(ErrCnt), 4, "0"), sErrMsg);
                    }

                }
                } // #BVB00202 
                    

            }
        } catch (Exception e) {
            logger.debug(e.getMessage());
            JResult.addProperty("i-stat", 0);
            JMsgObj.addProperty("Error_9999", "Failed in Validations");
        }
        finally
        {
        	i$body.remove("currImpactoLoggedUserId");
            i$body.remove("currImpactosessionID");
            i$body.remove("currImpacatocreatedAt");
            // #MAQ00027 starts
            i$filter.add("currImpacatocreatedAt", currImpacatocreatedAt);
            db$Ctrl.db$Remove("ICOR_T_REC_CACHE",i$filter);
            // #MAQ00027 ends
        }
        JResult.add("Messages", JMsgObj);
        return JResult;
    }
}
//#00000001 Ends