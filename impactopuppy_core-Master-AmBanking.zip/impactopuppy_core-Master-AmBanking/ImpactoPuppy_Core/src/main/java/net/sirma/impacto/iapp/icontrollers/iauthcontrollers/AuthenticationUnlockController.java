/*
----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
       |0.0.1.4    | Pavithra S | Sep 5, 2023  | #PAV00017   | Added new controller for user validation after sleep screen
*/

//#PAV00017 Changes Begins
package net.sirma.impacto.iapp.icontrollers.iauthcontrollers;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;
import com.nimbusds.jose.JOSEException;

import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IScreeningController;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.BiometricsRegController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IpasscodeController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.AuthenticationUnlockRequest;
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;

@RestController
@RequestMapping("unlockAuth")
public class AuthenticationUnlockController {
	private DBController db$Ctrl = new DBController();
	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private Logger logger = LoggerFactory.getLogger(AuthenticationUnlockController.class);
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IpasscodeController i$Pass = new IpasscodeController();
	private IAppMessageHandler I$AppMessageHandler = new IAppMessageHandler(); 
	private BiometricsRegController i$bioVer = new BiometricsRegController(); 
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@SuppressWarnings({ "unused", "rawtypes" })
	@RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.POST)
	public ResponseWrapper authenticationRequest(
			@Valid @RequestBody AuthenticationUnlockRequest authenticationUnlockRequest, HttpServletRequest request)
			throws AuthenticationException, IOException, JOSEException {
		LinkedTreeMap ison$Map = null;
		JsonObject isonReq = new JsonObject();
		try {
			IScreeningController I$ScrnCntr = new IScreeningController();
			SentryGuardController I$SntryCntr = new SentryGuardController();
			logger.info("WelCome to IMPACTO");
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonParser parser = new JsonParser();
			String decoReq = gson.toJson(authenticationUnlockRequest);
			ResponseWrapper jResponseWrapper = null;
			Boolean blckChar = I$ScrnCntr.i$NonEncChars(decoReq);
			decoReq = decoReq.replaceAll("\\+", "%2B");
			decoReq = URLDecoder.decode((decoReq), "UTF-8");
			authenticationUnlockRequest = gson.fromJson(decoReq, AuthenticationUnlockRequest.class);
			String sessionID = "";
			JsonObject isonBody = new JsonObject();
			JsonObject filter = new JsonObject();
			try {
				JsonParser parserM = new JsonParser();
				sessionID = i$impactoUtil.passwordDecrypt(authenticationUnlockRequest.getSessionID());
				JsonObject setter = new JsonObject();
				setter.addProperty("sessionId", sessionID);
				try {
					i$ResM.setGobalVals("sessionId", sessionID);
					i$ResM.setGobalVals("JSessionDets",
							db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", setter).getAsJsonObject());
					try {
						i$ResM.setGobalVals("deCryptKey",
								i$ResM.getGobalValJObj("JSessionDets").get("privateKey").getAsString());
					} catch (Exception e) {
						i$ResM.setGobalVals("deCryptKey",
								i$ResM.getGobalValJObj("JSessionDets").get("sessionKeyVal").getAsString());
					}
				} catch (Exception e) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message(
							i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "UNKNOWN SESSION")));
					return new ResponseWrapper(isonMap, HttpStatus.UNAUTHORIZED, null);
				}
				String username = i$impactoUtil.decryptPkey(authenticationUnlockRequest.getUsername());
				String password = i$impactoUtil.decryptPkey(authenticationUnlockRequest.getPassword());
				if (blckChar) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(isonBody, i$ResM.I_ERR, "INVALID REQUEST"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("JSessionDets").get("userId").getAsString(),
						username)) {
					JsonObject J$userdet = db$Ctrl.db$GetRow("ICOR_M_USER_PRF",
							"{\"userId\":\"" + username + "\",\"active\":\"A\",\"authStat\":\"A\"}");
					if (!I$utils.$isNull(J$userdet)) {
						String userPassDecrypt = password;
						userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt,
								J$userdet.get("salt").getAsString());
						if (I$utils.$iStrFuzzyMatch(userPassDecrypt, J$userdet.get("userPwd").getAsString())) {
							Authentication authentication = this.authenticationManager
									.authenticate(new UsernamePasswordAuthenticationToken(username, userPassDecrypt));
							SecurityContextHolder.getContext().setAuthentication(authentication);
							logger.debug("authenticated" + authentication.isAuthenticated());
							ison$Map = i$ResM.getisonMap(I$AppMessageHandler
									.get$Message(i$ResM.iHandleResStat(isonReq, i$ResM.I_SUCC, "AUTHENTICATED")));
							filter = new JsonObject();
							filter.addProperty("sessionId", sessionID);
							filter.addProperty("userId", username);
							setter.add("lastActivityAt", i$ResM.addDateTime(new Date()));
							db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", setter, filter);
							return new ResponseWrapper(ison$Map, HttpStatus.OK, null);
						} else {
							ison$Map = i$ResM.getisonMap(I$AppMessageHandler.get$Message(
									i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "AUTHENTICATION FAILED")));
							return new ResponseWrapper(ison$Map, HttpStatus.UNAUTHORIZED, null);
						}
					} else {
						ison$Map = i$ResM.getisonMap(I$AppMessageHandler
								.get$Message(i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "AUTHENTICATION FAILED")));
						return new ResponseWrapper(ison$Map, HttpStatus.UNAUTHORIZED, null);
					}
				}else {
					ison$Map = i$ResM.getisonMap(I$AppMessageHandler
							.get$Message(i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "AUTHENTICATION FAILED")));
					return new ResponseWrapper(ison$Map, HttpStatus.UNAUTHORIZED, null);
				}
			} catch (Exception e) {
				e.printStackTrace();
				ison$Map = i$ResM.getisonMap(i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "AUTHENTICATION FAILED"));
				return new ResponseWrapper(ison$Map, HttpStatus.UNAUTHORIZED, null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			ison$Map = i$ResM.getisonMap(i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "AUTHENTICATION FAILED"));
			return new ResponseWrapper(ison$Map, HttpStatus.UNAUTHORIZED, null);
		}
	}

}//#PAV00017 Changes Ends
