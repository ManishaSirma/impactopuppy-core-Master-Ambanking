/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Oct 8, 2018  | #BVB00005   | Adding Validations for JSON Array and Objects 
      |0.1 Beta    | Vijay 		| Oct 8, 2018  | #BVB00007   | Created separate functions for Datatype validations
      |0.1 Beta    | Vijay 		| Nov 2, 2018  | #BUG00001   | Single Value array is getting considered as String.
      |0.2.1       | Vijay 		| Jan 19, 2018 | #BVB00040   | Added MINFIELDLEN for validating String minimul Length
      |0.2.1       | Vijay 		| Jan 19, 2018 | #BVB00040   | Added MINFIELDLEN for validating String minimul Length
      |0.2.1       | Niegil 	| Feb 16, 2019 | #NYE00021   | Static Variable Issue
      |0.2.1       | Bhuvi 		| Feb 16, 2019 | #BHV00021   | Static Variable Issue
      |0.2.1       | Vijay 		| Feb 23, 2019 | #BVB00071   | Error Msg getting suppressed
      |0.3.12.272  | Syed 		| May 31, 2019 | #MAQ000016  | BYPASS condition added inside an Object 
      |0.3.17      | Vijay		| Aug 05, 2019 | #BVB00192   | MinVal and MaxVal Validation issue 
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.sirma.impacto.iapp.iconfig.PropLoader;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IDataValidator {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	// **********************************************************************//

	public static ThreadLocal<JsonObject> i$AnnotRes = ThreadLocal.<JsonObject>withInitial(() -> {
		return new JsonObject();
	}); // #NYE00021

	// for local temporary storage////////////

	public static ThreadLocal<JsonObject> J$TempStorage = ThreadLocal.<JsonObject>withInitial(() -> {
		return new JsonObject();
	}); // #BHV00021

	@SuppressWarnings("null")
	public void $validate_isonAnnote(JsonObject i$Annotate, JsonObject i$body, String ScrID, String SrvOpr) {
		JsonArray i$AnnoteFlds = null;
		String i$Msg = "";
		try {
			i$AnnoteFlds = i$Annotate.getAsJsonArray("FIELDS");
		} catch (Exception e) {
			i$AnnoteFlds = null;
			i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
			i$AnnotRes.get().addProperty("i-Msg", "INVALID OR UNKNOWN ANNOTATE"); // Nye Changes
		}
		;
		String iAnnotbyPass;
		try {
			iAnnotbyPass = i$Annotate.get("BYPASS").getAsString();
		} catch (Exception e) {
			iAnnotbyPass = "N";
		}
		;
		if (!I$utils.$iStrFuzzyMatch(iAnnotbyPass, "Y")) {
			if (i$AnnoteFlds == null || i$AnnoteFlds.size() < 1) {
				i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
				i$AnnotRes.get().addProperty("i-Msg", "INVALID OR UNKNOWN METHOD FIELDS ANNOTATE");// #NYE00021
				return;
			}
			;
		} else {
			i$AnnotRes.get().addProperty("i-stat", "1"); // #NYE00021
			i$AnnotRes.get().addProperty("i-Msg", "BYPASSED AT CONFIG LEVEL");// #NYE00021
			return;
		}
		;

		// Populating Required List
		Collection<String> requiredFlds = new ArrayList<String>();

		for (int i = 0; i < i$AnnoteFlds.size(); i++) {
			JsonObject jfld = i$AnnoteFlds.get(i).getAsJsonObject();
			// Adding Mandatory List
			try {
				if ((I$utils.$iStrFuzzyMatch(jfld.get("REQUIRED").getAsString(), "1"))
						&& (requiredFlds == null || !requiredFlds.contains(jfld.get("FIELDNAME").getAsString()))) {
					requiredFlds.add(jfld.get("FIELDNAME").getAsString());
				}
			} catch (Exception e) {
				// Eat Up
			}

		}
		;

		// Field Wise Validation
		// Going for Field Validation - 1st Loop Body Validation

		Map<String, Object> attributes = new HashMap<String, Object>();
		Set<Entry<String, JsonElement>> entrySet = i$body.entrySet();
		for (Map.Entry<String, JsonElement> entry : entrySet) {
			try {
				// #BUG00001 Starts
				if (i$body.get(entry.getKey()).isJsonArray()) {
					attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonArray());
				} else if (i$body.get(entry.getKey()).isJsonObject()) {
					attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonObject());
				} else {
					attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsString());
				}

				// attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsString());
				// #BUG00001 Ends
				// #BVB00005 Starts
			} catch (IllegalStateException e) {
				// Checking if the data is Array.
				try {
					attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonArray());
				} catch (Exception ex) {
					// Eat Up
				}
			} catch (UnsupportedOperationException uex) {
				// Checking if the data is dataObject
				try {
					attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonArray());
				} catch (Exception ex) {
					try {
						attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonObject());
					} catch (Exception e) {
						// Eat Up
					}
				}

			}
			// #BVB00005 Ends
		}
		;

		for (Map.Entry<String, Object> att : attributes.entrySet()) {// Body Loop 
			String CurrField = att.getKey();
			String CurrVal = att.getValue().toString();

			// Check if Mandatory Field Name is Known
			boolean foundFld = false;

			if (requiredFlds != null && requiredFlds.contains(CurrField))
				requiredFlds.remove(CurrField);
			for (int i = 0; i < i$AnnoteFlds.size(); i++) {
				JsonObject jfld = i$AnnoteFlds.get(i).getAsJsonObject();// Field Object loop

				if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDNAME").getAsString(), CurrField)) {
					foundFld = true;// Field Found

					// Validate Data Type
					if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Integer")) {
						i$Msg = $integerValidation(jfld, CurrField, CurrVal);

					} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Date")) {

						i$Msg = $dateValidation(jfld, CurrField, CurrVal);

					} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Double")) {

						i$Msg = $doubleValidation(jfld, CurrField, CurrVal);

					} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Float")) {
						i$Msg = $floatValidation(jfld, CurrField, CurrVal);

					} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "String")) {

						i$Msg = $stringValidation(jfld, CurrField, CurrVal);

					}
					// #BVB00005 Starts
					else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Array")) {
						JsonArray currVal = i$ResM.str2JsonA(CurrVal);

						try {
							main: {
								if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "STRING")) {

									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $stringValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(),
										"INTEGER")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $integerValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
											break main;
										}
									}

								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "DOUBLE")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $doubleValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "FLOAT")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $floatValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "DATE")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $dateValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "OBJECT")) {
									i$Msg = $objectValidation(jfld, CurrField, CurrVal);
									if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
										break main;
									}
								}
							}
						} catch (Exception e) {
							i$Msg = "INVALID VALUES FOR FIELD " + CurrField;
						}

					}

					else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "BOOLEAN")) {

						i$Msg = $booleanValidation(jfld, CurrField, CurrVal);

					} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "OBJECT")) {

						i$Msg = $objectValidation(jfld, CurrField, CurrVal);
					}

					break;
				}
			}
			;
			// #BVB00005 Ends
			// Field it Self is not Found
			if (!foundFld) {
				i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
				i$AnnotRes.get().addProperty("i-Msg", "INVALID OR UNKNOWN METHOD FIELD " + CurrField);// #NYE00021
				return;
			}
			;
			// #BVB00071 Starts 
			if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
				i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
				i$AnnotRes.get().addProperty("i-Msg", i$Msg);
				return;
			}
			// #BVB00071 ends
		}
		if (requiredFlds.size() > 0) {
			i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
			i$AnnotRes.get().addProperty("i-Msg", "MISSING MANDATORY FIELDS");// Details Not Shared on
																				// Purpose//#NYE00021
			return;
		}

		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$AnnotRes.get().addProperty("i-stat", "1"); // #NYE00021
			i$AnnotRes.get().addProperty("i-Msg", "ALL GOOD");// #NYE00021
		} else {
			i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
			i$AnnotRes.get().addProperty("i-Msg", i$Msg);// #NYE00021
		}

		return;

	};

	// #BVB00007 Starts

	public JsonObject $validate_isonAnnote_custom(JsonObject i$Annotate, JsonObject i$body, String ScrID,
			String SrvOpr) {
		JsonObject i$res = new JsonObject();
		String i$Msg = "";
		JsonArray i$AnnoteFlds = null;
		boolean foundFld = false;
		main: {
			try {
				i$AnnoteFlds = i$Annotate.getAsJsonArray("FIELDS");
			} catch (Exception e) {
				i$AnnoteFlds = null;
			}
			;
			String iAnnotbyPass;
			try {
				iAnnotbyPass = i$Annotate.get("BYPASS").getAsString();
			} catch (Exception e) {
				iAnnotbyPass = "N";
			}
			;
			if (!I$utils.$iStrFuzzyMatch(iAnnotbyPass, "Y")) {
				if (i$AnnoteFlds == null || i$AnnoteFlds.size() < 1) {
					i$Msg = "INVALID OR UNKNOWN METHOD FIELDS ANNOTATE";
					break main;
				}
				;
			} else {
				i$Msg = "BYPASSED AT CONFIG LEVEL";
				break main;
			}
			;

			// Populating Required List
			Collection<String> requiredFlds = new ArrayList<String>();

			for (int i = 0; i < i$AnnoteFlds.size(); i++) {
				JsonObject jfld = i$AnnoteFlds.get(i).getAsJsonObject();
				// Adding Mandatory List
				try {
					if ((I$utils.$iStrFuzzyMatch(jfld.get("REQUIRED").getAsString(), "1"))
							&& (requiredFlds == null || !requiredFlds.contains(jfld.get("FIELDNAME").getAsString()))) {
						requiredFlds.add(jfld.get("FIELDNAME").getAsString());
					}
				} catch (Exception e) {
					// Eat Up
				}

			}
			;

			// Field Wise Validation
			// Going for Field Validation - 1st Loop Body Validation

			Map<String, Object> attributes = new HashMap<String, Object>();
			Set<Entry<String, JsonElement>> entrySet = i$body.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				try {
					attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsString());
					// #BVB00005 Starts
				} catch (IllegalStateException e) {
					// Checking if the data is Array.
					try {
						attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonArray());
					} catch (Exception ex) {
						// Eat Up
					}
				} catch (UnsupportedOperationException uex) {
					// Checking if the data is dataObject
					try {
						attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonArray());
					} catch (Exception ex) {
						try {
							attributes.put(entry.getKey(), i$body.get(entry.getKey()).getAsJsonObject());
						} catch (Exception e) {
							// Eat Up
						}
					}

				}
				// #BVB00005 Ends
			}

			for (Map.Entry<String, Object> att : attributes.entrySet()) {// Body Loop 
				String CurrField = att.getKey();
				String CurrVal = att.getValue().toString();
				// Check if Mandatory Field Name is Known

				if (requiredFlds != null && requiredFlds.contains(CurrField))
					requiredFlds.remove(CurrField);
				for (int i = 0; i < i$AnnoteFlds.size(); i++) {
					JsonObject jfld = i$AnnoteFlds.get(i).getAsJsonObject();// Field Object loop

					if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDNAME").getAsString(), CurrField)) {
						foundFld = true;// Field Found

						// Validate Data Type
						if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Integer")) {
							i$Msg = $integerValidation(jfld, CurrField, CurrVal);

						} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Date")) {

							i$Msg = $dateValidation(jfld, CurrField, CurrVal);

						} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Double")) {

							i$Msg = $doubleValidation(jfld, CurrField, CurrVal);

						} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Float")) {
							i$Msg = $floatValidation(jfld, CurrField, CurrVal);

						} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "String")) {

							i$Msg = $stringValidation(jfld, CurrField, CurrVal);

						}
						// #BVB00005 Starts
						else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "Array")) {
							JsonArray currVal = i$ResM.str2JsonA(CurrVal);

							try {

								if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "STRING")) {

									for (int j = 0; j < currVal.size(); j++) {
									
										i$Msg = $stringValidation(jfld, CurrField, currVal.get(j).getAsString());
										
												
										if (I$utils.$iStrFuzzyMatch(i$res.get("i-stat").getAsString(), "0")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(),
										"INTEGER")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $integerValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (I$utils.$iStrFuzzyMatch(i$res.get("i-stat").getAsString(), "0")) {
											break main;
										}
									}

								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "DOUBLE")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $doubleValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (I$utils.$iStrFuzzyMatch(i$res.get("i-stat").getAsString(), "0")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "FLOAT")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $floatValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (I$utils.$iStrFuzzyMatch(i$res.get("i-stat").getAsString(), "0")) {
											break main;
										}
									}
								} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDDATATYPE").getAsString(), "DATE")) {
									for (int j = 0; j < currVal.size(); j++) {
										i$Msg = $dateValidation(jfld, CurrField, currVal.get(j).getAsString());
										if (I$utils.$iStrFuzzyMatch(i$res.get("i-stat").getAsString(), "0")) {
											break main;
										}
									}
								}

							} catch (Exception e) {
								i$Msg = "INVALID VALUES FOR FIELD " + CurrField;
							}

						}

						else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "BOOLEAN")) {

							i$Msg = $booleanValidation(jfld, CurrField, CurrVal);

						} else if (I$utils.$iStrFuzzyMatch(jfld.get("FIELDTYPE").getAsString(), "OBJECT")) {

							i$Msg = $objectValidation(jfld, CurrField, CurrVal);
						}

						break;
					}
				}
				;

				// #BVB00005 Ends
				// Field it Self is not Found
				if (!foundFld) {
					i$Msg = "INVALID OR UNKNOWN METHOD FIELD " + CurrField;
					break main;
				};
				// #BVB00071 Starts 
				if (!I$utils.$iStrFuzzyMatch(i$Msg, "")) {
					i$AnnotRes.get().addProperty("i-stat", "0");// #NYE00021
					i$AnnotRes.get().addProperty("i-Msg", i$Msg);
					break main;
				}
				// #BVB00071 ends
			}

			if (requiredFlds.size() > 0) {
				i$Msg = "MISSING MANDATORY FIELDS";// Details Not Shared on Purpose
				break main;
			}

		}

		if (I$utils.$iStrFuzzyMatch(i$Msg, "")) {
			i$res.addProperty("i-stat", "1");
			i$res.addProperty("i-Msg", "ALL GOOD");
		} else {
			i$res.addProperty("i-stat", "0");
			i$res.addProperty("i-Msg", i$Msg);
		}

		return i$res;

	};

	public String $integerValidation(JsonObject jfld, String CurrField, String CurrVal) {
		String i$Msg = "";
		try {
			Integer.valueOf(CurrVal);
			// Going for Range Validations
			main: {
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MINVAL").getAsString(), "@")) {
					if (jfld.get("MINVAL").getAsInt() > Integer.valueOf(CurrVal)) { // #BVB00192
						i$Msg = "INVALID LOWER RANGE FOR " + CurrField;
						break main;
					}
				}
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MAXVAL").getAsString(), "@")) {
					if (jfld.get("MAXVAL").getAsInt() < Integer.valueOf(CurrVal)) { // #BVB00192
						i$Msg = "INVALID UPPER RANGE FOR " + CurrField;
						break main;
					}
				}
				// Going for ENUM Type validation
				try {
					if (I$utils.$iStrFuzzyMatch(jfld.get("ENNUMFLD").getAsString(), "1")) {
						try {
							if (!I$utils.$iStrFuzzyMatch(
									jfld.get("ENNUMVAL").getAsJsonObject().get(CurrVal).getAsString(), "1")) {

								i$Msg = "INVALID ENNUM VALUE FOR " + CurrField;
								break main;
							}
						} catch (Exception e) {
							i$Msg = "INVALID ENNUM VALUE FOR " + CurrField;
							break main;
							//
						}

					}
				} catch (Exception e) {
					//
				}

				// #BVB00040 Starts
				try {
					if (i$impactoUtil.matchRegEx(CurrVal, jfld.get("PATTERN").getAsString())) {
						i$Msg = "INVALID FIELD VALUE FOR " + CurrField;
					}
				} catch (Exception e) {
					// Eat Up
				}
				// #BVB00040 Ends
			}
		} catch (Exception e) {
			i$Msg = "INVALID DATA TYPE INTEGER FOR " + CurrField;
		}

		return i$Msg;
	}

	public String $dateValidation(JsonObject jfld, String CurrField, String CurrVal) {
		String i$Msg = "";
		try {
			Date date1 = new SimpleDateFormat(
					I$utils.$strValNullIf(PropLoader.env.getProperty("impacto.date.format"), "dd/MM/yyyy"))
							.parse(CurrVal);

		} catch (Exception e) {
			i$Msg = "INVALID FORMAT OR DATATYPE DATE FOR " + CurrField;
		}

		return i$Msg;
	}

	public String $doubleValidation(JsonObject jfld, String CurrField, String CurrVal) {
		String i$Msg = "";

		try {
			Double.valueOf(CurrVal);
			// Going for Range Validations
			main: {
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MINVAL").getAsString(), "@")) {
					if (jfld.get("MINVAL").getAsDouble() > Double.valueOf(CurrVal)) {
						i$Msg = "INVALID LOWER RANGE FOR " + CurrField;
						break main;
					}
				}
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MAXVAL").getAsString(), "@")) {
					if (jfld.get("MAXVAL").getAsDouble() < Double.valueOf(CurrVal)) { // #BVB00192
						i$Msg = "INVALID UPPER RANGE FOR " + CurrField;
						break main;
					}
				}
				if (!I$utils.$iStrFuzzyMatch(jfld.get("DECIPLACE").getAsString(), "@")) {
					String strTmp = Double.toString(Math.abs(Double.valueOf(CurrVal)));
					int integerPlaces = strTmp.indexOf('.');
					int decimalPlaces = strTmp.length() - integerPlaces - 1;
					if (decimalPlaces > jfld.get("DECIPLACE").getAsInt()) {
						i$Msg = "INVALID PERCISION FOR " + CurrField;
						break main;
					}
				}
				// Going for ENUM Type validation
				try {
					if (!I$utils.$iStrFuzzyMatch(jfld.get("ENNUMFLD").getAsString(), "1")) {
						try {
							if (!I$utils.$iStrFuzzyMatch(
									jfld.get("ENNUMVAL").getAsJsonObject().get(CurrVal).getAsString(), "1")) {
								i$Msg = "INVALID ENNUM VALUE FOR " + CurrField;
								break main;
							}
						} catch (Exception e) {
							i$Msg = "INVALID ENNUM VALUE FOR " + CurrField;
							break main;
							//
						}

					}
				} catch (Exception e) {
					//
				}

				// #BVB00040 Starts
				try {
					if (i$impactoUtil.matchRegEx(CurrVal, jfld.get("PATTERN").getAsString())) {
						i$Msg = "INVALID FIELD VALUE FOR " + CurrField;
					}
				} catch (Exception e) {
					// Eat Up
				}
				// #BVB00040 Ends
			}
		} catch (Exception e) {
			i$Msg = "INVALID DATATYPE DOUBLE FOR " + CurrField;

		}

		return i$Msg;
	}

	public String $floatValidation(JsonObject jfld, String CurrField, String CurrVal) {
		String i$Msg = "";

		try {
			Float.valueOf(CurrVal);
			// Going for Range Validations
			main: {
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MINVAL").getAsString(), "@")) {
					if (jfld.get("MINVAL").getAsFloat() > Float.valueOf(CurrVal)) { // #BVB00192
						i$Msg = "INVALID LOWER RANGE FOR " + CurrField;
						break main;
					}
				}
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MAXVAL").getAsString(), "@")) {
					if (jfld.get("MAXVAL").getAsFloat() < Float.valueOf(CurrVal)) { // #BVB00192 
						i$Msg = "INVALID UPPER RANGE FOR " + CurrField;
						break main;
					}
				}
				if (!I$utils.$iStrFuzzyMatch(jfld.get("DECIPLACE").getAsString(), "@")) {
					String strTmp = Double.toString(Math.abs(Float.valueOf(CurrVal)));
					int integerPlaces = strTmp.indexOf('.');
					int decimalPlaces = strTmp.length() - integerPlaces - 1;
					if (decimalPlaces > jfld.get("DECIPLACE").getAsInt()) {
						i$Msg = "INVALID PERCISION FOR " + CurrField;
						break main;
					}
				}
				// Going for ENUM Type validation
				try {
					if (!I$utils.$iStrFuzzyMatch(jfld.get("ENNUMFLD").getAsString(), "1")) {
						try {
							if (!I$utils.$iStrFuzzyMatch(
									jfld.get("ENNUMVAL").getAsJsonObject().get(CurrVal).getAsString(), "1")) {
								i$Msg = "INVALID ENNUM VALUE FOR " + CurrField;
								break main;
							}
						} catch (Exception e) {
							i$Msg = "INVALID ENNUM VALUE FOR " + CurrField;
							break main;
							//
						}

					}
				} catch (Exception e) {
					//
				}

				// #BVB00040 Starts
				try {
					if (i$impactoUtil.matchRegEx(CurrVal, jfld.get("PATTERN").getAsString())) {
						i$Msg = "INVALID FIELD VALUE FOR " + CurrField;
					}
				} catch (Exception e) {
					// Eat Up
				}
				// #BVB00040 Ends
			}
		} catch (Exception e) {
			i$Msg = "INVALID DATATYPE FLOAT FOR " + CurrField;

		}

		return i$Msg;
	}

	public String $stringValidation(JsonObject jfld, String CurrField, String CurrVal) {
		String i$Msg = "";

		try {
			String.valueOf(CurrVal);
			if (!I$utils.$iStrFuzzyMatch(jfld.get("FIELDLEN").getAsString(), "@")) {
				if (CurrVal.length() > jfld.get("FIELDLEN").getAsInt()) {
					i$Msg = "INVALID LENGTH FOR " + CurrField;

				}
			}
			// #BVB00040 Starts
			try {
				if (!I$utils.$iStrFuzzyMatch(jfld.get("MINFIELDLEN").getAsString(), "@")) {
					if (CurrVal.length() < jfld.get("MINFIELDLEN").getAsInt()) {
						i$Msg = "INVALID LENGTH FOR " + CurrField;
					}
				}
			} catch (Exception e) {
				// Eat Up as the field is not available
			}
			// #BVB00040 Ends
			// #BVB00040 Starts
			try {
				if (i$impactoUtil.matchRegEx(CurrVal, jfld.get("PATTERN").getAsString())) {
					i$Msg = "INVALID FIELD VALUE FOR " + CurrField;
				}
			} catch (Exception e) {
				// Eat Up
			}
			// #BVB00040 Ends
		} catch (Exception e) {
			i$Msg = "INVALID DATATYPE STRING FOR " + CurrField;

		}

		return i$Msg;
	}

	public String $booleanValidation(JsonObject jfld, String CurrField, String CurrVal) {
		String i$Msg = "";

 		try {
			Boolean.valueOf(CurrVal);
		} catch (Exception e) {
			i$Msg = "INVALID BOOLEAN VALUE FOR " + CurrField;
		}

		return i$Msg;
	}

	public String $objectValidation(JsonObject jfld, String CurrField, String CurrVal) {
		JsonObject i$res = new JsonObject();
		String i$Msg = "";
		try {
			JsonObject currVal = i$ResM.str2Json(CurrVal);
			// #MAQ000016 starts
			if(jfld.has("BYPASS")) {
				if(I$utils.$iStrFuzzyMatch(jfld.get("BYPASS").getAsString(),"Y"))
					return i$Msg;
			}
			// #MAQ000016 ends
			i$res = $validate_isonAnnote_custom(jfld, currVal, "", "");

			if (i$res.get("i-stat").getAsInt() == 0) {
				i$Msg = i$res.get("i-Msg").getAsString();
			}

		} catch (Exception e) {
			i$Msg = "INVALID OBJECT VALUE FOR" + CurrField;
		}
		return i$Msg;
	}
	// #BVB00007 Ends

	public IDataValidator() {
		// Const
	}
}
// #00000001 Ends
