/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | #00000003 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Sep 27, 2018 | #BVB00002   | Encryption and Decryption
      |0.1.6       | Vijay 		| Dec 14, 2018 | #BVB00031   | Issue while deploying in some systems 
      |0.1.6       | Syed, RK	| Dec 18, 2018 | #MAQ00001   | Adding Desc field operation. 
      |0.2.1       | Vijay 		| Jan 09, 2019 | #BVB00035   | Encryption Decryption based on Maintenance 
      |0.1.10      | Syed 		| Jan 03, 2018 | #MAQ00002   | Improved code for looping of createArrayS
      |0.2.1       | Vijay 		| Jan 16, 2019 | #BVB00036   | Encryption and Decryption with RSA
      |0.2.1       | Niegil 	| Jan 16, 2019 | #00000003   | Added Generate Random Unique Numbers
      |0.2.1       | bhuvi      | Jan 15, 2019 | #BHU00001   | Added Generate Random Unique with current time
      |0.2.1       | bhuvi      | Jan 15, 2019 | #BHU00002   | Added Generate Random Alphanumeric string with special character
      |0.2.1       | Niegil 	| Jan 16, 2019 | #NYE00001   | Decryption/Encrypttion function overloaded
      |0.2.1       | Vijay 		| Feb 01, 2019 | #BVB00047   | Ambassador banking Login Rights
      |0.2.1       | Vijay 		| Feb 01, 2019 | #BVB00048   | Regex matcher for validation 
      |0.2.1       | Vijay 		| Feb 07, 2019 | #BVB00051   | Soundex Implementation, Fuzzy Search 
      |0.2.1       | Vijay 		| Feb 08, 2019 | #BVB00052   | Model Evaluation Functions 
      |0.2.1       | Vijay 		| Feb 08, 2019 | #BVB00066   | Bug 93. '$' coming in the password having issue.
      |0.2.1       | Vijay 		| Feb 08, 2019 | #BVB00075   | Formatted Template Function
      |0.2.1       | Hasan 		| MAR 07, 2019 | #HAS00001   | Added code for getting sdn filetype. 
      |0.2.1       | Vijay  	| Mar 11, 2019 | #BVB00092   | Nested Objects to Single Object
      |0.2.1       | Vijay  	| Mar 17, 2019 | #BVB00100   | Fuzzy Wuzzy, sortJsonArray, notInArray, getObjectOfArray Implementation
      |0.2.1       | Vijay  	| Mar 23, 2019 | #BVB00101   | Time Zone validation
      |0.2.1       | Niegil  	| Mar 25, 2019 | #NYE00010   | Lpad function rewritten
      |0.3.6       | Vijay  	| Apr 24, 2019 | #BVB00128   | Adding Refining Object function -- All Keys from child whose values are in parent will be returned
      |0.3.7       | Vijay  	| May 04, 2019 | #BVB00139   | Refining the Function Access to return a combined response 
      |0.3.7       | Vijay  	| May 04, 2019 | #BVB00141   | Functions for Macros creation and Execution
      |0.3.8       | Vijay  	| May 14, 2019 | #BVB00152   | SDN new Logical Flow
      |0.3.14.283  | Syed 		| Jun 11, 2019 | #MAQ00018   | Password History
      |0.3.14.285  | Syed 		| Jun 11, 2019 | #MAQ00019   | Password Policy
      |0.3.15      | Vijay  	| Jun 17, 2019 | #BVB00168   | HTML File Upload Changes
      |0.3.16      | Vijay  	| Jul 06, 2019 | #BVB00177   | Flatter the JsonOBject
      |0.3.16      | Vijay  	| Jul 10, 2019 | #BVB00181   | Trim Date function for Bridge date format
      |0.3.17      | Vijay  	| Jul 25, 2019 | #BVB00189   | Generic Function for Checking mandatory Fields 
      |0.3.16.327  | Bhuvi  	| Jul 26, 2019 | #BHUVI002   | Added default data for i-match in datasetfilter
	  |0.3.17      | Vijay   	| Aug 07, 2019 | #BVB00193   | Replace All Function
      |0.3.17      | Vijay   	| Aug 13, 2019 | #BVB00197   | Date Formatter Function
      |0.3.17      | Vijay   	| Aug 17, 2019 | #BVB00202   | Verify conditions on First object with second object 
      |0.3.17      | Vijay   	| Aug 21, 2019 | #BVB00203   | Encoding of XML Function
      |0.5.0       | Vijay   	| Sep 05, 2019 | #BVB00208   | Adding feature to validate the Object inside an array
      |3.1.7       | Vijay   	| Jan 02, 2020 | #BVB00216   | Making the '&' to Impacto format for later replacement. 
      |3.1.7       | Pappu      | Jul 23, 2021 | #PKY00026   | Added condition Is Not Equal To and Not In for dataSetFilter
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iutils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.Map.Entry;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.enterprise.context.spi.Context;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.language.Soundex;
import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.github.junrar.Archive;
import com.github.junrar.exception.RarException;
import com.github.junrar.impl.FileVolumeManager;
import com.github.junrar.rarfile.FileHeader;
import com.github.underscore.lodash.U;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nimbusds.jwt.SignedJWT;

import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import okhttp3.Response;

import net.sirma.fuzzy.fuzzywuzzy.FuzzySearch;
import net.sirma.impacto.iapp.ialgo.RSAAsymetricCrypt;
import net.sirma.impacto.iapp.ialgo.RSAKeyGeneration;
import net.sirma.impacto.iapp.ialgo.iDCryptor;
import net.sirma.impacto.iapp.iconfig.PropLoader;

@PropertySource("classpath:application.properties")
public class ImpactoUtil {

	private final static String ROLES_CLAIM = "roles";
	private static final String key = "aesEncryptionKey";
	private static final String initVector = "encryptionIntVec";

	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private static final Logger logger = LoggerFactory.getLogger(ImpactoUtil.class);

	private RSAAsymetricCrypt I$Crypt = new RSAAsymetricCrypt();

	// #BVB00031 Starts
	// private static final String keyDe = PropLoader.env.getProperty("ilockkey");
	private final String keyDe = PropLoader.env.getProperty("ilockkey");
	// #BVB00031 Ends

	// Valla Starts
	private static Random RANDOM = new SecureRandom();
	private static String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	private static int ITERATIONS = 10000;
	private static int KEY_LENGTH = 256;
	private static SimpleDateFormat dateFormat = null;
	// Valla Ends

	private iDCryptor iDCryptor = new iDCryptor(128, 1000);
	private IResManipulator i$ResM = new IResManipulator();
	private RSAAsymetricCrypt rsaAsymCrypt = new RSAAsymetricCrypt();

	public static String getUsername(SignedJWT jwt) throws ParseException {
		return jwt.getJWTClaimsSet().getSubject();
	}

	private Ioutils I$utils = new Ioutils();

	public String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());

			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	// #00000003 Begins
	public String generateRandomKey() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			// SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
			Date now = new Date();
			String strDate = sdf.format(now);
			UUID uuid = UUID.randomUUID();
			String sGenKey = String.valueOf(uuid) + strDate.replaceAll("\\s", "");
			return sGenKey;
		} catch (Exception e) {
			return null;
		}
	};

	public String generateRandomKey(int iLength) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			Date now = new Date();
			String strDate = sdf.format(now);
			UUID uuid = UUID.randomUUID();
			String sGenKey = strDate.replaceAll("\\s", "") + String.valueOf(uuid);
			while (iLength > sGenKey.length()) {
				sGenKey = sGenKey + sdf.format(now);
			}
			;
			sGenKey.substring(0, iLength - 1);
			return sGenKey;
		} catch (Exception e) {
			return null;
		}
	};

	// #00000003 Ends
	public String generateVerificationCode(int MIN_VERIFICATION_CODE, int MAX_VERIFICATION_CODE) {
		Random rand = new Random();
		Integer code = rand.nextInt(MIN_VERIFICATION_CODE - MAX_VERIFICATION_CODE + 1) + MAX_VERIFICATION_CODE;
		// Sce_key= code.toString();
		return code.toString();
	}

	public long generateRandomLong(int length) {
		Random random = new Random();
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}
		return Long.parseLong(new String(digits));
	}

	public int generateRandom(int min, int max) {
		Random generator = new Random();
		int roll = generator.nextInt(max) + min;
		// int num = generator.nextInt(99999) + 99999;
		if (roll < 100005 || roll > 999999) {
			roll = generator.nextInt(99999) + 99999;
		}
		return roll;
	}

	public int generatePin() throws Exception {
		Random generator = new Random();
		generator.setSeed(System.currentTimeMillis());

		int num = generator.nextInt(99999) + 99999;
		if (num < 100000 || num > 999999) {
			num = generator.nextInt(99999) + 99999;
		}
		return num;
	}

	public String getUserId(HttpServletRequest request) throws ParseException {
		String token = request.getHeader("Authorization");

		String[] tok = token.split("\\s+");

		String Username = SignedJWT.parse(tok[1]).getJWTClaimsSet().getSubject();
		return Username;
	}

	public String getUserRoles(HttpServletRequest request) throws ParseException {
		String token = request.getHeader("Authorization");
		String[] tok = token.split("\\s+");

		String Username = SignedJWT.parse(tok[1]).getJWTClaimsSet().getSubject();
		return Username;
	}

	@SuppressWarnings("unused")
	private String AuthorityListToCommaSeparatedString(Collection<? extends GrantedAuthority> authorities) {
		Set<String> authoritiesAsSetOfString = AuthorityUtils.authorityListToSet(authorities);
		return StringUtils.join(authoritiesAsSetOfString, ", ");
	}

	public Collection<? extends GrantedAuthority> getRoles(HttpServletRequest request) throws ParseException {
		Collection<? extends GrantedAuthority> authorities;
		String token = request.getHeader("Authorization");

		String[] tok = token.split("\\s+");

		String roles = SignedJWT.parse(tok[1]).getJWTClaimsSet().getStringClaim(ROLES_CLAIM);
		authorities = AuthorityUtils.commaSeparatedStringToAuthorityList(roles);
		return authorities;
	}

	public Boolean isNull(Double... values) {
		Boolean rtnVal = Boolean.FALSE;
		for (Double sVal : values) {
			if (sVal == null) {
				rtnVal = Boolean.TRUE;
				break;
			}
		}
		return rtnVal;
	}

	public char[] geek_Password(int len) {
		logger.debug("Generating password using random() : ");
		System.out.print("Your new password is : ");

		// A strong password has Cap_chars, Lower_chars,
		// numeric value and symbols. So we are using all of
		// them to generate our password
		String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String Small_chars = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "0123456789";
		String symbols = "!@#$%^&*_=+-/.?<>)";

		String values = Capital_chars + Small_chars + numbers + symbols;

		// Using random method
		Random rndm_method = new Random();

		char[] password = new char[len];

		for (int i = 0; i < len; i++) {
			// Use of charAt() method : to get character value
			// Use of nextInt() as it is scanning the value as int
			password[i] = values.charAt(rndm_method.nextInt(values.length()));

		}
		return password;
	}

	public Boolean isNullZero(Double... values) {
		Boolean rtnVal = Boolean.FALSE;
		for (Double sVal : values) {
			if (sVal == null || sVal == 0) {
				rtnVal = Boolean.TRUE;
				break;
			}
		}
		return rtnVal;
	}

	public Boolean isNullOrZero(Integer... values) {
		Boolean rtnVal = Boolean.FALSE;
		for (Integer sVal : values) {
			if (sVal == null || sVal == 0) {
				rtnVal = Boolean.TRUE;
				break;
			}
		}
		return rtnVal;
	}

	@SuppressWarnings("rawtypes")
	public Boolean isNullempty(Object value) {
		Boolean rtnVal = Boolean.TRUE;

		if (value instanceof String) {
			if (value != null && !((String) value).isEmpty()) {
				rtnVal = Boolean.FALSE;
			}
		} else if (value instanceof Collection) {
			if (value != null && !((Collection) value).isEmpty()) {
				rtnVal = Boolean.FALSE;
			}
		}
		return rtnVal;
	}

	public Boolean isNull(Object value) {
		Boolean rtnVal = Boolean.TRUE;
		if (value != null) {
			rtnVal = Boolean.FALSE;
		}
		return rtnVal;
	}

	public Boolean isNotNull(Object value) {
		return !isNull(value);
	}

	public String objectToString(Object obj) {
		String str = "";
		if (isNull(obj)) {
			str = null;
		} else {
			str = obj.toString();
		}
		return str;
	}

	public String checkForNull(String sInput) {

		String sOutput = "";
		if (!isNullempty(sInput)) {
			sOutput = sInput.trim();
		}
		return sOutput;
	}

	public int stringtoInt(String sInput) {

		int num = 0;
		if (!isNullempty(sInput)) {
			try {
				num = Integer.parseInt(sInput);
			} catch (Exception e) {

			}
		}
		return num;
	}

	public Double stringtoDouble(String sInput) {

		Double num = new Double(0);
		if (!isNullempty(sInput)) {
			try {
				num = Double.parseDouble(sInput);
			} catch (Exception e) {

			}
		}
		return num;
	}

	public Long stringtoLong(String sInput) {

		Long num = new Long(0);
		if (!isNullempty(sInput)) {
			try {
				num = Long.parseLong(sInput);
			} catch (Exception e) {

			}
		}
		return num;
	}

	public String getDocUploadPath() {

		int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
		String path = Calendar.getInstance().get(Calendar.YEAR) + "/" + month + "/"
				+ Calendar.getInstance().get(Calendar.DATE) + "/";
		return path;
	}

	public Double getPercentageValue(Double value, Double percVal) {

		return (value * percVal) / 100;
	}

	public Double getPercFromVals(Double val1, Double val2) {

		return (val1 / val2) * 100;
	}

	public String formatNumber(Double value, Boolean isDecimal) {

		if (isNull(value)) {
			return null;
		}

		String format = "#.0";

		if (!isDecimal) {
			format = "#";
		}

		DecimalFormat df = new DecimalFormat(format);
		String rtnVal = df.format(value);
		return rtnVal;
	}

	public String formatNumber(Double value) {
		return formatNumber(value, Boolean.TRUE);
	}

	public Double getWholeNumber(Double value) {
		String num = formatNumber(value, Boolean.FALSE);

		if (isNotNull(num))
			return new Double(num);
		else
			return null;
	}

	public boolean isNullOrZero(Long... values) {
		Boolean rtnVal = Boolean.FALSE;
		for (Long sVal : values) {
			if (sVal == null || sVal == 0) {
				rtnVal = Boolean.TRUE;
				break;
			}
		}
		return rtnVal;
	}
	// Changes for URL Security

	@SuppressWarnings("unused")
	private char rndChar() {

		int rnd = (int) (Math.random() * 52); // or use Random or whatever

		char base = (rnd < 26) ? 'A' : 'a';
		return (char) (base + rnd % 26);

	}

	public String getIPAddofClient(HttpServletRequest request) {

		String ip = request.getRemoteAddr(); // "0:0:0:0:0:0:0:1"
		if (ip.equalsIgnoreCase("0:0:0:0:0:0:0:1") || ip.equalsIgnoreCase("0:0:0:0:0:0:0:1")) {
			try {
				return InetAddress.getLocalHost().getHostAddress();
			} catch (Exception e) {
				return null;
			}
		}
		return ip;
	}

	public String getIPAddressofMachine(HttpServletRequest request) {
		String ipAdd = "";

		try {
			ipAdd = request.getHeader("X-FORWARDED-FOR");
			if (ipAdd == null || ipAdd.length() == 0 || "unknown".equalsIgnoreCase(ipAdd)) {
				ipAdd = request.getHeader("Proxy-Client-IP");
			}
			if (ipAdd == null || ipAdd.length() == 0 || "unknown".equalsIgnoreCase(ipAdd)) {
				ipAdd = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ipAdd == null || ipAdd.length() == 0 || "unknown".equalsIgnoreCase(ipAdd)) {
				ipAdd = request.getHeader("HTTP_CLIENT_IP");
			}
			if (ipAdd == null || ipAdd.length() == 0 || "unknown".equalsIgnoreCase(ipAdd)) {
				ipAdd = request.getHeader("HTTP_X_FORWARDED_FOR");
			}
			if (ipAdd == null || ipAdd.length() == 0 || "unknown".equalsIgnoreCase(ipAdd)) {
				ipAdd = request.getRemoteAddr();
			}
			if (ipAdd.contains(",")) {
				ipAdd = ipAdd.substring(0, ipAdd.indexOf(","));
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());

		}

		return ipAdd;
	}

	public String getHexIpAddressMachine(String ipAdd) {
		String hexOfIpAdd = "";
		try {
			String[] data = ipAdd.split("\\.");
			String hex = new String();
			for (int i = 0; i < data.length; i++) {
				logger.debug(data[i]);
				hex = Integer.toHexString(Integer.parseInt(data[i]));
				logger.debug("hex: " + hex);

				if (hex.length() == 1) {
					hex = "0" + hex;
				} else if (hex.length() > 2) {
					hex = hex.substring(0, 2);
				}
				hexOfIpAdd = hexOfIpAdd + hex;
			}
		} catch (Exception e) {
			logger.debug(e.getMessage());

			hexOfIpAdd = "7f000001";
		}

		return hexOfIpAdd;
	}

	public void copy(Object from, Object to) {
		try {
			BeanUtils.copyProperties(to, from);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}

	public String generateTranId(String type) {
		String tranId;
		String julianDate;
		String julianYear;
		try {

			// Calculating Julian Date
			Calendar cal = Calendar.getInstance();
			int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
			int year = cal.get(Calendar.YEAR);
			logger.debug("Year: " + year);
			logger.debug("dayOfYear: " + dayOfYear);
			String century = Integer.toString((year) / 100 - 19);
			julianYear = Integer.toString(year % 100);
			julianDate = century + julianYear + dayOfYear;
			logger.debug("Julian Date: " + julianDate);

			// Getting the time

			DateFormat dateFormat = new SimpleDateFormat("HHmmssSSS");
			Date date = new Date();
			logger.debug(dateFormat.format(date));

			// Preparing the TranId

			tranId = type + "#" + century + julianYear + Integer.toString(dayOfYear) + dateFormat.format(date);

			logger.debug("TranId: " + tranId);

		} catch (Exception e) {
			e.printStackTrace();
			tranId = type + "#118999" + "180608527";
			logger.debug("TranId: " + tranId);
		}
		logger.debug("TranId response is : " + tranId);
		return tranId;
	}

	public String generateHisId(String type) {
		String tranId;
		String julianDate;
		String julianYear;
		try {

			// Calculating Julian Date
			Calendar cal = Calendar.getInstance();
			int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
			int year = cal.get(Calendar.YEAR);
			logger.debug("Year: " + year);
			logger.debug("dayOfYear: " + dayOfYear);
			String century = Integer.toString((year) / 100 - 19);
			julianYear = Integer.toString(year % 100);
			julianDate = century + julianYear + dayOfYear;
			logger.debug("Julian Date: " + julianDate);

			// Getting the time

			DateFormat dateFormat = new SimpleDateFormat("HHmmssSSS");
			Date date = new Date();
			logger.debug(dateFormat.format(date)); // 2016/11/16 12:08:43

			// Preparing the TranId

			tranId = type + "#" + century + julianYear + Integer.toString(dayOfYear) + dateFormat.format(date);

		} catch (Exception e) {
			tranId = type + "#118999" + "180608527";

		}
		return tranId;
	}

	// #BVB00002 Starts
	/*
	 * public String encrypt(String value) { try { IvParameterSpec iv = new
	 * IvParameterSpec(initVector.getBytes("UTF-8")); SecretKeySpec skeySpec = new
	 * SecretKeySpec(key.getBytes("UTF-8"), "AES");
	 * 
	 * Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	 * cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
	 * 
	 * byte[] encrypted = cipher.doFinal(value.getBytes()); return
	 * Base64.encodeBase64String(encrypted); } catch (Exception ex) {
	 * ex.printStackTrace(); } return null; }
	 */
	public String decrypt(String encrypted) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
			byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));

			return new String(original);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}
	// #BVB00002 Ends

	// #BVB00035 Starts
	public String encrypt(String value) {
		try {
			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

			byte[] encrypted = cipher.doFinal(value.getBytes());
			logger.debug("encrypted string: " + Base64.encodeBase64String(encrypted));

			return Base64.encodeBase64String(encrypted);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}

	// #BVB00035 Ends
	public JsonArray filterArrayO(JsonArray reqArray, JsonObject filter) {
		JsonArray resArray = new JsonArray();

		Map<String, Object> filters = new HashMap<String, Object>();
		Set<Entry<String, JsonElement>> entrySet = filter.entrySet();
		for (Map.Entry<String, JsonElement> entry : entrySet) {
			try {
				filters.put(entry.getKey(), filter.get(entry.getKey()).getAsString());
				// #BVB00005 Starts
			} catch (Exception e) {
				// Eat Up
			}
		}

		for (int i = 0; i < reqArray.size(); i++) {
			JsonObject reqObject = reqArray.get(i).getAsJsonObject();

			main: {
				for (Map.Entry<String, Object> att : filters.entrySet()) {
					logger.debug("FieldName >>> " + att.getKey());
					logger.debug("FieldVal >>> " + att.getValue());
					String CurrField = att.getKey();
					String CurrVal = att.getValue().toString();

					if (!I$utils.$iStrFuzzyMatch(reqObject.get(CurrField).getAsString(), CurrVal)) {
						break main;
					}

				}
				resArray.add(reqObject);
			}

		}

		return resArray;

	}

	public JsonArray createArrayS(JsonArray reqMsg, String element) {
		JsonArray resMsg = new JsonArray();
		try {

			for (int i = 0; i < reqMsg.size(); i++) {
				try {
					resMsg.add(reqMsg.get(i).getAsJsonObject().get(element));
				} catch (Exception e) {
					e.printStackTrace();
					//
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}

		return resMsg;
	}

	// #MAQ00001 begins
	public JsonArray createArrayS(JsonArray reqMsg, JsonArray reqFieldArr) { // # MAQ00002
		JsonArray resMsg = new JsonArray();
		try {
			for (int i = 0; i < reqMsg.size(); i++) {
				try {
					// # MAQ00002 starts
					JsonObject i$runningObj = reqMsg.get(i).getAsJsonObject();
					JsonObject resMsgRunning = new JsonObject();
					for (int j = 0; j < reqFieldArr.size(); j++) {
						// for (int i = 0; i < reqMsg.size(); i++) {
						// try {
						// JsonObject resMsgRunning = new JsonObject();
						// for (int j = 0; j < element.size(); j++) {
						// JsonElement s = element.get(j);
						// JsonObject j1 = reqMsg.get(i).getAsJsonObject();
						// JsonElement s2 = j1.get(s.getAsString());
						//
						// resMsgRunning.add(s.toString(),s2);

						String reqFieldS = reqFieldArr.get(j).getAsString();
						String value = i$runningObj.get(reqFieldS).getAsString();
						resMsgRunning.addProperty(reqFieldS, value);
						// # MAQ00002 ends
					}
					resMsg.add(resMsgRunning);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// return null;
			resMsg = null;
		}

		return resMsg;
	}
	// #MAQ00001 ends

	public String passwordDecrypt(String password) {
		String password1 = "";
		try {
			String decryptedPassword = new String(java.util.Base64.getDecoder().decode(password));
			// iDCryptor aesUtil = new AesUtil(128, 1000);
			if (decryptedPassword != null && decryptedPassword.split("::").length == 3) {

				password1 = iDCryptor.decrypt(decryptedPassword.split("::")[1], decryptedPassword.split("::")[0], keyDe,
						decryptedPassword.split("::")[2]);
				logger.debug(password1);
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return password1;

	}

	// #NYE00001 Begins
	public String decryptPkey(String sVal) {
		String key = i$ResM.getGobalValStr("deCryptKey");
		try {
			return I$Crypt.decryptText(sVal, key);
		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed in Decrypting with Error: " + e.getMessage());
			return null;
		}
	}

	public String encryptPkey(String sVal) {
		String key = i$ResM.getGobalValStr("deCryptKey");
		try {
			return rsaAsymCrypt.encryptTextWithPrivate(sVal, key);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// #NYE00001 Ends

	public String encryptPrikey(String sVal) {
		String key = i$ResM.getGobalValStr("enCryptKey");
		try {
			return rsaAsymCrypt.encryptText(sVal, key);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// #BVB00035 Starts
	public String decrypt(String password, String key) {
		String password1 = "";
		try {
			String decryptedPassword = new String(java.util.Base64.getDecoder().decode(password));
			// iDCryptor aesUtil = new AesUtil(128, 1000);
			if (decryptedPassword != null && decryptedPassword.split("::").length == 3) {

				password1 = iDCryptor.decrypt(decryptedPassword.split("::")[1], decryptedPassword.split("::")[0], key,
						decryptedPassword.split("::")[2]);
//				logger.debug(password1);
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return password1;

	}

	public String encrypt(String plainText, String passKey) {
		iDCryptor iDCryptor = new iDCryptor(128, 1000);
		String finalString = "";
		try {
			String salt = iDCryptor.random(16);
			String iv = iDCryptor.random(16);
			byte[] encryptedKeyB = iDCryptor.encrypt(salt, iv, passKey, plainText);

			String finalEncrptedVal = formEncrypteVal(salt, iv, iDCryptor.base64(encryptedKeyB));
			byte[] data;
			try {
				data = finalEncrptedVal.getBytes("UTF-8");
				finalString = new String(iDCryptor.base64(data)); // Base64.encodeBase64(data));
			} catch (Exception e) {
				e.printStackTrace();
			}

			// logger.debug("encryptedKey: " + finalString);

		} catch (Exception e) {
			e.printStackTrace();

			finalString = null;
		}

		return finalString;
	}

	// #BVB00035 Ends
	/*
	 * 
	 * public String encrypt(String plainText, String passKey) {
	 * 
	 * String encryptedKey = ""; try {
	 * 
	 * //String salt = I$utils.$randomAplhanumeric(20); // String iv =
	 * I$utils.$randomAplhanumeric(20);
	 * 
	 * //encryptedKey = iDCryptor.encrypt(hexEncode(salt), hexEncode(iv), passKey,
	 * plainText);
	 * 
	 * //iDCryptor aesUtils = new iDCryptor(128,1000); String salt =
	 * iDCryptor.random(16); String iv = iDCryptor.random(16);
	 * 
	 * encryptedKey = iDCryptor.encrypt(salt,iv,passKey,plainText);
	 * 
	 * 
	 * }catch(Exception e) { e.printStackTrace();
	 * logger.debug("Failed in Ecryting: " + e.getMessage() ); encryptedKey = null;
	 * }
	 * 
	 * 
	 * return encryptedKey; }
	 */

	public String hexEncode(String str) {
		try {
			str = Hex.encodeHexString(str.getBytes());
		} catch (Exception e) {
			str = null;
		}

		return str;
	}

	public String concatenate(List<String> listOfItems, String separator) {
		StringBuilder sb = new StringBuilder();
		Iterator<String> stit = listOfItems.iterator();

		while (stit.hasNext()) {
			sb.append(stit.next());
			if (stit.hasNext()) {
				sb.append(separator);
			}
		}

		return sb.toString();
	}

	/**
	 * Checks if is collection empty.
	 *
	 * @param collection the collection
	 * @return true, if is collection empty
	 */
	private boolean isCollectionEmpty(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return true;
		}
		return false;
	}

	/**
	 * Checks if is object empty.
	 *
	 * @param object the object
	 * @return true, if is object empty
	 */
	public boolean isObjectEmpty(Object object) {
		if (object == null)
			return true;
		else if (object instanceof String) {
			if (((String) object).trim().length() == 0) {
				return true;
			}
		} else if (object instanceof Collection) {
			return isCollectionEmpty((Collection<?>) object);
		} else if (object instanceof byte[]) {

			if (((byte[]) object).length <= 0) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	// #BVB00035 Starts
	public String formEncrypteVal(String salt, String iv, String encrytedVal) {
		String aesPassword = (iv + "::" + salt + "::" + encrytedVal);

		return aesPassword;
	}
	// #BVB00035 Ends

	// BVBCURR
	// V0000025 File reading related changes

	// #V000004 starts
	public File extractRAR(String FileName, JsonObject argJson) throws IOException {

		File rarFile = new File(FileName);
		Archive a = null;
		try {
			a = new Archive(new FileVolumeManager(rarFile));
		} catch (RarException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (a != null) {
			a.getMainHeader().print();
			FileHeader fh = a.nextFileHeader();
			while (fh != null) {
				try {
					File out = new File("D:/Extract/" + fh.getFileNameString().trim());
					logger.debug(out.getAbsolutePath());
					// FileInputStream is = new FileInputStream(out);

					FileOutputStream os = new FileOutputStream(out);
					a.extractFile(fh, os);
					os.close();
					a.close();
					// Delete the Rar file
					/*
					 * try { rarFile.delete(); }catch(Exception e) { e.printStackTrace(); }
					 */
					return out;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
					return null;
				} catch (RarException e) {
					e.printStackTrace();
					return null;
				} catch (IOException e) {
					e.printStackTrace();

				}
				fh = a.nextFileHeader();
			}
		}
		return null;

	}

	@SuppressWarnings("unused")
	private File unzip(String zipFilePath, String destDir) {
		File dir = new File(destDir);
		// create output directory if it doesn't exist
		if (!dir.exists())
			dir.mkdirs();
		FileInputStream fis;
		// buffer for read and write data to file
		byte[] buffer = new byte[1024];
		try {
			fis = new FileInputStream(zipFilePath);
			ZipInputStream zis = new ZipInputStream(fis);
			ZipEntry ze = zis.getNextEntry();
			File newFile = null;
			while (ze != null) {
				String fileName = ze.getName();
				newFile = new File(destDir + File.separator + fileName);
				logger.debug("Unzipping to " + newFile.getAbsolutePath());
				// create directories for sub directories in zip
				new File(newFile.getParent()).mkdirs();
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				// close this ZipEntry
				zis.closeEntry();
				ze = zis.getNextEntry();
			}
			// close last ZipEntry
			zis.closeEntry();
			zis.close();
			fis.close();

			return newFile;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;

	}

	// XML parser functionalities

	public void XmlFileParser(String FileName) {

		try {
			File file = new File(FileName);
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

			Document doc = (Document) dBuilder.parse(file);

			logger.debug("Root element :" + ((org.w3c.dom.Document) doc).getDocumentElement().getNodeName());

			if (((Node) doc).hasChildNodes()) {

				printNote(((Node) doc).getChildNodes());

			}

		} catch (Exception e) {
			logger.debug(e.getMessage());
		}

	}

	private void printNote(NodeList nodeList) {

		for (int count = 0; count < nodeList.getLength(); count++) {

			Node tempNode = nodeList.item(count);

			// make sure it's element node.
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				// get node name and value
				logger.debug("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
				logger.debug("Node Value =" + tempNode.getTextContent());

				if (tempNode.hasAttributes()) {

					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();

					for (int i = 0; i < nodeMap.getLength(); i++) {

						Node node = nodeMap.item(i);
						logger.debug("attr name : " + node.getNodeName());
						logger.debug("attr value : " + node.getNodeValue());

					}

				}

				if (tempNode.hasChildNodes()) {

					// loop again if has child nodes
					printNote(tempNode.getChildNodes());

				}

				logger.debug("Node Name =" + tempNode.getNodeName() + " [CLOSE]");

			}

		}

	}

	// #V000004 Ends

	// #BVB00036 Starts
	public Collection<String> $getReqFields(JsonArray i$AnnoteFlds, String fieldName) {
		Collection<String> reqFlds = new ArrayList<String>();
		for (int i = 0; i < i$AnnoteFlds.size(); i++) {
			JsonObject jfld = i$AnnoteFlds.get(i).getAsJsonObject();
			// Adding Mandatory List
			try {
				if ((I$utils.$iStrFuzzyMatch(jfld.get(fieldName).getAsString(), "1"))
						&& (reqFlds == null || !reqFlds.contains(jfld.get("FIELDNAME").getAsString()))) {
					reqFlds.add(jfld.get("FIELDNAME").getAsString());
				}
				;

			} catch (Exception e) {
				// Eat Up
			}

			try {

				if (jfld.get("FIELDS").getAsJsonArray() != null) {
					JsonArray i$AnnoteFldsRun = jfld.get("FIELDS").getAsJsonArray();
					reqFlds.addAll($getReqFields(i$AnnoteFldsRun, fieldName));
				}
			} catch (Exception e) {
				// Eat Up
			}

		}
		;
		return reqFlds;

	}

	// BVBCURR

	// valla Starts
	public String getSalt(int length) {
		StringBuilder returnValue = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			returnValue.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
		}
		return new String(returnValue);
	}

	public byte[] hash(char[] password, byte[] salt) {
		PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH);
		Arrays.fill(password, Character.MIN_VALUE);
		try {
			SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			return skf.generateSecret(spec).getEncoded();
		} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
			throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
		} finally {
			spec.clearPassword();
		}
	}

	public String generateSecurePassword(String password, String salt) {
		String returnValue = null;
		byte[] securePassword = hash(password.toCharArray(), salt.getBytes());

		returnValue = java.util.Base64.getEncoder().encodeToString(securePassword);

		return returnValue;
	}

	public boolean verifyUserPassword(String providedPassword, String securedPassword, String salt) {
		boolean returnValue = false;

		// Generate New secure password with the same salt
		String newSecurePassword = generateSecurePassword(providedPassword, salt);

		// Check if two passwords are equal
		returnValue = newSecurePassword.equalsIgnoreCase(securedPassword);

		return returnValue;
	}
	// Valla Ends

	public String base64Encode(byte[] bytes) {
		try {
			return Base64.encodeBase64String(bytes);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public byte[] base64Decode(String str) {
		try {
			return Base64.decodeBase64(str);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public String $getMimeType(String encoded) {
		String type = "";
		try {
			Pattern mime = Pattern.compile("^data:([a-zA-Z0-9]+/[a-zA-Z0-9-]+).*;.*");
			Matcher matcher = mime.matcher(encoded);
			if (!matcher.find()) {
				type = null;
			} else {
				type = matcher.group(1).toLowerCase();
			}

		} catch (Exception e) {
			e.printStackTrace();
			type = null;
		}
		return type;
	}

	public boolean $isValidFileType(String mime, String type) {
		boolean valid = false;
		try {
			if (mime != null) {
				if (mime.contains(type)) {
					valid = true;
				}
			} else {
				valid = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			valid = false;
		}

		return valid;
	}

	public String getFileType(String encoded) {

		ImpactoUtil i$impactoUtil = new ImpactoUtil();
		String fileType = "";

		try {
			String mime = i$impactoUtil.$getMimeType(encoded);
			switch (mime) {
			case "application/x-rar":
				fileType = "RAR";
				break;
			case "application/zip":
				fileType = "ZIP";
				break;
			case "application/x-zip-compressed": // #HAS00001 Added
				fileType = "ZIP";
				break;

			/*
			 * case "": fileType = ""; case "": fileType = ""; case "": fileType = ""; case
			 * "": fileType = "";
			 */
			default:
				fileType = null;

			}
			if (isNull(fileType)) {
				if (looksLikeHTML(fileType)) {
					fileType = "HTML";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			fileType = null;
		}

		return fileType;

	}

// #NYE00010 Starts 
//	public String lpad(String input, int length, String replaceWith) {
//		String lPadString = "";
//		try {
//			lPadString = StringUtils.leftPad(input, length, replaceWith);
//		} catch (Exception e) {
//			lPadString = null;
//			e.printStackTrace();
//		}
//		return lPadString;
//	}
// #BVB00168 Starts 
	public boolean looksLikeHTML(String text) {
		boolean isHtml = false;
		try {
			String HTML_PATTERN = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
			Pattern pattern = Pattern.compile(HTML_PATTERN);
			Matcher matcher = pattern.matcher(text);
			isHtml = matcher.find();

		} catch (Exception e) {
			isHtml = false;
		}
		return isHtml;
	}

	// #BVB00168 Ends
	public String lpad(String input, int length, String replaceWith) {
		if (length == 0)
			return "";
		String lPadString = "";
		try {
			lPadString = StringUtils.leftPad(input, length, replaceWith);
		} catch (Exception e) {
			lPadString = null;
			e.printStackTrace();
		}
		return lPadString;
	}

	// #NYE00010 Ends
	public byte[][] genKeyPairRSA() {
		byte[][] keyPair = new byte[2][2];

		try {
			RSAKeyGeneration gk = new RSAKeyGeneration(1024);
			gk.createKeys();

			keyPair[0] = gk.getPublicKey().getEncoded();
			keyPair[1] = gk.getPrivateKey().getEncoded();
		} catch (Exception e) {
			// e.printStackTrace();
			logger.info("Failed in Generating Key Pair with error: " + e.getMessage());
			keyPair = null;
		}

		return keyPair;
	}

	// #BVB00036 Ends

	/**
	 * This is a Constructor
	 */
	public ImpactoUtil() {
		// Constructor
	}

	// #BHU00001
	public String generateRandomString(int length) {
		Random random = new Random();
		random.setSeed(System.currentTimeMillis());
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}
		return new String(digits);
	}

	/// #BHU00001 ends
	// #BHU00002 start
	public String getAlphaNumericId(int n) {

		// chose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz"
		// + "[!]@$#"; // #BVB00066
				+ "[!]@#"; // #BVB00066

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	// #BHU00002 Ends
	public String getAlphaNumericStr(int n) {

		// chose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}


	// #BVB00047 Starts
	public ArrayList<String> $jsonArrayToSList(JsonArray inArr) {
		ArrayList<String> arrList = new ArrayList<String>();
		try {
			for (int i = 0; i < inArr.size(); i++) {
				arrList.add(inArr.get(i).getAsString());
			}
		} catch (Exception e) {
			arrList = null;
			logger.debug("Failed in arrToList with Error: " + e.getMessage());
		}
		return arrList;
	}
	// #BVB00047 Ends

	public List<String> jsonArrayToSList(JsonArray inArr) {
		List<String> arrList = new ArrayList<String>();
		try {
			for (int i = 0; i < inArr.size(); i++) {
				arrList.add(inArr.get(i).getAsString());
			}
		} catch (Exception e) {
			arrList = null;
			logger.debug("Failed in arrToList with Error: " + e.getMessage());
		}
		return arrList;
	}

	public JsonArray $oListToJsonArray(ArrayList<JsonObject> fromlist) {
		JsonArray createdArray = new JsonArray();
		try {

			for (int i = 0; i < fromlist.size(); i++) {
				createdArray.add(fromlist.get(i));
			}

		} catch (Exception e) {
			createdArray = null;
			logger.debug("Failed in List to Array with: " + e.getMessage());
		}
		return createdArray;
	}

	public JsonArray $sListToJsonArray(ArrayList<String> fromlist) {
		JsonArray createdArray = new JsonArray();
		try {

			for (int i = 0; i < fromlist.size(); i++) {
				createdArray.add(fromlist.get(i));
			}

		} catch (Exception e) {
			createdArray = null;
			logger.debug("Failed in List to Array with: " + e.getMessage());
		}
		return createdArray;
	}

	// #BVB00048 Starts
	public boolean matchRegEx(String match, String pattern) {

		boolean matchFound = false;
		try {
			Pattern patternP = Pattern.compile(pattern);
			Matcher matcher = patternP.matcher(match);
			matchFound = matcher.matches();
		} catch (Exception e) {
			matchFound = false;
		}
		return matchFound;
	}

	// #BVB00048 Ends
	// #BVB00051 Starts

	public double fuzzySearch(String compareWith, String compare) {

		try {

			if (compareWith.equals(compare)) {
				return 1;
			}

			if (compare.isEmpty() || compareWith.isEmpty()) {
				logger.debug("Comparision strings cannot be Empty.. ");
				return 0;
			}

			double runningScore = 0;
			double finalScore;
			double charScore;
			String string = compareWith;
			String lString = string.toLowerCase();
			int strLength = string.length();
			String lWord = compare.toLowerCase();
			int wordLength = compare.length();
			int idxOf;
			int startAt = 0;
			double fuzzies = 1;
			double fuzzyFactor = 0;
			int i;
			double fuzziness = 0.5;

			if (fuzziness == 0) {
				fuzzyFactor = 1 - fuzziness;
			}
			;

			if (fuzziness > 0) {
				for (i = 0; i < wordLength; i += 1) {

					// Find next first case-insensitive match of a character.
					idxOf = lString.indexOf(lWord.charAt(i), startAt);

					if (idxOf == -1) {
						fuzzies += fuzzyFactor;
					} else {
						if (startAt == idxOf) {
							// Consecutive letter & start-of-string Bonus
							charScore = 0.7;
						} else {
							charScore = 0.1;

							// Acronym Bonus
							// Weighing Logic: Typing the first character of an acronym is as if you
							// preceded it with two perfect character matches.
							if (string.charAt(idxOf - 1) == ' ') {
								charScore += 0.8;
							}
						}

						// Same case bonus.
						if (string.charAt(idxOf) == compare.charAt(i)) {
							charScore += 0.1;
						}

						// Update scores and startAt position for next round of indexOf
						runningScore += charScore;
						startAt = idxOf + 1;
					}
				}
			} else {
				for (i = 0; i < wordLength; i += 1) {
					idxOf = lString.indexOf(lWord.charAt(i), startAt);
					if (-1 == idxOf) {
						return 0;
					}

					if (startAt == idxOf) {
						charScore = 0.7;
					} else {
						charScore = 0.1;
						if (string.charAt(idxOf - 1) == ' ') {
							charScore += 0.8;
						}
					}
					if (string.charAt(idxOf) == compare.charAt(i)) {
						charScore += 0.1;
					}
					runningScore += charScore;
					startAt = idxOf + 1;
				}
			}

			// Reduce penalty for longer strings.
			finalScore = 0.5 * (runningScore / strLength + runningScore / wordLength) / fuzzies;

			if ((lWord.charAt(0) == lString.charAt(0)) && (finalScore < 0.85)) {
				finalScore += 0.15;
			}
			return finalScore;
		} catch (Exception e) {
			return 0;
		}
	}

	public String getSoundex(String value) {

		return (new Soundex()).encode(value);
	}
	// #BVB00051 Ends

	// #BVB00052 Starts
	public JsonArray replaceFormula(JsonArray reqArray, JsonObject data, JsonArray preDefVal) {
		JsonArray resMsg = new JsonArray();
		try {
			for (int i = 0; i < reqArray.size(); i++) {
				String i$runningS = reqArray.get(i).getAsString();
				if (!I$utils.isInArray(preDefVal, i$runningS)) {
					try {
						resMsg.add(data.get(i$runningS).getAsString());
					} catch (Exception e) {
						try {
							resMsg.add(Double.parseDouble(i$runningS));
						} catch (Exception ex) {
							resMsg.add(Integer.parseInt(i$runningS));
						}
					}

				} else {
					resMsg.add(i$runningS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			resMsg = null;
		}

		return resMsg;
	}

	public Double evaluateInfix(JsonArray reqMsg, JsonArray preDefVal) {
		// char[] tokens = expression.toCharArray();

		// Stack for numbers: 'values'
		Stack<Double> values = new Stack<Double>();

		// Stack for Operators: 'ops'
		Stack<String> ops = new Stack<String>();

		for (int i = 0; i < reqMsg.size(); i++) {
			String i$runningS = reqMsg.get(i).getAsString();
			// Current token is a whitespace, skip it
			if (I$utils.$iStrFuzzyMatch(i$runningS, " "))
				continue;

			// Current token is a number, push it to stack for numbers

			if (!I$utils.isInArray(preDefVal, i$runningS)) {
				values.push(Double.parseDouble(i$runningS));
			}
			// Current token is an opening brace, push it to 'ops'

			else if (I$utils.$iStrFuzzyMatch(i$runningS, "(")) {
				ops.push(i$runningS);
			}
			// Closing brace encountered, solve entire brace
			else if (I$utils.$iStrFuzzyMatch(i$runningS, ")")) {
				while (!I$utils.$iStrFuzzyMatch(ops.peek(), "("))
					values.push(applyOp(ops.pop(), values.pop(), values.pop()));
				ops.pop();
			}

			// Current token is an operator.

			else if (I$utils.$iStrFuzzyMatch(i$runningS, "+") || I$utils.$iStrFuzzyMatch(i$runningS, "-")
					|| I$utils.$iStrFuzzyMatch(i$runningS, "*") || I$utils.$iStrFuzzyMatch(i$runningS, "/")) {
				// While top of 'ops' has same or greater precedence to current
				// token, which is an operator. Apply operator on top of 'ops'
				// to top two elements in values stack
				while (!ops.empty() && hasPrecedence(i$runningS, ops.peek()))
					values.push(applyOp(ops.pop(), values.pop(), values.pop()));

				// Push current token to 'ops'.
				ops.push(i$runningS);
			}

		}

		// Entire expression has been parsed at this point, apply remaining
		// ops to remaining values
		while (!ops.empty())
			values.push(applyOp(ops.pop(), values.pop(), values.pop()));

		// Top of 'values' contains result, return it
		return values.pop();

	}

	public boolean hasPrecedence(String op1, String op2) {
		if (I$utils.$iStrFuzzyMatch(op2, "(") || I$utils.$iStrFuzzyMatch(op2, ")"))
			return false;
		if ((I$utils.$iStrFuzzyMatch(op2, "*") || I$utils.$iStrFuzzyMatch(op2, "/"))
				&& (I$utils.$iStrFuzzyMatch(op2, "+") || I$utils.$iStrFuzzyMatch(op2, "-")))
			return false;
		else
			return true;
	}

	// A utility method to apply an operator 'op' on operands 'a'
	// and 'b'. Return the result.
	public double applyOp(String op, double b, double a) {
		double result = 0.0;
		try {
			switch (op) {
			case "+":
				result = a + b;
				break;
			case "-":
				result = a - b;
				break;
			case "*":
				result = a * b;
				break;
			case "/":
				if (b == 0)

				{
					result = 0;
				} else {

					result = a / b;
				}
				break;
			}
		} catch (Exception e) {
			result = 0;
		}
		return result;
	}

	public JsonObject getRating(JsonObject icorMDataFormula) {
		ImpactoUtil i$impactoUtil = new ImpactoUtil();
		JsonObject i$rating = new JsonObject();
		try {
			JsonArray i$formulaRating = icorMDataFormula.get("formulaRating").getAsJsonArray();
			String i$typeOfDisclosure = icorMDataFormula.get("typeOfDisclosure").getAsString();
			String i$dataType = icorMDataFormula.get("dataType").getAsString();

			if (I$utils.$iStrFuzzyMatch(i$typeOfDisclosure, "QN")) {
				if (I$utils.$iStrFuzzyMatch(i$dataType, "N") || I$utils.$iStrFuzzyMatch(i$dataType, "P")) {
					double valueDouble = icorMDataFormula.get("value").getAsDouble();
					i$rating = i$impactoUtil.$doubleValidator(i$formulaRating, valueDouble);
				}
			} else {
				if (I$utils.$iStrFuzzyMatch(i$dataType, "S")) {
					for (int i = 0; i < i$formulaRating.size(); i++) {
						String value = icorMDataFormula.get("value").getAsString();
						JsonObject i$runningObj = new JsonObject();
						i$runningObj = i$formulaRating.get(i).getAsJsonObject();
						if (I$utils.$iStrFuzzyMatch(i$runningObj.get("value").getAsString(), value)) {
							i$rating = i$runningObj;
						}

					}

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			i$rating = null;
		}
		return i$rating;
	}

	public JsonObject $doubleValidator(JsonArray formulaRating, double value) {
		JsonObject ratingMatchObj = new JsonObject();
		try {
			for (int i = 0; i < formulaRating.size(); i++) {
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = formulaRating.get(i).getAsJsonObject();
				if (value >= i$runningObj.get("lowerLimit").getAsDouble()
						&& value < i$runningObj.get("upperLimit").getAsDouble()) {
					ratingMatchObj = i$runningObj;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ratingMatchObj = null;
		}
		return ratingMatchObj;
	}

	public JsonObject getScore(JsonObject icorMScore) {
		JsonObject i$score = new JsonObject();
		try {
			JsonArray i$scoreRating = new JsonArray();
			i$scoreRating = icorMScore.getAsJsonArray("scoreRating");
			String i$value = icorMScore.get("value").getAsString();

			for (int i = 0; i < i$scoreRating.size(); i++) {
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = i$scoreRating.get(i).getAsJsonObject();

				if (I$utils.$iStrFuzzyMatch(i$runningObj.get("rating").getAsString(), i$value)) {
					i$score = i$runningObj;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			i$score = null;
		}

		return i$score;
	}

	public JsonObject getRank(JsonObject icorMRank) {
		JsonObject i$rank = new JsonObject();
		try {
			JsonArray i$ranking = new JsonArray();
			i$ranking = icorMRank.get("ranking").getAsJsonArray();
			double value = icorMRank.get("value").getAsDouble();

			for (int i = 0; i < i$ranking.size(); i++) {
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = i$ranking.get(i).getAsJsonObject();

				if (value >= i$runningObj.get("lowerLimit").getAsDouble()
						&& value < i$runningObj.get("upperLimit").getAsDouble()) {
					i$rank = i$runningObj;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			i$rank = null;
		}

		return i$rank;
	}

	// #BVB00052 Ends
	// #BVB00075 Starts
	public String getFormattedTmpl(String sTmpl, JsonObject J$vals) {
		// Every Field to be Replaced Should be in the format
		// ###IMP1###<JsonKey>###IMP2###
		try {
			Set<Entry<String, JsonElement>> entrySet = J$vals.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = "###IMP1###" + entry.getKey() + "###IMP2###";
				strVal = J$vals.get(entry.getKey()).getAsString();
				sTmpl = sTmpl.replaceAll(strKey, strVal);
			}
		} catch (Exception ex) {
			logger.debug(ex.getMessage());
		}
		return sTmpl;
	}
	// #BVB00075 Ends

	// #BVB00092 Starts
	public JsonObject nestedObjToSinObj(JsonObject isonMsg) {
		JsonObject splitted = new JsonObject();
		try {
			Set<Entry<String, JsonElement>> entrySet = isonMsg.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				String currKey = entry.getKey();
				JsonElement currVal = isonMsg.get(currKey);
				if (isonMsg.get(currKey).isJsonObject()) {
					// Call Object SPlitter
					splitted = mergeJsonObject(splitted, nestedObjToSinObj(currVal.getAsJsonObject(), currKey));
				} else if (isonMsg.get(currKey).isJsonPrimitive()) {
					splitted.addProperty(currKey, isonMsg.get(currKey).getAsString());
				} else if (isonMsg.get(currKey).isJsonArray()) {
					// Call recursively
					// splitted.add(currKey, currVal.getAsJsonArray());
				}
			}

		} catch (Exception e) {
			logger.debug("Failed while splitting the objects with: " + e.getMessage());
			e.printStackTrace();
			splitted = null;
		}
		return splitted;
	}

	public JsonObject nestedObjToSinObj(JsonObject isonMsg, String prefix) {
		JsonObject splitted = new JsonObject();
		try {
			Set<Entry<String, JsonElement>> entrySet = isonMsg.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				String currKey = entry.getKey();
				JsonElement currVal = isonMsg.get(currKey);
				if (isonMsg.get(currKey).isJsonObject()) {
					// Call Object SPlitter
					splitted = mergeJsonObject(splitted,
							nestedObjToSinObj(currVal.getAsJsonObject(), prefix + "." + currKey));
				} else if (isonMsg.get(currKey).isJsonPrimitive()) {
					splitted.addProperty(prefix + "." + currKey, isonMsg.get(currKey).getAsString());
				} else if (isonMsg.get(currKey).isJsonArray()) {
					// Call recursively
					// splitted.add(currKey, currVal.getAsJsonArray());
				}
			}

		} catch (Exception e) {
			logger.debug("Failed while splitting the objects with: " + e.getMessage());
			e.printStackTrace();
			splitted = null;
		}
		return splitted;
	}

	public JsonObject mergeJsonObject(JsonObject first, JsonObject second) {
		try {
			Set<Entry<String, JsonElement>> entrySet = second.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				// #BVB00168 Starts
				if (second.get(entry.getKey()).isJsonPrimitive()) {
					first.addProperty(entry.getKey(), second.get(entry.getKey()).getAsString());
				} else if (second.get(entry.getKey()).isJsonObject()) {
					first.add(entry.getKey(), second.get(entry.getKey()).getAsJsonObject());
				} else {
					first.add(entry.getKey(), second.get(entry.getKey()).getAsJsonArray());
				}
				// #BVB00168 Ends
			}

		} catch (Exception e) {
			logger.debug("Failed while merging the objects with: " + e.getMessage());
			e.printStackTrace();
			first = null;
		}
		return first;
	}

	// #BVB00092 Ends
	// #BVB00128 Starts
	public JsonObject refineJsonObject(JsonObject parent, JsonObject child) {
		JsonObject i$res = new JsonObject();
		try {
			Set<Entry<String, JsonElement>> entrySet = child.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				try {
					if (parent.has(entry.getKey())) {
						if (parent.get(entry.getKey()).isJsonPrimitive()) {
							i$res.addProperty(entry.getKey(), parent.get(entry.getKey()).getAsString());
						} else if (parent.get(entry.getKey()).isJsonObject()) {
							i$res.add(entry.getKey(), parent.get(entry.getKey()).getAsJsonObject());
						} else if (parent.get(entry.getKey()).isJsonArray()) {
							i$res.add(entry.getKey(), parent.get(entry.getKey()).getAsJsonArray());
						}
					}

				} catch (Exception ex) {
					// Eat Up
				}

			}
		} catch (Exception e) {

		}
		return i$res;
	}
	// #BVB00128 Ends

// #BVB00100 Starts 
	public JsonObject fuzzyWuzzy(String search, String searchIn, double cutoff) {
		JsonObject fuzzyResults = new JsonObject();
		try {
			ArrayList<String> choices = new ArrayList<String>();
			choices.add(search);
			fuzzyResults = FuzzySearch.extractAllJson(searchIn, choices, cutoff);
		} catch (Exception e) {
			e.printStackTrace();
			fuzzyResults = null;
		}
		return fuzzyResults;
	}

	public int fuzzyWuzzy(String search, String searchIn) {
		int fuzzyScore = 0;
		try {
			ArrayList<String> choices = new ArrayList<String>();
			choices.add(search);
			fuzzyScore = FuzzySearch.partialRatio(search.toUpperCase(), searchIn.toUpperCase());

		} catch (Exception e) {
			e.printStackTrace();
			fuzzyScore = 0;
		}
		return fuzzyScore;
	}

	public JsonArray sortJsonArray(String key, JsonArray unsortedArray) {
		JsonArray sortedArray = new JsonArray();
		try {
			ArrayList<JsonObject> sortedArrayList = new ArrayList<JsonObject>();
			for (int i = 0; i < unsortedArray.size(); i++) {
				sortedArrayList.add(unsortedArray.get(i).getAsJsonObject());
			}

			// Sort the Java Array List
			Collections.sort(sortedArrayList, new Comparator<JsonObject>() {

				@Override
				public int compare(JsonObject lhs, JsonObject rhs) {
					// TODO Auto-generated method stub

					try {
						return Double.compare(lhs.get(key).getAsDouble(), rhs.get(key).getAsDouble());
					} catch (Exception e) {
						e.printStackTrace();
						return 0;
					}
				}
			});

			sortedArray = $oListToJsonArray(sortedArrayList);

		} catch (Exception e) {
			sortedArray = null;
		}
		return sortedArray;
	}

	public JsonArray getObjectOfArray(int beginIndex, int endIndex, JsonArray parentArray) {
		JsonArray childArray = new JsonArray();
		boolean valid = true;
		try {
			int size = parentArray.size();
			if (size < beginIndex || beginIndex > endIndex) {
				valid = false;
			} else if (endIndex > size) {
				endIndex = size;
			}
			if (valid) {
				for (int i = beginIndex; i < endIndex; i++) {
					childArray.add(parentArray.get(i).getAsJsonObject());
				}
			} else {
				childArray = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			childArray = null;
		}
		return childArray;
	}

	public JsonArray notInArray(JsonArray parentArr, JsonArray childArr) {
		JsonArray notInArr = new JsonArray();

		try {
			ArrayList<String> parentList = $jsonArrayToSList(parentArr);
			ArrayList<String> childList = $jsonArrayToSList(childArr);
			parentList.removeAll(childList);
			notInArr = $sListToJsonArray(parentList);
		} catch (Exception e) {
			notInArr = null;
		}
		return notInArr;
	}

	// #BVB00100 Ends
	// #BVB00101 Starts
	public boolean isValidTimeZone(String dt, String zone) {
		boolean isValidTz = false;
		try {
			// dt.contains(zone); //dt.substring(Math.max(0, dt.length() -5));
			if (dt.contains(zone)) {
				isValidTz = true;
			} else {
				isValidTz = false;
			}

		} catch (Exception e) {
			logger.debug("Failed in Validating time zone: " + e.getMessage());
			isValidTz = false;
		}
		return isValidTz;
	}
	// #BVB00101 Ends

	public JsonObject objFromArrWithSearch(JsonArray inArray, String searchFld, String searchVal) {
		JsonObject foundObj = new JsonObject();
		try {

			for (int i = 0; i < inArray.size(); i++) {
				JsonObject i$runningObj = inArray.get(i).getAsJsonObject();
				if (i$runningObj.has(searchFld)) {
					if (I$utils.$iStrFuzzyMatch(i$runningObj.get(searchFld).getAsString(), searchVal)) {
						foundObj = i$runningObj;
						break;
					}
				}
			}
		} catch (Exception e) {
			logger.debug("Failed in objFromArrWithSearch: " + e.getMessage());
			foundObj = null;
		}

		return foundObj;
	}
	
	public boolean existObjFromArrWithSearch(JsonArray inArray, String searchFld, String searchVal) {
		try {

			for (int i = 0; i < inArray.size(); i++) {
				JsonObject i$runningObj = inArray.get(i).getAsJsonObject();
				if (i$runningObj.has(searchFld)) {
					if (I$utils.$iStrFuzzyMatch(i$runningObj.get(searchFld).getAsString(), searchVal)) {
						return true; 
					}
				}
			}
		} catch (Exception e) {
			logger.debug("Failed in objFromArrWithSearch: " + e.getMessage());
		}

		return false;
	}

	public double calculateDistanceBetweenPoints(double x1, double y1, double x2, double y2) {
		return Math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));
	}

// #BVB00141 Starts 
	public JsonArray sLdD(String inString, int setLength, int distance) {
		JsonArray microns = new JsonArray();
		String subStr = "";
		try {
			inString = inString.toUpperCase();
			inString = removeAllSpcChars(inString);
			for (int i = 0; i < inString.length(); i++) {
				subStr = getMacrons(inString, i, setLength, distance);
				if (subStr != null) {
					microns.add(subStr);
				}
			}

			// logger.debug("microns: " + gson.toJson(microns));

		} catch (Exception e) {

		}
		return microns;
	}

	public static String getMacrons(String inString, int index, int setLength, int distance) {
		String runningStr = "";
		try {
			String twiceString = inString + inString;
			char[] inStringChArr = twiceString.toCharArray();

			int position = index;
			int iterations = 0;

			while (iterations < setLength) {
				runningStr = runningStr + inStringChArr[position];
				position = position + distance;
				iterations++;
			}
		} catch (Exception e) {
			runningStr = null;
		}
		return runningStr;
	}

	public JsonArray sLdDTrn(String inString, int setLength, int distance) {
		JsonArray microns = new JsonArray();
		String subStr = "";
		try {
			inString = inString.toUpperCase();
			inString = removeAllSpcChars(inString);
			for (int i = 0; i < inString.length(); i++) {
				subStr = getMacronsTrn(inString, i, setLength, distance);
				if (subStr != null) {
					microns.add(subStr);
				}
			}

			// logger.debug("microns: " + gson.toJson(microns));

		} catch (Exception e) {

		}
		return microns;
	}

	public String getMacronsTrn(String inString, int index, int setLength, int distance) {
		String runningStr = "";
		try {
			String twiceString = inString + inString;
			char[] inStringChArr = twiceString.toCharArray();

			int position = index;
			int iterations = 0;

			while (iterations < setLength) {
				runningStr = runningStr + inStringChArr[position];
				position = position + distance;
				iterations++;
			}
		} catch (Exception e) {
			runningStr = null;
		}
		return "$" + runningStr;
	}

	// #BVB00141 Ends
	// #BVB00139 Starts
	public JsonArray refineFunctionAccess(JsonArray funcAccArr) {
		JsonArray refineFuncAcc = new JsonArray();
		boolean found = false;

		try {
			for (int i = 0; i < funcAccArr.size(); i++) {
				found = false;
				JsonObject i$runningObjI = funcAccArr.get(i).getAsJsonObject();
				for (int j = 0; j < refineFuncAcc.size(); j++) {
					JsonObject i$runningObjJ = refineFuncAcc.get(j).getAsJsonObject();
					JsonObject i$runningAcc = new JsonObject();

					if (i$runningObjI.get("function_id").getAsString()
							.equals(i$runningObjJ.get("function_id").getAsString())) {
						found = true;
						String funcId = i$runningObjJ.get("function_id").getAsString();
						Set<Entry<String, JsonElement>> accessJ = i$runningObjJ.entrySet();
						Set<Entry<String, JsonElement>> accessI = i$runningObjI.entrySet();

						for (Map.Entry<String, JsonElement> entryI : accessI) {
							for (Map.Entry<String, JsonElement> entryJ : accessJ) {
								if (entryI.getKey().equals(entryJ.getKey())) {
									String currKey = entryI.getKey();
									boolean currVal = (i$runningObjI.get(currKey).getAsBoolean()
											|| i$runningObjJ.get(currKey).getAsBoolean());
									i$runningAcc.addProperty(currKey, currVal);
								}
							}

						}
						i$runningAcc.addProperty("function_id", funcId);
						// add it to the
						refineFuncAcc.remove(j);
						refineFuncAcc.add(i$runningAcc);
					}

				}
				if (!found) {
					refineFuncAcc.add(i$runningObjI);
				}

			}
		} catch (Exception e) {

		}
		return refineFuncAcc;
	}

// #BVB00139 Ends
	public String removeAllSpcChars(String inString) {
		try {
			inString = inString.replaceAll("[^a-zA-Z0-9]", "");
		} catch (Exception e) {
			inString = null;
		}
		return inString;
	}

	// MAQ00018 starts
	public Boolean checkPassHist(String getPass, JsonObject i$PassHist, JsonObject J$userdet) {
		Boolean passMatch = false;
		try {

			if (i$PassHist != null) {
				JsonArray hist = i$PassHist.get("passHist").getAsJsonArray();
				int passMatchNo = J$userdet.get("passHist").getAsInt();
				if (passMatchNo > hist.size()) {
					passMatchNo = hist.size();
				}
				for (int i = (hist.size() - 1); i >= (hist.size() - passMatchNo); i--) {
					String tSaltPass = hist.get(i).getAsString();
					String[] saltPass = tSaltPass.split("_IMP_");
					String tSalt = saltPass[0];
					String encrytedPass = saltPass[1];
					String StrEncPass = generateSecurePassword(getPass, tSalt);
					if (I$utils.$iStrFuzzyMatch(StrEncPass, encrytedPass)) {
						passMatch = true;
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return passMatch;
	}
	// MAQ00018 ends

	// #NYE00014 Begins
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg) {
		JsonArray jAdata = new JsonArray();
		JsonArray jDAdata = null;
		JsonObject jDObj = null; // #BHUVI002 Added
		String sFilterType = "$and";
		String sdFilterType = "$and"; // #BHUVI002 Added
		/*
		 * Filter Code 0 - Is Equal To 1 - Is Greater Than 2 - Is Less Than 3 - Is
		 * Greater or Equal To 4 - Is Lesser or Equal To 5 - Contains 6 - Begins With 7
		 * - Ends With 8 - Not Contains 9- Is Not Equal To 10 - Not In
		 * 
		 * Type 0 - And 1 - Or Object Format dataSetFltr:{ "data": [ { "iField":
		 * "roleId", "iFilter": "0", "iValue": "TEM" }, { "iField": "authStat",
		 * "iFilter": "6", "iValue": "A" } ], "type": "0" }
		 */

		JsonObject j$DataFilter = new JsonObject();
		try {
			JsonArray jArry = new JsonArray();

			JsonObject j$DataFilterRes = new JsonObject();
			if (isonMsg.has(i$ResM.I_BDYTAG) && isonMsg.get(i$ResM.I_BDYTAG).getAsJsonObject().has(i$ResM.I_DSTFLTR)) {
				j$DataFilter = isonMsg.get(i$ResM.I_BDYTAG).getAsJsonObject().get(i$ResM.I_DSTFLTR).getAsJsonObject();
				// Found the Data Set Filter Tag
				jAdata = j$DataFilter.get("data").getAsJsonArray();
				// #BHUVI002 Changes Begin
				if (j$DataFilter.has("defdata"))
					jDAdata = j$DataFilter.get("defdata").getAsJsonArray();

				// #BHUVI002 Changes End

				// Type
				if (I$utils.$iStrFuzzyMatch(j$DataFilter.get("type").getAsString(), "1"))
					sFilterType = "$or";

				// #BHUVI002 Changes Begin
				// Def Type
				if ((j$DataFilter.has("dtype"))
						&& (I$utils.$iStrFuzzyMatch(j$DataFilter.get("dtype").getAsString(), "1")))
					sdFilterType = "$or";
				// #BHUVI002 Changes End

				// #NYE00015 Begins
				for (int i = 0; i < jAdata.size(); i++) {
					JsonObject jTmp = jAdata.get(i).getAsJsonObject();
					JsonObject jObj = new JsonObject();
					JsonObject jObjTmp = new JsonObject();
					// String Operations Begin
					if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "0")) {

						JsonArray jStrIntArr = new JsonArray();
						jObjTmp = new JsonObject();
						jObjTmp.addProperty(jTmp.get("iField").getAsString(), jTmp.get("iValue").getAsString());
						jStrIntArr.add(jObjTmp);
						try {
							Double dblTemp = jTmp.get("iValue").getAsDouble();
							jObjTmp = new JsonObject();
							jObjTmp.addProperty(jTmp.get("iField").getAsString(), dblTemp);
							jStrIntArr.add(jObjTmp);
						} catch (Exception ex) {
							// Not a Nyumber Val Ignore
						}
						;

						jObj.add("$or", jStrIntArr);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "6")) {
						jObjTmp.addProperty("$regex", "^" + jTmp.get("iValue").getAsString());
						jObjTmp.addProperty("$options", "si");
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "7")) {
						jObjTmp.addProperty("$regex", ".*(" + jTmp.get("iValue").getAsString() + ")$"); // #NYE00016
						jObjTmp.addProperty("$options", "si");
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "5")) {
						jObjTmp.addProperty("$regex", jTmp.get("iValue").getAsString());
						jObjTmp.addProperty("$options", "si");
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "8")) {
						jObjTmp.addProperty("$regex", "^((?!" + jTmp.get("iValue").getAsString() + ").)*$");
						jObjTmp.addProperty("$options", "si");
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					}
					// Numeric Logical Operator begin
					else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "1")) {
						Double dblVal = 0.00;
						try {
							dblVal = jTmp.get("iValue").getAsDouble();
						} catch (Exception ex) {
							j$DataFilter.addProperty("Invalid$Expr", "Invalid Filter Value "
									+ jTmp.get("iValue").getAsString() + " For Numeric Expression");
							return j$DataFilter;
						}

						jObjTmp.addProperty("$gt", dblVal);
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "2")) {
						Double dblVal = 0.00;
						try {
							dblVal = jTmp.get("iValue").getAsDouble();
						} catch (Exception ex) {
							j$DataFilter.addProperty("Invalid$Expr", "Invalid Filter Value "
									+ jTmp.get("iValue").getAsString() + " For Numeric Expression");
							return j$DataFilter;
						}
						jObjTmp.addProperty("$lt", dblVal);
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "3")) {
						Double dblVal = 0.00;
						try {
							dblVal = jTmp.get("iValue").getAsDouble();
						} catch (Exception ex) {
							j$DataFilter.addProperty("Invalid$Expr", "Invalid Filter Value "
									+ jTmp.get("iValue").getAsString() + " For Numeric Expression");
							return j$DataFilter;
						}
						jObjTmp.addProperty("$gte", dblVal);
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					} else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "4")) {
						Double dblVal = 0.00;
						try {
							dblVal = jTmp.get("iValue").getAsDouble();
						} catch (Exception ex) {
							j$DataFilterRes.addProperty("Invalid$Expr", "Invalid Filter Value "
									+ jTmp.get("iValue").getAsString() + " For Numeric Expression");
							return j$DataFilterRes;
						}
						jObjTmp.addProperty("$lte", dblVal);
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
					}else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "9")) {    //#PKY00026 starts

						String val =null;
						try {
							 val = jTmp.get("iValue").getAsString();
						}catch(Exception e) {
							j$DataFilterRes.addProperty("Invalid$Expr", "Invalid Filter Value "
									+ jTmp.get("iValue").getAsString() + " For Numeric Expression");
							return j$DataFilterRes;
						}
						jObjTmp.addProperty("$eq", val);//#TKS00015 changes
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
						
					}else if (I$utils.$iStrFuzzyMatch(jTmp.get("iFilter").getAsString(), "10")) {   

						JsonArray value = new JsonArray();
						try {
							value = jTmp.get("iValue").getAsJsonArray();
						}catch(Exception e) {
							j$DataFilterRes.addProperty("Invalid$Expr", "Invalid Filter Value "
									+ jTmp.get("iValue").getAsString() + " For Numeric Expression");
							return j$DataFilterRes;
						}
						jObjTmp.add("$nin", value);
						jObj.add(jTmp.get("iField").getAsString(), jObjTmp);
						jArry.add(jObj);
						
					}//#PKY00026 ends
				}
				// #NYE00015 Ends
				j$DataFilterRes.add(sFilterType, jArry);

				// #BHUVI002 Changes Begin
				if (jDAdata != null && jDAdata.size() > 0) {
					JsonArray jdefArr = new JsonArray();
					JsonObject jDObj1 = new JsonObject();
					jDObj = new JsonObject();
					jDObj.add(sdFilterType, jDAdata);
					jdefArr.add(jDObj);
					jdefArr.add(j$DataFilterRes);
					jDObj1.add("$and", jdefArr);
					return jDObj1;
				} else
					return j$DataFilterRes;
				// #BHUVI002 Changes End
			} else
				return null;
		} catch (Exception e) {
			logger.debug(" Error in get$FrmDataSetFilter -" + e.getMessage());
			return null;
		}
	}

	// MAQ00019 starts
	public Boolean checkPassPolicy(String getPass, JsonObject j$userdet) {
		Boolean passPolicyMet = true;
		if (getPass.length() < j$userdet.get("minchar").getAsInt()
				|| getPass.length() > j$userdet.get("maxchar").getAsInt()) {
			passPolicyMet = false;
		}
		try {
			String regex = "(\\S)(\\1+)";
			Pattern r = Pattern.compile(regex);
			Matcher m = r.matcher(getPass);
			while (m.find()) {
				if (m.group().length() > j$userdet.get("maximumconse").getAsInt()) {
					passPolicyMet = false;
				}
			}
		} catch (Exception e) {
			logger.debug(" Error in passwordpolicy check -" + e.getMessage());
		}
		try {
			String regex = "([-!$%^&*()_+|~=`{}\\\\[\\\\]:\\/;<>?,.@#]{1})";
			int count = PatternMatcherCount(regex, getPass);
			if (count < j$userdet.get("minispe").getAsInt()) {
				passPolicyMet = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(" Error in passwordpolicy check -" + e.getMessage());
		}
		try {
			String regex = "([0123456789]{1})";
			int count = PatternMatcherCount(regex, getPass);
			if (count < j$userdet.get("mininum").getAsInt()) {
				passPolicyMet = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(" Error in passwordpolicy check -" + e.getMessage());
		}
		try {
			String regex = "([a-z]{1})";
			int count = PatternMatcherCount(regex, getPass);
			if (count < j$userdet.get("minilower").getAsInt()) {
				passPolicyMet = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(" Error in passwordpolicy check -" + e.getMessage());
		}
		try {
			String regex = "([A-Z]{1})";
			int count = PatternMatcherCount(regex, getPass);
			if (count < j$userdet.get("miniupper").getAsInt()) {
				passPolicyMet = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(" Error in passwordpolicy check -" + e.getMessage());
		}
		return passPolicyMet;
	}

	public int PatternMatcherCount(String regex, String target) {
		int count = 0;
		try {
			Pattern r = Pattern.compile(regex);
			Matcher m = r.matcher(target);
			while (m.find()) {
				count++;
			}
		} catch (Exception e) {
			logger.debug(" Error in PatternMatcherCount -" + e.getMessage());
		}
		return count;
	}
	// MAQ00019 starts

	// #NYE00014 Ends
	// #BVB00177 Starts
	public JsonObject flattenJsonObject(JsonObject isonMapJson) {
		return flattenJsonObject("", isonMapJson);
	}

	public JsonObject flattenJsonObject(String prefix, JsonObject isonMapJson) {
		JsonObject mergedObject = new JsonObject();
		Gson gson = new Gson();
		try {

			Set<Entry<String, JsonElement>> entrySet = isonMapJson.entrySet();

			for (Map.Entry<String, JsonElement> entry : entrySet) {
				if (isonMapJson.get(entry.getKey()).isJsonArray()) {
					// attributes.put(entry.getKey(),
					// isonMapJson.get(entry.getKey()).getAsJsonArray());
				} else if (isonMapJson.get(entry.getKey()).isJsonObject()) {
					// attributes.put(entry.getKey(),
					// isonMapJson.get(entry.getKey()).getAsJsonObject());
					JsonObject return1 = flattenJsonObject(entry.getKey(),
							isonMapJson.get(entry.getKey()).getAsJsonObject());
					// logger.debug("res: " + gson.toJson(return1));
					Set<Entry<String, JsonElement>> entrySet1 = return1.entrySet();
					for (Map.Entry<String, JsonElement> entry1 : entrySet1) {
						if (prefix.equals(""))
							mergedObject.addProperty(entry1.getKey(), return1.get(entry1.getKey()).getAsString());
						else
							mergedObject.addProperty(prefix + "." + entry1.getKey(),
									return1.get(entry1.getKey()).getAsString());
					}
				} else {
					if (prefix.equals(""))
						mergedObject.addProperty(entry.getKey(), isonMapJson.get(entry.getKey()).getAsString());
					else
						mergedObject.addProperty(prefix + "." + entry.getKey(),
								isonMapJson.get(entry.getKey()).getAsString());
				}

			}

		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed in Merging Object with" + e.getMessage());
			mergedObject = null;
		}

		return mergedObject;
	}

	public boolean hasStringInKey(JsonObject isonMsg, String searchString) {
		boolean found = false;
		try {
			Set<Entry<String, JsonElement>> entrySet = isonMsg.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				if (entry.getKey().contains(searchString)) {
					found = true;
				}
			}
		} catch (Exception e) {
			found = true;
		}
		return found;
	}

	// #BVB00177 Ends
	// #BVB00181 Starts
	public String trimDate(String inDate) {
		try {
			if (inDate.contains(" 00:00:00.0")) {
				inDate = inDate.replace(" 00:00:00.0", "");
			}
		} catch (Exception e) {
			// Eat Up
		}
		return inDate;
	}

	// #BVB00181 Ends
	// #BVB00189 Starts
	public boolean checkMandFeilds(JsonObject argJson, JsonArray mandFields) {
		try {
			for (int i = 0; i < mandFields.size(); i++) {
				if (I$utils.$isNull(argJson.get(mandFields.get(i).getAsString()))) {
					return false;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	// #BVB00189 Ends
	// #BVB00193 Starts
	public String replaceAll(String sTmpl, String key, String keyVal) {
		try {
			keyVal = keyVal.replace("$", "*#*#");
			sTmpl = sTmpl.replaceAll(key, keyVal);
			sTmpl = sTmpl.replace("*#*#", "$");
		} catch (Exception e) {
			logger.debug("Failed in replaceAll: " + e.getMessage());
		}
		return sTmpl;

	}

	// #BVB00193 Ends
	// #BVB00197 Starts
	public String dateFormatter(String inDate, String inFormat, String outFormat) {
		try {
			SimpleDateFormat dmyFormat = new SimpleDateFormat(inFormat);
			SimpleDateFormat cntDate = new SimpleDateFormat(outFormat);
			Date orDate;

			orDate = dmyFormat.parse(inDate);

			return cntDate.format(orDate);

		} catch (Exception e) {
			return "";
		}
	}

	public String dateFormatter(String inDate) {
		try {
			SimpleDateFormat dmyFormat = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
			Date orDate;

			orDate = dmyFormat.parse(inDate);

			return cntDate.format(orDate);

		} catch (Exception e) {
			return inDate;
		}
	}

	// #BVB00197 Ends
	// #BVB00202 Starts
	public boolean verifyObjectConditions(JsonObject searchInObj, JsonObject searchObj) {
		boolean isValid = false;
		try {
			Set<Entry<String, JsonElement>> entrySet = searchObj.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				try {
					if (searchInObj.has(entry.getKey())) {
						if (searchInObj.get(entry.getKey()).isJsonPrimitive()) {
							if (!searchObj.get(entry.getKey()).isJsonArray()) { // #BVB00208
								if (I$utils.$iStrFuzzyMatch(searchInObj.get(entry.getKey()).getAsString(),
										searchObj.get(entry.getKey()).getAsString())) {
									isValid = true;
								}
							} // #BVB00208 Starts
							else {
								isValid = I$utils.isInArray(searchObj.get(entry.getKey()).getAsJsonArray(),
										searchInObj.get(entry.getKey()).getAsString());
							} // #BVB00208 Ends
						} else if (searchInObj.get(entry.getKey()).isJsonObject()) {
							isValid = verifyObjectConditions(searchInObj.get(entry.getKey()).getAsJsonObject(),
									searchObj.get(entry.getKey()).getAsJsonObject());
						}
					} else {
						isValid = false;
					}

					if (!isValid) {
						break;
					}

				} catch (Exception e) {
					isValid = false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			isValid = false;
		}
		return isValid;
	}

	// #BVB00202 Ends
	public String xmlEscapeText(String decodedXml) {
		try {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < decodedXml.length(); i++) {
				char c = decodedXml.charAt(i);
				switch (c) {
//		      case '<': sb.append("&lt;"); break;
//		      case '>': sb.append("&gt;"); break;
//		      case '\"': sb.append("&quot;"); break;
				case '&':
					// sb.append("&amp;");// #BVB00216
					sb.append("IMP1amp"); // #BVB00216
					break;
//		      case '\'': sb.append("&apos;"); break;
				default:
					if (c > 0x7e) {
						sb.append("&#" + ((int) c) + ";");
					} else
						sb.append(c);
				}
			}
			return sb.toString();
		} catch (Exception e) {
			return null;
		}
	}

	public boolean dateFormatVerifier(String inDate, String format) {
		try {
			SimpleDateFormat cntDate = new SimpleDateFormat(format);
			cntDate.setLenient(false);

			Date orDate = cntDate.parse(inDate);
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	public JsonObject xmlParser(String xmlStr) {
		String result = "";
		try {
			JsonParser parser = new JsonParser();
			result = U.xmlToJson(xmlStr);
			return parser.parse(result).getAsJsonObject();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public JsonArray getSystemIP() {
		JsonArray systemIps = new JsonArray();
		try {
			Enumeration<NetworkInterface> n = NetworkInterface.getNetworkInterfaces();
			for (; n.hasMoreElements();) {
				NetworkInterface e = n.nextElement();
				// System.out.println("Interface: " + e.getName());
				Enumeration<InetAddress> a = e.getInetAddresses();
				for (; a.hasMoreElements();) {
					InetAddress addr = a.nextElement();
					if (addr instanceof Inet4Address) {
						if (!I$utils.$iStrFuzzyMatch(addr.getHostAddress(), "127.0.0.1")) {
							systemIps.add(addr.getHostAddress());
						}
					}
				}
			}
		} catch (Exception e) {

		}
		return systemIps;
	}

	public boolean isValIp(JsonObject otpSystemAdmin) {
		boolean isValIp = false;
		try {
			
			String valReq = i$ResM.getStrfromObjWithDefault(otpSystemAdmin, "IPValRequired", "N");
			if (I$utils.$iStrFuzzyMatch(valReq, "Y")) {
				String ValMode = i$ResM.getStrfromObjWithDefault(otpSystemAdmin, "IPValMode", "D");
				JsonArray ipList = i$ResM.getArrfromObj(otpSystemAdmin, "IPList");
				JsonArray systemIpList = getSystemIP();
				for (int i = 0; i < systemIpList.size(); i++) {
					if (I$utils.$iStrFuzzyMatch(ValMode, "A")) {
						if (I$utils.isInArray(ipList, systemIpList.get(i).getAsString())) {
							isValIp = true;
							break;
						}
					} else {
						if (!I$utils.isInArray(ipList, systemIpList.get(i).getAsString())) {
							isValIp = true;
						}else {
							isValIp = false;
							break;
						}
					}
				}
			}else {
				isValIp = true;
			}
		} catch (Exception e) {
			isValIp = false;
		}
		return isValIp;
	}
	
	public String unzipGZipResonse(Response response) {
		try {
			//byte[] readBuffer = new byte[320000]; 
			byte[] tBytes = response.body().bytes();
			GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(tBytes));
			InputStreamReader reader = new InputStreamReader(gzip);
			BufferedReader in = new BufferedReader(reader);
			String message = in.readLine();
			// System.out.println(message);			
			
			//int read = gzip.read(readBuffer, 0, readBuffer.length);
			gzip.close();
			// Should hold the original (reconstructed) data
			//byte[] result = Arrays.copyOf(readBuffer, read);
			// Decode the bytes into a String
			//return new String(result, "UTF-8");
			return message; 
		} catch (Exception e) {
			return null; 
		}
	}
	public boolean msgCodeEntry(String sMsgCode) {
		boolean msgCodeEntry = false;
		try {
			
		
		JsonObject parentMsgCode = objFromArrWithSearch(i$ResM.getGobalValArr("parentMsgs"), "msgcode", sMsgCode); 
	    JsonObject requestMsgCodes = objFromArrWithSearch(i$ResM.getConfArr(i$ResM.getGobalValJObj("request")), "msgcode", sMsgCode);
		if(!I$utils.$isNullOrEmpty(parentMsgCode) && 
				I$utils.$iStrFuzzyMatch(parentMsgCode.get("conReq").getAsString(),"Y")){
			if(!I$utils.$isNullOrEmpty(requestMsgCodes) && 
					I$utils.$iStrFuzzyMatch(requestMsgCodes.get("conRec").getAsString(),"Y")) {
				msgCodeEntry = true; 
			}
		}
		} catch (Exception e) {
			
		}
		return msgCodeEntry; 
	}
	//SBC0087 STARTS
	
	
	//SBC0087 ENDS
	
}
// #00000001 Ends
