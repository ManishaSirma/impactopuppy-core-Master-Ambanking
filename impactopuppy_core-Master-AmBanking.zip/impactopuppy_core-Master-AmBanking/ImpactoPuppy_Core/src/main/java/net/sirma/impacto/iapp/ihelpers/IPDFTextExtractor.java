/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date          | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Samadhan 		| Jan 02, 2022  | #SRP00067   | Initial writing
      |0.1 Beta	   | Manikanta		| Jan 12, 2023  | #MVT00100   | Added code to extract pdf table contents
      |0.1 Beta	   | Manikanta		| Mar 01, 2023  | #MVT00109   | Changed the code to handle array out of bound index excep#MVT00127 tion
      |0.1 Beta    | Manikanta      | Jul 06, 2023  | #MVT00127   | Added code for dynamic pdf creatiion
      |0.1 Beta    | Madhura        | July 18,2023  | #MSA00024   | Added code for Risk Profiling report
      |0.1 Beta    | Madhura        | July 24,2023  | #MSA00025   | Added code for Black list and White list report
      |0.1 Beta    | Sumit          | Dec 04 2023   | #SKG00038    | Added code for  risk profile modifications     
 ----------------------------------------------------------------------------------------------
      
*/
// #SRP00067 Begins
package net.sirma.impacto.iapp.ihelpers;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.spire.pdf.PdfDocument;
import com.spire.pdf.PdfDocumentInformation;
import com.spire.pdf.PdfFileInfo;
import com.spire.pdf.utilities.PdfTable;
import com.spire.pdf.utilities.PdfTableExtractor;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URI;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.imageio.ImageIO;

import net.sirma.impacto.iapp.iconfig.PropLoader;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.ILedZ.ILeadAppController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;


//This is an example on how to get the x/y coordinates and size of each character in PDF

public class IPDFTextExtractor extends PDFTextStripper{

	public IPDFTextExtractor() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	private IResManipulator i$ResM = new IResManipulator();
	private static final Ioutils I$utils = new Ioutils();
	private DBController db$Ctrl = new DBController();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	private Ioutils I$Ioutils = new Ioutils();
	private static final Logger logger = LoggerFactory.getLogger(ILeadAppController.class);
	private static Font COURIER = new Font(Font.FontFamily.COURIER, 20, Font.BOLD);
	private static Font COURIER_SMALL = new Font(Font.FontFamily.COURIER, 16, Font.BOLD);
	private static Font COURIER_SMALL_FOOTER = new Font(Font.FontFamily.COURIER, 12, Font.BOLD);

	JsonArray res = new JsonArray();
	JsonObject keys=new JsonObject();
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "EXTRACTION")) {
				isonMsg = PDFBOX(isonMsg);
			} else if(I$utils.$iStrFuzzyMatch("SUMMARY", SrvOpr)) {//#MVT00100 BEGINS
				isonMsg = tableSummary(isonMsg);
			}
			else {
				isonMsg = readPdfTable(isonMsg);//#MVT00100 ENDS
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};
	//#MVT00127 begins
	public JsonObject generatePDFReport(JsonObject isonMsg) {
		try {
			JsonObject resp = new JsonObject();
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.A4.rotate(), 0.75F, 0.75F, 0.75F, 0.75F);
			document.setMargins(10, 10, 150, 50);
			PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
			HeaderPageEvent headerEvent = new HeaderPageEvent();
			writer.setPageEvent(headerEvent);
			headerEvent.onStartPage(writer, document);
			document.open();
//			document.addHeader(LINE_SEPARATOR, LINE_SEPARATOR);
//			addLogo(document);
//			addDocTitle(document, ibody.get("ReportType").getAsString());
//			createTable(document, isonMsg, ibody.get("noOfColumns").getAsInt());
//			addFooter(document);
//				leaveEmptyLine(paragraph, 3);
//				document.add(paragraph);
			JsonArray columns = ibody.getAsJsonArray("columns");
			JsonArray columnNames = ibody.getAsJsonArray("columnNames");
			PdfPTable table = new PdfPTable(ibody.get("noOfColumns").getAsInt());// SKG00038 changes
			if (ibody.get("noOfColumns").getAsInt() > 0) {
				table = new PdfPTable(ibody.get("noOfColumns").getAsInt());
				for (int i = 0; i < ibody.get("noOfColumns").getAsInt(); i++) {
					try {
						PdfPCell cell = new PdfPCell(new Phrase(columnNames.get(i).getAsString()));
						cell.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell.setBackgroundColor(BaseColor.WHITE);
						table.addCell(cell);
					} catch (Exception e) {
					}
				} // SKG00038 starts
				if (isonMsg.getAsJsonObject("i-body").getAsJsonArray("rowData").size() > 0) {
					table.setHeaderRows(1);
				}else {
					table.setWidthPercentage(100);
				}
			}
			PdfPTable table1 = new PdfPTable(1);
			if (isonMsg.getAsJsonObject("i-body").getAsJsonArray("rowData").size() <= 0) {
				table1.setWidthPercentage(100);
				table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				table1.getDefaultCell().setFixedHeight(100);
				table1.addCell(new Paragraph("No records found !!"));
			} else {
				getDbData(table, isonMsg, document);
			}
			document.add(table);
			document.add(table1); // SKG00038 end
			document.close();
			int pageCount = writer.getPageNumber();
			byte[] pdfAsBytes = byteArrayOutputStream.toByteArray();
			Font smallFont = FontFactory.getFont("Arial", 13, Font.NORMAL);
			Font smallFont2 = FontFactory.getFont("Arial", 16, Font.BOLD);
			PdfReader reader = new PdfReader(pdfAsBytes);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			DataOutputStream output = new DataOutputStream(outputStream);
			document = new Document();
			document.open();
			PdfStamper stamper = new PdfStamper(reader, output);
			for (int i = 1; i <= pageCount; i++) {
				ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_LEFT,
						new Phrase(ibody.get("ReportType").getAsString(), smallFont2), 10, 470, 0);

				ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_CENTER,
						new Phrase(i + "/" + pageCount, smallFont), 400, 30, 0);
			}
			stamper.close();
			byte[] finalPdfAsBytes = outputStream.toByteArray();
//			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64String = java.util.Base64.getEncoder().encodeToString(finalPdfAsBytes);
//			resp.addProperty("fileName", ibody.get("ReportType").getAsString());
			resp.addProperty("fileName", ibody.get("fileName").getAsString());
			resp.addProperty("report", base64String);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}
	private void createTable(Document document,JsonObject isonMsg, int noOfColumns) throws DocumentException {
		JsonObject ibody = isonMsg.getAsJsonObject("i-body"); 
		Paragraph paragraph = new Paragraph();
		
		leaveEmptyLine(paragraph, 3);
		document.add(paragraph);
		JsonArray  columns = ibody.getAsJsonArray("columns");
		JsonArray  columnNames = ibody.getAsJsonArray("columnNames"); //MVT


		PdfPTable table = new PdfPTable(noOfColumns);
//		List<String> columnNames=new ArrayList<String>();
//		columnNames.add("");
		
		for(int i=0; i<noOfColumns; i++) {
			PdfPCell cell = new PdfPCell(new Phrase(columnNames.get(i).getAsString()));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(BaseColor.YELLOW);
			table.addCell(cell);
		}

		table.setHeaderRows(1);
		getDbData(table, isonMsg, document);
		document.add(table);
	}
	
	public void getDbData(PdfPTable table, JsonObject isonMsg, Document document) {
		try {
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");
			JsonArray columns = ibody.getAsJsonArray("columns");
			JsonArray dbRowData = ibody.getAsJsonArray("rowData");
			int index = 1;
//			if (dbRowData.size() <= 0) {
//				PdfPTable table1 = new PdfPTable(1);
//				table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//				table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
//				table1.addCell(new Paragraph("No records found !!"));
//				document.add(table1);
//			} else {
//                int dbIteration = 0;
//                if(dbRowData.size() < 500) {
//                    dbIteration = dbRowData.size();
//                }else {
//                    dbIteration = 500;
//                }
			for (int i = 0; i < dbRowData.size(); i++) {
				try {
					JsonObject row = dbRowData.get(i).getAsJsonObject();
					for (int j = 0; j < columns.size(); j++) {
						try {
							table.setWidthPercentage(100);
							table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
							if (j == 0) {
								table.addCell(String.valueOf(index++));
								continue;
							}
							table.addCell(row.get(columns.get(j).getAsString()).getAsString());
						} catch (Exception e) {
							logger.debug(e.getMessage());
						}
					}
				} catch (Exception e) {
				}
//                    List<String> list = new ArrayList<String>();
//                    for (String rowData : list) {
//                        table.setWidthPercentage(100);
//                        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//                        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				//
//                        table.addCell(employee.getEmpId().toString());
//                        table.addCell(employee.getEmpName());
//                        table.addCell(employee.getEmpDept());
//                        table.addCell(currencySymbol + employee.getEmpSal().toString());
//                    }
			}
//            }
		} catch (Exception e) {
			e.getMessage();
		}
	}
		
	public void addDocTitle(Document document, String fileName) throws DocumentException {
		try {
		String localDateString = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
		Paragraph p1 = new Paragraph();
		leaveEmptyLine(p1, 1);
		p1.add(new Paragraph(fileName, COURIER));
		p1.setAlignment(Element.ALIGN_CENTER);
//		leaveEmptyLine(p1, 1);
//		p1.add(new Paragraph("Report generated on " + localDateString, COURIER_SMALL));
		document.add(p1);

		}catch(Exception e) {
			logger.debug(e.getMessage());
		}
	}
	
	private void addFooter(Document document) throws DocumentException {
		Paragraph p2 = new Paragraph();
		leaveEmptyLine(p2, 3);
		p2.setAlignment(Element.ALIGN_MIDDLE);
		p2.add(new Paragraph(
				"------------------------" + document.getPageNumber() +"------------------------", 
				COURIER_SMALL_FOOTER));
		
		document.add(p2);
	}
	
//	private void addLogo(Document document) {  //MVT000111 starts
//        try {
////        	URL url = new URL("http://www.yahoo.com/image_to_read.jpg");
////        	InputStream in = new BufferedInputStream(url.openStream());
////        	BufferedImage bf = ImageIO.read(in);
////            Image img = Image.getInstance("");
//        	
//            Image img = Image.getInstance("https://tech-u.tecutt.com/resources/images/logo/logo_login_lg.png");
//            img.scaleAbsolute(110, 80);
//			img.setAlignment(Element.ALIGN_CENTER);
//
//            document.add(img);
//        } catch (DocumentException | IOException e) {
//            e.printStackTrace();
//        }      
//    } //MVT000111 ends
	public static void leaveEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}
	//#MVT00127 ends
	//#MVT00100 begins
	public JsonObject readPdfTable(JsonObject isonMsg) {
		try {
			JsonArray tableData = new JsonArray();
			JsonArray content = new JsonArray();
			JsonObject data = new JsonObject();
			JsonObject updateObject = new JsonObject();
			
			try {
				String licence_key = PropLoader.env.getProperty("spire.pdf.licenceKey");
				com.spire.license.LicenseProvider.setLicenseKey(licence_key);
				i$ResM.setGobalVals("spire.pdf.licenceKey", licence_key);
			} catch (Exception e) {
				logger.debug(e.getMessage());
			}	
			
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			String base64= ibody.get("pdfData").getAsString();
//			String temp = I$utils.getBase64(base64);
			byte[] decodedBytes = Base64.decode(base64);
			long id = I$Imputils.generateRandomLong(15);
			
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ PDF Reading Started");
			PdfDocument pdf = new PdfDocument(decodedBytes);
	        PdfTableExtractor extractor = new PdfTableExtractor(pdf);
	        
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ PDF pages Reading"+pdf.getPages().getCount());
	        try{
	        	for (int pageIndex = 0; pageIndex < pdf.getPages().getCount(); pageIndex++) {
	        		PdfTable[] tableLists = extractor.extractTable(pageIndex);
	            
	        		if (tableLists != null && tableLists.length > 0) {
	        			for (PdfTable table : tableLists) {
	        				//Loop through the rows in the current table
	        				int a = table.getRowCount();
	        				logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ table row count"+a);
	        				for (int i = 0; i < table.getRowCount(); i++) {
	        					data = new JsonObject();
	        					//Loop through the columns in the current table
	        					for (int j = 0; j < table.getColumnCount(); j++) {
	        						//Extract data from the current table cell and append to the StringBuilder
	        						String text = table.getText(i, j);
	        						if(i==0) {
	        							content.add(text);
//	        							logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$  Reading spire text"+content);
	        						} else {
	        							data.addProperty(content.get(j).getAsString(), text);
	        						}
	        					}
	        					if(!I$utils.$isNull(data)){
	        						tableData.add(data);
	        					}
	        				}
	        			}
	        		}
	        	}
	        } catch(Exception e) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Data Is Missing", e.getMessage().toString());
				e.printStackTrace();
			}
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ PDF Reading Completed"+ tableData);

	        updateObject.addProperty("pdfTableId", "PDF"+ id);
	        updateObject.addProperty("CreatedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
	        updateObject.add("tableContent", tableData);
	        isonMsg = db$Ctrl.db$InsertRow("ICOR_M_PDF_TABLE_DATA", updateObject);
	        
	        isonMsg.get("i-body").getAsJsonObject().remove("tableContent");
	        ibody.addProperty("pdfTableId", "PDF"+ id);	        
		} catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}
	
	public JsonObject tableSummary(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonArray contents = new JsonArray();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			filter.addProperty("pdfTableId", ibody.get("pdfTableId").getAsString());
			JsonObject app$Json = db$Ctrl.db$GetRow("ICOR_M_PDF_TABLE_DATA", filter);
			JsonArray tableData = app$Json.get("tableContent").getAsJsonArray();
			
			int pageNo = ibody.get("intPgNo").getAsInt();
			int limit = ibody.get("intRecs").getAsInt();
			if(tableData.size()<limit) {	//#MVT00109 changes starts
				limit = tableData.size();
			}
			int skip = pageNo*limit;	//#MVT00109 changes ends
			for(int i=skip;i< (skip+limit);i++) {
				JsonObject content = new JsonObject();
				content = tableData.get(i).getAsJsonObject();
				contents.add(content);
			}
			ibody.addProperty("iRowCnt", tableData.size());
			ibody.add("iRowData", contents);
			
		} catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}
	//#MVT00100 ends
	public JsonObject PDFBOX(JsonObject isonMsg) throws InvalidPasswordException, IOException{
		try {
			
			PDDocument document = null;
			JsonObject pdfhelper=new JsonObject();
			JsonObject json=isonMsg.get("i-body").getAsJsonObject();
			String base64=json.get("pdf_data").getAsString();
			byte[] decodedBytes = Base64.decode(base64);
			try {
				document = PDDocument.load(decodedBytes);
				PDFTextStripper stripper = new IPDFTextExtractor();
				stripper.setSortByPosition(true);
				stripper.setStartPage(1);
				stripper.setEndPage(document.getNumberOfPages());

				Writer dummy = new OutputStreamWriter(new ByteArrayOutputStream());
				i$ResM.setGobalVals("isonMsg", isonMsg.getAsJsonObject());
				i$ResM.setGobalVals("resultObj", new JsonObject());
			    keys=i$ResM.getGobalValJObj("resultObj");
				stripper.writeText(document, dummy);
				try {
					keys.remove("");
					keys.remove("pdf_data");
				} catch (Exception e) {
				}
			} finally {
				if (document != null) {
					document.close();
				}
			}
		/**
		 * Override the default functionality of PDFTextStripper.writeString()
		 */
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
					i$ResM.getBody(isonMsg), "fields", keys);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA EXTRACT SUCCESSFULL");
		}catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SOMETHING WENT WRONG");
		}
		return isonMsg;
	}
	@Override
	protected void writeString(String string, List<TextPosition> textPositions) throws IOException {
	JsonObject isonMsg=i$ResM.getGobalValJObj("isonMsg");
	JsonObject jsonOb=i$ResM.getGobalValJObj("resultObj");
	JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
	JsonArray fieldArray = ibody.get("fields").getAsJsonArray();
	JsonObject fieldParameter = new JsonObject();
	for (int j = 0; j < fieldArray.size(); j++) {
		JsonObject funObject = fieldArray.get(j).getAsJsonObject();
		fieldParameter.add("Fields", funObject);
		JsonObject dataObj = fieldParameter;
		JsonObject data = dataObj.get("Fields").getAsJsonObject();
		
		int arr[] = { 1, 2 };
		if (Arrays.binarySearch(arr, getCurrentPageNo()) != -1) {
			String out = "";
			String currKey="";
			for (TextPosition text : textPositions) {
					JsonObject currFields = new JsonObject();
					String temp="";
					if (data.get("page_number").getAsInt() == getCurrentPageNo()) {
						if (text.getYDirAdj() > data.get("y_lesser").getAsInt() && text
								.getYDirAdj() < data.get("Y_greater").getAsInt()) {
							if (text.getXDirAdj() > data.get("x_lesser").getAsInt()
									&& text.getXDirAdj() < data.get("x_greater")
											.getAsInt()) {
//	              System.out.println(text.getUnicode()+ " [(X=" + text.getXDirAdj() + ",Y=" +
//	              text.getYDirAdj() + ") height=" + text.getHeightDir() + " width=" +
//	              text.getWidthDirAdj() + "]");
								 currKey = data.get("field_label").getAsString();
								if(!currFields.has(currKey)){
									currFields.addProperty(currKey, "");
								} 
							    temp = currFields.get(currKey).getAsString();
								temp = temp + text.getUnicode();
								out = out+temp;
							}
							if(currKey.equals("") && temp.equals("")) {
								continue;
							}else {
								currFields.addProperty(currKey, temp);
							}
							if(currFields.toString().equals("{}"))
							{
							  continue;
							}else {
							res.add(currFields);
							jsonOb.addProperty(currKey, temp);
							i$ResM.setGobalVals("resultObj",jsonOb);
							}
						}
					}
			}
			jsonOb.addProperty(currKey, out);
			i$ResM.setGobalVals("resultObj",jsonOb);
			if (!res.toString().equals("{}"))
				System.out.println(res.toString());
		}
	}
}
}
class HeaderFooterPageEvent extends PdfPageEventHelper {
    public void onCloseDocument(PdfWriter writer, Document document, ByteArrayOutputStream byteArrayOutputStream) throws DocumentException, IOException {
        int n = document.getPageNumber();
//        if (n > 0) {
//            ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER,new Phrase("page " + writer.getPageNumber()+"Of"), 550, 30, 0);
//        
       // }
        for (int i = 1; i <= n; i++) {
      	  ColumnText.showTextAligned(writer.getDirectContent(), 
      	    Element.ALIGN_CENTER, new Phrase(i+"/" + n), 550, 30, 0);
      }
        
/*     	byte[] pdfAsBytes = byteArrayOutputStream.toByteArray();
        PdfReader reader = new PdfReader(pdfAsBytes);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        DataOutputStream output = new DataOutputStream(outputStream);
        
        PdfStamper stamper = new PdfStamper(reader, output);
        for (int i = 1; i <= n; i++) {
        	  ColumnText.showTextAligned(stamper.getOverContent(i), 
        	    Element.ALIGN_CENTER, new Phrase(i+"/" + n), 550, 30, 0);
        }
        stamper.close();*/

    }
}
class HeaderFooterPageEvent2 extends PdfPageEventHelper {
    public void onStartPage(PdfWriter writer, Document document, String ReportType) {
        try {
            int pageNo = writer.getPageNumber();
            Image headerImg = null;
            RenderedImage renderedImage = null;
            ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
            if (pageNo >= 1) {
                try {
//                    renderedImage = generateImage("header");
//                    ImageIO.write(renderedImage, "jpg", byteImg);
//                    byte[] byteArr = byteImg.toByteArray();
                    headerImg = Image.getInstance("https://tech-u.tecutt.com/resources/images/logo/logo_login_lg.png");
                    headerImg.setAbsolutePosition(150, 700);
                    writer.getDirectContent().addImage(headerImg);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
        }
    }
}

class HeaderPageEvent extends PdfPageEventHelper {
//	private static final String LINE_SEPARATOR = null;
	private static Font COURIER = new Font(Font.FontFamily.COURIER, 20, Font.BOLD);

	public void onStartPage(PdfWriter writer, Document document) {
		try {
			int pageNo = writer.getPageNumber();
			Image headerImg = null;
			RenderedImage renderedImage = null;
			ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
			if (pageNo >= 0) {
				try {
					URL url = new URL("https://tech-u.tecutt.com/resources/images/logo/logo_login_lg.png");
					renderedImage = javax.imageio.ImageIO.read(url);
					ImageIO.write(renderedImage, "png", byteImg);
					byte[] byteArr = byteImg.toByteArray();
					headerImg = Image.getInstance(byteArr);
					headerImg.setAbsolutePosition(220, 500);
					headerImg.scaleAbsolute(300, 50);
					float width = headerImg.getScaledWidth();
					float height = headerImg.getScaledHeight();
					headerImg.setAlignment(Element.ALIGN_CENTER);
					writer.getDirectContent().addImage(headerImg);
				} catch (Exception e) {
					e.printStackTrace();
				}

				try {
					Paragraph p1 = new Paragraph();
					IPDFTextExtractor.leaveEmptyLine(p1, 3);
//					p1.add(new Paragraph("ABC", COURIER));
//					p1.setAlignment(Element.ALIGN_CENTER);
//					leaveEmptyLine(p1, 1);
//					p1.add(new Paragraph("Report generated on " + localDateString, COURIER_SMALL));
					writer.add(p1);
//					writer.getDirectContent().add
//					document.add(p1);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
		}
	}
}


//#SRP00067 Ends