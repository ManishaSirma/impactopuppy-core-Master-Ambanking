/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Baz 		| Oct 8th, 2018 | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Dec 10, 2018  | #BVB00026   | Added functions to handle -- iPortfolioClassification, iBucketization, iPDCalculation, iLgdAssignement, iReBucketization, iEclCalculation
      |0.2.1       | Vijay 		| Jan 18, 2019  | #BVB00039   | SDN Upload Changes
      |0.3.6       | Vijay 		| Apr 15, 2019  | #BVB00115   | Adding Generic Code for Thread Routing
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.ithreadworker.ICycleThreadWorker;
import net.sirma.impacto.iapp.iworkers.ithreadworker.IFileUploadWorker;
import net.sirma.impacto.iapp.iworkers.ithreadworker.ImongoUpdateWorker;
//import net.sirma.impacto.iapp.iworkers.ietldbworkers.IoracleEtlWorker;

public class IThreadController implements Runnable {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IThreadController.class); // Nye- Change Class Name
																				// always
	// **********************************************************************//

	private JsonObject jArgs;

	public IThreadController(JsonObject argJson) {
		this.jArgs = argJson;
	}

	public void iMongoUpdater(JsonObject argJson) {

		ImongoUpdateWorker iorcl = new ImongoUpdateWorker();
		iorcl.doCollUpdate(argJson);
	}

	// #BVB00026 Starts
	public void iPortfolioClassification(JsonObject argJson) {
		ICycleThreadWorker iCyleThreadWorker = new ICycleThreadWorker();
		iCyleThreadWorker.i$PortfolioClassification(argJson);
	}

	public void iBucketization(JsonObject argJson) {
		ICycleThreadWorker iCyleThreadWorker = new ICycleThreadWorker();
		iCyleThreadWorker.i$Bucketization(argJson);
	}

	public void iPDCalculation(JsonObject argJson) {
		ICycleThreadWorker iCyleThreadWorker = new ICycleThreadWorker();
		iCyleThreadWorker.i$PDCalculation(argJson);
	}

	public void iLgdAssignement(JsonObject argJson) {
		ICycleThreadWorker iCyleThreadWorker = new ICycleThreadWorker();
		iCyleThreadWorker.i$LgdAssignement(argJson);
	}

	public void iReBucketization(JsonObject argJson) {
		ICycleThreadWorker iCyleThreadWorker = new ICycleThreadWorker();
		iCyleThreadWorker.i$ReBucketization(argJson);
	}

	public void iEclCalculation(JsonObject argJson) {
		ICycleThreadWorker iCyleThreadWorker = new ICycleThreadWorker();
		iCyleThreadWorker.i$EclClaculation(argJson);

	}

	// #BVB00026 Ends
	// #BVB00039 Starts
	public void iFileUpload(JsonObject argJson) {
		IFileUploadWorker iFileUploadWorker = new IFileUploadWorker();
		iFileUploadWorker.processFile(argJson);
	}

	// #BVB00039 Ends
	@Override
	public void run() {

		try {
			// #BVB00026 Starts
			JsonObject argJson = this.jArgs;
			JsonObject isonMsg = argJson.getAsJsonObject("isonMsg");
			String ScrId = isonMsg.getAsJsonObject("i$response") .getAsJsonObject("response").getAsJsonObject("i-header").get("screenid").getAsString();
			String SOpr = i$ResM.getOpr(isonMsg);
			String SOpr1 = i$ResM.getOpr1(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			JsonObject globals = i$ResM.getObjfromObj(argJson, "globals"); 
			

			
			Set<Entry<String, JsonElement>> entrySet = globals.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				if(globals.get(entry.getKey()).isJsonArray()) {
					i$ResM.setGobalVals(entry.getKey(),globals.getAsJsonArray(entry.getKey()));  
				}else if(entry.getValue().isJsonObject()) {
					i$ResM.setGobalVals(entry.getKey(),globals.getAsJsonObject(entry.getKey()));
				}else if (entry.getValue().isJsonPrimitive()) {
					i$ResM.setGobalVals(entry.getKey(),globals.get(entry.getKey()).getAsString());
				}
			}
			
			if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr1, "iCycleMapping")
					&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE"))
				this.iPortfolioClassification(argJson);
			else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")
					&& I$utils.$iStrFuzzyMatch(SOpr1, "PORTFOLIOCLASSIFICATION")
					&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE"))
				this.iBucketization(argJson);
			else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr1, "BUCKETIZATION")
					&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE"))
				// this.iPDCalculation(argJson);
				this.iLgdAssignement(argJson);
			else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr1, "PDASSIGNMENT")
					&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE"))
				this.iReBucketization(argJson); // MAQ00003
			// this.iLgdAssignement(argJson);
			else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr1, "LGDASSIGNMENT")
					&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE"))
				this.iPDCalculation(argJson); // MAQ00003
			else if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr1, "REBUCKETIZATION")
					&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE"))
				this.iEclCalculation(argJson);

			// #BVB00026 Ends
			// #BVB00039 Starts
			else if (I$utils.$iStrFuzzyMatch(ScrId, "OB2SDNIM")) {
				this.iFileUpload(argJson);
			} 
			// #BVB00039 Ends
			// #BVB00115 Starts 
			else {
				String clsName = argJson.get("clsName").getAsString();
				String funcName = argJson.get("funcName").getAsString();

				Class<?> ctrlClass;
				ctrlClass = Class.forName(clsName);
				JsonObject result$ = null;
				Method ctrlFunc = null;
				ctrlFunc = ctrlClass.getMethod(funcName, JsonObject.class);
				Object ctrl$Caller = ctrlClass.newInstance();
				ctrlFunc.invoke(ctrl$Caller, isonMsg); // #BVB00068
			}
			// #BVB00115 Ends
		} catch (Exception e) {
			// Eat Up
			e.printStackTrace();
			logger.debug("Failed with error: " + e.getMessage());
		}

	}

	/*
	 * public class MyRunnable implements Runnable {
	 * 
	 * private int var;
	 * 
	 * public MyRunnable(int var) { this.var = var; }
	 * 
	 * public void run() { // code in the other thread, can reference "var" variable
	 * } }
	 */

}// #00000001 Ends
