/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Valla 		| Dec 20, 2018  | #00000001   | Initial writing
      |0.2.1       | Vijay 		| Mar 17, 2019  | #BVB00096   | Biometrics verification
      |0.3.8       | Vijay 		| May 14, 2019  | #BVB00150   | Customer Biometric Registration Code  
      |0.3.12      | Vijay 		| Jun 05, 2019  | #BVB00160   | Glabal Validation Logic
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.bson.internal.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.machinezoo.sourceafis.FingerprintMatcher;
import com.machinezoo.sourceafis.FingerprintTemplate;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class BiometricsRegController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil $imputils = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private IEmailService i$Email = new IEmailService();
	@SuppressWarnings("unused")
	private Logger logger = LoggerFactory.getLogger(BiometricsRegController.class); // Nye- Change Class Name
	// always
	// Nye Begins
	private IpinController I$pinController = new IpinController();
	private OtpController I$OtpController = new OtpController();
	// Nye Ends
	// **********************************************************************//

	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	@SuppressWarnings("unused")
	private IgenericWorker igenericWorker = new IgenericWorker();
	private IpasscodeController i$Pass = new IpasscodeController();// #NYE00048

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();

			String SvrOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			String SiteKey = i$ResM.getSiteKey(isonMsg);

			if (I$utils.$iStrFuzzyMatch(SvrName, "Biometrics") && I$utils.$iStrFuzzyMatch(SvrOpr, "enroll")) {
				isonMsg = RegBiometrics(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SvrName, "Biometrics")
					&& I$utils.$iStrFuzzyMatch(SvrOpr, "getBiometric")) {
				isonMsg = QuryBioMetrics(isonMsg);
			}
			// #BVB00096 Starts
			else if (I$utils.$iStrFuzzyMatch(SvrName, "Biometrics")
					&& I$utils.$iStrFuzzyMatch(SvrOpr, "verifyBiometric")) {
				isonMsg = verifyBiometrics(isonMsg);
			} else {
				// #BVB00096 Ends
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();

		}
		return isonMsg;
	};

	private JsonObject RegBiometrics(JsonObject isonMsg) {
		try {
			// Forwarding Request to DBController for Registration
			// 1 . Decrypt the Key
			String iKey = null;
			String iMode = "";
			JsonObject argJson = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			// Read the Key from Session key from ICOR_S_SESSION_VALIDATOR
			// iKey = $imputils.decrypt(i$body.get("iKey").getAsString(),
			// i$ResM.getGobalValStr("deCryptKey"));
			iKey = i$ResM.getBodyElementS(isonMsg, "iKey");
			iMode = i$ResM.getBodyElementS(isonMsg, "iMode");

			// 2. Check if Key exists
			if (!(iKey != null) || db$Ctrl.db$GetRowCnt("ICOR_M_ECOMM_REPO",
					"{\"$or\":[{\"Key_Owner\":\"" + iKey + "\"},{\"Key_Token\":\"" + iKey + "\"}]}") < 1) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "TYPE ERROR");
			} else {
				// 3. Verify Passcode
				String ipassCode = "";
				String OTP = "";
				boolean codeVerify = false;
				try {
					ipassCode = i$body.get("ipassCode").getAsString();
				} catch (Exception e) {
					ipassCode = "";
				}

				if (!I$utils.$iStrFuzzyMatch(ipassCode, "") && (I$utils.$iStrFuzzyMatch(iMode.substring(0, 1), "U"))) { // #BVB00150
					if (!i$Pass.Verify$PassCode(ipassCode)) {
						codeVerify = true;
					}
				} // #BVB00150 Starts
				else if (I$utils.$iStrFuzzyMatch(iMode.substring(0, 1), "C")) {
					codeVerify = true;
					// #BVB00150 Ends
				} else {
					codeVerify = false;
				}

				// 3. Verify the Ipin/OTP

				/*
				 * boolean pin$verify = false; JsonObject vry$Ipin = new JsonObject();
				 * vry$Ipin.addProperty("iKey", i$body.get("iKey").getAsString()); try { IPin =
				 * i$body.get("IPin").getAsString(); } catch(Exception e) { IPin = null; }
				 * 
				 * try { OTP = i$body.get("OTP").getAsString(); } catch(Exception e) { OTP =
				 * null; } if (IPin != null) { vry$Ipin.addProperty("IPin", IPin);
				 * 
				 * if (I$pinController.verifyIPin(vry$Ipin)) { pin$verify = true; } } else if
				 * (OTP != null) { vry$Ipin.addProperty("otp", OTP); if
				 * (I$OtpController.verify$OTP(vry$Ipin)) { pin$verify = true; } }
				 */
				if (!codeVerify) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID CODE");
				} else {
					JsonObject JBioMetrics = new JsonObject();
					JBioMetrics.addProperty("Finger1", i$body.get("Finger1").getAsString());
					try {
						JBioMetrics.addProperty("Finger2", i$body.get("Finger2").getAsString());
					} catch (Exception e) {
						// eat
					}

					try {
						JBioMetrics.addProperty("Finger3", i$body.get("Finger3").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger4", i$body.get("Finger4").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger5", i$body.get("Finger5").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger6", i$body.get("Finger6").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger7", i$body.get("Finger7").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger8", i$body.get("Finger8").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger9", i$body.get("Finger9").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger10", i$body.get("Finger10").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger11", i$body.get("Finger11").getAsString());
					} catch (Exception e) {
						// eat
					}
					try {
						JBioMetrics.addProperty("Finger12", i$body.get("Finger12").getAsString());
					} catch (Exception e) {
						// eat
					}
					// Store the Biometric info to the collection
					JsonObject i$Doc = new JsonObject();
					i$Doc.add("bioMetrics", JBioMetrics);
					db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", i$Doc,
							"{\"$or\":[{\"Key_Owner\":\"" + iKey + "\"},{\"Key\":\"" + iKey + "\"}]}");
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "BioMetric Updated Successfuly");
				}
			}
		} // End of try
		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	};

	public JsonObject QuryBioMetrics(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		// Annotate Validate
		// 1 . Decrypt the Key
		String iKey = i$ResM.getBodyElementS(isonMsg, "iKey");
		String iMode = i$body.get("iMode").getAsString();
		String sMatchStr = "{\"$and\":[{\"Key\":\"" + iKey + "\"},{\"Key_Mode\":\"" + iMode + "\"}]}";
		String sProjection = "{\"bioMetrics\":\"1\"}";
		JsonObject $iCommRes = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", sMatchStr, sProjection), $res = new JsonObject();
		if ($iCommRes != null) {
			try {
				$res.add("bioMetrics", $iCommRes.get("bioMetrics").getAsJsonObject());
			} catch (Exception e) {
				$res.addProperty("bioMetrics", "");
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, $res);

			// #BVB00096 Starts
			if (!I$utils.$isNull($res.get("bioMetrics"))) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "BioMetric Retrived Successfuly");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO BIO DATA FOUND");
			}
			// #BVB00096 Ends
		} else {
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_ERR, "NO BIO DATA FOUND");
		}
		return isonMsg;

	};

// #BVB00096 Starts
	public JsonObject QuryBioMetrics(String iKey, String iMode) {

		JsonObject bioMetrics = new JsonObject();
		try {
			String sMatchStr = "{\"$and\":[{\"Key\":\"" + iKey + "\"},{\"Key_Mode\":\"" + iMode + "\"}]}";
			String sProjection = "{\"bioMetrics\":\"1\"}";
			JsonObject $iCommRes = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", sMatchStr, sProjection);
			bioMetrics = $iCommRes.get("bioMetrics").getAsJsonObject();
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Querying Biometrics with: " + e.getMessage());
			bioMetrics = null;
		}
		return bioMetrics;

	};

	public JsonObject verifyBiometrics(JsonObject isonMsg) {
		try {
			String iKey = i$ResM.getBodyElementS(isonMsg, "iKey");
			String iBio = i$ResM.getBodyElementS(isonMsg, "iBio");
			String mode = i$ResM.getBodyElementS(isonMsg, "iMode");
			if (isBioValid(iKey, iBio, mode)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "BIOMETRICS VERIFIED SUCESSFULLY");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN BIOMETRICS");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BIOMETRIC VERIFICATION FAILED");
		}
		return isonMsg;
	}

	public boolean isBioValid(String bio, String mode) {
		boolean isBioValid = false;
		try {
			// #BVB00160 Starts 
			if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("srcJson").get("Login2FA").getAsString(), "Y")) {
				if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("srcJson").get("LoginiBio").getAsString(),
						"Y")) {
					// #BVB00160 Ends
					JsonObject bioMetrics = QuryBioMetrics(IResManipulator.iloggedUser.get(), mode);
					Set<Entry<String, JsonElement>> entrySet = bioMetrics.entrySet();

					for (Map.Entry<String, JsonElement> entry : entrySet) {
						String currField = entry.getKey();
						String currVal = bioMetrics.get(currField).getAsString();

						if (compareBio(bio, currVal)) {
							isBioValid = true;
							break;
						}
					}
					// #BVB00160  Starts
				} else {
					isBioValid = true;
				}
				
			} else {
				isBioValid = true;
			}
			// #BVB00160 Ends
		} catch (Exception e) {
			logger.debug("Failed in isBioValid with: " + e.getMessage());
			isBioValid = false;
		}
		return isBioValid;
	}

	public boolean isBioValid(String iKey, String bio, String mode) {
		boolean isBioValid = false;
		try {
			// #BVB00160 Starts
			if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("srcJson").get("Login2FA").getAsString(), "Y")) {
				if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("srcJson").get("LoginiBio").getAsString(),
						"Y")) {
					// #BVB00160 Ends
					JsonObject bioMetrics = QuryBioMetrics(iKey, mode);
					Set<Entry<String, JsonElement>> entrySet = bioMetrics.entrySet();

					for (Map.Entry<String, JsonElement> entry : entrySet) {
						String currField = entry.getKey();
						String currVal = bioMetrics.get(currField).getAsString();

						if (compareBio(bio, currVal)) {
							isBioValid = true;
							break;
						}
					}
					// // #BVB00160 Starts 
				} else {
					isBioValid = true;
				}
			} else {
				isBioValid = true;
			}
			// #BVB00160 Ends
		} catch (Exception e) {
			logger.debug("Failed in isBioValid with: " + e.getMessage());
			isBioValid = false;
		}
		return isBioValid;
	}

	public boolean compareBio(String req, String finger1) {
		boolean matches = false;
		JsonObject projection = new JsonObject();
		int bioThresholdEnc = 40;
		try {
			projection.addProperty("bioThreshold", "1");
			try {
				bioThresholdEnc = db$Ctrl.db$GetRow("ICOR_C_PARAM", projection).get("bioThreshold").getAsInt();
			} catch (Exception e) {
				bioThresholdEnc = 40;
			}
			byte[] probeImage = Base64.decode(req);
			byte[] candidateImage = Base64.decode(finger1);
			FingerprintTemplate probe = new FingerprintTemplate().dpi(500).create(probeImage);
			FingerprintTemplate candidate = new FingerprintTemplate().dpi(500).create(candidateImage);
			double score = new FingerprintMatcher().index(probe).match(candidate);
			logger.debug("score:" + score);
			matches = score >= bioThresholdEnc;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			matches = false;
		}
		return matches;

	}

// #BVB00096 Ends
	public BiometricsRegController() {
		super();
		// TODO Auto-generated constructor stub
	};
}

//#00000001 Ends
