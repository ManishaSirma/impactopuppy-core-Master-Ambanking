/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.14.283  | BHUVI 		| Jun 20, 2019 | #BHUVI001   |  Job for get all expired sdn 
      |0.3.16.327  | BHUVI 		| Jul 25, 2019 | #BHUVI002   |  Changes for send mail and message 

      ----------------------------------------------------------------------------------------------
      
*/
// #BHUVI001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.itextpdf.text.log.SysoCounter;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class SdnExpiryController {

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(IRepoController.class);
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private ImpactoUtil I$Imputils = new ImpactoUtil();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OB2SDNEX") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = QuerySdnExpiry(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OB2SDNEX") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = CreateSdnExpiry(isonMsg);
			} else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.getMessage();
			return isonMsg;
		}
		return isonMsg;
	}

	private JsonObject QuerySdnExpiry(JsonObject isonMsg) {
		// TODO Auto-generated method stub
		return null;
	}

	public JsonObject CreateSdnExpiry(JsonObject isonMsg) {
		try {
			int runEntriesCount = 0;
			JsonArray runEntries = new JsonArray();
			JsonObject argjson = new JsonObject();
			String collectionName = "ICOR_M_B2U_SDN";
			try {

				runEntriesCount = db$Ctrl.db$GetCountI(collectionName, "{'authStat':'A'}");
			} catch (Exception e) {
				runEntriesCount = 0;
			}
			double i$noOfIter = Double.valueOf(runEntriesCount) / 100;
			i$noOfIter = Math.ceil(i$noOfIter);

			for (int i = 0; i < i$noOfIter; i++) {
				JsonObject projection = new JsonObject();
				projection.addProperty("Sdn_List_Id", 1);
				projection.addProperty("expiryDays", 1);
				int skip = 100 * i;
				skip = (int) (skip + (i$noOfIter * i));
				runEntries = db$Ctrl.db$GetSummRowsArray(collectionName, "{'authStat':'A'}", projection, 0, skip, "Y");

				for (int j = 0; j < runEntries.size(); j++) {
					JsonObject i$runningObj = runEntries.get(j).getAsJsonObject();
					if (getExpiredSDN(i$runningObj,argjson))
						
					{
						sendNotification(i$runningObj,argjson);
					}
				}
			}

			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SDN Expiry Data Updated ");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SDN Expiry Data failed with: " + e.getMessage());
		}
		return isonMsg;
	}

	// #BHUVI002 start
	private void sendNotification(JsonObject i$runningObj, JsonObject argJson) {
		try {
			IWhatsupService I$Whatsapp = new IWhatsupService();
			ISmsService I$ISmsService = new ISmsService();
			IEmailService i$Email = new IEmailService();

			JsonObject projection = new JsonObject();
			projection.addProperty("notificationAccess", 1);
			JsonObject filter = new JsonObject();
			JsonObject to$emailIds = new JsonObject();
			JsonObject $mobNum = new JsonObject();
			JsonObject $whtsAppNum = new JsonObject();
			JsonObject map$Data = new JsonObject();

			boolean sendSms = false;
			boolean sendwhatsApp = false;
			boolean sendEmail = false;

			JsonObject notifyMapper = db$Ctrl.db$GetRow("ICOR_M_NOTIFICATION_MAPPER",
					"{'notificationName':'SDNUploadExpiry'}", "{}");
			JsonObject mode = notifyMapper.get("Mode").getAsJsonObject();

			if (mode.get("SMS").getAsInt() == 1) {
				projection.addProperty("IsdMobNum", 1);
				projection.addProperty("MobNum", 1);
				sendSms = true;
			}
			if (mode.get("WhatsApp").getAsInt() == 1) {
				projection.addProperty("IsdWhtsAppNum", 1);
				projection.addProperty("WhtsAppNum", 1);
				sendwhatsApp = true;
			}
			if (mode.get("Email").getAsInt() == 1) {
				projection.addProperty("EmpMail", 1);
				sendEmail = true;
			}

			filter.addProperty("notificationAccess.notificationId", notifyMapper.get("notificationId").getAsString());
			filter.addProperty("notificationAccess.required", true);

			JsonArray arrUsrprf = db$Ctrl.db$GetRows("ICOR_M_USER_PRF", filter, projection);
			int count = 1;

			for (int i = 0; i < arrUsrprf.size(); i++) {
				JsonObject objUsrprf = arrUsrprf.get(i).getAsJsonObject();
				if (objUsrprf.has("EmpMail")) {
					to$emailIds.addProperty("toemailid" + count, objUsrprf.get("EmpMail").getAsString());
				}
				if (objUsrprf.has("IsdMobNum") && objUsrprf.has("MobNum")) {
					$mobNum.addProperty("Mob_Number" + count,
							objUsrprf.get("IsdMobNum").getAsString().concat(objUsrprf.get("MobNum").getAsString()));
				}
				if (objUsrprf.has("IsdWhtsAppNum") && objUsrprf.has("WhtsAppNum")) {
					$whtsAppNum.addProperty("IsdWhtsAppNum" + count, objUsrprf.get("WhtsAppNum").getAsString());
				}
				count++;

			}
			if (!argJson.isJsonNull()) {

				int expiryMode = argJson.get("ExpiredInDays").getAsInt();
				if (expiryMode == 0) {
					map$Data.addProperty("document", i$runningObj.get("Sdn_List_Id").getAsString());
					map$Data.addProperty("tmp$name", "IMPACTO_DOCUMENT_EXPIRED");

				} else {
					map$Data.addProperty("noOfDays", argJson.get("ExpiredInDays").getAsInt());
					map$Data.addProperty("document", i$runningObj.get("Sdn_List_Id").getAsString());
					map$Data.addProperty("tmp$name", "IMPACTO_DOCUMENT_EXPIRY");
				}

			}

			if (sendSms) {
				try {
					JsonObject argJsonPass = new JsonObject();
					argJsonPass.add("mobile$numbers", $mobNum);
					argJsonPass.add("map$Data", map$Data);
					I$ISmsService.sendSMS(argJsonPass);

				} catch (Exception e) {
					e.getMessage();

				}
			}
			if (sendwhatsApp) {
				try {
					JsonObject argJsonPass = new JsonObject();
					argJsonPass.add("mobile$numbers", $whtsAppNum);
					argJsonPass.add("map$Data", map$Data);
					I$Whatsapp.sendWhatsup(argJsonPass);

				} catch (Exception e) {
					e.getMessage();

				}
			}
			if (sendEmail) {
				try {
					JsonObject argJsonPass = new JsonObject();
					argJsonPass.add("toemailIds", to$emailIds);
					argJsonPass.add("map$Data", map$Data);
					i$Email.sendEmail(argJsonPass);

				} catch (Exception e) {
					e.getMessage();

				}
			}
		} catch (Exception e) {
			e.getMessage();

		}
	}
 // #BHUVI002 Ends
	private boolean getExpiredSDN(JsonObject i$runningObj,JsonObject argJson) {
		try {
			String sdnListId = i$runningObj.get("Sdn_List_Id").getAsString();
			Gson gson = new Gson();
			JsonObject projection = new JsonObject();
			
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
			int DocValidityInDays = cParam.get("DocValidityInDays").getAsInt();

	
			String collectionName = "ICOR_M_B2U_SDNLIST_LEDGER";

			JsonObject filter = new JsonObject();
			filter.addProperty("Sdn_lst_id", sdnListId);
			filter.addProperty("isCurrVer", "Y");

			JsonObject jGetRow = db$Ctrl.db$GetRow(collectionName, filter);
			
			if(jGetRow!=null)
			{
			String currentExpiry = jGetRow.get("initiatedOnSrvDate").getAsString(); // #BVB00103
			String todayDate = I$utils.currentDateinString();
			int DiffinDays = I$utils.getDateDifference(todayDate,currentExpiry);
			System.out.println("");
			int ExpiredInDays = 0;

			if(DiffinDays<=0)
			{
				argJson.addProperty("ExpiredInDays", ExpiredInDays);
				return true;
			}
			else
			{
			if (DocValidityInDays >= DiffinDays) {
				//ExpiredInDays = DocValidityInDays - DiffinDays;
				argJson.addProperty("ExpiredInDays", DiffinDays);
				return true;
			} 
			}
			
			}
		} catch (Exception e) {
			e.getMessage();
			return false;
		}
		return false;

		}

}
//BHUVI001 Ends