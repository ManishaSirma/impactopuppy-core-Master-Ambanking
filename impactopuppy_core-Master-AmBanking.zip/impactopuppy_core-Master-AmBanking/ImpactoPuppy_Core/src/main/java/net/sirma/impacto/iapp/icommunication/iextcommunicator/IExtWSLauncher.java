/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Jab 1, 2019  | #00000001   | Initial writing
      |0.2.1       | Vijay 		| Jan 24, 2019 | #BVB00040   | Intial Fixes For CBS Adapter 
      |0.2.1       | Vijay 		| Feb 17, 2019 | #BVB00061   | Adding time out for Flexcube Request
      |0.3.6       | Vijay 		| Apr 28, 2019 | #BVB00132   | Adding support to Get request and making ConnectionTime and readTime DB driven
      |0.3.8       | Vijay 		| May 08, 2019 | #BVB00145   | Adding response when exception happens 
      |0.3.17      | Vijay 		| Jul 20, 2019 | #BVB00187   | Empty Reponse
      |0.3.17	   | Manikanta  | Jan 18, 2022 | #MVT00030	 | Added code for SSL issue 
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icommunication.iextcommunicator;

import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject; 

import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.idbworkers.ImongoWorker;
 
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Request.Builder;
import okhttp3.RequestBody;
import okhttp3.Response;



import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Request.Builder;
import okhttp3.RequestBody;
import okhttp3.Response;


@SuppressWarnings("unused")
public class IExtWSLauncher {
	private static final Logger logger = LoggerFactory.getLogger(IExtWSLauncher.class);
	private static final Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	public JsonObject ILaunchReq(JsonObject argJson) {
		return ILaunchReq(argJson, null); 
	}

	public JsonObject ILaunchReq(JsonObject argJson, RequestBody reqBody) {
		JsonObject jOkHttp = new JsonObject();
		jOkHttp.addProperty("unqCommID", argJson.get("unqCommID").getAsString());

		try {
			String requestType = argJson.get("requestType").getAsString();
			String gzipResponse = i$ResM.getStrfromObjWithDefault(argJson, "gzipResponse","N"); 
			

//			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
//			        .readTimeout(120, TimeUnit.SECONDS).build();
			OkHttpClient client = getUnsafeOkHttpClient();//#MVT00030 Changes
//java.net.SocketTimeoutException: timeout 
			

			// #BVB00132 Starts
			// Setting TimeOut
//			try {
//				
//			 client.setConnectTimeout(argJson.get("connectTimeOut").getAsLong(), TimeUnit.SECONDS);
//			} catch (Exception e) {
//				client.setConnectTimeout(120, TimeUnit.SECONDS); // connect timeout
//			}
//			try {
//				client.setReadTimeout(argJson.get("readTimeOut").getAsLong(), TimeUnit.SECONDS); // socket timeout
//			} catch (Exception e) {
//				client.setReadTimeout(120, TimeUnit.SECONDS); // socket timeout
//			}
			// #BVB00132 Ends
			MediaType mediaType  = null; 
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
			
			// RequestBody reqBody = null;
			if (i$impactoUtil.isObjectEmpty(reqBody)) {
				try {
					reqBody = RequestBody.create(mediaType, argJson.get("reqBody").getAsString());
				} catch (Exception Ex) {
					// No Body
					// reqBody = null;
					reqBody = RequestBody.create(null, new byte[0]);  
				}
			}
			JsonObject JHeaderTags = argJson.get("headerTags").getAsJsonObject();
			Builder ReqBldr = new Request.Builder();
			
			Response.Builder ResBldr = new Response.Builder();
			try {
				Set<Entry<String, JsonElement>> entrySet = JHeaderTags.entrySet();
				String strKey, strVal;
				for (Map.Entry<String, JsonElement> entry : entrySet) {
					strKey = entry.getKey();
					strVal = JHeaderTags.get(entry.getKey()).getAsString();
					ReqBldr.addHeader(strKey, strVal);
				}
			} catch (Exception ex) {
				// No Header Data
				logger.debug("No header data ::" + ex.getMessage());
			}
			ReqBldr.url(argJson.get("extUrl").getAsString()); // #BVB00040

			// #BVB00132 Starts
			// ReqBldr.post(reqBody);
			if (I$utils.$iStrFuzzyMatch(requestType, "POST")) {
				ReqBldr.post(reqBody);
			} else if (I$utils.$iStrFuzzyMatch(requestType, "GET")) {
				ReqBldr.get();
			}
			// #BVB00132 Ends
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();
			String responseBody = ""; 
			if(I$utils.$iStrFuzzyMatch(gzipResponse, "Y")) {
				responseBody = i$impactoUtil.unzipGZipResonse(response); 
			}else {
				responseBody= response.body().string(); 
			}
			
			if (response != null) { // #BVB00187
				if (response.isSuccessful()) {
					jOkHttp.addProperty("resStat", i$ResM.I_SUCC);
					jOkHttp.addProperty("resCode", response.code());
					// jOkHttp.addProperty("resBody", response.body().string());
					jOkHttp.addProperty("resBody", responseBody);
					return jOkHttp; // Nye Fix
				} else {
					jOkHttp.addProperty("resStat", i$ResM.I_ERR);
					jOkHttp.addProperty("resCode", response.code());
					try {
						// jOkHttp.addProperty("resBody", response.body().string());
						jOkHttp.addProperty("resBody", responseBody);
					} catch (Exception Ex) {
						// Eating up the Exception
						jOkHttp.addProperty("resBody", "");
						logger.debug("No resBody ::" + Ex.getMessage());
					}
					;
					return jOkHttp; // Nye Fix
				}
				// #BVB00187 Starts
			} else {
				jOkHttp.addProperty("resStat", i$ResM.I_ERR);
				jOkHttp.addProperty("resCode", "400");
				jOkHttp.addProperty("resExp", "Response Empty"); // #BVB00145
				jOkHttp.addProperty("resBody", "");
				return jOkHttp; // Nye Fix
			}
			// #BVB00187 Ends
		} catch (Exception ex) {
			jOkHttp.addProperty("resStat", i$ResM.I_ERR);
			jOkHttp.addProperty("resCode", "400");
			jOkHttp.addProperty("resExp", "Failed with: " + ex.getMessage()); // #BVB00145
			jOkHttp.addProperty("resBody", "");
			logger.debug("Failed in Sending out call with :" + ex.getMessage());
			return jOkHttp; // Nye Fix
		}
	}
	//#MVT00030 Changes starts
	private OkHttpClient getUnsafeOkHttpClient() {
		try {
	           final TrustManager[] trustAllCerts = new TrustManager[]{
	                   new X509TrustManager() {

	                       @Override
	                       public void checkClientTrusted(java.security.cert.X509Certificate[] chain,
	                                                      String authType) throws
	                               CertificateException {
	                       }

	                       @Override
	                       public void checkServerTrusted(java.security.cert.X509Certificate[] chain,
	                                                      String authType) throws
	                               CertificateException {
	                       }
	                       @Override
	                       public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                           return new java.security.cert.X509Certificate[]{};
	                       }
	                   }
	           };           

	        int connectTimeOut = 120; 
	        try {
//	          connectTimeOut = argJson.get("connectTimeOut").getAsInt();
	        } catch (Exception e) {
	          // TODO: handle exception
	        }
	        int readTimeOut = 120; 
	        try {
//	          readTimeOut = argJson.get("readTimeOut").getAsInt();
	        } catch (Exception e) {
	          // TODO: handle exception
	        }

	           final SSLContext sslContext = SSLContext.getInstance("SSL");
	           sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

	           final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

	           OkHttpClient.Builder builder = new OkHttpClient.Builder();
	           builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
	           builder.connectTimeout(connectTimeOut, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS).readTimeout(readTimeOut, TimeUnit.SECONDS);
	           builder.hostnameVerifier(new HostnameVerifier() {
	               @Override
	               public boolean verify(String hostname, SSLSession session) {
	                   return true;
	               }
	           });

	           return builder.build();
	       } catch (Exception e) {
	           throw new RuntimeException(e);
	       }
	}	//#MVT00030 Changes ends
}

//#00000001 Ends