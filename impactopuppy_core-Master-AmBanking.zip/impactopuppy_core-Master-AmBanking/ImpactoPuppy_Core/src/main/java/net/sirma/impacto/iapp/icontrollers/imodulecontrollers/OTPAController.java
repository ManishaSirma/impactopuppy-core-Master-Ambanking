/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.6       | Vijay 	    | Apr 24 2019  | #BVB00126   | Initial writing for OTP As a Screen to Unknown Numbers and Email Id's
      |0.3.6       | Srikanth   | Oct 17 2023  | #SRI00010   | handeling the OTP Trigger to Unknown Numbers and Email Id's
      --------------------------------------------------------------------------------------------------------
      
*/
// #BVB00126 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icommunication.whatsup.IWhatsupService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class OTPAController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private static DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil imp$utils = new ImpactoUtil();

	private IResManipulator i$ResM = new IResManipulator();
	private IEmailService i$Email = new IEmailService();
	private ISmsService i$SmsSrvc = new ISmsService();
	private Logger logger = LoggerFactory.getLogger(OTPAController.class); // #NYE00003 - Change Class Name
	// **********************************************************************//

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr2, "sendOTP")) {
				isonMsg =  sendOTP(i$body, isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			 
		}
		return isonMsg;
	};


	@SuppressWarnings("null")
	public JsonObject sendOTP(JsonObject argJson, JsonObject isonMsg) {
		try {
			// JsonObject sParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{ system: \"" +
			// "SYSTEM_PARAMS" + "\" }");

			// Loop through the mode we have received. Check where all it is 1, then send
			// OTP based on that

			// argJson.add("Key", argJson.get("Key").getAsJsonObject()); // Key have to be
			// Encrypted always
			JsonObject i$Param = null;
			JsonObject i$Resp = null;
			String sEMsg = "";
			String sOptMaint = "iOtpCommMode_" + i$ResM.getClientApp(isonMsg);
			// #NYE00003 Begins
			String sTmplName = null;
			String sMsgAnnote = null;
			JsonObject jBdy = new JsonObject();
			String eol = System.getProperty("line.separator");
			// String sMode = argJson.get("Mode").getAsString();
			JsonObject mode = argJson.get("Mode").getAsJsonObject();
			String iSendSmsOtp = mode.get("SMS").getAsString();
			String iSendMailOtp = mode.get("Email").getAsString();
			String iWhatsUpOtp = mode.get("WhatsApp").getAsString();

			// Check if Record Exists

			if (i$ResM.getBody(isonMsg).has("Msg_Annotation")) {
				sMsgAnnote = i$ResM.getBodyElementS(isonMsg, "Msg_Annotation");
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP", "{\"MSG_ANNOTATION\":\"" + sMsgAnnote + "\"}",
						"{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			} else
				sTmplName = "TMPL#OTP";

			try {
				i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"iOtpCommMode\"=1}");
			} catch (Exception ex) {
				i$Param = null;
			}

			JsonObject i$SrcParam = null;
			try {
				i$SrcParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"" + sOptMaint + "\":1}");
			} catch (Exception E) {
				i$SrcParam = null;
			}
			;

			// Generate the sec key and otp and store in otp validator
			argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));
			// argJson.addProperty("iotp", imp$utils.generateRandom(10005, 99999));
			argJson.addProperty("iotp", Integer.toString(imp$utils.generateRandom(10005, 99999)));
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("otp$verified", false);
			argJson.addProperty("tmplName", sTmplName);
			db$Ctrl.db$InsertRow("ICOR_S_IOTP_VALIDATOR", argJson);
			// #NYE00003 Ends

			JsonObject email$cnfdb = new JsonObject(); // #NYE00003 Adds

			if (i$Param != null || argJson.has("iOtpCommMode") || i$SrcParam != null) {

				// #NYE00003 Changes Begin - Revamped the Logic and Removed the old Code .
				if (argJson.has("iOtpCommMode")) {
					// Overriding th e OTP maintenance
					email$cnfdb = argJson.get("iOtpCommMode").getAsJsonObject();
				} else if (i$SrcParam != null && i$SrcParam.has(sOptMaint)) {
					email$cnfdb = i$SrcParam.get(sOptMaint).getAsJsonObject();
				} else {
					email$cnfdb = i$Param.get("iOtpCommMode").getAsJsonObject();
				}
				int iSend = 0;
				String sMedia = "";
				String sFailedText = "";
				if (I$utils.$strValNullIf(email$cnfdb.get("iSendSmsOtp").getAsString(), "").equals("Y")
						&& I$utils.$iStrFuzzyMatch(iSendSmsOtp, "1")) {
					i$Resp = sendSMS(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp))
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
					iSend++;
					sMedia = sMedia + "SMS:";
				}
				;

				if (I$utils.$strValNullIf(email$cnfdb.get("iSendMailOtp").getAsString(), "").equals("Y")
						&& I$utils.$iStrFuzzyMatch(iSendMailOtp, "1")) {
					i$Resp = sendEmail(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp))
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
					iSend++;
					sMedia = sMedia + "EMAIL:";
				}
				;
//				if (I$utils.$strValNullIf(email$cnfdb.get("iWhatsUpOtp").getAsString(), "").equals("Y")
//						&& I$utils.$iStrFuzzyMatch(iWhatsUpOtp, "1")) {
//					i$Resp = sendWhatsup(argJson, isonMsg);
//					if (!i$ResM.isRespSucc(i$Resp))
//						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
//					iSend++;
//					sMedia = sMedia + "WHATSAPP:";
//				}
				// SRI00010 starts
				String mobNumber = "";
				String EmailAddres = "";
				String mobEmailNumber = "";
				try {
//					JsonObject temp = argJson.getAsJsonObject("Key");
					mobNumber = argJson.getAsJsonObject("Key").get("SMS").getAsJsonArray().get(0).getAsString();
					if (!mobNumber.isEmpty()) {
						try {
							int numAsterisks = Math.min(mobNumber.split("-")[1].length() - 4,
									mobNumber.split("-")[1].length());
							mobNumber = "*".repeat(numAsterisks)
									+ mobNumber.split("-")[1].substring(mobNumber.split("-")[1].length() - 4);
							mobEmailNumber = mobNumber;
						}catch(Exception e) {
							e.printStackTrace();
						}
					}
					String EmailAddress = argJson.getAsJsonObject("Key").get("Email").getAsJsonArray().get(0)
							.getAsString();
					if (!EmailAddress.isEmpty()) {
						try {
							String[] parts = EmailAddress.split("@");
							if (parts.length == 2) {
								String username = parts[0];
								String domain = parts[1];
								if (username.length() > 3) {
									int numAsterisks1 = username.length() - 3;
									String maskedUsername = username.substring(0, 3) + "*".repeat(numAsterisks1);
									EmailAddres = maskedUsername + "@" + domain;
								} else {
									char[] charArr = username.toCharArray();
									StringBuilder maskedData = new StringBuilder();
									int i = 0;
									while (charArr.length > 1 && i < charArr.length - 1) {
										maskedData = maskedData.append(charArr[i]);
										i++;
									}
									maskedData = maskedData.append("*");
									String maskedUsername = maskedData.toString();
									EmailAddres = maskedUsername + "@" + domain;
								}
							}
							mobEmailNumber = EmailAddres;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					if (!mobNumber.isEmpty() && !EmailAddres.isEmpty()) {
						mobEmailNumber = mobNumber + "/" + EmailAddres;
					}

				} catch (Exception e) {
					e.getMessage();
				}
				// SRI00010 ends
				if (iSend < 1) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Otp Service is Disabled",
							"Contact Adminstrator");
				} else {
					if (I$utils.$iStrBlank(sFailedText)) {
						jBdy.addProperty("iSecKey", argJson.get("iSecKey").getAsString());
						jBdy.addProperty("mobEmailKey", mobEmailNumber); // SRI00010 changes
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBdy);
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
								"OTP Triggered Successfully Via :" + sMedia);
					} else {
						jBdy.addProperty("iSecKey", argJson.get("iSecKey").getAsString());
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBdy);
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								"OTP Triggered is not successful");
					}
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Otp Service is Disabled",
						"Contact Adminstrator");
			}
			// #NYE00003 Changes End
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending OTP or OTP Service is disabled", "Contact Adminstrator");

		}
	};

	private JsonObject sendSMS(JsonObject argJson, JsonObject isonMsg) {
		try {
			// String mode = argJson.get("Mode").getAsString();
			JsonArray Mob$No = new JsonArray();
			Mob$No = argJson.get("Key").getAsJsonObject().getAsJsonArray("SMS");
			JsonObject i$resBody = new JsonObject();

			if (I$utils.$isNull(Mob$No)) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Unable to Retrive Number");
			}
			;
			JsonObject i$res = new JsonObject();
			for (int i = 0; i < Mob$No.size(); i++) {
				argJson.addProperty("key$Type", "otp");
				argJson.add("mobile$numbers",
						i$ResM.getJsonObj("{\"Mob_Number1\":\"" + Mob$No.get(i).getAsString() + "\"}")); // #NYE00003
				JsonObject map$Data = new JsonObject();
				map$Data.addProperty("otp", argJson.get("iotp").getAsString());
				map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
				argJson.add("map$Data", map$Data);

				i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());
				// Forward to Otp Service
				i$res = i$SmsSrvc.SendSMSWOThread(argJson);
				//JsonObject i$res = i$SmsSrvc.SendSMSWOThread(argJson);
				
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg); 
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS OTP Sent Successfully ");
			} else {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			}
			
			//isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
			//return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS OTP Sent Successfully ");
			return isonMsg; 

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending SMS ");
		}

	};

	private JsonObject sendEmail(JsonObject argJson, JsonObject isonMsg) {
		try {
 
			JsonArray email$Details = argJson.get("Key").getAsJsonObject().getAsJsonArray("Email");
			JsonObject i$resBody = new JsonObject();

			if (email$Details == null) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Unable to Retrive Email ID");
			}
			;JsonObject i$res = new JsonObject();
			for (int i = 0; i < email$Details.size(); i++) {
				argJson.addProperty("key$Type", "otp");
				argJson.add("toemailIds",
						i$ResM.getJsonObj("{\"toemailid1\":\"" + email$Details.get(i).getAsString() + "\"}")); // #NYE00003
				JsonObject map$Data = new JsonObject();
				map$Data.addProperty("user", email$Details.get(i).getAsString());
				map$Data.addProperty("otp", argJson.get("iotp").getAsString());
				map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
				argJson.add("map$Data", map$Data);

				i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

				i$res = i$Email.SendEmailWOThread(argJson);  
			}
			
			
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(i$res), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email OTP Sent Successfully ");
			} else {
				isonMsg = i$ResM.iHandleResStat(i$res, isonMsg);
			}
 			//isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
			// return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email OTP Sent Successfully ");
			return isonMsg; 

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Email ");
		}

	};

	public JsonObject verifyOTP(JsonObject argJson, JsonObject isonMsg) {
		try {

			if ((argJson.has("otp"))
					&& db$Ctrl.db$GetRowCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
							+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }") > 0) { // #NYE00005
																											// corrected
																											// the
																											// condition
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP VERIFIED SUCCESSFULY");
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "INVALID OTP");
			}
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Verifying OTP ");
		}
	};

	public boolean verify$OTP(JsonObject argJson) { // #NYE00003 Changes
		try {

			if ((argJson.has("otp"))
					&& db$Ctrl.db$GetRowCnt("ICOR_S_IOTP_VALIDATOR", "{ iotp: \"" + argJson.get("otp").getAsString()
							+ "\" , iSecKey: \"" + argJson.get("iSecKey").getAsString() + "\" }") > 0) { // #NYE00005
																											// corrected
																											// the
																											// condition
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return false;
		}
	};

	private JsonObject sendWhatsup(JsonObject argJson, JsonObject isonMsg) {
		try {
			// Logic is slightly different here to pick the Primary WhatsappNo
			JsonArray Mob$No = argJson.get("Key").getAsJsonObject().getAsJsonArray("WhatsApp"); // #NYE00003
			JsonObject i$resBody = new JsonObject();
			for (int i = 0; i < Mob$No.size(); i++) {
				argJson.add("mobile$numbers",
						i$ResM.getJsonObj("{\"Mob_Number1\":\"" + Mob$No.get(i).getAsString() + "\"}")); // #NYE00003
				JsonObject map$Data = new JsonObject();
				map$Data.addProperty("otp", argJson.get("iotp").getAsString());
				map$Data.addProperty("tmp$name", argJson.get("tmplName").getAsString());
				argJson.add("map$Data", map$Data);
				// argJson.addProperty("iSecKey", imp$utils.randomAlphaNumeric(100));

				i$resBody.addProperty("iSecKey", argJson.get("iSecKey").getAsString());

				// Forward to Otp Service
				IWhatsupService I$Whp = new IWhatsupService();
				I$Whp.sendWhatsup(argJson);
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Whatsup OTP Sent Successfully ");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Whatsup ");
		}

	};

	}

//#BVB00126 Ends