/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Dec 4, 2018  | #BVB00024   | Initial writing
      |0.2.1       | Vijay 		| Feb 12, 2019 | #BVB00087   | DeDup verdict added
      |0.3.6       | Vijay 		| Apr 26, 2019 | #BVB00130   | Making the code generic for all fields  
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins

package net.sirma.impacto.iapp.iworkers.iappworkers;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ISdnScanWorker {

	private Logger logger = LoggerFactory.getLogger(ISdnScanWorker.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator I$ResMan = new IResManipulator();
	
	@SuppressWarnings("unused")
	public  String alertMessage(String alertList)
	{
		String alertMessage =null;
		if (StringUtils.containsIgnoreCase(alertList, "WORLDPOLITICIANS")|| StringUtils.containsIgnoreCase(alertList, "WORLDLEADERS") || StringUtils.containsIgnoreCase(alertList, "COE") 
				||  StringUtils.containsIgnoreCase(alertList, "TT_PEP") ||  StringUtils.containsIgnoreCase(alertList, "EUMEPS_PEP") || StringUtils.containsIgnoreCase(alertList, "PEP_President")||
				 StringUtils.containsIgnoreCase(alertList, "UN")) {
			
			if(alertMessage !=null) {
			alertMessage = alertMessage +"~" +" Client is a potential Politically Exposed Person(PEP)";}
			else alertMessage= " Client is a potential Politically Exposed Person(PEP)";
		} else if ( StringUtils.containsIgnoreCase(alertList, "TT_SDN") ||  StringUtils.containsIgnoreCase(alertList, "AUS") ||  StringUtils.containsIgnoreCase(alertList, "DEBAR") || StringUtils.containsIgnoreCase(alertList, "EEFS") 
				|| StringUtils.containsIgnoreCase(alertList, "EUMEPS_PEP") || StringUtils.containsIgnoreCase(alertList, "EEAS") || StringUtils.containsIgnoreCase(alertList, "GB_CON")  || StringUtils.containsIgnoreCase(alertList, "SDFM") 
				|| StringUtils.containsIgnoreCase(alertList, "SDN") || StringUtils.containsIgnoreCase(alertList, "SWISS") ) {
			if(alertMessage !=null) {
			alertMessage = alertMessage+"~" +"Client is a potential Specially Designated National(SDN)";
			}else alertMessage = "Client is a potential Specially Designated National(SDN)";
		} else if (StringUtils.containsIgnoreCase(alertList, "HitListCnty")  ||StringUtils.containsIgnoreCase(alertList, "UKHMT")) {
			if(alertMessage !=null) {
			alertMessage = alertMessage+"~" +"Client is a national or residing in a country under sanctions";
			}else alertMessage = "Client is a national or residing in a country under sanctions";
		} else if (StringUtils.containsIgnoreCase(alertList, "INTERPOL") ) {
			if(alertMessage !=null) {
			alertMessage = alertMessage+"~" + "Client is under watch for criminal activites";
			}else alertMessage =  "Client is under watch for criminal activites";
		}
		return alertMessage;
	}

	public  String scoreClass(String ColumnName, double score) {
		
		try{
		String status = null;
		String colorCoding = null;
		 
		// #BVB00130 Starts 
//		if (ColumnName.equals("FullName") || ColumnName.equals("Country")) {
//
//			if (score >= 80) {
//				status = "Critical";
//				colorCoding = "Light Red";
// 			} else if (score >= 65 & score < 80) {
//				status = "High";
//				colorCoding = "Light Orange";
// 			} else if (score >= 45 & score < 65) {
//				status = "Significant";
//				colorCoding = "Light Yellow";
// 			} else if (score >= 30 & score < 45) {
//				status = "Medium";
//				colorCoding = "Light Blue";
// 			} else if (score >= 15 & score < 30) {
//				status = "Low";
//				colorCoding = "Sky Blue";
// 			} else if (score > 0 & score < 15) {
//				status = "Very Low";
//				colorCoding = "Medium Light";
// 			} else {
//				status = "Clean";
//				colorCoding = "Light Green";
// 			}
//		} else if (ColumnName.equals("FName") || ColumnName.equals("LName")) {
//			if (score >= 90) {
//				status = "Critical";
//				colorCoding = "Light Red";
// 			} else if (score >= 65 & score < 90) {
//				status = "High";
//				colorCoding = "Light Orange";
// 			} else if (score >= 45 & score < 65) {
//				status = "Significant";
//				colorCoding = "Light Yellow";
// 			} else if (score >= 30 & score < 45) {
//				status = "Medium";
//				colorCoding = "Light Blue";
// 			} else if (score >= 15 & score < 30) {
//				status = "Low";
//				colorCoding = "Sky Blue";
// 			} else if (score > 0 & score < 15) {
//				status = "Very Low";
//				colorCoding = "Medium Light";
// 			} else {
//				status = "Clean";
//				colorCoding = "Light Green";
// 			}
//
//		} else if (ColumnName.equals("Address") || ColumnName.equals("DOB") || ColumnName.equals("id")) {
//			if (score >= 75) {
//				status = "Critical";
//				colorCoding = "Light Red";
// 			} else if (score >= 65 & score < 75) {
//				status = "High";
//				colorCoding = "Light Orange";
// 			} else if (score >= 45 & score < 65) {
//				status = "Significant";
//				colorCoding = "Light Yellow";
// 			} else if (score >= 30 & score < 45) {
//				status = "Medium";
//				colorCoding = "Light Blue";
// 			} else if (score >= 15 & score < 30) {
//				status = "Low";
//				colorCoding = "Sky Blue";
// 			} else if (score > 0 & score < 15) {
//				status = "Very Low";
//				colorCoding = "Medium Light";
// 			} else {
//				status = "Clean";
//				colorCoding = "Light Green";
// 			}
//
//		} // #BVB00087 Starts 
//		else {
		// #BVB00130 Ends
		if (ColumnName.equals("TECU_RP") ) {
			if (score >= 16) {
				status = "High";
 			} else if (score >= 11 & score < 16) {
 				status = "Medium";
 			} else {
				status = "Low";
 			}
		} else {
			if (score >= 75) {
				status = "Critical";
				colorCoding = "Light Red";
 			} else if (score >= 65 & score < 75) {
				status = "High";
				colorCoding = "Light Orange";
 			} else if (score >= 45 & score < 65) {
				status = "Significant";
				colorCoding = "Light Yellow";
 			} else if (score >= 30 & score < 45) {
				status = "Medium";
				colorCoding = "Light Blue";
 			} else if (score >= 15 & score < 30) {
				status = "Low";
				colorCoding = "Sky Blue";
 			} else if (score > 0 & score < 15) {
				status = "Very Low";
				colorCoding = "Medium Light";
 			} else {
				status = "Clean";
				colorCoding = "Light Green";
 			}
		} // #BVB00087 Ends
		return status;
		}catch(Exception e){
			return null;
		}
	}
	
	public  String colorCode(String status) {
		
		try{
		String colorCoding = null;
 		if (status.equals("Critical")) {
			colorCoding = "Light Red";
 		} else if (status.equals("High")) {
			colorCoding = "Light Green";
		} else if (status.equals("Significant")) {
			colorCoding = "Light Yellow";
		} else if (status.equals("Medium")) {
			colorCoding = "Light Blue";
		} else if (status.equals("Low")) {
			colorCoding = "Sky Blue";
		} else if (status.equals("Very Low")) {
			colorCoding = "Medium Light";
		} else {
			colorCoding = "Light Green";
		}
		return colorCoding;
		}catch(Exception e){
			return null;
		}
	}
	public  double fuzzySearch(String compareWith, String compare) {
		
		try{

		if (compareWith.equals(compare)) {
			return 1;
		}

		if (compare.isEmpty() || compareWith.isEmpty()) {
			return 0;
		}

		double runningScore = 0;
		double finalScore;
		double charScore;
		String string = compareWith;
		String lString = string.toLowerCase();
		int strLength = string.length();
		String lWord = compare.toLowerCase();
		int wordLength = compare.length();
		int idxOf;
		int startAt = 0;
		double fuzzies = 1;
		double fuzzyFactor = 0;
		int i;
		double fuzziness = 0.5;

		if (fuzziness == 0) {
			fuzzyFactor = 1 - fuzziness;
		}
		;

		if (fuzziness > 0) {
			for (i = 0; i < wordLength; i += 1) {

				// Find next first case-insensitive match of a character.
				idxOf = lString.indexOf(lWord.charAt(i), startAt);

				if (idxOf == -1) {
					fuzzies += fuzzyFactor;
				} else {
					if (startAt == idxOf) {
						// Consecutive letter & start-of-string Bonus
						charScore = 0.7;
					} else {
						charScore = 0.1;

						// Acronym Bonus
						// Weighing Logic: Typing the first character of an acronym is as if you
						// preceded it with two perfect character matches.
						if (string.charAt(idxOf - 1) == ' ') {
							charScore += 0.8;
						}
					}

					// Same case bonus.
					if (string.charAt(idxOf) == compare.charAt(i)) {
						charScore += 0.1;
					}

					// Update scores and startAt position for next round of indexOf
					runningScore += charScore;
					startAt = idxOf + 1;
				}
			}
		} else {
			for (i = 0; i < wordLength; i += 1) {
				idxOf = lString.indexOf(lWord.charAt(i), startAt);
				if (-1 == idxOf) {
					return 0;
				}

				if (startAt == idxOf) {
					charScore = 0.7;
				} else {
					charScore = 0.1;
					if (string.charAt(idxOf - 1) == ' ') {
						charScore += 0.8;
					}
				}
				if (string.charAt(idxOf) == compare.charAt(i)) {
					charScore += 0.1;
				}
				runningScore += charScore;
				startAt = idxOf + 1;
			}
		}

		// Reduce penalty for longer strings.
		finalScore = 0.5 * (runningScore / strLength + runningScore / wordLength) / fuzzies;

		if ((lWord.charAt(0) == lString.charAt(0)) && (finalScore < 0.85)) {
			finalScore += 0.15;
		}

		return finalScore;
		}catch(Exception e){
			return 1.1;
		}
	}
	
	public String randomAlphaNumeric() {
		String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		try{
			
		
		StringBuilder builder = new StringBuilder();
		int count = 10;
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
	
		return builder.toString();
		}catch(Exception e){
			return null;
		}
	}
	
	
}