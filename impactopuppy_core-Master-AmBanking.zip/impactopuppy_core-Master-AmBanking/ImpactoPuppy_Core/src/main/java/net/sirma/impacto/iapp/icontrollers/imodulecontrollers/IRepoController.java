/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 18, 2019 | #BVB00064   | Initial writing
      |0.2.1       | Vijay 		| Feb 23, 2019 | #BVB00070   | Issue for operation failed when wrong CIF entered
      |0.2.1       | Vijay 		| Feb 27, 2019 | #BVB00076   | Population of CIF data in ECOMM Repo
      |0.2.1       | Vijay 		| Feb 27, 2019 | #BVB00079   | Adding Biometrics and Other details to CIF Response 
      |0.2.1       | Niegil 	| Mar 02, 2019 | #NYE00001   | Redjusting Search Vals
      |0.2.1       | Vijay  	| Apr 02, 2019 | #BVB00108   | Loading data based on the Status
      |0.3.9       | Vijay  	| May 26, 2019 | #BVB00156   | Performance For repo loading
      |0.3.14.283  | Bhuvi  	| Jun 19, 2019 | #BHUVI001   | Add threading for repo loading
      |0.3.15.298  | Bhuvi  	| Jun 19, 2019 | #BHUVI002   | Added key token should not updated
      |0.3.16      | Vijay  	| Jul 10, 2019 | #BVB00180   | Repo Query with Accounts and without Accounts 
      |0.3.17      | Vijay 		| Jul 20, 2019 | #BVB00186   | Joint Partner Details
      |0.3.16.334  | Bhuvi 		| Aug 1,  2019 | #BHUVI003   | Additional Key Mode added in Ecom Repo.
      |0.3.16.334  | Pappu      | Jun 23, 2021 | #PKY00018   | Added Mobile and Email in CIF Response.
      |0.3.2       | Sushmita   | Jul 05, 2021 | #SKP00001   | Added code to change the mode in rqst to search from DOB
      |0.3.2       | Pappu      | Aug 02 2021  | #PKY00034   | Added condition to handle AccountClassType
      |0.3.2       | Pappu      | Aug 19 2021  | #PKY00042   | Added CustomerCategory in response for payOutAccount memberId
      |0.3.2	   | Manikanta  | Apr 29 2022  | #MVT00056	 | Added code to update email and mobile in Repo collection
      |0.3.2       | Sushmita   | AUG 26,2022  | #SKP00002   | Added code to Update digiCheck in cif and repo coll
      |0.3.2	   | Sindhu     | SEP 28, 2022 | #SRM00001   | Added code to update the profile pic and the date it is created
      |0.3.2	   | Sindhu     | SEP 30, 2022 | #SRM00002   | Added code to display pic update message
      |0.3.2	   | Sindhu     | May 29, 2022 | #SRM00038   | Added code to get account data summary
      |0.3.2	   | Srikanth   | Jul 10, 2023 | #SRI00001   | Added validation for customer dob
      |0.3.2	   | Pavithra   | Jul 10, 2023 | #PAV00003   | Added OR condition to validate using dob
      |0.3.2	   | Sindhu     | AUG 02, 2023 | #SRM00052   | Handled code to retrieve the required data from CIF collection
      |0.3.2	   | Srikanth   | Nov 16, 2023 | #SRI00024   | Handled code to retrieve the customer full name for the account fetching screen
      |0.3.2	   | Pavithra   | Dec 08, 2023 | #PAV00030   | Handled code for masking custAccNo 
    ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins

package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IRepoController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(IRepoController.class);
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private ImpactoUtil I$Imputils = new ImpactoUtil();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OABREPOQ") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = QueryRepo(isonMsg);
				// #BVB00076 Starts
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OABREPOQ") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = CreateRepo(isonMsg);
			} // #BVB00076 Ends
			else if(I$utils.$iStrFuzzyMatch(Scr, "OABCUPDT") && I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {	//#MVT00056 changes
				isonMsg = updateRepo(isonMsg);
			}
			else if(I$utils.$iStrFuzzyMatch(Scr, "OABUPDPC") && I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {	//#MSA changes
				isonMsg = updatePrfPic(isonMsg);
			}
			else if(I$utils.$iStrFuzzyMatch(Scr, "SABREPOQ") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {	////#SRM00038 
				isonMsg = accountSummaryData(isonMsg);
			}			
			else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}
	// #MVT00056 Starts
	public JsonObject updateRepo(JsonObject isonMsg) {
		JsonObject ibody = new JsonObject();
		boolean digiCheck;
		try {
			JsonObject mobObject = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject emailObject = new JsonObject();
			JsonObject cifObject = new JsonObject();
			JsonObject filtr = new JsonObject();
			String Mode = null;
			digiCheck = false;

			ibody = isonMsg.get("i-body").getAsJsonObject();
			
			if (ibody.has("mode") && I$utils.$iStrFuzzyMatch(ibody.get("mode").getAsString(), "CID")) {   //#SRM00001 changes starts
				try {
					cifObject.addProperty("CustomerImg", ibody.get("data").getAsString());
					filtr.addProperty("Key_Owner", ibody.get("cifId").getAsString());
					filtr.addProperty("Key_Mode", ibody.get("mode").getAsString());
					db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", cifObject, filtr, "true");

					cifObject.addProperty("changedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
					cifObject.addProperty("isProfilePicChanged", "Y");
					filtr = new JsonObject();
					filtr.addProperty("CustomerId", ibody.get("cifId").getAsString());
					db$Ctrl.db$UpdateRow("ICOR_M_CBS_CIF_DATA", cifObject, filtr, "true");
					ibody.remove("data");  //#SRM00002 changes
					ibody.addProperty("ProfilePic_Status", "Image Updated Successfully");     
					return isonMsg;
				} catch (Exception e) {
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATED DATA");
					return isonMsg;
				} //#SRM00001 changes end
			}
			JsonObject CParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);			
		    JsonArray keyMode = CParam.get("KeyMode").getAsJsonArray();
			String mobileId = ibody.get("mobileIsdCode").getAsString() + ibody.get("mobileId").getAsString();
			String emailId = ibody.get("emailId").getAsString();
			if (ibody.has("digiCheck")) {
				 digiCheck = ibody.get("digiCheck").getAsBoolean();  //SKP0002 Changes 
			}
						
			mobObject.addProperty("Mob_Number1", mobileId);
			emailObject.addProperty("toemailid1", emailId);

			for (int i = 0; i < keyMode.size(); i++) {
				try {
					JsonObject fltr = new JsonObject();
					JsonObject ecomm = new JsonObject();
					Mode = keyMode.get(i).getAsString();
					if (I$utils.$iStrFuzzyMatch(Mode, "CMB")) {
						ecomm.addProperty("Key", mobileId);
					}
					if (I$utils.$iStrFuzzyMatch(Mode, "CEM")) {
						ecomm.addProperty("Key", emailId);
					}
					ecomm.add("Mob_Numbers", mobObject);
					ecomm.add("EmailIds", emailObject);
					ecomm.addProperty("digiCheck", digiCheck); //SKP0002 Changes 
					fltr.addProperty("Key_Owner", ibody.get("cifId").getAsString());
					fltr.addProperty("Key_Mode", Mode);
					db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", ecomm, fltr, "true");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			cifObject.addProperty("CustomerEmailId", emailId);
			cifObject.addProperty("digiCheck", digiCheck);
			cifObject.addProperty("CustomerMobileId", ibody.get("mobileId").getAsString());
			cifObject.addProperty("CustomerMobileIsdNo", ibody.get("mobileIsdCode").getAsString());
			filtr.addProperty("CustomerId", ibody.get("cifId").getAsString());
			db$Ctrl.db$UpdateRow("ICOR_M_CBS_CIF_DATA", cifObject, filtr, "true");
		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATED DATA");
			return isonMsg;
		}
		ibody.addProperty("digiCheck", digiCheck);
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody); //SKP0002 Changes 
		i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
		return isonMsg;
	} // #MVT00056 ends
	// #BVB00076 Starts
	public JsonObject CreateRepo(JsonObject isonMsg) {

		try {
			String keyMode = i$ResM.getBodyElementS(isonMsg, "Key_Mode");
			String creationMode = i$ResM.getBodyElementS(isonMsg, "CreationMode");
			switch (keyMode.substring(0, 1)) {
			case "C": {
				// #BVB00108 Starts
				if (I$utils.$iStrFuzzyMatch(creationMode, "R")) {
					isonMsg = LoadCustomerDataFromRun(isonMsg);
				} else {
					isonMsg = LoadCustomerData(isonMsg);
				}
				// #BVB00108 Ends
				break;
			}
			default:
				break;
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEM + " Data Update failed with: " + e.getMessage());
		}
		return isonMsg;
	}
	//#SRM00038 Changes start
	public JsonObject accountSummaryData(JsonObject isonMsg) {
        JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
        try {
            JsonObject projection = new JsonObject();
            JsonObject filter = new JsonObject();
            JsonObject projection1 = new JsonObject();
            JsonObject filter1= new JsonObject();
            projection.addProperty("CustAcNo", 1);
            projection.addProperty("AcDesc", 1);
            projection.addProperty("AcCcy", 1);
            projection.addProperty("AcBranch", 1);
            projection.addProperty("AccountClassType", 1);
            projection.addProperty("AccountClassDesc", 1);
            projection.addProperty("_id", 0);
            filter.addProperty("CustNo", ibody.get("CustNo").getAsString());
            filter.addProperty("AccountClassType", ibody.get("AccountClassType").getAsString());
            filter1.addProperty("CustomerId", ibody.get("CustNo").getAsString());
            projection1.addProperty("CustomerFullName", 1);//SRI00024 starts
            projection1.addProperty("_id", 0);
           JsonObject CustName = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter1, projection1);
            JsonArray accountData = db$Ctrl.db$GetRows("ICOR_M_CBS_ACCOUNT_DATA", filter, projection);
            for (JsonElement element : accountData) {//PAV00030 Changes Starts
	        	JsonObject obj = element.getAsJsonObject();
	        	String lastFourDigits = obj.get("CustAcNo").getAsString().substring(obj.get("CustAcNo").getAsString().length() - 4);
	        	int maskCharCount = obj.get("CustAcNo").getAsString().length() - 4;
	        	String maskedCustAccNo = "x".repeat(maskCharCount) + lastFourDigits;
	        	obj.addProperty("MaskedCustAccNo", maskedCustAccNo);
            }//PAV00030 Changes Ends
            ibody.addProperty("custName", CustName.get("CustomerFullName").getAsString());
            ibody.addProperty("iRowCnt", accountData.size());
            ibody.add("iRowData", accountData);//SRI00024 ends
            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", ibody);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA RETRIEVED SUCCESSFULLY");
            
        } catch(Exception e) {
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
        }
        return isonMsg;
	}//#SRM00038 Changes end
	//MSA starts
	public JsonObject updatePrfPic(JsonObject isonMsg) {
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		try {
			String userId = ibody.get("userId").getAsString();
			String updtPic = ibody.get("prfPic").getAsString();
			JsonObject fltr = new JsonObject();
			JsonObject updtFld = new JsonObject();
			updtFld.addProperty("prfPic",updtPic);
			fltr.addProperty("userId",userId);
			JsonObject data = db$Ctrl.db$UpdateRow("ICOR_M_USER_PRF", updtFld, fltr, "true");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PROFILE PIC UPDATED SUCCESSFULLY");
		}
		catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATE PROFILE PIC");
		}
		return isonMsg;
	}
	//MSA ends

	public JsonObject LoadCustomerData(JsonObject isonMsg) {
		// JsonObject filter = new JsonObject();
		JsonObject argJson = new JsonObject();

		int runEntriesCount = 0;
		int noOfThread = 5;// BHUVI001 Added
		// JsonArray runEntries = new JsonArray();
		// JsonObject projection = new JsonObject();
		try {

			String collectionName = "ICOR_M_CBS_CIF_DATA"; // #BVB00108
			// Getting entries of the run
			try {
				// filter = new JsonObject();
				// #BVB00108
				// filter.addProperty("RepoLoaded", "N");
				runEntriesCount = db$Ctrl.db$GetCountI(collectionName, "{'RepoLoaded':{$ne:'Y'}}");// #BVB00108
			} catch (Exception e) {
				runEntriesCount = 0;
			}
			// BHUVI001 Starts
			double i$noOfIter = Double.valueOf(runEntriesCount) / noOfThread;
			i$noOfIter = Math.ceil(i$noOfIter);

			int i$noOfIterThread = (int) i$noOfIter;
			if (i$noOfIterThread < 1500) {
				noOfThread = 1;
				i$noOfIter = Double.valueOf(runEntriesCount);
				i$noOfIter = Math.ceil(i$noOfIter);
				i$noOfIterThread = (int) i$noOfIter;
			}
			String sUniqueId = I$Imputils.generateRandomKey();
			argJson.addProperty("uniqueId", sUniqueId);
			argJson.addProperty("totalNumberOfThreads", noOfThread);

			Thread t = null;
			for (int i = 0; i < noOfThread; i++) {

				JsonObject jWrkArgs = new JsonObject();
				JsonObject jArgs = new JsonObject();

				jArgs.addProperty("noOfIter", i$noOfIterThread);
				jArgs.addProperty("threadCount", i);
				jArgs.addProperty("uniqueId", sUniqueId);
				jArgs.addProperty("totalNumberOfThreads", noOfThread);

				jWrkArgs.add("isonMsg", jArgs.deepCopy());
				jWrkArgs.addProperty("clsName",
						"net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRepoController");
				jWrkArgs.addProperty("funcName", "IRepoThreadProcess");
				IThreadController IThread$worker = new IThreadController(jWrkArgs);

				t = new Thread(IThread$worker);

				t.start();
			}
			t.join();
			updateCifData(argJson);
			// BHUVI001 Ends
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, i$ResM.I_CUSMEM + " Data Updated ");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEM + " Data Update failed with: " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject LoadCustomerDataFromRun(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		int runEntriesCount = 0;
		JsonArray runEntries = new JsonArray();
		JsonObject projection = new JsonObject();
		try {
			String runId = i$ResM.getBodyElementS(isonMsg, "RUNID");

			// Getting collection Name from job logger
			filter.addProperty("RUNID", runId);
			JsonObject runDetails = db$Ctrl.db$GetRow("IBRIDGE_S_JOB_LOGGER", filter);
			String collectionName = runDetails.get("COLLECTION_NAME").getAsString();

			// Getting entries of the run

			try {
				filter = new JsonObject();
				filter.addProperty("RUNID", runId);
				runEntriesCount = db$Ctrl.db$GetCountI(collectionName, filter);
			} catch (Exception e) {
				runEntriesCount = 0;
			}

			double i$noOfIter = Math.ceil(runEntriesCount / runEntriesCount);

			for (int i = 0; i < i$noOfIter; i++) {
				projection.addProperty("CustomerId", 1);
				projection.addProperty("CustomerFullName", 1);
				projection.addProperty("CustomerEmailId", 1);
				projection.addProperty("CustomerMobileId", 1); // Mobile NUmber should be added here
				projection.addProperty("CustomerImage", 1); // Customer Pic should be added here

				runEntries = db$Ctrl.db$GetSummRowsArray(collectionName, filter, projection, i, runEntriesCount);

				// prepare for insertion into ECOMM Repo
				JsonArray argjson = new JsonArray();
				for (int j = 0; j < runEntries.size(); j++) {
					JsonArray ecommData = CreateEcommData(runEntries.get(i).getAsJsonObject(), argjson);// BHUVI002
																										// added
					db$Ctrl.db$InsertMany("ICOR_M_ECOMM_REPO", ecommData);
				}

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, i$ResM.I_CUSMEM + " Data Updated for RUNID: " + runId);
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEM + " Data Update failed with: " + e.getMessage());
		}
		return isonMsg;
	}

	// #BVB00108 Starts
	public JsonArray CreateEcommData(JsonObject runData, JsonArray cifUpdate) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject ecommObject = new JsonObject();
		Random rand = new Random();
		String keyToken = "";
		JsonArray ecommArray = new JsonArray();
		try {
			// Get the format
			projection.addProperty("ecommRepoTemplate", "1");
			projection.addProperty("KeyMode", "1");
			// BHUVI002 starts
			for (int i = 0; i < cifUpdate.size(); i++) {
				String keyOwnerEcom = cifUpdate.get(i).getAsJsonObject().get("Key_Owner").getAsString();
				String keyOwnerCif = runData.get("CustomerId").getAsString();
				if (I$utils.$iStrFuzzyMatch(keyOwnerEcom, keyOwnerCif)) {
					keyToken = cifUpdate.get(i).getAsJsonObject().get("Key_Token").getAsString();

				}
			}
			JsonObject icorCParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter, projection);
			JsonArray keyModeA = icorCParam.get("KeyMode").getAsJsonArray();

			if (I$utils.$iStrFuzzyMatch(keyToken, "")) {
				keyToken = I$impactoUtil.generateRandomKey(16);
			}
			// BHUVI002 ends
			JsonObject tempObject = new JsonObject();
			String emailId = runData.get("CustomerEmailId").getAsString();
			String mobileId = runData.get("CustomerMobileId").getAsString();
			mobileId = runData.get("CustomerMobileIsdNo").getAsString() + mobileId;//BHUVI003 ISD should come first
			for (int i = 0; i < keyModeA.size(); i++) {
				ecommObject = new JsonObject();
				String keyMode = keyModeA.get(i).getAsString();
				switch (keyMode) {
				case "CEM":
					ecommObject.addProperty("Key_Mode", keyMode);
					ecommObject.addProperty("Key", emailId);
					break;
				case "CID":
					ecommObject.addProperty("Key_Mode", keyMode);
					ecommObject.addProperty("Key", runData.get("CustomerId").getAsString());
					break;
				case "CMB":
					ecommObject.addProperty("Key_Mode", keyMode);
					ecommObject.addProperty("Key", mobileId);
					break;
				case "CTK":
					ecommObject.addProperty("Key_Mode", keyMode);
					ecommObject.addProperty("Key", keyToken);
					break;
				case "CWA":
					ecommObject.addProperty("Key_Mode", keyMode);
					ecommObject.addProperty("Key", mobileId);
					break;
					// #BHUVI003 Begins
				case "CPT":
					String pptNo = runData.get("CustomerPassportNo").getAsString();
					if (!I$utils.$iStrFuzzyMatch(pptNo, "")) {
						ecommObject.addProperty("Key_Mode", keyMode);
						ecommObject.addProperty("Key", pptNo);
						break;
					} else {
						continue;
					}
				case "CDL":
					String dlNo = runData.get("CustomerDriversPermitNo").getAsString();
					if (!I$utils.$iStrFuzzyMatch(dlNo, "")) {
						ecommObject.addProperty("Key_Mode", keyMode);
						ecommObject.addProperty("Key", dlNo);
						break;
					} else {
						continue;
					}
				case "CNI":
					String natNo = runData.get("CustomerNationalId").getAsString();
					if (!I$utils.$iStrFuzzyMatch(natNo, "")) {
						ecommObject.addProperty("Key_Mode", keyMode);
						ecommObject.addProperty("Key", natNo);
						break;
					} else {
						continue;
					}
                    // #BHUVI003 Ends
				default:
					break;
				}

				ecommObject.addProperty("Name", runData.get("CustomerFullName").getAsString());
				tempObject = new JsonObject();
				tempObject.addProperty("Mob_Number1", mobileId);
				ecommObject.add("Mob_Numbers", tempObject);

				tempObject = new JsonObject();
				tempObject.addProperty("toemailid1", emailId);
				ecommObject.add("EmailIds", tempObject);

				tempObject = new JsonObject();
				tempObject.addProperty("Whatsapp_Numbers1", mobileId);
				ecommObject.add("Whatsapp_Numbers", tempObject);

				tempObject = new JsonObject();
				tempObject.addProperty("EmailIdsAlt1", emailId);
				ecommObject.add("EmailIdsAlt", tempObject);

				tempObject = new JsonObject();
				tempObject.addProperty("Mob_NumbersAlt1", mobileId);
				ecommObject.add("Mob_NumbersAlt", tempObject);

				tempObject = new JsonObject();
				tempObject.addProperty("Whatsapp_NumbersAlt1", mobileId);
				ecommObject.add("Whatsapp_NumbersAlt", tempObject);

				ecommObject.addProperty("Key_Owner", runData.get("CustomerId").getAsString()); // Need to check this
				ecommObject.addProperty("Key_Token", keyToken);
				ecommObject.addProperty("prfPic", runData.get("CustomerImg").getAsString());
				ecommObject.addProperty("prfSig", runData.get("CustomerSig").getAsString());
				ecommObject.addProperty("active", runData.get("Active").getAsString());

				// ecommObject.addProperty("identityIME", "");
				// String fullName = runData.get("CustomerFullName").getAsString();
				// String[] name = fullName.split(" ");
				// // Getting Biometrics
				// filter = new JsonObject();
				// filter.addProperty("contactDetails.emailId",
				// runData.get("CustomerEmailId").getAsString());
				// filter.addProperty("personalInfo.firstName", name[0]);
				// filter.addProperty("personalInfo.lastName", name[1]);
				// // filter.addProperty("personalInfo.firstName",
				// // runData.get("CustomerFullName").getAsString());
				//
				// JsonObject kycApplication = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION",
				// filter);
				// if (!I$utils.$isNull(kycApplication)) {
				// ecommObject.add("bioMetrics",
				// kycApplication.get("bioMetrics").getAsJsonObject());
				// }

				ecommArray.add(ecommObject);

				// db$Ctrl.db$InsertRow("ICOR_M_ECOMM_REPO", ecommObject);

			}

		} catch (Exception e) {
			ecommArray = null;
			e.getMessage();

		}

		return ecommArray;

	}

	// #BVB00108 Ends
	// #BVB00076 Ends
	public JsonObject QueryRepo(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject i$res = new JsonObject();
		JsonObject i$CustDet =new JsonObject(); //PKY00042 changes
		JsonArray accountData = new JsonArray();// #BVB00186
		try {
			String keyMode = i$ResM.getBodyElementS(isonMsg, "Key_Mode");
			String keyValue = i$ResM.getBodyElementS(isonMsg, "Key_Value");
			String Sopr2 = i$ResM.getOpr2(isonMsg); // #BVB00180
			// SKP00001 Starts
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			// SKP00001 Ends
			/*
			 * switch (keyMode) { case "CEM": //filter.addProperty("EmailIds.toemailid1",
			 * keyValue); filter.addProperty("Key", keyValue); -- Niegil Fixes break; case
			 * "CID": filter.addProperty("Key_Owner", keyValue); break; case "CMB":
			 * filter.addProperty("Mob_Numbers.Mob_Number1", keyValue); break; case "CTK":
			 * filter.addProperty("Key_Token", keyValue); break; case "CWA":
			 * filter.addProperty("Whatsapp_Numbers.Whatsapp_Numbers1", keyValue); break;
			 * default: break; }
			 */ // #NYE00001 Comments
			// SKP00001 Starts
			try {
				
				if (I$utils.$iStrFuzzyMatch(keyMode, "CDB")||(i$body.has("dob")&& I$utils.$iStrFuzzyMatch(keyMode, "CID"))) { //PAV00003 changes 
					 i$CustDet = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", "{'CustomerId':'" + i$body.get("Key_Value").getAsString() + "','CustomerDobDate':'" + i$body.get("dob").getAsString() + "'}");
					if (!I$utils.$isNull(i$CustDet)) {
//						JsonObject TecuUser = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", "{'key':'" + i$body.get("Key_Value").getAsString() + "'}");
//						if (I$utils.$isNull(TecuUser)) {
							keyMode = "CID";
							i$body.addProperty("Key_Mode", "CID");
//						}
					}else {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid or Unknown Member or Customer ID or Invalid Dob"); //#SRM00054 error message changes
					}
				} else if(I$utils.$iStrFuzzyMatch(keyMode, "CID")) {
					 i$CustDet = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", "{'CustomerId':'" + i$body.get("Key_Value").getAsString()+ "'}");
				}
			} catch (Exception e) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Failed to retrive data" + e.getMessage());
			};
		    // SKP00001 Ends
			if (I$utils.$iStrFuzzyMatch(keyMode.substring(0, 1), "C")) {
				filter.addProperty("Key_Mode", keyMode);
				filter.addProperty("Key", keyValue); // #NYE00001

				JsonObject icorMEcomRepo = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", filter);

				if (!I$utils.$isNull(icorMEcomRepo)) { // #BVB00070

					String cif = icorMEcomRepo.get("Key_Owner").getAsString();
					String prfPic = icorMEcomRepo.get("prfPic").getAsString();
					String name = icorMEcomRepo.get("Name").getAsString();
					//#PKY00018 starts
					String emailId = icorMEcomRepo.get("EmailIds").getAsJsonObject().get("toemailid1").getAsString();
					String mobileNo = i$CustDet.get("CustomerMobileId").getAsString(); //SRM00052 changes
					String Mob_NumberISD= new String();
					try {
						 Mob_NumberISD = i$CustDet.get("CustomerMobileIsdNo").getAsString();//SRM00052 changes
					}catch(Exception e) {
						e.printStackTrace();
					}
					//#PKY00018 ends
					
					// String passIME = icorMEcomRepo.get("passIME").getAsString(); // Need to add
					// this TO DO
					// BVBCurr for Branches allowed records pick up
					// Getting allowed Branches
					
						
					// #BVB00186 Starts 
//					String userId = IResManipulator.iloggedUser.get();
//					JsonArray userABrn = db$Ctrl.getUserAllowedBrns(userId);
//					String alwBrn = "{'$in':['";
//					if (userABrn.size() > 0) {
//						for (int i = 0; i < userABrn.size(); i++) {
//							// {'$in':[]}
//							String runningBrn = userABrn.get(i).getAsString();
//							if (i <= userABrn.size() - 2) {
//								alwBrn = alwBrn + runningBrn + "','";
//							} else {
//								alwBrn = alwBrn + runningBrn + "']}";
//							}
//						}
//					} else {
//						alwBrn = alwBrn + "']}";
//					}
//					// Should not get the self account details
//					filter = new JsonObject();
//					filter.addProperty("userId", userId);
//					JsonObject icorMusrPf = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter);
//					String memberNo = icorMusrPf.get("memberNo").getAsString();
//
//					// {'$and' :[ {'CustNo':'105986', 'AcBranch': {'$in':['100','200']}}, {'CustNo':
//					// {'$ne':'105986'}}]}
//
//					filter = new JsonObject();
//					filter.addProperty("CustNo", cif);
//					filter.addProperty("AcBranch", alwBrn);
//					// String filterS = "{'CustNo':'"+ cif +"','AcBranch':"+ alwBrn +" }";
//					String filterS = "{'$and' :[ {'CustNo':'" + cif + "', 'AcBranch': " + alwBrn
//							+ "}, {'CustNo': {'$nin':['" + memberNo + "']}}]}";
//
//					projection.addProperty("CustAcNo", "1");
//					projection.addProperty("AcDesc", "1");
//					// projection.addProperty("CustNo", "1");
//					projection.addProperty("AcCcy", "1");
//					projection.addProperty("AcBranch", "1");
//					projection.addProperty("CustomerImg", "1");
//
//					JsonArray accountData = new JsonArray();
//					// #BVB00180 Starts 
					if (!I$utils.$iStrFuzzyMatch(Sopr2, "WOA")) {
						if(i$body.has("AccountClassType") && !I$utils.$iStrBlank(cif)) {     //#PKY00034 changes
							try {
								//JsonObject cif$ClassType = new JsonObject();
								String cif$ClassType= i$body.get("AccountClassType").getAsString();
								IDataValidator.J$TempStorage.get().addProperty("AccountClassType", cif$ClassType);
							}catch(Exception e) {
							}
						}
						accountData = db$Ctrl.db$getAccounts(cif);
						//accountData = db$Ctrl.db$GetRows("ICOR_M_CBS_ACCOUNT_DATA", filterS, projection);
						if (accountData.size() > 0) {
							// Get Joint Accounts related to this accounts: 
							
							// #BVB00186 Ends
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ACCOUNTS RETRIEVED SUCESSFULLY");
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
						}
					}else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, i$ResM.I_CUSMEM +  " RETRIEVED SUCESSFULLY");
					}
					// #BVB00180 Ends
					i$res.addProperty("cif", cif);
					i$res.addProperty("prfPic", prfPic);
					i$res.addProperty("name", name);
					i$res.add("accountData", accountData);
					//#PKY00018 starts
					i$res.addProperty("emailId", emailId);
					i$res.addProperty("mobileNo", mobileNo);
					i$res.addProperty("Mob_NumberISD", Mob_NumberISD);
					try {
						i$res.addProperty("CustomerCategory", i$CustDet.get("CustomerCategory").getAsString());  //PKY00042 chnages
					}catch(Exception e) {
					}
					//#PKY00018 ends

					// #BVB00079 Starts
					// Adding Biometrics if Available
					if (icorMEcomRepo.has("bioMetrics")) {
						i$res.add("bioMetrics", icorMEcomRepo.get("bioMetrics").getAsJsonObject());
					}
					// Adding identityIME if available
					if (icorMEcomRepo.has("identityIME")) {
						i$res.addProperty("identityIME", icorMEcomRepo.get("identityIME").getAsString());
					}
					i$res.addProperty("keyToken", icorMEcomRepo.get("Key_Token").getAsString());
					// #BVB00079 Ends

					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
					
					// #BVB00070 Starts
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
				}
			} else if (I$utils.$iStrFuzzyMatch(keyMode.substring(0, 1), "A")) {
				String filterS = "{'CustAcNo': {$regex:'" + keyValue + "'}}";
				JsonObject AccountData = db$Ctrl.db$GetRow("", filterS);

			}

			// #BVB00070 Ends
		} catch (Exception e) {
			logger.debug("Failed during data retrieval: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
		}
		return isonMsg;
	}

	public void IRepoThreadProcess(JsonObject argJson) {
		// BHUVI001 Starts
		JsonObject projection = new JsonObject();
		JsonArray runEntries = new JsonArray();
		JsonArray failedCif = new JsonArray();
		JsonArray succesCif = new JsonArray();
		JsonArray ecommDataA = new JsonArray();
		JsonArray filterA = new JsonArray();
		JsonObject cifDataUpdateO = new JsonObject();
		JsonObject threadLog = new JsonObject();
		JsonObject filterthreadLog = new JsonObject();
		JsonObject filter = new JsonObject();

		int i$noOfIterThread = argJson.get("noOfIter").getAsInt();
		int threadCount = argJson.get("threadCount").getAsInt();
		// BHUVI001 Ends
		try {
			String collectionName = "ICOR_M_CBS_CIF_DATA"; // #BVB00108
			double i$noOfIter = Double.valueOf(i$noOfIterThread) / 100;
			i$noOfIter = Math.ceil(i$noOfIter);

			for (int i = 0; i < i$noOfIter; i++) {
				projection.addProperty("CustomerId", 1);
				projection.addProperty("CustomerFullName", 1);
				projection.addProperty("CustomerEmailId", 1);
				projection.addProperty("CustomerMobileId", 1);
				projection.addProperty("CustomerImg", 1);
				projection.addProperty("CustomerMobileIsdNo", 1);
				projection.addProperty("CustomerDob", 1);
				projection.addProperty("Active", 1);
				projection.addProperty("CustomerSig", 1);
				projection.addProperty("CustomerPassportNo", 1);// #BHUVI003 Added
				projection.addProperty("CustomerDriversPermitNo", 1);// #BHUVI003 Added
				projection.addProperty("CustomerNationalId", 1);// #BHUVI003 Added

				int skip = 100 * i;// BHUVI001 Added
				skip = skip + (i$noOfIterThread * threadCount);// BHUVI001 Added
				runEntries = db$Ctrl.db$GetSummRowsArray(collectionName, "{'RepoLoaded':{$ne:'Y'}}", projection, skip,
						100, "Y");

				JsonObject iterate = new JsonObject();
				JsonArray cifObj = new JsonArray();
				JsonObject projection1 = new JsonObject();
				projection1.addProperty("Key_Owner", 1);
				projection1.addProperty("Key_Token", 1);

				// BHUVI002 starts
				for (JsonElement pa : runEntries) {
					iterate = pa.getAsJsonObject();
					cifObj.add(iterate.get("CustomerId").getAsString());
				}
				String collectionNameEcom = "ICOR_M_ECOMM_REPO"; // #BVB00108

				JsonArray runCifEcom = db$Ctrl.db$GetSummRowsArray(collectionNameEcom,
						"{$and:[{'Key_Token':{$nin:['','null']}},{'Key_Owner': { $in:" + cifObj
								+ "}},{'Key_Mode':'CTK'}]}",
						projection1, 0, 100, "Y");
				// BHUVI002 ends
				// prepare for insertion into ECOMM Repo
				// #BVB00156 Starts

				// cifDataUpdateO.addProperty("RepoLoaded", "Y");
				String sCustomerId = null;
				// #BVB00156 Ends
				for (int j = 0; j < runEntries.size(); j++) {
					// #BVB00108 Starts
					JsonObject i$runningObj = runEntries.get(j).getAsJsonObject();
					sCustomerId = i$runningObj.get("CustomerId").getAsString();
					// // Delete existing data before loading
					// filter = new JsonObject();
					JsonArray filterArray = new JsonArray();
					// filter.addProperty("Key_Owner",
					// i$runningObj.get("CustomerId").getAsString());
					// db$Ctrl.db$Remove("ICOR_M_ECOMM_REPO", filter);
					// #BVB00108 Ends
					try {
						JsonArray ecommData = CreateEcommData(i$runningObj, runCifEcom);// BHUVI002 added jsonarray
						// Based on the Key_Mode and Key_Owner, we will do upsert
						if (!I$utils.$isNull(ecommData)) {
							for (int k = 0; k < ecommData.size(); k++) {
								String keyMode = ecommData.get(k).getAsJsonObject().get("Key_Mode").getAsString();
								String keyOwner = ecommData.get(k).getAsJsonObject().get("Key_Owner").getAsString();
								filter = new JsonObject();
								filter.addProperty("Key_Mode", keyMode);
								filter.addProperty("Key_Owner", keyOwner);
								filterArray.add(filter);

							}
							// db$Ctrl.db$InsertMany("ICOR_M_ECOMM_REPO", ecommData);
							// #BVB00156 Starts
							ecommDataA.addAll(ecommData);
							filterA.addAll(filterArray);
							if (ecommDataA.size() > 100) {
								db$Ctrl.db$UpdateMany("ICOR_M_ECOMM_REPO", ecommDataA, filterA, "true");
								ecommDataA = new JsonArray();
								filterA = new JsonArray();
							}
							succesCif.add(sCustomerId);
						} else {
							failedCif.add(sCustomerId);
						}
						// #BVB00156 Ends
					} catch (Exception e) {
						failedCif.add(sCustomerId);

						e.getMessage();
					}
					/*
					 * filter = new JsonObject(); filter.addProperty("CustomerId",
					 * i$runningObj.get("CustomerId").getAsString()); // #BVB00156 Starts
					 * filterCifA.add(filter); cifDataUpdateA.add(cifDataUpdateO);
					 * if(cifDataUpdateA.size() > 100) { //
					 * db$Ctrl.db$UpdateRow("ICOR_M_CBS_CIF_DATA", "{'RepoLoaded':'Y'}", filter);
					 * db$Ctrl.db$UpdateMany("ICOR_M_CBS_CIF_DATA", cifDataUpdateA, filterCifA,
					 * "false"); cifDataUpdateA = new JsonArray(); filterCifA = new JsonArray(); }
					 */
					// #BVB00156 Ends
				}
			}

			// BHUVI001 Starts
			threadCount = threadCount + 1;

			JsonObject get = new JsonObject();
			JsonArray threadLogger = new JsonArray();
			// JsonObject thread = new JsonObject();
			get.add("failedCif", failedCif);
			get.add("succesCif", succesCif);

			threadLogger.add(get);
			threadLog.add("threadLogger" + threadCount, threadLogger);

			JsonObject filterArray = new JsonObject();
			filterArray.addProperty("unqId", argJson.get("uniqueId").getAsString());
			filterArray.addProperty("threadLogger.threadNumber", threadCount);

			db$Ctrl.db$UpdateMany("ICOR_M_ECOMM_REPO", ecommDataA, filterA, "true");

			filterthreadLog.addProperty("unqId", argJson.get("uniqueId").getAsString());
			// filterthreadLog.addProperty("threadLogger"+threadCount, threadCount);

			threadLog.addProperty("totalNumberOfThreads", 5);
			threadLog.addProperty("completedThreads", threadCount);
			// threadLog.add("threadLogger", threadLogger);

			db$Ctrl.db$UpdateRow("ICOR_M_IREPO_THREAD_LOG", threadLog, filterthreadLog, "true");
			// db$Ctrl.db$UpdateRowArray("ICOR_M_IREPO_THREAD_LOG", thread, filterArray,
			// "true","Y");
			// BHUVI001 Ends
		} catch (Exception e) {
			e.getMessage();
		}

	}

	// BHUVI001 Starts
	private void updateCifData(JsonObject argJson) {

		JsonObject filter = new JsonObject();
		JsonArray Doc = new JsonArray();

		try {
			int totalNumberOfThreads = argJson.get("totalNumberOfThreads").getAsInt();
			filter.addProperty("unqId", argJson.get("uniqueId").getAsString());
			JsonObject threadKey = db$Ctrl.db$GetRow("ICOR_M_IREPO_THREAD_LOG", filter);

			for (int i = 1; i <= totalNumberOfThreads; i++) {
				if (threadKey.has("threadLogger" + i)) {
					JsonArray i$updateCif = threadKey.get("threadLogger" + i).getAsJsonArray();
					JsonObject iterate = new JsonObject();

					for (JsonElement pa : i$updateCif) {
						iterate = pa.getAsJsonObject();
					}
					JsonArray succesCif = iterate.get("succesCif").getAsJsonArray();

					JsonObject isetRepo = new JsonObject();
					isetRepo.addProperty("RepoLoaded", "Y");
					Doc.add(isetRepo);
					db$Ctrl.db$UpdateMany("ICOR_M_CBS_CIF_DATA", isetRepo, succesCif, "CustomerId", "false");

				}
			}
		} catch (Exception e) {
			e.getMessage();
		}
	} // BHUVI001 Ends

	public IRepoController() {
		// Constructor
	}

}