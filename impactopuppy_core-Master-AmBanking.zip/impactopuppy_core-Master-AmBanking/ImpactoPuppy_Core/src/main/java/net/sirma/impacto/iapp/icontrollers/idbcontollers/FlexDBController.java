/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Jan 24, 2019 | #00000001   | Initial writing
      |0.2.1       | Vijay 		| Mar 06, 2019 | #BVB00088   | Changes for Generic Adapter response handling
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
 package net.sirma.impacto.iapp.icontrollers.idbcontollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iworkers.idbworkers.IoracleWorker;

public class FlexDBController {
	private static final Logger logger = LoggerFactory.getLogger(FlexDBController.class);
	private IResManipulator i$ResM = new IResManipulator();
	public JsonObject db$FlxControllerResult(JsonObject reqMessage, JsonObject argJson) {
		try {
			JsonObject result$ = null;
			IoracleWorker I$oracleWorker = new IoracleWorker();
			result$ = I$oracleWorker.processDBOpr(reqMessage, argJson);
			return result$;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Flx DB Controller Error: " + e.getMessage());
			// #BVB00088 Starts
			reqMessage = i$ResM.iHandleResStat(reqMessage, i$ResM.I_ERR, "FAILED IN OPERATION", e.getMessage());
			return reqMessage;
			// #BVB00088 Ends
		}
	};
	
}
//#00000001 Ends