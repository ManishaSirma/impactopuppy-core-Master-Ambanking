/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Jan 15, 2019 | #BVB00039   | Initial writing	
      |0.2.1       | Vijay 		| Feb 12, 2019 | #BVB00056   | Added Query and Response format Changed for Scanning
	  |0.2.1       | Vijay 		| Feb 27, 2019 | #BVB00077   | HIgh Court Scan 
	  |0.2.1       | Vijay 		| Mar 05, 2019 | #BVB00083   | Missing fields in response pf SDNScan
	  |0.3.2       | Vijay 		| Apr 04, 2019 | #BVB00109   | Sdn to consider the percentage maintained at field level in COnfiguration
	  |0.3.6       | Vijay 		| Apr 26, 2019 | #BVB00130   | Making the code generic for all fields  
	  |0.3.6       | Vijay 		| Apr 29, 2019 | #BVB00135   | Blocking SDN Scan For empty field values
	  |0.3.8       | Vijay  	| May 14, 2019 | #BVB00152   | SDN new Logical Flow 
      |0.3.9       | Vijay 		| May 21, 2019 | #BVB00154   | Wiki Search separate Function and Wiki Search in SDN
      |0.3.9       | Vijay 		| May 26, 2019 | #BVB00155   | Threshold setter for SDN Scan and Adding fieldName specific search 
      |3.1.2.419   | Hasan 		| Sept 16, 2019| #HASAN005   | Added thread for wiki, duckduckgo, gigablast, entireweb search Api
      |3.1.6.438   | Hasan 		| Jan 09, 2020 | #HASAN006   | replaced function call db$InsertRow() to db$UpdateRow()
      |3.1.6.438   | Syed 		| Feb 18, 2021 | #MAQ10102   | Changed PDF scan logic because of FuzzyWuzzy crashing JVM for ISDN_196
      |3.1.7.438   | Pappu      | Mar 12, 2021 | #PKY00003   | Made the correct and complete flow of pdfScan function by adding method and replacing the place of  jsonobject and array. 
      |3.1.7.438   | Tarun      | May 28, 2021 | #TKS00001   | Commented code for entire search 
      |3.1.7.438   | Pappu      | Nov 24, 2021 | #PKY00064   | Handled sdn scan in json File
      |3.1.7.438   | Pappu      | Dec 14, 2021 | #PKY00065   | Handled kyc job  scanning
      |3.1.7.438   | Pappu      | Dec 21, 2021 | #PKY00067   | handled to assign scanId to applicationId for kyc scan
      |3.1.7.438   | Manikanta  | Jan 18, 2022 | #MVT00029   | Added code for PDF scanning issue
      |3.1.7.438   | Pappu      | Jan 21, 2022 | #PKY00070   | handled single quotes(') containing customer name 
      |3.1.7.438   | Manikanta  | May 05, 2022 | #MVT00056   | Changed the code for web search issue
      |3.1.7.438   | Manikanta  | Jun 28, 2022 | #MVT00063   | Added code to handle Unique Id in SDN Scan collection
      |3.1.7.438   | Manikanta  | Sep 22, 2022 | #MVT00078   | Added Code to Handle empty spaces in Strings
      |3.1.7.438   | Manikanta  | Jun 05, 2023 | #MVT00123   | Added code for sdn scanning of digi members
      ----------------------------------------------------------------------------------------------
*/
// #BVB00039 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Date;

import org.apache.commons.codec.language.Nysiis;
import org.apache.commons.codec.language.Soundex;
 import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.ialgo.Metaphone3;
//import net.sirma.fuzzy.fuzzywuzzy.FuzzySearch;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMacronController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.*;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;

public class SdnScanController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private static final Logger logger = LoggerFactory.getLogger(SdnScanController.class);
	private ISdnScanWorker i$sdnScanWorker = new ISdnScanWorker();
	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	private IMacronController i$ImacroCtrl = new IMacronController();
	private IMbpmContorller i$ImbpmCtrl = new IMbpmContorller();
	private static final ICoreSysReqFwderController i$CoreSys = new ICoreSysReqFwderController();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject filter = new JsonObject();
		JsonObject jWrkArgs = new JsonObject();
		try {

			// ISdnScanController iSdnScan = new ISdnScanController();
			// adding code to get the body elements

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String ScrId = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "sdnScan")) {

				// Creating Thread
//				
//				  jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.isrvccontrollers.SdnScanController");
//				  jWrkArgs.addProperty("funcName", "sdnScanInitiator");
//				  
//				  jWrkArgs.add("isonMsg", isonMsg); 
//				  IThreadController IThread$worker = new
//				  IThreadController(jWrkArgs); Thread t = new Thread(IThread$worker);
//				  t.start();
//				 
				isonMsg = sdnScanInitiator(isonMsg);
				// #BVB00056 Starts
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "sdnQuery")) {
				isonMsg = sdnQuery(isonMsg);
			} else if(I$utils.$iStrFuzzyMatch(SrvOpr, "DIGI_SDNSCAN")) {
				return  digiSDNScan(isonMsg);	//#MVT00123 changes
			}else if(I$utils.$iStrFuzzyMatch(ScrId, "OB2DGTRN")) {
				isonMsg = sdnCheckOpr(isonMsg);	//#MSA00063 changes
//			}else if(I$utils.$iStrFuzzyMatch(ScrId, "OABDGTRN")) {
//				isonMsg = sdnCheckRemarkCheck(isonMsg);	//#MSA00064 changes
			}else if(I$utils.$iStrFuzzyMatch(ScrId, "LABDGTRN")) {
				isonMsg = sdnSummary(isonMsg);	//#MSA00064 changes
			}
			// #BVB00056 Ends
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage());
			e.printStackTrace();
			
		}
		return isonMsg;
	}
	//#MVT00123 begins
	public JsonObject digiSDNScan(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject response = new JsonObject();
			JsonObject projectn = new JsonObject();

			isonMsg = sdnScanInitiator(isonMsg);
			projectn.addProperty("_id", 0);
			projectn.addProperty("maxPercent", 1);
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");
			JsonObject cparam = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter, projectn);

			projectn.remove("maxPercent");
			projectn.addProperty("webScan", 1);
			projectn.addProperty("ScanResultsF", 1);
			filter.addProperty("ScanId", ibody.get("ScanId").getAsString());
			filter.addProperty("ScanType", "SdnScan");
			JsonObject sdnObject = db$Ctrl.db$GetRow("ICOR_M_SDN_SCAN", filter);
			JsonObject scanRes = sdnObject.getAsJsonObject("ScanResultsF");
			int maxres = scanRes.get("MaxPercent").getAsInt();
			if (maxres > cparam.get("maxPercent").getAsInt()) {
				response.addProperty("result",
						"Please note this transaction cannot be processed further. Kindly visit TECU for further Instructions");
				response.add("scanResult", scanRes);
				response.addProperty("ScanId", ibody.get("ScanId").getAsString());
				response.addProperty("sdnCheck", "Y");
			}else {
				response.addProperty("sdnCheck", "N");
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, response);
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed To Scan The User");
		}
		return isonMsg;
	}
	//#MVT00123 ends
	public JsonObject sdnScanInitiator(JsonObject isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			// Building the request
			JsonObject i$body = new JsonObject();
			String sdnConfigId = i$ResM.getBodyElementS(isonMsg, "sdnConfigId");
			if(I$Imputils.isNull(sdnConfigId)){
			//if(I$utils.$iStrFuzzyMatch(sdnConfigId, "") ) {
				sdnConfigId = "KYC" ;
			}
 			i$body = i$ResM.getBody(isonMsg);
			argJson.addProperty("applicationId", i$ResM.getBodyElementS(isonMsg, "applicationId"));
			argJson.addProperty("referenceNo", i$ResM.getBodyElementS(isonMsg, "referenceNo"));
			argJson.addProperty("sdnConfigId", sdnConfigId);// #BVB00155
			//#PKY00065 starts
			try {
				if(i$body.has("ScanType") && I$utils.$iStrFuzzyMatch(i$body.get("ScanType").getAsString().substring(i$body.get("ScanType").getAsString().length()-4), "Scan")) { 
					argJson.addProperty("ScanType", i$ResM.getBodyElementS(isonMsg, "ScanType"));
					argJson.addProperty("CustomerId", i$ResM.getBodyElementS(isonMsg, "CustomerId"));
					argJson.addProperty("peroidCode", i$ResM.getBodyElementS(isonMsg, "peroidCode"));
					argJson.addProperty("financialYear", i$ResM.getBodyElementS(isonMsg, "financialYear"));
					argJson.addProperty("uniqueId", i$ResM.getBodyElementS(isonMsg, "uniqueId"));	//#MVT00063 Changes
				}
			}catch(Exception e) {
				
			}
			//#PKY00065 ends

			JsonObject searchFields = i$ResM.getBodyElementO(isonMsg, "searchFields");
			//PKY00070 starts
			try {
				Set<String> keys = searchFields.keySet();
				for (String key : keys) {
					String fieldVal = searchFields.get(key).getAsString();
					if (fieldVal.contains("'")) {
						fieldVal = fieldVal.replace("'", "\\'").trim();
						searchFields.addProperty(key, fieldVal);
					}
				}
			} catch (Exception e) {
			}
			//PKY00070 ends
			Set<Entry<String, JsonElement>> entrySet = searchFields.entrySet();

			JsonArray fieldDetails = new JsonArray();
			JsonObject fields = new JsonObject();

			for (Map.Entry<String, JsonElement> entry : entrySet) {
				fields = new JsonObject();
				fields.addProperty("fieldName", entry.getKey());
				fields.addProperty("fieldVal", searchFields.get(entry.getKey()).getAsString());
				fieldDetails.add(fields);
			}
			argJson.add("fieldDetails", fieldDetails);
			argJson.add("searchFields", searchFields.getAsJsonObject());
			// #BVB00109 Commented below Starts
			// Getting Field Mapping
//			filter = new JsonObject();
//			filter.addProperty("Sdn_List_Id", i$ResM.getBodyElementS(isonMsg, "Sdn_List_Id"));
//			JsonArray fieldMapping = new JsonArray();
//			try {
//				fieldMapping = db$Ctrl.db$GetRow("ICOR_M_B2U_SDN", filter).getAsJsonArray("Field_Mapper");
//			} catch (Exception e) {
//
//			}
//			argJson.add("fieldMapping", fieldMapping);
			// #BVB00109 Ends
			argJson = sdnScan(argJson);
			// #BVB00056 Starts
			JsonObject i$res = new JsonObject();
			i$res.addProperty("ScanType", argJson.get("ScanType").getAsString());
			i$res.addProperty("ScanId", argJson.get("ScanId").getAsString());
			//#PKY00065 starts
			try {
				if(i$body.has("ScanType") && I$utils.$iStrFuzzyMatch(i$body.get("ScanType").getAsString().substring(i$body.get("ScanType").getAsString().length()-4), "Scan")) {
					i$res.add("ScanResultsF", argJson.get("ScanResultsF").getAsJsonObject());
					i$res.addProperty("CustomerId", argJson.get("CustomerId").getAsString());
				}
			}catch(Exception e) {
				
			}
			//#PKY00065 ends
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SDN SCAN COMPLETED");
			// #BVB00056 Ends
			return isonMsg;

		} catch (Exception e) {

			JsonObject i$res = new JsonObject();
			
			i$res.addProperty("ScanType", "SdnScan");
			i$res.addProperty("ScanId", I$Imputils.generateRandomKey());
 			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			 
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed with", e.getMessage());
			logger.debug("Failed in SDN Scan Initiator: " + e.getMessage());
			return isonMsg;
		}

	}

	public JsonObject sdnScan(JsonObject argJson) throws IOException, ParseException {
		JsonObject response = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		String finalAlertList = "";
		String webScan = "webScan";
		JsonArray i$tasks = new JsonArray();
		JsonArray hitListResponse = new JsonArray();
		JsonArray hitNameList = new JsonArray();

		try {

			// hitListResponse response = new hitListResponse();
			JsonObject scanDetailsTemp = new JsonObject();
			JsonArray scanDetailsArrayTemp = new JsonArray();
			double runningPercent = 0;
			double maxPercent = 0;
			String maxStatus = null;
			String alertList = new String();
			String alertMsg = new String();
			String CollName = "ICOR_M_SDN_DETAIL";
			String sdnConfigId = argJson.get("sdnConfigId").getAsString(); // #BVB00155
			// Making this object Driven
			JsonObject searchFields = argJson.getAsJsonObject("searchFields");
			JsonArray fieldDetails = new JsonArray();
			fieldDetails = argJson.getAsJsonArray("fieldDetails");

			// #BVB00109 Starts
			// Get all Configurations here and do a hash of it using Sdn_List_Id and
			// projection
			JsonObject fieldMapper = new JsonObject();
			if(!I$utils.$isNull(i$ResM.getGobalValJObj("fieldMapper"))) {   //#PKY00065 starts
				fieldMapper = i$ResM.getGobalValJObj("fieldMapper");
			}else {
				JsonArray icorMB2USdn = db$Ctrl.db$GetRows("ICOR_M_B2U_SDN", filter, projection);
				for (int i = 0; i < icorMB2USdn.size(); i++) {
					JsonObject i$runningObj = icorMB2USdn.get(i).getAsJsonObject();
					fieldMapper.add(i$runningObj.get("Sdn_List_Id").getAsString(), i$runningObj);
				}
			}//#PKY00065 ends
			argJson.add("fieldMapper", fieldMapper);

			// JsonArray fieldMapping = argJson.getAsJsonArray("fieldMapping");
			// #BVB00109 Ends
			// #BVB00155 Starts 
			// Get the SDN Configuration from param
			filter = new JsonObject();
			filter.addProperty("PARAM", sdnConfigId);
			JsonObject icorcSdnParam = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter);
			// #BVB00155 Ends
			//#PKY00065 starts
			String applicationId = null;
			try {
				 applicationId = argJson.get("applicationId").getAsString(); 	//#HASAN005 Added
			}catch(Exception e) {
			}
			String uniqueScanId = null;
			if(argJson.has("CustomerId")) {
				uniqueScanId = I$Imputils.generateRandomKey()+"-"+argJson.get("CustomerId").getAsString();
				applicationId = uniqueScanId;  //PKY00067 changes
			}else {
				uniqueScanId = I$Imputils.generateRandomKey();
			}
			//#PKY00065 ends
			for (int i = 0; i < fieldDetails.size(); i++) {
				JsonObject i$runningObj = new JsonObject();
				hitListResponse = new JsonArray();
				i$runningObj = fieldDetails.get(i).getAsJsonObject();

				String currField = i$runningObj.get("fieldName").getAsString();
				String currFieldVal = i$runningObj.get("fieldVal").getAsString().toUpperCase(); //#PKY00003
				if(!I$utils.$iStrFuzzyMatch(currFieldVal, "")) {
				// First using the Phonetic Search get the hits
				JsonObject phoenticSearch = new JsonObject();
				// fieldMapper = argJson.getAsJsonObject("fieldMapper");
				phoenticSearch.addProperty("CollName", CollName);
				phoenticSearch.addProperty("ColumnName", currField);
				phoenticSearch.addProperty("text", currFieldVal);
				// phoenticSearch.addProperty("typeOfSearch", "M");
				phoenticSearch.addProperty("typeOfSearch", icorcSdnParam.get("typeOfPhenotic").getAsString()); // #BVB00155
				phoenticSearch.add("fieldMapper", fieldMapper);
				JsonObject i$res = doPhoneticSearch(phoenticSearch);
				hitListResponse.addAll(i$res.getAsJsonArray("hitListResponse"));
				hitNameList.addAll(i$res.getAsJsonArray("hitNameList")); // #BVB00155
				// Then use Distance to get the hits

				JsonObject distanceSearch = new JsonObject();
				// fieldMapper = argJson.getAsJsonObject("fieldMapper");
				distanceSearch.addProperty("CollName", CollName);
				distanceSearch.addProperty("ColumnName", currField);
				distanceSearch.addProperty("text", currFieldVal);
				distanceSearch.addProperty("typeOfSearch", "D");
				distanceSearch.add("fieldMapper", fieldMapper);
				distanceSearch.add("icorcSdnParam", icorcSdnParam);
				i$res = doDistanceSearch(distanceSearch);
				hitListResponse.addAll(i$res.getAsJsonArray("hitListResponse"));
				hitNameList.addAll(i$res.getAsJsonArray("hitNameList"));
				// i$ImacroCtrl.doSDNScan(currField, currFieldVal);
				// Club all of them and build the Scan Details and proceed forward
				JsonObject i$buildObj = new JsonObject();
				i$buildObj.add("hitListResponse", hitListResponse);
				i$buildObj.addProperty("text", currFieldVal);
				i$buildObj.addProperty("ColumnName", currField);
				i$buildObj.addProperty("typeOfSearch", "D");
				i$buildObj.add("hitNameList", hitNameList);
				scanDetailsTemp = buildScanResults(i$buildObj);

//				if (!I$utils.$iStrFuzzyMatch(currFieldVal, "")) // #BVB00135
//
//					scanDetailsTemp = textSearch(CollName, currField, currFieldVal, argJson);
				if (!I$Imputils.isNull(scanDetailsTemp)) {
					scanDetailsArrayTemp.add(scanDetailsTemp);
				}
				if (I$utils.$iStrFuzzyMatch(currField, "FullName") 
						|| I$utils.$iStrFuzzyMatch(currField, "FName") || I$utils.$iStrFuzzyMatch(currField, "LName")) { //#MAQ10102
					// Have to add code for PDF scanning here
					JsonObject highCountIn = new JsonObject();
					String currFieldValue = i$runningObj.get("fieldVal").getAsString();	////#MVT00029 Changes
					highCountIn.addProperty("ScanCriteria", currField);
					highCountIn.addProperty("searchVal", currFieldValue);
					// #BVB00155 Starts 
					JsonArray highCoutIn = pdfScan(highCountIn);
					if (highCoutIn.size() > 0) {
						scanDetailsArrayTemp.addAll(highCoutIn);
					}
					
					if (argJson.has("ScanType") && !I$utils.$iStrFuzzyMatch(argJson.get("ScanType").getAsString()
							.substring(argJson.get("ScanType").getAsString().length() - 4), "Scan")) { // #PKY00065
						JsonArray diliScanCount = diliSdnScan(highCountIn); //#PKY00064 changes																	// changes
						if (diliScanCount.size() > 0) { //#PKY00064 changes
							scanDetailsArrayTemp.addAll(diliScanCount);
						}
					}
					// #BVB00155 Ends
					// #BVB00154 Starts
					// Do Wiki Scan
					//#HASAN005 start
					if (I$utils.$iStrFuzzyMatch(currField, "FullName")) { // #MAQ10102 #MVT00056 Changes
						if (!argJson.has("ScanType")) {// && !I$utils.$iStrFuzzyMatch(argJson.get("ScanType").getAsString() //To avoid web search in cif SDN scanning 
//								.substring(argJson.get("ScanType").getAsString().length() - 4), "Scan")) { // #PKY00065
																											// changes
							try {
								String $ctrler = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IWebSearchController";
								String $callThisFun = "doWebsearch";
								JsonObject jWrkArgs1 = new JsonObject();
								JsonObject jWrkArgs2 = new JsonObject();
								JsonObject jWrkArgs3 = new JsonObject();
								JsonObject jWrkArgs4 = new JsonObject();
								JsonObject jArgs = new JsonObject();
								jArgs.addProperty("applicationId", applicationId);
								jArgs.addProperty("searchKey", toTitleCase(currFieldVal));
								jArgs.addProperty("uniqueScanId", uniqueScanId);
								jArgs.addProperty("webScan", webScan);
								jArgs.addProperty("trnCd", "WikiSearch");
								jWrkArgs1.add("isonMsg", jArgs.deepCopy());
								jArgs.addProperty("trnCd", "duckDuckGoSearch");
								jWrkArgs2.add("isonMsg", jArgs.deepCopy());
								jArgs.addProperty("trnCd", "gigabLastGoSearch");
								jWrkArgs3.add("isonMsg", jArgs.deepCopy());
								jArgs.addProperty("trnCd", "diliSdnScan"); // #PKY00064 starts
								JsonObject jArgs4 = jArgs.deepCopy();
								jArgs4.addProperty("searchKey", i$runningObj.get("fieldVal").getAsString());
								jArgs4.addProperty("fieldName", currField);
								jWrkArgs4.add("isonMsg", jArgs4); // #PKY00064 ends
								// #TKS00001 starts
//							jArgs.addProperty("trnCd", "entireWebSearch");
//							jWrkArgs4.add("isonMsg", jArgs.deepCopy());
								// #TKS00001 ends

								try {
									jWrkArgs1.addProperty("clsName", $ctrler);
									jWrkArgs1.addProperty("funcName", $callThisFun);
									IThreadController IThread$worker1 = new IThreadController(jWrkArgs1);
									Thread t1 = new Thread(IThread$worker1);
									t1.start();
								} catch (Exception e) {
									e.printStackTrace();
								}

								try {
									jWrkArgs2.addProperty("clsName", $ctrler);
									jWrkArgs2.addProperty("funcName", $callThisFun);

									IThreadController IThread$worker2 = new IThreadController(jWrkArgs2);
									Thread t2 = new Thread(IThread$worker2);
									t2.start();
								} catch (Exception e) {
									e.printStackTrace();
								}

								try {
									jWrkArgs3.addProperty("clsName", $ctrler);
									jWrkArgs3.addProperty("funcName", $callThisFun);

									IThreadController IThread$worker3 = new IThreadController(jWrkArgs3);
									Thread t3 = new Thread(IThread$worker3);
									t3.start();
								} catch (Exception e) {
									e.printStackTrace();
								}

								// #PKY00064 starts
								try {
									jWrkArgs4.addProperty("clsName", $ctrler);
									jWrkArgs4.addProperty("funcName", $callThisFun);

									IThreadController IThread$worker4 = new IThreadController(jWrkArgs4);
									Thread t4 = new Thread(IThread$worker4);
									t4.start();
//								  t4.join();
								} catch (Exception e) {
									e.printStackTrace();
								}

								// #PKY00064 ends
								// #TKS00001 starts
//							  try {
//								  jWrkArgs4.addProperty("clsName", $ctrler);
//								  jWrkArgs4.addProperty("funcName", $callThisFun);	
//								  
//								  IThreadController IThread$worker4 = new IThreadController(jWrkArgs4);
//								  Thread t4 = new Thread(IThread$worker4);
//								  t4.start();	
//							  }catch(Exception e) {
//							  	e.printStackTrace();
//							  }
								// #TKS00001 ends
							} catch (Exception e) {
								e.printStackTrace();
							}
						}

					}
				}
			}
			}
			//String applicationId = argJson.get("applicationId").getAsString(); //#HASAN005 Commented //using this line above
			String referenceNo = argJson.get("referenceNo").getAsString();

			int size = scanDetailsArrayTemp.size();
			logger.debug("The size is: " + size);
			JsonObject maxObj = new JsonObject();
			for (int i = 0; i < size; i++) {
				try {
					alertList = ""; // #BVB00130
					JsonObject i$runningScanObj = scanDetailsArrayTemp.get(i).getAsJsonObject().get("ScanResults")
							.getAsJsonObject();
					JsonArray i$runningArr = i$runningScanObj.getAsJsonArray("ScanDetails5");
					// get scan list.. get the name of it and attach to AlertLists
					int sizescan5 = i$runningArr.size();
					// String hitList = i$runningScanObj.get("HitList").getAsString();
					String scanCriteria = i$runningScanObj.get("ScanCriteria").getAsString();
					for (int j = 0; j < sizescan5; j++) {

						JsonObject i$runningObj = i$runningArr.get(j).getAsJsonObject();
						//PKY00070 starts
						try {
							Set<String> keys = i$runningObj.keySet();
							for (String key : keys) {
								String fieldVal = i$runningObj.get(key).getAsString();
								if (fieldVal.contains("\\'")) {
									fieldVal = fieldVal.replace("\\'", "'").trim();
									i$runningObj.addProperty(key, fieldVal);
								}
							}
						} catch (Exception e) {
						}
						//PKY00070 ends
						runningPercent = i$runningObj.get("Percent").getAsDouble();
						String hitList = i$runningObj.get("ScanList").getAsString();
						// #BVB00109 Starts
						JsonObject icorMSdn = fieldMapper.getAsJsonObject(hitList);
						// #BVB00109 Ends
						// add HitList to alertList if not there already.
						if (!alertList.contains(hitList)) {
							if (I$utils.$iStrFuzzyMatch(alertList, "")) {
								alertList = hitList;
								if (!I$utils.$isNull(icorMSdn)) {
									if (!I$utils.$iStrFuzzyMatch(alertMsg, "")) {
										alertMsg = alertMsg + ", " + scanCriteria + " found in: "
												+ icorMSdn.get("Sdn_List_Name").getAsString();
									} else {
										alertMsg = scanCriteria + " found in: "
												+ icorMSdn.get("Sdn_List_Name").getAsString();
									}
								} else {
									if (!I$utils.$iStrFuzzyMatch(alertMsg, "")) {
										alertMsg = alertMsg + ", " + scanCriteria + " found in: " + hitList;
									} else {
										alertMsg = scanCriteria + " found in: " + hitList;
									}
								}
								// alertMsg = scanCriteria + " found in: " + hitList;
							} else {
								alertList = alertList + ", " + hitList;

								if (!I$utils.$isNull(icorMSdn)) {
									alertMsg = alertMsg + ", " + scanCriteria + " found in: "
											+ icorMSdn.get("Sdn_List_Name").getAsString();
								} else {
									alertMsg = alertMsg + ", " + scanCriteria + " found in: " + hitList;
								}
							}
						}
						if (runningPercent > maxPercent) {
							maxObj = i$runningObj;
							maxPercent = runningPercent;
						}
					}
					if (I$utils.$iStrFuzzyMatch(finalAlertList, "") && !I$utils.$iStrFuzzyMatch(alertList, "")) {
						finalAlertList = alertList; // #BVB00130
					} else if(!I$utils.$iStrFuzzyMatch(alertList, "")){
						finalAlertList = finalAlertList + ", " + alertList;
					}
					// ALert message
				} catch (Exception e) {

				}
			}
			JsonObject ScanResultsF = new JsonObject(); // #BVB00083
			if (!I$utils.$isNull(maxObj)) {
				// String alertMessage = i$sdnScanWorker.alertMessage(alertList);
				ScanResultsF.addProperty("MaxPercent", maxObj.get("Percent").getAsDouble());
				ScanResultsF.addProperty("MaxGrade", maxObj.get("Grade").getAsString()); // #BVB00083
				ScanResultsF.addProperty("AlertLists", finalAlertList);
				ScanResultsF.addProperty("AlertMessage", (alertMsg == null ? "" : alertMsg)); // #BVB00083
			} else {
				ScanResultsF.addProperty("MaxPercent", 0);
				ScanResultsF.addProperty("MaxGrade", ""); // #BVB00083
				ScanResultsF.addProperty("AlertLists", "");
				ScanResultsF.addProperty("AlertMessage", ""); // #BVB00083
			}
			JsonObject ScanDetails = new JsonObject();
			// ScanDetailsLatest ScanDetails = new ScanDetailsLatest();
			ScanDetails.add("ScanDetails", scanDetailsArrayTemp);

			response.addProperty("applicationId", applicationId);
			response.addProperty("referenceNo", referenceNo);

			// response.addProperty("ScanId", i$sdnScanWorker.randomAlphaNumeric());
			String timeStamp = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime());
			response.addProperty("ScanDtTime", timeStamp);
			response.add("ScanResultsF", ScanResultsF);
			response.add("ScanDetailsLatest", ScanDetails);
			//PKY00070 starts
			try {
				Set<String> keys = searchFields.keySet();
				for (String key : keys) {
					String fieldVal = searchFields.get(key).getAsString();
					if (fieldVal.contains("\\'")) {
						fieldVal = fieldVal.replace("\\'", "'").trim();
						searchFields.addProperty(key, fieldVal);
					}
				}
			} catch (Exception e) {
			}
			//PKY00070 ends
			response.add("searchFields", searchFields);			
			// #BVB00056 Starts
			//#PKY00065 starts
			if(argJson.has("ScanType") && I$utils.$iStrFuzzyMatch(argJson.get("ScanType").getAsString().substring(argJson.get("ScanType").getAsString().length()-4), "Scan")) { 
				try {
					response.addProperty("ScanType", argJson.get("ScanType").getAsString());
					response.addProperty("CustomerId", argJson.get("CustomerId").getAsString());
					response.addProperty("peroidCode", argJson.get("peroidCode").getAsString());
					response.addProperty("financialYear", argJson.get("financialYear").getAsString());
					response.addProperty("uniqueId", argJson.get("uniqueId").getAsString());	//#MVT00063 Changes
				}catch(Exception e) {
				}
			}else {
				response.addProperty("ScanType", "SdnScan");
			}
			//#PKY00065 ends
			response.addProperty("ScanId", uniqueScanId);
			// #BVB00056 Ends

			//#HASAN006 Started
			filter = new JsonObject();
			filter.addProperty("applicationId", applicationId);
			filter.addProperty("ScanId", uniqueScanId);
			db$Ctrl.db$UpdateRow("ICOR_M_SDN_SCAN", response, filter,"true");
			//#HASAN006 Ended
			return response;
		} catch (Exception e) {
			return null;
		}
	}

    public static String toTitleCase(String s)
    {
        String result = "";
        s = s.replaceAll("( )+", " ");
        String[] words = s.split(" "); //#MVT00078 Changes

        for (int i = 0; i < words.length; i++) 
        {
        	result += words[i].replaceFirst(words[i].charAt(0)+"", Character.toUpperCase(words[i].charAt(0))+"");
        	if(i != words.length -1)
        		result += " ";
        }

        return result;
    }

	/**
	 * 
	 * ArgJson should have CollName, ColumnName, text and typeOfSearch
	 * 
	 * @param argJson
	 */

	// public void doPhoneticSearch(String CollName, String ColumnName, String text,
	// JsonObject argJson) {
	public JsonObject doPhoneticSearch(JsonObject argJson) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		String typeOfSearch = "";
		JsonArray i$hit = new JsonArray();
		JsonObject fieldMapper = new JsonObject();
		JsonObject i$tasks = new JsonObject();
		JsonArray hitListResponse = new JsonArray();
		JsonArray hitNameList = new JsonArray();
		JsonObject i$res = new JsonObject();
		Soundex soundex = new Soundex();
		Nysiis nysiis = new Nysiis(); 
		Metaphone3 metaphone3 = new Metaphone3();
		try {
			String CollName = argJson.get("CollName").getAsString();
			String ColumnName = argJson.get("ColumnName").getAsString();
			String text = argJson.get("text").getAsString();
			typeOfSearch = argJson.get("typeOfSearch").getAsString();
			fieldMapper = argJson.getAsJsonObject("fieldMapper");
			if (I$utils.$iStrFuzzyMatch(typeOfSearch, "S")) {
				filter.addProperty("_S_" + ColumnName, soundex.soundex(text));
			} else if (I$utils.$iStrFuzzyMatch(typeOfSearch, "N")) {
				filter.addProperty("_N_" + ColumnName, nysiis.encode(text));
			} else if (I$utils.$iStrFuzzyMatch(typeOfSearch, "M")) {
				metaphone3.SetWord(text);
				metaphone3.Encode();
				
				filter.addProperty("_M_" + ColumnName, metaphone3.GetMetaph());
			}

			projection.addProperty(ColumnName, 1);
			projection.addProperty("SdnListId", 1);

			int hitCount = db$Ctrl.db$GetCountI(CollName, filter);
			double i$noOfIter = Math.ceil(Double.valueOf(hitCount) / 100);
			for (int k = 0; k < i$noOfIter; k++) {
				// i$hit = db$Ctrl.db$GetRows(CollName, filterS);
				i$hit = db$Ctrl.db$GetSummRowsArray(CollName, filter, projection, k, 100 * (k + 1));

				// i$hit, ColumnName, text, typeOfSearch, fieldMapper
				argJson.add("i$hit", i$hit);
				argJson.addProperty("ColumnName", ColumnName);
				argJson.addProperty("text", text);
				argJson.addProperty("typeOfSearch", typeOfSearch);

				argJson.add("fieldMapper", fieldMapper);

				i$tasks = buildTasks(argJson);
				hitListResponse.addAll(i$tasks.getAsJsonArray("hitListResponse"));
				hitNameList.addAll(i$tasks.getAsJsonArray("hitNameList"));
			}

			i$res.add("hitListResponse", hitListResponse);
			i$res.add("hitNameList", hitNameList);

		} catch (Exception e) {
			return null;
		}
		return i$res;
	}

	/**
	 * 
	 * 
	 */

	public JsonObject doDistanceSearch(JsonObject argJson) {
		String typeOfSearch = "";
		JsonArray i$hit = new JsonArray();
		JsonObject fieldMapper = new JsonObject();
		JsonObject i$tasks = new JsonObject();
		JsonArray hitListResponse = new JsonArray();
		JsonArray hitNameList = new JsonArray();
		JsonObject i$res = new JsonObject();
		try {
			String CollName = argJson.get("CollName").getAsString();
			String ColumnName = argJson.get("ColumnName").getAsString();
			String text = argJson.get("text").getAsString();
			typeOfSearch = argJson.get("typeOfSearch").getAsString();
			fieldMapper = argJson.getAsJsonObject("fieldMapper");
			JsonObject icorcSdnParam = argJson.getAsJsonObject("icorcSdnParam");// #BVB00155
			i$hit = i$ImacroCtrl.doSDNScan(ColumnName, text, icorcSdnParam);
			argJson.add("i$hit", i$hit);
			argJson.addProperty("ColumnName", ColumnName);
			argJson.addProperty("text", text);
			argJson.addProperty("typeOfSearch", typeOfSearch);

			argJson.add("fieldMapper", fieldMapper);

			i$tasks = buildTasks(argJson);
			i$res.add("hitListResponse", i$tasks.getAsJsonArray("hitListResponse"));
			i$res.add("hitNameList", i$tasks.getAsJsonArray("hitNameList"));

		} catch (Exception e) {
			return null;
		}
		return i$res;
	}

	/**
	 * i$hit -- All hits occurred with the given filter ColumnName -- column name of
	 * the search text -- SDN scan string typeOfSearch --Defines type Of seach --
	 * Phonetic/ Distance and method fieldMapper -- Field Mapper maintained in sdn
	 * Configuration
	 * 
	 * @param argJson
	 * @return
	 */

	// public JsonObject buildTasks(JsonArray i$hit, String ColumnName, String text,
	// String typeOfSearch, JsonObject fieldMapper) {
	public JsonObject buildTasks(JsonObject argJson) {
		double score = 0;
		JsonArray hitListResponse = new JsonArray();
		JsonArray hitNameList = new JsonArray();
		JsonObject ScanCriterias = new JsonObject();
		JsonObject i$res = new JsonObject();
		try {
			JsonArray i$hit = argJson.getAsJsonArray("i$hit");
			String ColumnName = argJson.get("ColumnName").getAsString();
			String text = argJson.get("text").getAsString();
			String typeOfSearch = argJson.get("typeOfSearch").getAsString();
			JsonObject fieldMapper = argJson.getAsJsonObject("fieldMapper");
			for (int i = 0; i < i$hit.size(); i++) {
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = i$hit.get(i).getAsJsonObject();
				JsonObject hitlist = new JsonObject();
				double fieldScore = 0;
				try {
					JsonObject colFieldMapper = I$Imputils
							.objFromArrWithSearch(fieldMapper.get(i$runningObj.get("SdnListId").getAsString())
									.getAsJsonObject().getAsJsonArray("Field_Mapper"), "FieldName", ColumnName);
					fieldScore = colFieldMapper.get("FieldScore").getAsDouble();
				} catch (Exception e) {
					fieldScore = 100;
				}

				hitlist.addProperty("ListName", i$runningObj.get("SdnListId").getAsString());
				hitlist.addProperty("HitType", typeOfSearch);
				hitlist.addProperty("ScanString", text);
				// hitlist.addProperty("MatchString",
				// i$runningObj.get(ColumnName).getAsString());
				if(I$utils.$iStrFuzzyMatch(typeOfSearch, "D")) {
				hitlist.addProperty("MatchString", i$runningObj.get("Micron_ID").getAsString());
				score = I$Imputils.fuzzyWuzzy(text, i$runningObj.get("Micron_ID").getAsString());
				}else {
					hitlist.addProperty("MatchString", i$runningObj.get(ColumnName).getAsString());
					score = I$Imputils.fuzzyWuzzy(text, i$runningObj.get(ColumnName).getAsString());
				}
				// score = i$sdnScanWorker.fuzzySearch(text, (String)
				// i$runningObj.get(ColumnName).getAsString());
				
				score = score / 100;
				hitlist.addProperty("Score", score);
				hitlist.addProperty("Percent", Math.round(score * 100));
				String scoreS = i$sdnScanWorker.scoreClass(ColumnName, score * 100);
				hitlist.addProperty("ScoreClass", scoreS);
				hitlist.addProperty("ColorCode", i$sdnScanWorker.colorCode(scoreS));
				hitlist.addProperty("ColumnName", ColumnName);
				// hitNameList.add(i$runningObj.get(ColumnName).getAsString());

				if (hitlist.get("Percent").getAsDouble() > fieldScore) {
					if (!I$utils.isInArray(hitNameList, i$runningObj.get("SdnListId").getAsString())) {
						hitNameList.add(i$runningObj.get("SdnListId").getAsString()); // need to check
					}
					hitListResponse.add(hitlist);
				}
			}
			i$res.add("hitNameList", hitNameList);
			i$res.add("hitListResponse", hitListResponse);

		} catch (Exception e) {
			logger.debug("Failed in buildTasks with: " + e.getMessage());
			i$res = null;
		}

		return i$res;
	}

	public JsonObject buildScanResults(JsonObject argJson) {
		int totalmatches = 0;
		int countOfRecords = 0;
		double score = 0;
		String typeOfSearch = "";
		JsonObject ScanCriterias = new JsonObject();
		String ColumnName = "";
		try {
			JsonArray hitListResponse = argJson.getAsJsonArray("hitListResponse");
			String text = argJson.get("text").getAsString();
			ColumnName = argJson.get("ColumnName").getAsString();
			typeOfSearch = argJson.get("typeOfSearch").getAsString();
			if (hitListResponse.size() < 5) {
				countOfRecords = hitListResponse.size();
			} else {
				countOfRecords = 5;
			}
			JsonArray scanDetails5Array = new JsonArray();
			for (int p = 0; p < countOfRecords; p++) {
				JsonObject Top5 = new JsonObject();
				// Top5 = new ScanDetails5Object();
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = hitListResponse.get(p).getAsJsonObject();
				Top5.addProperty("Grade", i$runningObj.get("ScoreClass").getAsString());
				Top5.addProperty("Percent", i$runningObj.get("Percent").getAsString());
				Top5.addProperty("ScanList", i$runningObj.get("ListName").getAsString());
				Top5.addProperty("Score", i$runningObj.get("Score").getAsString());
				Top5.addProperty("ScanString", i$runningObj.get("ScanString").getAsString());
				Top5.addProperty("MatchString", i$runningObj.get("MatchString").getAsString());
				scanDetails5Array.add(Top5);
			}
			double percentRunning = 0;
			for (int i = 0; i < hitListResponse.size(); i++) {
				JsonObject i$runningObj = hitListResponse.get(i).getAsJsonObject();
				percentRunning = percentRunning + i$runningObj.get("Percent").getAsDouble();
			}
			double avgPercentRunning = 0;
			String avgHitList = null;
			// FinalPercent
			for (int i = 0; i < hitListResponse.size(); i++) {
				JsonObject i$runningObj = hitListResponse.get(i).getAsJsonObject();
				avgPercentRunning = i$runningObj.get("Percent").getAsDouble();
				avgHitList = i$runningObj.get("ListName").getAsString(); // ScanCriteriaResultsF HitList
			}
			if (hitListResponse.size() > 0) {
				avgPercentRunning = Math.round(avgPercentRunning); // FinalPercent should be max score
				logger.debug("The Final Percentage :" + avgPercentRunning);
			} else {
				avgPercentRunning = 0;
				logger.debug("The Final Percentage :" + avgPercentRunning);
			}
			// Calculate final Grade based on above
			String FinalGrade = i$sdnScanWorker.scoreClass(ColumnName, avgPercentRunning);
			logger.debug("The FinalGrade is: " + FinalGrade);
			if (totalmatches > 0) {
				score = (score / totalmatches);
				score = Math.round(score * 100.0);
			} else {
				score = 0;
				logger.debug(text.toUpperCase() + " not found in any of the list.");
			}
			logger.debug("Completed Partial Search for:-> " + text.toUpperCase());
			JsonObject ScanResults = new JsonObject();
			// ScanResults.addProperty("ScanType", maxScanType); // #BVB00130
			ScanResults.addProperty("ScanCriteria", ColumnName);
			ScanResults.addProperty("FinalPercent", avgPercentRunning);
			ScanResults.addProperty("FinalGrade", FinalGrade);
			ScanResults.addProperty("HitList", avgHitList);
			ScanResults.add("ScanDetails5", scanDetails5Array);

			ScanCriterias.addProperty("ScanCriteria", ColumnName);
			ScanCriterias.addProperty("Type", typeOfSearch);
			ScanCriterias.add("Tasks", hitListResponse);
			ScanCriterias.add("ScanResults", ScanResults);
		} catch (Exception e) {
			e.printStackTrace();
			ScanCriterias = null;
		}
		return ScanCriterias;
	}

	public JsonObject textSearch(String CollName, String ColumnName, String text, JsonObject argJson)
			throws IOException {

		JsonArray hitNameList = new JsonArray();
		ArrayList<String> matchColList = new ArrayList<String>();

		// double listTypeDetails[] = new double[7];
		double score = 0;
		int totalhit = 0;
		int totalmatches = 0;
		int countOfRecords = 0;
		int index = 0;
		JsonObject ScanCriterias = new JsonObject();

		// writing logic in try loop
		try {

			// Set<String> collections = database.getCollectionNames();
			String searchText;
			// Reading data using readLine for name
			if (text != null) {
				searchText = text;
			} else {
				searchText = "";
			}

			JsonObject fieldMapper = argJson.getAsJsonObject("fieldMapper");

			// looping through all collections

			JsonObject filter = new JsonObject();
			JsonArray i$hit = new JsonArray();
			JsonArray hitListResponse = new JsonArray();
// #BVB00130 Starts 
//			if (ColumnName.equals("FullName") || ColumnName.equals("FName") || ColumnName.equals("LName")
//					|| ColumnName.equals("Address") || ColumnName.equals("Country")) {
//				// fullQuery.put(ColumnName, new BasicDBObject("$regex",
			// searchText).append("$options", "i"));
			String filterS = "";
			filterS = "{'" + ColumnName + "' : {$regex:'" + searchText + "', $options: 'i' }}";
			// filter.addProperty(ColumnName, filterS);
			int hitCount = db$Ctrl.db$GetCountI(CollName, filterS);
			double i$noOfIter = Math.ceil(Double.valueOf(hitCount) / 100);
			for (int k = 0; k < i$noOfIter; k++) {
				// i$hit = db$Ctrl.db$GetRows(CollName, filterS);
				i$hit = db$Ctrl.db$GetSummRowsArray(CollName, filterS, "{}", k, 100 * (k + 1));

//			}
//			// Applying Full Search for below DOB.
//			else if (ColumnName.equals("DOB") || ColumnName.equals("id")) {
//				filter = new JsonObject();
//				filter.addProperty(ColumnName, searchText);
//				i$hit = db$Ctrl.db$GetRows(CollName, filter);
//
//				// fullQuery.put(ColumnName, searchText);
//			}
// #BVB00130 Ends
				// Finding hit list and assigning to the cursor
				// DBCursor cursor = coll.find(fullQuery);
				// checking for count
				/*
				 * if (cursor.count() > 0) { matchColList.add(totalhit, collectionName);
				 * totalhit++; }
				 */
				// looping through cursor
				for (int i = 0; i < i$hit.size(); i++) {
					JsonObject i$runningObj = new JsonObject();
					i$runningObj = i$hit.get(i).getAsJsonObject();
					JsonObject hitlist = new JsonObject();
					// #BVB00109 Starts
					// Getting the score
					double fieldScore = 0;

					try {
						JsonObject colFieldMapper = I$Imputils
								.objFromArrWithSearch(fieldMapper.get(i$runningObj.get("SdnListId").getAsString())
										.getAsJsonObject().getAsJsonArray("Field_Mapper"), "FieldName", ColumnName);
						fieldScore = colFieldMapper.get("FieldScore").getAsDouble();
					} catch (Exception e) {
						fieldScore = 100;
					}
					// #BVB00109 Ends
					// hits hitlist = new hits();
					// hitlist.addProperty("ListName", collectionName);

					// hitlist.setListName(collectionName);
					// hitlist.addProperty("ListName", CollName);
					hitlist.addProperty("ListName", i$runningObj.get("SdnListId").getAsString());
//				if (ColumnName.equals("FullName") || ColumnName.equals("FName") || ColumnName.equals("LName")
//						|| ColumnName.equals("Address") || ColumnName.equals("DOB")) {
//					ListType = 0;
//					hitlist.addProperty("ListType", ListType);
//					// hitlist.setListType(ListType);
//				} else if (ColumnName.equals("Country") || ColumnName.equals("id")) {
//					ListType = 2;
//					hitlist.addProperty("ListType", ListType);
//					// hitlist.setListType(ListType);
//				}
					hitlist.addProperty("ScanString", text);
					// hitlist.setScanString(text);
					// hitlist.addProperty("ScanString", text);
					hitlist.addProperty("MatchString", i$runningObj.get(ColumnName).getAsString());

					// hitlist.setMatchString((String) temp.get(ColumnName));
					score = i$sdnScanWorker.fuzzySearch(searchText,
							(String) i$runningObj.get(ColumnName).getAsString());
					hitlist.addProperty("Score", score);
					// hitlist.setScore(score);
					hitlist.addProperty("Percent", Math.round(score * 100));
					// hitlist.setPercent(Math.round(score * 100));
					String scoreS = i$sdnScanWorker.scoreClass(ColumnName, score * 100);
					hitlist.addProperty("ScoreClass", scoreS);
					// hitlist.setScoreClass(scoreClass(ColumnName, score * 100));
					hitlist.addProperty("ColorCode", i$sdnScanWorker.colorCode(scoreS));
					// hitlist.setColorCode(colorCode(hitlist.getScoreClass()));

					hitNameList.add(i$runningObj.get(ColumnName).getAsString());
					if (hitlist.get("Percent").getAsDouble() > fieldScore) {
						hitListResponse.add(hitlist);
					}
				}
			}
			if (hitListResponse.size() != 0) {
				double runningPercent = 0,
						maxPercent = hitListResponse.get(0).getAsJsonObject().get("Percent").getAsDouble();
				int maxPercentIndex = 0;
				JsonObject tempHit = new JsonObject();
				for (int i = 0; i < hitListResponse.size(); i++) {

					JsonObject i$runningObj = new JsonObject();
					i$runningObj = hitListResponse.get(i).getAsJsonObject();
					index = i;
					runningPercent = i$runningObj.get("Percent").getAsDouble();
					maxPercent = i$runningObj.get("Percent").getAsDouble();
					maxPercentIndex = i;
					for (int j = i + 1; j < hitListResponse.size(); j++) {
						JsonObject i$runningObjJ = new JsonObject();
						i$runningObjJ = hitListResponse.get(j).getAsJsonObject();

						if (i$runningObjJ.get("Percent").getAsDouble() > runningPercent
								&& i$runningObjJ.get("Percent").getAsDouble() > maxPercent) {
							maxPercent = i$runningObjJ.get("Percent").getAsDouble();
							maxPercentIndex = j;
						}
					}
					tempHit = i$runningObj;
					hitListResponse.set(i, hitListResponse.get(maxPercentIndex));
					hitListResponse.set(maxPercentIndex, tempHit);
					// hitListResponse.add(i, hitListResponse.get(maxPercentIndex));
					// Hits.set(maxPercentIndex, tempHit);
				}
			}

			if (hitListResponse.size() < 5) {
				countOfRecords = hitListResponse.size();
			} else {
				countOfRecords = 5;
			}
			JsonArray scanDetails5Array = new JsonArray();
			for (int p = 0; p < countOfRecords; p++) {
				JsonObject Top5 = new JsonObject();
				// Top5 = new ScanDetails5Object();
				JsonObject i$runningObj = new JsonObject();
				i$runningObj = hitListResponse.get(p).getAsJsonObject();
				Top5.addProperty("Grade", i$runningObj.get("ScoreClass").getAsString());
				Top5.addProperty("Percent", i$runningObj.get("Percent").getAsString());
				Top5.addProperty("ScanList", i$runningObj.get("ListName").getAsString());
				Top5.addProperty("Score", i$runningObj.get("Score").getAsString());
				Top5.addProperty("ScanString", i$runningObj.get("ScanString").getAsString());
				Top5.addProperty("MatchString", i$runningObj.get("MatchString").getAsString());
				scanDetails5Array.add(Top5);
			}
			// #BVB00130 Starts
//			for (int i = 0; i < listTypeDetails.length; i++) {
//				listTypeDetails[i] = 0;
//			}
			// #BVB00130 Ends
			// Getting the scores
			double percentRunning = 0;
			for (int i = 0; i < hitListResponse.size(); i++) {
				JsonObject i$runningObj = hitListResponse.get(i).getAsJsonObject();
				index = 0;
				// index = i$runningObj.get("ListType").getAsInt();
				// listTypeDetails[index] += i$runningObj.get("Score").getAsDouble();

				percentRunning = percentRunning + i$runningObj.get("Percent").getAsDouble();

				// index++;
			}
			// Finding the average total percentage
			double avgPercentRunning = 0;
			String avgHitList = null;
			// FinalPercent
			for (int i = 0; i < hitListResponse.size(); i++) {
				JsonObject i$runningObj = hitListResponse.get(i).getAsJsonObject();
				avgPercentRunning = i$runningObj.get("Percent").getAsDouble();
				avgHitList = i$runningObj.get("ListName").getAsString(); // ScanCriteriaResultsF HitList
			}
			if (hitListResponse.size() > 0) {
				// avgPercentRunning = Math.round(percentRunning/Hits.size());
				avgPercentRunning = Math.round(avgPercentRunning); // FinalPercent should be max score
				logger.debug("The Final Percentage :" + avgPercentRunning);
			} else {
				avgPercentRunning = 0;
				logger.debug("The Final Percentage :" + avgPercentRunning);
			}
			// Calculate final Grade based on above
			String FinalGrade = i$sdnScanWorker.scoreClass(ColumnName, avgPercentRunning);
			logger.debug("The FinalGrade is: " + FinalGrade);
			for (int i = 0; i < matchColList.size(); i++) {
				logger.debug("Match found in list:-> " + matchColList.get(i).toUpperCase());
			}
			// logger.debug(">>>>>>> " + maxHitList);
			// Finding the max Score Type
			// #BVB00130 Starts
			// double runningScore = 0, maxScore = 0;
			// int maxScanType = 0;
//			for (int i = 0; i < listTypeDetails.length; i++) {
//				runningScore = listTypeDetails[i];
//				if (runningScore > maxScore) {
//					maxScore = runningScore / hitListResponse.size(); // FinalScore
//					maxScanType = i; // ScanType
//					logger.debug("The Max Score :" + maxScore);
//					logger.debug("The Scan Type :" + maxScanType);
//				}
//			}
			// #BVB00130 Ends
			if (totalmatches > 0) {
				logger.debug(searchText.toUpperCase() + " is available in:-> " + (totalhit)
						+ " no of files. Total number of times it has been hit is:-> " + totalmatches);
				score = (score / totalmatches);
				score = Math.round(score * 100.0);
			} else {
				score = 0;
				logger.debug(searchText.toUpperCase() + " not found in any of the list.");
			}
			logger.debug("Completed Partial Search for:-> " + searchText.toUpperCase());
			// Creating the output format
			// ScanCriteriaResultsF object data
			JsonObject ScanResults = new JsonObject();
			// ScanResults.addProperty("ScanType", maxScanType); // #BVB00130
			ScanResults.addProperty("ScanCriteria", ColumnName);
			ScanResults.addProperty("FinalPercent", avgPercentRunning);
			ScanResults.addProperty("FinalGrade", FinalGrade);
			ScanResults.addProperty("HitList", avgHitList);
			ScanResults.add("ScanDetails5", scanDetails5Array);

			// ScanResults.setScanType(maxScanType);
			// ScanResults.setScanCriteria(ColumnName);
			// ScanResults.setFinalPercent(avgPercentRunning);
			// ScanResults.setFinalGrade(FinalGrade);
			// ScanResults.setHitList(avgHitList);
			// ScanResults.setScanDetails5(scanDetails5Array);

			// ScanCriterias object data
			ScanCriterias.addProperty("ScanCriteria", ColumnName);
			ScanCriterias.add("Tasks", hitListResponse);
			ScanCriterias.add("ScanResults", ScanResults);

			// ScanCriterias.setScanCriteria(ColumnName);
			// ScanCriterias.setTasks(Hits);
			// ScanCriterias.setScanResults(ScanResults);

		} catch (Exception e) {
			e.printStackTrace();
			ScanCriterias = null;
		}
		// returning Scan Criteria object
		return ScanCriterias;
	}

	// #BVB00056 Starts
	public JsonObject sdnQuery(JsonObject isonMsg) {
		JsonObject icorMSdn = new JsonObject();
		JsonObject filter = new JsonObject();
		try {

			String ScanId = i$ResM.getBodyElementS(isonMsg, "ScanId");
			filter.addProperty("ScanId", ScanId);

			icorMSdn = db$Ctrl.db$GetRow("ICOR_M_SDN_SCAN", filter);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorMSdn);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
		} catch (Exception e) {
			// TODO: handle exception
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
		}

		return isonMsg;

	}

	// #BVB00056 Ends
	// #BVB00077 Starts
	public JsonArray pdfScan(JsonObject argJson) {
		JsonArray i$scanResA = new JsonArray();
//		JsonObject i$pdfScan = new JsonObject();
		try {
			String ScanCriteria = argJson.get("ScanCriteria").getAsString();
			// String ScanCriteria = "FULLNAME";
			// String sdnLstId = "TTHC_SDN_0001"; // Sdn_lst_id
			String searchValue = argJson.get("searchVal").getAsString().toUpperCase();   //#PKY00003
			JsonArray Tasks = new JsonArray();
//			JsonObject scanResults = new JsonObject();
			// JsonObject filter = new JsonObject();
			// filter.addProperty("id", "{'content':{$exists: true}}");
			// #MAQ10102 starts
			String filterS = "{'content': {'$regex': '" + searchValue + "','$options': 'i' } }";
			// JsonObject highCountOrder = db$Ctrl.db$GetRow("ICOR_M_SDN_DETAIL", filterS);
			JsonObject projection = new JsonObject();
			projection.addProperty("SdnListId", 1);  //PKY00064 changes
			projection.addProperty("_id", 0);   //PKY00064 changes
			JsonArray pdfOrder = db$Ctrl.db$GetRows("ICOR_M_SDN_DETAIL", filterS,projection);
			// JsonObject searchHits = new JsonObject();
			for (int i = 0; i < pdfOrder.size(); i++) {
				//#PKY00003 starts
				JsonObject i$pdfScan = new JsonObject();
				JsonObject scanResults = new JsonObject();
				//#PKY00003 ends
				try {
//					JsonObject i$runningObj = pdfOrder.get(i).getAsJsonObject();
//					logger.debug("PDF Scan with SDNLIST ID: " + i$runningObj.get("SdnListId").getAsString());
//					JsonObject sdnDet = db$Ctrl.db$GetRow("ICOR_M_SDN_DETAIL", "{'SdnListId':'"+i$runningObj.get("SdnListId").getAsString()+"'}");
//					JsonObject searchHits = I$Imputils.fuzzyWuzzy(searchValue, sdnDet.get("content").getAsString(),
//							0.5);// add to
//					JsonArray tasksUpdated = new JsonArray();
//					double totalScore = 0.0;
//					double avgScore = 0.0;
//					Tasks = searchHits.get("hits").getAsJsonArray();
//					for (int j = 0; j < Tasks.size(); j++) {
//						JsonObject i$runningTask = Tasks.get(j).getAsJsonObject();
//						i$runningTask.addProperty("ListName", i$runningObj.get("SdnListId").getAsString());
//						i$runningTask.addProperty("ListType", "0");
//						double Percent = i$runningTask.get("Percent").getAsDouble();
//						String scoreS = i$sdnScanWorker.scoreClass(ScanCriteria, Percent);
//						i$runningTask.addProperty("ScoreClass", scoreS);
//						// hitlist.setScoreClass(scoreClass(ColumnName, score * 100));
//						i$runningTask.addProperty("ColorCode", i$sdnScanWorker.colorCode(scoreS));
//	
//						tasksUpdated.add(i$runningTask);
//						totalScore = totalScore + Percent;
//	
//					}
//					// Need to Build Scan Results Object
//					// ScanResults.addProperty("ScanType", 0);
//					// ScanResults.addProperty("ScanCriteria", ScanCriteria);
//	
//					// Building ScanResults now
//					scanResults.addProperty("ScanType", "0");
//					scanResults.addProperty("ScanCriteria", ScanCriteria);
//					if(tasksUpdated.size() > 0) {
//					avgScore = totalScore / tasksUpdated.size();
//					}else {
//						avgScore = 0; 
//					}
//					scanResults.addProperty("FinalPercent", avgScore);
//					scanResults.addProperty("FinalGrade", i$sdnScanWorker.scoreClass(ScanCriteria, avgScore));
//					scanResults.addProperty("HitList", i$runningObj.get("SdnListId").getAsString());
//	
//					JsonArray ScanDetails5 = new JsonArray();
//	
//					JsonArray sortedArray = I$Imputils.sortJsonArray("Percent", tasksUpdated);
//	
//					ScanDetails5 = I$Imputils.getObjectOfArray(0, 5, sortedArray);
//	
//					scanResults.add("ScanDetails5", ScanDetails5);
//					i$pdfScan.addProperty("ScanCriteria", ScanCriteria);
//					i$pdfScan.add("Tasks", tasksUpdated);
//					i$pdfScan.add("ScanResults", scanResults);
					
					JsonObject i$runningObj = pdfOrder.get(i).getAsJsonObject();
					logger.debug("PDF Scan with SDNLIST ID: " + i$runningObj.get("SdnListId").getAsString());
					JsonObject sdnDet = db$Ctrl.db$GetRow("ICOR_M_SDN_DETAIL", "{'SdnListId':'"+i$runningObj.get("SdnListId").getAsString()+"'}");
					//JsonObject searchHits = I$Imputils.fuzzyWuzzy(searchValue, sdnDet.get("content").getAsString(),0.5);
					JsonArray tasksUpdated = new JsonArray();
					double totalScore = 0.0;
					double avgScore = 0.0;
					JsonObject i$runningTask =new JsonObject();
					double score = 0.4;
					if (I$utils.$iStrFuzzyMatch(ScanCriteria, "FullName")) {
						score = 1;
					}
				    i$runningTask.addProperty("Score", score);    
				    i$runningTask.addProperty("Percent", Math.round(score * 100));
					String scoreS = i$sdnScanWorker.scoreClass(ScanCriteria, score * 100);
				    i$runningTask.addProperty("ScanString", searchValue);
				    i$runningTask.addProperty("Grade", scoreS);
				  //#PKY00003 starts	//#MVT00029 Changes starts
				    String contentStr = sdnDet.get("content").getAsString();
				    String searchStr = argJson.get("searchVal").getAsString();
					try {
						String[] contArr = contentStr.split(searchStr);
						String content = contArr[1];
						content = content.substring(0, 60);
						i$runningTask.addProperty("reason", searchValue + " " + content);
					} catch (Exception e) {
						String[] contArr = contentStr.split(searchStr);
						String firstContent = contArr[0];
						int index = firstContent.length();
						String content = firstContent.substring(index - 61, index);
						for (int j = 0; j < content.length(); j++) {
							if (content.charAt(j) == (' ')) {
								content = content.substring(j + 1);
								break;
							}
						}
						i$runningTask.addProperty("reason", content + " " + searchValue);
					}//#MVT00029 Changes ends
				  //#PKY00003 ends
				    i$runningTask.addProperty("MatchString", i$runningTask.get("reason").getAsString());
					i$runningTask.addProperty("ListName", i$runningObj.get("SdnListId").getAsString());
					i$runningTask.addProperty("ListType", "0");					
					i$runningTask.addProperty("ScanList", i$runningObj.get("SdnListId").getAsString());
					i$runningTask.addProperty("ScoreClass", scoreS);
					i$runningTask.addProperty("ColorCode", i$sdnScanWorker.colorCode(scoreS));

					tasksUpdated.add(i$runningTask);
					
					scanResults.addProperty("ScanType", "0");
					scanResults.addProperty("ScanCriteria", ScanCriteria);
					scanResults.addProperty("FinalPercent", score);
					scanResults.addProperty("FinalGrade", i$sdnScanWorker.scoreClass(ScanCriteria, score));
					scanResults.addProperty("HitList", i$runningObj.get("SdnListId").getAsString());
	
					JsonArray ScanDetails5 = new JsonArray();
	
					JsonArray sortedArray = I$Imputils.sortJsonArray("Percent", tasksUpdated);
	
					ScanDetails5 = I$Imputils.getObjectOfArray(0, 5, sortedArray);
	
					scanResults.add("ScanDetails5", ScanDetails5);
					i$pdfScan.addProperty("ScanCriteria", ScanCriteria);
					i$pdfScan.add("Tasks", tasksUpdated);
					i$pdfScan.add("ScanResults", scanResults);
				//#PKY00003 starts
				} catch (Exception e) {
					e.printStackTrace();
				}
				i$scanResA.add(i$pdfScan);  
				//#PKY00003 ends
				
				// #MAQ10102 ends
				
			}

			//i$scanResA.add(i$pdfScan);
//			i$highCourtScan.addProperty("FinalPercent", 100.0);
//			int hitCount = Tasks.size();
//			String FinalGrade = "";
//			if (hitCount > 5) {
//				FinalGrade = "HIGH";
//			} else if (hitCount > 1 && hitCount <= 5) {
//				FinalGrade = "MEDIUM";
//			}
//			i$highCourtScan.addProperty("FinalGrade", FinalGrade);
//			i$highCourtScan.addProperty("HitList", ""); // ICOR_M_SDN_DETAIL
//			i$highCourtScan.add("ScanDetails5", Tasks); 
		} catch (Exception e) {
			e.printStackTrace();
			i$scanResA = null;
		}

		return i$scanResA;
	}
//#PKY00064 starts
	public JsonArray diliSdnScan(JsonObject argJson) {
	    JsonArray i$scanResA = new JsonArray();
	    try {
	        String value = argJson.get("searchVal").getAsString();
	        String key = argJson.get("ScanCriteria").getAsString();
	        if (key.equalsIgnoreCase("FullName")) {
	            key = "name";
	        } else if (key.equalsIgnoreCase("FName")) {
	            key = "givenNames";
	        } else if (key.equalsIgnoreCase("LName")) {
	            key = "lastNames";
	        }
	        String filter = "{" + key + ": {'$regex': '" + value + "','$options': 'i' } }";
	        JsonObject Json$DbDetails = db$Ctrl.db$GetRows("ICOR_M_SDN_DETAILS_JSON", filter, 0, 3);
	        JsonArray icorJsonDetails = Json$DbDetails.get("i-body").getAsJsonArray();
	        for (int i = 0; i < icorJsonDetails.size(); i++) {
	            try {
	                JsonObject i$jsonScan = new JsonObject();
	                JsonObject scanResults = new JsonObject();
	                JsonObject json$DbData = icorJsonDetails.get(i).getAsJsonObject();
	                String jsonValue = json$DbData.get(key).getAsString().toUpperCase();
	                if (jsonValue.contains(value)) {
	                    JsonArray tasksUpdated = new JsonArray();
	                    String ScanCriteria = argJson.get("ScanCriteria").getAsString();
	                    double totalScore = 0.0;
	                    double avgScore = 0.0;
	                    JsonObject i$runningTask = new JsonObject();
	                    double score = 0.4;
	                    if (I$utils.$iStrFuzzyMatch(ScanCriteria, "FullName")) {
	                        score = 1;
	                    }
	                    i$runningTask.addProperty("Score", score);
	                    i$runningTask.addProperty("Percent", Math.round(score * 100));
	                    String scoreS = i$sdnScanWorker.scoreClass(ScanCriteria, score * 100);
	                    i$runningTask.addProperty("ScanString", value);
	                    i$runningTask.addProperty("Grade", scoreS);
	                    String contentStr = json$DbData.get("sourceId").getAsString().toUpperCase();
	                    contentStr = contentStr.replace("_", " ");
	                    i$runningTask.addProperty("reason", value + " " + contentStr);
	                    i$runningTask.addProperty("MatchString", i$runningTask.get("reason").getAsString());
	                    i$runningTask.addProperty("ListName", contentStr);
	                    i$runningTask.addProperty("ListType", "0");
	                    i$runningTask.addProperty("ScanList", contentStr);
	                    i$runningTask.addProperty("ScoreClass", scoreS);
	                    i$runningTask.addProperty("ColorCode", i$sdnScanWorker.colorCode(scoreS));
	                    tasksUpdated.add(i$runningTask);
	                    scanResults.addProperty("ScanType", "0");
	                    scanResults.addProperty("ScanCriteria", ScanCriteria);
	                    scanResults.addProperty("FinalPercent", score);
	                    scanResults.addProperty("FinalGrade", i$sdnScanWorker.scoreClass(ScanCriteria, score));
	                    scanResults.addProperty("HitList", contentStr);
	                    JsonArray ScanDetails5 = new JsonArray();
	                    JsonArray sortedArray = I$Imputils.sortJsonArray("Percent", tasksUpdated);
	                    ScanDetails5 = I$Imputils.getObjectOfArray(0, 5, sortedArray);
	                    scanResults.add("ScanDetails5", ScanDetails5);
	                    i$jsonScan.addProperty("ScanCriteria", ScanCriteria);
	                    i$jsonScan.add("Tasks", tasksUpdated);
	                    i$jsonScan.add("ScanResults", scanResults);
	                    
	                }
	                i$scanResA.add(i$jsonScan);
	            } catch (Exception e) {

	            }
	        }
	    } catch (Exception e) {

	    }
	    return i$scanResA;
	}
//#PKY00064 ends
	public static JsonObject searchHits(String search, String searchIn) {

		int lastIndex = 0;
		JsonObject i$res = new JsonObject();
		JsonArray Tasks = new JsonArray();
		try {

			while (lastIndex != -1) {

				lastIndex = searchIn.indexOf(search, lastIndex);

				if (lastIndex != -1) {
					lastIndex += search.length();
					int finishIndex = searchIn.indexOf(";", lastIndex + 1);
					String reason = searchIn.substring(lastIndex, finishIndex);
					Tasks.add(reason);

				}
			}
			i$res.add("Tasks", Tasks);
			logger.debug("Tasks: " + Tasks);
			// logger.debug("count: " + count);
		} catch (Exception e) {
			e.printStackTrace();
			i$res = null;
		}

		return i$res;
	}
//MSA00062 Starts
	public JsonObject sdnCheck(JsonObject argJson) {
		try {
			JsonObject refNo = new JsonObject();
			JsonObject request = new JsonObject();
			String trnCd = argJson.get("i-body").getAsJsonObject().get("trnCd").getAsString();
			JsonObject trnData = argJson.get("i-body").getAsJsonObject().get("trnData").getAsJsonObject();
			String acc = null;
			String amount = null;
			Date date = new Date();
			SimpleDateFormat DateFor = new SimpleDateFormat("ddMMyyyy");
			SimpleDateFormat DateFor_1 = new SimpleDateFormat("YYYY-MM-dd HH:MM:SS");
			String stringDate = DateFor.format(date);
			String stringDate_1 = DateFor_1.format(date);
			String randomno = I$Imputils.randomAlphaNumeric(6);
			String i$randomno = I$Imputils.randomAlphaNumeric(4);
			String cif = null;
			String fromAcc = null;
			String toAcc = null;
			
			if(I$utils.$iStrFuzzyMatch(trnCd, "IFT")) {
				acc = trnData.get("debitAccNo").getAsString();
				cif = acc.substring(3, 9);
				amount = trnData.get("lcyAmount").getAsString();
				fromAcc = trnData.get("debitAccNo").getAsString();
				toAcc = trnData.get("creditAccNo").getAsString();
				request.addProperty("referenceNo", "TF" + trnCd + cif + stringDate + randomno);
				refNo.addProperty("referenceNo", "TF" + trnCd + cif + stringDate + randomno);
			}else if(I$utils.$iStrFuzzyMatch(trnCd, "ACH")) {
				acc = trnData.get("txnAcc").getAsString();
				cif = acc.substring(3, 9);
				amount = trnData.get("txnAmt").getAsString();
				fromAcc = trnData.get("txnAcc").getAsString();
				toAcc = trnData.get("achBeneficiaryAcc").getAsString();
				request.addProperty("referenceNo", "TF" + trnCd + cif + stringDate + randomno);
				refNo.addProperty("referenceNo", "TF" + trnCd + cif + stringDate + randomno);
			}else if(I$utils.$iStrFuzzyMatch(trnCd, "LINCU")) {
				acc = trnData.get("acc").getAsString();
				cif = acc.substring(3, 9);
				amount = trnData.get("txnAmt").getAsString();
				fromAcc = trnData.get("acc").getAsString();
				toAcc = trnData.get("lincuCardNo").getAsString(); 
				request.addProperty("referenceNo", "TF" + trnCd + cif + stringDate + i$randomno);
				refNo.addProperty("referenceNo", "TF" + trnCd + cif + stringDate + i$randomno);
			}
			request.addProperty("key", cif);
			request.addProperty("amount",amount);
			request.addProperty("trnCd",trnCd);
			request.addProperty("recipientName",trnData.get("recipientName").getAsString());
			request.addProperty("typeOfTransfer",argJson.get("i-body").getAsJsonObject().get("transferType").getAsString());
			request.addProperty("fromAccNo",fromAcc);
			request.addProperty("toAccNo",toAcc);
			request.addProperty("status","PENDING");
			request.addProperty("sdnCheck","Y");
			request.addProperty("initiatedAt", stringDate_1);
			request.addProperty("remarks", "Please note that the transaction has been initiated and will be reviewed by the Credit Union. Once approved, the transaction will be processed on the core banking system");
			request.add("transferDetails", argJson.get("i-body").getAsJsonObject());
			request.add("transferheaderDetails", argJson.get("i-header").getAsJsonObject());
			db$Ctrl.db$InsertRow("ICOR_M_DIGI_SDN_CHECK", request);
			argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, refNo);
			i$ResM.setGobalVals("refrenceNoData", argJson);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return argJson;
	}//MSA00062 Ends
	//MSA00063 Starts
	public JsonObject sdnCheckOpr(JsonObject argJson) {
		try {
			String SOpr = i$ResM.getOpr(argJson);
			String refNo = argJson.get("i-body").getAsJsonObject().get("referenceNo").getAsString();
			String remarks = argJson.get("i-body").getAsJsonObject().get("remarks").getAsString();
			JsonObject filter = new JsonObject();
			JsonObject updateRemark = new JsonObject();
			filter.addProperty("referenceNo", refNo);
			JsonObject respData = new JsonObject();
			String msgText = null;
			
			JsonObject sdnCheckData = db$Ctrl.db$GetRow("ICOR_M_DIGI_SDN_CHECK", filter);
			JsonObject ibodyCopy = sdnCheckData.get("transferDetails").getAsJsonObject();
			JsonObject iHeaderCopy = sdnCheckData.get("transferheaderDetails").getAsJsonObject();
			
			if (I$utils.$iStrFuzzyMatch(SOpr, "ACCEPT")) {
				try {
					argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, ibodyCopy);
					argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_HEADER, iHeaderCopy);
					JsonObject successSdn = i$CoreSys.coreReqFwd(argJson);
					if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(successSdn),"i-SUCC")) {
						updateRemark.addProperty("remarks", remarks);
						updateRemark.addProperty("status", "ACCEPTED");
						updateRemark.add("acceptedAt", i$ResM.adddate(new Date()).getAsJsonObject());
						updateRemark.addProperty("processedBy", IResManipulator.iloggedUser.get());
						db$Ctrl.db$UpdateRow("ICOR_M_DIGI_SDN_CHECK", updateRemark, filter);
						
						JsonObject finalData = db$Ctrl.db$GetRow("ICOR_M_DIGI_SDN_CHECK", filter);
						
						respData.addProperty("referenceNo", finalData.get("referenceNo").getAsString() );
						respData.addProperty("amount", finalData.get("amount").getAsString());
						respData.addProperty("fromAccNo",finalData.get("fromAccNo").getAsString() );
						respData.addProperty("toAccNo", finalData.get("toAccNo").getAsString());
						respData.addProperty("status", finalData.get("status").getAsString());
						respData.addProperty("remarks",finalData.get("remarks").getAsString() );
						respData.addProperty("typeOfTransfer", finalData.get("typeOfTransfer").getAsString());
						respData.addProperty("acceptedAt", finalData.get("acceptedAt").getAsString());
						respData.addProperty("processedBy", finalData.get("processedBy").getAsString());
						
						argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, respData);
						msgText = successSdn.get("i-stat").getAsJsonObject().get("i-success").getAsJsonObject().get("msgtext").getAsString();
						argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_SUCC, msgText);
					}else {
						msgText = successSdn.get("i-stat").getAsJsonObject().get("i-error").getAsJsonObject().get("msgtext").getAsString();
						argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_ERR, msgText);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (I$utils.$iStrFuzzyMatch(SOpr, "REJECT")) {
				try {
					updateRemark.addProperty("remarks", remarks);
					updateRemark.addProperty("status", "REJECTED");
					updateRemark.add("rejectedAt", i$ResM.adddate(new Date()).getAsJsonObject());
					updateRemark.addProperty("processedBy", IResManipulator.iloggedUser.get());
					db$Ctrl.db$UpdateRow("ICOR_M_DIGI_SDN_CHECK", updateRemark, filter);
					
					JsonObject finalData = db$Ctrl.db$GetRow("ICOR_M_DIGI_SDN_CHECK", filter);

					respData.addProperty("referenceNo", finalData.get("referenceNo").getAsString() );
					respData.addProperty("amount", finalData.get("amount").getAsString());
					respData.addProperty("fromAccNo",finalData.get("fromAccNo").getAsString() );
					respData.addProperty("toAccNo", finalData.get("toAccNo").getAsString());
					respData.addProperty("status", finalData.get("status").getAsString());
					respData.addProperty("remarks",finalData.get("remarks").getAsString() );
					respData.addProperty("typeOfTransfer", finalData.get("typeOfTransfer").getAsString());
					respData.addProperty("rejectedAt", finalData.get("rejectedAt").getAsString());
					respData.addProperty("processedBy", finalData.get("processedBy").getAsString());
					
					argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, respData);
					argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_SUCC, "Transaction Rejected Successfully");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return argJson;
	}//MSA00063 Ends
	//MSA00064 Starts
//	public JsonObject sdnCheckRemarkCheck(JsonObject argJson) {
//		try {
//			String refNo = argJson.get("i-body").getAsJsonObject().get("referenceNo").getAsString();
//			JsonObject filter = new JsonObject();
//			JsonObject finalRemarks = new JsonObject();
//			filter.addProperty("referenceNo", refNo);
//			JsonObject trnFwrData = db$Ctrl.db$GetRow("ICOR_M_DIGI_SDN_CHECK", filter);
//			String status = trnFwrData.get("status").getAsString();
//
//			if (!I$utils.$isNull(trnFwrData)) {
//				if (I$utils.$iStrFuzzyMatch(status, "REJECTED")) {
//					finalRemarks.addProperty("remarks", trnFwrData.get("rejectedRemarks").getAsString());
//					finalRemarks.addProperty("typeOfTransfer", trnFwrData.get("typeOfTransfer").getAsString());
//					finalRemarks.addProperty("fromAccNo", trnFwrData.get("fromAccNo").getAsString());
//					finalRemarks.addProperty("toAccNo", trnFwrData.get("toAccNo").getAsString());
//					finalRemarks.addProperty("status", trnFwrData.get("status").getAsString());
//					finalRemarks.addProperty("referenceNo", trnFwrData.get("referenceNo").getAsString());
//					finalRemarks.addProperty("recipientName", trnFwrData.get("recipientName").getAsString());
//					finalRemarks.addProperty("amount", trnFwrData.get("amount").getAsString());
//				} else if (I$utils.$iStrFuzzyMatch(status, "ACCEPTED")) {
//					finalRemarks.addProperty("remarks", trnFwrData.get("acceptedRemarks").getAsString());
//					finalRemarks.addProperty("typeOfTransfer", trnFwrData.get("typeOfTransfer").getAsString());
//					finalRemarks.addProperty("fromAccNo", trnFwrData.get("fromAccNo").getAsString());
//					finalRemarks.addProperty("toAccNo", trnFwrData.get("toAccNo").getAsString());
//					finalRemarks.addProperty("status", trnFwrData.get("status").getAsString());
//					finalRemarks.addProperty("referenceNo", trnFwrData.get("referenceNo").getAsString());
//					finalRemarks.addProperty("recipientName", trnFwrData.get("recipientName").getAsString());
//					finalRemarks.addProperty("amount", trnFwrData.get("amount").getAsString());
//				} else {
//					finalRemarks.addProperty("remarks", trnFwrData.get("remarks").getAsString());
//					finalRemarks.addProperty("typeOfTransfer", trnFwrData.get("typeOfTransfer").getAsString());
//					finalRemarks.addProperty("fromAccNo", trnFwrData.get("fromAccNo").getAsString());
//					finalRemarks.addProperty("toAccNo", trnFwrData.get("toAccNo").getAsString());
//					finalRemarks.addProperty("status", trnFwrData.get("status").getAsString());
//					finalRemarks.addProperty("referenceNo", trnFwrData.get("referenceNo").getAsString());
//					finalRemarks.addProperty("recipientName", trnFwrData.get("recipientName").getAsString());
//					finalRemarks.addProperty("amount", trnFwrData.get("amount").getAsString());
//				}
//				argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, finalRemarks);
//			} else {
//				argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_ERR, "NO RECORDS FOUND");
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return argJson;
//	}//MSA00064 Ends  
	public JsonObject sdnSummary(JsonObject argJson) {
		try {
			String key = i$ResM.getBodyElementS(argJson, "key");
			JsonObject filter = new JsonObject();
			JsonObject finalSdnData = new JsonObject();
			filter.addProperty("key", key);
			JsonObject sort = new JsonObject();
			sort.addProperty("_id", -1);
			JsonObject proj = new JsonObject();
			proj.addProperty("transferDetails", 0);
			proj.addProperty("transferheaderDetails", 0);
			proj.addProperty("key", 0);
			proj.addProperty("_id", 0);
			proj.addProperty("trnCd", 0);
			proj.addProperty("sdnCheck", 0);
			String filt = "{\"key\":\""+key+"\",\"status\":{\"$in\":[\"PENDING\",\"REJECTED\"]}}";
			
			JsonArray sdnCheckData  = db$Ctrl.db$GetRows$Sort("ICOR_M_DIGI_SDN_CHECK", filt, proj.toString(), sort.toString());
//			if (sdnCheckData.size() > 0) {
				finalSdnData.add("iRowData", sdnCheckData);
				argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, finalSdnData);
//			}else {
//				argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_SUCC,sdnCheckData );
//			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return argJson;
	}
	// #BVB00077 Ends
	public SdnScanController() {
		// Cons
	}
}