/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Mar 06, 2019 | #BVB00088   | Initial writing
      |0.3.13      | Vijay 		| Jun 06, 2019 | #BVB00162   | Settlement instructions maintenances Implementation
      |0.3.9       | Vijay 		| May 27, 2019 | #BVB00172   | Demo Mode Handling for Transactions ** Might have to remove during release
      |0.3.9       | Syed 		| Sep 01, 2021 | #MAQ00144   | Removed access check of AMB
      |0.3.9       | Tarun 		| Sep 20, 2021 | #TKS00003   | added code for lincu and ACH flexcube call.  
      ----------------------------------------------------------------------------------------------
*/
// #BVB00050 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.ICbsSettleInstr;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICorePrePostController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(ICorePrePostController.class);
	private ICbsSettleInstr I$CbsSettleInstr = new ICbsSettleInstr();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			JsonObject i$body = new JsonObject();

			if ( I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = CoreReqFwd(isonMsg);
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Success in PrePostFlight");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject processRes(JsonObject argJson, JsonObject isonheader, JsonObject isonMapJson) {
		// #BVB00172 Starts
		JsonParser parser = new JsonParser();
		JsonObject projection = new JsonObject();
		JsonObject filter = new JsonObject();
		String mode = "PROD";
		JsonObject isonMsg = new JsonObject();
		try {
			isonMsg = argJson.getAsJsonObject("isonMsg");
			String trnCd = i$ResM.getBodyElementS(isonMsg, "trnCd");
			projection.addProperty("mode", "1");
			try {
				// mode = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter, projection).get("mode").getAsString();
				mode = i$ResM.getGobalValStr("mode"); 
			} catch (Exception e) {
				mode = "PROD";
			}
			if (I$utils.$iStrFuzzyMatch(mode, "DEMO")) {
				String res = "";
				if (I$utils.$iStrFuzzyMatch(trnCd, "CD")) {
					res = "{'i-config': {'sitekey': '3453d693-b0ce-4c6c-a2d7-882adadf7112', 'browser': '', 'clientApp': 'ImpactoWeb', 'imecd': '', 'os': '', 'brwversion': '', 'osversion': '', 'iclntversion': '', 'sessionID': '20190306153118706a3b4e1c0-416d-4e9a-8741-425239cc5cbf', 'SrcID': 'ImpactoWeb', 'srcApiKey': '895cb63e80d98fef398443255ccc0b6e'}, 'i-header': {'msg-id': '"+ i$ResM.getMsgID(isonMsg)+ "', 'key-hash': '', 'screenid': 'XEXCBRFD', 'srvcname': '', 'srvcopr': '', 'srvcopr1': '', 'srvcopr2': '', 'srvcopr3': '', 'operation': 'CREATE', 'operation1': '@', 'operation2': '@', 'operation3': '@'}, 'i-body': {'batchNo': '5725', 'REFERENCE_NO': '1005725180610001', 'cbsMsg': {'cbsMsg1': '\\nST-SAVE-052\\nSuccessfully Saved and Authorized\\n'} }, 'i-stat': {'i-statMsg': 'i-SUCC', 'i-success': [{'msgcode': 'iS#WS00001', 'msgtext': 'TRANSACTION COMPLETED SUCCESSFULLY ', 'conReq': 'N'} ], 'i-warn': [{'msgcode': '', 'msgtext': ''} ], 'i-error': [{'msgcode': '', 'msgtext': ''} ] } }";
					isonMsg = parser.parse(res).getAsJsonObject();
				} else if (I$utils.$iStrFuzzyMatch(trnCd, "CW")) {
					res = "{'i-config': {'sitekey': '3453d693-b0ce-4c6c-a2d7-882adadf7112', 'browser': '', 'clientApp': 'ImpactoWeb', 'imecd': '', 'os': '', 'brwversion': '', 'osversion': '', 'iclntversion': '', 'sessionID': '20190624150420874d5a599e9-ad5d-4ad7-b1e9-017cc8fb320a', 'SrcID': 'ImpactoWeb', 'srcApiKey': '895cb63e80d98fef398443255ccc0b6e'}, 'i-header': {'msg-id': '"+ i$ResM.getMsgID(isonMsg)+ "', 'key-hash': '', 'screenid': 'XEXCBRFD', 'srvcname': '', 'srvcopr': '', 'srvcopr1': '', 'srvcopr2': '', 'srvcopr3': '', 'operation': 'CREATE', 'operation1': '@', 'operation2': '@', 'operation3': '@'}, 'i-body': {'batchNo': '8523', 'REFERENCE_NO': '1008523180610001', 'cbsMsg': {'cbsMsg1': '\\nST-SAVE-052\\nSuccessfully Saved and Authorized\\n'}, 'unqCommID': '6df37887-2d82-4ace-a6bb-0be3f5842e2920190624151443215'}, 'i-stat': {'i-statMsg': 'i-SUCC', 'i-success': [{'msgcode': 'iS#WS00001', 'msgtext': 'TRANSACTION COMPLETED SUCCESSFULLY ', 'conReq': 'N'} ], 'i-warn': [{'msgcode': '', 'msgtext': ''} ], 'i-error': [{'msgcode': '', 'msgtext': ''} ] } }";
					isonMsg = parser.parse(res).getAsJsonObject();
				} else if (I$utils.$iStrFuzzyMatch(trnCd, "FT")) {
					res = "{'i-config': {'sitekey': '3453d693-b0ce-4c6c-a2d7-882adadf7112', 'browser': '', 'clientApp': 'ImpactoWeb', 'imecd': '', 'os': '', 'brwversion': '', 'osversion': '', 'iclntversion': '', 'sessionID': '20190306185014973b3965b2d-0274-4608-a904-75b34c0c7f7a', 'SrcID': 'ImpactoWeb', 'srcApiKey': '895cb63e80d98fef398443255ccc0b6e'}, 'i-header': {'msg-id': '"+ i$ResM.getMsgID(isonMsg)+ "', 'key-hash': '', 'screenid': 'XEXCBRFD', 'srvcname': '', 'srvcopr': '', 'srvcopr1': '', 'srvcopr2': '', 'srvcopr3': '', 'operation': 'CREATE', 'operation1': '@', 'operation2': '@', 'operation3': '@'}, 'i-body': {'batchNo': '7805', 'REFERENCE_NO': '1007805180610001', 'cbsMsg': {'cbsMsg1': '\\nST-SAVE-052\\nSuccessfully Saved and Authorized\\n'} }, 'i-stat': {'i-statMsg': 'i-SUCC', 'i-success': [{'msgcode': 'iS#WS00001', 'msgtext': 'TRANSACTION COMPLETED SUCCESSFULLY ', 'conReq': 'N'}], 'i-warn': [{'msgcode': '', 'msgtext': ''}], 'i-error': [{'msgcode': '', 'msgtext': ''}] } }";
					isonMsg = parser.parse(res).getAsJsonObject();
				} else if (I$utils.$iStrFuzzyMatch(trnCd, "CIF")) {
					isonMsg = parser.parse(res).getAsJsonObject();
				} else if (I$utils.$iStrFuzzyMatch(trnCd, "TD")) {
					res = "{'i-config': {'sitekey': '3453d693-b0ce-4c6c-a2d7-882adadf7112', 'browser': '', 'clientApp': 'ImpactoWeb', 'imecd': '', 'os': '', 'brwversion': '', 'osversion': '', 'iclntversion': '', 'sessionID': 'MjU3NzA5MDk0NDAzTWpVM056QTVNRGswTkRBeg==', 'SrcID': 'ImpactoWeb', 'srcApiKey': '895cb63e80d98fef398443255ccc0b6e'}, 'i-header': {'msg-id': '"+ i$ResM.getMsgID(isonMsg)+ "', 'key-hash': '', 'screenid': 'XEXCBRFD', 'srvcname': '', 'srvcopr': '', 'srvcopr1': '', 'srvcopr2': '', 'srvcopr3': '', 'operation': 'CREATE', 'operation1': '@', 'operation2': '@', 'operation3': '@'}, 'i-body': {'TDACCOUNTNO': '1000001611415761', 'cbsMsg': {'cbsMsg1': '\\nST-TD-199\\nMin / Max Amount not maintained for this account class\\n', 'cbsMsg2': ''} }, 'i-stat': {'i-statMsg': 'i-SUCC', 'i-success': {'msgcode': 'iS#WS00001', 'msgtext': 'TRANSACTION COMPLETED SUCCESSFULLY '}, 'i-warn': {'msgcode': '', 'msgtext': ''}, 'i-error': {'msgcode': '', 'msgtext': ''} } }";
					isonMsg = parser.parse(res).getAsJsonObject();
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
				}
			} else {
				isonMsg = argJson.getAsJsonObject("isonMsgRes");
			}
		} catch (Exception e) {

		}
		// #BVB00172 Ends
		return isonMsg;

	}

	public JsonObject CoreReqFwd(JsonObject isonMsg) {
		try {

			String trnCd = i$ResM.getBodyElementS(isonMsg, "trnCd");

			if (I$utils.$iStrFuzzyMatch(trnCd, "CD")) {
				String initialCD = "N";
				try {
					initialCD = i$ResM.getBodyElementO(isonMsg, "trnData").get("initialCD").getAsString();
				} catch (Exception e) {
					// pass
				}
				if (I$utils.$iStrFuzzyMatch(initialCD, "Y")) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For CD Sucessfull"); // #YPR00062 Changes
				} else {
					isonMsg = CBSCashDeposit(isonMsg);
				}
			} else if (I$utils.$iStrFuzzyMatch(trnCd, "CW")) {
				isonMsg = CBSCashWithdrawal(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(trnCd, "IFT")) {
				isonMsg = CBSFundsTransfer(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(trnCd, "CIF")) {
				isonMsg = CBSCifCreation(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(trnCd, "LINCU")) {
				isonMsg = CBSLINCUCreation(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(trnCd, "ACH")) {
				isonMsg = CBSACHCreation(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(trnCd, "PR")) {
				isonMsg = CBSPayroll(isonMsg);
			}
			else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
		}

		return isonMsg;
	}

	public JsonObject CBSCifCreation(JsonObject isonMsg) {
		try {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed in CIF PREFLIGHT WITH", e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject CBSCashDeposit(JsonObject isonMsg) {
		JsonObject i$body = new JsonObject();
		JsonObject trnData = new JsonObject();
		try {
			i$body = i$ResM.getBody(isonMsg);
			trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			String batchNo = createBatchNo();
			String currency = trnData.get("currency").getAsString();
			String mainAcBrn = trnData.get("creditBranchCode").getAsString();
			String offsetBrn = getOffset("OFFSETBRN", mainAcBrn, currency, "ALL", "CD");
			String valueDate = getValueDate(mainAcBrn);

			trnData.addProperty("offsetBrn", offsetBrn);
			trnData.addProperty("batchNo", batchNo);
			trnData.addProperty("valueDate", valueDate);
			trnData.addProperty("branchCode", mainAcBrn);

			JsonObject offsetAc = getOffsetAc("OFFSETACC", mainAcBrn, currency, "ALL", "CD"); // #BVB00162
			trnData.addProperty("offsetTrn", getOffset("OFFSETTRN", mainAcBrn, currency, "ALL", "CD")); // #BVB00162
			trnData.addProperty("offsetAccType", offsetAc.get("mapClass").getAsString());// #BVB00162
			trnData.addProperty("offsetAcc", offsetAc.get("mapValue").getAsString()); // #BVB00162
			trnData.addProperty("trnBrn", getOffset("TRNBRANCH", mainAcBrn, currency, "ALL", "CD"));// #BVB00162
			trnData.addProperty("offsetCcy", getOffset("OFFSETCCY", mainAcBrn, currency, "ALL", "CD"));// #BVB00162

			i$body.add("trnData", trnData);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For CD Sucessfull");// #BVB00162
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION PARAMATERIZATION FAILED WITH: ", e.getMessage());// #BVB00162
		}
		return isonMsg;
	}

	private JsonObject CBSCashWithdrawal(JsonObject isonMsg) {
		JsonObject i$body = new JsonObject();
		JsonObject trnData = new JsonObject();
		try {
			i$body = i$ResM.getBody(isonMsg);
			trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			String mainAcBrn = trnData.get("deditBranchCode").getAsString();
			String batchNo = createBatchNo();
			String currency = trnData.get("currency").getAsString();
			String offsetBrn = getOffset("OFFSETBRN", mainAcBrn, currency, "ALL", "CW");// #BVB00162
			String valueDate = getValueDate(mainAcBrn);

			trnData.addProperty("offsetBrn", offsetBrn);
			trnData.addProperty("batchNo", batchNo);
			trnData.addProperty("valueDate", valueDate);
			trnData.addProperty("branchCode", mainAcBrn);
			JsonObject offsetAc = getOffsetAc("OFFSETACC", mainAcBrn, currency, "ALL", "CW"); // #BVB00162
			trnData.addProperty("offsetTrn", getOffset("OFFSETTRN", mainAcBrn, currency, "ALL", "CW"));// #BVB00162
			trnData.addProperty("offsetAccType", offsetAc.get("mapClass").getAsString());
			trnData.addProperty("offsetAcc", offsetAc.get("mapValue").getAsString());
			trnData.addProperty("trnBrn", getOffset("TRNBRANCH", mainAcBrn, currency, "ALL", "CW"));// #BVB00162
			trnData.addProperty("offsetCcy", getOffset("OFFSETCCY", mainAcBrn, currency, "ALL", "CW"));// #BVB00162

			i$body.add("trnData", trnData);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For CW Sucessfull");// #BVB00162
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED WITH ", e.getMessage());// #BVB00162
		}
		return isonMsg;
	}

	private JsonObject CBSFundsTransfer(JsonObject isonMsg) {
		JsonObject i$body = new JsonObject();
		JsonObject trnData = new JsonObject();
		try {
			i$body = i$ResM.getBody(isonMsg);
			trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			String batchNo = createBatchNo();
			String currency = trnData.get("currency").getAsString();

			String mainAcBrn = trnData.get("debitBranchCode").getAsString();

			String valueDate = getValueDate(mainAcBrn);

			trnData.addProperty("batchNo", batchNo);
//			trnData.addProperty("valueDate", valueDate);
			trnData.addProperty("branchCode", mainAcBrn);
			// #MAQ00144 starts
			String trnBrn;
			try {
				trnBrn = getOffset("TRNBRANCH", mainAcBrn, currency, "ALL", "IFT");
			} catch (Exception e) {
				trnBrn = mainAcBrn;
			}
			String trnCode;
			try {
				trnCode = getOffset("OFFSETTRN", mainAcBrn, currency, "ALL", "IFT");
			} catch (Exception e) {
				trnCode = "MSC";
			}
			
			trnData.addProperty("trnBrn", trnBrn);// #BVB00162
			trnData.addProperty("trnCode", trnCode);// #BVB00162
			// #MAQ00144 ends
			i$body.add("trnData", trnData);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For IFT Sucessfull");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED WITH ", e.getMessage());
		}
		return isonMsg;
	}
	
	private JsonObject CBSPayroll(JsonObject isonMsg) {
		JsonObject i$body = new JsonObject();
		JsonObject trnData = new JsonObject();
		try {
			i$body = i$ResM.getBody(isonMsg);
			trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			//String batchNo = createBatchNo();
			String currency = trnData.get("currency").getAsString();

			String mainAcBrn = trnData.get("debitBranchCode").getAsString();

			String valueDate = getValueDate(mainAcBrn);

			//trnData.addProperty("batchNo", batchNo);
			trnData.addProperty("valueDate", valueDate);
			trnData.addProperty("branchCode", mainAcBrn);
			// #MAQ00144 starts
			// #MAQ00144 ends
			i$body.add("trnData", trnData);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For Payroll Sucessfull");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED WITH ", e.getMessage());
		}
		return isonMsg;
	}
	
	//#TKS00003 starts
	private JsonObject CBSLINCUCreation(JsonObject isonMsg) {
		JsonObject i$body = new JsonObject();
		JsonObject trnData = new JsonObject();
		try {
			i$body = i$ResM.getBody(isonMsg);
			trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			String batchNo = createBatchNo();
			String currency = trnData.get("ccy").getAsString();

			String mainAcBrn = trnData.get("branch").getAsString();

			String valueDate = getValueDate(mainAcBrn);

			trnData.addProperty("batchNo", batchNo);
//			trnData.addProperty("valueDate", valueDate);
			trnData.addProperty("branchCode", mainAcBrn);
			// #MAQ00144 starts
			String trnBrn;
			try {
				trnBrn = getOffset("TRNBRANCH", mainAcBrn, currency, "ALL", "LINCU");
			} catch (Exception e) {
				trnBrn = mainAcBrn;
			}
			String trnCode;
			try {
				trnCode = getOffset("OFFSETTRN", mainAcBrn, currency, "ALL", "LINCU");
			} catch (Exception e) {
				trnCode = "MSC";
			}
			
			trnData.addProperty("trnBrn", trnBrn);// #BVB00162
			trnData.addProperty("trnCode", trnCode);// #BVB00162
			// #MAQ00144 ends
			i$body.add("trnData", trnData);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For LINCU Sucessfull");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED WITH ", e.getMessage());
		}
		return isonMsg;
	}
	//#TKS00003 ends
	//#TKS00003 starts
	private JsonObject CBSACHCreation(JsonObject isonMsg) {
		JsonObject i$body = new JsonObject();
		JsonObject trnData = new JsonObject();
		try {
			i$body = i$ResM.getBody(isonMsg);
			trnData = i$ResM.getBodyElementO(isonMsg, "trnData");
			String batchNo = createBatchNo();
			String currency = trnData.get("ccy").getAsString();

			String mainAcBrn = trnData.get("branch").getAsString();

			String valueDate = getValueDate(mainAcBrn);

			trnData.addProperty("batchNo", batchNo);
//			trnData.addProperty("valueDate", valueDate);
			trnData.addProperty("branchCode", mainAcBrn);
			// #MAQ00144 starts
			String trnBrn;
			try {
				trnBrn = getOffset("TRNBRANCH", mainAcBrn, currency, "ALL", "ACH");
			} catch (Exception e) {
				trnBrn = mainAcBrn;
			}
			String trnCode;
			try {
				trnCode = getOffset("OFFSETTRN", mainAcBrn, currency, "ALL", "ACH");
			} catch (Exception e) {
				trnCode = "MSC";
			}
			
			trnData.addProperty("trnBrn", trnBrn);// #BVB00162
			trnData.addProperty("trnCode", trnCode);// #BVB00162
			// #MAQ00144 ends
			i$body.add("trnData", trnData);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Pre For ACH Sucessfull");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED WITH ", e.getMessage());
		}
		return isonMsg;
	}
	//#TKS00003 ends
	private String createBatchNo() {
		String batchNo = "";
		try {
			batchNo = Long.toString(i$impactoUtil.generateRandomLong(4));
		} catch (Exception e) {
			batchNo = "0001";
		}
		return batchNo;
	}

	private String getValueDate(String trnBrn) {
		String date = "";
		JsonObject filter = new JsonObject();
		try {
			// Have to get the data from E - Data collection
			filter.addProperty("BranchCode", trnBrn);
			filter.addProperty("Type", "CBS_BRANCH");
			date = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter).get("BranchDate").getAsString();
			//date = date.replaceAll(" 00:00:00.0", "");
			date = i$impactoUtil.trimDate(date); 

		} catch (Exception e) {
			logger.debug("Failed to Get the value Date for branch: " + trnBrn + " with error: " + e.getMessage());
			date = null;
		}
		return date;
	}

	// #BVB00162 Starts
	private String getOffset(String sMapType, String brnCd, String ccy, String custCat, String trnCd) {
		JsonObject offSetRec = new JsonObject();
		try {
			JsonObject icorMAmbassador = i$ResM.getGobalValJObj("AMBASSADOR");
			if (!I$utils.$isNull(icorMAmbassador)) {
				String group = icorMAmbassador.get("Grp_Type").getAsString();
				String subGroup = icorMAmbassador.get("Sub_Grp_Type").getAsString();

				offSetRec = I$CbsSettleInstr.getInstrMap(brnCd, group, subGroup, IResManipulator.iloggedUser.get(), ccy,
						custCat, trnCd, sMapType);

				// Get the data from ICOR_C_WS_TRANSMITTER
			}
		} catch (Exception e) {
			offSetRec = null;
		}

		return offSetRec.get("mapValue").getAsString();
	}

	private JsonObject getOffsetAc(String sMapType, String brnCd, String ccy, String custCat, String trnCd) {
		JsonObject offSetRec = new JsonObject();
		try {
			JsonObject icorMAmbassador = i$ResM.getGobalValJObj("AMBASSADOR");
			if (!I$utils.$isNull(icorMAmbassador)) {
				String group = icorMAmbassador.get("Grp_Type").getAsString();
				String subGroup = icorMAmbassador.get("Sub_Grp_Type").getAsString();

				offSetRec = I$CbsSettleInstr.getInstrMap(brnCd, group, subGroup, IResManipulator.iloggedUser.get(), ccy,
						custCat, trnCd, sMapType);

				// Get the data from ICOR_C_WS_TRANSMITTER
			}
		} catch (Exception e) {
			offSetRec = null;
		}

		return offSetRec;
	}

	// #BVB00162 Ends
	public ICorePrePostController() {
		// Constructor
	}
}
