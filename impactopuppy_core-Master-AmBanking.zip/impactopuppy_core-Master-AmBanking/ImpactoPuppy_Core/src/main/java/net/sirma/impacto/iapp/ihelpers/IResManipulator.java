/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Oct 1, 2018  | #BVB00004   | Added new Functions 
      |0.1 Beta    | Vijay 		| Nov 29, 2018 | #BVB00016   | Feature I-Projection added
      |0.1 Beta    | Niegil 	| Jan 15, 2019 | #00000002   | Source Code Validation FrameWork Changes 
      |0.1 Beta    | Niegil 	| Jan 16, 2019 | #00000003   | Global Var Changs 
      |0.1 Beta    | Niegil 	| Jan 18, 2019 | #00000004   | Global Var Changs 
      |0.2.1 Beta  | Vijay 		| Jan 24, 2019 | #BVB00041   | Data Time function Bug Fix
      |0.2.1       | Vijay 		| Jan 30, 2019 | #BVB00043   | Audit Login for Users
      |0.2.1       | Vijay 		| Feb 02, 2019 | #BVB00049   | Audit Login for Users
      |0.2.1       | Niegil 	| Feb 05, 2019 | #NYE00001   | Changes for IsonMsg Resp Validation , Add to Body Function, IWARN Addition
      |0.2.1       | Niegil 	| Feb 09, 2019 | #NYE00002   | Changes for Globals Reset
      |0.2.1       | Niegil 	| Feb 16, 2019 | #NYE00003   | Clean Thread Locals
      |0.2.1       | Viay   	| Feb 17, 2019 | #BVB00077   | Getting Body message as Array
      |0.2.1       | Viay   	| Feb 17, 2019 | #BVB00062   | WS change and function to get header element generic 
      |0.2.1       | Niegil 	| Feb 16, 2019 | #NYE00041   | Added Constant for the Error Framework
      |0.3.5       | Vijay  	| Apr 15, 2019 | #BVB00114   | New function to add a new property and its value to I-Body
      |0.3.7       | Vijay 		| May 02, 2019 | #BVB00137   | Adding handling for queryFilter coming as String 
      |0.3.7       | Vijay 		| May 02, 2019 | #BVB00147   | Get only date with a format
      |0.3.7       | Baz 		| May 15, 2019 | #BZ000148   | Get ScrId from i-config
      |0.2.1       | Niegil 	| May 22, 2019 | #NYE10042   | Added DataSet Filter KeyName
      |0.3.15.293  | Syed 		| Jun 21, 2019 | #MAQ00020   | Changed Gson to Gson Builder
      |0.3.17      | Vijay 		| Aug 05, 2019 | #BVB00191   | ReKyc Flow change
      |0.3.17      | Tarun 		| Sep 01, 2022 | #TKS00012   | added code to return string
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder; // #MAQ00020
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

import net.sirma.impacto.iapp.iutils.Ioutils;

public class IResManipulator {
	public static final String I_YCHAR = null;
	private Logger logger = LoggerFactory.getLogger(IResManipulator.class);
	private Ioutils I$utils = new Ioutils();
	public static ThreadLocal<JsonObject> JReqheader = ThreadLocal.<JsonObject>withInitial(() -> {
		return new JsonObject();
	}); // #NYE00003
	public final String I_SUCC = IConstants.I_SUCC.toString(), I_ERR = IConstants.I_ERR.toString(),
			I_WRN = IConstants.I_WRN.toString(), I_SUCCWCD = IConstants.I_SUCCWCD.toString(),
			I_BDYTAG = IConstants.I_BDYTAG.toString(), I_STATTAG = IConstants.I_STATTAG.toString(),
			I_ERRWCD = IConstants.I_ERRWCD.toString(), I_WRNWCD = IConstants.I_WRNWCD.toString(),
			I_REQTPL = IConstants.I_REQTPL.toString(), I_REQTPL_NBDY = IConstants.I_REQTPL_NBDY.toString(),
			I_RESISTAT = IConstants.I_RESISTAT.toString(), I_BDYRTAG = IConstants.I_BDYRTAG.toString(),
			I_REMFRMJSON = "REMFRMJSON", I_ADDTOJSON = "ADDTOJSON", I_MATCH = IConstants.I_MATCH.toString(),
			I_SUCCESS = IConstants.I_SUCCESS.toString(), I_ERROR = IConstants.I_ERROR.toString(),
			I_MSGTEXT = IConstants.I_MSGTEXT.toString(), I_WARNING = IConstants.I_WARNING.toString(), // #NYE00001
			I_STATTAGMSG = IConstants.I_STATTAGMSG.toString(), // #NYE00041
			I_STATMSGCODE = IConstants.I_STATMSGCODE.toString(), // #NYE00041
			I_CONFREQ = IConstants.I_CONFREQ.toString(), // #NYE00041
			I_DSTFLTR = IConstants.I_DSTFLTR.toString(), // #NYE10042
			I_PROJECTION = IConstants.I_PROJECTION.toString(), I_CALLJAVA = IConstants.I_CALLJAVA.toString(),
			I_CALLWS = IConstants.I_CALLWS.toString(), I_CORE_SESSION = IConstants.I_CORE_SESSION.toString(), // #BVB00062
			// #BVB00191 Starts
			I_DRIVERSPERMIT = IConstants.I_DRIVERSPERMIT.toString(), I_NATIONALID = IConstants.I_NATIONALID.toString(),
			I_DRIVERPERMIT = IConstants.I_DRIVERPERMIT.toString(), I_PASSPORT = IConstants.I_PASSPORT.toString(),
			I_PRIDOC = IConstants.I_PRIDOC.toString(), I_XML = IConstants.I_XML.toString(),
			I_SECDOC = IConstants.I_SECDOC.toString(), I_ORACLE = IConstants.I_ORACLE.toString(),
			I_MONGO = IConstants.I_MONGO.toString(), I_CUSMEM = IConstants.I_CUSMEM.toString(),
			I_CUSMEMCAPS = IConstants.I_CUSMEMCAPS.toString(),
					I_SUCCTEXT = IConstants.I_SUCCTEXT.toString(),
					I_WRNTEXT = IConstants.I_WRNTEXT.toString(),I_ERRTEXT = IConstants.I_ERRTEXT.toString(),
					I_MAIN_SESSION = IConstants.I_MAIN_SESSION.toString(), I_PRAGMA_SESSION =  IConstants.I_PRAGMA_SESSION.toString(),
							I_CONF = IConstants.I_CONF.toString(),I_RESTATARR = IConstants.I_RESTATARR.toString(),
									I_HEADER = IConstants.I_HEADER.toString(), I_SUP_LOC_MSG = IConstants.I_SUP_LOC_MSG.toString(),I_CONFIG = IConstants.I_CONFIG.toString();
	// #BVB00191 Ends
	// public JsonObject JGobalConstans = new JsonObject(); // #00000003 Changes for
	// Request Forwarder
	public static ThreadLocal<JsonObject> JGobalConstans = ThreadLocal.<JsonObject>withInitial(() -> {
		return new JsonObject();
	});

	public static ThreadLocal<String> iloggedUser = ThreadLocal.<String>withInitial(() -> {
		return "";
	});

	// #NYE00003 Begin
	public void cleanThreadLocals() {
		IResManipulator.iloggedUser.remove();
		IResManipulator.JGobalConstans.remove();
		IDataValidator.J$TempStorage.remove();
		IDataValidator.i$AnnotRes.remove();
		IResManipulator.JReqheader.remove();
	}; // isStringOn
		// #NYE00003 End

	public JsonObject getHeader(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header");
		} catch (Exception E) {
			return null;
		}
	};

	// #00000003 - Changes for Request Forwarder - Begins
	public void setGobalVals(String property, JsonObject value) {
		JGobalConstans.get().add(property, value);
	};

	public void setGobalVals(String property, JsonArray value) {
		JGobalConstans.get().add(property, value);
	};

	public void setGobalVals(String property, String value) {
		JGobalConstans.get().addProperty(property, value);
	};

	public void setGobalVals(String property, Integer value) {
		JGobalConstans.get().addProperty(property, value);
	};

	public void setGobalVals(String property, Boolean value) {
		JGobalConstans.get().addProperty(property, value);
	};

	public String getGobalValStr(String memberName) {
		try {
			return JGobalConstans.get().get(memberName).getAsString(); // #00000004
		} catch (Exception Ex) {
			return null;
		}
	};
	
	public JsonObject getGobalValJObj(String memberName) {
		try {
			return JGobalConstans.get().get(memberName).getAsJsonObject(); // #00000004
		} catch (Exception Ex) {
			return null;
		}
	};
	
	public JsonArray getGobalValArr(String memberName) {
		try {
			return JGobalConstans.get().get(memberName).getAsJsonArray(); // #00000004
		} catch (Exception Ex) {
			return null;
		}
	};
	
	public JsonObject getAllGobal() {
		try {
			return JGobalConstans.get().getAsJsonObject();
		} catch (Exception Ex) {
			return null;
		}
	};

	public void setAllGlobal(JsonObject globals) {
		try {

			Set<Entry<String, JsonElement>> entrySet = globals.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				try {
					if (globals.get(entry.getKey()).isJsonArray()) {
						setGobalVals(entry.getKey(), globals.getAsJsonArray(entry.getKey()));
					} else if (entry.getValue().isJsonObject()) {
						setGobalVals(entry.getKey(), globals.getAsJsonObject(entry.getKey()));
					} else if (entry.getValue().isJsonPrimitive()) {
						setGobalVals(entry.getKey(), globals.get(entry.getKey()).getAsString());
					}
				} catch (Exception ed) {

				}
			}
		} catch (Exception e) {

		}
	};

	public JsonArray getConfArr(JsonObject isonMsg) {
 		try {
			return isonMsg.getAsJsonArray("i-conf");
		} catch (Exception e) {
			return null;
		}
	};
	
	public boolean hasConfArr(JsonObject isonMsg) {
 		try {
			return isonMsg.has("i-conf");
		} catch (Exception e) {
			return false;
		}
	};
	
	
	public int getBodyElementI(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-body").get(element).getAsInt();
		} catch (Exception E) {
			return -999;
		}
	};
	//#TKS00012 changes
	public String getBodyElementToS(JsonObject isonMsg, String element, String defaultVal) {
	    try {
	      return isonMsg.getAsJsonObject("i-body").get(element).toString();
	    } catch (Exception E) {
	      return defaultVal;
	    }
	  };
	
	public JsonArray iHandleRes(String iStatMsgCode, String iMsgText, String conReq) {
 		JsonArray isonArrMsgBuilder = new JsonArray(); 
		try {
			JsonObject isonMsgBuilderObj = new JsonObject();
			isonMsgBuilderObj.addProperty(I_STATMSGCODE, iStatMsgCode);
            isonMsgBuilderObj.addProperty(I_MSGTEXT, iMsgText);
            isonMsgBuilderObj.addProperty(I_CONFREQ, "N"); 
			isonArrMsgBuilder.add(isonMsgBuilderObj);
		} catch (Exception e) {
			
		}
		return isonArrMsgBuilder; 
	}
	
	
	public JsonObject iHandleRes(JsonObject resJson, String iStatMsgCode, String iMsgText, String conReq) {
		String istat = I_RESTATARR;
		JsonParser parser = new JsonParser();
		JsonObject jelemIstat = new JsonObject();
		JsonArray isonArrMsgBlnk = new JsonArray(); 
		JsonObject isonMsgblkObj = new JsonObject();
        isonMsgblkObj.addProperty("msgcode", "");
        isonMsgblkObj.addProperty("msgtext", "");
        
		isonArrMsgBlnk.add(isonMsgblkObj);
		JsonArray isonArrMsgBuilder =  iHandleRes(iStatMsgCode, iMsgText, conReq);
		if (I$utils.$iStrFuzzyMatch(iStatMsgCode, I_ERR)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_ERR);  
			jelemIstat = parser.parse(istat).getAsJsonObject(); 
			jelemIstat.add(I_ERROR, isonArrMsgBuilder);
			jelemIstat.add(I_SUCCESS, isonArrMsgBlnk);
			jelemIstat.add(I_WARNING, isonArrMsgBlnk);
			
		} else if (I$utils.$iStrFuzzyMatch(iStatMsgCode, I_WRN)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_WRN); 
			jelemIstat = parser.parse(istat).getAsJsonObject();
			jelemIstat.add(I_ERROR, isonArrMsgBlnk);
			jelemIstat.add(I_SUCCESS, isonArrMsgBlnk);
			jelemIstat.add(I_WARNING, isonArrMsgBuilder);
		} else if (I$utils.$iStrFuzzyMatch(iStatMsgCode, I_SUCC)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_SUCC); 
			jelemIstat = parser.parse(istat).getAsJsonObject();
			jelemIstat.add(I_ERROR, isonArrMsgBlnk);
			jelemIstat.add(I_SUCCESS, isonArrMsgBuilder);
			jelemIstat.add(I_WARNING, isonArrMsgBlnk);
		}
		
		resJson.add(I_STATTAG, jelemIstat);
		return resJson;
	}
	 
	
	public JsonObject iHandleResStat(JsonObject resJson, String iStatMsgCode, JsonArray isonArrMsgBuilder) {
		String istat = I_RESTATARR;
		JsonParser parser = new JsonParser();
		JsonObject jelemIstat = new JsonObject();
		JsonArray isonArrMsgBlnk = new JsonArray(); 
		JsonObject isonMsgblkObj = new JsonObject();
        isonMsgblkObj.addProperty("msgcode", "");
        isonMsgblkObj.addProperty("msgtext", "");
        
		isonArrMsgBlnk.add(isonMsgblkObj);
        
		if (I$utils.$iStrFuzzyMatch(iStatMsgCode, I_ERR)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_ERR);  
			jelemIstat = parser.parse(istat).getAsJsonObject(); 
			jelemIstat.add(I_ERROR, isonArrMsgBuilder);
			jelemIstat.add(I_SUCCESS, isonArrMsgBlnk);
			jelemIstat.add(I_WARNING, isonArrMsgBlnk);
			
		} else if (I$utils.$iStrFuzzyMatch(iStatMsgCode, I_WRN)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_WRN); 
			jelemIstat = parser.parse(istat).getAsJsonObject();
			jelemIstat.add(I_ERROR, isonArrMsgBlnk);
			jelemIstat.add(I_SUCCESS, isonArrMsgBlnk);
			jelemIstat.add(I_WARNING, isonArrMsgBuilder);
		} else if (I$utils.$iStrFuzzyMatch(iStatMsgCode, I_SUCC)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_SUCC); 
			jelemIstat = parser.parse(istat).getAsJsonObject();
			jelemIstat.add(I_ERROR, isonArrMsgBlnk);
			jelemIstat.add(I_SUCCESS, isonArrMsgBuilder);
			jelemIstat.add(I_WARNING, isonArrMsgBlnk);
		}
		
		resJson.add(I_STATTAG, jelemIstat);
		return resJson;
	}
	
	public int getIntfromObjWithDefault(JsonObject inObj, String name, int defaultValue) {
		try {
			return inObj.get(name).getAsInt();
		} catch (Exception e) {
			return defaultValue;
		}
	}

	public Integer getGobalValInt(String memberName) {
		try {
			return JGobalConstans.get().get(memberName).getAsInt();
		} catch (Exception Ex) {
			return null;
		}
	};

	public boolean getGobalValBol(String memberName) {
		try {
			return JGobalConstans.get().get(memberName).getAsBoolean();
		} catch (Exception Ex) {
			return false; // #MAQ00051
		}
	};

	//

	// #00000003 - Changes for Request Forwarder - Ends

	// #00000002 Begin
	@SuppressWarnings("unused")
	public void setHeadersInfo(HttpServletRequest request) {
		@SuppressWarnings("rawtypes")
		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = request.getHeader(key);
			JReqheader.get().addProperty(key, value);
		}
		JReqheader.get().addProperty("LocalAddr", request.getLocalAddr());
		if (request.getHeader("X-Forwarded-For") != null)
			JReqheader.get().addProperty("RemoteAddr", request.getHeader("X-Forwarded-For"));
		else
			JReqheader.get().addProperty("RemoteAddr", request.getRemoteAddr());
		JReqheader.get().addProperty("RemoteHost", request.getRemoteHost());
		JReqheader.get().addProperty("RequestedSessionId", request.getRequestedSessionId());
		JReqheader.get().addProperty("RemotePort", request.getRemotePort());
		JReqheader.get().addProperty("DIGEST_AUTH", request.DIGEST_AUTH);
		JReqheader.get().addProperty("RemoteUser", request.getRemoteUser());
		JReqheader.get().addProperty("LocalName", request.getLocalName());
		JReqheader.get().addProperty("RequestURI", request.getRequestURI());
		JReqheader.get().addProperty("PathTranslated", request.getPathTranslated());
		JReqheader.get().addProperty("PathInfo", request.getPathInfo());
		JReqheader.get().addProperty("AuthType", request.getAuthType());
		JReqheader.get().addProperty("ContentType", request.getContentType());
		JReqheader.get().addProperty("ContextPath", request.getContextPath());
		JReqheader.get().addProperty("Protocol", request.getProtocol());
		JReqheader.get().addProperty("CharacterEncoding", request.getCharacterEncoding());
		JReqheader.get().addProperty("Scheme", request.getScheme());
		JReqheader.get().addProperty("ServerName", request.getServerName());
		// #BVB00043 Starts
		try {
			JReqheader.get().addProperty("Authorization", request.getHeader("Authorization").replaceAll("Bearer ", ""));
		} catch (Exception e) {
			// Eat up
		}
		// #BVB00043 Ends
		if (JReqheader.get().get("RemoteAddr").getAsString().endsWith("0.0.1")) {
			InetAddress inetAddress;
			try {
				inetAddress = InetAddress.getLocalHost();
				String ipAddress = inetAddress.getHostAddress();
				JReqheader.get().addProperty("RemoteAddr", ipAddress);
				JReqheader.get().addProperty("RemoteHost", inetAddress.toString());
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	// #00000002 End
	public JsonObject getConfig(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config");
		} catch (Exception E) {
			return null;
		}
	};

	public JsonObject getBody(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-body");
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00077 Starts
	public JsonArray getBodyA(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonArray("i-body");
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00077 Ends
	public JsonObject getMatch(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-match");
		} catch (Exception E) {
			return null;
		}
	};
	// #BVB00016 Starts

	public JsonArray getProjection(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonArray("i-projection");
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00016 Ends

	public String getSrvcName(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("srvcname").getAsString();
		} catch (Exception E) {
			E.printStackTrace();
			return null;
		}
	};

	public String getSrvcopr(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("srvcopr").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getJsonStr(JsonObject isonMsg) {
//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			return gson.toJson(isonMsg);
		} catch (Exception E) {
			return null;
		}
	};

	// #NYE00001 Begins
	public JsonObject getJsonObj(String sJson) {
		JsonParser jsonParser = new JsonParser();
		JsonObject jObj = (JsonObject) jsonParser.parse(sJson);
		try {
			return jObj;
		} catch (Exception E) {
			return null;
		}
	};

	public JsonArray getJsonArr(String sJson) {
		JsonParser jsonParser = new JsonParser();
		JsonArray jObj = (JsonArray) jsonParser.parse(sJson);
		try {
			return jObj;
		} catch (Exception E) {
			return null;
		}
	};

	public String getStrJson(JsonElement jsonArr) {
		Gson gson = new Gson();
		try {
			return gson.toJson(jsonArr);
		} catch (Exception E) {
			return null;
		}
	};

	public JsonObject add2IsonBody(JsonObject isonMsg, String sMemberName, Object Val) {
		try {
			String sClsName = Val.getClass().getName();

			if (I$utils.$iStrFuzzyMatch(sClsName, String.class.getName()))
				isonMsg.getAsJsonObject("i-body").addProperty(sMemberName, (String) Val);
			if (I$utils.$iStrFuzzyMatch(sClsName, Integer.class.getName()))
				isonMsg.getAsJsonObject("i-body").addProperty(sMemberName, (Integer) Val);
			if (I$utils.$iStrFuzzyMatch(sClsName, Float.class.getName()))
				isonMsg.getAsJsonObject("i-body").addProperty(sMemberName, (Float) Val);
			if (I$utils.$iStrFuzzyMatch(sClsName, Double.class.getName()))
				isonMsg.getAsJsonObject("i-body").addProperty(sMemberName, (Double) Val);
			if (I$utils.$iStrFuzzyMatch(sClsName, boolean.class.getName()))
				isonMsg.getAsJsonObject("i-body").addProperty(sMemberName, (Boolean) Val);
			if (I$utils.$iStrFuzzyMatch(sClsName, JsonObject.class.getName()))
				isonMsg.getAsJsonObject("i-body").add(sMemberName, (JsonObject) Val);
			if (I$utils.$iStrFuzzyMatch(sClsName, JsonElement.class.getName()))
				isonMsg.getAsJsonObject("i-body").add(sMemberName, (JsonElement) Val);
			return isonMsg;
		} catch (Exception E) {
			return null;
		}
	};

	// #NYE00001 ends
	public String getSrvcopr1(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("srvcopr1").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getSrvcopr2(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("srvcopr2").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getSrvcopr3(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("srvcopr3").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getMsgID(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("msg-id").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getkeyHash(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("key-hash").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getScreenID(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("screenid").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	// #NYE00041 Begins
	public JsonArray getMsgtextArr(JsonObject isonMsg) {
		JsonArray re$ult = new JsonArray();
		try {
			String iStat = isonMsg.getAsJsonObject("i-stat").get("i-statMsg").getAsString();
			if (I$utils.$iStrFuzzyMatch(iStat, I_SUCC)) {
				re$ult = isonMsg.getAsJsonObject("i-stat").getAsJsonArray(I_SUCCESS);
			} else if (I$utils.$iStrFuzzyMatch(iStat, I_WRN)) {
				re$ult = isonMsg.getAsJsonObject("i-stat").getAsJsonArray(I_WARNING);
			} else if (I$utils.$iStrFuzzyMatch(iStat, I_ERR)) {
				re$ult = isonMsg.getAsJsonObject("i-stat").getAsJsonArray(I_ERROR);
			}
			return re$ult;
		} catch (Exception e) {
			return null;
		}
	};

// #NYE00041 Ends 

	public String getMsgtext(JsonObject isonMsg) {
		String msgText = "";
		// #NYE00041 Begins
		try {
			String iStat = isonMsg.getAsJsonObject("i-stat").get("i-statMsg").getAsString();
			if (I$utils.$iStrFuzzyMatch(iStat, I_SUCC)) {
				msgText = isonMsg.getAsJsonObject("i-stat").getAsJsonArray(I_SUCCESS).get(0).getAsJsonObject()
						.get(I_MSGTEXT).getAsString();
			} else if (I$utils.$iStrFuzzyMatch(iStat, I_WRN)) {
				msgText = isonMsg.getAsJsonObject("i-stat").getAsJsonArray(I_WARNING).get(0).getAsJsonObject()
						.get(I_MSGTEXT).getAsString();
			} else if (I$utils.$iStrFuzzyMatch(iStat, I_ERR)) {
				msgText = isonMsg.getAsJsonObject("i-stat").getAsJsonArray(I_ERROR).get(0).getAsJsonObject()
						.get(I_MSGTEXT).getAsString();
			}
			return msgText;
		}
		// #NYE00041 Ends
		catch (Exception e) {
			try {
				String iStat = isonMsg.getAsJsonObject("i-stat").get("i-statMsg").getAsString();
				if (I$utils.$iStrFuzzyMatch(iStat, I_SUCC)) {
					msgText = isonMsg.getAsJsonObject("i-stat").getAsJsonObject(I_SUCCESS).get(I_MSGTEXT).getAsString();
				} else if (I$utils.$iStrFuzzyMatch(iStat, I_WRN)) {
					msgText = isonMsg.getAsJsonObject("i-stat").getAsJsonObject(I_WARNING).get(I_MSGTEXT).getAsString(); // #NYE00001
				} else if (I$utils.$iStrFuzzyMatch(iStat, I_ERR)) {
					msgText = isonMsg.getAsJsonObject("i-stat").getAsJsonObject(I_ERROR).get(I_MSGTEXT).getAsString();
				}
			} catch (Exception E) {
				return null;
			}
			return msgText;
		}
	};

	// #NYE00001 Begins

	public boolean isRespSucc(JsonObject isonMsg) {
		try {
			String iStat = isonMsg.getAsJsonObject("i-stat").get("i-statMsg").getAsString();
			return iStat.equals(I_SUCC);
		} catch (Exception E) {
			return false;
		}
	};

	// #NYE00001 Ends

	public String getStatMsg(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-stat").get("i-statMsg").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public JsonObject getiStat(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-stat");
		} catch (Exception E) {
			return null;
		}
	}

	public String getOpr(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("operation").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getOpr1(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("operation1").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getOpr2(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("operation2").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getOpr3(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-header").get("operation3").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getClientSessionID(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("sessionID").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getBrwVer(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("brwversion").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getOSVer(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("osversion").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getIWebVer(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("iclntversion").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getIME(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("imecd").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getOS(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("os").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getSiteKey(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("sitekey").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getBrowser(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("browser").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	public String getClientApp(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("clientApp").getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	// #00000002 Adds
	public String getSrcApiKey(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("srcApiKey").getAsString();
		} catch (Exception E) {
			return null;
		}
	};
	// #00000002 Ends

	// #BZ000148 begins
	public String getSrcId(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-config").get("SrcID").getAsString();
		} catch (Exception E) {
			return null;
		}
	}; // //#BZ000148 ends

	// #BVB00004 Starts
	public JsonArray getIMatch(JsonObject isonMapJson) {
		try {
			return isonMapJson.getAsJsonArray("I_MATCH");
		} catch (Exception E) {
			return null;
		}
	};

	public String getTranId(JsonObject isonMsg) {
		try {
			return isonMsg.getAsJsonObject("i-body").get("tranId").getAsString();
		} catch (Exception E) {
			return "";
		}
	};
	// #
	
	public String getBodyElementS(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-body").get(element).getAsString();
		} catch (Exception E) {
			return null;
		}
	};
	// #BVB00004 Ends
	
	public String getBodyElementS(JsonObject isonMsg, String element, String defaultVal) {
		try {
			return isonMsg.getAsJsonObject("i-body").get(element).getAsString();
		} catch (Exception E) {
			return defaultVal;
		}
	};

	// #BVB00049 Starts
	public JsonObject getBodyElementO(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-body").get(element).getAsJsonObject();
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00049 Ends
	public JsonArray getBodyElementA(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-body").get(element).getAsJsonArray();
		} catch (Exception E) {
			return null;
		}
	};

	public JsonElement getBodyElement(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-body").get(element);
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00062 Starts
	public String getHeaderElementS(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-header").get(element).getAsString();
		} catch (Exception E) {
			return null;
		}
	};
	// #BVB00062 Ends

	public String getConfigElementS(JsonObject isonMsg, String element) {
		try {
			return isonMsg.getAsJsonObject("i-config").get(element).getAsString();
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00016 Starts
	public JsonArray getIProjection(JsonObject isonMapJson) {
		try {
			return isonMapJson.getAsJsonArray("I_PROJECTION");
		} catch (Exception E) {
			return null;
		}
	};

	// #BVB00016 Ends
	//MSA00041 starts
	public JsonArray getINonProjection(JsonObject isonMapJson) {
		try {
			return isonMapJson.getAsJsonArray("I_NON_PROJECTION");
		} catch (Exception E) {
			return null;
		}
	};//MSA00041 ends
	public JsonObject adddate(Date dt) {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		String nowAsISO = df.format(dt);
		JsonParser parser = new JsonParser();
		return parser.parse("{ \"$date\" :\"" + nowAsISO + "\"}").getAsJsonObject();
	}

	public String getOnlydate(Date dt) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // Quoted "Z" to indicate UTC, no timezone offset
		String nowAsISO = df.format(dt);
		return nowAsISO;
	}

	public String getdateTime(Date dt) {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		String nowAsISO = df.format(dt);
		return nowAsISO;
	}

// #BVB00147 Starts
	public String getOnlydate(Date dt, String format) {
		DateFormat df = new SimpleDateFormat(format); // Quoted "Z" to indicate UTC, no timezone offset
		String nowAsISO = df.format(dt);
		return nowAsISO;
	}

	// #BVB00147 Ends
	// #BVB00004 Starts
	public JsonObject addDateTime(Date dt) {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		// DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss:SSS'Z'");//
		// BVB00041
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); // BVB00041
		df.setTimeZone(tz);
		String nowAsISO = df.format(dt);
		JsonParser parser = new JsonParser();
		return parser.parse("{ \"$date\" :\"" + nowAsISO + "\"}").getAsJsonObject();
	}
	// #BVB00004 Ends

	public JsonObject iHandleArgJson(String JsonOpr, JsonObject argJson, String PropName, String Propval) {
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_ADDTOJSON)) {
			JsonParser parser = new JsonParser();
			try {
				argJson.add(PropName, parser.parse(Propval).getAsJsonObject());
			} catch (Exception e) {
				argJson.addProperty(PropName, Propval);
			}
		}
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_REMFRMJSON))
			argJson.remove(PropName);
		return argJson;
	};

	// #BVB00137 Starts
	public JsonObject iHandleArgJson(String JsonOpr, JsonObject argJson, String PropName, String Propval,
			boolean isStringOnly) {
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_ADDTOJSON)) {
			try {
				argJson.addProperty(PropName, Propval);
			} catch (Exception e) {

			}
		}
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_REMFRMJSON))
			argJson.remove(PropName);
		return argJson;
	};

	// #BVB00137 Ends
	public JsonObject iHandleArgJson(String JsonOpr, JsonObject argJson, String PropName, Integer Propval) {
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_ADDTOJSON)) {
			argJson.addProperty(PropName, Propval);
		}
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_REMFRMJSON))
			argJson.remove(PropName);
		return argJson;
	};

	public JsonObject iHandleArgJson(String JsonOpr, JsonObject argJson, String PropName) {
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_REMFRMJSON))
			argJson.remove(PropName);
		return argJson;
	};

	public JsonObject iHandleArgJson(String JsonOpr, JsonObject argJson, String PropName, JsonArray Propval) {
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_ADDTOJSON))
			argJson.add(PropName, Propval);
		return argJson;
	};

	public JsonObject iHandleArgJson(String JsonOpr, JsonObject argJson, String PropName, JsonObject Propval) {
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		if (I$utils.$iStrFuzzyMatch(JsonOpr, I_ADDTOJSON))
//			argJson.add(PropName, new Gson().toJsonTree(Propval));
			argJson.add(PropName, gson.toJsonTree(Propval)); // #MAQ00020
		return argJson;
	};

	public JsonObject iHandleResStat(JsonObject resJson, String Status, String Msg) {
		return iHandleResStat(resJson, Status, Msg, null);
	};

	// #BVB00114 Starts
	public JsonObject addStrToBody(JsonObject isonMsg, String PropName, String Propval) {
		try {
			if (isonMsg.has("i-body")) {
				isonMsg.getAsJsonObject("i-body").addProperty(PropName, Propval);
			} else {
				JsonObject i$body = new JsonObject();
				i$body.addProperty(PropName, Propval);
				iHandleArgJson(I_ADDTOJSON, isonMsg, I_BDYTAG, i$body);
			}
		} catch (Exception e) {
			// Eat up
		}
		return isonMsg;
	}
// #BVB00114 Ends

	@SuppressWarnings("rawtypes")
	public LinkedTreeMap getisonMap(JsonObject isonRes) {
		try {
//			Gson gson = new Gson();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			LinkedTreeMap isonMap = gson.fromJson(gson.toJson(isonRes).toString(), LinkedTreeMap.class);
			return isonMap;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public JsonObject str2Json(String Json) {
		JsonParser parser = new JsonParser();
		return parser.parse(Json).getAsJsonObject();
	}

	public JsonArray str2JsonA(String Json) {
		JsonParser parser = new JsonParser();
		return parser.parse(Json).getAsJsonArray();
	}

	public JsonObject iHandleResStat(JsonObject resJson, String Status, String Msg, String eMsg) {
		String istat = I_RESISTAT;
		JsonParser parser = new JsonParser();
		JsonObject jelemIstat = new JsonObject();
		if (I$utils.$iStrFuzzyMatch(Status, I_ERR)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_ERR);
			istat = istat.replaceAll("(?i)#ERR", I_ERRWCD);
			if (I$utils.$iStrBlank(eMsg)) {
				istat = istat.replaceAll("(?i)#ETEXT", Msg);
				logger.debug(Msg);
			} else {
				istat = istat.replaceAll("(?i)#ETEXT", Msg + " - " + eMsg);
				logger.debug(Msg + "::::::::" + eMsg);
			}

			istat = istat.replaceAll("(?i)#WARN", "");
			istat = istat.replaceAll("(?i)#WTEXT", "");
			istat = istat.replaceAll("(?i)#SUCC", "");
			istat = istat.replaceAll("(?i)#STEXT", "");

			jelemIstat = parser.parse(istat).getAsJsonObject();
			;
		} else if (I$utils.$iStrFuzzyMatch(Status, I_WRN)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_WRN);
			istat = istat.replaceAll("(?i)#WARN", I_WRNWCD);
			istat = istat.replaceAll("(?i)#WTEXT", Msg);

			istat = istat.replaceAll("(?i)#ERR", "");
			istat = istat.replaceAll("(?i)#ETEXT", "");
			istat = istat.replaceAll("(?i)#SUCC", "");
			istat = istat.replaceAll("(?i)#STEXT", "");

			jelemIstat = parser.parse(istat).getAsJsonObject();
			logger.debug(Msg);
		} else if (I$utils.$iStrFuzzyMatch(Status, I_SUCC)) {
			istat = istat.replaceAll("(?i)#STATMSG", I_SUCC);
			istat = istat.replaceAll("(?i)#SUCC", I_SUCCWCD);
			istat = istat.replaceAll("(?i)#STEXT", Msg);

			istat = istat.replaceAll("(?i)#ERR", "");
			istat = istat.replaceAll("(?i)#ETEXT", "");
			istat = istat.replaceAll("(?i)#WARN", "");
			istat = istat.replaceAll("(?i)#WTEXT", "");

			jelemIstat = parser.parse(istat).getAsJsonObject();
			logger.debug(Msg);
		}
		resJson.add(I_STATTAG, jelemIstat);
		return resJson;
	}
	
	public JsonObject iHandleResStat(JsonObject fromIsonMsg, JsonObject toIsonMsg) {
		try {
			toIsonMsg.add("i-stat", getiStat(fromIsonMsg));  
		} catch (Exception e) {
			
		}
		return toIsonMsg; 
	}

	public String convertId(JsonObject objectId) {
		String idString = null;

		try {
			ObjectId id = new ObjectId(objectId.get("timestamp").getAsInt(),
					objectId.get("machineIdentifier").getAsInt(), objectId.get("processIdentifier").getAsShort(),
					objectId.get("counter").getAsInt());
			idString = id.toHexString();
		} catch (Exception e) {
			ObjectId id = new ObjectId(objectId.get("timestamp").getAsInt(),
					objectId.get("randomValue1").getAsInt(), objectId.get("randomValue2").getAsShort(),
					objectId.get("counter").getAsInt());
			idString = id.toHexString();
			logger.debug("Failed in convertId: " + e.getMessage());
			
		}
		return idString;
	}

	public JsonObject getObjfromObj(JsonObject inObj, String objName) {
		try {
			return inObj.get(objName).getAsJsonObject();
		} catch (Exception e) {
			return new JsonObject();
		}
	}

	public JsonArray getArrfromObj(JsonObject inObj, String objName) {
		try {
			return inObj.get(objName).getAsJsonArray();
		} catch (Exception e) {
			return new JsonArray();
		}
	}

	public String getStrfromObj(JsonObject inObj, String name) {
		try {
			return inObj.get(name).getAsString();
		} catch (Exception e) {
			return "";
		}
	}

	public String getStrfromObjWithDefault(JsonObject inObj, String name, String defaultValue) {
		try {
			return inObj.get(name).getAsString();
		} catch (Exception e) {
			return defaultValue;
		}
	}

	
	public void setRollBack() {
		setGobalVals("TCLStatus", "R");
	}
	
	public void setCommit() {
		setGobalVals("TCLStatus", "C");
	}
	
	public String getTCLStatus() {
		return getGobalValStr("TCLStatus"); 
	} 
	
	public String getMsgCode(String istatMsg) {
		String istatMsgCode = "";   
		try {
			if(I$utils.$iStrFuzzyMatch(istatMsg, I_SUCC)) {
				istatMsgCode = I_SUCCWCD; 
			}else if(I$utils.$iStrFuzzyMatch(istatMsg, I_WRN)) {
				istatMsgCode = I_WRNWCD; 
			}else if(I$utils.$iStrFuzzyMatch(istatMsg, I_ERR)) {
				istatMsgCode = I_ERRWCD; 
			}
			 			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return istatMsgCode; 
		
	}
	
	public IResManipulator() {
		// Constructor
	}

}
// #00000001 Ends
