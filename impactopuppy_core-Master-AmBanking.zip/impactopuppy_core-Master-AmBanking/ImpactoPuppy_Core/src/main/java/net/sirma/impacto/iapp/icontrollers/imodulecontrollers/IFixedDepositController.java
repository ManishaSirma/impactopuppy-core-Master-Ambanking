/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Baz 		| Mar 25, 2019 | #0000001   | Initial writing
      |0.2.1       | Sindhu     | Jan 11, 2023 | #SRM00022  | Handled code for fetching the FD records that are from digiApp

      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IFixedDepositController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	 private DBController db$Ctrl = new DBController();
	    private Ioutils I$utils = new Ioutils();
	    private IResManipulator i$ResM = new IResManipulator();
	    private static final Logger logger = LoggerFactory.getLogger(IKYCController.class);
	    private IAppMessageHandler iAppMsgHandler = new IAppMessageHandler();
	    JsonObject thread$isonMsg = new JsonObject();
	    JsonObject thread$isonheader = new JsonObject();
	    JsonObject thread$isonMapJson = new JsonObject();
	    JsonObject ibody = new JsonObject();
	    JsonObject icbsbody = new JsonObject();
	    String rCollName = null;
	    String userid = null;

	    public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
	        try {
	            String SOpr = i$ResM.getOpr(isonMsg);
	            String Scr = i$ResM.getScreenID(isonMsg);
	            if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
	                userid = IResManipulator.iloggedUser.get();
	                thread$isonMsg = isonMsg;
	                thread$isonheader = isonheader;
	                thread$isonMapJson = isonMapJson;
	                return createKYCApln(isonMsg, isonheader, isonMapJson);
	            }  if(I$utils.$iStrFuzzyMatch(Scr, "SABFXDPT")) {  //#SRM00022 changes
	                return digiApln(isonMsg, isonheader, isonMapJson);
	            }
	            else {
	                isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
	            }
	        } catch (Exception e) {
	            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
	            e.printStackTrace();
	            return isonMsg;
	        }
	        return null;
	    }

	    public JsonObject createKYCApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
	        JsonObject jBody = new JsonObject();
	        JsonObject jConfig = new JsonObject();
	        String sRef = null;
	        String Coll_Name = "";
	        String DcStatus = null;
	        String ScrCtrlClass = null;
	        String sAppNumber = null;
	        jConfig = i$ResM.getConfig(isonMsg);
	        String srcId = jConfig.get("SrcID").getAsString();
	        jBody = i$ResM.getBody(isonMsg);
	        // remove the _id from the body if it exist
	        try {
	            jBody.remove("_id");
	        } catch (Exception e) {
	            // pass
	        }

	        try {
	            JsonObject jFilter = new JsonObject();

	            try {
	                Coll_Name = isonMapJson.get("COLLNAME").getAsString();
	            } catch (Exception e) {
	                Coll_Name = null;
	            };
	            // #Va000026 Begins
	            sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
	            sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
	            DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
	            ZonedDateTime now = ZonedDateTime.now();
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
	                i$ResM.adddate(Date.from(now.toInstant())).getAsJsonObject());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
	                IResManipulator.iloggedUser.get());

	            String qry$up = "{$and:[{\"applicationId\":\"" + sAppNumber + "\", \"referenceNo\" : {$ne:\"" + sRef +
	                "\"}, \"isCurrVer\":\"Y\"}]}";

	            String srefqry = "{$ne: \"" + sRef + "\"}";
	            JsonObject subqry = new JsonObject();
	            subqry.addProperty("$ne", sRef);
	            jFilter.add("referenceNo", subqry.getAsJsonObject());
	            jFilter.addProperty("applicationId", sAppNumber);
	            // String ftr$qry = "{\"applicationId\":\""+sAppNumber+"\",\"referenceNo\":{$ne:
	            // \""+sRef+"\"}}";
	            JsonObject $update = new JsonObject();
	            $update.addProperty("isCurrVer", "N");
	            db$Ctrl.db$UpdateRow(Coll_Name, $update, jFilter);
	            db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", $update, jFilter);

	            // WOrkflow Status
	            jFilter = new JsonObject();
	            jFilter.addProperty("applicationId", sAppNumber);
	            jFilter.addProperty("referenceNo", sRef);
	            JsonObject Appl$Json = new JsonObject();
	            Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);
	            if(I$utils.$iStrFuzzyMatch(srcId,"TecuDigiApp")) { //#SRM00022 changes
	                jBody.addProperty("digiApp", true);
	            }
	            if (!(Appl$Json != null)) {
	                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
	            } else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
	                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
	            } else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
	                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
	            } else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED")) ||
	                (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
	                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
	            } else {
	                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
	            }

	            jBody.addProperty("referenceNo", sRef);
	            JsonObject Jbdy = new JsonObject();
	            // trigger Workflow
	            if (I$utils.$iStrFuzzyMatch(DcStatus, "COMPLETED")) {

	                updateReferDcStatus(sAppNumber, Coll_Name);
	                //#PKY00025 starts
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", IResManipulator.iloggedUser.get());
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);

	                jFilter.addProperty("applicationId", sAppNumber);
	                jFilter.addProperty("referenceNo", sRef);
	                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");

	                // Fwd the Control to Workflow COntroller.
	                ExecutorService executor = Executors.newFixedThreadPool(1); // creating a pool of threads
	                for (int i = 0; i < 1; i++) {
	                    Runnable worker = new imbpmFromFDFwdThread(isonMsg, isonheader, isonMapJson);
	                    executor.execute(worker); // calling execute method of ExecutorService
	                }
	                //executor.shutdown();
	                //while (!executor.isTerminated()) {
	                //}

	                logger.debug("Finished all threads");
	                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");

	            } else {
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
	                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
	                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
	            } //#PKY00025 ends

	            // Workflow loop End
	        } catch (Exception es) {
	            es.printStackTrace();
	            logger.debug(es.getMessage());
	            jBody.addProperty("referenceNo", sRef);
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);
	            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION REGISTRATION");
	            return isonMsg;
	        }
	    }
	    //#SRM00022 begins
	    public JsonObject digiApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

	        String Coll_Name = "";
	        try {
	            Coll_Name = isonMapJson.get("COLLNAME").getAsString();
	        } catch (Exception e) {
	            Coll_Name = null;
	        }
	        ;
	        JsonObject projection = new JsonObject();
	        JsonObject queryFilter = new JsonObject();
	        queryFilter.addProperty("digiApp", true);
	        JsonArray appl = new JsonArray();
	        projection.addProperty("applicationId", 1);
	        projection.addProperty("createdAt", 1);
	        projection.addProperty("WRK_FLW_STAGE", 1);
	        appl = db$Ctrl.db$GetRows(Coll_Name, queryFilter, projection);
	        isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", appl);
	        return isonMsg;
	    }
	    //#SRM00022 ends
	    // #Va000027 Begins
	    public void updateReferDcStatus(String sAppNumber, String Coll_Name) {
	        // Change the rejected application queue so that application may not appear in
	        // rejected list
	        try {
	            JsonObject jFlter = new JsonObject();
	            jFlter.addProperty("applicationId", sAppNumber);
	            JsonObject Apl$Json = new JsonObject();
	            Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
	            if (Apl$Json != null) {
	                if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
	                    jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
	                    JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
	                    if (task$Json != null) {
	                        task$Json.addProperty("Queue", "ReferDcResubmit");
	                        db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);
	                    }
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	    // #Va000027 Ends
	    // #BVB00033 Ends

	    // Threading for calling IMBPM Controller // #BZ00002 change begins
	    class imbpmFromFDFwdThread implements Runnable {
	        private String message;
	        JsonArray flght$Opr;
	        JsonObject iosnMsg;
	        JsonObject isonMapJson;
	        JsonObject isonheader;

	        public imbpmFromFDFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
	            this.message = "RUN";
	            this.iosnMsg = isonMsg;
	            this.isonMapJson = isonMapJson;
	            this.isonheader = isonheader;
	        }

	        public void run() {
	            logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
	            logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
	            JsonObject i$res = mirrorController(iosnMsg, isonMapJson, isonheader); // call processmessage method that
	            // sleeps the
	            // logger.debug("Thread Result" + i$res.toString());
	            logger.debug(Thread.currentThread().getName() + " (End)"); // prints thread name
	        }
	    }

	    // #Va000029 change begins
	    public JsonObject mirrorController(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

	        try {
	            JsonObject Jbdy = new JsonObject();
	            JsonObject jBody = new JsonObject();
	            jBody = i$ResM.getBody(isonMsg);
	            String sRef = null;
	            String Coll_Name = "";
	            String DcStatus = null;
	            String ScrCtrlClass = null;
	            String sAppNumber = null;

	            JsonObject jFilter = new JsonObject();
	            // Redirecting to Create KYC application workflow
	            sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
	            sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
	            // DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
	            // update the referDc Applicaiton
	            JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP",
	                "{\"SCRID\":" + i$ResM.getScreenID(isonMsg) + "}", "{\"WORKFLOW\":1}");

	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
	                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
	                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
	                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
	                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
	                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
	                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
	            // #DVJ00032 Starts
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId",
	                i$ResM.getBody(isonMsg).get("userId").getAsString());
	            // #DVJ00032 Ends
	            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
	            // Fwd the Control to Workflow COntroller.
	            ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
	            Class < ? > ctrlClass;
	            ctrlClass = Class.forName(ScrCtrlClass);
	            JsonObject result$ = null;
	            Method ctrlFunc = null;
	            ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
	            Object ctrl$Caller = ctrlClass.newInstance();
	            result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
	            if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
	                if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
	                    i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
	                    return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
	                } else {
	                    i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
	                    return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
	                }
	            } else {

	                i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
	                return isonMsg;
	            }

	        } catch (Exception e) {
	            return null;
	        }
	    }

	public IFixedDepositController() {
		// Cons
	}
}
// #0000001 Ends