/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by 	| Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |3.2.6	   | Syed 			| Jan 29, 2020 | #MAQ00055   | Initial writing 
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.google.gson.JsonArray;
import com.itextpdf.text.pdf.codec.Base64;

public class IExcelCreate {
	
	public String createExcel(JsonArray jProjection, JsonArray jData) {
		String excelBase64Str = null;
	    try
	    {
//	    	String jProjection = "[{'fieldName':'userId','displayName':'User Id'},{'fieldName':'EmpMail','displayName':'Email Id'},{'fieldName':'MobNum','displayName':'Mobile No'},{'fieldName':'authorizedOnSrvDate','displayName':'Authorized On'},{'fieldName':'authorizer','displayName':'Authorizer'},{'fieldName':'errorMsg','displayName':'Error Msg'},{'fieldName':'initiatedOnSrvDate','displayName':'Initiated On'},{'fieldName':'initiator','displayName':'Initiator'}]";
//	    	String jData = "[{'userId':'VINODP','EmpMail':'vinod.pawar+11@sirmaindia.com','MobNum':'8806427043','authorizedOnSrvDate':'2019-05-31T05:05:00.000Z','authorizer':'MOTOE3','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'May 31, 2019 10:01:00 AM'},{'userId':'AP','EmpMail':'vinod.pawar+101@sirmaindia.com','MobNum':'8806427047','authorizedOnSrvDate':'2019-04-16T08:52:00.000Z','authorizer':'NARESH_AUTHORISER','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 16, 2019 2:17:00 PM'},{'userId':'GNI4007','EmpMail':'ganesh.niyogi@sirmaindia.com','MobNum':'9980835282','authorizedOnSrvDate':'2019-02-14T07:12:00.000Z','authorizer':'AP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 14, 2019 12:25:00 PM'},{'userId':'GNI4007AU','EmpMail':'ganeshniyogi@gmail.com','MobNum':'9980835282','authorizedOnSrvDate':'2019-02-14T07:35:00.000Z','authorizer':'AP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 14, 2019 1:05:00 PM'},{'userId':'NARESH','EmpMail':'naresh.kamalakannan+006@sirmaindia.com','MobNum':'770867936767','authorizedOnSrvDate':'2019-04-10T06:51:00.000Z','authorizer':'NARESH_AUTHORISER','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 10, 2019 12:21:00 PM'},{'userId':'555555','EmpMail':'jins.kurian+003@sirmaindia.com','MobNum':'7448594753','authorizedOnSrvDate':'2019-04-09T15:13:00.000Z','authorizer':'666666','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 9, 2019 8:41:00 PM'},{'userId':'NARESH_AUTH','EmpMail':'naresh.kamalakannan@sirmaindia.com','MobNum':'7708679396','authorizedOnSrvDate':'2019-02-14T09:14:00.000Z','authorizer':'AP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 14, 2019 2:42:00 PM'},{'userId':'IMPACTO123','EmpMail':'bhuvnesh.bhandari@sirmaindia.com','MobNum':'9760338383','authorizedOnSrvDate':'2019-02-14T10:34:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 14, 2019 3:54:00 PM'},{'userId':'IMPACTO1234','EmpMail':'vinod.pawar@sirmaindia.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-14T10:35:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 14, 2019 4:03:00 PM'},{'userId':'666666','EmpMail':'jins.kurian9@sirmaindi5.com','MobNum':'7448594755','authorizedOnSrvDate':'2019-04-12T10:52:00.000Z','authorizer':'JIN_AUT','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 3, 2019 7:13:00 PM'},{'userId':'GNITEST001','EmpMail':'ganeshniyogi@gmail.com','MobNum':'9980835282','authorizedOnSrvDate':'2019-02-14T13:19:00.000Z','authorizer':'GNI4007AU','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 14, 2019 5:56:00 PM'},{'userId':'GNITEST002','EmpMail':'ganeshniyogi8888@gmail.com','MobNum':'9982335282','authorizedOnSrvDate':'2019-03-20T10:38:00.000Z','authorizer':'GNI4007AU','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Mar 20, 2019 4:07:00 PM'},{'userId':'B2U1','EmpMail':'vinod.pawar@sirmaindia.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-15T11:02:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 4:30:00 PM'},{'userId':'B2U2','EmpMail':'naresh.kamalakannan@sirmaindia.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-15T11:03:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 4:30:00 PM'},{'userId':'898989','EmpMail':'jins.kurian@sirmaindia.com','MobNum':'7448594754','authorizedOnSrvDate':'2019-02-15T11:14:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 2:37:00 PM'},{'userId':'USER1010','EmpMail':'pawaev40@gmail.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-15T11:46:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 5:14:00 PM'},{'userId':'USER1020','EmpMail':'vinodpawar311095@gmail.com','MobNum':'8008438176','authorizedOnSrvDate':'2019-02-15T11:51:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 5:19:00 PM'},{'userId':'NARESH_AUTH1','EmpMail':'naresh.kamalakannan@sirmaindia.com','MobNum':'7708679396','authorizedOnSrvDate':'2019-02-15T12:00:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 5:26:00 PM'},{'userId':'TES_S004','EmpMail':'hkjlk@gmail.com','MobNum':'7448594754','authorizedOnSrvDate':'2019-02-17T10:58:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 16, 2019 3:27:00 PM'},{'userId':'TES_S003','EmpMail':'jins.kurian@sirmaindia.com','MobNum':'7448594754','authorizedOnSrvDate':'2019-02-15T14:46:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 15, 2019 2:41:00 PM'},{'userId':'PAVAN_KALYAN','EmpMail':'vinod.pawar+001@sirmaindia.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-19T10:25:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 19, 2019 3:46:00 PM'},{'userId':'ALLU_ARJUN','EmpMail':'vinod.pawar+002@sirmaindia.com','MobNum':'880642702','authorizedOnSrvDate':'2019-03-23T04:52:00.000Z','authorizer':'VINOD_APPROVER','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Mar 23, 2019 10:17:00 AM'},{'userId':'CHIRANJIVI','EmpMail':'vinod.pawar+001@sirmaindia.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-19T10:25:00.000Z','authorizer':'VINODP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 19, 2019 3:47:00 PM'},{'userId':'VIJAY','EmpMail':'vijaybabu.batta@sirmaindia.com','MobNum':'9008066009','authorizedOnSrvDate':'2019-02-16T10:32:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 16, 2019 3:57:00 PM'},{'userId':'PAUL123','EmpMail':'debayan.paul@sirmaindia.com','MobNum':'8787768870','authorizedOnSrvDate':'2019-02-16T12:40:00.000Z','authorizer':'555555','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 16, 2019 6:00:00 PM'},{'userId':'DON','EmpMail':'vinod.pawar+001@sirmaindia.com','MobNum':'8806427040','authorizedOnSrvDate':'2019-02-19T09:25:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 19, 2019 2:52:00 PM'},{'userId':'DON_2','EmpMail':'vinod.pawar+001@sirmaindia.com','MobNum':'8880081760','authorizedOnSrvDate':'2019-02-20T09:33:00.000Z','authorizer':'AP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 20, 2019 3:03:00 PM'},{'userId':'MODI','EmpMail':'vinod.pawar+001@sirmaindia.com','MobNum':'8788430030','authorizedOnSrvDate':'2019-02-20T06:22:00.000Z','authorizer':'AP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 20, 2019 11:51:00 AM'},{'userId':'NARESH_AUTH2','EmpMail':'naresh.kamalakannan+001@sirmaindia.com','MobNum':'3123','authorizedOnSrvDate':'2019-02-20T05:46:00.000Z','authorizer':'555555','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 20, 2019 11:09:00 AM'},{'userId':'TEST_USER','EmpMail':'naresh.kamalakannan+001@sirmaindia.com','MobNum':'7708679396','authorizedOnSrvDate':'2019-02-20T07:47:00.000Z','authorizer':'NARESH_AUTH2','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 20, 2019 1:15:00 PM'},{'userId':'MEGA','EmpMail':'naresh.kamalakannan+002@sirmaindia.com','MobNum':'7708679396','authorizedOnSrvDate':'2019-02-21T11:19:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 21, 2019 4:48:00 PM'},{'userId':'MEGHNA','EmpMail':'naresh.kamalakannan@sirmaindia.com','MobNum':'9987834499','authorizedOnSrvDate':'2019-02-21T11:40:00.000Z','authorizer':'666666','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 21, 2019 5:08:00 PM'},{'userId':'MEGA001','EmpMail':'meghana.ms+12@sirmaindia.com','MobNum':'770867933','authorizedOnSrvDate':'2019-03-26T06:11:00.000Z','authorizer':'VINOD_APPROVER','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Mar 26, 2019 11:41:00 AM'},{'userId':'NARESH_APPROVER','EmpMail':'naresh.kamalakannan+004@gmail.com','MobNum':'770867938989','authorizedOnSrvDate':'2019-04-10T06:47:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 10, 2019 12:16:00 PM'},{'userId':'DUMMY','EmpMail':'nareshk0106@gmail.com','MobNum':'576576','authorizedOnSrvDate':'2019-02-22T12:00:00.000Z','authorizer':'555555','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 22, 2019 5:27:00 PM'},{'userId':'NARESH_AUTHORISER','EmpMail':'naresh.kamalakannan+009@sirmaindia.com','MobNum':'73281378789','authorizedOnSrvDate':'2019-04-10T06:50:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 10, 2019 12:19:00 PM'},{'userId':'DUMMY_TEST1','EmpMail':'naresh.kamalakannan+001@sirmaindia.com','MobNum':'77086231231','authorizedOnSrvDate':'2019-02-23T06:13:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 23, 2019 11:21:00 AM'},{'userId':'DUMMY_TEST3','EmpMail':'naresh.kamalakannan+001@sirmaindia.com','MobNum':'45676576','authorizedOnSrvDate':'2019-02-25T07:55:00.000Z','authorizer':'555555','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 25, 2019 1:22:00 PM'},{'userId':'DUMMY_TEST4','EmpMail':'naresh.kamalakannan+005@sirmaindia.com','MobNum':'54656','authorizedOnSrvDate':'2019-02-25T10:30:00.000Z','authorizer':'666666','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 25, 2019 3:59:00 PM'},{'userId':'AAAA','EmpMail':'bhuvi.chiks@gmail.com','MobNum':'7895333334','authorizedOnSrvDate':'2019-02-25T10:36:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 25, 2019 4:06:00 PM'},{'userId':'KEDARNATH','EmpMail':'vinod.pawar+0022@sirmaindia.com','MobNum':'1233422334','authorizedOnSrvDate':'2019-02-26T09:23:00.000Z','authorizer':'555555','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 26, 2019 2:52:00 PM'},{'userId':'AAA','EmpMail':'bhuvib08@gmail.com','MobNum':'9760338383','authorizedOnSrvDate':'2019-02-25T11:29:00.000Z','authorizer':'NARESH','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 25, 2019 4:58:00 PM'},{'userId':'MLV','EmpMail':'venkataraman.ml@sirmaindia.com','MobNum':'9008423388','authorizedOnSrvDate':'2019-04-25T10:37:00.000Z','authorizer':'HARSH_AU','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Apr 25, 2019 11:30:00 AM'},{'userId':'MLVAU','EmpMail':'venkataraman.ml+001@sirmaindia.com','MobNum':'8277025431','authorizedOnSrvDate':'2019-03-30T08:56:00.000Z','authorizer':'NARESH_APPROVER','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Mar 30, 2019 2:24:00 PM'},{'userId':'DUMMY3','EmpMail':'lincutest9@gmail.com','MobNum':'8765876','authorizedOnSrvDate':'2019-02-28T10:52:00.000Z','authorizer':'NARESH_APPROVER','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 28, 2019 4:18:00 PM'},{'userId':'ABCD','EmpMail':'vinod.pawar+06@sirmaindia.com','MobNum':'1234567891','authorizedOnSrvDate':'2019-02-28T09:46:00.000Z','authorizer':'666666','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 28, 2019 3:15:00 PM'},{'userId':'DCBA','EmpMail':'vinod.pawar+012@sirmaindia.com','MobNum':'1324289234','authorizedOnSrvDate':'2019-02-28T11:55:00.000Z','authorizer':'AP','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Feb 28, 2019 5:23:00 PM'},{'userId':'PAUL','EmpMail':'debayan.paul@sirmaindia.com','MobNum':'8765678987','authorizedOnSrvDate':'2019-08-29T16:59:00.000Z','authorizer':'MAQS','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Aug 29, 2019 10:27:00 PM'},{'userId':'AMB_HAS','EmpMail':'mmtakked@gmail.com','MobNum':'9876567898','authorizedOnSrvDate':'2019-07-02T04:35:00.000Z','authorizer':'MOTOE3','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Mar 7, 2019 1:34:00 PM'},{'userId':'AMB_RK','EmpMail':'radhakrishnabca@gmail.com','MobNum':'96764474413','authorizedOnSrvDate':'2019-08-13T09:31:00.000Z','authorizer':'MOTOE3','errorMsg':'Record Sucessfully Authorized','initiatedOnSrvDate':'Aug 13, 2019 3:00:00 PM'}]";

	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        //create a new excel workbook
	        HSSFWorkbook wb = new HSSFWorkbook();
	        //create a new excel sheet in the work book
	        HSSFSheet sheet = wb.createSheet("Sheet1");
	        
	        HSSFRow row=   sheet.createRow(0);
	        HSSFCellStyle style = wb.createCellStyle();
	        style.setWrapText(true);
	        row.setRowStyle(style);		        
	        

			for (int i = 0; i < jProjection.size(); i++) {
				String displayName = jProjection.get(i).getAsJsonObject().get("displayName").getAsString();
				row.createCell(i).setCellValue(displayName);
			}
	        
	        for (int i = 1; i <= jData.size(); i++) {
	        	row = sheet.createRow(i);
	        	for (int j = 0; j < jProjection.size(); j++) {
					String fieldName = jProjection.get(j).getAsJsonObject().get("fieldName").getAsString();
					String fieldValue;
					try {
					fieldValue = jData.get(i).getAsJsonObject().get(fieldName).getAsString();
					} catch(Exception e) {
						fieldValue = "";
					}
					row.createCell(j).setCellValue(fieldValue);
	        	}
			} 
	        
	        //writing the excel to outstream
	        wb.write(outputStream);
	        //encoding the excel as Base64 encoded string
	        excelBase64Str = Base64.encodeBytes(outputStream.toByteArray());
	        
	        System.out.println(excelBase64Str);
	        
	    }catch(IOException ioe){
	        ioe.printStackTrace();
	    }
	    return excelBase64Str;

	}

	public IExcelCreate() {
		//super();
		// TODO Auto-generated constructor stub
	}

}