/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date          | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Valla 		| Jan 28, 2019  | #00000001   | Initial writing
      |0.1 Beta    | Valla 		| Feb 21, 2019  | #00000002   |for null check the Queue Access
      |0.1 Beta    | Valla 		| Feb 22, 2019  | #00000003   | CBS ADAPTER missing fields additions
      |0.1 Beta    | Valla 		| Feb 23, 2019  | #00000004   | CBS ADAPTER Country Code for TT
      |0.1 Beta    | Baz 		| Feb 25, 2019  | #00000005   | CBS ADAPTER ocrDetails name change
      |0.1 Beta    | Baz 		| Mar 08, 2019  | #00000006   | Fixes for defect ID 285
      |0.1 Beta    | Baz 		| Mar 13, 2019  | #00000007   | Fixes for defect ID 286
      |0.1 Beta    | Baz 		| Mar 14, 2019  | #00000007   | Ambassador Application Retrieval functionalities
      |0.1 Beta    | Baz 		| Mar 16, 2019  | #00000008   |Negative Flow Related Changes
      |0.1 Beta    | Baz 		| Mar 22, 2019  | #00000009   |Last 10 Pending Records for the Ambassador
      |0.1 Beta    | Baz 		| Mar 22, 2019  | #00000010   |Fetch Task Change
      |0.1 Beta    | Vijay 		| Mar 11, 2019  | #BVB00090   | Risk Profilling Datasheet creation
      |0.1 Beta    | Baz 		| Mar 23, 2019  | #00000011   |Changed the Response and Istat
      |0.1 Beta    | Baz 		| Mar 26, 2019  | #00000012   |IsCurrVer changes and Removed -Id from mongo query
      |0.1 Beta    | Baz 		| Mar 28, 2019  | #00000013   |Logging methtod added
      |0.1 Beta    | Baz 		| Mar 30, 2019  | #00000014   |DEDUPE and added for Account creation
      |0.1 Beta    | Baz 		| Apr 04, 2019  | #00000015   |Added Total Numnber of Records for the referred application and Incomplete applications
      |0.1 Beta    | Baz 		| Apr 10, 2019  | #00000016   |Defect 400 fixes and added ModelType to RiskProfile
      |0.1 Beta    | Baz 		| Apr 25, 2019  | #00000017   |Lead creation Changes
      |0.1 Beta    | Baz 		| Apr 30, 2019  | #00000018   |Acquire and release Changes
      !0.1 Beta    | Baz 		| May 05, 2019  | #00000019   |Fecth Tasks for Role Query changed Spelling mistake rectified
      !0.1 Beta    | Baz 		| May 06, 2019  | #00000020   |Role has rights for processing the tasks is changed
      !0.1 Beta    | Baz 		| May 08, 2019  | #00000021   |Role has rights for Fetching  tasks is changed
      !0.1 Beta    | Baz 		| May 09, 2019  | #00000022   |I-State message changes for Acquire Task
      !0.1 Beta    | Baz 		| May 17, 2019  | #00000023   |added felxcube fields for Customer creation
      !0.1 Beta    | Baz 		| May 17, 2019  | #00000024   |changed remarks data type
      !0.1 Beta    | Baz 		| May 21, 2019  | #00000025   |Included cif and iLeadSource for Leads
      !0.1 Beta    | Baz 		| May 21, 2019  | #00000026   |Retry changes
      !0.1 Beta    | Baz 		| May 28, 2019  | #00000027   |Document Tracker issue fix
      !0.1 Beta    | Baz 		| May 29, 2019  | #00000028   |Threading made to Sync for PostFlight Oprs
      !0.1 Beta    | Baz 		| May 31, 2019  | #00000029   |CUNA and CLico changes
      !0.1 Beta    | Baz 		| May 31, 2019  | #00000030   |Re-KYC cif pulling change
      !0.3.13      | Vijay 		| Jun 05, 2019  | #BVB00161   |Advance filter changes
      !0.3.13      | Vijay 		| Jun 05, 2019  | #BVB00162   |unqCommID spelling correction
      !0.1 Beta    | Baz 		| Jun 05, 2019  | #00000031   |Review Task issue fix
      !0.3.14      | Vijay 		| Jun 10, 2019  | #BVB00163   |Cuna Clico Working fixes
      !0.3.14      | Baz 		| Jun 11, 2019  | #00000033   |Release Task Func
      !0.3.14      | Vijay 		| Jun 28, 2019  | #BVB00174   |New CIF request changes
      !0.3.14      | Baz        | Jun 29, 2019  | #00000034   |Document Tracker Update
	  !0.3.15      | RK         | Jul 06, 2019  | #00000035   |Document Tracker version number fix
	  !0.3.15.298  | Baz        | July 6, 2019  | #00000035   |Document Tracker Version Number Issue Fixed
	  !0.3.15.298  | Baz        | July 8, 2019  | #00000036   |Release Lock Issue Fixed.
      !0.3.17      | Vijay      | July 18, 2019 | #BVB00185   | Re-KYC Fixes and few bug fixes in KYC
      !0.3.14      | Baz 		| July 17, 2019 | #00000036   |New SDN changes
      !0.3.14      | Baz 		| July 18, 2019 | #00000037   |FetchHeldTasks with Pagination
      !0.3.14      | Baz 		| July 22, 2019 | #00000038   |PersonalInfo an contactDetils inclusion to idocTracker
      !0.3.14      | Baz 		| July 24, 2019 | #00000039   |Logger change to track the Task flow
      !0.3.14      | Baz 		| July 29, 2019 | #00000040   |Initiator as approver or Authorizer validations
      !0.3.14      | Baz 		| July 29, 2019 | #00000041   |iDocTracker Changes
      !0.3.14      | Baz 		| Aug 03,  2019 | #00000042   |KYCM related chages
      !0.3.17      | Vijay 		| Aug 06,  2019 | #BVB00193   | ReKYC New Flow 
      !0.3.17      | Baz 		| Aug 07,  2019 | #00000043   |iDocTracker for ReKYC changes
      !0.3.17      | Vijay 		| Aug 07,  2019 | #BVB00195   | Dual Citizen Ship check and Fixes 
	  !0.3.17      | Vijay 		| Aug 09,  2019 | #BVB00196   | FATCA FCUBS Changes
	  !0.3.17      | Vijay 		| Aug 13,  2019 | #BVB00198   | Naming Convention Change
	  !0.3.17      | Baz 		| Aug 16,  2019 | #00000044   | Revamp of Retry for Account and ReKYC
	  !0.3.17      | Baz 		| Aug 17,  2019 | #00000046   | cbsRetry Revamping for ErrorMsg
	  !0.3.17      | Bhuvi 		| Aug 19,  2019 | #BHUVI001   | sorting changes
	  !0.3.17      | Baz 		| Aug 28,  2019 | #00000047   | Notification Sending Code revamp, Date Format Change  
	  !0.3.17      | Baz 		| Aug 29,  2019 | #00000048   | Re SDN Scan for ReKYC fixes and EDD Request Creation Changes
	  !0.3.17      | Baz 		| Aug 31,  2019 | #00000049   | ReKYC Signature and Image Upload
	  !0.3.17      | Baz 		| Aug 31,  2019 | #00000050   | RecordState change for O_OPEN
	  !0.4.2       | Vijay 		| Sep 02,  2019 | #BVB00205   | Restricting the Random generation to 3 digit only
	  !0.4.2       | Vijay 		| Sep 05,  2019 | #BVB00207   | ReKYC Extra Feilds Addition
	  !0.4.2       | Baz 		| Sep 05,  2019 | #00000052   | Account Creation Retry iState Changes
	  !1.0.0       | Vijay 		| Sep 06,  2019 | #BVB00209   | New fields Addition
	  !1.0.0       | Baz 		| Sep 17,  2019 | #00000053   | C_ClOSED addition for ReKYC-Lite
	  |2.3.0.3     | Vijay 		| Sep 18,  2019 | #BVB00211   | Adding Missing fields in the request
	  |3.1.1       | Vijay 		| Oct 16,  2019 | #BVB00214   | Bug 920 --Minor Guardian Details Population
	  |3.1.2       | Vijay 		| Nov 19,  2019 | #BVB00216   | Adding Employee No to the next layers
	  |4.0.2.469   | Pruthvi 	| Feb 04,  2021 | #YPR00046   | Adding validatons SDN,RiskPrf operations
	  |0.1 Beta    | Pruthvi 	| Feb 22,  2021 | #YPR00052   | Added Enrichment operation in Verify Stage
	  |4.0.3       | Devraj 	| Feb 19,  2021 | #DVJ00032   | Fixed application display issue from TECU
	  |4.0.4       | Devraj 	| Mar 06,  2021 | #DVJ00039   | Added applicantName field in KYC workflow
	  |4.0.4       | Pruthvi 	| Mar 16,  2021 | #YPR00060   | Added Enrichment validation in VERIFY and APPROVE Stage
	  |4.0.5       | Devraj 	| Mar 12,  2021 | #DVJ00040   | Added final workflow as ACTIVATED
	  |4.0.6       | Devraj 	| Mar 16,  2021 | #DVJ00041   | Added workflow stages as InitialDeposit and OSV
	  |4.0.7       | Devraj 	| Mar 16,  2021 | #DVJ00042   | Added payment status field
	  |4.0.8       | Devraj 	| Mar 18,  2021 | #DVJ00044   | Adding the service of Smartphone SMS verification in INIT stage
	  |4.0.9       | Devraj 	| Mar 18,  2021 | #DVJ00046   | Removed the same Initiator and Authorizer validation
	  |4.0.10      | Devraj 	| Mar 18,  2021 | #DVJ00047   | Added the final COMPLETED stage in workflow
	  |4.1.0       | Devraj 	| Mar 19,  2021 | #DVJ00048   | CBS stat data is updated in db
	  |4.1.1       | Devraj 	| Mar 22,  2021 | #DVJ00049   | Added missing fields validation of flexcube issue
	  |4.1.1       | Pruthvi 	| Mar 22,  2021 | #YPR00062   | Added CBS Cash Deposit to memver account
	  |4.1.2       | Devraj 	| Apr 02,  2021 | #DVJ00053   | Added the verificationMode field in KYM Summary
	  |0.1 Beta    | Pruthvi 	| Apr 07,  2021 | #YPR00067   | Added changes for deDupe search fields
	  |0.3 Beta    | Pruthvi 	| Apr 08,  2021 | #YPR00068   | Added deeplink notification into preflightops
	  |0.3 Beta    | Pruthvi 	| Apr 14,  2021 | #YPR00072   | Added deposit reminder notification into preflightops
	  |0.3 Beta    | Pruthvi 	| Apr 15,  2021 | #YPR00074   | Added Clico,Cuna notifications changes
	  |0.3 Beta    | Piyush 	| Apr 27,  2021 | #PM000100   | Added Changes for CLICO and EDD
	  |0.3 Beta    | Pruthvi 	| Apr 30,  2021 | #YPR00076   | Added Clico,Cuna notifications changes to approve Stage
	  |0.3 Beta    | Piyush 	| May 02,  2021 | #PM000101   | Added Changes for Nominee and Beneficiary
	  |0.3 Beta    | Pruthvi 	| May 03,  2021 | #YPR00077   | Added ContactDetails Object in Enrichmnet stage
	  |2.8 Beta    | Pappu      | May 24,  2021 | #PKY00012   | Added branch for WorkFlowId
	  |0.4 Beta    | Piyush 	| May 24,  2021 | #PM000102   | Added Changes to change mapping for UDF details
	  |0.4 Beta    | Piyush 	| Jun 16,  2021 | #PM000103   | Added Changes to include fixes for Bug 937(Recommender TECU Bahalf Flag)
	  |0.5 Beta    | Pruthvi 	| Jun 23,  2021 | #YPR00093   | Added Changes for Term Deposit
	  |0.4 Beta    | Pappu      | Jun 22,  2021 | #PKY00016   | Added condition for Fixed deposit SMS_TRIGGER
	  |0.4 Beta    | Pappu      | Jun 24,  2021 | #PKY00019   | Added condition for Enrichment in Approve stage for fixed deposit and LOAN
	  |0.4 Beta    | Pappu      | Jun 30,  2021 | #PKY00020   | Addded changes for Leads call 
	  |0.4 Beta    | Pappu      | Jul 02,  2021 | #PKY00021   | Added fixed deposit cbsDetails
	  |0.4 Beta    | Pappu      | Jul 05,  2021 | #PKY00022   | handled applicantName, PaymentStatus, and verificationMode for fixed deposit and CIF.
	  |0.4 Beta    | Piyush 	| Jul 02,  2021 | #PM000104   | Added Changes to include fixes for Bug 960(Nominee Relationship)
	  |0.4 Beta    | Pappu      | Jul 14,  2021 | #PKY00023   | Added changes of retry for fixed deposit and Loan
      |0.4 Beta    | Piyush 	| Jul 20,  2021 | #PM000105   | Added Changes to include fixes for Bug 980 and 981(Joint Holders)
      |0.4 Beta    | Pappu      | Jul 20,  2021 | #PKY00024   | Added changes for userId
      |0.4 Beta    | Pappu      | Jul 26,  2021 | #PKY00028   | Added SOA Operation in loan workFlow
      |0.4 Beta    | Pappu      | Jul 28,  2021 | #PKY00030   | Added Collateral Operation in loan workFlow
      |0.4 Beta    | Pappu      | Jul 30,  2021 | #PKY00031   | handle Enrichment for SOA, COLLATERAL AND CHERRYPICKS
      |0.4 Beta    | Pappu      | Jul 30,  2021 | #PKY00032   | handle applicationId in unqCommID 
      |0.4 Beta    | Pappu      | Jul 30,  2021 | #PKY00033   | Added Enrichment for cherrypicks workflow
      |0.4 Beta    | Samadhan   | Aug 03,  2021 | #SRP00009   | Added Enrichment for FIP workflow changes
      |0.4 Beta    | Pappu  	| Aug 04,  2021 | #PKY00029   | Added Changes for Enrichment (ReferRisk and ReferCompilance)
      |0.4 Beta    | Pappu  	| Aug 05,  2021 | #PKY00037   | handled first time application creation failed
      |0.4 Beta    | Pappu      | Aug 13,  2021 | #PKY00039   | handled enrichment for tatil insurance
      |0.4 Beta    | Sushmita   | Aug 18,  2021 | #SKP00002   | Written code for FD Notification template triggering from controljson
      |0.4 Beta    | Pappu      | Aug 20,  2021 | #PKY00043   | handled cbsDetails msg for for Fcip, fip, fcip and lincu workflow
      |0.4 Beta    | Samadhan   | Aug 24,  2021 | #SRP00014   | Added code for map sms and Email triggered for FCIP
      |0.4 Beta    | Pappu      | Sep 01,  2021 | #PKY00045   | handled sendgrid API
      |0.4 Beta    | Samadhan   | sep 08,  2021 | #SRP00021   | Added Code for CIF Template
      |0.4 Beta    | Pappu      | Sep 14,  2021 | #PKY00046   | handled success notification for loan and LOc
      |4.4         | Samadhan   | Sep 17,2021   | #SRP00023   | handled Varification pending notification for Loan
      |4.4         | Tarun      | Sep 23,2021   | #TKS00006   | handled Verification for same officer cannot approve to next stage.
      |4.4         | Samadhan   | Oct 05, 2021  | #SRP00028   | handled success notification for Lincu Application.
      |4.4         | Pappu      | Oct 07, 2021  | #PKY00052   | Handled Fip appln success notification 
      |4.4         | Pappu      | Oct 13, 2021  | #PKY00053   | Handled Verify and appovedby projection in loan summary request
      |4.4         | Pappu      | Oct 14, 2021  | #PKY00054   | fixed issue in Verification for same officer cannot approve to next stage.
	  |4.4         | Piyush     | Oct 23, 2021  | #PM000106   | LOAN and TD/FD Flexcube Mapping Changes
	  |4.4         | Piyush     | Oct 26, 2021  | #PM000107   | TD Restricting null object
	  |4.4         | Piyush     | Oct 27, 2021  | #PM000108   | Handled dob, passport Issue and expiry date.
	  |4.4         | Pappu      | Oct 28, 2021  | #PKY00055   | improved Cbs Lead creation flexcube call
	  |4.4         | Piyush     | Oct 28, 2021  | #PM000109   | Handled FD Beneficiaries
	  |4.4         | Pappu      | oct 29, 2021  | #PKY00056   | improved Fd flexcube call issue
	  |4.4         | Pappu      | oct 02, 2021  | #PKY00057   | handling to send pending appln review notifician to tecu officier for Lincu, FD, and Health plan Module
	  |4.4         | Pappu      | oct 03, 2021  | #PKY00058   | handling to send pending appln review notifician to insurance Team for FIP and FCIP module
	  |4.4         | Pappu      | nov 12, 2021  | #PKY00060   | handled tatil appln success notification
	  |4.4         | Piyush     | Nov 12, 2021  | #PM000110   | Handled Bug 1208
	  |4.4         | Sushmita   | N0v 30, 2021  | #SKP00003   | Added code for Hold Application
	  |4.4         | Sushmita   | Dec 10, 2021  | #SKP00004   | Added LOC Operation in Loan Workflow
	  |4.4         | Pappu      | Dec 28, 2021  | #PKY00069   | Added sdn scanning for member, nominee, spouse, joint partner, cuna ben and clico ben
	  |4.4         | Piyush     | Jan 17, 2022  | #PM000111   | Handled Bug 1580, Capturing UDF Related Info
	  |4.4         | Samadhan   | Jan 31, 2022  | #SRP00047   | Handled ApprovedAt field for FD.
	  |4.4 		   | Manikanta  | Feb 18, 2022  | #MVT00036   | Added code to update remarks in tatil reports
	  |4.4         | Samadhan   | Mar 11, 2022  | #SRP00052   | Handled code for update Remark for Terminte Applications
      |0.4 Beta    | Piyush     | Jan 20,  2022 | #PM000106   | Added Changes as part of Bug 1679
	  |0.4 Beta    | Samadhan   | Mar 10,  2022 | #SRP00051   | Added Code for Sdn scan, Risk Profiling, Dedupe check for ScanDetails
	  |0.4         | Samadhan   | may 23, 2022  | #SRP00067   | Handled Code for moreinfo fields in Enrichment for KYM workflow
	  |0.4 		   | Manikanta  | Sep 30, 2022  | #MVT00076	  | Handles code for default values in member on boarding
	  |0.4		   | Manikanta  | Nov 21, 2022  | #MVT00091   | Added code to handle branch and applicant name in cash deposit report
	  |0.4		   | Manikanta  | Jan 06, 2023  | #MVT00096	  | Added code to send payrol notifications
	  |0.4		   | Manikanta  | Jan 13, 2023	| #MVT00097   | Added code to update initial deposit amount
	  |0.4		   | Piyush     | Jan 24, 2023	| #PM000107   | Added code to handle birth certificate pin no
	  |0.4		   | Manikanta  | Jan 27, 2023  | #MVT00101   | Added code for no data birth certificate pin no
	  |0.4		   | Manikanta  | Feb 02, 2023  | #MVT00103   | Added code to handle unique communication id error
	  |0.4		   | Manikanta  | Feb 09, 2023  | #MVT00105   | Added code to handle cif retry for kyc
	  |0.4		   | Manikanta  | Apr 14, 2023  | #MVT00110   | Added code to handle key tecu on behalf in flexcube
	  |0.4		   | Manikanta  | May 03, 2023	| #MVT00111   | Added code to handle nominee and joint partner exceptions
	  |0.4		   | Manikanta  | May 17, 2023  | #MVT00116   | Added code to handle nominee remarks null data
	  |0.4		   | Sindhu     | May 19, 2023  | #SRM00036   | Added code to handle new workflow stages
	  |0.4		   | Sindhu     | May 26, 2023  | #SRM00037   | Added code to handle securityType for shares and FD  
	  |0.4		   | Madhura    | Jun 05, 2023  | #MSA00018   | Added code to handle contact details of references
	  |0.4		   | Sindhu     | Jun 20, 2023  | #SRM00044   | Handled code for creating account for CASA150
	  |0.4 		   | Manikanta  | Aug 08, 2023  | #MVT00134   | Added code for to for casa 150 and settlement instruction issues
	  |0.4		   | Sindhu     | Sep 12, 2023  | #SRM00058   | Handled code for updating IBM process as 'NA' after CIF completion
	  |0.4		   | Sindhu     | Sep 27, 2023  | #SRM00060   | Added code for updating the CBS CIF details in the respective collections
	  |0.4		   | Manikanta  | Oct 16, 2023  | #MVT00138	  | Added code for settlement instructions hitting flexcube
	  |0.4		   | Sindhu     | Oct 17, 2023  | #SRM00064   | Added code for verifying queue access while acquiring a particular application
 	  |0.4		   | Sindhu     | Oct 19, 2023  | #SRM00065   | Added code for loan authorization
	  |0.4		   | Manikanta  | Nov 07, 2023  | #MVT00150   | Added code for Enrichment Queue Access
	  |0.4 		   | Manikanta  | Dec 19, 2023  | #MVT00155   | Added code to handle transunion
	  |0.4 		   | Manikanta  | Dec 21, 2023  | #MVT00156   | Added code to handle settlement instructions
	  |0.4 		   | Srikanth   | Feb 19, 2024  | #SRI00034   | Added code to handle the loanCategory to add in the Data base 
	  |0.4 		   | Srikanth   | Feb 19, 2024  | #SRI00035   | Added code to handle the projections 
 -----------------------------------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mongodb.BasicDBObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.OtpController;
import net.sirma.impacto.iapp.ihelpers.IPDFPopulatorKeyMapping;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IMbpmContorller {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil Im$utils = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private IExtWSLauncher i$EWslancher = new IExtWSLauncher();
	private OtpController i$otpC = new OtpController();
	private IEmailService i$Email = new IEmailService();
	private ISmsService i$SmsSrvc = new ISmsService();
	private IWebSearchController i$webSrvc = new IWebSearchController();
	private IFoldersController i$foldersctrl = new IFoldersController();
	private static final Logger logger = LoggerFactory.getLogger(IMbpmContorller.class); // Nye- Change Class Name
	private GenericAppController i$genAppCtrl = new GenericAppController();
	private IFuncSrvcController srvcFunction = new IFuncSrvcController();
	private IPDFPopulatorKeyMapping i$pdfKeyMap = new IPDFPopulatorKeyMapping();
	private ICoreSysReqFwderController I$coreSys = new ICoreSysReqFwderController();
	// always
	// **********************************************************************//

	JsonObject thread$isonMsg = new JsonObject();
	JsonObject thread$isonheader = new JsonObject();
	JsonObject thread$isonMapJson = new JsonObject();
	JsonObject global = new JsonObject();
	JsonObject ibody = new JsonObject();
	JsonObject icbsbody = new JsonObject();
	String rCollName = null;
	String userid = null;

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		logger.info("SAM023 isonMsg"+isonMsg+"\n isonheader"+isonheader+"\n isonMapJson"+isonMapJson);
		try {
			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();
			String iKey = null;
			JsonObject argJson = new JsonObject();
			userid = IResManipulator.iloggedUser.get();
			thread$isonMsg = isonMsg;
			thread$isonheader = isonheader;
			thread$isonMapJson = isonMapJson; 
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
  			// #PKY00037 Starts
			logger.info("SAM024 Scr"+Scr+"\n SOpr"+SOpr);
			if((Scr.substring(0, 3).equalsIgnoreCase("OAB")) ||I$utils.$iStrFuzzyMatch(Scr, "OLDLNCRT") || I$utils.$iStrFuzzyMatch(Scr, "OLDLNRWL") || I$utils.$iStrFuzzyMatch(Scr, "ORCRECON") || I$utils.$iStrFuzzyMatch(Scr, "OB2UACCR")) {
				Scr = "XWFIMPWF";
				SOpr = "PROCESS_TASK";
			}
			// #PKY00037 Ends
			String ScrOpr1 = i$ResM.getOpr2(isonMsg);
			logger.info("SAM025 Scr"+Scr+"\n SOpr"+SOpr);
			if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "PROCESS_TASK")) {
				return processTask(isonMsg, i$ResM);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FETCH_TASK")) {
				return fetchTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FETCH_TASKS")) {
				return fetchTasks(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "ACQUIRE_TASK")) {
				return acquireTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "ENRICHMENT_TASK")) {//#YPR00052 Changes
				return enrichmentTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "TERMINATE_TASK")) {
				return terminateTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "HOLD_TASK")) {
				return holdTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "RELEASE_TASK")) { // #00000008
																													// changes
				return releaseHoldTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")
					&& I$utils.$iStrFuzzyMatch(ScrOpr1, "RELEASELOCK")) { // #00000008
				// changes
				return $releaseTask(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FetchIncTasks")) { // #00000008
				return fetchInCApps(isonMsg); // #00000009 change
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "SearchTasks")) {
				return searchTasks(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FetchRejTasks")) { // #00000008
				return fetchRejApps(isonMsg); // #00000009 change
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "CbsRetry")) { // ##00000026
				return cbsRetry(isonMsg); // ##00000026 change
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FetchAmbNotifications")) {
				return ambNotifications(isonMsg); // #00000010 change
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FetchLatestAppls")) {
				return last10Appls(isonMsg); // #00000010 change
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XWFIMPWF") && I$utils.$iStrFuzzyMatch(SOpr, "FetchHeldTasks")) { // #00000037 change
				return getWorkflowAllHeldAppls(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(Scr, "EMAIL") && I$utils.$iStrFuzzyMatch(SOpr, "Email_Trigger")) { // #00000037
				return emailTriggering(isonMsg);
			}else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
	};

	@SuppressWarnings({ "null", "rawtypes", "unused" })
	private JsonObject processTask(JsonObject isonMsg, IResManipulator i$ResM) {
		logger.info("SAM026 isonMsg"+isonMsg);
		IResManipulator.iloggedUser.set(IResManipulator.iloggedUser.get());
		IResManipulator.JGobalConstans.set(IResManipulator.JGobalConstans.get());
		i$ResM.getAllGobal(); 
		String reqObjId = null;
		String reqKeyFld = null;
		String workFlowId = null;
		String currStage = null;
		String fwdOpr = null;
		String fwdMode = null;
		String curQueue = null;
		String nxtStgNum = null;
		String prvStgNum = null;
		String tskStg = null;
		String newStgNum = null;
		String autoFwdStg = null;
		String autoFwdOpr = null;
		String currStageName = null;
		String applicationId = null;
		String paymentStatus = null; // #DVJ00042 Change
		String refer_userId = null;
		String refer_Queue = null;
		String nxtStageName = null;
		String userId = null;
		String stgName = null;
		JsonObject isonthread = new JsonObject();
		isonthread.add("newIsonMasg", thread$isonMsg);
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject arg$Json = new JsonObject();
		JsonObject task$Json = new JsonObject();
		JsonObject control$Json = new JsonObject();
		JsonObject app$Json = new JsonObject();
		JsonObject all$Oprs = new JsonObject();
		JsonObject stg$LfeCycle = new JsonObject();
		JsonObject cur$Stage = new JsonObject();
		JsonObject nxt$stage = new JsonObject();
		JsonObject cstg$fwdRule = new JsonObject();
		JsonObject fwd$Rule = new JsonObject();
		JsonObject fwd$filter = new JsonObject();
		JsonArray pre$flghtOprs = new JsonArray();
		JsonArray pst$flghtOprs = new JsonArray();
		JsonObject fw$opr = new JsonObject();
		JsonObject rec$Id = new JsonObject();
		String CurrentStageName = null;
		int nxtStage_number = 0;
		String isReleaseOpr = "N";
		logger.info("SAM027 i$body"+i$body);
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		;

		if (i$body.has("ReqObjId")) {
			reqObjId = i$body.get("ReqObjId").getAsString();
		} else
			reqObjId = null;

		if (i$body.has("ReqKeyFld")) {
			reqKeyFld = i$body.get("ReqKeyFld").getAsString();
		}
		;
		if (i$body.has("FwdOpr")) {
			fwdOpr = i$body.get("FwdOpr").getAsString();
		}
		if (i$body.has("isReleaseOpr")) {
			isReleaseOpr = i$body.get("isReleaseOpr").getAsString();
		}

		if (i$body.has("TaskStage")) {
			tskStg = i$body.get("TaskStage").getAsString();
		}
		if (i$body.has("applicationId")) {
			applicationId = i$body.get("applicationId").getAsString();
		}
		// #DVJ00042 Starts
		if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CIF_WFLW_NEW"))) {     //#PKY00022 changes
			if (i$body.has("paymentStatus")) {
				paymentStatus = i$body.get("paymentStatus").getAsString();
			} else {
				paymentStatus = "Payment Due";
			}
		}
		// #DVJ00042 Ends
		// for checking the Current stage matches with inoming request
		logger.info("SAM028 CurrentStageName"+CurrentStageName);
		if (i$body.has("CurrentStageName")) {
			CurrentStageName = i$body.get("CurrentStageName").getAsString();
		}

		if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER")) {
			if (i$body.has("toUserId")) {
				refer_userId = i$body.get("toUserId").getAsString();
				if (I$utils.$iStrFuzzyMatch(refer_userId, IResManipulator.iloggedUser.get())) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SELF REFER IS NOT POSSIBLE");
				}
			} else
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")) {
			if (i$body.has("toQueue")) {
				refer_Queue = i$body.get("toQueue").getAsString();
			} else
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_DC")) {

			if (i$body.has("toUserId")) {
				refer_userId = i$body.get("toUserId").getAsString();
				if (I$utils.$iStrFuzzyMatch(refer_userId, IResManipulator.iloggedUser.get())) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SELF REFER IS NOT POSSIBLE");
				}
			} else
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");

		}
		if (i$body.has("userId")) {
			userId = i$body.get("userId").getAsString();
		} else {
			userId = IResManipulator.iloggedUser.get();
		}
		if (i$body.has("fwdMode")) {
			fwdMode = i$body.get("fwdMode").getAsString();
		} else {
			fwdMode = "M";
		}

		try {
			// 1. Retrieve the Controll Json from DB

			arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
			logger.info("SAM029 arg$Json"+arg$Json);
			if (!(arg$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// set all prerequisite Jsons
			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			all$Oprs = control$Json.get("ALLWOPRS").getAsJsonObject();
			stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
			stgName = stg$LfeCycle.get(tskStg).getAsJsonObject().get("STGID").getAsString();
			String[] sName = stgName.split("#");
			stgName = sName[1];

//			String query = "{\"$or\":[{\"$and\" :[{\"applicationId\":\"" + applicationId + "\"}," + "{\""
//					+ control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
//					+ "{\"$and\" :[{\"applicationId\":\"" + applicationId + "\"}," + "{\""
//					+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}]}";

			JsonObject query = new JsonObject();
			query.addProperty("applicationId", applicationId);
			query.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			query.addProperty("isCurrVer", "Y");

			app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(), query);
			rCollName = control$Json.get("RECCOLLNAME").getAsString();
			
			// #DVJ00039 Starts
			//#PKY00022 starts
			String applicantName = "";
			try {
				logger.info("SAM030 workFlowId"+workFlowId+"\napp$Json"+app$Json);
			    if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIXED_DEPOSIT_WORKFLOW"))){  
					applicantName = app$Json.get("trnData").getAsJsonObject().get("CustomerFullName").getAsString(); 
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LEAD_WRKFLOW"))){   
					applicantName = app$Json.get("CustomerFullName").getAsString();        
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_TATIL_INSURANCE_WORKFLOW"))){  
					applicantName = app$Json.get("custInfo").getAsJsonObject().get("CustomerFullName").getAsString();               
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CUSTSVR_WORKFLOW"))){  
					applicantName = app$Json.get("CustomerFullName").getAsString();               
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_PAYROLL_WORKFLOW"))){  
					applicantName = app$Json.get("CustomerFullName").getAsString();               
				}
				else {    
					JsonObject nameMapData = new JsonObject();
					try{
					if(I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CHERRY_PICKS_WORKFLOW"))
						nameMapData = app$Json.get("fcipData").getAsJsonObject();
					else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LINCU_WORKFLOW")))
						nameMapData = app$Json.get("fcbl").getAsJsonObject();
					else 
						nameMapData = app$Json.get("personalInfo").getAsJsonObject();
					
					} catch (Exception e) {}
					try {
						applicantName = nameMapData.get("firstName").getAsString();
						if(!I$utils.$iStrBlank(nameMapData.get("middleName").getAsString())) {
							applicantName = applicantName +" "+ nameMapData.get("middleName").getAsString();
						}
						if(!I$utils.$iStrBlank(nameMapData.get("lastName").getAsString())) {
							applicantName = applicantName +" "+ nameMapData.get("lastName").getAsString();
						}
					} catch (Exception e) {}
				}
			}catch(Exception e) {
				
			}
			logger.info("SAM030 workFlowId"+workFlowId+"\napp$Json"+app$Json);
			//#PKY00022 ends
			// #DVJ00039 Ends

			if (!(app$Json != null)) {
				logger.info("SAM014 isonMsg"+isonMsg);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			} else if (I$utils.$iStrFuzzyMatch(app$Json.get("RecordStat").getAsString(), "T_TERMINATE")) {

				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "APPLICATION IS TERMINATED");
			} else if (I$utils.$iStrFuzzyMatch(app$Json.get("RecordStat").getAsString(), "C_CLOSED")) {

				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "APPLICATION IS CLOSED");
			}
			logger.info("SAM031 task$Json"+task$Json);
			// 2. Get the Current Stage of the TASK from ProcessTable - IF No Record then
			// Process for INIT_STG

			task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
					"{\"$or\":[{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
							+ "{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}]}");
			logger.info("SAM032 task$Json"+task$Json);
			try {
				if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "INIT"))) {
					if (!(I$utils.$iStrFuzzyMatch(fwdMode, "A"))) {
						if (!(I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(),
								CurrentStageName))) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
						}
					}
				}
			} catch (Exception e) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			
			try {
				if (I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "INITIAL DEPOSIT APPLICATION AND OSV") &&  // #SRM00036 changes
						(I$utils.$iStrFuzzyMatch(task$Json.get("paymentStatus").getAsString(), "Payment Due"))) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Initial Deposit Receipt has not been uploaded");
				}
			} catch (Exception e) {
			}

			if (!(task$Json != null)) {

				if (!(I$utils.$iStrFuzzyMatch(fwdOpr, null)) && (I$utils.$iStrFuzzyMatch(fwdOpr, "INIT"))) {
					task$Json = new JsonObject();
					if (reqKeyFld != null) {
						task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
					}
					if (reqObjId != null) {
						task$Json.addProperty(control$Json.get("RECOBJIDFLD").getAsString(), reqObjId);
					}
					currStage = tskStg;
					cur$Stage = stg$LfeCycle.get(currStage).getAsJsonObject();
					try {
						nxtStgNum = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject()
								.get("NEW_STG").getAsString();
					} catch (Exception e) {
						nxtStgNum = null;
					}

					nxt$stage = stg$LfeCycle.get(nxtStgNum).getAsJsonObject();

					try {
						fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
					} catch (Exception e) {
						fwd$Rule = null;
					}
					try {
						currStageName = nxt$stage.get("STGNAME").getAsString();
					} catch (Exception e) {
						currStageName = null;
					}
					try {
						nxtStageName = nxt$stage.get("NEXT_STGNAME").getAsString();
						logger.info("CURRENT STAGE", nxtStageName);
					} catch (Exception e) {
						currStageName = null;
					}
					try {
						prvStgNum = nxt$stage.get("PREV_STG_NO").getAsString();
					} catch (Exception e) {
						prvStgNum = null;
					}
					try {
						newStgNum = fw$opr.get("NEW_STG").getAsString();
					} catch (Exception e) {
						newStgNum = null;
					}

					try {
						nxtStage_number = fw$opr.get("NEW_STG").getAsInt();
					} catch (Exception e) {
						newStgNum = null;
					}
					
					if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CIF_WFLW_NEW"))) {              ////#PKY00022 changes
						try {
							task$Json.addProperty("verificationMode", app$Json.get("verificationMode").getAsString());
							if (I$utils.$iStrFuzzyMatch(app$Json.get("verificationMode").getAsString(), "Smartphone")) { // #YPR00085 Changes
								task$Json.addProperty("smartphoneVerification","Pending");
							}else {
								task$Json.addProperty("smartphoneVerification","NA");
							}
						} catch (Exception e) {
							task$Json.addProperty("verificationMode", "Visit Branch");
							task$Json.addProperty("smartphoneVerification","NA"); // #YPR00085 Changes
						}
					}

					if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")
							|| I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER"))) {
						try {
							int curstg = nxtStage_number + 1;
							String cursstage = "" + curstg;
							JsonObject nxtQueue = stg$LfeCycle.get(cursstage).getAsJsonObject();
							nxtStage_number++;
							task$Json.addProperty("NxtTskStage", "" + nxtStage_number);
						} catch (Exception e) {
							task$Json.addProperty("NxtTskStage", "NA");
						}
						curQueue = getCurrQueue(nxt$stage, fwdOpr);
						task$Json.addProperty("WorkFlowId", workFlowId);
						task$Json.addProperty("isCurrVer", "Y"); // #00000012 change
						task$Json.addProperty("Queue", curQueue);
						task$Json.addProperty("CurrentTask", fwdOpr);
						task$Json.addProperty("TaskId", Im$utils.generateRandomKey(16));
						task$Json.add("InitiatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
						task$Json.addProperty("CurrentTskStage", nxtStgNum);
						task$Json.addProperty("CurrentStageName", currStageName);
						task$Json.addProperty("PreTskStage", prvStgNum);
						task$Json.addProperty("applicationId", applicationId);
						task$Json.addProperty("cbsCif", "NA");
						task$Json.addProperty("cbsStatus", "NA");
						task$Json.addProperty("NewTskStage", newStgNum);
						if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CIF_WFLW_NEW"))) {              ////#PKY00022 changes
							task$Json.addProperty("paymentStatus", paymentStatus);		// #DVJ00042 Change
						}
						if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CUSTSVR_WORKFLOW"))) {
							task$Json.addProperty("cif", app$Json.get("cif").getAsString());
							task$Json.addProperty("criteria", app$Json.get("criteria").getAsString());	
							task$Json.addProperty("nature", app$Json.get("nature").getAsString());	
							task$Json.addProperty("priority", app$Json.get("priority").getAsString());	
							task$Json.addProperty("status", app$Json.get("status").getAsString());
							task$Json.addProperty("type", app$Json.get("type").getAsString());// #DVJ00042 Change
						}
						if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_RECONCILIATION_WORKFLOW"))) {
							try {
								task$Json.addProperty("comparisonCredit", app$Json.get("comparisonCredit").getAsString());
							}catch(Exception e) {
								
							}
							try {
								task$Json.addProperty("comparisonDebit", app$Json.get("comparisonDebit").getAsString());
							}catch(Exception e) {
								
							}
							try {
								task$Json.addProperty("comparisonDifference", app$Json.get("comparisonDifference").getAsString());
							}catch(Exception e) {
								
							}
							try {
								task$Json.addProperty("flexcubeDifference", app$Json.get("flexcubeDifference").getAsString());	
							}catch(Exception e) {
								
							}
							try {
								task$Json.add("individualDifference", app$Json.get("individualDifference").getAsJsonArray());
							}catch(Exception e) {
								
							}	
						}
						if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_PAYROLL_WORKFLOW"))) {
							try {
								task$Json.addProperty("bankAccNo", app$Json.get("bankAccNo").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("bankCredited", app$Json.get("bankCredited").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("bankCreditedDesc", app$Json.get("bankCreditedDesc").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("creditAccNo", app$Json.get("creditAccNo").getAsString());
							}catch(Exception e) {}
							
							try {
								task$Json.addProperty("creditAmount", app$Json.get("creditAmount").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("creditDate", app$Json.get("creditDate").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("currency", app$Json.get("currency").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("currencyDesc", app$Json.get("currencyDesc").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("custNo", app$Json.get("custNo").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("realisedAmount", app$Json.get("realisedAmount").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("receiptReferenceNo", app$Json.get("receiptReferenceNo").getAsString());
							}catch(Exception e) {}
							try {
								task$Json.addProperty("remittanceAmount", app$Json.get("remittanceAmount").getAsString());
							}catch(Exception e) {}
						}
						try {
							task$Json.addProperty("cbsCif",
									app$Json.get("contactDetails").getAsJsonObject().get("CIF").getAsString());
						} catch (Exception e) {
							// pass
						}
						try {
							task$Json.add("contactDetails", app$Json.get("contactDetails").getAsJsonObject());
						} catch (Exception e) {
							// pass
						}
						task$Json.addProperty(stgName, app$Json.get("createdBy").getAsString());
						try {
							task$Json.add("remarks", app$Json.get("WorkFlowRemarks").getAsJsonArray());
							task$Json.add("latestRemarks", app$Json.get("WorkFlowLatestRemarks").getAsJsonArray());
						} catch (Exception e) {
							// pass
						}
						task$Json.addProperty(stgName, app$Json.get("createdBy").getAsString());
						task$Json.addProperty("ModifiedBy", app$Json.get("createdBy").getAsString());
						// #00000025 begins
						try {
							task$Json.addProperty("iLeadSource", app$Json.get("iLeadSource").getAsString());
						} catch (Exception e) {
							// pass
						}
						try {
							task$Json.addProperty("cif", app$Json.get("cif").getAsString());
						} catch (Exception e) {
							// pass
						}		//SRI00034 Changes  Starts 
						try {
							task$Json.addProperty("loanProduct", app$Json.getAsJsonObject("loanDetails").get("loanProduct").getAsString());

						} catch (Exception e) {
							e.printStackTrace();
						}
						try {
							task$Json.addProperty("loanProductDesc", app$Json.getAsJsonObject("loanDetails").get("loanProductDesc").getAsString());

						} catch (Exception e) {
							e.printStackTrace();
						} 		//SRI00034 Changes  Ends  
						// #00000025 ends
					}
					if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER")) {
						task$Json.addProperty("TaskAssignedTo", refer_userId);
						task$Json.addProperty("Queue", refer_userId);
						task$Json.addProperty("ReferedBy", IResManipulator.iloggedUser.get());
					}
					if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_DC")) {
						task$Json.addProperty("TaskAssignedTo", refer_userId);
						task$Json.addProperty("Queue", refer_userId);
						task$Json.addProperty("ReferedBy", IResManipulator.iloggedUser.get());
					}
					if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")) {
						task$Json.addProperty("TaskAssignedQueue", refer_Queue);
						task$Json.addProperty("Queue", refer_Queue);
						task$Json.addProperty("ReferedBy", IResManipulator.iloggedUser.get());
					}
					task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
					if (reqObjId != null) {
						task$Json.addProperty("O_Id", reqObjId);
					}
				} else {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORKFLOW NOT YET INITIATED");
				} // end of INIT LOOP
			} else {
				JsonObject oldtask$Json = new JsonObject();
				rec$Id.add("_id", task$Json.get("_id").getAsJsonObject()); // #00000018 change
				oldtask$Json.addProperty("Queue", task$Json.get("Queue").getAsString());
				oldtask$Json.addProperty("CurrentTask", task$Json.get("CurrentTask").getAsString());
				oldtask$Json.addProperty("CurrentTskStage", task$Json.get("CurrentTskStage").getAsString());
				oldtask$Json.addProperty("CurrentStageName", task$Json.get("CurrentStageName").getAsString()); // #00000008
				oldtask$Json.addProperty("NxtTskStage", task$Json.get("NxtTskStage").getAsString());
				oldtask$Json.addProperty("PreTskStage", task$Json.get("PreTskStage").getAsString());
				oldtask$Json.addProperty("NewTskStage", task$Json.get("NewTskStage").getAsString());
				try {
					oldtask$Json.addProperty("ModifiedBy", task$Json.get("ModifiedBy").getAsString());
				} catch (Exception e) {
					// pass
				}
				// #TKS00006 Starts
				try {
					if ((I$utils.$iStrFuzzyMatch(task$Json.get("ModifiedBy").getAsString(), userId)) && 
							(I$utils.$iStrFuzzyMatch(arg$Json.get("WORKFLOWID").getAsString(), "IMPACTO_LEAD_WRKFLOW"))) {  //PKY00054 changes
						try {
							 currStageName = stg$LfeCycle.get(tskStg).getAsJsonObject().get("STGNAME").getAsString();  //PKY00054 changes
						}catch(Exception e) {}
						if (!I$utils.$iStrFuzzyMatch(currStageName , "INITIATION")) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"CHECKER CAN'T BE THE MAKER/ AUTHOURIZER CAN'T BE THE APPROVER");
						}
					}
				}catch(Exception e) {} //#TKS00006 Ends
				
//				// #00000040 change begins
//				if (I$utils.$iStrFuzzyMatch(task$Json.get("initiatorId").getAsString(), userId)) {	// #DVJ00041 Change
//					if (!(I$utils.$iStrFuzzyMatch(fwdMode, "A"))) {
//						if (!(I$utils.$iStrFuzzyMatch(isReleaseOpr, "Y"))) {
//							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INTIATOR CAN'T BE THE AUTHORIZER");
//						}
//					}
//				}
				// #DVJ00046 Ends
				// #00000040 change Ends
//				if (I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "HOLD")) {
//
//				}
				if (!(I$utils.$iStrFuzzyMatch(fwdOpr, null)) && (I$utils.$iStrFuzzyMatch(fwdOpr, "INIT"))) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORKFLOW IS ALREADY INITIATED FOR THIS JOB");
				}
				currStage = tskStg;
				cur$Stage = stg$LfeCycle.get(currStage).getAsJsonObject();
				try {
					nxtStgNum = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject().get("NEW_STG")
							.getAsString();
				} catch (Exception e) {
					nxtStgNum = null;
				}
				nxt$stage = stg$LfeCycle.get(nxtStgNum).getAsJsonObject();
				try {
					fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
				} catch (Exception e) {
					fwd$Rule = null;
				}
				try {
					currStageName = nxt$stage.get("STGNAME").getAsString();
				} catch (Exception e) {
					currStageName = null;
				}
				try {
					nxtStgNum = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject().get("NEW_STG")
							.getAsString();
				} catch (Exception e) {
					nxtStgNum = null;
				}
				try {
					prvStgNum = nxt$stage.get("PREV_STG_NO").getAsString();
				} catch (Exception e) {
					prvStgNum = null;
				}
				try {
					newStgNum = fw$opr.get("NEW_STG").getAsString();
				} catch (Exception e) {
					newStgNum = null;
				}
				try {
					nxtStage_number = fw$opr.get("NEW_STG").getAsInt();
				} catch (Exception e) {
					newStgNum = null;
				}
				curQueue = getCurrQueue(nxt$stage, fwdOpr);
				task$Json.addProperty("isCurrVer", "Y"); // #00000012 change
				if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")
						|| I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER"))) {
					try {
						int curstg = nxtStage_number + 1;
						String cursstage = "" + curstg;
						JsonObject nxtQueue = stg$LfeCycle.get(cursstage).getAsJsonObject();

						nxtStage_number++;
						task$Json.addProperty("NxtTskStage", "" + nxtStage_number);
					} catch (Exception e) {
						task$Json.addProperty("NxtTskStage", "NA");
					}
					task$Json.addProperty("Queue", curQueue);
					task$Json.addProperty("CurrentTask", nxtStgNum);
					task$Json.addProperty("CurrentTskStage", nxtStgNum);
					try {
						task$Json.add("remarks", app$Json.get("WorkFlowRemarks").getAsJsonArray());
						task$Json.add("latestRemarks", app$Json.get("WorkFlowLatestRemarks").getAsJsonArray());
					} catch (Exception e) {
						// pass
					}
					if (I$utils.$iStrFuzzyMatch(stgName, "initiatorId")) {		// #DVJ00041 Change
						task$Json.addProperty(stgName, app$Json.get("createdBy").getAsString());
					} else {
						task$Json.addProperty(stgName, IResManipulator.iloggedUser.get()); // 00000016 change
					}
					if (I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETE APPLICATION")) {		// #DVJ00047 Change
						task$Json.addProperty("CurrentStageName", "CLOSED APPLICATION");
					} else {
						task$Json.addProperty("CurrentStageName", currStageName);
					}
					task$Json.addProperty("PreTskStage", prvStgNum);
					task$Json.addProperty("NewTskStage", newStgNum);
					task$Json.addProperty("applicationId", applicationId);
				}
				task$Json.add("ModifiedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				task$Json.addProperty("ModifiedBy", userId);
				task$Json.add("prevStageDetail", oldtask$Json);
				task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
				if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER")) {
					task$Json.addProperty("TaskAssignedTo", refer_userId);
					task$Json.addProperty("Queue", refer_userId);
				}
				if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_DC")) {
					task$Json.addProperty("TaskAssignedTo", refer_userId);
					task$Json.addProperty("Queue", refer_userId);
				}
				if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")) {
					task$Json.addProperty("TaskAssignedQueue", refer_Queue);
					task$Json.addProperty("Queue", refer_Queue);
				}
				// #00000007 Begins
				task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
				if (reqObjId != null) {
					task$Json.addProperty("O_Id", reqObjId);
				}
			}
			// 3. Verify the user Queue Access rights for Current Task
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")) {
			}
			if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "INIT"))) {
				if (!(I$utils.$iStrFuzzyMatch(fwdMode, "A"))) {
					if (!(db$Ctrl.db$hasQuOprRights(userId, workFlowId, getCurrQueue(cur$Stage, fwdOpr), fwdOpr,
							getRoles(IResManipulator.iloggedUser.get())))) {
						try {
							if((I$utils.$iStrFuzzyMatch(CurrentStageName, "VERIFY APPLICATION")) && !(I$utils.$iStrFuzzyMatch(app$Json.get("verificationMode").getAsString(), "Smartphone"))) { // #00000020 & #YPR validates to smartphone verify
								return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER DOESN'T HAVE RIGHTS");
								}
						}catch(Exception e) {
							
						}	
					}
				}
			}
			;
			// 7. Check Any PreFlight Operations Fire them 1 after Other . If All Success -
			// In Parallel Threads (Do In a Pool)
			fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
			pre$flghtOprs = fw$opr.get("PREFLIGHT_OPRS").getAsJsonArray();
			app$Json.addProperty("WorkFlowId", workFlowId);   //#PKY00016 changes
			if (pre$flghtOprs != null && pre$flghtOprs.size() > 0) {
				// Forward to Thread pool controller
				ExecutorService executor = Executors.newFixedThreadPool(3);// creating a pool of 5 threads
				try {
					for (int i = 0; i < 1; i++) {
						Runnable worker = new preflightOprThread(pre$flghtOprs, isonMsg, app$Json, i$ResM.getAllGobal());
						executor.execute(worker);// calling execute method of ExecutorService
					}
					executor.shutdown();
					while (!executor.isTerminated()) {
					}
				} finally {
					try {
						executor.shutdown();
					} catch (Exception er) {
						//
					}
				}
				logger.debug("Finished all threads");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_MSGTEXT, "NO PREFLIGHT OPERATIONS");
			}
			// Update the Collection for Task and Logs
			JsonObject jfilter = new JsonObject();
			jfilter.addProperty("WorkFlowId", workFlowId);
			jfilter.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			task$Json.remove("_id");
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "INIT")) {
//				ibody.remove("SMS_TRIGGER");	// #DVJ00044 Change
				ibody.remove("CALLJAVA");	// #DVJ00048 Change
				task$Json.add("ScanDetails", ibody);
			} else if ((I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETED")) || (I$utils.$iStrFuzzyMatch(fwdOpr, "CONVERT"))) {	// #DVJ00047 Change
				if (icbsbody != null) {
					task$Json.add("cbsDetails", icbsbody);
					task$Json.addProperty(stgName, task$Json.get("ModifiedBy").getAsString());
				}
			} else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CIF_WFLW_NEW"))) {  //#SRM00060 starts
				try {
				if (icbsbody != null) {
					task$Json.add("cbsDetails", icbsbody);
					task$Json.addProperty(stgName, task$Json.get("ModifiedBy").getAsString());
				}
				} catch (Exception e) {
					e.printStackTrace();
				} //#SRM00060 ends
			}
			try {//SRP00047 Starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIXED_DEPOSIT_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					task$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//SRP00047 Ends
			try { //MSA00104 starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LINCU_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					task$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//MSA00104 ends
			try { //MSA00104 starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CHERRY_PICKS_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					task$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//MSA00104 ends
			try { //MSA00104 starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIP_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					task$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//MSA00104 ends
			try {//SRP00047 Starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_PAYROLL_WORKFLOW")))
				{
					String creditVerified = app$Json.get("creditVerified").getAsString();
					if(creditVerified.equals("N")){
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "As credit is not verified the system will not post any accounting entries to credit the member account.");
					}
				}
			}catch(Exception e) {}
			try { // SRM00058 CHANGES
				if((I$utils.$iStrFuzzyMatch(currStageName, "COMPLETE APPLICATION")) && (I$utils.$iStrFuzzyMatch(nxtStgNum, "5"))) {
					task$Json.addProperty("NxtTskStage", "NA"); 
				}
			}catch (Exception e) {
				
			}// SRM00058
			task$Json.addProperty("isCurrVer", "Y"); // #00000012 change
			task$Json.addProperty("applicantName", applicantName);	// #DVJ00039 Changes
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jfilter, "true");
			// Update the actual Application for TaskId and RecordStat and Workfloe Status
			jfilter = new JsonObject();
			jfilter.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			app$Json = new JsonObject();
			try {//SRP00047 Starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIXED_DEPOSIT_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					app$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//SRP00047 Ends
			
			try {//MSA00104 Starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LINCU_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					app$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//MSA00104 Ends
			try { //MSA00104 starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CHERRY_PICKS_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					app$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//MSA00104 ends
			try { //MSA00104 starts
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIP_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(stgName, "approverId")))
				{
					app$Json.add("approvedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				}
			}catch(Exception e) {}//MSA00104 ends

			// #00000024 begins
			JsonArray Remarks = new JsonArray();
			JsonArray LatestRemarks = new JsonArray();
			if (i$body.has("Remarks")) {
				Remarks = i$body.get("Remarks").getAsJsonArray();
				task$Json.add("remarks", Remarks);
				app$Json.add("WorkFlowRemarks", Remarks); // #00000024 change				
			}
			if (i$body.has("LatestRemarks")) {
				LatestRemarks = i$body.get("LatestRemarks").getAsJsonArray();
				task$Json.add("latestRemarks", LatestRemarks);
				app$Json.add("WorkFlowLatestRemarks", LatestRemarks); // #00000024 change
			}
			try {
			} catch (Exception e) {
				// pass
			}
			// #00000024 end
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETED")) {		// #DVJ00047 Change
				app$Json.addProperty("RecordStat", "C_CLOSED");
				app$Json.addProperty("WRK_FLW_STAGE", task$Json.get("CurrentStageName").getAsString());
			} 
			// #DVJ00041 Starts
			else if ((I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "COMPLETED") || I$utils
					.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "COMPLETE APPLICATION"))) {		// #DVJ00047 Change
				app$Json.addProperty("completerId", userId);	// #DVJ00047 Change
				task$Json.addProperty("completerId", userId);	// #DVJ00047 Change
				app$Json.addProperty("RecordStat", "C_COMPLETED"); // #DVJ00047 Change
			// #DVJ00041 Ends
				app$Json.addProperty("WRK_FLW_STAGE", task$Json.get("CurrentStageName").getAsString());
			} else if (I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "HOLD")) {
				app$Json.addProperty("RecordStat", "H_HOLD");
				app$Json.addProperty("WRK_FLW_STAGE", task$Json.get("CurrentStageName").getAsString());
			} else if ((I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETED")
					|| I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETE APPLICATION"))) {		// #DVJ00047 Change
				app$Json.addProperty("WRK_FLW_STAGE", task$Json.get("CurrentStageName").getAsString());
				app$Json.addProperty("RecordStat", "C_CLOSED");
			} else if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_DC")) {
				app$Json.addProperty("WRK_FLW_STAGE", "WIP");
				app$Json.addProperty("RecordStat", "W-WIP");
				app$Json.addProperty("DcStatus", "ReferDcIncomplete");

			} else {
				app$Json.addProperty("RecordStat", "O_OPEN"); //
			}
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "INIT")|| (I$utils.$iStrFuzzyMatch(fwdOpr, "ACCEPT")) && (I$utils.$iStrFuzzyMatch(currStageName, "VERIFY APPLICATION"))){//#SRP00051 changes
				app$Json.add("ScanDetails", ibody);
			} else if (I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETED")) {		// #DVJ00047 Change
				if (icbsbody != null) {
					app$Json.add("cbsDetails", icbsbody);
				}
			}
			// #00000007 Begins
			if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE") || I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER"))) {
				app$Json.addProperty(stgName, task$Json.get(stgName).getAsString()); // 00000016 Change
				// #00000007 Ends
			} else if (I$utils.$iStrFuzzyMatch(stgName, "initiatorId")) {		// #DVJ00041 Change
				app$Json.addProperty(stgName, app$Json.get("createdBy").getAsString());
			} else {
				app$Json.addProperty(stgName, IResManipulator.iloggedUser.get()); // 00000016 change
			}
			app$Json.addProperty("WorkFlowTaskId", task$Json.get("TaskId").getAsString());
			app$Json.addProperty("WorkFlowStatus", task$Json.get("CurrentStageName").getAsString());
			app$Json.addProperty("isCurrVer", "Y");
			if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CIF_WFLW_NEW"))) {              //#PKY00022 changes
				app$Json.addProperty("paymentStatus", paymentStatus);		// #DVJ00042 Change
			    app$Json.addProperty("currStgNo", task$Json.get("CurrentTask").getAsString()); //#SRM00058 Changes
			}
			
			if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_PAYROLL_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "COMPLETE APPLICATION"))) {              //#PKY00022 changes
				app$Json.addProperty("approveDate", i$ResM.getOnlydate(new Date()));		// #DVJ00042 Change
			}
			
			if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CUSTSVR_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "APPROVE APPLICATION"))) {              //#PKY00022 changes
				app$Json.addProperty("status", "pending");		// #DVJ00042 Change
			}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CUSTSVR_WORKFLOW")) && (I$utils.$iStrFuzzyMatch(task$Json.get("CurrentStageName").getAsString(), "COMPLETE APPLICATION"))) {
				app$Json.addProperty("status", "closed");
			}
			// #00000038 changes begins
			app$Json.addProperty("operationDone", fwdOpr);
			app$Json.addProperty("operationPerformedBy", IResManipulator.iloggedUser.get());
			if((I$utils.$iStrFuzzyMatch(app$Json.get("operationPerformedBy").getAsString(), ""))){   // #PKY00024 changes
				app$Json.addProperty("operationPerformedBy", userId);
			}
			// #00000038 changes ends

			app$Json.addProperty("applicantName", applicantName);	// #DVJ00039 Changes
			db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), app$Json, jfilter);
			// 4. Populate Fwd Allowed Oprs
			logger.info("Fwd Allowed Operations are", all$Oprs.toString());
			fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
			pst$flghtOprs = fw$opr.get("POSTFLIGHT_OPRS").getAsJsonArray();
			if (pst$flghtOprs != null && pst$flghtOprs.size() > 0) {
				app$Json = new JsonObject();
				JsonObject jflter = new JsonObject();
				jflter.addProperty("applicationId", applicationId);
				jflter.addProperty("referenceNo", reqKeyFld);
				app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(), jflter);
				app$Json.addProperty("WorkFlowId", workFlowId);   //#PKY00016 changes
				// Forward to Thread pool controller
				ExecutorService executorpst = Executors.newFixedThreadPool(5);// creating a pool of 5 threads
				for (int i = 0; i < 1; i++) { // Changing the thread for sync #00000028
					Runnable worker = new postflightOprThread(pst$flghtOprs, isonMsg, app$Json, i$ResM.getAllGobal());
					executorpst.execute(worker);// calling execute method of ExecutorService
				}
				executorpst.shutdown();
				while (!executorpst.isTerminated()) {
				}
				logger.debug("Finished all threads");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_MSGTEXT, "NO POSTFLIGT OPERATIONS");
				// end of post flight Operations
			}
			// Iterate each Rule from the if FwdMode is Auto
			if (I$utils.$iStrFuzzyMatch(fw$opr.get("AUTOFWD").getAsString(), "Y")) {
				ObjectId objId = new ObjectId();
				BasicDBObject query1 = new BasicDBObject();
				if (reqObjId != null) {
					try {
						query1.put("_id", new ObjectId(task$Json.get("_id").getAsJsonObject().toString()));
						query1.putAll((Map) fwd$Rule.get("FWDFILTER"));
					} catch (Exception e) {
						// Pass
					}
				}
				try {
					cstg$fwdRule = fw$opr.get("AUTOFWDRULE").getAsJsonObject().get(tskStg).getAsJsonObject();
					fwd$filter = cstg$fwdRule.get("Filter").getAsJsonObject();
					autoFwdStg = cstg$fwdRule.get("AUTOFWDSTG").getAsString();
					autoFwdOpr = cstg$fwdRule.get("AUTOFWDOPR").getAsString();
				} catch (Exception e) {
					fwd$filter.addProperty("_id", objId.toString());
				}
				if (!(fwd$filter != null) && db$Ctrl.db$GetRowCnt(control$Json.get("RECCOLLNAME").getAsString(),
						fwd$filter.toString()) < 1) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO MATCHING RULE");
				} else {
					JsonObject isonMsgNew = new JsonObject();
					isonMsgNew.add("newIsonMsg", isonMsg);
					// call the thread controller for processing the next step the same method again
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							i$ResM.getBody(isonMsgNew.get("newIsonMsg").getAsJsonObject()), "FwdOpr", autoFwdOpr);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							i$ResM.getBody(isonMsgNew.get("newIsonMsg").getAsJsonObject()), "TaskStage", autoFwdStg);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							i$ResM.getBody(isonMsgNew.get("newIsonMsg").getAsJsonObject()), "WorkFlowId", workFlowId);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							i$ResM.getBody(isonMsgNew.get("newIsonMsg").getAsJsonObject()), "userId",
							IResManipulator.iloggedUser.get());
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							i$ResM.getBody(isonMsgNew.get("newIsonMsg").getAsJsonObject()), "fwdMode", "A");
					//#PKY00024 starts
					try {
						if(I$utils.$iStrBlank(isonMsgNew.get("newIsonMsg").getAsJsonObject().get("i-body").getAsJsonObject().get("userId").getAsString())) {
							 JsonObject user$Body = isonMsgNew.get("newIsonMsg").getAsJsonObject().get("i-body").getAsJsonObject();
							 user$Body.addProperty("userId", userId);
							 
							 i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
										i$ResM.getBody(isonMsgNew.get("newIsonMsg").getAsJsonObject()), "userId", userId);
						}
					}catch(Exception e) {
						
					}//#PKY00024 ends
					
					try {
						thread$isonMsg = isonMsgNew.get("newIsonMsg").getAsJsonObject();
						global = i$ResM.getAllGobal();
						triggerProcessThread.start();
					} catch (Exception e) {
						triggerProcessThread.interrupt();
					}

				}
			}
			// 8. Then Set To Current Task to the Calling Stage
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "INIT")|| (I$utils.$iStrFuzzyMatch(fwdOpr, "ACCEPT")) && (I$utils.$iStrFuzzyMatch(currStageName, "VERIFY APPLICATION"))){//#SRP00051 Chnages
			   task$Json.add("ScanDetails", ibody);
			} else if (I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETED"))	// #DVJ00047 Change
				if (icbsbody != null) {
					task$Json.add("cbsDetails", icbsbody);
				}
			if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE") || I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER"))) {
				task$Json.addProperty("WorkFlowId", workFlowId);
				task$Json.addProperty("CurrentTask", nxtStgNum);
				task$Json.add("UpdatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
				task$Json.addProperty("CurrentTskStage", nxtStgNum);
				task$Json.addProperty("CurrentStageName", currStageName);
				task$Json.addProperty("PreTskStage", prvStgNum);
				task$Json.addProperty("NewTskStage", nxtStgNum);
			}
			task$Json.addProperty("ModifiedBy", userId);
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER")) {
				task$Json.addProperty("TaskAssignedTo", refer_userId);
				task$Json.addProperty("Queue", refer_userId);
			}
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_DC")) {
				task$Json.addProperty("TaskAssignedTo", refer_userId);
				task$Json.addProperty("Queue", refer_userId);
			}
			if (I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE")) {
				task$Json.addProperty("TaskAssignedQueue", refer_Queue);
				task$Json.addProperty("Queue", refer_Queue);
			}
			task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			if (reqObjId != null) {
				task$Json.addProperty("O_Id", reqObjId);
			}
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			// Persit the Task to I CORE IBP PROCESS Collection and
			// log the task in logger
			task$Json.addProperty("isCurrVer", "Y"); // #00000012 change
			// #DVJ00048 Starts
			try {
				task$Json.remove("cbsCif");
				task$Json.remove("cbsStatus");
				task$Json.remove("cbsDetails");
			} catch (Exception e) {}
			// #DVJ00048 Ends
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
			task$Json.add("IsonMsg", isonMsg);

			// #00000039 changes begins
			try {
				task$Json.addProperty("operationDone", fwdOpr);
				if (!(I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(), ""))) {
					task$Json.addProperty("operationPerformedBy", IResManipulator.iloggedUser.get());
				} else
					task$Json.addProperty("operationPerformedBy", "IMPACTO_COMMON_USER");
			} catch (Exception e) {
				task$Json.addProperty("operationDone", fwdOpr);
				task$Json.addProperty("operationPerformedBy", "IMPACTO_SYSTEM");
			}
			// #00000039 changes ends

			db$Ctrl.db$InsertRow("ICOR_IBM_PROCESS_LOGGER", task$Json);
			// 10. Then Check FWD Mode if 'A' process , Check the Rule and then the next
			// stage calling the same function with the next stage in a different thread.
			// 11. Return Response to the caller ..
			JsonObject ires$json = new JsonObject();
			ires$json.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			ires$json.addProperty("CurrentStageName", task$Json.get("CurrentStageName").getAsString());
			String suc$msg = null;
			if (!(I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_QUEUE") || I$utils.$iStrFuzzyMatch(fwdOpr, "REFER_USER"))) {
				if ((I$utils.$iStrFuzzyMatch(fwdOpr, "COMPLETED")|| I$utils.$iStrFuzzyMatch(currStageName, "COMPLETE APPLICATION"))) {		// #DVJ00047 Change
					try { //#PKY00043 starts
						if(!I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CHERRY_PICKS_WORKFLOW")&& !I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_TATIL_INSURANCE_WORKFLOW")&& !I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIP_WORKFLOW")&& !I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LINCU_WORKFLOW") && !I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CUSTSVR_WORKFLOW")) {    
							suc$msg = "Application successfully submitted for CBS processing. Please visit the Summary Screen for details post CBS approval.";
						}else {
							suc$msg = "APPLICATION SUCCESSFULLY PROCESSED ";
						}
					}catch(Exception e) {
						suc$msg = "Application successfully submitted for CBS processing. Please visit the Summary Screen for details post CBS approval.";
					}    //#PKY00043 ends
				} else
					suc$msg = "APPLICATION SUCCESSFULLY PROCESSED ";
			} else {
				suc$msg = "APPLICATION SUCCESSFULLY PROCESSED ";
			}
			try {
				if (rec$Id != null) {
					i$releaseLock(rec$Id); //// #00000018 change
				}
			} catch (Exception e) {
				// pass
			}
			logger.info("SAM033 isonMsg"+isonMsg);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, suc$msg);
		} catch (Exception excep) {
			// i$releaseLock(rec$Id); //// #00000018 change Not releasing the application in
			// case of error
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			logger.info("SAM034 isonMsg"+isonMsg);
			return isonMsg;
		}
	}

	@SuppressWarnings("unused")
	private JsonObject acquireTask(JsonObject isonMsg) {
		String workFlowId = null;
		String TaskId = null;
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		String applicationId = null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject Jfilter = new JsonObject();
		JsonArray jqueue = new JsonArray();
		String isQueueAccess = "Y";
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		;
		if (i$body.has("TaskId")) {
			TaskId = i$body.get("TaskId").getAsString();
		}
		if (i$body.has("applicationId")) {
			applicationId = i$body.get("applicationId").getAsString();
		}
		Jfilter.addProperty("WorkFlowId", workFlowId);
		Jfilter.addProperty("TaskId", TaskId);
		Jfilter.addProperty("applicationId", applicationId); // #00000018 change
		ArrayList<String> iRoles = new ArrayList<String>(); // #SRM00064 changes start

		jqueue = db$Ctrl.db$GetRows("ICOR_M_USER_PRF", "{\"userId\":\"" + IResManipulator.iloggedUser.get() + "\"}",
				"{\"roles\":1}");
		if (jqueue != null) {
			for (int i = 0; i < jqueue.size(); i++) {
				try {
					iRoles.add(jqueue.get(i).getAsJsonObject().get("roles").getAsString());
				} catch (Exception e) {
					JsonObject jroles = new JsonObject();
					jroles = jqueue.get(i).getAsJsonObject();
					JsonArray jarr = new JsonArray();
					jarr = jroles.get("roles").getAsJsonArray();
					for (int j = 0; j < jarr.size(); j++) {
						String roles = jarr.get(j).getAsString();
						iRoles.add(roles);
					}
				}
			}

			JsonObject queuefilt = new JsonObject();
			JsonObject proj = new JsonObject();
			queuefilt.addProperty("roleOrUser", "U");
			queuefilt.addProperty("userId", IResManipulator.iloggedUser.get());
			queuefilt.addProperty("active", "A");
			JsonObject usr$wrkFlow = db$Ctrl.db$GetRow("ICOR_M_QUEUE_ACC", queuefilt.toString(), proj);
			JsonObject usr$wrkFlowAccroles = new JsonObject();
			if (usr$wrkFlow != null) { //#MVT00150 starts
				try {
					usr$wrkFlowAccroles = usr$wrkFlow.get("queueAccess").getAsJsonObject().get(workFlowId)
							.getAsJsonObject();
					
					if (usr$wrkFlowAccroles.has("QE#REFCOMPLIANCE") && I$utils.$iStrFuzzyMatch(
							usr$wrkFlowAccroles.getAsJsonObject("QE#REFCOMPLIANCE").get("ENRICHMENT").getAsString(),
							"false")) {
						isQueueAccess = "N"; // #SRM00064 changes end
					}
				} catch (Exception e) {
				}
			}
			String sroleMatch = null;
			JsonObject usr$wrkFlowAcc = new JsonObject();

			JsonArray usr$wrkFlowArray = new JsonArray();
			for (int i = 0; i < iRoles.size(); i++) {
				if (i == 0)
					sroleMatch = "\"" + iRoles.get(i) + "\"";
				else
					sroleMatch += ",\"" + iRoles.get(i) + "\"";
			}
			if (iRoles != null) {
				usr$wrkFlowArray = db$Ctrl.db$GetRows("ICOR_M_QUEUE_ACC",
						"{\"$and\":[{\"roleOrUser\":\"R\"},{\"roleId\":{ \"$in\": [" + sroleMatch + "]}}]}",
						"{\"roleId\":1,\"queueAccess\":1}"); //
			}
			for (int i = 0; i < usr$wrkFlowArray.size(); i++) {
				try {
					usr$wrkFlow = usr$wrkFlowArray.get(i).getAsJsonObject();
				} catch (Exception e) {
				}
				if (usr$wrkFlow != null) { // 00000002 changes
					try {
						usr$wrkFlowAcc = usr$wrkFlow.get("queueAccess").getAsJsonObject().get(workFlowId)
								.getAsJsonObject();
						if (usr$wrkFlowAcc.has("QE#REFCOMPLIANCE") && I$utils.$iStrFuzzyMatch(
								usr$wrkFlowAcc.getAsJsonObject("QE#REFCOMPLIANCE").get("ENRICHMENT").getAsString(),
								"false")) {
							isQueueAccess = "N"; // #SRM00064 changes end
						}
					} catch (Exception e) {
					}//#MVT00150 ends
				}

			}
			i$body.addProperty("isQueueAccess", isQueueAccess);
			if (I$utils.$iStrFuzzyMatch(isQueueAccess, "Y")) {
				try {
					JsonObject i$res = new JsonObject();
					isonMsg.addProperty("primaryKey", applicationId); // #00000018 change
					// #00000022 Begins
					JsonObject ires$stat = new JsonObject();
					String istateMsg = null;
					JsonObject i$aqrs = db$Ctrl.db$AcqRow("ICOR_IBM_PROCESS", Jfilter);
					try {
						ires$stat = i$aqrs.get("i-stat").getAsJsonObject();
						istateMsg = ires$stat.get("i-statMsg").getAsString();
						if (I$utils.$iStrFuzzyMatch(istateMsg, "i-ERROR")) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									ires$stat.get("i-error").getAsJsonObject().get("msgtext").getAsString());
						} else
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD ACQUIRED SUCCESSFULLY");
						// #00000022 End
					} catch (Exception e) {
						// Do nothing
						istateMsg = null;
					}
				} catch (Exception excep) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED",
							excep.getMessage().toString());
					excep.printStackTrace();
				}
			}
		}
		;
		return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD ACQUIRED SUCCESSFULLY");
	};

	@SuppressWarnings({ "unused", "null" })
	private JsonObject releaseTask(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		String workFlowId = null;
		String TaskId = null;
		String applicationId = null;
		JsonObject Jfilter = new JsonObject();
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		;
		if (i$body.has("TaskId")) {
			TaskId = i$body.get("TaskId").getAsString();
		}
		if (i$body.has("applicationId")) {
			applicationId = i$body.get("applicationId").getAsString();
		}
		Jfilter.addProperty("WorkFlowId", workFlowId);
		Jfilter.addProperty("TaskId", TaskId);
		Jfilter.addProperty("applicationId", applicationId);
		try {
			JsonObject i$res = new JsonObject();
			i$res = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", Jfilter);
			JsonObject recIdObject = new JsonObject();
			if (i$res != null) {
				recIdObject = i$res.getAsJsonObject("_id");
			} else {
				recIdObject = i$res.getAsJsonObject("_id");
			}
			;
			JsonObject re$ = i$releaseLock(recIdObject);
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
		;
		return isonMsg;
	};

	@SuppressWarnings("unused")
	private JsonObject fetchTasks(JsonObject isonMsg) {
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonArray i$Roles = new JsonArray();
		String workFlowId = null;
		String userId = IResManipulator.iloggedUser.get();
		int skip = 0;
		int limit = 10;
		String WrkFlwId = null;
		int totalAppls = 0;

		int sortBy = -1;
		if (i$body.has("sortBy")) {
			sortBy = i$body.get("sortBy").getAsInt();
		}
		try {
			skip = i$body.get("intPgNo").getAsInt(); // #BVB00161
		} catch (Exception e) {
			skip = 0;
		}
		;
		try {
			limit = i$body.get("intRecs").getAsInt();// #BVB00161
		} catch (Exception e) {
			limit = 10;
		}
		;
		// #BVB00161 Starts
		try {
			if (i$body.has("WorkFlowId")) {
				workFlowId = i$body.get("WorkFlowId").getAsString();
			} else if (i$body.has("dataSetFltr")) {
				workFlowId = Im$utils
						.objFromArrWithSearch(i$ResM.getBodyElementO(isonMsg, "dataSetFltr").getAsJsonArray("data"),
								"iField", "WorkFlowId")
						.get("iValue").getAsString();
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
//		try {
//			workFlowId = i$body.get("WorkFlowId").getAsString();
//		} catch (Exception e) {
//			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
//		}
//		;
		// #BVB00161 Ends
		try {
			ArrayList<String> iRoles = new ArrayList<String>();
			ArrayList<String> iQueus = new ArrayList<String>();
			ArrayList<String> iUsrQueus = new ArrayList<String>();
			ArrayList<String> wrkFlws = new ArrayList<String>();
			i$Roles = db$Ctrl.db$GetRows("ICOR_M_USER_PRF",
					"{\"userId\":\"" + IResManipulator.iloggedUser.get() + "\"}", "{\"roles\":1}");
			if (i$Roles != null) {
				for (int i = 0; i < i$Roles.size(); i++) {
					try {
						iRoles.add(i$Roles.get(i).getAsJsonObject().get("roles").getAsString());
					} catch (Exception e) { // #00000006 | Fixes for defect ID 285 starts
						JsonObject irole = new JsonObject();
						irole = i$Roles.get(i).getAsJsonObject();
						JsonArray irls = new JsonArray();
						irls = irole.get("roles").getAsJsonArray();
						for (int itr = 0; itr < irls.size(); itr++) {
							String abcs = irls.get(itr).getAsString(); // #00000021 change
							iRoles.add(abcs);
						}

					} // //#00000006 | Fixes for defect ID 285 Ends
				}
			}
			JsonObject act$pron = new JsonObject();
			act$pron.addProperty("userId", 1);
			act$pron.addProperty("userId", 1);
			String uid$Query = "{\"$and\":[{\"roleOrUser\":\"U\"},{\"userId\":\"" + IResManipulator.iloggedUser.get()
					+ "\"}]}";
			String proj = "{\"userId\":1,\"queueAccess\":1}";
			// #00000010 Begins
			JsonObject $proQuery = new JsonObject();
			$proQuery.addProperty("roleOrUser", "U");
			$proQuery.addProperty("userId", IResManipulator.iloggedUser.get());
			$proQuery.addProperty("active", "A");
			JsonObject usr$wrkFlow = db$Ctrl.db$GetRow("ICOR_M_QUEUE_ACC", $proQuery.toString(), proj); // #00000010
			JsonObject usr$wrkFlowAccroles = new JsonObject();
			JsonObject usr$wrkFlowAcc = new JsonObject();
			if (usr$wrkFlow != null) {
				try {
					usr$wrkFlowAccroles = usr$wrkFlow.get("queueAccess").getAsJsonObject().get(workFlowId)
							.getAsJsonObject();
					iQueus = getKeySet(usr$wrkFlowAccroles);
				} catch (Exception e) {
				}
			}
			// Get the Ques for the Workflow Ids with user ID
			String sroleMatch = null;
			for (int i = 0; i < iRoles.size(); i++) {
				if (i == 0)
					sroleMatch = "\"" + iRoles.get(i) + "\"";
				else
					sroleMatch += ",\"" + iRoles.get(i) + "\"";
			}
			;
			i$Roles = null;
			JsonArray usr$wrkFlowArray = new JsonArray();
			usr$wrkFlowAcc = new JsonObject();
			// String query1 = "{\"$and\":[{\"roleOrUser\":\"R\"},{\"roleId\":{ \"$in\": ["
			// + sroleMatch + "]}}]},{\"roleId\":1,\"queueAccess\":1}";
			if (iRoles != null) {
				usr$wrkFlowArray = db$Ctrl.db$GetRows("ICOR_M_QUEUE_ACC",
						"{\"$and\":[{\"roleOrUser\":\"R\"},{\"roleId\":{ \"$in\": [" + sroleMatch + "]}}]}",
						"{\"roleId\":1,\"queueAccess\":1}"); // #00000019 change
			}
			for (int i = 0; i < usr$wrkFlowArray.size(); i++) {
				try {
					usr$wrkFlow = usr$wrkFlowArray.get(i).getAsJsonObject();
				} catch (Exception e) {
					// pass
				}
				if (usr$wrkFlow != null) { // 00000002 changes starts
					try {
						usr$wrkFlowAcc = usr$wrkFlow.get("queueAccess").getAsJsonObject().get(workFlowId)
								.getAsJsonObject();
					} catch (Exception e) {
						// pass
					}
				} else if (!(usr$wrkFlowAccroles != null)) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"USER DOESN'T HAVE PROPER QUEUE ACCESS FOR THIS WORKFLOW");
				}
				// 00000002 Ends
				iUsrQueus = getKeySet(usr$wrkFlowAcc);
				iQueus.addAll(iUsrQueus);
			}
			String sMatchString = null;
			JsonArray inerArray = new JsonArray();
			iQueus.add(IResManipulator.iloggedUser.get());
			logger.info("Queues Are", iQueus);
			for (int i = 0; i < iQueus.size(); i++) {
				if (i == 0) {
					sMatchString = "\"" + iQueus.get(i) + "\"";
					inerArray.add(iQueus.get(i));
				} else {
					sMatchString += ",\"" + iQueus.get(i) + "\"";
					inerArray.add(iQueus.get(i));
				}
			}
			;
			String query = "{\"$and\":[{\"WorkFlowId\":\"" + workFlowId + "\"},{\"Queue\":{ \"$in\": [" + sMatchString
					+ "]}}, {\"isCurrVer\":\"Y\"}]}"; // #00000012 change
			JsonObject Proj = new JsonObject();
			if(!I$utils.$iStrFuzzyMatch(workFlowId , "IMPACTO_CUSTSVR_WORKFLOW")) {
				Proj.addProperty("TaskId", 1);
				Proj.addProperty("applicationId", 1);
				Proj.addProperty("referenceNo", 1);
				Proj.addProperty("CurrentTask", 1);
				Proj.addProperty("CurrentTskStage", 1);
				Proj.addProperty("NxtTskStage", 1);
				Proj.addProperty("WorkFlowId", 1);
				Proj.addProperty("InitiatedAt", 1);
				Proj.addProperty("createdAt", 1);
				/* Proj.addProperty("CurrentTask", 1) */;
				Proj.addProperty("Queue", 1);
				Proj.addProperty("CurrentStageName", 1);
				Proj.addProperty("InitiatedBy", 1);
//				Proj.addProperty("ScanDetails", 1);
				Proj.addProperty("TaskAssignedQueue", 1);
				Proj.addProperty("ApprovedBy", 1); // #00000007 Change
				Proj.addProperty("AuthorizedBy", 1); // #00000007 Change
				Proj.addProperty("APPROVED_BY", 1); // #00000007 Chages
				Proj.addProperty("AUTHORIZED_BY", 1); // #00000007 Change
				Proj.addProperty("OPENED_BY", 1); // #00000007 Change
				Proj.addProperty("ASSIGNED_BY", 1); // #00000007 Change
				Proj.addProperty("WIPD_BY", 1); // #00000007 Chages
				Proj.addProperty("CONVERTD_BY", 1); // #00000007 Change
				Proj.addProperty("opened", 1); // #00000007 Change
				Proj.addProperty("verificationMode", 1); // #DVJ00053 Change
				Proj.addProperty("smartphoneVerification", 1); // #YPR00085 Changes
				// #DVJ00041 Starts
				Proj.addProperty("applicantName", 1);
				Proj.addProperty("initiatorId", 1);
				Proj.addProperty("verifierId", 1);
				Proj.addProperty("initialDepositorAndOsvId", 1); // #SRM00036
				Proj.addProperty("approverId", 1);
				Proj.addProperty("approvedby", 1); //#PKY00053 changes
			        Proj.addProperty("verify", 1); //#PKY00053 changes
				Proj.addProperty("initialDepositorId", 1); 
				Proj.addProperty("paymentStatus", 1);			
				Proj.addProperty("osvId", 1);
				Proj.addProperty("completerId", 1); // #DVJ00047 Change
				// #DVJ00041 Ends
				Proj.addProperty("workedby", 1); // #00000007 Chages
				Proj.addProperty("converted", 1); // #00000007 Change
				Proj.addProperty("assigner", 1); // #00000007 Change
				Proj.addProperty("workedby", 1); // #00000007 Change
				Proj.addProperty("convertedby", 1); // #00000007 Change
				Proj.addProperty("authorizer", 1); // #00000007 Change
				//#PKY00054 starts
//				Proj.addProperty("cbsDetails.CBS_KYCMN", 1); // #00000012 change
//				Proj.addProperty("cbsDetails.CBS_ADAPTER", 1);
//				Proj.addProperty("cbsDetails.CIF_CREATION", 1);
//				Proj.addProperty("cbsDetails.CBS_CD", 1); // #YPR00062 Changes
//				Proj.addProperty("cbsDetails.ACC_CREATION", 1);
//				Proj.addProperty("cbsDetails.CBS_CUST_UPDATE", 1);
//				Proj.addProperty("cbsDetails.LEAD_CREATION", 1); //#PKY00021 changes
				//#PKY00054 Ends
				Proj.addProperty("loanProduct", 1); //SRI00035 Chnages 
				Proj.addProperty("loanProductDesc", 1); 	//SRI00035 Chnages 
				Proj.addProperty("cbsDetails", 1);
				Proj.addProperty("cif", 1); // #00000012 change
				Proj.addProperty("cbsCif", 1); // #00000012 change
				Proj.addProperty("iLeadSource", 1); // #00000012 change
				Proj.addProperty("contactDetails.branch", 1); //PKY00012 Changes
			}else {
				Proj.addProperty("TaskId", 1);
				Proj.addProperty("cif", 1);
				Proj.addProperty("applicationId", 1);
				Proj.addProperty("referenceNo", 1);
				Proj.addProperty("CurrentTask", 1);
				Proj.addProperty("CurrentTskStage", 1);
				Proj.addProperty("NxtTskStage", 1);
				Proj.addProperty("WorkFlowId", 1);
				Proj.addProperty("WRK_FLW_STAGE", 1);
				Proj.addProperty("InitiatedAt", 1);
				Proj.addProperty("verifierId", 1);
				Proj.addProperty("approverId", 1);
				Proj.addProperty("completerId", 1);
				Proj.addProperty("Queue", 1);
				Proj.addProperty("CurrentStageName", 1);
				// #DVJ00041 Starts
				Proj.addProperty("applicantName", 1);
				Proj.addProperty("initiatorId", 1);
				Proj.addProperty("ModifiedBy", 1);
				Proj.addProperty("InitiatedAt", 1);
				Proj.addProperty("criteria", 1);
				Proj.addProperty("nature", 1);
				Proj.addProperty("priority", 1);
				Proj.addProperty("status", 1);
				Proj.addProperty("type", 1);
			}
			
			// fire the query to get all the Task for the queues
			JsonObject qur$queue = new JsonObject();
			JsonObject subqry = new JsonObject();
			subqry.add("$in", inerArray);
			qur$queue.add("Queue", subqry.getAsJsonObject());
			qur$queue.addProperty("WorkFlowId", workFlowId);
			qur$queue.addProperty("isCurrVer", "Y");
			// #BVB00161 Starts
			// Data Filter Changes
			JsonObject i$Match = new JsonObject();
			Gson gson = new Gson();
			JsonObject j$DataFilter = i$genAppCtrl.get$FrmDataSetFilter(isonMsg);
			String qur$queueS = "";
			if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr"))) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, j$DataFilter.get("Invalid$Expr").getAsString());
			}
			// #NYE00015 Begin
			else if (j$DataFilter != null) {
				// Get Formated I-MATCH Dataset Filter
				i$Match = j$DataFilter;
				// query = "{$and:[ " + gson.toJson(j$DataFilter)+ " ,"+ query+ "]}";

				query = "{'$and':[ " + gson.toJson(j$DataFilter) + ",{'Queue':{ '$in': [" + sMatchString
						+ "]}}, {'isCurrVer':'Y'}]}";

				qur$queueS = "{$and:[ " + gson.toJson(qur$queue) + " ," + gson.toJson(j$DataFilter) + "]}";
			} else {
				qur$queueS = gson.toJson(qur$queue);
			}
			if (i$body.has("sortBy")) {
				sortBy = i$body.get("sortBy").getAsInt();
			}
			JsonObject sort = new JsonObject();
			sort.addProperty("_id", sortBy);
			// String sortS = gson.toJson(sort);
			// #BVB00161 Ends
			totalAppls = db$Ctrl.db$GetCountI("ICOR_IBM_PROCESS", query);
//			sort = new JsonObject();
//			sort.addProperty("_id", -1);
			JsonObject wrk$flwTasks = db$Ctrl.db$GetRows$Sort("ICOR_IBM_PROCESS", qur$queueS, Proj, skip, limit, sort); // Sort
																														// fixess
																														// //
																														// #BVB00161
			JsonObject res$blder = new JsonObject();
			res$blder.add("PaginatedApplicationsInQueue", wrk$flwTasks.get("i-body").getAsJsonArray());
			res$blder.addProperty("TotalApplsInQueue", "" + totalAppls);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
			// isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
			// wrk$flwTasks);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	};

	private JsonObject terminateTask(JsonObject isonMsg) {
		String reqObjId = null, reqKeyFld = null, workFlowId = null, currStage = null, fwdOpr = null, curQueue = null,
				nxtStgNum = null, prvStgNum = null, tskStg = null, newStgNum = null,currStageName=null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject arg$Json = new JsonObject();
		JsonObject task$Json = new JsonObject();
		JsonObject control$Json = new JsonObject();
		JsonObject app$Json = new JsonObject();
		JsonObject stg$LfeCycle = new JsonObject();
		JsonObject cur$Stage = new JsonObject();
		JsonObject fw$opr = new JsonObject();
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		;
		if (i$body.has("ReqObjId")) {
			reqObjId = i$body.get("ReqObjId").getAsString();
		} else
			reqObjId = "NULL";
		if (i$body.has("ReqKeyFld")) {
			reqKeyFld = i$body.get("ReqKeyFld").getAsString();
		}
		;
		if (i$body.has("FwdOpr")) {
			fwdOpr = i$body.get("FwdOpr").getAsString();
		}
		if (i$body.has("TaskStage")) {
			tskStg = i$body.get("TaskStage").getAsString();
		}
		if (i$body.has("CurrentStageName")) {
			currStageName = i$body.get("CurrentStageName").getAsString();
		}
		try {
			// 1. Retrieve the Controll Json from DB
			arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
			if (!(arg$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// set all prerequisite Jsons
			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
			app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(),
					"{\"$or\":[{\"" + control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"},{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}");
			if (!(app$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// 2. Get the Current Stage of the TASK from ProcessTable - IF No Record then
			// Process for INIT_STG
			task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
					"{\"$or\":[{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
							+ "{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}]}");
			if (task$Json != null) {
				currStage = tskStg;
				cur$Stage = stg$LfeCycle.get(currStage).getAsJsonObject();
				try {
					fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
				} catch (Exception e) {
				}
				try {
				} catch (Exception e) {
				}
				try {
					nxtStgNum = cur$Stage.get("NEXT_STG_NO").getAsString();
				} catch (Exception e) {
					nxtStgNum = null;
				}
				try {
					prvStgNum = cur$Stage.get("PREV_STG_NO").getAsString();
				} catch (Exception e) {
					prvStgNum = null;
				}
				try {
					newStgNum = fw$opr.get("NEW_STG").getAsString();
				} catch (Exception e) {
					newStgNum = null;
				}
				curQueue = getCurrQueue(cur$Stage, fwdOpr);
				task$Json.addProperty("Queue", "QE#DLQ");
				task$Json.addProperty("CurrentTask", fwdOpr);
				task$Json.addProperty("CurrentTskStage", currStage);
				task$Json.addProperty("CurrentStageName", fwdOpr); // #00000008 Changes
				task$Json.addProperty("NxtTskStage", nxtStgNum);
				task$Json.addProperty("PreTskStage", prvStgNum);
				task$Json.addProperty("NewTskStage", newStgNum);
				task$Json.addProperty("TerminatedBy", IResManipulator.iloggedUser.get());
				task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
				if (reqObjId != null) {
					task$Json.addProperty("O_Id", reqObjId);
				}
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORKFLOW IS NOT INITIATED YET");
			}
			// 3. Verify the user Queue Access rights for Current Task
			String iRoles = getRoles(IResManipulator.iloggedUser.get());
			if (!(db$Ctrl.db$hasQuOprRights(IResManipulator.iloggedUser.get(), workFlowId, curQueue, fwdOpr, iRoles)) ) {
				if(!(I$utils.$iStrFuzzyMatch(app$Json.get("verificationMode").getAsString(), "Smartphone")) && (I$utils.$iStrFuzzyMatch(currStageName, "VERIFY APPLICATION"))) { //#YPR validates to smartphone verify
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER DOESN'T HAVE RIGHTS");
			}
			}
			;
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			task$Json.remove("_id");
			JsonArray LatestRemarks = new JsonArray();//#SRP00052 Changes starts
			if (i$body.has("LatestRemarks")) {
				LatestRemarks = i$body.get("LatestRemarks").getAsJsonArray();
				app$Json.add("WorkFlowLatestRemarks", LatestRemarks);
				task$Json.add("latestRemarks", LatestRemarks);
			}
			// Persit the Task to I CORE IBP PROCESS Collection and
			// log the task in logger
			task$Json.addProperty("isCurrVer", "Y"); // #00000012 change
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
			task$Json.add("IsonMsg", isonMsg);
			db$Ctrl.db$InsertRow("ICOR_IBM_PROCESS_LOGGER", task$Json);
			$tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			app$Json = new JsonObject();
			// #00000024 begins
			JsonArray Remarks = new JsonArray();
			//JsonArray LatestRemarks = new JsonArray();
			if (i$body.has("Remarks")) {
				Remarks = i$body.get("Remarks").getAsJsonArray();
				app$Json.add("WorkFlowRemarks", Remarks);
			}
//			if (i$body.has("LatestRemarks")) {
//				LatestRemarks = i$body.get("LatestRemarks").getAsJsonArray();
//				app$Json.add("WorkFlowLatestRemarks", LatestRemarks);
//			}//#SRP00052 Changes End
			// #00000024 ends
			app$Json.addProperty("RecordStat", "T_TERMINATE"); // #00000008 changes
			app$Json.addProperty("WorkFlowTaskId", task$Json.get("TaskId").getAsString());
			app$Json.addProperty("WorkFlowStatus", task$Json.get("CurrentStageName").getAsString());
			app$Json.addProperty("isCurrVer", "Y");
			task$Json.remove("_id");
			db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), app$Json, $tsk$Filter);
			JsonObject ires$json = new JsonObject();
			ires$json.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			ires$json.addProperty("CurrentStageName", task$Json.get("CurrentStageName").getAsString());
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ires$json);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	};

	@SuppressWarnings("unused")
	private JsonObject fetchTask(JsonObject isonMsg) {
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		JsonObject i$body = i$ResM.getBody(isonMsg);
		String workFlowId = null, tskId = null;
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		;
		if (i$body.has("TaskId")) {
			tskId = i$body.get("ReqObjId").getAsString();
		}
		;
		try {
			JsonObject wrk$flwTask = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
					"{\"$and\":[{\"WorkFlowId\":\"" + workFlowId + "\"},{\"TaskId\":\"" + tskId + "\"}]}");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
		}
	}

	Thread triggerProcessThread = new Thread(new Runnable() {
		@Override
		public void run() {
			try {
				i$ResM.setAllGlobal(global);
				processTask(thread$isonMsg, i$ResM);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});
	private JsonObject thread$isonMpJson;

	@SuppressWarnings({ "static-access", "unused" })
	public JsonObject funcCaller(JsonArray pst$flghtOprs, JsonObject isonMsg, JsonObject app$Json) {
		String scanType = null;
		try {
			Thread.sleep(100);
			logger.debug("Thread execution is started");
			//#YPR00046 Starts
			JsonObject filterV = new JsonObject();
			filterV.addProperty("SrcID", "ImpactoCore");
			JsonObject projection = new JsonObject();
//			projection.addProperty("SDNValRequired", "1");
//			projection.addProperty("RskPrfValRequired", "1");
//			projection.addProperty("_id", "0");
			String sdnVal = "N";
			String rskPrfVal = "N";
			try {
				JsonObject srcMps = db$Ctrl.db$GetRow("ICOR_S_EXT_SRC_MAP", filterV);
				sdnVal = srcMps.get("SDNValRequired").getAsString();
				rskPrfVal = srcMps.get("RskPrfValRequired").getAsString();
			} catch(Exception e){
			}
			//#YPR00046 Ends
			JsonObject i$response = new JsonObject();
			for (int i = 0; i < pst$flghtOprs.size(); i++) {
				JsonObject flght$oprs = pst$flghtOprs.get(i).getAsJsonObject();
				JsonObject JBody = i$ResM.getBody(isonMsg);

				if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_TYPE").getAsString(), "CALLWS")) {
					// Construct argjson and call the webservice calling controller
					JsonObject args$Json = new JsonObject();
					args$Json.addProperty("unqCommID", Im$utils.generateRandomKey(12));
					args$Json.addProperty("mediaType", flght$oprs.get("MediaType").getAsString());
					args$Json.add("reqBody", flght$oprs.get("ReqBody").getAsJsonObject());
					args$Json.add("extUrl", flght$oprs.get("ExtUrl").getAsJsonObject());
					args$Json.add("headerTags", flght$oprs.get("HeaderTags").getAsJsonObject());
					if (I$utils.$iStrFuzzyMatch(flght$oprs.get("Mode").getAsString(), "Asynchrounous")) {
						i$response = i$EWslancher.ILaunchReq(args$Json);
						if (!(I$utils.$iStrFuzzyMatch(i$response.get("HTTP_STATUS").getAsString(), "OK"))) {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"ERROR IN CALLING THE EXTRNAL WEBSERVICE");
						} else {
							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
									"CALL TO EXTERNAL WEBSERVICE IS SUCCESSFUL");
						}
					}
				} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_TYPE").getAsString(), "CALLJAVA")) {
					scanType = flght$oprs.get("OPR_TYPE").getAsString();
					String ScrCtrlClass = flght$oprs.get("Controller").getAsString();
					JsonObject isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
					JsonObject isonMap = new JsonObject();
					JsonObject headerJson = new JsonObject();
					JsonObject Jbdy = new JsonObject();
					JsonObject SearchJson = new JsonObject();
					// 00000005 start
					// #DVJ00044 Starts
					if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SMS_TRIGGER")) {
						// #YPR00068 Starts
						try {
							JsonObject jBody = new JsonObject();
							String fwdOpr,CurrentStageName ;
							fwdOpr=CurrentStageName =null;
							jBody = i$ResM.getBody(isonMsg);
							if (jBody.has("FwdOpr")) {
								fwdOpr = jBody.get("FwdOpr").getAsString();
							}
							if (jBody.has("CurrentStageName")) {// #YPR00072 Changes 
								CurrentStageName = jBody.get("CurrentStageName").getAsString();
							}
							if ((I$utils.$iStrFuzzyMatch(fwdOpr, "INIT"))) {
								 if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_CIF_WFLW_NEW"))) {
//									i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#CONFIRMATIN#MAIL"); // #YPR00071 Changes 
									i$otpC.sendNotificFN(app$Json, "TMPL#TT#VERIFICATION#PENDING");   //#SRP00021 Starts
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(app$Json, "verificationMode"),"Smartphone")) {
										i$otpC.sendDeepLnk(isonMsg);
									}else if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(app$Json, "verificationMode"),"Visit Branch")) {
										i$otpC.sendNotificFN(app$Json, "TMPL#TT#INCMPLT#VISIT#BRNCH");
									}
								}
								 //MSA00017 starts
								 else if((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_PAYROLL_WORKFLOW"))){
									 i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#BACKTO#TECU#NOTIFICATION#MAIL");
								 }
								 else if((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_RE_KYC_WRKFLOW_LITE"))){
									 i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#MY#INFORMATION#NOTIFICATION#MAIL");
								 }//MSA00017 ends
								//SKP00002 Changes starts
								 else if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_FIXED_DEPOSIT_WORKFLOW"))) {  //#PKY00016 changes
									 //#PKY00045 starts
									 if(I$utils.$iStrFuzzyMatch(isonBody.get("i-body").getAsJsonObject().get("Msg_Annotation").getAsString(), "TECU_FD_SUCCESS_NOTIFICATION")) {
										 JsonObject pdfAttachment = db$Ctrl.db$GetRow("ICOR_M_PDF_TEMPLATE", "{'pdfId':'FD0004'}");
										 JsonArray attachment = new JsonArray();
										 attachment.add(pdfAttachment);
										 app$Json.add("attachment", attachment);
										 for(int j=0; j< app$Json.get("attachment").getAsJsonArray().size();j++) {
												JsonObject pdfDetails  = app$Json.get("attachment").getAsJsonArray().get(j).getAsJsonObject();
												app$Json.addProperty("pdfId", pdfDetails.get("pdfId").getAsString());
												JsonObject resp = i$pdfKeyMap.processMsg(app$Json, headerJson, isonMap);
												JsonObject Body = resp.getAsJsonObject("i-body");
												String Strbase64 = Body.get("I#FileData").getAsString();
												
												byte[] pdf = org.apache.commons.codec.binary.Base64.decodeBase64(Strbase64.getBytes());
												String strBase64 = org.apache.commons.codec.binary.Base64.encodeBase64String(pdf);
												pdfDetails.remove("template");
												pdfDetails.addProperty("docType", "application/pdf");
												pdfDetails.addProperty("fileName", pdfDetails.get("pdfName").getAsString()+".pdf");
												pdfDetails.addProperty("template", strBase64);
											}
										 i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#FD#NOTIFICATION#MAIL");
										 i$otpC.sendNotificFN(app$Json, "TMPL#TT#FD#VERIFICATION#PENDING");  //#PKY00057 changes
									 }
									 //#PKY00045 ends
									
								//SKP00002 Changes ends
								 }//#PKY00046 starts
								 else if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_LEAD_WRKFLOW"))) {
									 if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(app$Json.get("loanDetails").getAsJsonObject(),"loanProduct"),"LOC")) {
										 i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#LOC#NOTIFICATION#MAIL");
									 }else{
											i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#LOAN#NOTIFICATION#MAIL");
											i$otpC.sendNotificFN(app$Json, "TMPL#TT#LOAN#VERIFICATION#PENDING"); //#SRP00023 Start
										}
								 }//#PKY00046 ends
								 //#MVT00096 begins
								 else if((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_PAYROLL_WORKFLOW"))) {
									 i$otpC.sendNotificFN(app$Json, "TMPL#TT#PAYROL#CREATE");
								 }//#MVT00096 ends
								//#SRP00014 Starts
								else if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_CHERRY_PICKS_WORKFLOW"))) { 
									if(I$utils.$iStrFuzzyMatch(isonBody.get("i-body").getAsJsonObject().get("Msg_Annotation").getAsString(), "FCIP_APPLICATION_CREATION")) {//#PKY00058 changes
										 i$otpC.sendNotificFN(app$Json, "TMPL#TT#FCIP#SUCC");
										 i$otpC.sendNotificFN(app$Json, "TMPL#TT#FCIP#VERIFICATION#PENDING");//#PKY00058 changes
									}
									   
								 }//#SRP00014 Ends
								 //#SRP00028 Starts
								else if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_LINCU_WORKFLOW"))) {  
									if(I$utils.$iStrFuzzyMatch(isonBody.get("i-body").getAsJsonObject().get("Msg_Annotation").getAsString(), "TECU_LINCU_SUCCESS_NOTIFICATION")) {//#PKY00057 changes
								    i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#LINCU#NOTIFICATION#MAIL");
								    i$otpC.sendNotificFN(app$Json, "TMPL#TT#LINCU#VERIFICATION#PENDING"); //#PKY00057 changes
									}
									//#PKY00057 starts
							    } else if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_TATIL_INSURANCE_WORKFLOW"))) {  
									if(I$utils.$iStrFuzzyMatch(isonBody.get("i-body").getAsJsonObject().get("Msg_Annotation").getAsString(), "TECU_TATIL_VERIFICATION_PENDING")) {//#PKY00057 changes
										i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#TATIL#NOTIFICATION#MAIL"); //#PKY00060 changes
									    i$otpC.sendNotificFN(app$Json, "TMPL#TT#TATIL#VERIFICATION#PENDING"); //#PKY00057 changes
										}
								    } 
								//#PKY00057 ends
								//#SRP00028 Ends
                                else if((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_FIP_WORKFLOW"))){ //#PKY00052 changes
									if(I$utils.$iStrFuzzyMatch(isonBody.get("i-body").getAsJsonObject().get("Msg_Annotation").getAsString(), "TECU_FIP_SUCCESS_NOTIFICATION")) {
										i$otpC.sendNotificFN(app$Json, "TMPL#TT#SUCCESS#FIP#NOTIFICATION#MAIL");
										i$otpC.sendNotificFN(app$Json, "TMPL#TT#FIP#VERIFICATION#PENDING");
									}
								}
								continue;
							}else if(I$utils.$iStrFuzzyMatch(CurrentStageName, "APPROVE APPLICATION")){
								if ((I$utils.$iStrFuzzyMatch(app$Json.get("WorkFlowId").getAsString(), "IMPACTO_CIF_WFLW_NEW"))) {
//									try {
//										if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(app$Json, "paymentStatus"),"Payment Due")) {
//											i$otpC.sendNotificFN(app$Json, "TMPL#TT#MEMBR#ONBOARDED"); // #YPR00072 Changes
//										}
//									} catch (Exception e) {
//	
//									}
									try {
										if (I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isapplyForCunaInsurance").getAsString(), "Y")) {
											i$otpC.sendNotificFN(app$Json, "TMPL#TT#CUNA#SUCC"); // #YPR00076 Changes
										}
									} catch (Exception e) {
	
									}
									try {
										if (I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isapplyForClico").getAsString(), "Y")) {
											i$otpC.sendNotificFN(app$Json, "TMPL#TT#CLICO#SUCC");// #YPR00076 Changes
										}
									} catch (Exception e) {
	
									}
								}
								continue;
							}else {
								continue;
							}

						} catch (Exception e) {
							continue;
						}
						// #YPR00068 Ends
					}else if(I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_PR_CREATION")) {
						JsonObject trnData = new JsonObject();
						JsonObject filter = new JsonObject();
						JsonObject updObj = new JsonObject();
//						String creditVerified = app$Json.get("creditVerified").getAsString();
//						if(I$utils.$iStrFuzzyMatch(creditVerified, "Y")) {
//							
//						}else {
//							
//						}
						try {
							filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
							filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
							isonBody = new JsonObject();
							isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							int batchNo = I$utils.$igetRandonNum(9999);
							String branchCode = app$Json.get("creditAccNo").getAsString().substring(0, 3);
							trnData.addProperty("batchNo", batchNo + "");
							trnData.addProperty("valueDate", app$Json.get("approveDate").getAsString());
							trnData.addProperty("branchCode", branchCode);
							trnData.addProperty("currency", "TTD");
							trnData.addProperty("debitBranchCode", "100");
							trnData.addProperty("debitAccNo", "1001001451501000");
							trnData.addProperty("lcyAmount", app$Json.get("creditAmount").getAsString());
							trnData.addProperty("trnCode", "154");
							trnData.addProperty("addlText", "Successfully Processed");
							trnData.addProperty("creditBranchCode", branchCode);
							trnData.addProperty("creditAccNo", app$Json.get("creditAccNo").getAsString());
							updObj.add("trnData", trnData);
							db$Ctrl.db$UpdateRow("ICOR_C_PAYROLL_CIF_FT_COLL", updObj, filter);
							i$body.add("trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						} catch (Exception e) {

						}
					}
					// #DVJ00044 Ends
					//#PKY00069 starts
					else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SDN_SCAN") ) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						StringBuilder fullName = new StringBuilder();
						JsonObject personalInfo = app$Json.get("personalInfo").getAsJsonObject();
						if(personalInfo.has("firstName") && !I$utils.$iStrBlank(personalInfo.get("firstName").getAsString())) {
							fullName.append(personalInfo.get("firstName").getAsString());
							fullName.append(" ");
						}if(personalInfo.has("middleName") && !I$utils.$iStrBlank(personalInfo.get("middleName").getAsString())) {
							fullName.append(personalInfo.get("middleName").getAsString());
							fullName.append(" ");
						}if(personalInfo.has("lastName") && !I$utils.$iStrBlank(personalInfo.get("lastName").getAsString())) {
							fullName.append(personalInfo.get("lastName").getAsString());
						}
						SearchJson.addProperty("FullName", fullName.toString());
						SearchJson.addProperty("FName", i$ResM.getStrfromObj(personalInfo, "firstName"));
						SearchJson.addProperty("LName", i$ResM.getStrfromObj(personalInfo, "lastName"));
						StringBuilder address = new StringBuilder();
						if(personalInfo.has("permAddLine1") && !I$utils.$iStrBlank(personalInfo.get("permAddLine1").getAsString())) {
							address.append(personalInfo.get("permAddLine1").getAsString());
							address.append(" ");
						}if(personalInfo.has("permAddLine2") && !I$utils.$iStrBlank(personalInfo.get("permAddLine2").getAsString())) {
							address.append(personalInfo.get("permAddLine2").getAsString());
							address.append(" ");
						}if(personalInfo.has("permAddLine3") && !I$utils.$iStrBlank(personalInfo.get("permAddLine3").getAsString())) {
							address.append(personalInfo.get("permAddLine3").getAsString());
							address.append(" ");
						}if(personalInfo.has("permAddCity") && !I$utils.$iStrBlank(personalInfo.get("permAddCity").getAsString())) {
							address.append(personalInfo.get("permAddCity").getAsString());
							address.append(" ");
						}if(personalInfo.has("permAddState") && !I$utils.$iStrBlank(personalInfo.get("permAddState").getAsString())) {
							address.append(personalInfo.get("permAddState").getAsString());
						}
						SearchJson.addProperty("Address", address.toString());
						SearchJson.addProperty("Residence Country", i$ResM.getStrfromObj(personalInfo, "permAddCountry"));
						SearchJson.addProperty("Nationality", i$ResM.getStrfromObj(personalInfo, "permAddCountry"));
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", i$ResM.getStrfromObj(app$Json, "referenceNo"));
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", i$ResM.getStrfromObj(app$Json, "applicationId"));
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SDN_SCAN_SPOUSE")) { // #00000034
						try {
							if (I$utils.$iStrFuzzyMatch(app$Json.get("additionalDetails").getAsJsonObject().get("maritalStatus").getAsString(), "M")) {
								scanType = flght$oprs.get("OPR_NAME").getAsString();
								StringBuilder fullName = new StringBuilder();
								JsonObject additionalDetails = app$Json.get("additionalDetails").getAsJsonObject();
								JsonObject personalInfo = app$Json.get("personalInfo").getAsJsonObject();
								if(additionalDetails.has("spouseFirstName") && !I$utils.$iStrBlank(additionalDetails.get("spouseFirstName").getAsString())) {
									fullName.append(additionalDetails.get("spouseFirstName").getAsString());
									fullName.append(" ");
								}if(additionalDetails.has("spouseMiddleName") && !I$utils.$iStrBlank(additionalDetails.get("spouseMiddleName").getAsString())) {
									fullName.append(additionalDetails.get("spouseMiddleName").getAsString());
									fullName.append(" ");
								}if(additionalDetails.has("spouseSurName") && !I$utils.$iStrBlank(additionalDetails.get("spouseSurName").getAsString())) {
									fullName.append(additionalDetails.get("spouseSurName").getAsString());
								}
								SearchJson.addProperty("FullName",fullName.toString());
								SearchJson.addProperty("FName", additionalDetails.get("spouseFirstName").getAsString());
								SearchJson.addProperty("LName", additionalDetails.get("spouseSurName").getAsString());
								StringBuilder address = new StringBuilder();
								if(personalInfo.has("permAddLine1") && !I$utils.$iStrBlank(personalInfo.get("permAddLine1").getAsString())) {
									address.append(personalInfo.get("permAddLine1").getAsString());
									address.append(" ");
								}if(personalInfo.has("permAddLine2") && !I$utils.$iStrBlank(personalInfo.get("permAddLine2").getAsString())) {
									address.append(personalInfo.get("permAddLine2").getAsString());
									address.append(" ");
								}if(personalInfo.has("permAddLine3") && !I$utils.$iStrBlank(personalInfo.get("permAddLine3").getAsString())) {
									address.append(personalInfo.get("permAddLine3").getAsString());
									address.append(" ");
								}if(personalInfo.has("permAddCity") && !I$utils.$iStrBlank(personalInfo.get("permAddCity").getAsString())) {
									address.append(personalInfo.get("permAddCity").getAsString());
									address.append(" ");
								}if(personalInfo.has("permAddState") && !I$utils.$iStrBlank(personalInfo.get("permAddState").getAsString())) {
									address.append(personalInfo.get("permAddState").getAsString());
								}
								SearchJson.addProperty("Address", address.toString());
								SearchJson.addProperty("Residence Country", personalInfo.get("permAddCountry").getAsString());
								SearchJson.addProperty("Nationality", additionalDetails.get("spouseNationality").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
										app$Json.get("referenceNo").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
										app$Json.get("applicationId").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
							} else {
								continue;
							}
						} catch (Exception e) {

							continue;
						}
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SDN_SCAN_NOMINEE")) {
						try {
							if (I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject()
									.get("isnominateBenificiary").getAsString(), "Y")) {

								scanType = flght$oprs.get("OPR_NAME").getAsString();
								StringBuilder fullName  = new StringBuilder();
								JsonObject nomnationOfBenificiary = app$Json.get("nomnationOfBenificiary").getAsJsonObject();
								if(nomnationOfBenificiary.has("nomFirstName") && !I$utils.$iStrBlank(nomnationOfBenificiary.get("nomFirstName").getAsString())) {
									fullName.append(nomnationOfBenificiary.get("nomFirstName").getAsString());
									fullName.append(" ");
								}if(nomnationOfBenificiary.has("nomMiddleName") && !I$utils.$iStrBlank(nomnationOfBenificiary.get("nomMiddleName").getAsString())) {
									fullName.append(nomnationOfBenificiary.get("nomMiddleName").getAsString());
									fullName.append(" ");
								}if(nomnationOfBenificiary.has("nomLastName") && !I$utils.$iStrBlank(nomnationOfBenificiary.get("nomLastName").getAsString())) {
									fullName.append(nomnationOfBenificiary.get("nomLastName").getAsString());
								}
								SearchJson.addProperty("FullName",fullName.toString());
								SearchJson.addProperty("FName", nomnationOfBenificiary.get("nomFirstName").getAsString());
								SearchJson.addProperty("LName", nomnationOfBenificiary.get("nomLastName").getAsString());
								StringBuilder address = new StringBuilder();
								if(nomnationOfBenificiary.has("nomPermAddLine") && !I$utils.$iStrBlank(nomnationOfBenificiary.get("nomPermAddLine").getAsString())) {
									address.append(nomnationOfBenificiary.get("nomPermAddLine").getAsString());
									address.append(" ");
								}if(nomnationOfBenificiary.has("nomPermAddLine2") && !I$utils.$iStrBlank(nomnationOfBenificiary.get("nomPermAddLine2").getAsString())) {
									address.append(nomnationOfBenificiary.get("nomPermAddLine2").getAsString());
									address.append(" ");
								}if(nomnationOfBenificiary.has("nomCity") && !I$utils.$iStrBlank(nomnationOfBenificiary.get("nomCity").getAsString())) {
									address.append(nomnationOfBenificiary.get("nomCity").getAsString());
								}
								SearchJson.addProperty("Address", address.toString());
								SearchJson.addProperty("Residence Country", app$Json.get("personalInfo")
										.getAsJsonObject().get("permAddCountry").getAsString());
								SearchJson.addProperty("Nationality", app$Json.get("nomnationOfBenificiary")
										.getAsJsonObject().get("nomNationality").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
										app$Json.get("referenceNo").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
										app$Json.get("applicationId").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
							} else {
								continue;
							}
						} catch (Exception e) {

							continue;
						}
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(),"SDN_SCAN_JOINT_PARTNER")) {

						try {
							if (I$utils.$iStrFuzzyMatch(
									app$Json.get("moreInfo").getAsJsonObject().get("isJointPatner").getAsString(),
									"Y")) {
								scanType = flght$oprs.get("OPR_NAME").getAsString();
								StringBuilder fullName = new StringBuilder();
								JsonObject jointPatnerAuthorization = app$Json.get("jointPatnerAuthorization").getAsJsonObject();
								if(jointPatnerAuthorization.has("firstNamePartnerJP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("firstNamePartnerJP").getAsString())) {
									fullName.append(jointPatnerAuthorization.get("firstNamePartnerJP").getAsString());
									fullName.append(" ");
								}if(jointPatnerAuthorization.has("middleNamePartnerJP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("middleNamePartnerJP").getAsString())) {
									fullName.append(jointPatnerAuthorization.get("middleNamePartnerJP").getAsString());
									fullName.append(" ");
								}if(jointPatnerAuthorization.has("surNamePartnerJP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("surNamePartnerJP").getAsString())) {
									fullName.append(jointPatnerAuthorization.get("surNamePartnerJP").getAsString());
								}
								SearchJson.addProperty("FullName", fullName.toString());
								SearchJson.addProperty("FName", jointPatnerAuthorization.get("firstNamePartnerJP").getAsString());
								SearchJson.addProperty("LName", jointPatnerAuthorization.get("surNamePartnerJP").getAsString());
								StringBuilder address = new StringBuilder();
								if(jointPatnerAuthorization.has("permAddLine1JP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("permAddLine1JP").getAsString())) {
									address.append(jointPatnerAuthorization.get("permAddLine1JP").getAsString());
									address.append(" ");
								}if(jointPatnerAuthorization.has("permAddLine2JP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("permAddLine2JP").getAsString())) {
									address.append(jointPatnerAuthorization.get("permAddLine2JP").getAsString());
									address.append(" ");
								}if(jointPatnerAuthorization.has("permAddCityJP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("permAddCityJP").getAsString())) {
									address.append(jointPatnerAuthorization.get("permAddCityJP").getAsString());
									address.append(" ");
								}if(jointPatnerAuthorization.has("permAddStateJP") && !I$utils.$iStrBlank(jointPatnerAuthorization.get("permAddStateJP").getAsString())) {
									address.append(jointPatnerAuthorization.get("permAddStateJP").getAsString());
								}
								SearchJson.addProperty("Address", address.toString());
								SearchJson.addProperty("Residence Country", jointPatnerAuthorization.get("permAddCountryJP").getAsString());
								SearchJson.addProperty("Nationality", jointPatnerAuthorization.get("permAddCountryJP").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
										app$Json.get("referenceNo").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
										app$Json.get("applicationId").getAsString());
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
							} else {
								continue;
							}
						} catch (Exception e) {

							continue;
						} // #00000034 changes Ends
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SDN_SCAN_CLICO_BEN")) {

					    try {
					        if (I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isapplyForClico").getAsString(), "Y")) {
					            scanType = flght$oprs.get("OPR_NAME").getAsString();
					            JsonArray beneficiaryDetails = app$Json.get("clicoDeclaration").getAsJsonObject().get("beneficiaryDetails").getAsJsonArray();
					            JsonObject result$Body = new JsonObject();
					            for (int j = 0; j < beneficiaryDetails.size(); j++) {
					                int benBody = j + 1;
					                JsonObject benDetails = beneficiaryDetails.get(j).getAsJsonObject();
					                StringBuilder fullName = new StringBuilder();
					                if (benDetails.has("firstName") && !I$utils.$iStrBlank(benDetails.get("firstName").getAsString())) {
					                    fullName.append(benDetails.get("firstName").getAsString());
					                    fullName.append(" ");
					                }
					                if (benDetails.has("middleName") && !I$utils.$iStrBlank(benDetails.get("middleName").getAsString())) {
					                    fullName.append(benDetails.get("middleName").getAsString());
					                    fullName.append(" ");
					                }
					                if (benDetails.has("lastName") && !I$utils.$iStrBlank(benDetails.get("lastName").getAsString())) {
					                    fullName.append(benDetails.get("lastName").getAsString());
					                }
					                SearchJson.addProperty("FullName", fullName.toString());
					                SearchJson.addProperty("FName", benDetails.get("firstName").getAsString());
					                SearchJson.addProperty("LName", benDetails.get("lastName").getAsString());
					                StringBuilder address = new StringBuilder();
					                if (benDetails.has("addLine1") && !I$utils.$iStrBlank(benDetails.get("addLine1").getAsString())) {
					                    address.append(benDetails.get("addLine1").getAsString());
					                    address.append(" ");
					                }
					                if (benDetails.has("addCity") && !I$utils.$iStrBlank(benDetails.get("addCity").getAsString())) {
					                    address.append(benDetails.get("addCity").getAsString());
					                    address.append(" ");
					                }
					                if (benDetails.has("addState") && !I$utils.$iStrBlank(benDetails.get("addState").getAsString())) {
					                    address.append(benDetails.get("addState").getAsString());
					                }
					                SearchJson.addProperty("Address", address.toString());
					                SearchJson.addProperty("Residence Country", benDetails.get("addCountry").getAsString());
					                SearchJson.addProperty("Nationality", benDetails.get("addCountry").getAsString());
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
					                    app$Json.get("referenceNo").getAsString());
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
					                    app$Json.get("applicationId").getAsString());
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);

					                Class < ? > ctrlClass;
					                ctrlClass = Class.forName(ScrCtrlClass);
					                JsonObject result$ = null;
					                Method ctrlFunc = null;
					                ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
					                Object ctrl$Caller = ctrlClass.newInstance();
					                result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonBody, headerJson, isonMap);
					                JsonObject ires$stat = new JsonObject();
					                String istateMsg = null;
					                try {
					                    ires$stat = result$.get("i-stat").getAsJsonObject();
					                    istateMsg = ires$stat.get("i-statMsg").getAsString();
					                } catch (Exception e) {
					                    istateMsg = null;
					                }
					                if (I$utils.$iStrFuzzyMatch(istateMsg, "i-SUCC")) {
					                    JsonObject reslt$body = new JsonObject();
					                    try {
					                        reslt$body = i$ResM.getBody(result$);
					                        result$Body.add(scanType + benBody, reslt$body);
					                    } catch (Exception e) {
					                        reslt$body.addProperty("Message", "Scan Details are Not Present");
					                        result$Body.add(scanType+benBody, reslt$body);
					                    }
					                } else {
					                    JsonObject reslt$body = new JsonObject();
					                    try {
					                        reslt$body = i$ResM.getBody(result$);
					                        result$Body.add(scanType + benBody, reslt$body);
					                    } catch (Exception e) {
					                        reslt$body.addProperty("Message", "Scan Details are Not Present");
					                    }
					                }
					            }
					            ibody.add(scanType, result$Body);
					            continue;
					        } else {
					            continue;
					        }
					    } catch (Exception e) {

					        continue;
					    }
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SDN_SCAN_CUNA_BEN")) {

					    try {
					        if (I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isapplyForCunaInsurance").getAsString(), "Y")) {
					            scanType = flght$oprs.get("OPR_NAME").getAsString();
					            JsonArray beneficiaryDetails = app$Json.get("cunaInsurance").getAsJsonObject().get("beneficiaryDetails").getAsJsonArray();
					            JsonObject result$Body = new JsonObject();
					            for (int j = 0; j < beneficiaryDetails.size(); j++) {
					                int benBody = j + 1;
					                JsonObject benDetails = beneficiaryDetails.get(j).getAsJsonObject();
					                StringBuilder fullName = new StringBuilder();
					                if (benDetails.has("firstName") && !I$utils.$iStrBlank(benDetails.get("firstName").getAsString())) {
					                    fullName.append(benDetails.get("firstName").getAsString());
					                    fullName.append(" ");
					                }
					                if (benDetails.has("middleName") && !I$utils.$iStrBlank(benDetails.get("middleName").getAsString())) {
					                    fullName.append(benDetails.get("middleName").getAsString());
					                    fullName.append(" ");
					                }
					                if (benDetails.has("lastName") && !I$utils.$iStrBlank(benDetails.get("lastName").getAsString())) {
					                    fullName.append(benDetails.get("lastName").getAsString());
					                }
					                SearchJson.addProperty("FullName", fullName.toString());
					                SearchJson.addProperty("FName", benDetails.get("firstName").getAsString());
					                SearchJson.addProperty("LName", benDetails.get("lastName").getAsString());
					                StringBuilder address = new StringBuilder();
					                if (benDetails.has("address") && !I$utils.$iStrBlank(benDetails.get("address").getAsString())) {
					                	 SearchJson.addProperty("Address", benDetails.get("address").getAsString());
					                }
					                if (benDetails.has("addCountry") && !I$utils.$iStrBlank(benDetails.get("addCountry").getAsString())) {
					                	SearchJson.addProperty("Residence Country", benDetails.get("addCountry").getAsString());
					                	SearchJson.addProperty("Nationality", benDetails.get("addCountry").getAsString());
					                }
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
					                    app$Json.get("referenceNo").getAsString());
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
					                    app$Json.get("applicationId").getAsString());
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
					                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);

					                Class < ? > ctrlClass;
					                ctrlClass = Class.forName(ScrCtrlClass);
					                JsonObject result$ = null;
					                Method ctrlFunc = null;
					                ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
					                Object ctrl$Caller = ctrlClass.newInstance();
					                result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonBody, headerJson, isonMap);
					                JsonObject ires$stat = new JsonObject();
					                String istateMsg = null;
					                try {
					                    ires$stat = result$.get("i-stat").getAsJsonObject();
					                    istateMsg = ires$stat.get("i-statMsg").getAsString();
					                } catch (Exception e) {
					                    istateMsg = null;
					                }
					                if (I$utils.$iStrFuzzyMatch(istateMsg, "i-SUCC")) {
					                    JsonObject reslt$body = new JsonObject();
					                    try {
					                        reslt$body = i$ResM.getBody(result$);
					                        result$Body.add(scanType + benBody, reslt$body);
					                    } catch (Exception e) {
					                        reslt$body.addProperty("Message", "Scan Details are Not Present");
					                        result$Body.add(scanType+benBody, reslt$body);
					                    }
					                } else {
					                    JsonObject reslt$body = new JsonObject();
					                    try {
					                        reslt$body = i$ResM.getBody(result$);
					                        result$Body.add(scanType + benBody, reslt$body);
					                    } catch (Exception e) {
					                        reslt$body.addProperty("Message", "Scan Details are Not Present");
					                    }
					                }
					            }
					            ibody.add(scanType, result$Body);
					            continue;
					        } else {
					            continue;
					        }
					    } catch (Exception e) {

					        continue;
					    }//#PKY00069 ends
					}else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "RE_SDN_SCAN")) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject cif$json = new JsonObject();
						String cif = null;
						try {
							// Sdn Re Scan Changes
							SearchJson.addProperty("FullName",
									app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString()
											+" "+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
													.getAsString());
							SearchJson.addProperty("FName",
									app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString());
							SearchJson.addProperty("LName",
									app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
							SearchJson.addProperty("Address", app$Json.get("personalInfo").getAsJsonObject()
									.get("mailAddLine1").getAsString() + ","
									+ app$Json.get("personalInfo").getAsJsonObject().get("mailAddLine2").getAsString()
									+ ","
									+ app$Json.get("personalInfo").getAsJsonObject().get("mailAddLine3").getAsString()
									+ ","
									+ app$Json.get("personalInfo").getAsJsonObject().get("mailAddLine4").getAsString());
							SearchJson.addProperty("Residence Country",
									app$Json.get("personalInfo").getAsJsonObject().get("permAddCountry").getAsString());
							SearchJson.addProperty("Nationality",
									app$Json.get("personalInfo").getAsJsonObject().get("permAddCountry").getAsString());

							// SDN re Scan Change ends
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
									app$Json.get("applicationId").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						}
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "ACC_SDN_SCAN")) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject cif$json = new JsonObject();
						String filter = "{\"CustomerId\":\""
								+ app$Json.get("trnData").getAsJsonObject().get("cif").getAsString() + "\"}";
						cif$json = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter);
						SearchJson.addProperty("FullName", cif$json.get("CustomerFullName").getAsString());
						SearchJson.addProperty("FName", cif$json.get("CustomerFirstName").getAsString());
						SearchJson.addProperty("LName", cif$json.get("CustomerLastName").getAsString());
						SearchJson.addProperty("Address", cif$json.get("AddressForCorrespondence1").getAsString());
						SearchJson.addProperty("Residence Country",
								cif$json.get("CustomerExposureCountry").getAsString());
						SearchJson.addProperty("Nationality", cif$json.get("CustomerNationality").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
								app$Json.get("referenceNo").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
								app$Json.get("applicationId").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "Sdn_List_Id", "OFAC_SDN_CSV");
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ScanType", "24-01-1935");
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "searchFields", SearchJson);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "DEDUPE")) {
						try {
							scanType = flght$oprs.get("OPR_NAME").getAsString();
							// Build i-body for DeDupe
							String deDupeChkId = flght$oprs.get("deDupCheckId").getAsString();
							SearchJson = new JsonObject();
							SearchJson.addProperty("CustomerEmailId",i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "emailId"));
							SearchJson.addProperty("CustomerFirstName",i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "firstName")); // #YPR00067 changes
							SearchJson.addProperty("CustomerMiddleName",i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "middleName")); // #YPR00067 changes
							SearchJson.addProperty("CustomerLastName",i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "lastName"));  // #YPR00067 changes
							SearchJson.addProperty("CustomerMobileIsdNo",i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "mobileISD").replace("+",""));
							SearchJson.addProperty("CustomerMobileId",i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "mobileNumber"));
							// Change begins
							SearchJson.addProperty("CustomerDriversPermitNo", "");
							SearchJson.addProperty("CustomerPassportNo", "");
							SearchJson.addProperty("CustomerNationalId", "");
							try {
								SearchJson.addProperty("CustomerBirthCertNo", app$Json.get("additionalDetails")
										.getAsJsonObject().get("birthCertificatePinNo").getAsString());
							} catch (Exception e) {
								SearchJson.addProperty("CustomerBirthCertNo", "");
							}
							try {
								SearchJson.addProperty("CustomerBcIssueCountry", app$Json.get("additionalDetails")
										.getAsJsonObject().get("birthCertIssuingCountry").getAsString());
							} catch (Exception e) {
								SearchJson.addProperty("CustomerBcIssueCountry", "");
							}
							try {
								if (I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject().get("priDocName").getAsString(), "Drivers Permit")) {
									SearchJson.addProperty("CustomerDriversPermitNo", app$Json.get("personalInfo").getAsJsonObject().get("priDocId").getAsString());								
								} else if (I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject().get("priDocName").getAsString(), "National Id")) {
									SearchJson.addProperty("CustomerNationalId", app$Json.get("personalInfo").getAsJsonObject().get("priDocId").getAsString());
								} else if (I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject().get("priDocName").getAsString(), "Passport")) {
									SearchJson.addProperty("CustomerPassportNo", app$Json.get("personalInfo").getAsJsonObject().get("priDocId").getAsString());
								}
							} catch (Exception e) {}
							try {
								if (I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject().get("secDocName").getAsString(), "Drivers Permit")) {
									SearchJson.addProperty("CustomerDriversPermitNo", app$Json.get("personalInfo").getAsJsonObject().get("secDocId").getAsString());								
								} else if (I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject().get("secDocName").getAsString(), "National Id")) {
									SearchJson.addProperty("CustomerNationalId", app$Json.get("personalInfo").getAsJsonObject().get("secDocId").getAsString());
								} else if (I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject().get("secDocName").getAsString(), "Passport")) {
									SearchJson.addProperty("CustomerPassportNo", app$Json.get("personalInfo").getAsJsonObject().get("secDocId").getAsString());
								}
							} catch (Exception e) {}
							// Change Ends
							SearchJson.addProperty("CustomerDobDate", Im$utils.dateFormatter(
									app$Json.get("personalInfo").getAsJsonObject().get("dob").getAsString())); // #BVB00185
																												// Added
																												// formatter
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
									app$Json.get("applicationId").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "deDupCheckId", deDupeChkId);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "request", SearchJson);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
						} catch (Exception e) {
							// pass
						}
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "ACC_DEDUPE")) { // #00000014
						try {
							scanType = flght$oprs.get("OPR_NAME").getAsString();
							// Build i-body for DeDupe
							String deDupeChkId = flght$oprs.get("deDupCheckId").getAsString();
							SearchJson = new JsonObject();
							SearchJson.addProperty("CustNo",
									app$Json.get("trnData").getAsJsonObject().get("cif").getAsString());
							SearchJson.addProperty("CustomerAccountClass",
									app$Json.get("trnData").getAsJsonObject().get("accountClass").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
									app$Json.get("applicationId").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "deDupCheckId", deDupeChkId);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "request", SearchJson);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
						} catch (Exception e) {
							// pass
						} // #00000014 Ends.
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "RiskProfiling") && !I$utils.$iStrFuzzyMatch(rskPrfVal, "N")) { //#YPR00046 Changes
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo",
								app$Json.get("referenceNo").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId",
								app$Json.get("applicationId").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "modelType", "TECU_RP"); // #00000016 change
						// #BVB00090 Starts
						// Creating Datasheet
						JsonObject i$datasheet = new JsonObject();
						try {
							int transaction = app$Json.getAsJsonObject("questionary").get("transaction").getAsInt();
							if(transaction < 0) {
								transaction = 0;
							} else if(transaction > 10000) {
								transaction = 10000;	
							}
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Transaction", transaction);
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Transaction", 11);
						}						
						try {
							int highRiskTransaction = app$Json.getAsJsonObject("questionary").get("highRiskTransaction").getAsInt();
							if(highRiskTransaction < 0) {
								highRiskTransaction = 0;
							} else if(highRiskTransaction > 10000) {
								highRiskTransaction = 10000;	
							}
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "High_Risk_Transaction", highRiskTransaction);							
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "High_Risk_Transaction", 3);
						}						
						try {
							//if KYC appln, new member
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "New Member");
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "New Member");
						}					
						try {
							String geoOrigin = app$Json.getAsJsonObject("additionalDetails").get("birthCountryDesc").getAsString();
							if(db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Geographic_Origin','formulaRating.value':{'$regex' : '^"+geoOrigin+"$','$options' : 'i'}}") > 0) {
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", app$Json.getAsJsonObject("additionalDetails").get("birthCountryDesc").getAsString());
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
						}					
						try {
							String geoLoc = app$Json.getAsJsonObject("personalInfo").get("permAddCity").getAsString() + ", " + app$Json.getAsJsonObject("personalInfo").get("permAddState").getAsString();
							if(db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Geographic_Location','formulaRating.value':{'$regex' : '^"+geoLoc+"$','$options' : 'i'}}") > 0) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", geoLoc);
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");
						}					
						try {
							String businessNature = app$Json.getAsJsonObject("employment").get("occupation").getAsString();
							if(db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Nature_of_Business','formulaRating.value':{'$regex' : '^"+businessNature+"$','$options' : 'i'}}") > 0) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", businessNature);
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", "Other");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", "Other");
						}					
						try {
							String occupation = app$Json.getAsJsonObject("employment").get("occupation").getAsString();
							if(db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Occupation','formulaRating.value':{'$regex' : '^"+occupation+"$','$options' : 'i'}}") > 0) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", occupation);
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
						}				
						try {
							Boolean fixedDepositInterested = true;
							try {
								if (I$utils.$iStrFuzzyMatch(app$Json.getAsJsonObject("questionary").get("fixedDepositInterested").getAsString(),"N"))
									fixedDepositInterested = false;
							} catch (Exception e) {}	
							if (fixedDepositInterested || I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isapplyForClico").getAsString(),"Y") 
									|| I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isapplyForCunaInsurance").getAsString(),"Y")) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Insurance");
							} else if (I$utils.$iStrFuzzyMatch(app$Json.get("additionalDetails").getAsJsonObject().get("interestedInLoan").getAsString(),"Y")) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Loan");
							} else if (I$utils.$iStrFuzzyMatch(app$Json.get("moreInfo").getAsJsonObject().get("isLinCUApplication").getAsString(),"Y")) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "LINCU card");
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Insurance");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Insurance");
						}					
						try {
							if (app$Json.get("questionary").getAsJsonObject().get("dueDiligence").getAsBoolean() != true) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member unwilling or reluctant to co-operate with the Society’s due diligence process");
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member co-operative with due diligence process");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member co-operative with due diligence process");
						}						
						try {
							if (app$Json.get("questionary").getAsJsonObject().get("delegatedAutourity").getAsBoolean() == true) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity", "Transaction involves power of attorney or other form of delegated authority");
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity", "Transaction does NOT involve power of attorney or other form of delegated authority");								
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity", "Transaction does NOT involve power of attorney or other form of delegated authority");
						}					
						try {
							if (!I$utils.$iStrFuzzyMatch(app$Json.get("employment").getAsJsonObject().get("accountFunded").getAsString(),"Via Salary")) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds", "Member’s source of funds or origin of wealth is NOT easily verifiable and/or a significant portion (more than 50%) is proceeds of a cash intensive business");
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds", "Member’s source of funds or origin of wealth is easily verifiable and is not proceeds of a cash intensive business");							
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds", "Member’s source of funds or origin of wealth is easily verifiable and is not proceeds of a cash intensive business");
						}				
						try {

							JsonObject argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", "{'trnCd':'duckDuckGoSearch'}");
				            argJson.addProperty("unqCommID", Im$utils.generateRandomKey());
				            argJson.add("reqBody", new JsonObject());
				            String extUrl = argJson.get("extUrl").getAsString();            
				            extUrl = extUrl.replaceAll("###IMP1###key###IMP2###", app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString()
									+" "+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
									.getAsString());
				            argJson.addProperty("extUrl", extUrl);
				            JsonObject JResp = i$EWslancher.ILaunchReq(argJson);
				            JsonArray blackListWords = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", "{'PARAM':'BlackListWords'}").getAsJsonArray("value");
				            JsonObject Res = i$webSrvc.doDuckDuckGoSearch(JResp.get("resBody").getAsString(), blackListWords);
				            if(Res.get("hits").getAsJsonArray().size()>0) {
				            	i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search", "Member is the subject of Negative News relating to criminal activities");
				            } else 
				            	i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search", "Member is NOT the subject of Negative News relating to criminal activities");
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search", "Member is NOT the subject of Negative News relating to criminal activities");
						}
												
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "dataSheet", i$datasheet);
						// #BVB00090 Ends
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
						// Build i-body for Risk Profiling
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_KYCMN")) { // #00000042
																													// change
																													// begins
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ CBS_KYCMN STARTED");

						try {
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							trnData.addProperty("fullName",
									app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
											+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
													.getAsString());
							try {	//#MVT00076 Changes starts
							trnData.addProperty("placeOfBirth", app$Json.get("personalInfo").getAsJsonObject()
									.get("placeOfBirth").getAsString());
							} catch(Exception e) {
								trnData.addProperty("placeOfBirth", "TT");
							}
							String $dob = null;
							try {
								$dob = Im$utils.dateFormatter(
										app$Json.get("personalInfo").getAsJsonObject().get("dob").getAsString());
							} catch (Exception e) {
								// pass
							}
							if ($dob != null) {
								trnData.addProperty("dob", $dob);
							} else {
								trnData.addProperty("dob", "");
							}
							try {
								trnData.addProperty("emailId",
										app$Json.get("contactDetails").getAsJsonObject().get("emailId").getAsString());
							} catch (Exception e) {
								trnData.addProperty("emailId", "");
							}
							try {
							trnData.addProperty("mobileNumber",
									app$Json.get("contactDetails").getAsJsonObject().get("mobileNumber").getAsString());
							} catch(Exception e) {
								trnData.addProperty("mobileNumber","");
							}
							try {
								trnData.addProperty("mobileISD", app$Json.get("contactDetails").getAsJsonObject()
										.get("mobileISD").getAsString());
							} catch (Exception e) {
								trnData.addProperty("mobileISD", "+1868");
							}
							if (I$utils.$iStrFuzzyMatch(
									app$Json.get("personalInfo").getAsJsonObject().get("permAddCountry").getAsString(),
									"Trinidad and Tobago")) {
								trnData.addProperty("permAddCountry", "TT"); // 00000003
							} else {
//								trnData.addProperty("permAddCountry", app$Json.get("personalInfo").getAsJsonObject()
//										.get("permAddCountry").getAsString()); // 00000004
								trnData.addProperty("permAddCountry", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "permAddCountry", "TT"));
							}
//							trnData.addProperty("employerWorkPhoneNumber",
//									app$Json.get("employment").getAsJsonObject().get("employerExtension").getAsString()
//											+ app$Json.get("employment").getAsJsonObject()
//													.get("employerWorkPhoneNumber").getAsString());
							try {
								trnData.addProperty("employerWorkPhoneNumber", app$Json.get("employment")
										.getAsJsonObject().get("employerWorkPhoneNumber").getAsString());
							} catch (Exception e) {
								trnData.addProperty("employerWorkPhoneNumber", "");
							}
							try {
								trnData.addProperty("homePhoneNumber", app$Json.get("additionalDetails")
										.getAsJsonObject().get("homePhoneNumber").getAsString());
							} catch (Exception e) {
								trnData.addProperty("homePhoneNumber", "");
							}
//							trnData.addProperty("homePhoneNumber",
//									app$Json.get("employment").getAsJsonObject().get("employerExtension").getAsString()
//											+ app$Json.get("employment").getAsJsonObject()
//													.get("employerWorkPhoneNumber").getAsString());

							try {
								trnData.addProperty("homephoneExtension", app$Json.get("additionalDetails")
										.getAsJsonObject().get("homephoneExtension").getAsString());
							} catch (Exception e) {
								trnData.addProperty("homephoneExtension", "");
							}

							try {
//							trnData.addProperty("birthCountry", app$Json.get("additionalDetails").getAsJsonObject()
//									.get("birthCountry").getAsString());
							
							trnData.addProperty("birthCountry", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "birthCountry", "TT"));					
							} catch(Exception e) {
								trnData.addProperty("birthCountry", "TT");
							}
							try {
							trnData.addProperty("mailAddCountry",
									app$Json.get("personalInfo").getAsJsonObject().get("mailAddCountry").getAsString());
							} catch(Exception e) {
								trnData.addProperty("mailAddCountry", "TT");
							} //#MVT00076 Changes
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "applicationId",
									app$Json.get("applicationId").getAsString()); // #BVB00174
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						} // #00000042 Ends
					} else if ((I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CIF_CREATION"))
							|| (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_ADAPTER"))) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						String accNumber = null;

						if (!(ifKYMSuccess(app$Json, scanType))) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "KYCMN EXCP EXC000001");
						}
						logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ CIF CREATION STARTED");
						/*
						 * CIF: 022404 (6 Digit) Account Number of above CIF: 1000224041500019 Break up
						 * of Ac no: 100(Branch Code) 022404(CIF) 150(Account Class) 0019(4 Digit)
						 */
						// Build i-body for trnData
						try {
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							// #00000042 starts
							String KYC_REF_NO = null;
							try {
								KYC_REF_NO = icbsbody.get("CBS_KYCMN").getAsJsonObject().get("KYC_REF_NO")
										.getAsString();
								trnData.addProperty("kycRefNo", KYC_REF_NO);
							} catch (Exception e) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "KYCMN EXCP EXC000001");
							}
							// #00000042 ends
							try {
								trnData.addProperty("fullName",app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString()
								+ " " + app$Json.get("personalInfo").getAsJsonObject().get("middleName").getAsString() 
								+ " " + app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
								}catch (Exception e) {
								trnData.addProperty("fullName", "");
							}
							trnData.addProperty("sName", I$utils.$igetRandonNum(9999,1000));
							trnData.addProperty("mailAddLine1", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddLine1"));
							trnData.addProperty("mailAddLine2", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddLine2"));
							trnData.addProperty("mailAddLine3", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddLine3"));
							trnData.addProperty("mailAddCity", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddCity"));
							if (I$utils.$iStrFuzzyMatch(
									app$Json.get("personalInfo").getAsJsonObject().get("mailAddCountry").getAsString(),
									"Trinidad and Tobago")) {
								trnData.addProperty("mailAddCountry", "TT"); // 00000003
							} else {
//								trnData.addProperty("mailAddCountry", app$Json.get("personalInfo").getAsJsonObject()
//										.get("mailAddCountry").getAsString()); // 00000004

								trnData.addProperty("mailAddCountry", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "mailAddCountry", "TT"));

							}
							trnData.addProperty("mailAddZipCode", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddZipCode"));

							trnData.addProperty("isMailAddrSame", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "isMailAddrSame"));
							trnData.addProperty("permAddLine1", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "permAddLine1", ""));
							trnData.addProperty("permAddLine2", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "permAddLine2", ""));
							trnData.addProperty("permAddLine3", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "permAddLine3", ""));
							trnData.addProperty("permAddLine4", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "permAddLine4", ""));
							trnData.addProperty("permAddCity", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "permAddCity", ""));
							trnData.addProperty("permAddZipCode", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddZipCode"));
							trnData.addProperty("branch",
									fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", ""));
							trnData.addProperty("firstName", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "firstName", ""));
							trnData.addProperty("middleName", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "middleName", ""));
							trnData.addProperty("lastName",
									fecthValueFormJson(app$Json.get("personalInfo").getAsJsonObject(), "lastName", ""));
							trnData.addProperty("placeOfBirth", fecthValueFormJson(
									app$Json.get("personalInfo").getAsJsonObject(), "placeOfBirth", "TT")); //#MVT00076 Changes
							String $dob = null;
							try {
								$dob = Im$utils.dateFormatter(
										app$Json.get("personalInfo").getAsJsonObject().get("dob").getAsString());
							} catch (Exception e) {
								// pass
							}
							if ($dob != null) {
								trnData.addProperty("dob", $dob);
							} else {
								trnData.addProperty("dob", ""); // #BVB00174
							}
							trnData.addProperty("methodOfCommunication", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "methodOfCommunication", ""));
							trnData.addProperty("language", "ENG");
							trnData.addProperty("emailId", fecthValueFormJson(
									app$Json.get("contactDetails").getAsJsonObject(), "emailId", ""));
							trnData.addProperty("mobileNumber", fecthValueFormJson(
									app$Json.get("contactDetails").getAsJsonObject(), "mobileNumber", ""));
							trnData.addProperty("gender",
									fecthValueFormJson(app$Json.get("personalInfo").getAsJsonObject(), "gender", ""));
							// #00000023 start
							// #BVB00213 Starts
							trnData.addProperty("mobileISD", i$ResM
									.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "mobileISD"));

							trnData.addProperty("homePhoneNumber", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "homePhoneNumber"));

							trnData.addProperty("homephoneExtension", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "homephoneExtension"));

							trnData.addProperty("custCAT", i$ResM
									.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(), "custCAT"));
							// #BVB00213 Ends
							// #00000023 ends
							trnData.addProperty("telephone",
									i$ResM.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(),
											"homephoneExtension")
											+ i$ResM.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(),
													"homePhoneNumber"));
							trnData.addProperty("currency", fecthValueFormJson(
									app$Json.get("contactDetails").getAsJsonObject(), "currency", ""));
							trnData.addProperty("custCatDesc", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "custCATDesc", ""));
							trnData.addProperty("birthCountry", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "birthCountry", "TT"));//#MVT00076 Changes
							trnData.addProperty("geoLocationDesc", fecthValueFormJson(
									app$Json.get("contactDetails").getAsJsonObject(), "geoLocationDesc", ""));
							trnData.addProperty("accClassType", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "acClassType", ""));
							trnData.addProperty("accountClass", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "accountClass", ""));
							trnData.addProperty("openDt",
									fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "openDt", ""));
							trnData.addProperty("tecuReferenceDesc", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "tecuReferenceDesc", ""));
							try {
								trnData.addProperty("interestedInLoan", app$Json.get("additionalDetails")
										.getAsJsonObject().get("interestedInLoan").getAsString());
							} catch (Exception e) {
								trnData.addProperty("interestedInLoan", "N");
							}
							trnData.addProperty("methodOfCommunicationDesc", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "methodOfCommunicationDesc")); // #BVB00211

							trnData.addProperty("interestedloanType", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "interestedloanType", ""));
							trnData.addProperty("employer",
									fecthValueFormJson(app$Json.get("employment").getAsJsonObject(), "employer", ""));
							trnData.addProperty("employerCountry", fecthValueFormJson(
									app$Json.get("employment").getAsJsonObject(), "employerCountry", "TT")); //#MVT00076 Changes
							trnData.addProperty("employerOther", fecthValueFormJson(
									app$Json.get("employment").getAsJsonObject(), "employerOther", "")); // #BVB00207
							trnData.addProperty("sectorEmployedDesc", fecthValueFormJson(
									app$Json.get("employment").getAsJsonObject(), "sectorEmployedDesc", ""));
							trnData.addProperty("employmentTypeDesc", fecthValueFormJson(
									app$Json.get("employment").getAsJsonObject(), "employmentTypeDesc", ""));
							trnData.addProperty("sectorEmployed", fecthValueFormJson(
									app$Json.get("employment").getAsJsonObject(), "sectorEmployed", ""));
							if (I$utils.$iStrFuzzyMatch(
									app$Json.get("personalInfo").getAsJsonObject().get("permAddCountry").getAsString(),
									"Trinidad and Tobago")) {
								trnData.addProperty("permAddCountry", "TT"); // 00000003
							} else {
//								trnData.addProperty("permAddCountry", app$Json.get("personalInfo").getAsJsonObject()
//										.get("permAddCountry").getAsString()); // 00000004
								
								trnData.addProperty("permAddCountry", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "permAddCountry", "TT"));
							}
							// #BVB00174 Starts

							try {
								trnData.addProperty("uidName", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "priDocName", ""));
								trnData.addProperty("uidVal", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "priDocId", ""));
								String priDocName = fecthValueFormJson(app$Json.get("personalInfo").getAsJsonObject(),
										"priDocName", "");
								String secDocName = fecthValueFormJson(app$Json.get("personalInfo").getAsJsonObject(),
										"secDocName", "");
								trnData.addProperty("prefix", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "prefix", ""));
								trnData.addProperty("uidName", fecthValueFormJson(
										app$Json.get("personalInfo").getAsJsonObject(), "priDocName", ""));
								trnData = buildIdCardDetails(app$Json, trnData);

							} catch (Exception e) {

							}
							try {
								// #BVB00195 Starts
//														String isCitizenShipofOtherCountry = app$Json.get("moreInfo").getAsJsonObject()
//																.get("isCitizenShipofOtherCountry").getAsString();
								if (!app$Json.has("fatcaDeclaration")) {
									app$Json.add("fatcaDeclaration", new JsonObject());
								}
								String isCitizenShipofOtherCountry = "N"; 
								try {
				
								isCitizenShipofOtherCountry = fecthValueFormJson(
										app$Json.get("fatcaDeclaration").getAsJsonObject(), "isCitizenOfOtherCountry",
										"");
								}catch(Exception e){
									isCitizenShipofOtherCountry = "N"; 
								}
								trnData.addProperty("isCitizenShipofOtherCountry",
										fecthValueFormJson(app$Json.get("fatcaDeclaration").getAsJsonObject(),
												"isCitizenOfOtherCountry", ""));
								// #BVB00195 Ends
								if (I$utils.$iStrFuzzyMatch(isCitizenShipofOtherCountry, "Y")) {
									trnData.addProperty("citizenShip1", fecthValueFormJson(
											app$Json.get("fatcaDeclaration").getAsJsonObject(), "fatcaCountry", "TT"));
									trnData.addProperty("citizenShip2", fecthValueFormJson(
											app$Json.get("fatcaDeclaration").getAsJsonObject(), "fatcaCountry", "TT"));
									String isUSCitizen = app$Json.get("fatcaDeclaration").getAsJsonObject()
											.get("isUSCitizen").getAsString();
									if (I$utils.$iStrFuzzyMatch(isUSCitizen, "Y")) {
										// #BVB00196 Starts

										// Prepare for Indicia
										/*
										 * 1) Any Address is US 2) Any Mobile Number 3) ARE YOU A GRANTEE OF A POWER OF
										 * ATTORNEY OR AN AUTHORISED 4) Birth Country US 5) ARE YOU A U.S. CITIZEN,
										 * RESIDENT OR GREEN CARD HOLDER? 6) ARE YOU GIVING STANDING INSTRUCTIONS FOR
										 * THE TRANSFER OF DIVIDEND
										 */

										// 2.
										if (I$utils
												.$iStrFuzzyMatch(app$Json.get("contactDetails").getAsJsonObject()
														.get("mobileISD").getAsString(), "1")
												|| I$utils.$iStrFuzzyMatch(app$Json.get("additionalDetails")
														.getAsJsonObject().get("homephoneExtension").getAsString(), "1")
												|| I$utils.$iStrFuzzyMatch(app$Json.get("additionalDetails")
														.getAsJsonObject().get("mobNo2Extension").getAsString(), "1")) {
											trnData.addProperty("usIndicia2",
													"Current US unambiguous Telephone number");
											trnData.addProperty("usIndicia", "Current US unambiguous Telephone number");
										} else {
											trnData.addProperty("usIndicia2", "");
										}

										// 1.
										if (I$utils
												.$iStrFuzzyMatch(app$Json.get("personalInfo").getAsJsonObject()
														.get("permAddCountry").getAsString(), "US")
												|| I$utils.$iStrFuzzyMatch(app$Json.get("personalInfo")
														.getAsJsonObject().get("mailAddCountry").getAsString(), "US")) {
											trnData.addProperty("usIndicia1",
													"Current US mailing/resident Address including a US post office Box");
											trnData.addProperty("usIndicia",
													"Current US mailing/resident Address including a US post office Box");
										} else {
											trnData.addProperty("usIndicia1", "");
										}

										// 3. isGranteePOA
										if (I$utils.$iStrFuzzyMatch(app$Json.get("fatcaDeclaration").getAsJsonObject()
												.get("isGranteePOA").getAsString(), "Y")) {
											trnData.addProperty("usIndicia3",
													"Currently effective Power of attorney or signator authority granted to a person with a US address");
											trnData.addProperty("usIndicia",
													"Currently effective Power of attorney or signator authority granted to a person with a US address");
										} else {
											trnData.addProperty("usIndicia3", "");
										}

										if (I$utils.$iStrFuzzyMatch(app$Json.get("fatcaDeclaration").getAsJsonObject()
												.get("isStandingInstructIncome").getAsString(), "Y")) {
											trnData.addProperty("usIndicia6",
													"Standing instructions to transafer funds to an account maintained in the US");
											trnData.addProperty("usIndicia",
													"Standing instructions to transafer funds to an account maintained in the US");
										} else {
											trnData.addProperty("usIndicia6", "");
										}

										if (I$utils.$iStrFuzzyMatch(app$Json.get("additionalDetails").getAsJsonObject()
												.get("birthCountry").getAsString(), "US")) {
											trnData.addProperty("usIndicia4", "Identification of a US place of bitrth");
											trnData.addProperty("usIndicia", "Identification of a US place of bitrth");
										} else {
											trnData.addProperty("usIndicia4", "");
										}

										if (I$utils.$iStrFuzzyMatch(app$Json.get("fatcaDeclaration").getAsJsonObject()
												.get("isUSCitizen").getAsString(), "Y")) {
											trnData.addProperty("usIndicia5",
													"Identification of account holder as US Citizen or Resident");
											trnData.addProperty("usIndicia",
													"Identification of account holder as US Citizen or Resident");
										} else {
											trnData.addProperty("usIndicia5", "");
										}

										if (!trnData.has("usIndicia")) {
											trnData.addProperty("usIndicia", "");
										}
										// #BVB00196 Ends

//																trnData.addProperty("usIndicia", app$Json.get("fatcaDeclaration")
//																		.getAsJsonObject().get("ssnNo1").getAsString());
										trnData.addProperty("tinNumber",
												i$ResM.getStrfromObj(app$Json.get("fatcaDeclaration").getAsJsonObject(),
														"ssnNo1").replace("-", ""));
									}
									// #BVB00174 Starts
									else {
										trnData.addProperty("usIndicia", "");
										trnData.addProperty("usIndicia1", "");
										trnData.addProperty("usIndicia2", "");
										trnData.addProperty("usIndicia3", "");
										trnData.addProperty("usIndicia4", "");
										trnData.addProperty("usIndicia5", "");
										trnData.addProperty("usIndicia6", "");
										trnData.addProperty("tinNumber", "");
									}
									// #BVB00174 Ends
								} else {
									trnData.addProperty("citizenShip1", "");
									trnData.addProperty("usIndicia", "");
									trnData.addProperty("usIndicia1", "");
									trnData.addProperty("usIndicia2", "");
									trnData.addProperty("usIndicia3", "");
									trnData.addProperty("usIndicia4", "");
									trnData.addProperty("usIndicia5", "");
									trnData.addProperty("usIndicia6", "");
									trnData.addProperty("tinNumber", "");
									trnData.addProperty("citizenShip2", "");
								}
								trnData.addProperty("educationCodeDesc", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "educationCodeDesc", ""));
								trnData.addProperty("educationCode", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "educationCode", ""));
								trnData.addProperty("maritalStatusDesc", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "maritalStatusDesc", ""));
								trnData.addProperty("maritalStatus", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "maritalStatus", ""));
								trnData.addProperty("spouseFullName",
										fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
												"spouseFirstName", "")
												+ " "
												+ fecthValueFormJson(
														app$Json.get("additionalDetails").getAsJsonObject(),
														"spouseSurName", ""));
								trnData.addProperty("numberOfDependent", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "numberOfDependent", ""));
								trnData.addProperty("numberOfChildren", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "numberOfChildren", ""));
								trnData.addProperty("motherMaidenName", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "motherMaidenName", ""));
								trnData.addProperty("spouseMemberOfTecu", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "spouseMemberOfTecu", ""));
								trnData.addProperty("faxNumber", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "faxNumber", ""));
								trnData.addProperty("faxNumberExtension", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "faxNumberExtension", "")); // #BVB00213
								
								if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
										"mobNo2", ""), "")) {
								trnData.addProperty("mobNo2",
										fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
												"mobNo2Extension", "")
												+ fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
														"mobNo2", ""));}
								else {
									trnData.addProperty("mobNo2",""); 
								}
								
								// #BVB00196 Starts
								trnData.addProperty("isNational", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "isNational", ""));
								String isResident = i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "isResident");
								if (I$utils.$iStrFuzzyMatch(isResident, "N")) {
									trnData.addProperty("isResident", isResident);
								} else {
									trnData.addProperty("isResident", "R");
								}
//								trnData.addProperty("isResident", fecthValueFormJson(
//										app$Json.get("additionalDetails").getAsJsonObject(), "isResident", ""));
								trnData.addProperty("nationality", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "nationality", "TT")); //#MVT00076 Changes
								// #BVB00196 Ends
								// #BVB00209 Starts
								// BUG 2122 Changes Starts #PM000107
								//trnData.addProperty("birthCertPinNo", fecthValueFormJson(
								//		app$Json.get("additionalDetails").getAsJsonObject(), "birthCertPinNo", ""));
								try {//#MVT00101 changes begins
									trnData.addProperty("birthCertificatePinNo",
											fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
													"birthCertificatePinNo", ""));
								} catch (Exception e) {
									logger.debug(e.getMessage());
								}//#MVT00101 changes ends
								// BUG 2122 Changes Ends #PM000107	 	
								trnData.addProperty("isMinor", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "isAMinor", ""));
								trnData.addProperty("guardianName", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "guardianName", "")); // #BVB00214

								trnData.addProperty("countryOfIssuance", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "countryOfIssuance", "TT")); //#MVT00076 Changes
								// #BVB00209 Ends
							} catch (Exception e) {
								e.printStackTrace();

							}
							try {
								String employmentMode = app$Json.get("employment").getAsJsonObject()
										.get("employmentMode").getAsString();

								// #BVB00213 Starts
								trnData.addProperty("employerExtension", fecthValueFormJson(
										app$Json.get("employment").getAsJsonObject(), "employerExtension", ""));
								trnData.addProperty("employerPhoneNumber", fecthValueFormJson(
										app$Json.get("employment").getAsJsonObject(), "employerWorkPhoneNumber", ""));
								trnData.addProperty("employeeNo", fecthValueFormJson(
										app$Json.get("employment").getAsJsonObject(), "employeeNo", "")); // #BVB00216

								// #BVB00213 Ends
								if (!I$utils.$iStrFuzzyMatch(employmentMode, "U")) {
									trnData.addProperty("employmentMode", employmentMode);
									trnData.addProperty("occupation", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "occupation", ""));
									trnData.addProperty("employer", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "employer", ""));
									trnData.addProperty("employerCountry", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "employerCountry", "TT")); //#MVT00076 Changes

									//#PM000105 Changes Starts
									
									trnData.addProperty("empAdd1", fecthValueFormJson(
                                            app$Json.get("employment").getAsJsonObject(), "employerAddressLine1", ""));
                                    trnData.addProperty("empAdd2", fecthValueFormJson(
                                            app$Json.get("employment").getAsJsonObject(), "employerAddressLine2", ""));
                                    trnData.addProperty("employerCity", fecthValueFormJson(
                                            app$Json.get("employment").getAsJsonObject(), "employerCity", ""));
                                    trnData.addProperty("employerCountryDesc", fecthValueFormJson(
                                            app$Json.get("employment").getAsJsonObject(), "employerCountryDesc", ""));

								/*	
									trnData.addProperty("empAdd1", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "empAdd1", ""));
								    trnData.addProperty("empAdd2", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "empAdd2", "")); 
									trnData.addProperty("employerCity", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "employerCity", "")); */
									//#PM000105 Changes Ends
									if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
											"employerWorkPhoneNumber", ""), "")) {
									trnData.addProperty("employerWorkPhoneNumber",
											fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
													"employerExtension", "")
													+ fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
															"employerWorkPhoneNumber", ""));}
									else {
										trnData.addProperty("employerWorkPhoneNumber",""); 
									}
									if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
															"employerWorkPhoneNumber2", ""), "")) {
									trnData.addProperty("employerWorkPh2",
											fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
													"employerExtension2", "")
													+ fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
															"employerWorkPhoneNumber2", ""));
									}else {
										trnData.addProperty("employerWorkPh2",""); 
									}

									//#PM000105 Changes Starts
								/*	trnData.addProperty("empAdd2", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "empAdd2", "")); */
									trnData.addProperty("employerCity", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "employerCity", ""));
									//#PM000105 Changes Ends
									if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
											"empfaxNo", ""), "")) {
									trnData.addProperty("empfaxNo",
											i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(),
													"empfaxNoExtension")
													+ i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(),
															"empfaxNo"));
									}else {
										trnData.addProperty("empfaxNo",""); 
									}
									trnData.addProperty("officialEmailId", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "officialEmailId", ""));
									trnData.addProperty("employerDesc", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "employerDesc", ""));
									trnData.addProperty("payFrequency", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "payFrequency", ""));
									trnData.addProperty("empZipCode", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "empZipCode", ""));
									// #DVJ00049 Starts
									if(app$Json.get("employment").getAsJsonObject().has("joiningDate")) {
										trnData.addProperty("joiningDate", Im$utils.dateFormatter(app$Json.get("employment").getAsJsonObject().get("joiningDate").getAsString()));
									} else {
										trnData.addProperty("joiningDate", I$utils.changeDateFormat(new Date(), "yyyy-mm-dd"));
									}
									// #DVJ00049 Ends
									trnData.addProperty("empAddDet", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "empAddDetails", ""));
									
									// trnData.addProperty("avgMonthlyIncome",
									// app$Json.get("employment").getAsJsonObject().get("avgMonthlyIncome").getAsString());
									trnData.addProperty("avgMonthlyIncomeDesc", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "avgMonthlyIncomeDesc", ""));	// #DVJ00049 Change
									trnData.addProperty("avgMonthlyIncome", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "avgMonthlyIncome"));
									trnData.addProperty("accountFunded", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "accountFunded", ""));
									trnData.addProperty("enterSourceAccountFunded",
											fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
													"enterSourceAccountFunded", ""));
									// #DVJ00049 Starts
									trnData.addProperty("salary",
											fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
													"salary", "")); //#PM000105 Changes
									// #DVJ00049 Ends
								} else {
									trnData.addProperty("employmentMode", employmentMode);
									trnData.addProperty("occupation", "");
									trnData.addProperty("employer", "");
									trnData.addProperty("employerCountry", "TT"); //#MVT00076 Changes
									trnData.addProperty("empAdd1", "");
									trnData.addProperty("empAdd2", ""); //#PM000105 Changes
									trnData.addProperty("employerCity", ""); //#PM000105 Changes
									trnData.addProperty("employerWorkPhoneNumber", "");
									trnData.addProperty("employerCountryDesc", ""); //#PM000105 Changes
									trnData.addProperty("empfaxNo", "");
									trnData.addProperty("officialEmailId", "");
									trnData.addProperty("employerDesc", "");
									trnData.addProperty("payFrequency", "");
									trnData.addProperty("empZipCode", "");
									trnData.addProperty("joiningDate", "");
									trnData.addProperty("empAddDet", "");
									// trnData.addProperty("avgMonthlyIncome",
									// app$Json.get("employment").getAsJsonObject().get("avgMonthlyIncome").getAsString());
									trnData.addProperty("avgMonthlyIncome", ""); // Temp need to change
									trnData.addProperty("avgMonthlyIncomeDesc", "");
									trnData.addProperty("accountFunded", "");
									trnData.addProperty("enterSourceAccountFunded", "");
									trnData.addProperty("salary", "");
									trnData.addProperty("employerWorkPh2","");
								}
							} catch (Exception e) {

							}

							try {
								String isJointPatner = app$Json.get("moreInfo").getAsJsonObject().get("isJointPatner")
										.getAsString();
								trnData.addProperty("isJointPatner", isJointPatner);
								if (!I$utils.$iStrFuzzyMatch(isJointPatner, "N")) { //#MVT00111 changes begins
									try {
									trnData.addProperty("FullNameJP",
											fecthValueFormJson(app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
													"firstNamePartnerJP", "")
													+ " "
													+ fecthValueFormJson(
															app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
															"surNamePartnerJP", "")); // #PM000105
									} catch(Exception e) {
										trnData.addProperty("FullNameJP","");
									}
									try {
										trnData.addProperty("firstNamePartnerJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"firstNamePartnerJP", ""));
									} catch (Exception e) {
										trnData.addProperty("firstNamePartnerJP", "");
									}
									try {
										trnData.addProperty("surNamePartnerJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"surNamePartnerJP", ""));
									} catch (Exception e) {
										trnData.addProperty("surNamePartnerJP", "");
									}
									try {
										trnData.addProperty("permAddLine1JP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"permAddLine1JP", ""));
									} catch (Exception e) {
										trnData.addProperty("permAddLine1JP", "");
									}
									try {
										trnData.addProperty("permAddLine2JP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"permAddLine2JP", ""));
									} catch (Exception e) {
										trnData.addProperty("permAddLine2JP", "");
									}
									try {
										trnData.addProperty("permAddCityJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"permAddCityJP", "")); // #BVB00209
									} catch (Exception e) {
										trnData.addProperty("permAddCityJP", "");
									}
									try {
										trnData.addProperty("permAddCountryJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"permAddCountryJP", ""));
									} catch (Exception e) {
										trnData.addProperty("permAddCountryJP", "");
									}
									try {
										trnData.addProperty("permAddZipCodeJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"permAddZipCodeJP", ""));
									} catch (Exception e) {
										trnData.addProperty("permAddZipCodeJP", "");
									}

									try {
										trnData.addProperty("customerPassportNoJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerPassportNoJP", ""));
									} catch (Exception e) {
										trnData.addProperty("customerPassportNoJP", "");
									}
									try {
										trnData.addProperty("passportIssueDateJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"passportIssueDateJP", ""));
									} catch (Exception e) {
										trnData.addProperty("passportIssueDateJP", "");
									}

									try {
										trnData.addProperty("passportExpiryDateJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"passportExpiryDateJP", ""));
									} catch (Exception e) {
										trnData.addProperty("passportExpiryDateJP", "");
									}
									//PIYUSH CHANGES STARTS
									
									try {
										trnData.addProperty("passportIssuedCountryJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"passportIssuedCountryJP", ""));
									} catch (Exception e) {
										trnData.addProperty("passportIssuedCountryJP", "");
									}
									
									try {
										trnData.addProperty("customerDPNoJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerDriversPermitNoJP", ""));
									} catch (Exception e) {
//										trnData.addProperty("customerDriversPermitNoJP", "");
										 trnData.addProperty("customerDPNoJP", "");
									}
									try {
										trnData.addProperty("customerDpIssueDateJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerDpIssueDateJP", ""));
									} catch (Exception e) {
										trnData.addProperty("customerDpIssueDateJP", "");
									}

									try {
										trnData.addProperty("customerDpExpiryDateJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerDpExpiryDateJP", ""));
									} catch (Exception e) {
										trnData.addProperty("customerDpExpiryDateJP", "");
									}
								
									try {
										trnData.addProperty("customerDpIssuedCountryJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerDpIssuedCountryJP", ""));
									} catch (Exception e) {
										trnData.addProperty("customerDpIssuedCountryJP", "");
									}	

									try {
										trnData.addProperty("customerNationalIdJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerNationalIdJP", ""));
									} catch (Exception e) {
										trnData.addProperty("customerNationalIdJP", "");
									}
									try {
										trnData.addProperty("pinIssDateJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"pinIssDateJP", ""));
									} catch (Exception e) {
										trnData.addProperty("pinIssDateJP", "");
									}

									try {
										trnData.addProperty("pinExpDateJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"pinExpDateJP", ""));
									} catch (Exception e) {
										trnData.addProperty("pinExpDateJP", "");
									}
								
									try {
										trnData.addProperty("idIssCountryJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"idIssCountryJP", ""));
									} catch (Exception e) {
										trnData.addProperty("idIssCountryJP", "");
									}									
									
									//PIYUSH CHANGES ENDS
									try {
										trnData.addProperty("jointPartnerMemberNumber",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"jointPartnerMemberNumber", ""));
									} catch (Exception e) {
										trnData.addProperty("jointPartnerMemberNumber", "");
									}
									try {
										trnData.addProperty("branchCodeJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"branchCodeJP", ""));
									} catch (Exception e) {
										trnData.addProperty("branchCodeJP", "");
									}
									try {
										trnData.addProperty("customerEmailIdJP",
												fecthValueFormJson(
														app$Json.get("jointPatnerAuthorization").getAsJsonObject(),
														"customerEmailIdJP", ""));
									} catch (Exception e) {
										trnData.addProperty("customerEmailIdJP", "");
									}
									trnData.addProperty("isJointPatner", "Y");
									//#MVT00111 changes ends
								} else {
									trnData.addProperty("firstNamePartnerJP", "");
									trnData.addProperty("surNamePartnerJP", "");
									trnData.addProperty("permAddLine1JP", "");
									trnData.addProperty("permAddLine2JP", "");
									trnData.addProperty("permAddCityJP", "");
									trnData.addProperty("permAddCountryJP", "");
									trnData.addProperty("permAddZipCodeJP", "");
									trnData.addProperty("customerPassportNoJP", "");
									trnData.addProperty("passportIssueDateJP", "");
									trnData.addProperty("passportExpiryDateJP", "");
									trnData.addProperty("branchCodeJP", "");
									trnData.addProperty("jointPartnerMemberNumber", "");
									trnData.addProperty("customerEmailIdJP", "");
                                    trnData.addProperty("FullNameJP", ""); //#PM000105
    								trnData.addProperty("isJointPatner", "N");
									//PIYUSH CHANGES STARTS
									trnData.addProperty("passportIssuedCountryJP", "");
									trnData.addProperty("customerDPNoJP", "");
									trnData.addProperty("customerDpIssueDateJP", "");
									trnData.addProperty("customerDpExpiryDateJP", "");
									trnData.addProperty("customerDpIssuedCountryJP", "");
									trnData.addProperty("customerNationalIdJP", "");
									trnData.addProperty("pinIssDateJP", "");
									trnData.addProperty("pinExpDateJP", "");	
									trnData.addProperty("idIssCountryJP", "");									
									//PIYUSH CHANGES ENDS

								}
							} catch (Exception e) {
								trnData.addProperty("firstNamePartnerJP", "");
								trnData.addProperty("surNamePartnerJP", "");
								trnData.addProperty("permAddLine1JP", "");
								trnData.addProperty("permAddLine2JP", "");
								trnData.addProperty("permAddCityJP", "");
								trnData.addProperty("permAddCountryJP", "");
								trnData.addProperty("permAddZipCodeJP", "");

								trnData.addProperty("customerPassportNoJP", "");
								trnData.addProperty("passportIssueDateJP", "");
								trnData.addProperty("passportExpiryDateJP", "");
								trnData.addProperty("branchCodeJP", "");
								trnData.addProperty("jointPartnerMemberNumber", "");
								trnData.addProperty("customerEmailIdJP", "");
                                trnData.addProperty("FullNameJP", ""); //#PM000105
								//PIYUSH CHANGES STARTS
								trnData.addProperty("passportIssuedCountryJP", "");
								trnData.addProperty("customerDPNoJP", "");
								trnData.addProperty("customerDpIssueDateJP", "");
								trnData.addProperty("customerDpExpiryDateJP", "");
								trnData.addProperty("customerDpIssuedCountryJP", "");
								trnData.addProperty("customerNationalIdJP", "");
								trnData.addProperty("pinIssDateJP", "");
								trnData.addProperty("pinExpDateJP", "");	
								trnData.addProperty("idIssCountryJP", "");									
								//PIYUSH CHANGES ENDS								
							}
							try {				
								String isnominateBenificiary = fecthValueFormJson(
										app$Json.get("moreInfo").getAsJsonObject(), "isnominateBenificiary", "N");
								if (!I$utils.$iStrFuzzyMatch(isnominateBenificiary, "N")) {
									try {	//#MVT00111 changes begins
									trnData.addProperty("nomFullName",
											fecthValueFormJson(app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
													"nomFirstName", "")
													+ " "
													+ fecthValueFormJson(
															app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
															"nomMiddleName", "")
													+ " "
													+ fecthValueFormJson(
															app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
															"nomLastName", "")); // #BVB00213
									} catch(Exception e) {
										trnData.addProperty("nomFullName","");
									}
//									trnData.addProperty("nomRelationMember",
//											fecthValueFormJson(app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
//													"nomRelationMember", ""));
									try {
										JsonObject nomineeBen = app$Json.get("nomnationOfBenificiary").getAsJsonObject();
										String prefix = nomineeBen.get("prefix").getAsString();

										trnData.addProperty("nomPrefix", prefix);
									} catch (Exception e) {
										trnData.addProperty("nomPrefix", "");
									}

//									trnData.addProperty("nomPrefix", i$ResM.getStrfromObj(
//											app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomPrefix"));

									try {
										trnData.addProperty("nomFirstName",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomFirstName"));
									} catch (Exception e) {
										trnData.addProperty("nomFirstName", "");
									}
									try {
										trnData.addProperty("nomMiddleName",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomMiddleName"));
									} catch (Exception e) {
										trnData.addProperty("nomMiddleName", "");
									}

									try {
										trnData.addProperty("nomLastName",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomLastName"));
									} catch (Exception e) {
										trnData.addProperty("nomLastName", "");
									}
									
									//PM000104 CHANGES STARTS		
								/*	trnData.addProperty("nomRelationMember",
											i$ResM.getStrfromObj(
													app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
													"nomRelationMember")); */
													
								trnData.addProperty("nomRelationMember","BENE"); 
										
									try {	
										String isnominateBeneOther = fecthValueFormJson(
												app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomRelationMember", "BENE");					
									
//									if (I$utils.$iStrFuzzyMatch(isnominateBeneOther, "OTHER")) {
//										trnData.addProperty("nomRemarks",
//												i$ResM.getStrfromObj(
//														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
//														"nomRelationInsuredOther"));
//									} else {
//										trnData.addProperty("nomRemarks",
//												i$ResM.getStrfromObj(
//														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
//														"nomRelationMemberDesc"));
//									}
									}
									catch(Exception e)
									{
										//pass
									}
									try { //#MVT00116 changes starts
									trnData.addProperty("nomRemarks",
											i$ResM.getStrfromObj(
													app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
													"nomBirthCertPinNo"));
									} catch(Exception e) {
										trnData.addProperty("nomRemarks","");
									}//#MVT00116 changes ends
								/*	trnData.addProperty("nomRelationMember",
											i$ResM.getStrfromObj(
													app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
													"nomRelationMember")); */
									//PM000104 CHANGES ENDS	
									try {
										trnData.addProperty("dobNomination",
												Im$utils.dateFormatter(i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"dobNomination")));
									} catch (Exception e) {
										trnData.addProperty("dobNomination", "");
									}
									try {
										trnData.addProperty("genderNomination",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"genderNomination"));
									} catch (Exception e) {
										trnData.addProperty("genderNomination", "");
									}

									try {
										trnData.addProperty("nomPermAddLine",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomPermAddLine"));
									} catch (Exception e) {
										trnData.addProperty("nomPermAddLine", "");
									}
									try {
										trnData.addProperty("nomPermAddLine1",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomPermAddLine1"));
									} catch (Exception e) {
										trnData.addProperty("nomPermAddLine1", "");
									}
									try {
										trnData.addProperty("nomPermAddLine2",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomPermAddLine2"));
									} catch (Exception e) {
										trnData.addProperty("nomPermAddLine2", "");
									}
									try {
									trnData.addProperty("nomPermAddLine3",
											i$ResM.getStrfromObj(
													app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
													"nomPermAddLine3"));
									} catch(Exception e) {
										trnData.addProperty("nomPermAddLine3", "");
									}
									try {
									trnData.addProperty("nomCity",
											i$ResM.getStrfromObj(
													app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
													"nomCity"));
									} catch(Exception e) {
										trnData.addProperty("nomCity", "");
									}
									try {
										trnData.addProperty("nomNationality",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomNationality"));
									} catch (Exception e) {
										trnData.addProperty("nomNationality", "");
									}

									try {
										trnData.addProperty("nomEmailId",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomEmailId"));
									} catch (Exception e) {
										trnData.addProperty("nomEmailId", "");
									}

//									try {
//										trnData.addProperty("nomPrefix", i$ResM.getStrfromObj(
//												app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomPrefix"));
//									} catch (Exception e) {
//										trnData.addProperty("nomPrefix", "");
//									}
									
									try {
										trnData.addProperty("nomMobNo",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomMobNoExtension")
														+ i$ResM.getStrfromObj(app$Json.get("nomnationOfBenificiary")
																.getAsJsonObject(), "nomMobNo"));
									} catch (Exception e) {
										trnData.addProperty("nomMobNo", "");
									}
									try {
										trnData.addProperty("nomHomePhone",
												i$ResM.getStrfromObj(
														app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
														"nomHomePhoneExtension")
														+ i$ResM.getStrfromObj(app$Json.get("nomnationOfBenificiary")
																.getAsJsonObject(), "nomHomePhone"));
									} catch (Exception e) {
										trnData.addProperty("nomHomePhone", "");
									}
									//#MVT00111 changes ends
									try {
										trnData = buildIdCardDetailsNom(app$Json, trnData);	//#MVT00116 changes
									} catch (Exception e) {

									}
									
									//PM000101 CHANGES STARTS
									try
									{
									 trnData.addProperty("nomDocId", i$ResM.getStrfromObj(
									 app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocId"));
									}
									catch(Exception e)
									{
										trnData.addProperty("nomDocId",""); 
									}
									try
									{
										trnData.addProperty("nomDocIssDate",
												 Im$utils.dateFormatter(i$ResM.getStrfromObj(
												 app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocIssDate")));
									}
									catch(Exception e)
									{
										trnData.addProperty("nomDocIssDate",""); 
									}
									try
									{
										trnData.addProperty("nomDocExpDate",
												 Im$utils.dateFormatter(i$ResM.getStrfromObj(
												 app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocExpDate")));
									}
									catch(Exception e)
									{
										trnData.addProperty("nomDocExpDate",""); 
									}
									try
									{
										trnData.addProperty("nomDocCountryIssue", i$ResM.getStrfromObj(
												 app$Json.get("nomnationOfBenificiary").getAsJsonObject(),
												 "nomDocCountryIssue"));
									}
									catch(Exception e)
									{
										trnData.addProperty("nomDocCountryIssue","TT"); //#MVT00076 Changes
									}
									try
									{
									 trnData.addProperty("nomDocDLId", i$ResM.getStrfromObj(
									 app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocDLId"));
									}
									catch(Exception e)
									{
										trnData.addProperty("nomDocDLId",""); 
									}
									try
									{
									 trnData.addProperty("nomDocNaId", i$ResM.getStrfromObj(
									 app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocNaId"));
									}
									catch(Exception e)
									{
										trnData.addProperty("nomDocNaId",""); 
									}
									//PM000101 CHANGES ENDS
								} else {
									trnData.addProperty("nomFullName", "");
									trnData.addProperty("nomRelationMember", "");
									trnData.addProperty("nomFirstName", "");
									trnData.addProperty("nomMiddleName", "");
									trnData.addProperty("nomLastName", "");
									trnData.addProperty("dobNomination", "");
									trnData.addProperty("genderNomination", "");
									trnData.addProperty("nomPermAddLine", "");
									trnData.addProperty("nomPermAddLine2", "");
									trnData.addProperty("nomPermAddLine3", "");
									trnData.addProperty("nomCity", "");
									trnData.addProperty("nomNationality", "TT"); //#MVT00076 Changes
									trnData.addProperty("nomEmailId", "");
									trnData.addProperty("nomDocIssDate", "");
									trnData.addProperty("nomDocExpDate", "");
									trnData.addProperty("nomDocCountryIssue", "TT"); //#MVT00076 Changes
									trnData.addProperty("nomDocId", "");
									trnData.addProperty("nomPrefix", "");
									trnData.addProperty("nomMobNo", "");
									trnData.addProperty("nomDocNaId", "");
									trnData.addProperty("nomDocDLId", "");
									trnData.addProperty("nomDocId", "");
									trnData.addProperty("nomDocIssDate", "");
									trnData.addProperty("nomDocExpDate", "");
									trnData.addProperty("nomDocCountryIssue", "TT");
									trnData.addProperty("nomMobNo", "");
									trnData.addProperty("nomHomePhone", "");
									trnData.addProperty("nomRemarks", ""); //PM000104 Changes

								}
							} catch (Exception e) {
								trnData.addProperty("nomFullName", "");
								trnData.addProperty("nomRelationMember", "");
								trnData.addProperty("nomFirstName", "");
								trnData.addProperty("nomMiddleName", "");
								trnData.addProperty("nomLastName", "");
								trnData.addProperty("dobNomination", "");
								trnData.addProperty("genderNomination", "");
								trnData.addProperty("nomPermAddLine", "");
								trnData.addProperty("nomPermAddLine2", "");
								trnData.addProperty("nomPermAddLine3", "");
								trnData.addProperty("nomNationality", "");
								trnData.addProperty("nomEmailId", "");
								trnData.addProperty("nomDocIssDate", "");
								trnData.addProperty("nomDocExpDate", "");
								trnData.addProperty("nomDocCountryIssue", "");
								trnData.addProperty("nomDocId", "");
								trnData.addProperty("nomPrefix", "");
								trnData.addProperty("nomDocNaId", "");
								trnData.addProperty("nomDocDLId", "");
								trnData.addProperty("nomDocId", "");
								trnData.addProperty("nomDocIssDate", "");
								trnData.addProperty("nomDocExpDate", "");
								trnData.addProperty("nomDocCountryIssue", ""); 
								trnData.addProperty("nomMobNo", "");
								trnData.addProperty("nomHomePhone", "");
								trnData.addProperty("nomRemarks", ""); //PM000104 Changes
							}
							// #BVB00209 Starts
							// Recommender Details
							
							try {

				                if (I$utils.$iStrFuzzyMatch(fecthValueFormJson(
				                    app$Json.get("moreInfo").getAsJsonObject(), "isRecommmendation", ""), "Y")) {
				                    trnData.addProperty("recMemNo", fecthValueFormJson(
				                    app$Json.get("recommenderDetails").getAsJsonObject(), "recMemNo", ""));
				                    trnData.addProperty("isRecommmendation", ""); //#PM000103 Changes
				                } else {
				                  trnData.addProperty("recMemNo", "");
				                  //#PM000103 Changes
				                  trnData.addProperty("isRecommmendation", fecthValueFormJson(
				                      app$Json.get("recommenderDetails").getAsJsonObject(), "isRecommmendation", ""));
				                }
				              } catch (Exception e) {
				                trnData.addProperty("recMemNo", "");
				                trnData.addProperty("isRecommmendation", ""); //#PM000103 Changes
				              }
							
	                                           	// Udf Data
							try {
								trnData.addProperty("iambCheckerId", app$Json.get("approverId").getAsString()); //#PM000102 CHANGES 
								//#PM000106 CHANGES STARTS
							//	trnData.addProperty("iambMakerId", app$Json.get("osvId").getAsString()); //#PM000102 CHANGES
							    trnData.addProperty("iambMakerId", app$Json.get("verifierId").getAsString()); 
								//#PM000106 CHANGES ENDS
								//PM000102 Changes Starts
							//	trnData.addProperty("iambMakerDt", app$Json.get("createdAt").getAsString());
							//	trnData.addProperty("iambCheckerDt", i$ResM.getdateTime(new Date()));
								
								String $makerdt = null;
								try {
									$makerdt = Im$utils.dateFormatter(app$Json.get("createdAt").getAsString());
								} catch (Exception e) {
									// pass
								}
								if ($makerdt != null) {
									trnData.addProperty("iambMakerDt", $makerdt);
								} else {
									trnData.addProperty("iambMakerDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd"));
								} 
									trnData.addProperty("iambCheckerDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd"));
									//PM000102 Changes Ends


							} catch (Exception e) {
								trnData.addProperty("iambCheckerId", "");
								trnData.addProperty("iambMakerId", "");
								trnData.addProperty("iambMakerDt", "");
								trnData.addProperty("iambCheckerDt", "");

							}
							// #BVB00209 Ends
							// Default Empty values as not available

							// trnData.addProperty("birthCertPinNo", "");
							// trnData.addProperty("birthCertiCntry", "");
							// trnData.addProperty("isMinor", "N");
							trnData.addProperty("applicationId", app$Json.get("applicationId").getAsString());
							trnData.addProperty("onbehalftecue", fecthValueFormJson( //#MVT00110 changes
					                    app$Json.get("recommenderDetails").getAsJsonObject(), "onbehalftecue", ""));
//							trnData.addProperty("onbehalftecue", app$Json.get("applicationId").getAsString());
							trnData = refineIsdCodes(trnData);
							// #BVB00174
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "applicationId",
									app$Json.get("applicationId").getAsString()); // #BVB00174
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						} catch (Exception e) {
							logiCbsBody(app$Json, "CIF_CREATION", "N");
							continue;
						}
					}else if(I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "DOCS_UPLOAD")) {
						JsonObject i$body = new JsonObject();
						i$body = isonBody.get("i-body").getAsJsonObject();
						String cif = null;
//						JsonObject cifCreation = new JsonObject();
//						JsonObject cbsMsg = new JsonObject();
//						cbsMsg.addProperty("cbsMsg1", "ST-SAVE-002Record Successfully Saved and Authorized");
//						cbsMsg.addProperty("cbsMsg2", "");
//						cbsMsg.add("cbsMsg3", null);
//						cbsMsg.add("cbsMsg4", null);
//						cbsMsg.add("cbsMsg5", null);
//						cifCreation.addProperty("CIF", "114430");
//						cifCreation.addProperty("NAME", "IVANA DIAS");
//						cifCreation.addProperty("ACCOUNT", "1001144301510013");
//						cifCreation.add("cbsMsg", cbsMsg);
//						cifCreation.addProperty("unqCommID", "eb80f291-72e1-4dba-b28c-d7b7baad292e20210331162948838");
//						cifCreation.addProperty("message", "i-SUCC");
//						cifCreation.addProperty("applicationId", "MA100121083000014470");
//						cifCreation.addProperty("referenceNo", "HoF2baAOZeQGpdAZBuQs3Z75uR1zyQG2o4NhYXNfQOnpikU004470");
//						icbsbody.add("CIF_CREATION", cifCreation);
						try {
							cif = icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString();
						} catch (Exception e) {
						}
						if (ifCifSuccess(app$Json, scanType)) {
							try {
								JsonObject cifData = new JsonObject();
								JsonObject cifObj = new JsonObject();
								JsonObject query = new JsonObject();
								JsonObject jWrkArgs = new JsonObject();
								String applicationId = isonMsg.get("i-body").getAsJsonObject().get("applicationId")
										.getAsString();
								query.addProperty("applicationId", applicationId);
								JsonObject applnData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", query);
								cifObj.addProperty("cifId", cif);
								cifObj.addProperty("seqName", "SEQ#CIFAPPL");
								cifObj.addProperty("seqNo", applicationId);
								cifObj.addProperty("cifCreated", true);
								cifObj.addProperty("tranId", "");
								cifObj.addProperty("cntCode",
										applnData.get("prerequisites").getAsJsonObject().get("country").getAsString());
								JsonObject personalDetails = applnData.get("personalDetails").getAsJsonObject();
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, cifObj);
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "CIF GENERATED SUCCESS");
								JsonObject folderData = i$foldersctrl.addFoldrAPI(isonMsg);
								i$body.add("folderData", folderData);
								i$body.addProperty("applicationId", applicationId);
								i$body.addProperty("cifId", cif);
								i$body.addProperty("cntCode",
										applnData.get("prerequisites").getAsJsonObject().get("country").getAsString());
								i$body.addProperty("typeOfProduct",
										fecthValueFormJson(personalDetails, "openingAccountReason", ""));
								i$body.addProperty("accNo", icbsbody.get("CIF_CREATION").getAsJsonObject().get("ACCOUNT").getAsString());
								i$body.addProperty("referenceNo", fecthValueFormJson(applnData, "referenceNo", ""));
								isonBody = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, "i-body", i$body);
								jWrkArgs.add("isonMsg", isonBody.deepCopy());
								jWrkArgs.addProperty("clsName",
										"net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController");
								jWrkArgs.addProperty("funcName", "documentDownload");

								IThreadController IThread$worker = new IThreadController(jWrkArgs);
								Thread t = new Thread(IThread$worker);
								// threads Started
								t.start();
							}catch(Exception e) {}
							
						}//TKS00010 ends
					}
					else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_CD")) { // #YPR00062 Starts

						scanType = flght$oprs.get("OPR_NAME").getAsString();
						
						if (!(ifCifSuccess(app$Json, scanType))) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CD EXCP EXC000001");
						}
						logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ CASH DEPOSIT STARTED");

						try {
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							String date = "";
							String offsetAccType = "";
							String offsetAcc = "";
							JsonObject filter = new JsonObject();
							JsonObject proj = new JsonObject();
							JsonArray cbsData = new JsonArray();

							try {
								// Have to get the data from E - Data collection
//								filter.addProperty("BranchCode", fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", ""));
								filter.add("$or", i$ResM.getJsonArr("[{'$and':[{'Type':'CBS_BRANCH','BranchCode':'"+fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", "")+"'}]}, {'$and':[{'Type':'CBS_INITIAL_CD','KeyId':'"+fecthValueFormJson(app$Json, "paymentVia", "")+"'}]}]"));
								cbsData = db$Ctrl.db$GetRows("ICOR_M_CBS_E_DATA", filter,proj);
								
								for(int r=0;r<cbsData.size();r++) {
									JsonObject isrunningObj = cbsData.get(r).getAsJsonObject();
									if(isrunningObj.has("BranchDate")) {
								      date =isrunningObj.get("BranchDate").getAsString();
									}else {
										offsetAccType = isrunningObj.get("Acctype").getAsString();
										offsetAcc = isrunningObj.get("AcGlNo").getAsString();
									}
									
								}
								date = Im$utils.trimDate(date);
							} catch (Exception e) {
								date = null;
							}
							trnData.addProperty("fullName",
									app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
											+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
													.getAsString());
							trnData.addProperty("trnBrn",fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", ""));
							trnData.addProperty("branchCode",fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", ""));
							trnData.addProperty("currency", fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "currency", ""));
							trnData.addProperty("offsetCcy", fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "currency", ""));
							trnData.addProperty("creditBranchCode", fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", ""));
							trnData.addProperty("creditAccNo", fecthValueFormJson(icbsbody.get("CIF_CREATION").getAsJsonObject(), "ACCOUNT", ""));
							
							
							trnData.addProperty("batchNo", Long.toString(Im$utils.generateRandomLong(4)));
							if(date!=null) {
							    trnData.addProperty("valueDate",date);
							}else {
								trnData.addProperty("valueDate","2020-06-02");
							}
	
							trnData.addProperty("offsetAccType", offsetAccType);
							trnData.addProperty("offsetAcc",offsetAcc);
							trnData.addProperty("offsetBrn",fecthValueFormJson(app$Json.get("contactDetails").getAsJsonObject(), "branch", "999"));//#MVT00091 Changes starts
							trnData.addProperty("lcyAmount", fecthValueFormJson(app$Json, "initialDepositeAmount", "300"));
							trnData.addProperty("offsetTrn", "MSC");
							trnData.addProperty("addlText", app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
									+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")//#MVT00091 Changes ends
									.getAsString()+ " " + "| INITIAL CASH DEPOSIT");
							trnData.addProperty("initialCD","Y");

							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "applicationId",
									app$Json.get("applicationId").getAsString()); 
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						} // #YPR00062 Ends
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CUNA_IWS")) { // #00000029
						// starts
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						String isCunaOpted = null;

						if (I$utils.$iStrFuzzyMatch(
								app$Json.get("moreInfo").getAsJsonObject().get("isapplyForCunaInsurance").getAsString(),
								"N")) {
							logger.debug(
									"$$$$$$$$$$$$$$$$$$$$$$$$$$$$ CUNA is not opted for this applicaiton $$$$$$$$$$$$$$");
							continue;
						} else if (!(ifCifSuccess(app$Json, scanType))) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CUNA EXCP EXC000001");
						}
						logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ CUNA CREATION STARTED");
						try {
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							trnData.addProperty("fullName",
									app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
											+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
													.getAsString());
							trnData.addProperty("custNo",
									icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString());
							trnData.addProperty("branch",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							trnData.addProperty("openDt",
									app$Json.get("contactDetails").getAsJsonObject().get("openDt").getAsString());
//	trnData.addProperty("planEndDate", app$Json.get("cunaInsurance").getAsJsonObject()
//		.get("cunaDateEndPlan").getAsString());
							trnData.addProperty("planEndDate", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaDateEndPlan", ""));

//	trnData.addProperty("cunaRemarks1",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("cunaRemarks1").getAsString());
							trnData.addProperty("cunaRemarks1", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaRemarks1", "ok"));
							trnData.addProperty("gender",
									app$Json.get("cunaInsurance").getAsJsonObject().get("cunaGender").getAsString());
//	trnData.addProperty("remarksCuna",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("cunaRemarks1").getAsString());
							trnData.addProperty("remarksCuna",
									fecthValueFormJson(app$Json.get("cunaInsurance").getAsJsonObject(), "cunaRemarks1",
											"Ok to create Cuna Insurance"));
							trnData.addProperty("deditBranchCode",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString()); // #BVB00174
							trnData.addProperty("debitAccNo",
									icbsbody.get("CIF_CREATION").getAsJsonObject().get("ACCOUNT").getAsString()); // #BVB00174
//	trnData.addProperty("certificateNumber",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("cunaCertNo").getAsString());
							trnData.addProperty("certificateNumber", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaCertNo", ""));
							String $cdod = null;

							try {
								$cdod = Im$utils.dateFormatter(
										app$Json.get("cunaInsurance").getAsJsonObject().get("cunaDod").getAsString()); //#PM000100
							} catch (Exception e) {
// pass
							}
							if ($cdod != null) {
						//		trnData.addProperty("cunaDod", I$utils.changeDateFormatS($cdod,"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd"));// #YPR00070 changes
								trnData.addProperty("cunaDod", $cdod); //#PM000100
							} else {
								trnData.addProperty("cunaDod", "");
							}
//trnData.addProperty("cunaDod",
//app$Json.get("cunaInsurance").getAsJsonObject().get("cunaDob").getAsString());
							String $dob = null;
							try {
								$dob = Im$utils.dateFormatter(
										app$Json.get("personalInfo").getAsJsonObject().get("dob").getAsString());
							} catch (Exception e) {
// pass
							}
							if ($dob != null) {
								trnData.addProperty("dob", $dob);
							} else {
								trnData.addProperty("dob", "");// #BVB00174
							}
							try {
								JsonObject beneficiaryDetails = new JsonObject();
								JsonArray beneficiaryDetailsArray = app$Json.get("cunaInsurance").getAsJsonObject()
										.get("beneficiaryDetails").getAsJsonArray();
								for (int ben = 1; ben <= beneficiaryDetailsArray.size(); ben++) {
									beneficiaryDetails = beneficiaryDetailsArray.get(ben-1).getAsJsonObject();
									int benR = ben;
// if(!I$utils.$iStrFuzzyMatch(beneficiaryDetails.get("srNo").getAsString(),""))
// {
									trnData.addProperty("srNo" + benR, benR);
									trnData.addProperty("cunaBen" + benR + "FirstName",
											beneficiaryDetails.get("firstName").getAsString());
									trnData.addProperty("cunaBen" + benR + "MiddleName",
											beneficiaryDetails.get("middleName").getAsString());
									trnData.addProperty("cunaBen" + benR + "LastName",
											beneficiaryDetails.get("lastName").getAsString());
									String $cdob = null;
									try {
										$dob = Im$utils.dateFormatter(beneficiaryDetails.get("dob").getAsString());
									} catch (Exception e) {
// pass
									}
									if ($dob != null) {
										trnData.addProperty("cunaBen" + benR + "Dob", $dob);
									} else {
										trnData.addProperty("cunaBen" + benR + "Dob", "");
									}
									trnData.addProperty("cunaBen" + benR + "Minor",
											beneficiaryDetails.get("minor").getAsString());
									trnData.addProperty("cunaBen" + benR + "TrusteeName",
											beneficiaryDetails.get("trusteeName").getAsString());
									trnData.addProperty("cunaBen" + benR + "PercentBenefits",
											beneficiaryDetails.get("percentBenefits").getAsString());
									try {
										trnData.addProperty("cunaDod" + benR,
												beneficiaryDetails.get("dod").getAsString());
									} catch (Exception exp) {
										trnData.addProperty("cunaDod" + benR, ""); // #BVB00174
									}
								}
							} catch (Exception e) {
							}
//	trnData.addProperty("cunaCIRCovAmt",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("cunaCIRCovAmt").getAsString());
							trnData.addProperty("cunaCIRCovAmt", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaCIRCovAmt", ""));
//	trnData.addProperty("isCIR",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("isCIR").getAsString());
							trnData.addProperty("isCIR",
									fecthValueFormJson(app$Json.get("cunaInsurance").getAsJsonObject(), "isCIR", "N"));
//	trnData.addProperty("cunaCIRAge",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("cunaCIRAge").getAsString());
							trnData.addProperty("cunaCIRAge", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaCIRAge", ""));
//	trnData.addProperty("cunaCIRAgeBand", app$Json.get("cunaInsurance").getAsJsonObject()
//		.get("cunaCIRAgeBand").getAsString());
							trnData.addProperty("cunaCIRAgeBand", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaCIRAgeBand", ""));
//	trnData.addProperty("cunaCIRPremAmt", app$Json.get("cunaInsurance").getAsJsonObject()
//		.get("cunaCIRPremAmt").getAsString());
							trnData.addProperty("cunaCIRPremAmt", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaCIRPremAmt", ""));
							String $cireDate = null;
							try {
								$cireDate = Im$utils.dateFormatter(app$Json.get("cunaInsurance").getAsJsonObject()
										.get("cunaCIREndDate").getAsString());
							} catch (Exception e) {
// pass
							}
							if ($cireDate != null) {
								trnData.addProperty("cunaCIREndDate1", $cireDate);
							} else {
								trnData.addProperty("cunaCIREndDate1", "");
							}
							String $cirsDate = null;
							try {
								$cirsDate = Im$utils.dateFormatter(app$Json.get("cunaInsurance").getAsJsonObject()
										.get("cunaCIRStartDate").getAsString());
							} catch (Exception e) {
// pass
							}
							if ($cirsDate != null) {
								trnData.addProperty("cunaCIRStartDate1",
										app$Json.get("contactDetails").getAsJsonObject().get("openDt").getAsString());
							} else {
								trnData.addProperty("cunaCIRStartDate1", ""); // #BVB00163
							}

//	trnData.addProperty("cunaCIREndReason1", app$Json.get("cunaInsurance").getAsJsonObject()
//		.get("cunaCIREndDateReason").getAsString());
							trnData.addProperty("cunaCIREndReason1", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaCIREndDateReason", ""));

//	trnData.addProperty("cunaRemarks2",
//		app$Json.get("cunaInsurance").getAsJsonObject().get("cunaRemarks2").getAsString());
							trnData.addProperty("cunaRemarks2", fecthValueFormJson(
									app$Json.get("cunaInsurance").getAsJsonObject(), "cunaRemarks2", ""));
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"CIF CREATION EXCP EXC000001");
						}

					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "EDD_CREATION")) { // #00000048
																													// change
																													// begins
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						if (I$utils.$iStrFuzzyMatch(
								app$Json.get("moreInfo").getAsJsonObject().get("isPoliticallyExposed").getAsString(),
								"N")) {
							logger.debug(
									"$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Clico is not opted for this applicaiton $$$$$$$$$$$$$$");
							continue;
						} else if (!(ifCifSuccess(app$Json, scanType))) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "EDD EXCP EXC000001");
						}
						logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ EDD CREATION STARTED");
						try {
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							trnData.addProperty("custNo",
									icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString());
							trnData.addProperty("srcFundSalMonthIncome", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcFundSalMonthIncome", ""));
							trnData.addProperty("fullName",app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString()+ " "+ 
									app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString());
							trnData.addProperty("srcFundSalMonthIncome", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcFundSalMonthIncome", ""));
							trnData.addProperty("srcFundCommMonthIncome", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcFundCommMonthIncome", ""));
							trnData.addProperty("srcFundBusinessMonthIncome", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcFundBusinessMonthIncome", ""));
							trnData.addProperty("srcWealthWorthInvestment", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthInvestment", ""));
							trnData.addProperty("srcWealthWorthInheritance", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthInheritance", ""));
							trnData.addProperty("srcWealthWorthCashInHand", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthCashInHand", ""));
							trnData.addProperty("srcWealthWorthCashInBank", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthCashInBank", ""));
							trnData.addProperty("srcWealthWorthStocks", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthStocks", ""));
							trnData.addProperty("srcWealthWorthBonds", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthBonds", ""));
							trnData.addProperty("srcWealthWorthRealEstate", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthRealEstate", ""));
							trnData.addProperty("srcWealthWorthMotorVehicle", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthMotorVehicle", ""));
							trnData.addProperty("srcWealthWorthHousehold", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthHousehold", ""));
							trnData.addProperty("srcWealthWorthLI", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthLI", ""));
							trnData.addProperty("srcWealthWorthOtherAssets", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "srcWealthWorthOtherAssets", ""));
							trnData.addProperty("liabilitiesTotalAssets", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesTotalAssets", ""));
							trnData.addProperty("liabilitiesWorthLoans5year", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesWorthLoans5year", ""));
							trnData.addProperty("liabilitiesWorthShortLoan", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesWorthShortLoan", ""));
							trnData.addProperty("liabilitiesWorthMortageLoan", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesWorthMortageLoan", ""));
							trnData.addProperty("liabilitiesWorthCreditCard", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesWorthCreditCard", ""));
							trnData.addProperty("liabilitiesWorthHirePurchase",
									fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"liabilitiesWorthHirePurchase", ""));
							trnData.addProperty("liabilitiesNetWorth", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesNetWorth", ""));

							trnData.addProperty("liabilitiesWorthOther", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesWorthOther", ""));
							trnData.addProperty("liabilitiesTotalLiabilities", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "liabilitiesTotalLiabilities", ""));
							trnData.addProperty("anticipatedCheckShares", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "anticipatedCheckShares", ""));
							trnData.addProperty("anticipatedCheckFixedDeposits",
									fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"anticipatedCheckFixedDeposits", ""));
							trnData.addProperty("anticipatedCheckCharacterLoan",
									fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"anticipatedCheckCharacterLoan", ""));
							trnData.addProperty("anticipatedCheckInvestment", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "anticipatedCheckInvestment", ""));
							trnData.addProperty("anticipatedCheckMotorVehicleLoan",
									fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"anticipatedCheckMotorVehicleLoan", ""));
							trnData.addProperty("anticipatedCheckLINCU", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "anticipatedCheckLINCU", ""));
							trnData.addProperty("LevelOfNumberOfTra", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "LevelOfNumberOfTra", ""));
							trnData.addProperty("LevelOfVolumeTra", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "LevelOfVolumeTra", ""));
							trnData.addProperty("pepMemberNameOfEmployer", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "pepMemberNameOfEmployer", ""));
							trnData.addProperty("pepMemberNameOPublicFun", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "pepMemberNameOPublicFun", ""));
							trnData.addProperty("pepMemberPositionDuties", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "pepMemberPositionDuties", ""));
							trnData.addProperty("pepMemberCountry", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "pepMemberCountry", "TT"));
							trnData.addProperty("pepMemberYearsService", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "pepMemberYearsService", ""));
							trnData.addProperty("pepRelationship", fecthValueFormJson(
									app$Json.get("enhanced_due").getAsJsonObject(), "pepRelationship", ""));

							if (I$utils
									.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonIndCheckOperatingIncome", ""), "Y")) {
								trnData.addProperty("businessNonIndCheckOperatingIncome", "Operating Income");
								trnData.addProperty("businessNonIndOSVolumnofAssets",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndOSVolumnofAssets", ""));
								trnData.addProperty("businessNonIndOSAnnualBusTurnover",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndOSAnnualBusTurnover", ""));
							} else {
								trnData.addProperty("businessNonIndCheckOperatingIncome", "");
								trnData.addProperty("businessNonIndOSVolumnofAssets", "");
								trnData.addProperty("businessNonIndOSAnnualBusTurnover", "");
							}

							if (I$utils
									.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonIndCheckFromShareholder", ""), "Y")) {
								trnData.addProperty("businessNonIndCheckFromShareholder", "From Shareholders");
								trnData.addProperty("businessNonIndFSVolumnofAssets",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndFSVolumnofAssets", ""));
								trnData.addProperty("businessNonIndFSAnnualBusTurnover",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndFSAnnualBusTurnover", ""));
							} else {
								trnData.addProperty("businessNonIndCheckFromShareholder", "");
								trnData.addProperty("businessNonIndFSVolumnofAssets", "");
								trnData.addProperty("businessNonIndFSAnnualBusTurnover", "");
							}

							if (I$utils
									.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonIndCheckFromGroupComp", ""), "Y")) {
								trnData.addProperty("businessNonIndCheckFromGroupComp", "From Group Companies");
								trnData.addProperty("businessNonIndFGCVolumnofAssets",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndFGCVolumnofAssets", ""));
								trnData.addProperty("businessNonIndFGCAnnualBusTurnover",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndFGCAnnualBusTurnover", ""));
							} else {
								trnData.addProperty("businessNonIndCheckFromGroupComp", "");
								trnData.addProperty("businessNonIndFGCVolumnofAssets", "");
								trnData.addProperty("businessNonIndFGCAnnualBusTurnover", "");
							}
							if (I$utils
									.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonIndCheckInvestment", ""), "Y")) {
								trnData.addProperty("businessNonIndCheckInvestment", "Investment");
								trnData.addProperty("businessNonIndInvVolumnofAssets",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndInvVolumnofAssets", ""));
								trnData.addProperty("businessNonIndInvAnnualBusTurnover",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonIndInvAnnualBusTurnover", ""));
							} else {
								trnData.addProperty("businessNonIndCheckInvestment", "");
								trnData.addProperty("businessNonIndInvVolumnofAssets", "");
								trnData.addProperty("businessNonIndInvAnnualBusTurnover", "");
							}
							if (I$utils
									.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonIndCheckCreditFacilities", ""), "Y")) {
								trnData.addProperty("businessNonIndCheckCreditFacilities", "Credit Facilities");
								trnData.addProperty("businessNonCFVolumnofAssets",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonCFVolumnofAssets", ""));
								trnData.addProperty("businessNonCFAnnualBusTurnover",
										fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
												"businessNonCFAnnualBusTurnover", ""));
							} else {
								trnData.addProperty("businessNonIndCheckCreditFacilities", "");
								trnData.addProperty("businessNonCFVolumnofAssets", "");
								trnData.addProperty("businessNonCFAnnualBusTurnover", "");
							}

							trnData.addProperty("businessNonIndCheckOther",
									fecthJsonValWithDefault(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonIndCheckOther", "", "N"));
							trnData.addProperty("businessNonOtherVolumnofAssets",
									fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonOtherVolumnofAssets", ""));
							trnData.addProperty("businessNonOtherAnnualBusTurnover",
									fecthValueFormJson(app$Json.get("enhanced_due").getAsJsonObject(),
											"businessNonOtherAnnualBusTurnover", ""));

							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body); // #00000029
																											// Ends
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"EDD  CREATION EXCP EXC000001");
						} // #00000048 change ends
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CLICO_IWS")) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						if (I$utils.$iStrFuzzyMatch(
								app$Json.get("moreInfo").getAsJsonObject().get("isapplyForClico").getAsString(), "N")) {
							logger.debug(
									"$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Clico is not opted for this applicaiton $$$$$$$$$$$$$$");
							continue;
						} else if (!(ifCifSuccess(app$Json, scanType))) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "CLICO EXCP EXC000001");
						}
						logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ CLICO CREATION STARTED");
						try {
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							trnData.addProperty("fullName",
									app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
											+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
													.getAsString());
							trnData.addProperty("custNo",
									icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString());
							trnData.addProperty("branch",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							String $opdate = null;
							try {
								$opdate = Im$utils.dateFormatter(
										app$Json.get("contactDetails").getAsJsonObject().get("openDt").getAsString());
							} catch (Exception e) {
								// pass
							}
							if ($opdate != null) {
								trnData.addProperty("openDt", $opdate);
							} else {
								trnData.addProperty("openDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd")); // #DVJ00050
																													// Change
							}
							String $pldate = null;
							try {
								$pldate = Im$utils.dateFormatter(app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("planEndDate").getAsString());
							} catch (Exception e) {
								// pass
							}
							if ($pldate != null) {
								trnData.addProperty("planEndDate", $pldate);
							} else {
								trnData.addProperty("planEndDate", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd")); // #DVJ00050
																														// Change
							}
							try {
							trnData.addProperty("reasonForPlanEndDate", app$Json.get("clicoDeclaration").getAsJsonObject()
									.get("reasonForPlanEndDate").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							try {
							trnData.addProperty("remarksClico", app$Json.get("clicoDeclaration").getAsJsonObject()
									.get("remarksClico").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							try {
							trnData.addProperty("deditBranchCode",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							try {
							trnData.addProperty("debitAccNo",
									icbsbody.get("CIF_CREATION").getAsJsonObject().get("ACCOUNT").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							try {
							trnData.addProperty("certificateNumber", app$Json.get("clicoDeclaration").getAsJsonObject()
									.get("certificateNumber").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							try {
							trnData.addProperty("approvedClaimNumber", app$Json.get("clicoDeclaration").getAsJsonObject()
									.get("approvedClaimNumber").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							try {
						    trnData.addProperty("gender", app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("gender").getAsString());
							}
							catch(Exception e)
							{
								// pass
							}
							String $date = null;
							try {
								$date = Im$utils.dateFormatter(app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("clicoDod").getAsString());
							} catch (Exception e) {
								// pass
							}
							if ($date != null) {
								trnData.addProperty("clicoDod", $date);
							} else {
								trnData.addProperty("clicoDod", ""); // ##PM000100
																														// Change
							}

							String $dob = null;
							try {
								$dob = Im$utils.dateFormatter(app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("clicoDob").getAsString());
							} catch (Exception e) {
								// pass
							}
							if ($dob != null) {
								trnData.addProperty("dob", $dob);
							} else {
								trnData.addProperty("dob", ""); // #PM000100
							}
							// #DVJ00050 Starts
							try {
								trnData.addProperty("medicalPlanReq", app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("medicalPlanReq").getAsString());
							} catch (Exception e) {
								trnData.addProperty("medicalPlanReq", "");
							}
							// #DVJ00050 Ends						
							try {
								JsonObject cbeneficiaryDetails = new JsonObject();
								JsonArray beneficiaryDetailsArray = app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("beneficiaryDetails").getAsJsonArray();
								for (int ben = 1; ben <= beneficiaryDetailsArray.size(); ben++) {
									cbeneficiaryDetails = beneficiaryDetailsArray.get(ben-1).getAsJsonObject();
									int benR = ben;
									// #DVJ00050 Starts
									try {
										trnData.addProperty("srNo" + benR, benR);
									} catch (Exception e) {
										
									}
									try {
										trnData.addProperty("clicoBen" + benR + "FirstName",
												cbeneficiaryDetails.get("firstName").getAsString());
									} catch (Exception e) {
										if (!trnData.has("firstName"))
											trnData.addProperty("firstName", "");
									}
									try {
										trnData.addProperty("clicoBen" + benR + "MiddleName",
												cbeneficiaryDetails.get("middleName").getAsString());
									} catch (Exception e) {
										if (!trnData.has("middleName"))
											trnData.addProperty("middleName", "");
									}
									try {
										trnData.addProperty("clicoBen" + benR + "LastName",
												cbeneficiaryDetails.get("lastName").getAsString());
									} catch (Exception e) {
										if (!trnData.has("lastName"))
											trnData.addProperty("lastName", "");
									}
									
									String $cdob = null;
									try {
										$dob = Im$utils.dateFormatter(cbeneficiaryDetails.get("dob").getAsString());
										if ($dob != null) {
											trnData.addProperty("clicoBen" + benR + "Dob", $dob);
										} else {
											trnData.addProperty("clicoBen" + benR + "Dob", ""); // #PM000100 Change
										}
									} catch (Exception e) {
									}
									
									// #BVB00174 Starts
									try {
										trnData.addProperty("clicoBen" + benR + "Minor",
													cbeneficiaryDetails.get("minor").getAsString());									
									} catch (Exception e) {
										
									}
									
									// #BVB00174 Ends
									//#PM000001 CHANGES STARTS
									try {
										trnData.addProperty("clicoBen" + benR + "TrusteeName",
												cbeneficiaryDetails.get("trusteeName").getAsString());
									} catch (Exception e) {
										
									}
									try {
										trnData.addProperty("clicoBen" + benR + "PercentBenefits",
												cbeneficiaryDetails.get("percentBenefits").getAsString());
									} catch (Exception e) {
										
									}
									
									String $cdod = null;
									String $dod = null;
									try {
										$dob = Im$utils.dateFormatter(cbeneficiaryDetails.get("dod").getAsString());
										if ($dob != null) {
											trnData.addProperty("clicoBen" + benR + "Dod", $dob);
										} else {
											trnData.addProperty("clicoBen" + benR + "Dod",""); // #PM000100 Change
										}
									} catch (Exception e) {
									}
									
									try {
										trnData.addProperty("clicoBen" + benR + "Dod",
												cbeneficiaryDetails.get("dod").getAsString());
									} catch (Exception exp) {
										if (!trnData.has("Dod"))
											trnData.addProperty("clicoBen" + benR,""); // #PM000100 Change
									}
									
									//#PM000001 CHANGES ENDS
								}
							} catch (Exception e) {
							}

							//medicalPlanReq 
							String $date3 = null;
							try {
								$date3 = Im$utils.dateFormatter(app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("cimStartDate").getAsString());
							} catch (Exception e) {
							}
							if ($date3 != null) {
								trnData.addProperty("cimStartDate", $date3);
							} else {
								trnData.addProperty("cimStartDate", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd")); // #PM000100
																															// Change
							}

							String $date4 = null;
							try {
								$date4 = Im$utils.dateFormatter(app$Json.get("clicoDeclaration").getAsJsonObject()
										.get("cimEndDate").getAsString());
							} catch (Exception e) {
							}
							if ($date4 != null) {
								trnData.addProperty("cimEndDate", $date4);
							} else {
								trnData.addProperty("cimEndDate", ""); // #PM000100																												// Change
							}
							//#PM000001 CHANGES STARTS
							try {
							trnData.addProperty("cimremarks", app$Json.get("clicoDeclaration").getAsJsonObject()
									.get("cimremarks").getAsString());
							}
							catch(Exception e)
							{
								// pass
								trnData.addProperty("cimremarks","");
							}
							//#PM000001 CHANGES ENDS
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body); // #00000029
																											// Ends
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"CIF CREATION EXCP EXC000001");
						}
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_CUST_UPDATE")) {
						// #00000017
						// change Start
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						// pull the Customer data from cif collection
						try {
							JsonObject flter = new JsonObject();
							// flter.addProperty("CustomerId",
							// app$Json.get("cbsDetails").getAsJsonObject().get("CIF_CREATION")
							// .getAsJsonObject().get("CIF").getAsString());
							flter.addProperty("CustomerId",
									app$Json.get("contactDetails").getAsJsonObject().get("CIF").getAsString()); // #00000030
																												// Change
							JsonObject prjctn = new JsonObject();
							//
//																		prjctn.addProperty("CustomerId", 1);
//																		prjctn.addProperty("CustomerFirstName", 1);
//																		prjctn.addProperty("CustomerShortName", 1);
//																		prjctn.addProperty("CustomerLastName", 1);
//																		prjctn.addProperty("CustomerEmailId", 1);
//																		prjctn.addProperty("CustomerBranch", 1);
//																		prjctn.addProperty("placeOfBirth", 1);
//																		// #BVB00185 Starts
							// prjctn.addProperty("CustomerShortName", 1);
//																		prjctn.addProperty("AddressForCorrespondence1", 1);
//																		prjctn.addProperty("AddressForCorrespondence2", 1);
//																		prjctn.addProperty("AddressForCorrespondence3", 1);
//																		prjctn.addProperty("AddressForCorrespondence4", 1);
//																		prjctn.addProperty("PassportExpiryDate", 1);
//																		prjctn.addProperty("PassportIssueDate", 1);
//																		prjctn.addProperty("CustomerDob", 1);
							//
//																		prjctn.addProperty("CustomerNationality", 1);
							// #BVB00185 Ends
							JsonObject cifDetails = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", flter, prjctn);
							JsonObject trnData = new JsonObject();
							isonBody = new JsonObject();
							isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
							// Construct tranData and append it back to jsonBody and finally to request
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							// populate the values to be the jsonObject
							trnData.addProperty("applicationId", i$ResM.getStrfromObj(app$Json, "applicationId"));
							trnData.addProperty("custNo",
									i$ResM.getStrfromObj(app$Json.getAsJsonObject("contactDetails"), "CIF"));
							trnData.addProperty("sName", i$ResM.getStrfromObj(cifDetails, "CustomerShortName"));
							trnData.addProperty("fullName",
									i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "firstName")
											+ " " + i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(),
													"lastName"));
							trnData.addProperty("mailAddZipCode", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddZipCode"));

							trnData.addProperty("isMailAddrSame", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "isMailAddrSame"));
							trnData.addProperty("permAddLine1", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddLine1"));
							trnData.addProperty("permAddLine2", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddLine2"));
							trnData.addProperty("permAddLine3", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddLine3"));
							// #BVB00207 Starts
							trnData.addProperty("permAddCity", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddCity"));
							trnData.addProperty("permAddZipCode", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddZipCode"));

							trnData.addProperty("mailAddLine1", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddLine1"));
							trnData.addProperty("mailAddLine2", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddLine2"));
							trnData.addProperty("mailAddLine3", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddLine3"));
							trnData.addProperty("mailAddCity", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddCity"));

							// #BVB00207 Ends
							trnData.addProperty("branch",
									i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "branch"));
							trnData.addProperty("firstName",
									i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "firstName"));
							trnData.addProperty("middleName",
									i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "middleName"));
							trnData.addProperty("lastName",
									i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "lastName"));
							trnData.addProperty("placeOfBirth", i$ResM.getStrfromObj(
									app$Json.get("personalInfo").getAsJsonObject(), "placeOfBirth"));
							String $dob = null;
							try {
								$dob = Im$utils.dateFormatter(
										i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "dob"));
							} catch (Exception e) {
							}
							if ($dob != null) {
								trnData.addProperty("dob", $dob);
							} else {
								trnData.addProperty("dob", ""); // #BVB00174
							}
							trnData.addProperty("methodOfCommunication", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "methodOfCommunication"));
							trnData.addProperty("language", "ENG");
							trnData.addProperty("emailId",
									i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "emailId"));
							trnData.addProperty("mobileNumber", i$ResM
									.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "mobileNumber"));
							trnData.addProperty("gender",
									i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "gender"));
							// #00000023 start
							try {
								trnData.addProperty("mobileISD", i$ResM
										.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "mobileISD"));
							} catch (Exception e) {
								trnData.addProperty("mobileISD", "+1868");
							}
							try {
								trnData.addProperty("custCAT", i$ResM
										.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(), "custCAT"));
							} catch (Exception e) {
								trnData.addProperty("custCAT", "01");
							}
							// #00000023 ends
							trnData.addProperty("currency",
									i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "currency"));
							trnData.addProperty("custCatDesc", i$ResM
									.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(), "custCATDesc"));
							trnData.addProperty("birthCountry", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "birthCountry"));
							trnData.addProperty("geoLocationDesc", i$ResM.getStrfromObj(
									app$Json.get("contactDetails").getAsJsonObject(), "geoLocationDesc"));
							trnData.addProperty("accClassType", i$ResM
									.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(), "acClassType"));
							trnData.addProperty("accountClass", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "accountClass"));
							trnData.addProperty("openDt",
									i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "openDt"));
							trnData.addProperty("tecuReferenceDesc", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "tecuReferenceDesc"));
							trnData.addProperty("interestedInLoan", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "interestedInLoan"));
							trnData.addProperty("interestedloanType", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "interestedloanType"));
							trnData.addProperty("employer",
									i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employer"));

							trnData.addProperty("employerCountry", i$ResM
									.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employerCountry"));

							trnData.addProperty("sectorEmployedDesc", i$ResM
									.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "sectorEmployedDesc"));
							trnData.addProperty("employmentTypeDesc", i$ResM
									.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employmentTypeDesc"));
							trnData.addProperty("sectorEmployed", i$ResM
									.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "sectorEmployed"));
							// #BVB00207 Starts
							trnData.addProperty("permAddCountry", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "permAddCountry")); // 00000004
							trnData.addProperty("mailAddCountry", i$ResM
									.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "mailAddCountry")); // 00000004

							trnData.addProperty("telephone",
									i$ResM.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(),
											"homephoneExtension")
											+ i$ResM.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(),
													"homePhoneNumber"));

							trnData.addProperty("birthCertificatePinNo", i$ResM.getStrfromObj(
									app$Json.get("additionalDetails").getAsJsonObject(), "birthCertificatePinNo"));
							trnData.addProperty("isMinor", i$ResM
									.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(), "isAMinor"));
							trnData.addProperty("guardianName", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "guardianName", "")); // #BVB00214
							trnData.addProperty("countryOfIssuance", fecthValueFormJson(
									app$Json.get("additionalDetails").getAsJsonObject(), "countryOfIssuance", ""));
							// #BVB00207 Starts
							// #BVB00174 Starts

							try {
								trnData.addProperty("uidName", i$ResM
										.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "priDocName"));
								trnData.addProperty("uidVal", i$ResM
										.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "priDocId"));

								String priDocName = i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(),
										"priDocName");
								String secDocName = i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(),
										"secDocName");

								trnData.addProperty("prefix",
										i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "prefix"));
								trnData.addProperty("uidName", i$ResM
										.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "priDocName"));
								trnData.addProperty("uidName", i$ResM
										.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "priDocName"));

								trnData = buildIdCardDetails(app$Json, trnData);

							} catch (Exception e) {
							}

							try {
								// #BVB00195 Starts
//																			String isCitizenShipofOtherCountry = app$Json.get("moreInfo").getAsJsonObject()
//																					.get("isCitizenShipofOtherCountry");
								String isCitizenShipofOtherCountry = i$ResM.getStrfromObj(
										app$Json.get("fatcaDeclaration").getAsJsonObject(), "isCitizenOfOtherCountry");

								trnData.addProperty("isCitizenShipofOtherCountry", isCitizenShipofOtherCountry);
								// #BVB00195 Ends
								if (I$utils.$iStrFuzzyMatch(isCitizenShipofOtherCountry, "Y")) {
									trnData.addProperty("citizenShip1", i$ResM.getStrfromObj(
											app$Json.get("fatcaDeclaration").getAsJsonObject(), "fatcaCountry"));
									trnData.addProperty("citizenShip2", i$ResM.getStrfromObj(
											app$Json.get("fatcaDeclaration").getAsJsonObject(), "fatcaCountry"));
									String isUSCitizen = i$ResM.getStrfromObj(
											app$Json.get("fatcaDeclaration").getAsJsonObject(), "isUSCitizen");
									if (I$utils.$iStrFuzzyMatch(isUSCitizen, "Y")) {
										// #BVB00196 Starts
										// Prepare for Indicia
										/*
										 * 1) Any Address is US 2) Any Mobile Number 3) ARE YOU A GRANTEE OF A POWER OF
										 * ATTORNEY OR AN AUTHORISED 4) Birth Country US 5) ARE YOU A U.S. CITIZEN,
										 * RESIDENT OR GREEN CARD HOLDER? 6) ARE YOU GIVING STANDING INSTRUCTIONS FOR
										 * THE TRANSFER OF DIVIDEND
										 */

										// 2.
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(
												app$Json.get("contactDetails").getAsJsonObject(), "mobileISD"), "1")
												|| I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(
														app$Json.get("additionalDetails").getAsJsonObject(),
														"homephoneExtension"), "1")
												|| I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(
														app$Json.get("additionalDetails").getAsJsonObject(),
														"mobNo2Extension"), "1")) {
											trnData.addProperty("usIndicia2",
													"Current US unambiguous Telephone number");
											trnData.addProperty("usIndicia", "Current US unambiguous Telephone number");
										} else {
											trnData.addProperty("usIndicia2", "");
										}

										// 1.
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(
												app$Json.get("personalInfo").getAsJsonObject(), "permAddCountry"), "US")
												|| I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(
														app$Json.get("personalInfo").getAsJsonObject(),
														"mailAddCountry"), "US")) {
											trnData.addProperty("usIndicia1",
													"Current US mailing/resident Address including a US post office Box");
											trnData.addProperty("usIndicia",
													"Current US mailing/resident Address including a US post office Box");
										} else {
											trnData.addProperty("usIndicia1", "");
										}

										// 3. isGranteePOA
										if (I$utils.$iStrFuzzyMatch(
												i$ResM.getStrfromObj(app$Json.get("fatcaDeclaration").getAsJsonObject(),
														"isGranteePOA"),
												"Y")) {
											trnData.addProperty("usIndicia3",
													"Currently effective Power of attorney or signator authority granted to a person with a US address");
											trnData.addProperty("usIndicia",
													"Currently effective Power of attorney or signator authority granted to a person with a US address");
										} else {
											trnData.addProperty("usIndicia3", "");
										}

										if (I$utils.$iStrFuzzyMatch(
												i$ResM.getStrfromObj(app$Json.get("fatcaDeclaration").getAsJsonObject(),
														"isStandingInstructIncome"),
												"Y")) {
											trnData.addProperty("usIndicia6",
													"Standing instructions to transafer funds to an account maintained in the US");
											trnData.addProperty("usIndicia",
													"Standing instructions to transafer funds to an account maintained in the US");
										} else {
											trnData.addProperty("usIndicia6", "");
										}

										if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(
												app$Json.get("additionalDetails").getAsJsonObject(), "birthCountry"),
												"US")) {
											trnData.addProperty("usIndicia4", "Identification of a US place of bitrth");
											trnData.addProperty("usIndicia", "Identification of a US place of bitrth");
										} else {
											trnData.addProperty("usIndicia4", "");
										}

										if (I$utils.$iStrFuzzyMatch(
												i$ResM.getStrfromObj(app$Json.get("fatcaDeclaration").getAsJsonObject(),
														"isUSCitizen"),
												"Y")) {
											trnData.addProperty("usIndicia5",
													"Identification of account holder as US Citizen or Resident");
											trnData.addProperty("usIndicia",
													"Identification of account holder as US Citizen or Resident");
										} else {
											trnData.addProperty("usIndicia5", "");
										}

										if (!trnData.has("usIndicia")) {
											trnData.addProperty("usIndicia", "");
										}

//																					trnData.addProperty("usIndicia", app$Json.get("fatcaDeclaration")
//																							.getAsJsonObject().get("ssnNo1"));
										trnData.addProperty("tinNumber",
												i$ResM.getStrfromObj(app$Json.get("fatcaDeclaration").getAsJsonObject(),
														"ssnNo1").replace("-", ""));// #BVB00213
									}
									// #BVB00174 Starts
									else {
										trnData.addProperty("usIndicia", "");
										trnData.addProperty("usIndicia1", "");
										trnData.addProperty("usIndicia2", "");
										trnData.addProperty("usIndicia3", "");
										trnData.addProperty("usIndicia4", "");
										trnData.addProperty("usIndicia5", "");
										trnData.addProperty("usIndicia6", "");
										trnData.addProperty("tinNumber", "");
									}
									// #BVB00174 Ends
								} else {
									trnData.addProperty("citizenShip1", "");
									trnData.addProperty("usIndicia", "");
									trnData.addProperty("usIndicia1", "");
									trnData.addProperty("usIndicia2", "");
									trnData.addProperty("usIndicia3", "");
									trnData.addProperty("usIndicia4", "");
									trnData.addProperty("usIndicia5", "");
									trnData.addProperty("usIndicia6", "");
									trnData.addProperty("tinNumber", "");
									trnData.addProperty("citizenShip2", "");
								}
								// #BVB00196 Starts
								trnData.addProperty("educationCodeDesc", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "educationCodeDesc"));
								trnData.addProperty("educationCode", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "educationCode"));
								trnData.addProperty("maritalStatusDesc", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "maritalStatusDesc"));
								trnData.addProperty("maritalStatus", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "maritalStatus"));
								trnData.addProperty("spouseFullName",
										i$ResM.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(),
												"spouseFirstName")
												+ " "
												+ i$ResM.getStrfromObj(
														app$Json.get("additionalDetails").getAsJsonObject(),
														"spouseSurName"));

								trnData.addProperty("numberOfDependent", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "numberOfDependent"));
								trnData.addProperty("numberOfChildren", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "numberOfChildren"));
								trnData.addProperty("motherMaidenName", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "motherMaidenName"));
								trnData.addProperty("spouseMemberOfTecu", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "spouseMemberOfTecu"));
								trnData.addProperty("faxNumber", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "faxNumber"));
								trnData.addProperty("faxNumberExtension", fecthValueFormJson(
										app$Json.get("additionalDetails").getAsJsonObject(), "faxNumberExtension", "")); // #BVB00213
								
								if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
										"mobNo2", ""), "")) {
								trnData.addProperty("mobNo2",
										fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
												"mobNo2Extension", "")
												+ fecthValueFormJson(app$Json.get("additionalDetails").getAsJsonObject(),
														"mobNo2", ""));}
								else {
									trnData.addProperty("mobNo2",""); 
								}
								
								
								trnData.addProperty("isNational", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "isNational"));
								String isResident = i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "isResident");
								if (I$utils.$iStrFuzzyMatch(isResident, "N")) {
									trnData.addProperty("isResident", isResident);
								} else {
									trnData.addProperty("isResident", "R");
								}
//								trnData.addProperty("isResident", i$ResM.getStrfromObj(
//										app$Json.get("additionalDetails").getAsJsonObject(), "isResident"));
								trnData.addProperty("nationality", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "nationality"));
								// #BVB00211 Starts
								trnData.addProperty("homePhoneNumber", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "homePhoneNumber"));

//														trnData.addProperty("homePhoneNumber",
//																app$Json.get("employment").getAsJsonObject().get("employerExtension").getAsString()
//																		+ app$Json.get("employment").getAsJsonObject()
//																				.get("employerWorkPhoneNumber").getAsString());

								trnData.addProperty("homephoneExtension", i$ResM.getStrfromObj(
										app$Json.get("additionalDetails").getAsJsonObject(), "homephoneExtension"));
								trnData.addProperty("methodOfCommunicationDesc",
										i$ResM.getStrfromObj(app$Json.get("additionalDetails").getAsJsonObject(),
												"methodOfCommunicationDesc"));
								// #BVB00211 Ends
							} catch (Exception e) {
							}

							try {
								String employmentMode = i$ResM
										.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employmentMode");

								// #BVB00213 Starts
								trnData.addProperty("employerExtension", fecthValueFormJson(
										app$Json.get("employment").getAsJsonObject(), "employerExtension", ""));
								trnData.addProperty("employerPhoneNumber", fecthValueFormJson(
										app$Json.get("employment").getAsJsonObject(), "employerWorkPhoneNumber", ""));

								// #BVB00213 Ends
								trnData.addProperty("employeeNo", fecthValueFormJson(
										app$Json.get("employment").getAsJsonObject(), "employeeNo", "")); // #BVB00216

								if (!I$utils.$iStrFuzzyMatch(employmentMode, "U")) {
									trnData.addProperty("employmentMode", employmentMode);
									trnData.addProperty("occupation", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "occupation"));
									trnData.addProperty("employer", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employer"));
									trnData.addProperty("employerCountry", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "employerCountry"));
									trnData.addProperty("empAdd1", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "empAdd1"));
									//#PM000105 Changes Starts
								/*	trnData.addProperty("empAdd2", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "empAdd2")); */
									trnData.addProperty("employerCity", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employerCity"));
									//#PM000105 Changes Ends
									trnData.addProperty("employerExtension", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "employerExtension"));// #BVB00213
									if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
											"employerWorkPhoneNumber", ""), "")) {
									trnData.addProperty("employerWorkPhoneNumber",
											i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(),
													"employerExtension")

													+ i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(),
															"employerWorkPhoneNumber"));
									}else {
										trnData.addProperty("employerWorkPhoneNumber",""); 
									}
									if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
											"employerWorkPhoneNumber2", ""), "")) {
					trnData.addProperty("employerWorkPh2",
							fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
									"employerExtension2", "")
									+ fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
											"employerWorkPhoneNumber2", ""));
					}else {
						trnData.addProperty("employerWorkPh2",""); 
					}
					
									
									trnData.addProperty("employerOther", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "employerOther", "")); // #BVB00207
									//#PM000105 Changes Starts
								/*	trnData.addProperty("empAdd2", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "empAdd2")); */
									trnData.addProperty("employerCity", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "employerCity"));
									//#PM000105 Changes Ends
									if(!I$utils.$iStrFuzzyMatch(fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
											"empfaxNo", ""), "")) {
									trnData.addProperty("empfaxNo",
											i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(),
													"empfaxNoExtension")
													+ i$ResM.getStrfromObj(app$Json.get("employment").getAsJsonObject(),
															"empfaxNo"));
									}else {
										trnData.addProperty("empfaxNo","");
									}
									trnData.addProperty("officialEmailId", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "officialEmailId"));
									trnData.addProperty("employerDesc", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "employerDesc"));
									trnData.addProperty("payFrequency", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "payFrequency"));
									trnData.addProperty("empZipCode", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "empZipCode"));
									trnData.addProperty("joiningDate", Im$utils.dateFormatter(i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "joiningDate")));
									trnData.addProperty("empAddDet", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "empAddDetails", ""));
									// trnData.addProperty("avgMonthlyIncome",
									// app$Json.get("employment").getAsJsonObject().get("avgMonthlyIncome"));
									trnData.addProperty("avgMonthlyIncome", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "avgMonthlyIncome"));
									trnData.addProperty("avgMonthlyIncomeDesc", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "avgMonthlyIncomeDesc"));
									trnData.addProperty("salary", i$ResM
											.getStrfromObj(app$Json.get("employment").getAsJsonObject(), "salary"));
									trnData.addProperty("payFrequency", i$ResM.getStrfromObj(
											app$Json.get("employment").getAsJsonObject(), "payFrequency"));
									trnData.addProperty("accountFunded", fecthValueFormJson(
											app$Json.get("employment").getAsJsonObject(), "accountFunded", ""));
									trnData.addProperty("enterSourceAccountFunded",
											fecthValueFormJson(app$Json.get("employment").getAsJsonObject(),
													"enterSourceAccountFunded", ""));

								} else {
									trnData.addProperty("employmentMode", employmentMode);
									trnData.addProperty("occupation", "");
									trnData.addProperty("employer", "");
									trnData.addProperty("empAdd1", "");
									trnData.addProperty("employerCountry", "");
								//	trnData.addProperty("empAdd2", ""); //#PM000105 Changes Starts
									trnData.addProperty("employerCity", ""); //#PM000105 Changes Starts
									trnData.addProperty("employerWorkPhoneNumber", "");
									trnData.addProperty("empfaxNo", "");
									trnData.addProperty("officialEmailId", "");
									trnData.addProperty("employerDesc", "");
									trnData.addProperty("payFrequency", "");
									trnData.addProperty("empZipCode", "");
									trnData.addProperty("joiningDate", "");
									trnData.addProperty("employerOther", "");
									trnData.addProperty("salary", "");
									trnData.addProperty("payFrequency", "");
									trnData.addProperty("employerExtension", "");
									trnData.addProperty("empAddDet", ""); 
									// trnData.addProperty("avgMonthlyIncome",
									// app$Json.get("employment").getAsJsonObject().get("avgMonthlyIncome"));
									trnData.addProperty("avgMonthlyIncome", "");
									trnData.addProperty("avgMonthlyIncomeDesc", "");
									trnData.addProperty("accountFunded", "");
									trnData.addProperty("enterSourceAccountFunded", "");
									trnData.addProperty("employerWorkPh2",""); 
								}

								// trnData.addProperty("birthCertPinNo", "");
								// trnData.addProperty("birthCertiCntry", "");
								// trnData.addProperty("isMinor", "N");

							} catch (Exception e) {
							}


							// #BVB00209 Starts
							try {
								trnData.addProperty("iambCheckerId", app$Json.get("approverId").getAsString());//PM000102 Changes
								//#PM000106 CHANGES STARTS
								//trnData.addProperty("iambMakerId", app$Json.get("osvId").getAsString());//PM000102 Changes
								trnData.addProperty("iambMakerId", app$Json.get("verifierId").getAsString());
								//#PM000106 CHANGES ENDS
								//PM000102 Changes Starts
								//	trnData.addProperty("iambMakerDt", app$Json.get("createdAt").getAsString());
								//	trnData.addProperty("iambCheckerDt", i$ResM.getdateTime(new Date()));
								String $makerdt = null;
								try {
									$makerdt = Im$utils.dateFormatter(app$Json.get("createdAt").getAsString());
								} catch (Exception e) {
									// pass
								}
								if ($makerdt != null) {
									trnData.addProperty("iambMakerDt", $makerdt);
								} else {
									trnData.addProperty("iambMakerDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd"));	
								} 
									trnData.addProperty("iambCheckerDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd"));
									//PM000102 Changes Ends	

							} catch (Exception e) {
								trnData.addProperty("iambCheckerId", "");
								trnData.addProperty("iambMakerId", "");
								trnData.addProperty("iambMakerDt", "");
								trnData.addProperty("iambCheckerDt", "");

							}
							// #BVB00209 Ends
							trnData = refineIsdCodes(trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
									i$ResM.getStrfromObj(app$Json, "referenceNo"));
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
									i$ResM.getStrfromObj(app$Json.get("contactDetails").getAsJsonObject(), "branch"));
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "applicationId",
									i$ResM.getStrfromObj(app$Json, "applicationId"));
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);

						} catch (Exception e) { // #00000030 change
							logiCbsBody(app$Json, scanType, "N");
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"CIF UPDATION EXCP EXC000001");
						}

					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(),
							"CBS_ACCOUNT_CREATION")) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject i$body = new JsonObject();
						i$body = isonBody.get("i-body").getAsJsonObject();
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "tranId",
								app$Json.get("referenceNo").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnBrn",
								app$Json.get("trnData").getAsJsonObject().get("branchCode").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData",
								app$Json.get("trnData").getAsJsonObject());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CASA150_ACCOUNT_CREATION")) { // SRM00044 Changes start
						try {
							JsonObject ison$Body = new JsonObject();
							ison$Body = isonMsg.deepCopy();
							JsonObject i$bdy = ison$Body.get("i-body").getAsJsonObject();
							JsonArray funcDtl = new JsonArray();
							JsonObject funcDtlObj = new JsonObject();
							funcDtlObj.addProperty("memberId", app$Json.get("cif").getAsString());
							funcDtlObj.addProperty("funcName", "GET_CIF_SHARE_DEPOSIT");
							funcDtl.add(funcDtlObj);
							i$bdy.add("funcDetails", funcDtl);
							JsonObject data = srvcFunction.exeCallOrcl(ison$Body);
							// MSA00095 starts
							JsonObject ison$BodyCopy = new JsonObject();
							ison$BodyCopy = isonMsg.deepCopy();
							JsonObject i$bdyC = ison$BodyCopy.get("i-body").getAsJsonObject();
							JsonArray funcDetl = new JsonArray();
							JsonObject funcDetlObj = new JsonObject();
							funcDetlObj.addProperty("p_acc_no", data.get("GET_CIF_SHARE_DEPOSIT").getAsJsonObject().get("l_data").getAsString());
							funcDetlObj.addProperty("funcName", "fn_cifaccountreopen");
							funcDetl.add(funcDetlObj);
							i$bdyC.add("funcDetails", funcDetl);
							JsonObject data2 = srvcFunction.exeCallOrcl(ison$BodyCopy);
							if ((data.has("i-body")
									&& data.getAsJsonObject("i-body").getAsJsonArray("funcRes").size() < 1) || I$utils.$iStrFuzzyMatch(
											data2.get("fn_cifaccountreopen").getAsJsonObject().get("l_data").getAsString(),
											"N")) {

//								if(isonMsg.getAsJsonObject("i-body").has("casa150") && I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-body").get("casa150").getAsString(), "true")){
								app$Json.addProperty("casa150", "true");
								Random random = new Random();
								scanType = flght$oprs.get("OPR_NAME").getAsString();
								JsonObject trnData = new JsonObject();
								JsonObject i$body = new JsonObject();
								isonBody = new JsonObject();
								JsonObject loanDetails = app$Json.get("loanDetails").getAsJsonObject();
								isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
								// Construct tranData and append it back to jsonBody and finally to request
								i$body = flght$oprs.get("IsonBody").getAsJsonObject().get("i-body").getAsJsonObject();
								String prdCd = null;
								String accNo = loanDetails.get("loanBranch").getAsString()
										+ app$Json.get("cif").getAsString() + "150"
										+ String.format("%04d", random.nextInt(10000));

								try {
									prdCd = app$Json.get("loanDetails").getAsJsonObject().get("loanProduct")
											.getAsString();
								} catch (Exception e) {
								}
								if (!I$utils.$iStrBlank(prdCd)) {
									trnData.addProperty("prdCd", prdCd);
								} else {
									trnData.addProperty("prdCd", "");
								}

								trnData.addProperty("150Account", accNo);
								trnData.addProperty("branch", loanDetails.get("loanBranch").getAsString());
								trnData.addProperty("ccy", fecthValueFormJson(loanDetails, "currencyCode", ""));
								trnData.addProperty("custNo", fecthValueFormJson(app$Json, "cif", ""));
								trnData.addProperty("amount", fecthValueFormJson(loanDetails, "amount", ""));
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);

							} else {
//								app$Json.addProperty("casa150", "true");
								app$Json.addProperty("accountNo",
										data.getAsJsonObject("GET_CIF_SHARE_DEPOSIT").get("l_data").getAsString());
								JsonObject applId = new JsonObject();
								applId.addProperty("applicationId", app$Json.get("applicationId").getAsString());
								if (I$utils.$iStrFuzzyMatch(
										data2.get("fn_cifaccountreopen").getAsJsonObject().get("l_data").getAsString(),
										"Y")) {
									JsonObject isonCopy = isonMsg.deepCopy();
									JsonObject trnData = new JsonObject();
									JsonObject bodyData = new JsonObject();
									JsonObject headerData = new JsonObject();
									JsonObject configData = new JsonObject();
									String branch = data2.get("fn_cifaccountreopen").getAsJsonObject().get("p_acc_no")
											.getAsString().substring(0, 3);
									JsonObject transmitterData = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER",
											"{\"trnCd\":\"CASA150REOPEN\"}");

									trnData.addProperty("accNo",
											data2.get("fn_cifaccountreopen").getAsJsonObject().get("p_acc_no").getAsString());
									trnData.addProperty("branch", branch);

									try {
										configData.addProperty("imecd",
												isonMsg.get("i-config").getAsJsonObject().get("imecd").getAsString());
									}catch(Exception e) {
										configData.addProperty("imecd","");
									}

									bodyData.add("trnData", trnData);
									bodyData.addProperty("trnCd", "CASA150REOPEN");
									bodyData.addProperty("ctrnCd", transmitterData.get("ctrnCd").getAsString());
									bodyData.addProperty("ctrnOpr", transmitterData.get("ctrnOpr").getAsString());
									bodyData.addProperty("ctrnOpr1", transmitterData.get("ctrnOpr1").getAsString());
									bodyData.addProperty("ctrnOpr2", transmitterData.get("ctrnOpr2").getAsString());
									bodyData.addProperty("ctrnOpr3", transmitterData.get("ctrnOpr3").getAsString());
									bodyData.addProperty("trnOpr", transmitterData.get("trnOpr").getAsString());
									bodyData.addProperty("trnOpr1", transmitterData.get("trnOpr1").getAsString());
									bodyData.addProperty("trnOpr2", transmitterData.get("trnOpr2").getAsString());
									bodyData.addProperty("trnOpr3", transmitterData.get("trnOpr3").getAsString());
									bodyData.addProperty("extSys", transmitterData.get("extSys").getAsString());
									try {
									bodyData.addProperty("tranId", app$Json.get("tranId").getAsString());
									}catch(Exception e) {
										bodyData.addProperty("tranId", "");
									}

									headerData.addProperty("screenid", "XEXCBRFD");
									headerData.addProperty("operation", "CREATE");
									headerData.addProperty("operation1", "@");
									headerData.addProperty("operation2", "@");
									headerData.addProperty("operation3", "@");
									headerData.addProperty("trnBrn", branch);
									try {
									headerData.addProperty("msg-id",
											isonMsg.get("i-header").getAsJsonObject().get("msg-id").getAsString());
									}catch(Exception e) {
										headerData.addProperty("msg-id","");
									}

									isonCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonCopy, i$ResM.I_BDYTAG,
											bodyData);
									isonCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonCopy, i$ResM.I_HEADER,
											headerData);
									isonCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonCopy, i$ResM.I_CONFIG,
											configData);
									JsonObject sysResp = I$coreSys.coreReqFwd(isonCopy);

									String applicationId = app$Json.get("applicationId").getAsString();
									JsonObject filter = new JsonObject();
									JsonObject upData = new JsonObject();
									upData.add("tranCdData", sysResp);
									filter.addProperty("applicationId", applicationId);
									JsonObject updateLonaApp = db$Ctrl.db$UpdateRow("ICOR_C_LD_LEAD_APPLICATIONS", upData,
											filter);

									JsonObject flxCubeResp = i$ResM.getGobalValJObj("tranCdResponse");
									String statMsg = i$ResM.getStatMsg(sysResp);
									if (I$utils.$iStrFuzzyMatch(statMsg, i$ResM.I_SUCC)) {
										String msgText = sysResp.get("i-stat").getAsJsonObject().get("i-success")
												.getAsJsonObject().get("msgtext").getAsString();
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, msgText);
									} else {
										String msgText = sysResp.get("i-stat").getAsJsonObject().get("i-error")
												.getAsJsonObject().get("msgtext").getAsString();
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, msgText);
										break;
									}
									data2.addProperty("applicationId", app$Json.get("applicationId").getAsString());
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, data2);
//									break;
								} else if (I$utils.$iStrFuzzyMatch(
										data2.get("fn_cifaccountreopen").getAsJsonObject().get("l_data").getAsString(),
										"X")) {
									data2.addProperty("applicationId", app$Json.get("applicationId").getAsString());
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, data2);
//									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, applId);
								} // MSA00095 ends
								continue; // #MVT00135 changes
							} // #SRM00065 changes start
						} catch (Exception e) {
							app$Json.addProperty("accountNo","");
							logger.debug(e.getMessage());
						}

					} else if(I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "LOAN_AUTHORIZATION")) {
						JsonObject loanDetails = app$Json.get("loanDetails").getAsJsonObject();
						JsonObject i$body = new JsonObject();
						i$body = flght$oprs.get("IsonBody").getAsJsonObject().get("i-body").getAsJsonObject();
						if (I$utils.$iStrFuzzyMatch(loanDetails.get("loanProduct").getAsString(), "AL01")
								|| I$utils.$iStrFuzzyMatch(loanDetails.get("loanProduct").getAsString(), "CL01")) {
							JsonObject trnData = new JsonObject();
							trnData.addProperty("branchCode", loanDetails.get("loanBranch").getAsString());
							trnData.addProperty("loanAcNo",
									icbsbody.getAsJsonObject("LEAD_CREATION").get("ACCNO").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						}

					} // SRM00065 changes end
					else if(I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SETTLEMENT_MAINTENANCE_WORKFLOW")) {
						if(JBody.has("fn_cifaccountreopen") && (I$utils.$iStrFuzzyMatch(JBody.get("fn_cifaccountreopen").getAsJsonObject().get("l_data").getAsString(), "X") || I$utils.$iStrFuzzyMatch(JBody.get("fn_cifaccountreopen").getAsJsonObject().get("l_data").getAsString(), "Y")) && I$utils.$iStrFuzzyMatch(app$Json.get("loanDetails").getAsJsonObject().get("loanProduct").getAsString(), "AL01")) {
							continue;
						}//MSA00095 changes
						//#MVT00156 changes begins
						String ldata;
						JsonObject ison$Body = isonMsg.deepCopy();
						JsonObject i$bdy = ison$Body.get("i-body").getAsJsonObject();
						JsonArray funcDtl = new JsonArray();
						JsonObject funcDtlObj = new JsonObject();
						funcDtlObj.addProperty("p_member", app$Json.get("cif").getAsString());
						funcDtlObj.addProperty("funcName", "fn_getCIFSettleINS");
						funcDtl.add(funcDtlObj);
						i$bdy.add("funcDetails", funcDtl);
						JsonObject data = srvcFunction.exeCallOrcl(ison$Body).getAsJsonObject("i-body")
								.getAsJsonArray("funcRes").get(0).getAsJsonObject();
						try {
							ldata = data.getAsJsonObject("fn_getCIFSettleINS").get("l_data").getAsString();
						} catch (Exception e) {
							ldata = "";
						}

						if (I$utils.$iStrBlank(ldata)) { // #MVT00134 changes  //#MVT00156 changes ends
//						if(isonMsg.getAsJsonObject("i-body").has("casa150") && I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-body").get("casa150").getAsString(), "true")){
							scanType = flght$oprs.get("OPR_NAME").getAsString();
							JsonObject trnData = new JsonObject();
							JsonObject i$body = new JsonObject();
							isonBody = new JsonObject();
							JsonObject loanDetails = app$Json.get("loanDetails").getAsJsonObject();
							isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
							// Construct tranData and append it back to jsonBody and finally to request
							i$body = flght$oprs.get("IsonBody").getAsJsonObject().get("i-body").getAsJsonObject();
							String prdCd = null;

							try {
								prdCd = app$Json.get("loanDetails").getAsJsonObject().get("loanProduct").getAsString();
							} catch (Exception e) {
							}
							if (!I$utils.$iStrBlank(prdCd)) {
								trnData.addProperty("prdCd", prdCd);
							} else {
								trnData.addProperty("prdCd", "");
							}
							//#MVT00138 code changes
							try {
								trnData.addProperty("accNo", icbsbody.getAsJsonObject("CASA150_ACCOUNT_CREATION")
										.get("CASAACCNO").getAsString());
							} catch (Exception e) {
								trnData.addProperty("accNo", app$Json.get("accountNo").getAsString());
							} //#MVT00138 code ends
							trnData.addProperty("branch", loanDetails.get("loanBranch").getAsString());
							trnData.addProperty("ccy", fecthValueFormJson(loanDetails, "currencyCode", ""));
							trnData.addProperty("custNo", fecthValueFormJson(app$Json, "cif", ""));
							trnData.addProperty("amount", fecthValueFormJson(loanDetails, "amount", ""));
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						} else { //#MVT00135 changes
							continue;
						}
					} //#SRM00044 changes end
					else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CD_CBS")) {
						String creditAccNo= "";
						Random rand = new Random();
						JsonObject filter = new JsonObject();
						JsonObject i$body = new JsonObject();
						JsonObject trnData = new JsonObject();
						
						i$body = isonBody.get("i-body").getAsJsonObject();
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject loanDetails = app$Json.get("loanDetails").getAsJsonObject();
						try {
							creditAccNo = icbsbody.getAsJsonObject("CASA150_ACCOUNT_CREATION").get("CASAACCNO").getAsString();
						} catch(Exception e) {
							creditAccNo  =  app$Json.get("accountNo").getAsString();
						}
						
						isonBody = new JsonObject();
						isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
						filter.addProperty("Type", "CBS_BRANCH");
						filter.addProperty("BranchCode", i$body.getAsJsonObject("trnData").get("branchNo").getAsString());
						JsonObject cbseData = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter);						
//						String valueDate = cbseData.get("BranchDate").getAsString();
						
						int batchNo = rand.nextInt(9000) + 1000;;
//						batchNo = String.format("%04d", rand.nextInt(10000));
						trnData.addProperty("batchNo", batchNo);
						trnData.addProperty("valueDate", fecthValueFormJson(cbseData, "BranchDate", ""));
						trnData.addProperty("lcyAmount", fecthValueFormJson(loanDetails, "amount", ""));
						trnData.addProperty("branchCode", loanDetails.get("loanBranch").getAsString());
						trnData.addProperty("creditBranchCode", loanDetails.get("loanBranch").getAsString());
						trnData.addProperty("creditAccNo", creditAccNo);

						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
					}
					else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_LEAD_CREATION")) { // #00000017
						
						if (!I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(app$Json.get("loanDetails").getAsJsonObject(),"loanProduct"),"LOC")) {
							scanType = flght$oprs.get("OPR_NAME").getAsString();
							JsonObject trnData = new JsonObject();
							isonBody = new JsonObject();
							isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
							// Construct tranData and append it back to jsonBody and finally to request
							JsonObject i$body = new JsonObject();
							i$body = isonBody.get("i-body").getAsJsonObject();
							// populate the values to be the jsonObject
							JsonObject loanDetails = new JsonObject();
							JsonObject loanSummary = new JsonObject(); //PIYUSH CHANGES
							JsonArray sharesBlockingAmountDetails = new JsonArray();
							JsonArray fdBlockingAmountDetails = new JsonArray();				
							JsonObject shareDetails = new JsonObject();
							JsonObject fdDetails = new JsonObject();
							//#PKY00055 starts
							String prdCd = null;
							try {
								prdCd = app$Json.get("loanDetails").getAsJsonObject().get("loanProduct").getAsString();
							} catch(Exception e){							
							}
							loanDetails = app$Json.get("loanDetails").getAsJsonObject();
							loanSummary = app$Json.get("loanSummary").getAsJsonObject(); //PIYUSH CHANGES
//							JsonObject extraDetails = app$Json.get("extraDetails").getAsJsonObject();
							try {
								if (!I$utils.$iStrFuzzyMatch(app$Json.get("iLeadSource").getAsString(),
										"ImpactoAMBank")) {
									trnData.addProperty("branch", fecthValueFormJson(loanDetails, "loanBranch", "")); // PIYUSH HANGES
								} else {
									trnData.addProperty("branch", fecthValueFormJson(loanSummary, "loanBranch", "")); // PIYUSH CHANGES
								}
							} catch (Exception e) {
								trnData.addProperty("branch", fecthValueFormJson(loanSummary, "loanBranch", "")); // PIYUSH CHANGES
							}

							try { // #MVT00135 changes begins
								//MSA00073 starts
								if (I$utils.$iStrFuzzyMatch(app$Json.get("loanDetails").getAsJsonObject()
										.get("loanProduct").getAsString(), "LOC")) {
									trnData.addProperty("accNo",
											icbsbody.getAsJsonObject("LOC_CREATION").get("CASAACCNO").getAsString());
								}else {
									trnData.addProperty("accNo",
											icbsbody.getAsJsonObject("CASA150_ACCOUNT_CREATION").get("CASAACCNO").getAsString());
								}//MSA00073 ends
							} catch (Exception e) {
								trnData.addProperty("accNo", app$Json.get("accountNo").getAsString());
							}  //#MVT00135 changes ends
							trnData.addProperty("trnCode", "154");
							trnData.addProperty("ccy", fecthValueFormJson(loanDetails, "currencyCode", ""));
							trnData.addProperty("custNo",fecthValueFormJson(app$Json, "cif", ""));
							trnData.addProperty("amount", fecthValueFormJson(loanDetails, "amount", ""));
							trnData.addProperty("linkages", fecthValueFormJson(loanDetails, "linkages", ""));  //#SRM00037 changes start
							trnData.addProperty("tenor", fecthValueFormJson(loanDetails, "tenor", "")); // PIYUSH CHANGES
							trnData.addProperty("emi", fecthValueFormJson(loanDetails, "emi", "")); // PIYUSH CHANGES
							trnData.addProperty("firstPaymentDate", fecthValueFormJson(loanSummary, "firstPaymentDate", "")); // PIYUSH CHANGES
							try { 
								if (prdCd.equalsIgnoreCase("AL01")) {
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(loanDetails, "securityType"),"Shares")) {
										sharesBlockingAmountDetails = loanDetails.get("sharesBlockingAmountDetails").getAsJsonArray();

										for (int k = 0; k < sharesBlockingAmountDetails.size(); k++) {
											shareDetails = sharesBlockingAmountDetails.get(k).getAsJsonObject();
											trnData.addProperty("securityType", "C");
											trnData.addProperty("accountNumber_" + k,
													shareDetails.get("accNum").getAsString());
											trnData.addProperty("accountDescription_" + k,
													shareDetails.get("accDesc").getAsString());
										}
									} else if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(loanDetails, "securityType"), "Fixed Deposit")) {
										fdBlockingAmountDetails = loanDetails.get("fdBlockingAmountDetails").getAsJsonArray();

										for (int j = 0; j < fdBlockingAmountDetails.size(); j++) {
											fdDetails = fdBlockingAmountDetails.get(j).getAsJsonObject();
											if (I$utils.$iStrFuzzyMatch(fdDetails.get("isSelected").getAsString(),"true")) {
												trnData.addProperty("securityType", "D");
												trnData.addProperty("accountNumber_" + j,shareDetails.get("accNum").getAsString());
												trnData.addProperty("accountDescription_" + j,shareDetails.get("accDesc").getAsString());
											}

										}
									} else {
										trnData.addProperty("accountNumber_0", " ");
										trnData.addProperty("accountDescription_0", " ");
										trnData.addProperty("securityType", " ");

									}
								}else {
									trnData.addProperty("accountNumber_0", " ");
									trnData.addProperty("accountDescription_0", " ");
									trnData.addProperty("securityType", " ");
								}
							} catch (Exception e) { //#MVT00134 changes begins
								trnData.addProperty("accountNumber_0", " ");
								trnData.addProperty("accountDescription_0", " ");
								trnData.addProperty("securityType", " ");
							} //SRM00037 changes end //#MVT00134 changes ends
							//#PKY00055 ends
							//#PM000106 CHANGES STARTS
							String branchDate = null;
							try {
								branchDate = Im$utils.dateFormatter(app$Json.get("loanDetails").getAsJsonObject().get("branchDate").getAsString());
							} catch (Exception e) {
							}
							if (!I$utils.$iStrBlank(branchDate)){
								trnData.addProperty("branchDate", branchDate);
							} else {
								trnData.addProperty("branchDate", "");
							}
							
							String maturityDate = null;
							try {
								maturityDate = Im$utils.dateFormatter(app$Json.get("loanDetails").getAsJsonObject().get("maturityDate").getAsString());
							} catch (Exception e) {
							}
							if (!I$utils.$iStrBlank(maturityDate)){
								trnData.addProperty("maturityDate", maturityDate);
							} else {
								trnData.addProperty("maturityDate", "");
							}
							if (!I$utils.$iStrBlank(prdCd))
							{
								trnData.addProperty("prdCd", prdCd);
							} else {
								trnData.addProperty("prdCd", "");
							}
	                        
							// Capturing UDE Details
							
							String intCode = "INTEREST_RATE";
							String penalCode = "PENAL_INT_RATE";
							String unionDisb = "UNION_DISB";
							String unionRoll = "UNION_ROLL";
							String unionVami = "UNION_VAMI";
							String unionDisbRate = "31";
//							String penalRate = "12"; //PIYUSH CHANGES
//							String penalRate = "4.8"; //PIYUSH CHANGES
							
							//#MVT00155 changes begins
							if (prdCd.equalsIgnoreCase("AL01")) {
								trnData.addProperty("transUnion", "N");
							} else {
								trnData.addProperty("transUnion", "Y");
							}
							//#MVT00155 changes ends
							if (prdCd.equalsIgnoreCase("CL01"))
							{
							  	try {
									trnData.addProperty("transUnion", fecthValueFormJson(loanDetails, "transunionAgreement", "Y"));//MSA
							  		trnData.addProperty("intCode", intCode);
							  		trnData.addProperty("penalCode", penalCode);
							  		trnData.addProperty("unionDisb", unionDisb);
							  		trnData.addProperty("unionRoll", unionRoll);
							  		trnData.addProperty("unionVami", unionVami);
									trnData.addProperty("intRate", fecthValueFormJson(loanDetails, "intrestRate", ""));  //#PKY00055 changes
									trnData.addProperty("penalRate", fecthValueFormJson(loanDetails, "intrestRate", ""));
									trnData.addProperty("unionDisbRate", unionDisbRate);
									trnData.addProperty("unionRollRate", unionDisbRate);
									trnData.addProperty("unionVamiRate", unionDisbRate);
							  	}
							  	catch(Exception e)
							  	{
							  		trnData.addProperty("intCode", "");
							  		trnData.addProperty("penalCode", "");
							  		trnData.addProperty("unionDisb", "");
							  		trnData.addProperty("unionRoll", "");
							  		trnData.addProperty("unionVami", "");
									trnData.addProperty("intRate", "");
									trnData.addProperty("penalRate", "");
									trnData.addProperty("unionDisbRate", "");
									trnData.addProperty("unionRollRate", "");
									trnData.addProperty("unionVamiRate", "");
							  	}
							} else {
							   try {
							  		trnData.addProperty("intCode", intCode);
							  		trnData.addProperty("penalCode", penalCode); 
							  		trnData.addProperty("unionDisb", "");
							  		trnData.addProperty("unionRoll", "");
							  		trnData.addProperty("unionVami", "");
									trnData.addProperty("intRate", fecthValueFormJson(loanDetails, "intrestRate", "")); //#PKY00055 changes
									trnData.addProperty("penalRate", fecthValueFormJson(loanDetails, "intrestRate", ""));
									trnData.addProperty("unionDisbRate", "");
									trnData.addProperty("unionRollRate", "");
									trnData.addProperty("unionVamiRate", "");
							   }	
							   catch(Exception e)
							   {
							  		trnData.addProperty("intCode", "");
							  		trnData.addProperty("penalCode", ""); 
							  		trnData.addProperty("unionDisb", "");
							  		trnData.addProperty("unionRoll", "");
							  		trnData.addProperty("unionVami", "");
									trnData.addProperty("intRate", "");
									trnData.addProperty("penalRate", "");
									trnData.addProperty("unionDisbRate", "");
									trnData.addProperty("unionRollRate", "");
									trnData.addProperty("unionVamiRate", ""); 
							   }
							}
							
							// Capturing References Details
							
							String ref1FirstName = null;
							String ref1LastName = null;
							String ref1FullName = null;
							String ref1ContCode = null;
							String ref1ContNo = null;
							StringBuilder contactNo1 = new StringBuilder();
							try {
								ref1FirstName = fecthValueFormJson(loanDetails, "reference1FirstName", "");  //#PKY00055 changes //MSA
								ref1LastName = fecthValueFormJson(loanDetails, "reference1LastName", "");    //#PKY00055 changes //MSA
								ref1ContCode = fecthValueFormJson(loanDetails, "reference1ContactNumberCode", ""); //MSA00018 changes starts //MSA
								ref1ContNo = fecthValueFormJson(loanDetails, "reference1ContactNumber", ""); //MSA
								contactNo1.append(ref1ContCode);
								contactNo1.append("-");
								contactNo1.append(ref1ContNo);//MSA00018 changes ends
							} catch(Exception e){							
							}
							if (!I$utils.$iStrBlank(ref1FirstName))
							{
								ref1FullName = ref1FirstName + " " + ref1LastName + " " + contactNo1;
								trnData.addProperty("reference1", ref1FullName);
							} else {
								trnData.addProperty("reference1", "");
							}
							
							String ref2FirstName = null;
							String ref2LastName = null;
							String ref2FullName = null;
							String ref2ContCode = null;
							String ref2ContNo = null;
							StringBuilder contactNo2 = new StringBuilder();
							try {
								ref2FirstName = fecthValueFormJson(loanDetails, "reference2FirstName", "");  //#PKY00055 changes //MSA
								ref2LastName = fecthValueFormJson(loanDetails, "reference2LastName", "");   //#PKY00055 changes //MSA
								ref2ContCode = fecthValueFormJson(loanDetails, "reference2ContactNumberCode", "");//MSA00018 changes starts //MSA
								ref2ContNo = fecthValueFormJson(loanDetails, "reference2ContactNumber", ""); //MSA
								contactNo2.append(ref2ContCode);
								contactNo2.append("-");
								contactNo2.append(ref2ContNo);
							} catch(Exception e){							
							}
							if (!I$utils.$iStrBlank(ref2FirstName))
							{
								ref2FullName = ref2FirstName + " " + ref2LastName + " " + contactNo2;
								trnData.addProperty("reference2", ref2FullName);//MSA00018 changes ends
							} else {
								trnData.addProperty("reference2", "");
							}
							
							// Capturing borrower and co-borrower details
							String brwCustNo = null;
							String coBowCustNo1 = null;
							String coBowCustNo2 = null;
							int brwAmount ;
							int coBow1amount;
							int coBow2amount;
							String coBowResp = "CBW";
							
							try {
							brwCustNo = app$Json.get("cif").getAsString();
							}
							catch (Exception e)
							{
								brwCustNo = "";	
							}
							
							try {
							coBowCustNo1 = app$Json.get("coBorrower1CustomerId").getAsString();
							}
							catch (Exception e)
							{
								coBowCustNo1 = "";	
							}
							
							try {
							coBowCustNo2 = app$Json.get("coBorrower2CustomerId").getAsString();
							}
							catch (Exception e)
							{
								coBowCustNo2 = "";	
							}
							
							try {
							brwAmount = app$Json.get("loanDetails").getAsJsonObject().get("amount").getAsInt();   //#PKY00055 changes
							}
							catch (Exception e)
							{
								brwAmount = 0;	
							}
							
							if (!I$utils.$iStrBlank(brwCustNo))
							{
								trnData.addProperty("brwCustNo", brwCustNo);
								trnData.addProperty("brwCustName", fecthValueFormJson(app$Json, "CustomerFullName", ""));   //#PKY00055 changes
								trnData.addProperty("perCustNo", 100);	
								trnData.addProperty("brwAmount", brwAmount);
							}
							else
							{
								trnData.addProperty("brwCustNo", "");
								trnData.addProperty("brwCustName", "");
								trnData.addProperty("perCustNo", "");	
								trnData.addProperty("brwAmount", "");
							}
							
							if (!I$utils.$iStrBlank(coBowCustNo1))
							{
								trnData.addProperty("coBowCustNo1", coBowCustNo1);
								trnData.addProperty("coBowCustName1", fecthValueFormJson(app$Json, "coBorrower1CustomerFullName", ""));   //#PKY00055 changes
								trnData.addProperty("perCustNo", 50);
								trnData.addProperty("perCustNo1", 50);
								coBow1amount = brwAmount/2;
								trnData.addProperty("brwAmount", coBow1amount);
								trnData.addProperty("coBow1amount", coBow1amount);
								trnData.addProperty("coBowResp1", coBowResp);
								trnData.addProperty("branchDate1", fecthValueFormJson(app$Json, "branchDate1", ""));
							}
							else
							{
								trnData.addProperty("coBowCustNo1", "");
								trnData.addProperty("coBowCustName1", "");
//								trnData.addProperty("perCustNo", "");
								trnData.addProperty("perCustNo1", "");
//								trnData.addProperty("brwAmount", "");
								trnData.addProperty("coBow1amount", "");
								trnData.addProperty("coBowResp1", "");
								trnData.addProperty("branchDate1", "");
							}
							
							if (!I$utils.$iStrBlank(coBowCustNo2))
							{
								trnData.addProperty("coBowCustNo2", coBowCustNo2);
								trnData.addProperty("coBowCustName2", fecthValueFormJson(app$Json, "coBorrower2CustomerFullName", ""));   //#PKY00055 changes
								trnData.addProperty("perCustNo", 33.34);
								trnData.addProperty("perCustNo1", 33.33);
								trnData.addProperty("perCustNo2", 33.33);
								coBow2amount = brwAmount/3;
								trnData.addProperty("brwAmount", coBow2amount);
								trnData.addProperty("coBow1amount", coBow2amount);
								trnData.addProperty("coBow2amount", coBow2amount);
								trnData.addProperty("coBowResp2", coBowResp);
								trnData.addProperty("branchDate2", fecthValueFormJson(app$Json, "branchDate2", ""));
							}
							else
							{
								trnData.addProperty("coBowCustNo2", "");
								trnData.addProperty("coBowCustName2", "");
//								trnData.addProperty("perCustNo", "");
//								trnData.addProperty("perCustNo1", "");
								trnData.addProperty("perCustNo2", "");
//								trnData.addProperty("brwAmount", "");
//								trnData.addProperty("coBow1amount", "");
								trnData.addProperty("coBow2amount", "");
								trnData.addProperty("coBowResp2", "");
								trnData.addProperty("branchDate2", "");
							}
							
							// Capturing Approval Details Info
							String udfDate = null;
							if (prdCd.equalsIgnoreCase("CL01")) {
								try {
									udfDate = Im$utils.dateFormatter(fecthValueFormJson(loanDetails, "udfDate", "")); // #PKY00055 changes //MSA
								} catch (Exception e) {
								}
								if (!I$utils.$iStrBlank(udfDate)) {
									trnData.addProperty("udfDate", udfDate);
								} else {
									trnData.addProperty("udfDate", "");
								}
								// #PKY00055 starts
//								try {
//									trnData.addProperty("loanPurpose",fecthValueFormJson(loanDetails, "purposeLoan", "")); //MSA
//								} catch (Exception e) {
//									trnData.addProperty("loanPurpose", " ");
//								}
//								try {
//									trnData.addProperty("loanPurposeDesc",fecthValueFormJson(loanDetails, "purposeLoanDesc", "")); //MSA
//								} catch (Exception e) {
//									trnData.addProperty("loanPurposeDesc", " ");
//								}
								try {
									trnData.addProperty("loanPurpose",fecthValueFormJson(loanDetails, "loanPurpose", ""));
								} catch (Exception e) {
									trnData.addProperty("loanPurpose", " ");
								}
								try {
									trnData.addProperty("loanPurposeDesc",fecthValueFormJson(loanDetails, "loanPurposeDesc", ""));
								} catch (Exception e) {
									trnData.addProperty("loanPurposeDesc", " ");
								}
//							trnData.addProperty("transUnion", fecthValueFormJson(extraDetails, "transunionAgreement", "Y"));
								try {
									trnData.addProperty("comments", fecthValueFormJson(loanDetails, "comments", "")); //MSA
								} catch (Exception e) {
									trnData.addProperty("comments", " ");
								}
								try {
									if (!I$utils.$iStrFuzzyMatch(app$Json.get("iLeadSource").getAsString(), "ImpactoAMBank")) {
										trnData.addProperty("confirmedBranch",fecthValueFormJson(loanDetails, "confirmedBranch", "")); // PIYUSH CHANGES //MSA
									} else {
										trnData.addProperty("confirmedBranch",fecthValueFormJson(loanSummary, "loanBranch", "")); // PIYUSH CHANGES
									}
								} catch (Exception e) {
									trnData.addProperty("confirmedBranch",fecthValueFormJson(loanSummary, "loanBranch", "")); // PIYUSH CHANGES
								}
								try {
									trnData.addProperty("loanOfficer",fecthValueFormJson(loanDetails, "loanOfficer", "")); //MSA
								} catch (Exception e) {
									trnData.addProperty("loanOfficer", " ");
								}
//								try {
//									trnData.addProperty("promotionId",fecthValueFormJson(loanDetails, "promotionId", "")); //MSA
//								} catch (Exception e) {
//									trnData.addProperty("promotionId", " ");
//								}
								trnData.addProperty("promotionCode","");
								
								try {
									trnData.addProperty("promotionCodeDesc",fecthValueFormJson(loanDetails, "promotionCodeDesc", ""));
								} catch (Exception e) {
									trnData.addProperty("promotionCodeDesc", " ");
								}
								try {
									trnData.addProperty("purposeDescription",fecthValueFormJson(loanDetails, "purposeDescription", ""));
								} catch (Exception e) {
									trnData.addProperty("purposeDescription", " ");
								}
								try {
									trnData.addProperty("promotionMedium",fecthValueFormJson(loanDetails, "promotionMedium", "")); //MSA
								} catch (Exception e) {
									trnData.addProperty("promotionMedium", " ");
								}
								try {
									trnData.addProperty("soaInfo", fecthValueFormJson(loanDetails, "soaInfo", "")); //MSA
								} catch (Exception e) {
									trnData.addProperty("soaInfo", " ");
								}
								// #PKY00055 ends
								// #PM000106 CHANGES ENDS
							}else { //MSA00080 changes starts
								try {
									udfDate = Im$utils.dateFormatter(fecthValueFormJson(loanDetails, "udfDate", "")); // #PKY00055 changes
								} catch (Exception e) {
								}
								if (!I$utils.$iStrBlank(udfDate)) {
									trnData.addProperty("udfDate", udfDate);
								} else {
									trnData.addProperty("udfDate", "");
								}
								// #PKY00055 starts
								try {
									trnData.addProperty("loanPurpose",fecthValueFormJson(loanDetails, "loanPurpose", ""));
								} catch (Exception e) {
									trnData.addProperty("loanPurpose", " ");
								}
								try {
									trnData.addProperty("loanPurposeDesc",fecthValueFormJson(loanDetails, "loanPurposeDesc", ""));
								} catch (Exception e) {
									trnData.addProperty("loanPurposeDesc", " ");
								}
//							trnData.addProperty("transUnion", fecthValueFormJson(extraDetails, "transunionAgreement", "Y"));
								try {
									trnData.addProperty("comments", fecthValueFormJson(loanDetails, "comments", ""));
								} catch (Exception e) {
									trnData.addProperty("comments", " ");
								}
								try {
									if (!I$utils.$iStrFuzzyMatch(app$Json.get("iLeadSource").getAsString(), "ImpactoAMBank")) {
										trnData.addProperty("confirmedBranch",fecthValueFormJson(loanDetails, "confirmedBranch", "")); // PIYUSH CHANGES
									} else {
										trnData.addProperty("confirmedBranch",fecthValueFormJson(loanSummary, "loanBranch", "")); // PIYUSH CHANGES
									}
								} catch (Exception e) {
									trnData.addProperty("confirmedBranch",fecthValueFormJson(loanSummary, "loanBranch", "")); // PIYUSH CHANGES
								}
								try {
									trnData.addProperty("loanOfficer",fecthValueFormJson(loanDetails, "loanOfficer", ""));
								} catch (Exception e) {
									trnData.addProperty("loanOfficer", " ");
								}
								try {
									if (prdCd.equalsIgnoreCase("AL01")) {
										trnData.addProperty("promotionCode", "AL01");
									} else {
										trnData.addProperty("promotionCode", "");
									}
								} catch (Exception e) {
									trnData.addProperty("promotionCode", "");
								}
								try {
									trnData.addProperty("promotionCodeDesc",fecthValueFormJson(loanDetails, "promotionCodeDesc", ""));
								} catch (Exception e) {
									trnData.addProperty("promotionCodeDesc", " ");
								}
								try {
									trnData.addProperty("purposeDescription",fecthValueFormJson(loanDetails, "purposeDescription", ""));
								} catch (Exception e) {
									trnData.addProperty("purposeDescription", " ");
								}
								try {
									trnData.addProperty("promotionMedium",fecthValueFormJson(loanDetails, "promotionMedium", ""));
								} catch (Exception e) {
									trnData.addProperty("promotionMedium", " ");
								}
								try {
									trnData.addProperty("soaInfo", fecthValueFormJson(loanDetails, "soaInfo", ""));
								} catch (Exception e) {
									trnData.addProperty("soaInfo", " ");
								}
								// #PKY00055 ends
								// #PM000106 CHANGES ENDS
							} //MSA00080 changes ends
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body); // #00000017  change Ends
						}
						 else { 
							continue;
						}
						
					}else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_COLLATERAL_CREATION")) {    //#PKY00030 starts
						
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject trnData = new JsonObject();
						JsonObject collateralInfo = app$Json.get("collateralInfo").getAsJsonObject(); 
						isonBody = new JsonObject();
						isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
						// Construct tranData and append it back to jsonBody and finally to request
						JsonObject i$body = new JsonObject();
						i$body = flght$oprs.get("IsonBody").getAsJsonObject().get("i-body").getAsJsonObject();
						trnData.addProperty("sharingReq", collateralInfo.get("sharingRequired").getAsString()); 
						trnData.addProperty("autoPoolCreat", collateralInfo.get("autoPoolCreate").getAsString()); 
						trnData.addProperty("available", collateralInfo.get("available").getAsString()); 
						trnData.addProperty("issuerName", collateralInfo.get("issuerName").getAsString()); 
						trnData.addProperty("interestRate", collateralInfo.get("interestRate").getAsString()); 
						trnData.addProperty("collateralCurrency", collateralInfo.get("collateralCurrency").getAsString()); 
						trnData.addProperty("collateralCode", collateralInfo.get("collateralCode").getAsString());  
						trnData.addProperty("collateralValue", collateralInfo.get("collateralValue").getAsString()); 
						trnData.addProperty("haircut", collateralInfo.get("haircut").getAsString()); 
						trnData.addProperty("lendableMargin", collateralInfo.get("lendableMargin").getAsString()); 
						trnData.addProperty("limitContribution", collateralInfo.get("limitContribution").getAsString());
						trnData.addProperty("startDate", collateralInfo.get("startDate").getAsString()); 
						trnData.addProperty("collateralType", collateralInfo.get("collateralType").getAsString()); 
						trnData.addProperty("secured", collateralInfo.get("secured").getAsString()); 
						trnData.addProperty("graceDays", collateralInfo.get("graceDays").getAsString()); 
						trnData.addProperty("branchCode", collateralInfo.get("branchCode").getAsString()); 
						trnData.addProperty("remarks", collateralInfo.get("remarks").getAsString()); 
						trnData.addProperty("contractRefNo", collateralInfo.get("contractReference").getAsString()); 
						trnData.addProperty("takeOver", collateralInfo.get("takenOver").getAsString()); 
						trnData.addProperty("categoryName", collateralInfo.get("collateralCategory").getAsString()); 
						trnData.addProperty("liabName", collateralInfo.get("liabilityName").getAsString()); 
						trnData.addProperty("liabNo", collateralInfo.get("liabilityNo").getAsString()); 
						trnData.addProperty("liabBranch", collateralInfo.get("branchCode").getAsString()); 
						trnData.addProperty("id", app$Json.get("cif").getAsString()); 
						trnData.addProperty("issuerRefNo", collateralInfo.get("issuerReferenceNo").getAsString()); 
						trnData.addProperty("collateralId", collateralInfo.get("collateralCode").getAsString()); 
						trnData.addProperty("revalCollat", collateralInfo.get("revaluateCollateral").getAsString());
						trnData.addProperty("source", collateralInfo.get("sourceCode").getAsString()); 
						trnData.addProperty("liabilityId", collateralInfo.get("liabilityNo").getAsString());
						trnData.addProperty("mortgageInitiated", "");
						trnData.addProperty("revokeable", ""); 

						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);      //#PKY00030 ends
						
					}else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_SOA_CREATION")) {    //#PKY00028 starts
						
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject trnData = new JsonObject();
						JsonObject soaDetails = app$Json.get("soaInfo").getAsJsonObject(); 
						isonBody = new JsonObject();
						isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
						// Construct tranData and append it back to jsonBody and finally to request
						JsonObject i$body = new JsonObject();
						i$body = flght$oprs.get("IsonBody").getAsJsonObject().get("i-body").getAsJsonObject();
						trnData.addProperty("memberId", fecthValueFormJson(app$Json, "cif","")); 
						trnData.addProperty("referenceNumber", fecthValueFormJson(soaDetails, "referenceNumber", "")); 
						trnData.addProperty("memberName", fecthValueFormJson(app$Json, "CustomerFullName", "")); 
						trnData.addProperty("member2", fecthValueFormJson(soaDetails, "coBorrowerMemberId", ""));
						trnData.addProperty("memberName2", fecthValueFormJson(soaDetails, "coBorrowerMemberName", "")); 
						trnData.addProperty("ages", fecthValueFormJson(soaDetails, "monthlyExpenses_tecuRepayment", "")); 
						trnData.addProperty("totalMonthlyExp", fecthValueFormJson(soaDetails, "totalExpenses", ""));
						trnData.addProperty("monthlyExp", fecthValueFormJson(soaDetails, "netSalary_tecuRepayment", ""));  
						trnData.addProperty("income2", fecthValueFormJson(soaDetails, "coborrowerNetSalary", "")); 
						trnData.addProperty("income3", fecthValueFormJson(soaDetails, "memberNis", "")); 
						trnData.addProperty("income4", fecthValueFormJson(soaDetails, "coborrowerNis", "")); 
						trnData.addProperty("income5", fecthValueFormJson(soaDetails, "otherIncome", "")); 
						trnData.addProperty("residue", fecthValueFormJson(soaDetails, "residueAmount", ""));
						trnData.addProperty("tdsPer", fecthValueFormJson(soaDetails, "totalRepayment", "")); 
						trnData.addProperty("gross2", fecthValueFormJson(soaDetails, "coborrowerPension", "")); 
						trnData.addProperty("gross1", fecthValueFormJson(soaDetails, "memberPension", "")); 
						trnData.addProperty("assetRemarks", fecthValueFormJson(soaDetails, "miscellanecusRemarks", "")); 
						trnData.addProperty("job", fecthValueFormJson(soaDetails, "memberNetSalary", "")); 
						trnData.addProperty("soaDate", fecthValueFormJson(soaDetails, "soaDate", "")); 
						trnData.addProperty("totalNetSalary", fecthValueFormJson(soaDetails, "totalNetSalary", "")); 
						trnData.addProperty("totalGrossSalary", fecthValueFormJson(soaDetails, "totalGrossSalary", "")); 
						trnData.addProperty("landB", fecthValueFormJson(soaDetails, "landB", "")); 
						trnData.addProperty("annual", fecthValueFormJson(soaDetails, "annual", "")); 
						trnData.addProperty("totalAssets", fecthValueFormJson(soaDetails, "totalAssets", "")); 
						trnData.addProperty("tecuLoans", fecthValueFormJson(soaDetails, "tecuLoans", "")); 
						trnData.addProperty("totalLiabilities", fecthValueFormJson(soaDetails, "totalLiabilities", "")); 
						trnData.addProperty("netWorth", fecthValueFormJson(soaDetails, "netWorth", "")); 
						trnData.addProperty("property", fecthValueFormJson(soaDetails, "propertys", "")); 
						trnData.addProperty("tds", fecthValueFormJson(soaDetails, "tds", "")); 
						trnData.addProperty("gds", fecthValueFormJson(soaDetails, "gds", "")); 
						trnData.addProperty("remarks", fecthValueFormJson(soaDetails, "loanRemaks", "")); 
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);      //#PKY00028 ends
						
					}else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "LOAN_LOC_CREATION")) { //SKP00004 Starts
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(app$Json.get("loanDetails").getAsJsonObject(),"loanProduct"),"LOC")) {
							
							JsonObject trnData = new JsonObject();
							scanType = flght$oprs.get("OPR_NAME").getAsString();
							JsonObject loanDetails = app$Json.get("loanDetails").getAsJsonObject();
							JsonObject extraDetails = app$Json.get("extraDetails").getAsJsonObject();
							JsonObject memberInfo = app$Json.get("memberInfo").getAsJsonObject();
							JsonObject i$body = new JsonObject();
							String createdAt = null;
							String ModifiedAt = null;
							String locAcNo = null;
							String accClass = "155";
							String accNo = Integer.toString(I$utils.$igetRandonNum(9999, 1000));
							try {
								createdAt = Im$utils.dateFormatter(app$Json.get("createdAt").getAsString());
							} catch (Exception e) {
								
							}
							try {
								ModifiedAt = Im$utils.dateFormatter(app$Json.get("ModifiedAt").getAsString());
							} catch (Exception e) {
								
							}
							i$body = flght$oprs.get("IsonBody").getAsJsonObject().get("i-body").getAsJsonObject();
							trnData.addProperty("branchCode", fecthValueFormJson(loanDetails,"loanBranch", "")); 
							trnData.addProperty("custNo", fecthValueFormJson(app$Json,"cif", "")); 
							trnData.addProperty("custName", fecthValueFormJson(app$Json,"CustomerFullName", ""));
							trnData.addProperty("acDesc", fecthValueFormJson(app$Json,"CustomerFullName", ""));
							trnData.addProperty("ImabMaker", fecthValueFormJson(app$Json,"createdBy", "")); 
							trnData.addProperty("accNo", icbsbody.getAsJsonObject("LOC_CREATION").get("CASAACCNO").getAsString());
							locAcNo = loanDetails.get("loanBranch").getAsString()+app$Json.get("cif").getAsString()+accClass+accNo;
							trnData.addProperty("locAcNo",locAcNo); 
							if(createdAt != null || createdAt !="") {
							trnData.addProperty("IambMakerDt", I$utils.changeDateFormatS(createdAt,"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd"));
							}else {
								trnData.addProperty("IambMakerDt", "");
							}
							trnData.addProperty("ImabChecker", fecthValueFormJson(app$Json,"approvedby", ""));
							if (ModifiedAt != null || ModifiedAt != "") {
								trnData.addProperty("IambCheckerDt", I$utils.changeDateFormatS(ModifiedAt,
										"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd"));
							} else {
								trnData.addProperty("IambCheckerDt", "");
							}
							
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);    //SKP00004 Ends
						}else {
							continue;
						}
					}else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_FD_CREATION")) {
						
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						JsonObject trnData = new JsonObject();
						JsonObject app$JsonFd = app$Json.get("trnData").getAsJsonObject(); // #YPR00093 Starts
						isonBody = new JsonObject();
						isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
						// Construct tranData and append it back to jsonBody and finally to request
						JsonObject i$body = new JsonObject();
						i$body = isonBody.get("i-body").getAsJsonObject();
						// populate the values to be the jsonObject
//						i$body.addProperty("trnBrn", app$Json.get("branchCode").getAsString());
//						i$body.addProperty("tranId", app$Json.get("referenceNo").getAsString());
						trnData.addProperty("initialTDAmt", app$JsonFd.get("initialTDAmt").getAsString()); 
						trnData.addProperty("custNo", app$JsonFd.get("custNo").getAsString());
						trnData.addProperty("branchCode", app$JsonFd.get("branchCode").getAsString());
						trnData.addProperty("tdCcy", app$JsonFd.get("tdCcy").getAsString());
						trnData.addProperty("termAcNo", app$JsonFd.get("termAccNo").getAsString()); 
						trnData.addProperty("acCls", app$JsonFd.get("acCls").getAsString());
						trnData.addProperty("acDesc", app$JsonFd.get("acDesc").getAsString());
						trnData.addProperty("payInBranch", app$JsonFd.get("payInBranch").getAsString());
						trnData.addProperty("payInAccNo", app$JsonFd.get("payInAccNo").getAsString());
						trnData.addProperty("payOutBranch", app$JsonFd.get("payOutBranch").getAsString());
						trnData.addProperty("payOutAccNo", app$JsonFd.get("payOutAccNo").getAsString());
						// #YPR00093 Ends
						// #PM000111 CHANGES STARTS
						trnData.addProperty("dateOfIssue", app$JsonFd.get("dateOfIssue").getAsString());
						trnData.addProperty("IambMaker", fecthValueFormJson(app$Json, "verifierId", ""));
						trnData.addProperty("IambChecker", fecthValueFormJson(app$Json, "approverId", ""));

						String createdAt = null;
						String approvedAt=null; //#SRP00047 Starts

						try {
							createdAt = Im$utils.dateFormatter(app$Json.get("createdAt").getAsString());
						} catch (Exception e) {
						}
						try {
							approvedAt = Im$utils.dateFormatter(app$Json.get("approvedAt").getAsString()); //#SRP00047 Starts
						} catch (Exception e) {
						}

						if (createdAt != null || createdAt != "") {
							trnData.addProperty("IambMakerDt",
									I$utils.changeDateFormatS(createdAt, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd"));
						} else {
							trnData.addProperty("IambMakerDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd"));
						}

						if (approvedAt != null || approvedAt != "") {//#SRP00047 Starts
							trnData.addProperty("IambCheckerDt", I$utils.changeDateFormatS(approvedAt,
										"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd"));
						} else {
							trnData.addProperty("IambCheckerDt", I$utils.changeDateFormat(new Date(), "yyyy-MM-dd"));
						}//#SRP00047 Ends
																											 
			            // #PM000111 CHANGES ENDS
						// #PM000109 CHANGES STARTS
						String remarks = null;
						String bankName = null;
						String bankAccountNumber = null;
						String bankAddress = null;
						try {
							remarks =  app$JsonFd.get("paymentOfInterest").getAsString();
						}
						catch (Exception e)
						{
							remarks = "";
						}
						try {
							bankName =  app$JsonFd.get("bankName").getAsString();
						}
						catch (Exception e)
						{
							bankName = "";
						}
						try {
							bankAccountNumber =  app$JsonFd.get("bankAccountNumber").getAsString();
						}
						catch (Exception e)
						{
							bankAccountNumber = "";
						}
						try {
							bankAddress =  app$JsonFd.get("bankAddress").getAsString();
						}
						catch (Exception e)
						{
							bankAddress = "";
						}
						
						if (!I$utils.$iStrBlank(remarks))   //#PKY00056 changes
						{
						 try {	
							 if(!I$utils.$iStrFuzzyMatch(remarks, "Credit to bank account and provide bank information"))  //#PKY00056 changes
						  {
							  trnData.addProperty("remarks", remarks); 
						  }
						  else
						  {
							//  remarks = remarks + " " + bankName + " " + bankAccountNumber + " "  + bankAddress; //PM000110 Changes
								remarks = bankName + " " + bankAccountNumber + " "  + bankAddress;				//PM000110 Changes			
							    trnData.addProperty("remarks", remarks);
						  }
						 }
						 catch(Exception e)
						 {
							// 
						 }
						}
						else
						{
							trnData.addProperty("remarks", "");
						}
						//#PM000109 CHANGES ENDS
						
						//#PM000106 CHANGES STARTS
						String maturityDate = null;
						try {
						maturityDate = Im$utils.dateFormatter(app$JsonFd.get("maturityDate").getAsString());
						} catch (Exception e) {
						}
						if (!I$utils.$iStrBlank(maturityDate)) {    //#PKY00056 changes
						trnData.addProperty("maturityDate", maturityDate);
						} else {
						trnData.addProperty("maturityDate", "");
						}
						
						String beneficiary = null;
						try {
							beneficiary = app$JsonFd.get("addBeneficiary").getAsString();
						} catch (Exception e) {
						}
						if (beneficiary.equalsIgnoreCase("Y")) {
						trnData.addProperty("addBeneficiary", beneficiary);
						} else {
							trnData.addProperty("addBeneficiary", "N");
						}
						
												// Beneficiary Details
						
						if (beneficiary.equalsIgnoreCase("Y")) //#PM000109 Changes
						{                       //#PM000109 Changes
						try {
							JsonObject cbeneficiaryDetails = new JsonObject();
							JsonArray beneficiaryDetailsArray = app$JsonFd.get("beneficiary").getAsJsonArray();
;							for (int ben = 1; ben <= beneficiaryDetailsArray.size(); ben++) {
								cbeneficiaryDetails = beneficiaryDetailsArray.get(ben-1).getAsJsonObject();
								
								if (!I$utils.$isNull(cbeneficiaryDetails))//#PM000107 Changes     //#PKY00056 changes
								{	                                               //#PM000107 Changes
								int benR = ben;
								
								try
								{
									trnData.addProperty("RecordNo" + benR,ben);
								}
								catch(Exception e)
							    {
									trnData.addProperty("RecordNo" + benR,"");
						 	    }
								try {
									trnData.addProperty("FirstName" + benR,cbeneficiaryDetails.get("firstName").getAsString());
								} catch (Exception e) {
										trnData.addProperty("FirstName" + benR, "");
								}
								try {
									trnData.addProperty("MiddleName" + benR,cbeneficiaryDetails.get("middleName").getAsString());
								} catch (Exception e) {
									trnData.addProperty("MiddleName" + benR, "");
								}
								try {
									trnData.addProperty("LastName" + benR,cbeneficiaryDetails.get("lastName").getAsString());
								} catch (Exception e) {
									trnData.addProperty("LastName" + benR, "");
								}	
								
								try {
									trnData.addProperty("Relationship" + benR,cbeneficiaryDetails.get("relationInsured").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Relationship" + benR, "");
								}
								try {
									trnData.addProperty("Remarks" + benR,cbeneficiaryDetails.get("remarks").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Remarks" + benR, "");
								}
								try {
									trnData.addProperty("Prefix" + benR,cbeneficiaryDetails.get("prefix").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Prefix" + benR, "");
								}
								try {
									trnData.addProperty("AddressLine1" + benR,cbeneficiaryDetails.get("addLine1").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressLine1" + benR, "");
								}	
								try {
									trnData.addProperty("AddressLine2" + benR,cbeneficiaryDetails.get("addLine2").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressLine2" + benR, "");
								}
								try {
									trnData.addProperty("AddressLine3" + benR,cbeneficiaryDetails.get("addLine3").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressLine3" + benR, "");
								}
								try {
									trnData.addProperty("AddressCountry" + benR,cbeneficiaryDetails.get("addCountry").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressCountry" + benR, "");
								}
								try {
									trnData.addProperty("PercentBenefit" + benR,cbeneficiaryDetails.get("percentBenefits").getAsString());
								} catch (Exception e) {
									trnData.addProperty("PercentBenefit" + benR, "");
								}
								
								//#PM000108 Changes Starts
								String $dob = null;
								try {
									$dob = Im$utils.dateFormatter(cbeneficiaryDetails.get("dob").getAsString());
								}
								catch (Exception e) {
								}
								if (!I$utils.$iStrBlank($dob)) {    //#PKY00056 changes
										trnData.addProperty("Dob" + benR, $dob);
									} else {
										trnData.addProperty("Dob" + benR, "");
									}
									//#PM000108 Changes Ends	
								
								try {
									trnData.addProperty("Gender" + benR,cbeneficiaryDetails.get("gender").getAsString());									
								} catch (Exception e) {
								    trnData.addProperty("Gender" + benR, "");	
								}
								try {
									trnData.addProperty("Telephone" + benR,cbeneficiaryDetails.get("telephone").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Telephone" + benR, "");
								}
								try {
									trnData.addProperty("MobileNo" + benR,cbeneficiaryDetails.get("mobileNo").getAsString());
								} catch (Exception e) {
									trnData.addProperty("MobileNo" + benR, "");
								}
								
							    try {
									trnData.addProperty("EmailId" + benR,cbeneficiaryDetails.get("emailId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("EmailId" + benR, "");
								}
								
							    try {
									trnData.addProperty("PassportId" + benR,cbeneficiaryDetails.get("passportId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("PassportId" + benR, "");
								}
							  //#PM000108 Changes Starts
								String $pptIssDt = null;
								try {
									$pptIssDt = Im$utils.dateFormatter(cbeneficiaryDetails.get("passportIssDate").getAsString());
								}
								catch (Exception e) {
								}
								if (!I$utils.$iStrBlank($pptIssDt)) {     //#PKY00056 changes
										trnData.addProperty("PassportIssDt" + benR, $pptIssDt);
									} else {
										trnData.addProperty("PassportIssDt" + benR, "");
									}
								
								String $pptExpDt = null;
								try {
									$pptExpDt = Im$utils.dateFormatter(cbeneficiaryDetails.get("passportExpDate").getAsString());
								}
								catch (Exception e) {
								}
								if (!I$utils.$iStrBlank($pptExpDt)){    //#PKY00056 changes
										trnData.addProperty("PassportExpDt" + benR, $pptExpDt);
									} else {
										trnData.addProperty("PassportExpDt" + benR, "");
									}
									
									//#PM000108 Changes Ends
								
								try {
									trnData.addProperty("PassportIssCt" + benR,cbeneficiaryDetails.get("passportCountryIssue").getAsString());
								} catch (Exception e) {
									trnData.addProperty("PassportIssCt" + benR, "");
								}
								
								try {
									trnData.addProperty("NationalId" + benR,cbeneficiaryDetails.get("nationalId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("NationalId" + benR, "");
								}	

								try {
									trnData.addProperty("DriversPermitId" + benR,cbeneficiaryDetails.get("driversPermitId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("DriversPermitId" + benR, "");
								}	
								
								try {
									trnData.addProperty("Minor" + benR,cbeneficiaryDetails.get("minor").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Minor" + benR, "");
								}	
								
								try {
									trnData.addProperty("ZipCode" + benR,cbeneficiaryDetails.get("addZipCode").getAsString());
								} catch (Exception e) {
									trnData.addProperty("ZipCode" + benR, "");
								}	
								
								try {
									trnData.addProperty("AddState" + benR,cbeneficiaryDetails.get("addState").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddState" + benR, "");
								}
								
								try {
									trnData.addProperty("AddCity" + benR,cbeneficiaryDetails.get("addCity").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddCity" + benR, "");
								}
							}  //#PM000107 Changes
								//#PM000109 Changes Starts
								else
								{
									int benR = ben;
									try
								{
									trnData.addProperty("RecordNo" + benR,ben);
								}
								catch(Exception e)
							    {
									trnData.addProperty("RecordNo" + benR,"");
						 	    }
								try {
									trnData.addProperty("FirstName" + benR,cbeneficiaryDetails.get("firstName").getAsString());
								} catch (Exception e) {
										trnData.addProperty("FirstName" + benR, "IMPACTOTEST");
								}
								try {
									trnData.addProperty("MiddleName" + benR,cbeneficiaryDetails.get("middleName").getAsString());
								} catch (Exception e) {
									trnData.addProperty("MiddleName" + benR, "");
								}
								try {
									trnData.addProperty("LastName" + benR,cbeneficiaryDetails.get("lastName").getAsString());
								} catch (Exception e) {
									trnData.addProperty("LastName" + benR, "");
								}	
								
								try {
									trnData.addProperty("Relationship" + benR,cbeneficiaryDetails.get("relationInsured").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Relationship" + benR, "POA");
								}
								try {
									trnData.addProperty("Remarks" + benR,cbeneficiaryDetails.get("remarks").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Remarks" + benR, "");
								}
								try {
									trnData.addProperty("Prefix" + benR,cbeneficiaryDetails.get("prefix").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Prefix" + benR, "Messers.");
								}
								try {
									trnData.addProperty("AddressLine1" + benR,cbeneficiaryDetails.get("addLine1").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressLine1" + benR, "");
								}	
								try {
									trnData.addProperty("AddressLine2" + benR,cbeneficiaryDetails.get("addLine2").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressLine2" + benR, "");
								}
								try {
									trnData.addProperty("AddressLine3" + benR,cbeneficiaryDetails.get("addLine3").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressLine3" + benR, "");
								}
								try {
									trnData.addProperty("AddressCountry" + benR,cbeneficiaryDetails.get("addCountry").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddressCountry" + benR, "");
								}
								try {
									trnData.addProperty("PercentBenefit" + benR,cbeneficiaryDetails.get("percentBenefits").getAsString());
								} catch (Exception e) {
									trnData.addProperty("PercentBenefit" + benR, "");
								}
								
								String $dob = null;
								try {
									$dob = Im$utils.dateFormatter(cbeneficiaryDetails.get("dob").getAsString());
								}
								catch (Exception e) {
								}
								if (!I$utils.$iStrBlank($dob)){     //#PKY00056 changes
										trnData.addProperty("Dob" + benR, $dob);
									} else {
										trnData.addProperty("Dob" + benR, "");
									}	
								
								try {
									trnData.addProperty("Gender" + benR,cbeneficiaryDetails.get("gender").getAsString());									
								} catch (Exception e) {
								    trnData.addProperty("Gender" + benR, "");	
								}
								try {
									trnData.addProperty("Telephone" + benR,cbeneficiaryDetails.get("telephone").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Telephone" + benR, "");
								}
								try {
									trnData.addProperty("MobileNo" + benR,cbeneficiaryDetails.get("mobileNo").getAsString());
								} catch (Exception e) {
									trnData.addProperty("MobileNo" + benR, "");
								}
								
							    try {
									trnData.addProperty("EmailId" + benR,cbeneficiaryDetails.get("emailId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("EmailId" + benR, "");
								}
								
							    try {
									trnData.addProperty("PassportId" + benR,cbeneficiaryDetails.get("passportId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("PassportId" + benR, "");
								}
								String $pptIssDt = null;
								try {
									$pptIssDt = Im$utils.dateFormatter(cbeneficiaryDetails.get("passportIssDate").getAsString());
								}
								catch (Exception e) {
								}
								if (!I$utils.$iStrBlank($pptIssDt)){    //#PKY00056 changes
										trnData.addProperty("PassportIssDt" + benR, $pptIssDt);
									} else {
										trnData.addProperty("PassportIssDt" + benR, "");
									}
								
								String $pptExpDt = null;
								try {
									$pptExpDt = Im$utils.dateFormatter(cbeneficiaryDetails.get("passportExpDate").getAsString());
								}
								catch (Exception e) {
								}
								if (!I$utils.$iStrBlank($pptExpDt)){    //#PKY00056 changes
										trnData.addProperty("PassportExpDt" + benR, $pptExpDt);
									} else {
										trnData.addProperty("PassportExpDt" + benR, "");
									}
								
								try {
									trnData.addProperty("PassportIssCt" + benR,cbeneficiaryDetails.get("passportCountryIssue").getAsString());
								} catch (Exception e) {
									trnData.addProperty("PassportIssCt" + benR, "");
								}
								
								try {
									trnData.addProperty("NationalId" + benR,cbeneficiaryDetails.get("nationalId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("NationalId" + benR, "");
								}	

								try {
									trnData.addProperty("DriversPermitId" + benR,cbeneficiaryDetails.get("driversPermitId").getAsString());
								} catch (Exception e) {
									trnData.addProperty("DriversPermitId" + benR, "");
								}	
								
								try {
									trnData.addProperty("Minor" + benR,cbeneficiaryDetails.get("minor").getAsString());
								} catch (Exception e) {
									trnData.addProperty("Minor" + benR, "");
								}	
								
								try {
									trnData.addProperty("ZipCode" + benR,cbeneficiaryDetails.get("addZipCode").getAsString());
								} catch (Exception e) {
									trnData.addProperty("ZipCode" + benR, "");
								}	
								
								try {
									trnData.addProperty("AddState" + benR,cbeneficiaryDetails.get("addState").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddState" + benR, "");
								}
								
								try {
									trnData.addProperty("AddCity" + benR,cbeneficiaryDetails.get("addCity").getAsString());
								} catch (Exception e) {
									trnData.addProperty("AddCity" + benR, "");
								}
								}
								//#PM000109 Changes Ends
							}
						} 
						catch (Exception e) {
						} 
						//#PM000106 CHANGES ENDS
						}						
						//#PM000109 Changes Starts
						else
						{
							trnData.addProperty("RecordNo1", "1");
							trnData.addProperty("RecordNo2", "2");
							trnData.addProperty("RecordNo3", "3");
							trnData.addProperty("RecordNo4", "4");
							trnData.addProperty("FirstName1", "IMPACTOTEST");
							trnData.addProperty("FirstName2", "IMPACTOTEST");
							trnData.addProperty("FirstName3", "IMPACTOTEST");
							trnData.addProperty("FirstName4", "IMPACTOTEST");
							trnData.addProperty("Relationship1", "POA");
							trnData.addProperty("Relationship2", "POA");
							trnData.addProperty("Relationship3", "POA");
							trnData.addProperty("Relationship4", "POA");
							trnData.addProperty("Prefix1", "Messers.");
							trnData.addProperty("Prefix2", "Messers.");
							trnData.addProperty("Prefix3", "Messers.");
							trnData.addProperty("Prefix4", "Messers.");
							//For 1st Beneficiary
							trnData.addProperty("LastName1", "");
							trnData.addProperty("MiddleName1", "");
							trnData.addProperty("Remarks1", "");
							trnData.addProperty("AddressLine11", "");
							trnData.addProperty("AddressLine21", "");
							trnData.addProperty("AddressLine31", "");
							trnData.addProperty("AddressCountry1", "");
							trnData.addProperty("PercentBenefit1", "");
							trnData.addProperty("Dob1", "");
							trnData.addProperty("Gender1", "");
							trnData.addProperty("Telephone1", "");
							trnData.addProperty("MobileNo1", "");
							trnData.addProperty("EmailId1", "");
							trnData.addProperty("PassportId1", "");
							trnData.addProperty("PassportIssDt1", "");
							trnData.addProperty("PassportExpDt1", "");
							trnData.addProperty("PassportIssCt1", "");
							trnData.addProperty("NationalId1", "");
							trnData.addProperty("DriversPermitId1", "");
							trnData.addProperty("Minor1", "");
							trnData.addProperty("ZipCode1", "");
							trnData.addProperty("AddState1", "");
							trnData.addProperty("AddCity1", "");
							//For 2nd beneficiary
							trnData.addProperty("LastName2", "");
							trnData.addProperty("MiddleName2", "");
							trnData.addProperty("Remarks2", "");
							trnData.addProperty("AddressLine12", "");
							trnData.addProperty("AddressLine22", "");
							trnData.addProperty("AddressLine32", "");
							trnData.addProperty("AddressCountry2", "");
							trnData.addProperty("PercentBenefit2", "");
							trnData.addProperty("Dob2", "");
							trnData.addProperty("Gender2", "");
							trnData.addProperty("Telephone2", "");
							trnData.addProperty("MobileNo2", "");
							trnData.addProperty("EmailId2", "");
							trnData.addProperty("PassportId2", "");
							trnData.addProperty("PassportIssDt2", "");
							trnData.addProperty("PassportExpDt2", "");
							trnData.addProperty("PassportIssCt2", "");
							trnData.addProperty("NationalId2", "");
							trnData.addProperty("DriversPermitId2", "");
							trnData.addProperty("Minor2", "");
							trnData.addProperty("ZipCode2", "");
							trnData.addProperty("AddState2", "");
							trnData.addProperty("AddCity2", "");
							//For 3rd beneficiary
							trnData.addProperty("LastName3", "");
							trnData.addProperty("MiddleName3", "");
							trnData.addProperty("Remarks3", "");
							trnData.addProperty("AddressLine13", "");
							trnData.addProperty("AddressLine23", "");
							trnData.addProperty("AddressLine33", "");
							trnData.addProperty("AddressCountry3", "");
							trnData.addProperty("PercentBenefit3", "");
							trnData.addProperty("Dob3", "");
							trnData.addProperty("Gender3", "");
							trnData.addProperty("Telephone3", "");
							trnData.addProperty("MobileNo3", "");
							trnData.addProperty("EmailId3", "");
							trnData.addProperty("PassportId3", "");
							trnData.addProperty("PassportIssDt3", "");
							trnData.addProperty("PassportExpDt3", "");
							trnData.addProperty("PassportIssCt3", "");
							trnData.addProperty("NationalId3", "");
							trnData.addProperty("DriversPermitId3", "");
							trnData.addProperty("Minor3", "");
							trnData.addProperty("ZipCode3", "");
							trnData.addProperty("AddState3", "");
							trnData.addProperty("AddCity3", "");
							//For 4th beneficiary
							trnData.addProperty("LastName4", "");
							trnData.addProperty("MiddleName4", "");
							trnData.addProperty("Remarks4", "");
							trnData.addProperty("AddressLine14", "");
							trnData.addProperty("AddressLine24", "");
							trnData.addProperty("AddressLine34", "");
							trnData.addProperty("AddressCountry4", "");
							trnData.addProperty("PercentBenefit4", "");
							trnData.addProperty("Dob4", "");
							trnData.addProperty("Gender4", "");
							trnData.addProperty("Telephone4", "");
							trnData.addProperty("MobileNo4", "");
							trnData.addProperty("EmailId4", "");
							trnData.addProperty("PassportId4", "");
							trnData.addProperty("PassportIssDt4", "");
							trnData.addProperty("PassportExpDt4", "");
							trnData.addProperty("PassportIssCt4", "");
							trnData.addProperty("NationalId4", "");
							trnData.addProperty("DriversPermitId4", "");
							trnData.addProperty("Minor4", "");
							trnData.addProperty("ZipCode4", "");
							trnData.addProperty("AddState4", "");
							trnData.addProperty("AddCity4", "");							
						}										
						//#PM000109 CHANGES ENDS
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, "trnData", trnData);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$body);
						
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CUST_IMG_UPLOAD")
							|| I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "RE_CUST_IMG_UPLOAD")) {
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						String custImgfileUri = null;
						String custImgfileCnt = null;
						String cif = null;
						// is cif creation sucessful??
						// #00000049 changes begins
						if (I$utils.$iStrFuzzyMatch(scanType, "CUST_IMG_UPLOAD")) {
							try {
								cif = icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString();
							} catch (Exception e) {
							}
							if (!(ifCifSuccess(app$Json, scanType))) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"CUST_IMAGE_UPLOAD EXCP EXC000001");
							}
						} else if (I$utils.$iStrFuzzyMatch(scanType, "RE_CUST_IMG_UPLOAD")) {
							try {
								cif = icbsbody.get("CBS_CUST_UPDATE").getAsJsonObject().get("CIF").getAsString();
							} catch (Exception e) {
							}
							if (I$utils.$iStrFuzzyMatch(cif, null) || I$utils.$iStrFuzzyMatch(cif, "")) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"CUST_IMAGE_UPLOAD EXCP EXC000001");
							}

						}
						// #00000049 changes ends
//						if (!(ifCifSuccess(app$Json, scanType))) {
//							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//									"CUST_IMAGE_UPLOAD EXCP EXC000001");
//						}
						String ScrCtrlCls = flght$oprs.get("fileDowLoadReq").getAsJsonObject().get("Controller")
								.getAsString();
						JsonObject fileuriBody = flght$oprs.get("fileDowLoadReq").getAsJsonObject().get("IsonBody")
								.getAsJsonObject();
						// get the filetoken Url
						JsonArray doc$Details = new JsonArray();
						try {
							doc$Details = app$Json.get("documents").getAsJsonObject().get("documentDetails")
									.getAsJsonArray();
							JsonObject doc$curr = new JsonObject();
							for (int itr = 0; itr < doc$Details.size(); itr++) {
								doc$curr = doc$Details.get(itr).getAsJsonObject();
								if (I$utils.$iStrFuzzyMatch(doc$curr.get("idType").getAsString(), "Customer Image")
										|| I$utils.$iStrFuzzyMatch(doc$curr.get("idType").getAsString(), "Member Image") // #BVB00196
								) { // changed key to match the Device Key
									JsonArray side$obj = new JsonArray();
									JsonObject side$Obj = new JsonObject();
									side$obj = doc$curr.get("sides").getAsJsonArray();
									for (int itrj = 0; itrj < side$obj.size(); itrj++) {
										side$Obj = side$obj.get(itrj).getAsJsonObject();

										custImgfileUri = side$Obj.get("FileUrlToken").getAsString();
										itr = 9999;
										break;
									}
								} else {
									logiCbsBody(app$Json, scanType, "N");
									continue;
								}
							}
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						}
						// Build i-body for FIle Download from DMS
						JsonObject trnData = new JsonObject();
						// Forward the request to controller for downloading the file
						trnData.addProperty("FileUrlToken", custImgfileUri);
						trnData.addProperty("tranId", app$Json.get("referenceNo").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, fileuriBody, i$ResM.I_BDYTAG, trnData);
						Class<?> ctrlClass;
						ctrlClass = Class.forName(ScrCtrlCls);
						JsonObject resultf$ = null;
						Method ctrlFunc = null;
						ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class,
								JsonObject.class);
						Object ctrl$Caller = ctrlClass.newInstance();
						resultf$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, fileuriBody, headerJson, isonMap); // Image
																												// Upload
																												// Issue
						if (I$utils.$iStrFuzzyMatch(
								resultf$.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(), "i-SUCC")) {
							custImgfileCnt = resultf$.get("i-body").getAsJsonObject().get("FileContent").getAsString();
						} else {
							continue;
						}
						try {
							trnData = new JsonObject();
							trnData.addProperty("cifId", cif);
							trnData.addProperty("sigId", cif + Integer.toString(I$utils.$igetRandonNum(999, 100))); // #BVB00205
							trnData.addProperty("sigName", cif);
							trnData.addProperty("sigTitle", cif + Integer.toString(I$utils.$igetRandonNum(999, 100))); // #BVB00205
							trnData.addProperty("branchCode",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							trnData.addProperty("fileType",
									cif + "_" + Integer.toString(I$utils.$igetRandonNum(999, 100)) + "." + "jpg"); // #BVB00205
							trnData.addProperty("imageType", "I");
							trnData.addProperty("imageText", custImgfileCnt);
							isonBody = new JsonObject();
							isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "extSys", "FLEXCUBE");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "trnCd", "SIG");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnCd", "FCUBSDBLCustService");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr", "CustImage");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr1", "@");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr2", "@");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr3", "@");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
						} catch (Exception e) {
							return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "IMPROPER DOC DETAILS");
						}
					} else if (I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "SIGN_UPLOAD")
							|| I$utils.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "RE_SIGN_UPLOAD")) {
						i$ResM.iloggedUser.set(userid);
						IResManipulator.iloggedUser.set(i$ResM.iloggedUser.get());
						IResManipulator.JGobalConstans.set(i$ResM.JGobalConstans.get());
						String cif = null;
						scanType = flght$oprs.get("OPR_NAME").getAsString();
						String custSigfileUri = null;
						String custSigfileCnt = null;
						// is cif creation sucessful??
						// #00000049 changes begins
						if (I$utils.$iStrFuzzyMatch(scanType, "SIGN_UPLOAD")) {
							try {
								cif = icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString();
							} catch (Exception e) {
							}
							if (!(ifCifSuccess(app$Json, scanType))) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"CUST_IMAGE_UPLOAD EXCP EXC000001");
							}
						} else if (I$utils.$iStrFuzzyMatch(scanType, "RE_SIGN_UPLOAD")) {
							try {
								cif = icbsbody.get("CBS_CUST_UPDATE").getAsJsonObject().get("CIF").getAsString();
							} catch (Exception e) {
							}
							if (I$utils.$iStrFuzzyMatch(cif, null) || I$utils.$iStrFuzzyMatch(cif, "")) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"CUST_IMAGE_UPLOAD EXCP EXC000001");
							}

						}
						// #00000049 changes end
						String ScrCtrlCls = flght$oprs.get("fileDowLoadReq").getAsJsonObject().get("Controller")
								.getAsString();
						JsonObject fileuriBody = flght$oprs.get("fileDowLoadReq").getAsJsonObject().get("IsonBody")
								.getAsJsonObject();
						// get the filetoken Url
						JsonArray doc$Details = new JsonArray();
						try {
							doc$Details = app$Json.get("documents").getAsJsonObject().get("documentDetails")
									.getAsJsonArray();
							JsonObject doc$curr = new JsonObject();
							for (int itr = 0; itr < doc$Details.size(); itr++) {
								doc$curr = doc$Details.get(itr).getAsJsonObject();
								if (I$utils.$iStrFuzzyMatch(doc$curr.get("idType").getAsString(),
										"Signature Document")) {
									JsonArray side$obj = new JsonArray();
									JsonObject side$Obj = new JsonObject();
									side$obj = doc$curr.get("sides").getAsJsonArray();
									for (int itrj = 0; itrj < side$obj.size(); itrj++) {
										side$Obj = side$obj.get(itrj).getAsJsonObject();
										custSigfileUri = side$Obj.get("FileUrlToken").getAsString();
										itr = 9999;
										break;
									}
								}
							}
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						}
						// Build i-body for FIle Download from DMS
						JsonObject trnData = new JsonObject();
						// Forward the request to controller for downloading the file
						trnData.addProperty("FileUrlToken", custSigfileUri);
						trnData.addProperty("tranId", app$Json.get("referenceNo").getAsString());
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, fileuriBody, i$ResM.I_BDYTAG, trnData);
						Class<?> ctrlClass;
						ctrlClass = Class.forName(ScrCtrlCls);
						JsonObject resultf$ = null;
						Method ctrlFunc = null;
						ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class,
								JsonObject.class);
						Object ctrl$Caller = ctrlClass.newInstance();
						resultf$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, fileuriBody, headerJson, isonMap);
						if (I$utils.$iStrFuzzyMatch(
								resultf$.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(), "i-SUCC")) {
							custSigfileCnt = resultf$.get("i-body").getAsJsonObject().get("FileContent").getAsString();
						} else {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						}
						try {
							trnData.addProperty("cifId", cif);
							trnData.addProperty("sigId", cif + Integer.toString(I$utils.$igetRandonNum(999, 100))); // #BVB00205
							trnData.addProperty("sigName", cif);
							trnData.addProperty("sigTitle", cif + Integer.toString(I$utils.$igetRandonNum(999, 100))); // #BVB00205
							trnData.addProperty("branchCode",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							trnData.addProperty("fileType",
									cif + "_" + Integer.toString(I$utils.$igetRandonNum(999, 100)) + "." + "jpg"); // #BVB00205
							trnData.addProperty("imageType", "S");
							trnData.addProperty("imageText", custSigfileCnt);
							isonBody = new JsonObject();
							isonBody = flght$oprs.get("IsonBody").getAsJsonObject();
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "extSys", "FLEXCUBE");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "trnCd", "SIG");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnCd", "FCUBSDBLCustService");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr", "CustImage");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "trnBrn",
									app$Json.get("contactDetails").getAsJsonObject().get("branch").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr1", "@");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr2", "@");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ctrnOpr3", "@");
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "tranId",
									app$Json.get("referenceNo").getAsString());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "trnData", trnData);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, Jbdy);
						} catch (Exception e) {
							logiCbsBody(app$Json, scanType, "N");
							continue;
						}
					}//#PKY00032 starts
					try {
						JsonObject i$body = isonBody.get("i-body").getAsJsonObject();
						i$body.addProperty("applicationId", isonMsg.get("i-body").getAsJsonObject().get("applicationId").getAsString());
					}catch(Exception e) {
						
					}//#PKY00032 ends
					// Mirror method
					Class<?> ctrlClass;
					ctrlClass = Class.forName(ScrCtrlClass);
					JsonObject result$ = null;
					Method ctrlFunc = null;
					ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
					Object ctrl$Caller = ctrlClass.newInstance();
					result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonBody, headerJson, isonMap);
					JsonObject ires$stat = new JsonObject();
					String istateMsg = null;

					try {
						ires$stat = result$.get("i-stat").getAsJsonObject();
						istateMsg = ires$stat.get("i-statMsg").getAsString();
					} catch (Exception e) {
						istateMsg = null;
					}
					if (I$utils.$iStrFuzzyMatch(istateMsg, "i-SUCC")) {
						JsonObject reslt$body = new JsonObject();
						try {
							if ((I$utils.$iStrFuzzyMatch(scanType, "CIF_CREATION")) || (I$utils
									.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_ADAPTER"))) {
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("CIF_CREATION", reslt$body);
								reslt$body.addProperty("applicationId", app$Json.get("applicationId").getAsString());
								reslt$body.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
								logcbsCifData(reslt$body);
								String cif = null;
								String errorMsg = null; // #00000027 change
								try {
									errorMsg = reslt$body.get("cbsMsg").getAsJsonObject().get("cbsMsg2").getAsString();
								} catch (Exception e) {
									// pass
								}
								if (reslt$body.has("CIF")) {
									cif = reslt$body.get("CIF").getAsString();
									if (cif != null && (cif != "")) { // #00000027
										// call document tracker update
										idocTracker(reslt$body.get("CIF").getAsString(), app$Json, "KYC");
										try {

											JsonObject emailId = new JsonObject();
											JsonObject mobileId = new JsonObject();
											String fullName = null;
											emailId.addProperty("toemailid1", app$Json.get("contactDetails")
													.getAsJsonObject().get("emailId").getAsString());
											mobileId.addProperty("Mob_Number1",
													app$Json.get("contactDetails").getAsJsonObject().get("mobileISD")
															.getAsString()
															+ app$Json.get("contactDetails").getAsJsonObject()
																	.get("mobileNumber").getAsString());
											JsonObject map$Data1 = new JsonObject();

											try {
												fullName = app$Json.get("personalInfo").getAsJsonObject()
														.get("firstName").getAsString() + " "
														+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
																.getAsString();
											} catch (Exception e) {
												fullName = "";
											}
											JsonObject emailJson = new JsonObject();
											emailJson.add("toemailIds", emailId);
											emailJson.add("mobile$numbers", mobileId);
											emailJson.addProperty("fullName", fullName);
											emailJson.addProperty("cif", cif);
											emailJson.addProperty("tmp$name", "TMPL#CIF");
//											processNotifications(emailJson, isonMsg); // 00000047 change
										} catch (Exception e) {
											e.printStackTrace();
										}
									}
								}

							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_ACCOUNT_CREATION")) { // #00000014
								try { // Chagne
									reslt$body = i$ResM.getBody(result$);
									reslt$body.addProperty("message", istateMsg);
									icbsbody.add("ACC_CREATION", reslt$body);
									JsonObject emailJson = new JsonObject();
									JsonObject flter = new JsonObject();
									String fullName = null;
									flter.addProperty("CustomerId",
											app$Json.get("trnData").getAsJsonObject().get("cif").getAsString());
									JsonObject prjctn = new JsonObject();
									prjctn.addProperty("CustomerFirstName", 1);
									prjctn.addProperty("CustomerLastName", 1);
									prjctn.addProperty("CustomerEmailId", 1);
									logger.debug(
											"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ EMAIL SENDING");
									JsonObject cifDetails = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", flter, prjctn);
									fullName = cifDetails.get("CustomerFirstName").getAsString() + " "
											+ cifDetails.get("CustomerLastName").getAsString();
									JsonObject emailid = new JsonObject();
									emailid.addProperty("toemailid1", cifDetails.get("CustomerEmailId").getAsString());
									emailJson.add("toemailIds", emailid);
									processEmailNotification(emailJson, isonMsg); // 00000047 Change

									JsonObject emailId = new JsonObject();
									JsonObject mobileId = new JsonObject();
									emailId.addProperty("toemailid1", cifDetails.get("CustomerEmailId").getAsString());
									mobileId.addProperty("Mob_Number1",
											cifDetails.get("CustomerMobileIsdNo").getAsString()
													+ cifDetails.get("CustomerMobileId").getAsString());

									try {
										fullName = app$Json.get("personalInfo").getAsJsonObject().get("firstName")
												.getAsString() + " "
												+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
														.getAsString();
									} catch (Exception e) {
										fullName = "";
									}
									emailJson.add("toemailIds", emailId);
									emailJson.add("mobile$numbers", mobileId);
									emailJson.addProperty("fullName", fullName);
									emailJson.addProperty("accountNumber",
											app$Json.get("trnData").getAsJsonObject().get("acNo").getAsString());
									emailJson.addProperty("cif",
											app$Json.get("trnData").getAsJsonObject().get("cif").getAsString());
									emailJson.addProperty("tmp$name", "TMPL#ACC");
									processNotifications(emailJson, isonMsg); // 00000047 Change

								} catch (Exception e) {
									// Email not sent
								}
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_LEAD_CREATION")) { // #00000017 change
																									// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("LEAD_CREATION", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "SETTLEMENT_MAINTENANCE_WORKFLOW")) {    //#SRM00075 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("SETTLEMENT_MAINTENANCE", reslt$body);
							}
							else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_COLLATERAL_CREATION")) {    //#PKY00030 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("COLLATERAL_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_SOA_CREATION")) {    //#PKY00028 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("SOA_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "LOAN_LOC_CREATION")) {    //#SKP00004 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("LOC_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "CASA150_ACCOUNT_CREATION")) {    //#SKP00004 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
							}else if(I$utils.$iStrFuzzyMatch(scanType, "CBS_FD_CREATION")){   //#PKY00021 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("FD_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "CUST_IMG_UPLOAD")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("CUST_IMG_UPLOAD", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "RE_CUST_IMG_UPLOAD")) { // #00000049 change
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("CUST_IMG_UPLOAD", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_KYCMN")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("CBS_KYCMN", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "SIGN_UPLOAD")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("SIGN_UPLOAD", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "RE_SIGN_UPLOAD")) { // #00000049 changes
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("SIGN_UPLOAD", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_KYCMN")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("CBS_KYCMN", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_CD")) { //#YPR00062 Changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("CBS_CD", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CUNA_IWS")) { // #00000017 change
								// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
//								i$otpC.sendNotificFN(app$Json, "TMPL#TT#CUNA#SUCC");  // #YPR00074 Changes
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CLICO_IWS")) { // #00000017 change
								// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
//								i$otpC.sendNotificFN(app$Json, "TMPL#TT#CLICO#SUCC");  // #YPR00074 Changes
							} else if (I$utils.$iStrFuzzyMatch(scanType, "EDD_CREATION")) { // ##00000048 change
								// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
							}
							// #BVB00185 Starts
							else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_CUST_UPDATE")) {
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);

								icbsbody.add("CBS_CUST_UPDATE", reslt$body);
								String cif = null;
								try {

									if (reslt$body.has("CIF")) {
										cif = reslt$body.get("CIF").getAsString();
										if ((cif != null) && (cif != "")) {
											idocTracker(reslt$body.get("CIF").getAsString(), app$Json, "RKYC");
											JsonObject emailId = new JsonObject();
											JsonObject mobileId = new JsonObject();
											String fullName = null;
											emailId.addProperty("toemailid1", app$Json.get("contactDetails")
													.getAsJsonObject().get("emailId").getAsString());
											mobileId.addProperty("Mob_Number1",
													app$Json.get("contactDetails").getAsJsonObject().get("mobileISD")
															.getAsString()
															+ app$Json.get("contactDetails").getAsJsonObject()
																	.get("mobileNumber").getAsString());
											JsonObject map$Data1 = new JsonObject();

											try {
												fullName = app$Json.get("personalInfo").getAsJsonObject()
														.get("firstName").getAsString() + " "
														+ app$Json.get("personalInfo").getAsJsonObject().get("lastName")
																.getAsString();
											} catch (Exception e) {
												fullName = "";
											}
											JsonObject emailJson = new JsonObject();
											emailJson.add("toemailIds", emailId);
											emailJson.add("mobile$numbers", mobileId);
											emailJson.addProperty("fullName", fullName);
											emailJson.addProperty("cif", cif);
											emailJson.addProperty("tmp$name", "TMPL#CIF#UPDATE");//TMPL#CIF#UPDATE
											processNotifications(emailJson, isonMsg); // Change

										}
									}
								} catch (Exception e) {
								}

								// #BVB00185 Ends
							} else {
								reslt$body = i$ResM.getBody(result$);
								ibody.add(scanType, reslt$body);
							}
							try {
								JsonObject $tsk$Filter = new JsonObject();
								$tsk$Filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
								$tsk$Filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
								JsonObject task$Json = new JsonObject();
								task$Json.add("cbsDetails", icbsbody);
								// Persit the Task to I CORE IBP PROCESS Collection and
								// log the task in logger
								db$Ctrl.db$UpdateRow(rCollName, task$Json, $tsk$Filter); // #00000015 Change
								db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter); // #00000015 Change
							} catch (Exception e) {
							}
						} catch (Exception e) {
							reslt$body.addProperty("Message", "Scan Details are Not Present");
							ibody.add(scanType, reslt$body);
						}
					} else {
						JsonObject reslt$body = new JsonObject();
						try {
							if ((I$utils.$iStrFuzzyMatch(scanType, "CIF_CREATION")) || (I$utils
									.$iStrFuzzyMatch(flght$oprs.get("OPR_NAME").getAsString(), "CBS_ADAPTER"))) {
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("CIF_CREATION", reslt$body);
								String cif = null;
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("CIF_CREATION", reslt$body);
								reslt$body.addProperty("applicationId", app$Json.get("applicationId").getAsString());
								reslt$body.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
								logcbsCifData(reslt$body);

							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_CUST_UPDATE")) {
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("CBS_CUST_UPDATE", reslt$body);
								String cif = null;
								try {
									// Build Email Json
									JsonObject map$Data1 = new JsonObject();
									JsonObject emailId = new JsonObject();
									String fullName = null;
									// icbsbody.add("CIF_CREATION", reslt$body);
								} catch (Exception e) {
									// pass
								}
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_ACCOUNT_CREATION")) { // #00000014 Change
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("ACC_CREATION", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_LEAD_CREATION")) { // #00000017 change
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("LEAD_CREATION", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_COLLATERAL_CREATION")) {    //#PKY00030 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("COLLATERAL_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_SOA_CREATION")) {    //#PKY00028 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("SOA_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "LOAN_LOC_CREATION")) {    //#SKP00004 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("LOC_CREATION", reslt$body);
							}else if(I$utils.$iStrFuzzyMatch(scanType, "CBS_FD_CREATION")) {    //#PKY00021 changes
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add("FD_CREATION", reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "CUNA_IWS")) { // #00000017 change
								// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_KYCMN")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add("CBS_KYCMN", reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CLICO_IWS")) { // #00000017 change
								// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "EDD_CREATION")) { // ##00000048 change
								// Start
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CUST_IMG_UPLOAD")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add(scanType, reslt$body);
							}else if (I$utils.$iStrFuzzyMatch(scanType, "CBS_CD")) { //#YPR00062 Changes
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "SIGN_UPLOAD")) {
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "RE_CUST_IMG_UPLOAD")) { // #00000049 change
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "RE_SIGN_UPLOAD")) { // #00000049 change
								reslt$body = i$ResM.getBody(result$);
								icbsbody.add(scanType, reslt$body);
							} else if (I$utils.$iStrFuzzyMatch(scanType, "CASA150_ACCOUNT_CREATION")) {    //#MVT00135 changes starts
								reslt$body = i$ResM.getBody(result$);
								reslt$body.addProperty("message", istateMsg);
								icbsbody.add(scanType, reslt$body);
								app$Json.addProperty("accountNo", icbsbody.getAsJsonObject("CASA150_ACCOUNT_CREATION")
										.get("CASAACCNO").getAsString());
							}//#MVT00135 changes ends
							else {
								reslt$body = i$ResM.getBody(result$);
								ibody.add(scanType, reslt$body);
							}
							try {
								JsonObject $tsk$Filter = new JsonObject();
								JsonObject task$Json = new JsonObject();
								$tsk$Filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
								$tsk$Filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
								if (icbsbody != null) {

									task$Json.add("cbsDetails", icbsbody);
									db$Ctrl.db$UpdateRow(rCollName, task$Json, $tsk$Filter); // #00000014 Change
									db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);	// #DVJ00048 Change
								}
							} catch (Exception e) {
								// pass
							}
						} catch (Exception e) {
							reslt$body.addProperty("Message", "Scan Details are Not Present");
						}
					}
				}
			}
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE SERVICE" + e.getMessage());
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, e.getMessage().toString());
		}
	}

	private JsonObject holdTask(JsonObject isonMsg) {
		String reqObjId = null, reqKeyFld = null, workFlowId = null, currStage = null, fwdOpr = null, prvStgNum = null,
				tskStg = null, newStgNum = null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject arg$Json = new JsonObject();
		JsonObject task$Json = new JsonObject();
		JsonObject control$Json = new JsonObject();
		JsonObject app$Json = new JsonObject();
		JsonObject stg$LfeCycle = new JsonObject();
		JsonObject cur$Stage = new JsonObject();
		JsonObject fw$opr = new JsonObject();
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		if (i$body.has("ReqObjId")) {
			reqObjId = i$body.get("ReqObjId").getAsString();
		} else
			reqObjId = "NULL";
		if (i$body.has("ReqKeyFld")) {
			reqKeyFld = i$body.get("ReqKeyFld").getAsString();
		}
		if (i$body.has("FwdOpr")) {
			fwdOpr = i$body.get("FwdOpr").getAsString();
		}
		if (i$body.has("TaskStage")) {
			tskStg = i$body.get("TaskStage").getAsString();
		}
		try {
			// 1. Retrieve the Controll Json from DB
			arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
			if (!(arg$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// set all prerequisite Jsons
			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
			app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(),
					"{\"$or\":[{\"" + control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"},{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}");
			if (!(app$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
					"{\"$or\":[{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
							+ "{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}]}");
			if (task$Json != null) {
				currStage = tskStg;
				cur$Stage = stg$LfeCycle.get(currStage).getAsJsonObject();
				try {
					fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
				} catch (Exception e) {
				}
				try {
				} catch (Exception e) {
				}
				try {
					prvStgNum = cur$Stage.get("PREV_STG_NO").getAsString();
				} catch (Exception e) {
					prvStgNum = null;
				}
				try {
					newStgNum = fw$opr.get("NEW_STG").getAsString();
				} catch (Exception e) {
					newStgNum = null;
				}
				// #00000008 changes begins
				JsonObject oldtask$Json = new JsonObject();
				oldtask$Json.addProperty("CurrentStageName", task$Json.get("CurrentStageName").getAsString());
				oldtask$Json.addProperty("Queue", task$Json.get("Queue").getAsString());
				oldtask$Json.addProperty("CurrentTask", task$Json.get("CurrentTask").getAsString());
				oldtask$Json.addProperty("CurrentTskStage", task$Json.get("CurrentTskStage").getAsString());
				oldtask$Json.addProperty("NxtTskStage", task$Json.get("NxtTskStage").getAsString());
				oldtask$Json.addProperty("PreTskStage", task$Json.get("PreTskStage").getAsString());
				oldtask$Json.addProperty("NewTskStage", task$Json.get("NewTskStage").getAsString());
				try {
					oldtask$Json.addProperty("ModifiedBy", task$Json.get("ModifiedBy").getAsString());
				} catch (Exception e) {
				}
				//// #00000008 ends
				task$Json.addProperty("Queue", IResManipulator.iloggedUser.get());
				task$Json.addProperty("CurrentTask", fwdOpr);
				task$Json.addProperty("CurrentTskStage", currStage);
				task$Json.addProperty("CurrentStageName", "APPLICATION HOLD");
				task$Json.addProperty("NxtTskStage", newStgNum);
				task$Json.addProperty("PreTskStage", prvStgNum);
				task$Json.addProperty("NewTskStage", newStgNum);
				task$Json.add("prevStageDetail", oldtask$Json);
				task$Json.addProperty("HeldBy", IResManipulator.iloggedUser.get());
				task$Json.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
				task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
				if (reqObjId != null) {
					task$Json.addProperty("O_Id", reqObjId);
				}
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORKFLOW IS NOT INITIATED YET");
			}
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			task$Json.remove("_id");
			JsonArray LatestRemarks = new JsonArray();//#MVT00036 Changes starts
			if (i$body.has("LatestRemarks")) {
				LatestRemarks = i$body.get("LatestRemarks").getAsJsonArray();
				app$Json.add("WorkFlowLatestRemarks", LatestRemarks);
				task$Json.add("latestRemarks", LatestRemarks);
			}
			// Persit the Task to I CORE IBP PROCESS Collection and
			// log the task in logger
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
			task$Json.add("IsonMsg", isonMsg);
			db$Ctrl.db$InsertRow("ICOR_IBM_PROCESS_LOGGER", task$Json);
			$tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			app$Json = new JsonObject();
			//SKP00003 Starts
			JsonArray Remarks = new JsonArray();
//			JsonArray LatestRemarks = new JsonArray();
			if (i$body.has("Remarks")) {
				Remarks = i$body.get("Remarks").getAsJsonArray();
				app$Json.add("WorkFlowRemarks", Remarks);
			}
			/*if (i$body.has("LatestRemarks")) {
				LatestRemarks = i$body.get("LatestRemarks").getAsJsonArray();
				app$Json.add("WorkFlowLatestRemarks", LatestRemarks);
			}*/
			//SKP00003 ends //#MVT00036 Changes ends
			app$Json.addProperty("RecordStat", "H_HOLD");
			app$Json.addProperty("WorkFlowTaskId", task$Json.get("TaskId").getAsString());
			app$Json.addProperty("WorkFlowStatus", task$Json.get("CurrentStageName").getAsString());
			task$Json.remove("_id");
			db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), app$Json, $tsk$Filter);
			JsonObject ires$json = new JsonObject();
			ires$json.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			ires$json.addProperty("CurrentStageName", task$Json.get("CurrentStageName").getAsString());
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ires$json);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}
	
	//#YPR00052 Starts
	private JsonObject enrichmentTask(JsonObject isonMsg) {
		String reqObjId = null, reqKeyFld = null, workFlowId = null, currStage = null, fwdOpr = null, curQueue = null,
				nxtStgNum = null, prvStgNum = null, tskStg = null, newStgNum = null,currStageName=null,currStgNum=null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonParser parser = new JsonParser();
		JsonObject arg$Json = new JsonObject();
		JsonObject task$Json = new JsonObject();
		JsonObject control$Json = new JsonObject();
		JsonObject app$Json = new JsonObject();
		JsonObject stg$LfeCycle = new JsonObject();
		JsonObject cur$Stage = new JsonObject();
		JsonObject fw$opr = new JsonObject();
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		;
		if (i$body.has("ReqObjId")) {
			reqObjId = i$body.get("ReqObjId").getAsString();
		} else
			reqObjId = "NULL";
		if (i$body.has("ReqKeyFld")) {
			reqKeyFld = i$body.get("ReqKeyFld").getAsString();
		}
		;
		if (i$body.has("FwdOpr")) {
			fwdOpr = i$body.get("FwdOpr").getAsString();
		}
		if (i$body.has("TaskStage")) {
			tskStg = i$body.get("TaskStage").getAsString();
		}
		if (i$body.has("CurrentStageName")) {
			currStageName = i$body.get("CurrentStageName").getAsString();
		}
		try {
			// 1. Retrieve the Controll Json from DB
			arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
			if (!(arg$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// set all prerequisite Jsons
			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
			app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(),
					"{\"$or\":[{\"" + control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"},{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}");
			if (!(app$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// 2. Get the Current Stage of the TASK from ProcessTable - IF No Record then
			// Process for INIT_STG
			task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
					"{\"$or\":[{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
							+ "{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}]}");
			if (task$Json != null) {
				currStage = tskStg;
				cur$Stage = stg$LfeCycle.get(currStage).getAsJsonObject();
				try {
					fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
				} catch (Exception e) {
				}
				try {
					nxtStgNum = cur$Stage.get("NEXT_STG_NO").getAsString();
				} catch (Exception e) {
					nxtStgNum = null;
				}
				try {
					prvStgNum = cur$Stage.get("PREV_STG_NO").getAsString();
				} catch (Exception e) {
					prvStgNum = null;
				}
				try {
					newStgNum = fw$opr.get("NEW_STG").getAsString();
				} catch (Exception e) {
					newStgNum = null;
				}
				try {
					currStgNum = cur$Stage.get("CURR_STG_NO").getAsString();    //#PKY00029 changes
				} catch (Exception e) {
					nxtStgNum = null;
				}
				curQueue = getCurrQueue(cur$Stage, fwdOpr);
				task$Json.addProperty("Queue", curQueue);
				task$Json.addProperty("CurrentTask", currStgNum);  //#PKY00029 changes
				task$Json.addProperty("CurrentTskStage", currStage);
				task$Json.addProperty("CurrentStageName", currStageName);
				task$Json.addProperty("NxtTskStage", nxtStgNum);
				task$Json.addProperty("PreTskStage", prvStgNum);
				task$Json.addProperty("NewTskStage", currStgNum);  //#PKY00029 changes
				task$Json.addProperty("EnrichedBy", IResManipulator.iloggedUser.get());
				task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
				if (reqObjId != null) {
					task$Json.addProperty("O_Id", reqObjId);
				}
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORKFLOW IS NOT INITIATED YET");
			}
			// 3. Verify the user Queue Access rights for Current Task
			String iRoles = getRoles(IResManipulator.iloggedUser.get());
			if (!(db$Ctrl.db$hasQuOprRights(IResManipulator.iloggedUser.get(), workFlowId, curQueue, fwdOpr, iRoles)) ) {
//				if(!(I$utils.$iStrFuzzyMatch(app$Json.get("verificationMode").getAsString(), "Smartphone")) && (I$utils.isInArray( parser.parse("['VERIFY APPLICATION','APPROVE APPLICATION']").getAsJsonArray(),currStageName))) { //#YPR00060 QueueAccess
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "USER DOESN'T HAVE RIGHTS");
//			}
			}
			;
			// #YPR00060 Starts
			app$Json = new JsonObject();
			JsonObject enrichedData = i$body.get("enrichedData").getAsJsonArray().get(0).getAsJsonObject();
			//#PKY00019 starts
			if (enrichedData != null) {
				if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIXED_DEPOSIT_WORKFLOW"))) {
					try {
						app$Json.add("trnData", enrichedData.get("trnData").getAsJsonObject());
					} catch (Exception e) {
					}
					try {
						app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
					} catch (Exception e) {
					}
					try {
						app$Json.add("WorkFlowLatestRemarks", enrichedData.get("WorkFlowLatestRemarks").getAsJsonArray());
					} catch (Exception e) {
					}
					try {
						app$Json.add("WorkFlowRemarks", enrichedData.get("WorkFlowRemarks").getAsJsonArray());
					} catch (Exception e) {
					}
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LEAD_WRKFLOW"))) {
					try {
						app$Json.add("memberInfo", enrichedData.get("memberInfo").getAsJsonObject());
					}catch (Exception e) {
					}
					try {
						app$Json.add("loanDetails", enrichedData.get("loanDetails").getAsJsonObject());
					}catch (Exception e) {
					}
					try {
						app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
					}catch (Exception e) {
					}
					try {
						app$Json.add("extraDetails", enrichedData.get("extraDetails").getAsJsonObject());
					}catch (Exception e) {
					}
					try {
						app$Json.add("coBorrowerDetails", enrichedData.get("coBorrowerDetails").getAsJsonArray());
					}catch (Exception e) {
					}try {
						app$Json.add("soaInfo", enrichedData.get("soaInfo").getAsJsonObject());             //#PKY00031 starts
					} catch (Exception e) {
					}
					try {
						app$Json.add("collateralInfo", enrichedData.get("collateralInfo").getAsJsonObject());
					} catch (Exception e) {
					}
					try {
						app$Json.add("cherrypicks", enrichedData.get("cherrypicks").getAsJsonObject());      
					} catch (Exception e) {
					}try {
						app$Json.add("ScanDetails", enrichedData.get("ScanDetails").getAsJsonObject());      //#PKY00031 ends
					} catch (Exception e) {
					}
					//#PKY00019 ends
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CHERRY_PICKS_WORKFLOW"))) {     //#PKY00033 starts
					try {
						app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
					} catch (Exception e) {
					}
					try {
						app$Json.add("insuredInfo", enrichedData.get("insuredInfo").getAsJsonArray());
					} catch (Exception e) {                                                              //#PKY00033 ends
					}
					try {
						app$Json.add("fcipData", enrichedData.get("fcipData").getAsJsonObject());
					} catch (Exception e) {                                                              //#PKY00033 ends
					}
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIP_WORKFLOW"))) {           //#SRP00009 Start
					try {
						app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
					} catch (Exception e) {
					}
					try {
						app$Json.add("personalInfo", enrichedData.get("personalInfo").getAsJsonObject());
					} catch (Exception e) {                                                              
					}
					try {
						app$Json.add("fipDesignation", enrichedData.get("fipDesignation").getAsJsonObject());
					} catch (Exception e) {                                                             
				    }
					try {
						app$Json.add("fipEnrolment", enrichedData.get("fipEnrolment").getAsJsonObject());
					} catch (Exception e) {                                                             
				    }  
					try {
						app$Json.add("fipDeduction", enrichedData.get("fipDeduction").getAsJsonObject());
					} catch (Exception e) {                                                             
				    }                                                                              
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_TATIL_INSURANCE_WORKFLOW"))) {     //#PKY00039 starts
					try {
			              app$Json.add("custInfo", enrichedData.get("custInfo").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("moreInfo", enrichedData.get("moreInfo").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("tatilApplication", enrichedData.get("tatilApplication").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("tatilCoronaQuestionnaire", enrichedData.get("tatilCoronaQuestionnaire").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("tatilProofOfAddress", enrichedData.get("tatilProofOfAddress").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("tatildeduction", enrichedData.get("tatildeduction").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("tatilEvidenceOfInsurability", enrichedData.get("tatilEvidenceOfInsurability").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("tatilPremiercardInfo", enrichedData.get("tatilPremiercardInfo").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("dentalAndVisionCareBenefits", enrichedData.get("dentalAndVisionCareBenefits").getAsJsonObject());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("WorkFlowLatestRemarks", enrichedData.get("WorkFlowLatestRemarks").getAsJsonArray());
			            } catch (Exception e) {
			            }
					try {
			              app$Json.add("WorkFlowRemarks", enrichedData.get("WorkFlowRemarks").getAsJsonArray());        //#PKY00039 ends
			            } catch (Exception e) {
			            }
				}else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LINCU_WORKFLOW"))) {              //#SKP00001 starts    //#SRP00009 Ends
			          try {
			              app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
			            } catch (Exception e) {
			            }
			            try {
			              app$Json.add("fcbl", enrichedData.get("fcbl").getAsJsonObject());  
			            } catch (Exception e) {                                                              
			            }
			            try {
			              app$Json.addProperty("creditUnion", enrichedData.get("creditUnion").getAsString());  
			            } catch (Exception e) {                                                              
			            }
			            try {
			              app$Json.addProperty("date", enrichedData.get("date").getAsString());  
			            } catch (Exception e) {                                                              
			            }
			            try {
			              app$Json.addProperty("branch", enrichedData.get("branch").getAsString());  
			            } catch (Exception e) {                                                              
			            }
			            try {
			              app$Json.addProperty("memberNo", enrichedData.get("memberNo").getAsString());  
			            } catch (Exception e) {                                                              
			            }                                                                               //#SKP00001 Ends
			       }else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CUSTSVR_WORKFLOW"))) {
			    	   try {
                           app$Json.addProperty("cif", enrichedData.get("cif").getAsString());
                           task$Json.addProperty("cif", enrichedData.get("cif").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("applicantName", enrichedData.get("applicantName").getAsString()); // #YPR00077
                           task$Json.addProperty("applicantName", enrichedData.get("applicantName").getAsString());                                                                        // changes
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("type", enrichedData.get("type").getAsString());
                           task$Json.addProperty("type", enrichedData.get("type").getAsString());
                       } catch (Exception e) {
                       }
                       try {//#SRP00067 Start
                           app$Json.addProperty("priority", enrichedData.get("priority").getAsString());
                           task$Json.addProperty("priority", enrichedData.get("priority").getAsString());
                       } catch (Exception e) {
                       }//#SRP00067 Ends
                       try {
                           app$Json.addProperty("status",
                                   enrichedData.get("status").getAsString());
                           task$Json.addProperty("status",
                                   enrichedData.get("status").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("nature", enrichedData.get("nature").getAsString());
                           task$Json.addProperty("nature", enrichedData.get("nature").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("criteria", enrichedData.get("criteria").getAsString());
                           task$Json.addProperty("criteria", enrichedData.get("criteria").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("contactDate",
                                   enrichedData.get("contactDate").getAsString());
                           task$Json.addProperty("contactDate",
                                   enrichedData.get("contactDate").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("targetDate",
                                   enrichedData.get("targetDate").getAsString());
                           task$Json.addProperty("targetDate",
                                   enrichedData.get("targetDate").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("activationDate",
                                   enrichedData.get("activationDate").getAsString());
                           task$Json.addProperty("activationDate",
                                   enrichedData.get("activationDate").getAsString());
                       } catch (Exception e) {
                       }
                       try {
                           app$Json.addProperty("remarks", enrichedData.get("remarks").getAsString());
                           task$Json.addProperty("remarks", enrichedData.get("remarks").getAsString());
                       } catch (Exception e) {
                       }
			       }else if((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_PAYROLL_WORKFLOW"))) {              //#SKP00001 starts    //#SRP00009 Ends
				          try {
				              app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
				              task$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
				            } catch (Exception e) {
				            }
				            try {
				              app$Json.addProperty("remittanceAmount", enrichedData.get("remittanceAmount").getAsString()); 
				              task$Json.addProperty("remittanceAmount", enrichedData.get("remittanceAmount").getAsString());
				            } catch (Exception e) {                                                              
				            }
				            try {
					              app$Json.addProperty("realisedAmount", enrichedData.get("realisedAmount").getAsString()); 
					              task$Json.addProperty("realisedAmount", enrichedData.get("realisedAmount").getAsString());
					            } catch (Exception e) {                                                              
					            }
				            try {
				              app$Json.addProperty("creditDate", enrichedData.get("creditDate").getAsString());  
				              task$Json.addProperty("creditDate", enrichedData.get("creditDate").getAsString());
				            } catch (Exception e) {                                                              
				            }
				            try {
				              app$Json.addProperty("creditAmount", enrichedData.get("creditAmount").getAsString()); 
				              task$Json.addProperty("creditAmount", enrichedData.get("creditAmount").getAsString());
				            } catch (Exception e) {                                                              
				            }
				            try {
				              app$Json.addProperty("foreignBankCharges", enrichedData.get("foreignBankCharges").getAsString());  
				              task$Json.addProperty("foreignBankCharges", enrichedData.get("foreignBankCharges").getAsString());
				            } catch (Exception e) {                                                              
				            }
							try {
								app$Json.addProperty("creditVerified",
										enrichedData.get("creditVerified").getAsString());
								task$Json.addProperty("creditVerified",
										enrichedData.get("creditVerified").getAsString());
							} catch (Exception e) {
							}
				       }
				else {
						try {
							app$Json.add("personalInfo", enrichedData.get("personalInfo").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("contactDetails", enrichedData.get("contactDetails").getAsJsonObject()); // #YPR00077
																													// changes
						} catch (Exception e) {
						}
						try {
							app$Json.add("employment", enrichedData.get("employment").getAsJsonObject());
						} catch (Exception e) {
						}
						try {//#SRP00067 Start
							app$Json.add("moreInfo", enrichedData.get("moreInfo").getAsJsonObject());
						} catch (Exception e) {
						}//#SRP00067 Ends
						try {
							app$Json.add("politicatalExposedDetailsDetails",
									enrichedData.get("politicatalExposedDetailsDetails").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("additionalDetails", enrichedData.get("additionalDetails").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("fatcaDeclaration", enrichedData.get("fatcaDeclaration").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("recommenderDetails",
									enrichedData.get("recommenderDetails").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("nomnationOfBenificiary",
									enrichedData.get("nomnationOfBenificiary").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("jointPatnerAuthorization",
									enrichedData.get("jointPatnerAuthorization").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("clicoDeclaration", enrichedData.get("clicoDeclaration").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("cunaInsurance", enrichedData.get("cunaInsurance").getAsJsonObject());
						} catch (Exception e) {
						}
						try {
							app$Json.add("documents", enrichedData.get("documents").getAsJsonObject());
						} catch (Exception e) {
						}//#MVT00097 changes starts
						try {
							app$Json.addProperty("initialDepositeAmount", enrichedData.get("initialDepositeAmount").getAsString());
						} catch (Exception e) {
							logger.debug(e.getLocalizedMessage());
						}//#MVT00097 changes ends
					}
				
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED - ENRICHED DATA NOT FOUND");
			}
			//#PKY00029 starts
			JsonArray updatedRemarks = new JsonArray();
			JsonObject remarks = new JsonObject();
			try {
				if(task$Json.has("remarks")) {
					JsonArray remarksDetails = task$Json.get("remarks").getAsJsonArray();
					remarks= remarksDetails.get(0).getAsJsonObject();
					remarks.addProperty("CurrentTask", fwdOpr);
					remarks.addProperty("NewTskStage", currStgNum);
					updatedRemarks.add(remarks);
					task$Json.add("remarks", updatedRemarks);
				}				
			}catch(Exception e) {
			}
			try {
				if(task$Json.has("latestRemarks")) {
					JsonArray latestRemarksDetails = task$Json.get("latestRemarks").getAsJsonArray();
					latestRemarksDetails.add(remarks);
					task$Json.add("latestRemarks", latestRemarksDetails);
				}				
			}catch(Exception e) {
				
			}//#PKY00029 ends
			// #YPR00060 Ends
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			task$Json.remove("_id");
			// Persit the Task to I CORE IBP PROCESS Collection and
			// log the task in logger
			task$Json.addProperty("isCurrVer", "Y"); // #00000012 change
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
			task$Json.add("IsonMsg", isonMsg);
			db$Ctrl.db$InsertRow("ICOR_IBM_PROCESS_LOGGER", task$Json);
			$tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("referenceNo", i$body.get("referenceNo").getAsString());
			$tsk$Filter.addProperty("applicationId", i$body.get("applicationId").getAsString());
			db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), app$Json, $tsk$Filter);
			try {// #SRP00051 Starts
				if ((I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_CIF_WFLW_NEW"))) {
					try {
						JsonArray pre$flghtOprs = new JsonArray();
						fw$opr = cur$Stage.get("ALLWOPR").getAsJsonObject().get(fwdOpr).getAsJsonObject();
						pre$flghtOprs = fw$opr.get("PREFLIGHT_OPRS").getAsJsonArray();
						app$Json.addProperty("WorkFlowId", workFlowId);
						if (pre$flghtOprs != null && pre$flghtOprs.size() > 0) {
							app$Json.addProperty("referenceNo", $tsk$Filter.get("referenceNo").getAsString());
							app$Json.addProperty("applicationId", $tsk$Filter.get("applicationId").getAsString());
							ExecutorService executor = Executors.newFixedThreadPool(3);// creating a pool of 5 threads
							try {
								for (int i = 0; i < 1; i++) {
									Runnable worker = new preflightOprThread(pre$flghtOprs, isonMsg, app$Json,
											i$ResM.getAllGobal());
									executor.execute(worker);// calling execute method of ExecutorService
								}
								executor.shutdown();
								while (!executor.isTerminated()) {
								}
							} finally {
								try {
									executor.shutdown();
								} catch (Exception er) {
								}
							}
							logger.debug("Finished all threads");
							String applicantName = "";
							try {
								applicantName = app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString();
								if(!I$utils.$iStrBlank(app$Json.get("personalInfo").getAsJsonObject().get("middleName").getAsString())) {
									applicantName = applicantName +" "+ app$Json.get("personalInfo").getAsJsonObject().get("middleName").getAsString();
								}
								if(!I$utils.$iStrBlank(app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString())) {
									applicantName = applicantName +" "+ app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString();
								}
							} catch (Exception e) {}
							app$Json.addProperty("applicantName", applicantName);
							task$Json.addProperty("applicantName", applicantName);
							if (I$utils.$iStrFuzzyMatch(fwdOpr, "ENRICHMENT")) {
								app$Json.add("ScanDetails", ibody);
							}
							db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), app$Json, $tsk$Filter);
							if (I$utils.$iStrFuzzyMatch(fwdOpr, "ENRICHMENT")) {
								task$Json.add("ScanDetails", ibody);
							}
							db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_MSGTEXT, "NO PREFLIGHT OPERATIONS");
						}
					} catch (Exception e) {
					}
				}
			} catch (Exception e) {
			} // #SRP00051 Ends
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, app$Json);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	};
	
	//#YPR00052 Ends

	public String getCurrQueue(JsonObject argJson, String fwdOpr) {
		// get the Allowed Queue
		String curQueue = null;
		try {
			Set<Entry<String, JsonElement>> entrySet = argJson.get("ALLWQUEUE").getAsJsonObject().entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = entry.getKey();
				strVal = argJson.get("ALLWQUEUE").getAsJsonObject().get(entry.getKey()).getAsString();
				if (strVal.contains("1")) {
					curQueue = strKey;
				}
				return curQueue;
			}
		} catch (Exception e) {
			return null;
		}
		return curQueue;
	}

	class postflightOprThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject app$Josn;
		JsonObject global;
		@SuppressWarnings("static-access")
		public postflightOprThread(JsonArray flght$Opr, JsonObject isonMsg, JsonObject app$Josn,
				JsonObject global) {
			this.message = "RUN";
			this.flght$Opr = flght$Opr;
			this.iosnMsg = isonMsg;
			this.app$Josn = app$Josn;
			this.global = global; 
			i$ResM.iloggedUser.set(userid);
			IResManipulator.iloggedUser.set(i$ResM.iloggedUser.get());
			IResManipulator.JGobalConstans.set(i$ResM.JGobalConstans.get());
			logger.info("User ID" + IResManipulator.iloggedUser.get());
			logger.info("User ID2" + i$ResM.iloggedUser.get());
		}

		public void run() {
			logger.debug(Thread.currentThread().getName() + " (Start) message POST FLIGHT OPRS = " + message);
			i$ResM.setAllGlobal(global);
			JsonObject i$res = funcCaller(flght$Opr, iosnMsg, app$Josn);// call processmessage method that sleeps the
																		// thread for 2 seconds
			logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}
	}

	class preflightOprThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject app$Josn;
		JsonObject globals; 
		
		public preflightOprThread(JsonArray flght$Opr, JsonObject isonMsg, JsonObject app$Josn, JsonObject globals) {
			this.message = "RUN";
			this.flght$Opr = flght$Opr;
			this.iosnMsg = isonMsg;
			this.app$Josn = app$Josn;
			this.globals = globals; 
		}

		public void run() {
			logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
			i$ResM.setAllGlobal(globals);
			JsonObject i$res = funcCaller(flght$Opr, iosnMsg, app$Josn);// call processmessage method that sleeps the
																		// thread for 2 seconds
			logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}
	}

	@SuppressWarnings("unused")
	public ArrayList<String> getKeySet(JsonObject i$sonObject) {
		ArrayList<String> iQueus = new ArrayList<String>();
		try {
			Map<String, Object> attributes = new HashMap<String, Object>();
			Set<Entry<String, JsonElement>> entrySet = i$sonObject.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				iQueus.add(entry.getKey());
			}
			return iQueus;
		} catch (Exception e) {
			// nothing here
		}
		return iQueus;
	}

	private JsonObject releaseHoldTask(JsonObject isonMsg) {
		String reqObjId = null, reqKeyFld = null, workFlowId = null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject arg$Json = new JsonObject();
		JsonObject task$Json = new JsonObject();
		JsonObject control$Json = new JsonObject();
		JsonObject app$Json = new JsonObject();
		String fwdOpr = null;
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		if (i$body.has("ReqObjId")) {
			reqObjId = i$body.get("ReqObjId").getAsString();
		} else
			reqObjId = "NULL";
		if (i$body.has("ReqKeyFld")) {
			reqKeyFld = i$body.get("ReqKeyFld").getAsString();
		}
		if (i$body.has("FwdOpr")) {
			fwdOpr = i$body.get("FwdOpr").getAsString();
		}
		if (i$body.has("TaskStage")) {
		}
		try {
			// 1. Retrieve the Controll Json from DB
			arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
			if (!(arg$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			// set all prerequisite Jsons
			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(),
					"{\"$or\":[{\"" + control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"},{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}");
			if (!(app$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
					"{\"$or\":[{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
							+ "{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\""
							+ control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId + "\"}]}]}");
			if (task$Json != null) {
				// #00000031 change start
				if (I$utils.$iStrFuzzyMatch(task$Json.get("ModifiedBy").getAsString(),
						IResManipulator.iloggedUser.get())) {
					if ((I$utils.$iStrFuzzyMatch(fwdOpr, "RELEASE"))) {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "REFERER CAN'T BE THE REVIEWER");
					}
				}
				// #00000031 ends
				// #00000008 changes begins
				task$Json.addProperty("Queue",
						task$Json.get("prevStageDetail").getAsJsonObject().get("Queue").getAsString());
				task$Json.addProperty("CurrentTask",
						task$Json.get("prevStageDetail").getAsJsonObject().get("CurrentTask").getAsString());
				task$Json.addProperty("CurrentTskStage",
						task$Json.get("prevStageDetail").getAsJsonObject().get("CurrentTskStage").getAsString());
				task$Json.addProperty("CurrentStageName",
						task$Json.get("prevStageDetail").getAsJsonObject().get("CurrentStageName").getAsString());
				task$Json.addProperty("NxtTskStage",
						task$Json.get("prevStageDetail").getAsJsonObject().get("NxtTskStage").getAsString());
				task$Json.addProperty("PreTskStage",
						task$Json.get("prevStageDetail").getAsJsonObject().get("PreTskStage").getAsString());
				task$Json.addProperty("NewTskStage",
						task$Json.get("prevStageDetail").getAsJsonObject().get("NewTskStage").getAsString());
				// #00000008 Changes Ends
				if ((I$utils.$iStrFuzzyMatch(fwdOpr, "HOLD"))) {
					task$Json.addProperty("ModifiedBy", "IMPACTO_COMMON_USER");
					task$Json.addProperty("ReleasedBy", IResManipulator.iloggedUser.get());
				} else {
					task$Json.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
					task$Json.addProperty("ReviewedBy", IResManipulator.iloggedUser.get());
				}
				task$Json.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
				if (reqObjId != null) {
					task$Json.addProperty("O_Id", reqObjId);
				}
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORKFLOW IS NOT INITIATED YET");
			}
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			task$Json.remove("_id");
			// Persit the Task to I CORE IBP PROCESS Collection and
			// log the task in logger
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
			task$Json.add("IsonMsg", isonMsg);
			db$Ctrl.db$InsertRow("ICOR_IBM_PROCESS_LOGGER", task$Json);
			$tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			app$Json = new JsonObject();
			// #00000024 begins
			JsonArray Remarks = new JsonArray();
			JsonArray LatestRemarks = new JsonArray();
			if (i$body.has("Remarks")) {
				Remarks = i$body.get("Remarks").getAsJsonArray();
				app$Json.add("WorkFlowRemarks", Remarks);
			}
			if (i$body.has("LatestRemarks")) {
				LatestRemarks = i$body.get("LatestRemarks").getAsJsonArray();
				app$Json.add("WorkFlowLatestRemarks", LatestRemarks);
			}
			// #00000024 ends
			app$Json.addProperty("RecordStat", "O_OPEN");
			app$Json.addProperty("WorkFlowTaskId", task$Json.get("TaskId").getAsString());
			app$Json.addProperty("WorkFlowStatus", task$Json.get("CurrentStageName").getAsString());
			task$Json.remove("_id");
			db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), app$Json, $tsk$Filter);
			JsonObject ires$json = new JsonObject();
			ires$json.addProperty("TaskId", task$Json.get("TaskId").getAsString());
			ires$json.addProperty("CurrentStageName", task$Json.get("CurrentStageName").getAsString());
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ires$json);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}

//	#00000009  Begins
	private JsonObject fetchInCApps(JsonObject isonMsg) {
		try {
			int totalIncompleteApps = 0;
			JsonObject i$body = i$ResM.getBody(isonMsg);
			int skip = 0;
			int limit = 10;
			String WrkFlwId = null;
			JsonObject sort = new JsonObject();
			sort.addProperty("_id", 1);

			sort.addProperty("_id", -1);// #BHUVI001 Added
			Gson gson = new Gson();// #BHUVI001 Added
			String sortS = gson.toJson(sort);// #BHUVI001 Added
			try {
				skip = i$body.get("intPgNo").getAsInt();// #BVB00161
			} catch (Exception e) {
				skip = 0;
			}
			;
			try {
				limit = i$body.get("intRecs").getAsInt();// #BVB00161
			} catch (Exception e) {
				limit = 10;
			}
			;
			try {
				WrkFlwId = i$body.get("WorkFlowId").getAsString();
			} catch (Exception e) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORK FLOW ID IS BLANK");
			}
			JsonObject query = new JsonObject();
			JsonObject inc$appls = new JsonObject();
			query.addProperty("DcStatus", "In-Complete");
			query.addProperty("isCurrVer", "Y"); // #00000012 change
			query.addProperty("createdBy", IResManipulator.iloggedUser.get());
			// query.addProperty("WorkFlowId", WrkFlwId);
			// fire the query to get all the Task for the queues
			// 00000011 begins
			if (I$utils.$iStrFuzzyMatch(WrkFlwId, "IMPACTO_CIF_WFLW_NEW")) {
				JsonObject app$proj = new JsonObject();
				app$proj.addProperty("applicationId", 1);
				app$proj.addProperty("referenceNo", 1);
				app$proj.addProperty("RecordStat", 1);
				app$proj.addProperty("contactDetails", 1);
				app$proj.addProperty("personalInfo.firstName", 1);
				app$proj.addProperty("personalInfo.lastName", 1);
				inc$appls = db$Ctrl.db$GetRows$Sort("ICOR_C_B2U_CIF_APPLICATION", query, app$proj, skip, limit, sortS);
				totalIncompleteApps = db$Ctrl.db$GetCountI("ICOR_C_B2U_CIF_APPLICATION", query.toString());
			} else if (I$utils.$iStrFuzzyMatch(WrkFlwId, "IMPACTO_ACCOUNT_CREATION_WRKFLOW")) {
				JsonObject ap$proj = new JsonObject();
				ap$proj.addProperty("contactDetails", 1);
				ap$proj.addProperty("trnData", 1);
				ap$proj.addProperty("DcStatus", 1);
				ap$proj.addProperty("WorkFlowRemarks", 1);
				ap$proj.addProperty("WorkFlowLatestRemarks", 1);
				ap$proj.addProperty("_id", 0);
				inc$appls = db$Ctrl.db$GetRows$Sort("ICOR_C_B2U_ACCOUNTS", query, ap$proj, skip, limit, sortS);
				totalIncompleteApps = db$Ctrl.db$GetCountI("ICOR_C_B2U_ACCOUNTS", query.toString());
			}
			JsonObject res$blder = new JsonObject();
			res$blder.add("IncompleteApplications", inc$appls.get("i-body").getAsJsonArray()); // #00000015 change
			res$blder.addProperty("totolNumberOfInCompleteApplications", "" + totalIncompleteApps);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder); // #00000015
																										// change
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
			// 00000011 Ends
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}

	private JsonObject fetchRejApps(JsonObject isonMsg) {
		try {
			int totalIncompleteApps = 0;
			JsonObject i$body = i$ResM.getBody(isonMsg);
			int skip = 0;
			int limit = 10;
			String WrkFlwId = null;
			try {
				skip = i$body.get("intPgNo").getAsInt();// #BVB00161
			} catch (Exception e) {
				skip = 0;
			}
			;
			try {
				limit = i$body.get("intRecs").getAsInt();// #BVB00161
			} catch (Exception e) {
				limit = 10;
			}
			try {
				WrkFlwId = i$body.get("WorkFlowId").getAsString();
			} catch (Exception e) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WORK FLOW ID IS BLANK");
			}
			JsonObject sort = new JsonObject();
			sort.addProperty("_id", 1);

			sort.addProperty("_id", -1);
			Gson gson = new Gson();
			String sortS = gson.toJson(sort);
			JsonObject query = new JsonObject();
			// #00000015 Begins
			query.addProperty("Queue", IResManipulator.iloggedUser.get());
			query.addProperty("isCurrVer", "Y");
			JsonObject subqry = new JsonObject();
			subqry.addProperty("$ne", "INITIAL DEPOSIT APPLICATION");		// #DVJ00041 Change
			query.add("CurrentStageName", subqry.getAsJsonObject());
			query.addProperty("WorkFlowId", WrkFlwId);
			// #00000015 ends
			// fire the query to get all the Task for the queues
			JsonObject app$proj = new JsonObject();
			app$proj.addProperty("applicationId", 1);
			app$proj.addProperty("referenceNo", 1);
			app$proj.addProperty("CurrentStageName", 1);
			app$proj.addProperty("_id", 0); // #00000012 change
			JsonObject inc$appls = db$Ctrl.db$GetRows$Sort("ICOR_IBM_PROCESS", query, app$proj, skip, limit, sortS); // #00000015
			// Change
			// #00000011 Begins
			JsonArray appls = new JsonArray();
			JsonArray rebld$apps = new JsonArray();
			appls = inc$appls.get("i-body").getAsJsonArray();
			for (int i = 0; i < appls.size(); i++) {
				JsonObject app = appls.get(i).getAsJsonObject();
				JsonObject ap$proj = new JsonObject();
				JsonObject kyc$app = new JsonObject();
				if (I$utils.$iStrFuzzyMatch(WrkFlwId, "IMPACTO_CIF_WFLW_NEW")) {
					ap$proj.addProperty("contactDetails", 1);
					ap$proj.addProperty("personalInfo.firstName", 1);
					ap$proj.addProperty("personalInfo.lastName", 1);
					ap$proj.addProperty("personalInfo.lastName", 1);
					ap$proj.addProperty("WorkFlowRemarks", 1);
					ap$proj.addProperty("WorkFlowLatestRemarks", 1);
					ap$proj.addProperty("_id", 0);
					JsonObject filter = new JsonObject();
					filter.addProperty("applicationId", app.get("applicationId").getAsString());
					filter.addProperty("referenceNo", app.get("referenceNo").getAsString());
					// filter.addProperty("isCurrVer", "Y"); //#00000012 change
					kyc$app = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter, ap$proj);
					if (kyc$app != null) {
						try {
							app.add("ApplicationDetails", kyc$app);
							rebld$apps.add(app);
						} catch (Exception e) {
							// pass
						}
					}
				} else if (I$utils.$iStrFuzzyMatch(WrkFlwId, "IMPACTO_ACCOUNT_CREATION_WRKFLOW")) {
					ap$proj.addProperty("contactDetails", 1);
					ap$proj.addProperty("trnData", 1);
					ap$proj.addProperty("DcStatus", 1);
					ap$proj.addProperty("WorkFlowRemarks", 1);
					ap$proj.addProperty("WorkFlowLatestRemarks", 1);
					ap$proj.addProperty("_id", 0);
					JsonObject filter = new JsonObject();
					filter.addProperty("applicationId", app.get("applicationId").getAsString());
					filter.addProperty("referenceNo", app.get("referenceNo").getAsString());
					// filter.addProperty("isCurrVer", "Y"); //#00000012 change
					kyc$app = db$Ctrl.db$GetRow("ICOR_C_B2U_ACCOUNTS", filter, ap$proj);
					if (kyc$app != null) {
						try {
							app.add("ApplicationDetails", kyc$app);
							rebld$apps.add(app);
						} catch (Exception e) {
							// pass
						}
					}
				}
			}
			query = new JsonObject();
			query.addProperty("isCurrVer", "Y");
			query.addProperty("Queue", IResManipulator.iloggedUser.get());
			subqry = new JsonObject();
			subqry.addProperty("$ne", "INITIAL DEPOSIT APPLICATION");		// #DVJ00041 Change
			query.add("CurrentStageName", subqry.getAsJsonObject());
			query.addProperty("WorkFlowId", WrkFlwId);
			// query.addProperty("DcStatus", "ReferDcIncomplete");
			totalIncompleteApps = db$Ctrl.db$GetCountI("ICOR_IBM_PROCESS", query.toString());
			JsonObject res$blder = new JsonObject();
			res$blder.add("ReferredApplications", rebld$apps.getAsJsonArray());
			res$blder.addProperty("totolNumberOfReferedApplications", "" + totalIncompleteApps);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
			// 00000011 Ends
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}

	// #00000009 Ends
	// #00000010 Begins
	private JsonObject ambNotifications(JsonObject isonMsg) {
		try {
			int totalIncompleteApps = 0;
			int totalRejApps = 0;
			JsonObject query = new JsonObject();
			query.addProperty("isCurrVer", "Y");
			query.addProperty("createdBy", IResManipulator.iloggedUser.get());
			query.addProperty("DcStatus", "ReferDcIncomplete");
			totalRejApps = db$Ctrl.db$GetCountI("ICOR_C_B2U_CIF_APPLICATION", query.toString());
			JsonObject rebld$apps = new JsonObject();
			rebld$apps.addProperty("numberOfReferredKycAppls", "" + totalRejApps);
			query = new JsonObject();
			query.addProperty("DcStatus", "In-Complete");
			query.addProperty("isCurrVer", "Y"); // #00000012 change
			query.addProperty("createdBy", IResManipulator.iloggedUser.get());
			totalIncompleteApps = db$Ctrl.db$GetCountI("ICOR_C_B2U_CIF_APPLICATION", query.toString());
			rebld$apps.addProperty("numberOfIncmpltKycAppls", "" + totalIncompleteApps);
			query = new JsonObject();
			query.addProperty("isCurrVer", "Y");
			query.addProperty("createdBy", IResManipulator.iloggedUser.get());
			query.addProperty("DcStatus", "ReferDcIncomplete");
			totalRejApps = 0;
			totalRejApps = db$Ctrl.db$GetCountI("ICOR_C_B2U_ACCOUNTS", query.toString());
			rebld$apps.addProperty("numberOfReferredAccAppls", "" + totalRejApps);
			query = new JsonObject();
			query.addProperty("DcStatus", "In-Complete");
			query.addProperty("isCurrVer", "Y"); // #00000012 change
			query.addProperty("createdBy", IResManipulator.iloggedUser.get());
			totalIncompleteApps = 0;
			totalIncompleteApps = db$Ctrl.db$GetCountI("ICOR_C_B2U_ACCOUNTS", query.toString());
			rebld$apps.addProperty("numberOfIncmpltAccAppls", "" + totalIncompleteApps);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, rebld$apps);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
			// 00000011 Ends
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}
	// #00000010 Ends

	private JsonObject last10Appls(JsonObject isonMsg) {
		try {
			String scrId = null;
			JsonObject top$10Apps = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject query = new JsonObject();
			query.addProperty("isCurrVer", "Y");
			query.addProperty("DcStatus", "Completed");
			query.addProperty("createdBy", IResManipulator.iloggedUser.get());
			JsonObject ap$proj = new JsonObject();
			ap$proj.addProperty("applicationId", 1);
			ap$proj.addProperty("referenceNo", 1);
			if (i$body.has("scrId")) {
				scrId = i$body.get("scrId").getAsString();
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "INVALID SCREEN ID");
			}
			;
			if (I$utils.$iStrFuzzyMatch(scrId, "OABCCUOB")) {
				JsonObject sort = new JsonObject();
				sort.addProperty("_id", 1);
				ap$proj.addProperty("contactDetails", 1);
				ap$proj.addProperty("personalInfo.firstName", 1);
				ap$proj.addProperty("personalInfo.lastName", 1);
				ap$proj.addProperty("personalInfo.lastName", 1);
				ap$proj.addProperty("WorkFlowRemarks", 1);
				ap$proj.addProperty("WorkFlowLatestRemarks", 1);
				top$10Apps = db$Ctrl.db$GetRows$Sort("ICOR_C_B2U_CIF_APPLICATION", query, ap$proj, 0, 10,
						sort.toString());
			} else if (I$utils.$iStrFuzzyMatch(scrId, "OB2UACCR")) {
				top$10Apps = db$Ctrl.db$GetTopRows("ICOR_C_B2U_ACCOUNTS", query.toString(), "_id", 10);
			} else if (I$utils.$iStrFuzzyMatch(scrId, "OB2ULNAP")) {
				top$10Apps = db$Ctrl.db$GetTopRows("ICOR_C_B2U_LOAN_APPLICATIONS", query.toString(), "_id", 10);
			} else {
				// through Invalid screen Id error
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
					top$10Apps.get("i-body").getAsJsonArray());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
			// 00000011 Ends
		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}

	private JsonObject searchTasks(JsonObject isonMsg) {
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String type = null;
			String creteria = null;
			String value = null;
			JsonObject srch$qry = new JsonObject();
			if (i$body.has("type")) {
				type = i$body.get("type").getAsString();
				srch$qry.addProperty(type, value);
			}
			if (i$body.has("creteria")) {
				creteria = i$body.get("creteria").getAsString();
				srch$qry.addProperty(creteria, creteria);
			}
			if (i$body.has("value")) {
				value = i$body.get("value").getAsString();
				srch$qry.addProperty(value, value);
			}
			JsonObject Proj = new JsonObject();
			Proj.addProperty("TaskId", 1);
			Proj.addProperty("applicationId", 1);
			Proj.addProperty("referenceNo", 1);
			Proj.addProperty("CurrentTask", 1);
			Proj.addProperty("CurrentTskStage", 1);
			Proj.addProperty("NxtTskStage", 1);
			Proj.addProperty("WorkFlowId", 1);
			/* Proj.addProperty("CurrentTask", 1) */;
			Proj.addProperty("Queue", 1);
			Proj.addProperty("CurrentStageName", 1);
			Proj.addProperty("InitiatedBy", 1);
			Proj.addProperty("ScanDetails", 1);
			Proj.addProperty("ApprovedBy", 1); // #00000007 Chages
			Proj.addProperty("AuthorizedBy", 1); // #00000007 Changes
			Proj.addProperty("cbsDetails", 1); // #00000007 Changes
			int skip = 0;
			int limit = 100;
			JsonObject res$appls = db$Ctrl.db$GetRows("ICOR_IBM_PROCESS", srch$qry, Proj, skip, limit);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$appls);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
	}

	// for releasing the rec
	public JsonObject i$releaseLock(JsonObject recIdObject) {
		try {
			String recID = null;
			try {
				// recID = i$ResM.convertId(recIdObject);
				recID = i$ResM.convertId(recIdObject.getAsJsonObject("_id"));// #00000036
			} catch (Exception e) {
				// pass
			}
			return db$Ctrl.db$ReleaseRow(recID);
		} catch (Exception e) {
			return null;
		}
	}

	public String formatsName(String sName) {
		String fsName = null;
		fsName = sName.length() <= 7 ? sName : sName.substring(0, 7);
		int num = fsName.length();
		if (num < 7) {
			int slen = 7 - num;
			fsName = String.format("%1$-" + slen + "s", fsName).replace(' ', '0');
		}
		return fsName;
	}

//	public String dateFromatter(String date) {
//		SimpleDateFormat dmyFormat = new SimpleDateFormat("yyyy-MM-dd");
//		SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
//		Date orDate;
//		try {
//			orDate = dmyFormat.parse(date);
//
//			return cntDate.format(orDate);
//		} catch (Exception e) {
//			return "";
//		}
//
//	}

	// #00000020 begins
	@SuppressWarnings("unused")
	public String getRoles(String user_id) {
		ArrayList<String> iQueus = new ArrayList<String>();
		ArrayList<String> iRoles = new ArrayList<String>();
		String sroleMatch = null;
		try {
			ArrayList<String> iUsrQueus = new ArrayList<String>();
			ArrayList<String> wrkFlws = new ArrayList<String>();
			JsonArray i$Roles = db$Ctrl.db$GetRows("ICOR_M_USER_PRF", "{\"userId\":\"" + user_id + "\"}",
					"{\"roles\":1}");
			if (i$Roles != null) {
				for (int i = 0; i < i$Roles.size(); i++) {
					try {
						iRoles.add(i$Roles.get(i).getAsJsonObject().get("roles").getAsString());
					} catch (Exception e) { // #00000006 | Fixes for defect ID 285 starts
						JsonObject irole = new JsonObject();
						irole = i$Roles.get(i).getAsJsonObject();
						JsonArray irls = new JsonArray();
						irls = irole.get("roles").getAsJsonArray();
						for (int itr = 0; itr < irls.size(); itr++) {
							String abcs = irls.get(itr).getAsString(); // *** Please consider this while merging...
							iRoles.add(abcs);
						}
					}
				}
				// Get the Ques for the Workflow Ids with user ID
				for (int i = 0; i < iRoles.size(); i++) {
					if (i == 0)
						sroleMatch = "\"" + iRoles.get(i) + "\"";
					else
						sroleMatch += ",\"" + iRoles.get(i) + "\"";
				}
				;
				return sroleMatch;
			}
		} catch (Exception e) {
			// nothing here
		}

		return sroleMatch;

	}// #00000020 ends

	// 00000047 change begins
	public void sendNotifications(JsonObject app$Json, String mode, String tmplate, String CIF, JsonObject isonMsg) {
		String cif = CIF;
		if (cif != null) {

			try {
				// Build Email Json
				JsonObject map$Data1 = new JsonObject();
				JsonObject emailId = new JsonObject();
				String fullName = null;
				emailId.addProperty("toemailid1",
						app$Json.get("contactDetails").getAsJsonObject().get("emailId").getAsString());
				try {
					fullName = app$Json.get("personalInfo").getAsJsonObject().get("firstName").getAsString() + " "
							+ app$Json.get("personalInfo").getAsJsonObject().get("lastName").getAsString();
				} catch (Exception e) {
					fullName = "";
				}
				JsonObject emailJson = new JsonObject();
				map$Data1.addProperty("fullName", fullName);
				map$Data1.addProperty("tmp$name", tmplate);
				try {
					map$Data1.addProperty("cif", cif);
					emailJson.add("toemailIds", emailId.getAsJsonObject());
					emailJson.add("map$Data", map$Data1.getAsJsonObject());
					processEmailNotification(emailJson, isonMsg);
				} catch (Exception e) {
				}
			} catch (Exception e) {
			}
		}
	}

	// 00000047 ends
	public JsonObject processEmailNotification(JsonObject i$emailJson, JsonObject isonMsg) {

		try {
			i$Email.sendEmail(i$emailJson);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email OTP Sent Successfully ");
			return isonMsg;
		} catch (Exception e) {

			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Email ");

		}

	}

	// CIF application documents maitainance
	private void idocTracker(String cif, JsonObject app$Json, String oprName) {
		try {
			JsonObject flter = new JsonObject();
			JsonObject i$body = new JsonObject();
			int versNo = 1;
			int noOfRecords = 0;
			flter.addProperty("cif", cif);
			Gson gson = new GsonBuilder().serializeNulls().create();
			noOfRecords = db$Ctrl.db$GetCountI("ICOR_M_B2U_DOC_TRACKER", flter);
			if (noOfRecords > 0) {
				versNo = noOfRecords + 1;
			}
			// #00000035 End
			// #00000043 Starts
			if (I$utils.$iStrFuzzyMatch(oprName, "RKYC")) {
				JsonObject i$update = new JsonObject();
				i$update.addProperty("isCurrVer", "N");
				db$Ctrl.db$UpdateRow("ICOR_M_B2U_DOC_TRACKER", i$update, flter);
			}
			// #00000043 Ends

			i$body.addProperty("applicationId", i$ResM.getStrfromObj(app$Json, "applicationId"));
			i$body.addProperty("referenceNo", i$ResM.getStrfromObj(app$Json, "referenceNo"));
			i$body.addProperty("version", versNo);
			i$body.addProperty("cif", cif);
			i$body.add("documents", i$ResM.getObjfromObj(app$Json, "documents"));
			i$body.add("personalInfo", i$ResM.getObjfromObj(app$Json, "personalInfo")); // 00000034 change
			// #BVB00195 Starts
			i$body.add("extraDocDetails", i$ResM.getObjfromObj(app$Json, "extraDocDetails"));
			i$body.add("primaryOCrResult", i$ResM.getObjfromObj(app$Json, "primaryOCrResult"));
			i$body.add("secondaryOCRResult", i$ResM.getObjfromObj(app$Json, "secondaryOCRResult"));

			i$body.addProperty("utilityReq", i$ResM.getStrfromObj(app$Json, "utilityReq"));
			i$body.add("moreInfo", i$ResM.getObjfromObj(app$Json, "moreInfo"));
			i$body.add("fatcaDeclaration", i$ResM.getObjfromObj(app$Json, "fatcaDeclaration"));
			i$body.add("enhanced_due", i$ResM.getObjfromObj(app$Json, "enhanced_due"));
			i$body.add("politicatalExposedDetailsDetails",
					i$ResM.getObjfromObj(app$Json, "politicatalExposedDetailsDetails"));

			// #BVB00195 Ends
			i$body.addProperty("EmpMail",
					i$ResM.getStrfromObj(i$ResM.getObjfromObj(app$Json, "contactDetails"), "emailId")); // #00000038
			// change
			i$body.addProperty("MobNum",
					i$ResM.getStrfromObj(i$ResM.getObjfromObj(app$Json, "contactDetails"), "mobileNumber")); // #00000038
																												// change
			i$body.addProperty("IsdMobNum",
					i$ResM.getStrfromObj(i$ResM.getObjfromObj(app$Json, "contactDetails"), "mobileISD")); // #00000038
																											// change
			i$body.add("updatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
			i$body.addProperty("isCurrVer", "Y");
			db$Ctrl.db$InsertRow("ICOR_M_B2U_DOC_TRACKER", i$body);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// #00000026 begins
	private JsonObject cbsRetry(JsonObject isonMsg) {

		String reqKeyFld = null;
		String workFlowId = null;
		String applicationId = null;
		String unqComId = null;
		String retry_mode = null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		try {
			try {
				workFlowId = i$body.get("WorkFlowId").getAsString();
			} catch (Exception e) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			;
			if (i$body.has("ReqKeyFld")) {
				reqKeyFld = i$body.get("ReqKeyFld").getAsString();
			}
			;

			if (i$body.has("applicationId")) {
				applicationId = i$body.get("applicationId").getAsString();
			}
			JsonObject arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
			if (!(arg$Json != null)) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			}
			JsonObject control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
			rCollName = control$Json.get("RECCOLLNAME").getAsString();
			// query the application
			JsonObject query = new JsonObject();
			query.addProperty("applicationId", applicationId);
			query.addProperty(control$Json.get("RECKEYFLD").getAsString(), reqKeyFld);
			query.addProperty("isCurrVer", "Y");
			JsonObject app$Json = db$Ctrl.db$GetRow(control$Json.get("RECCOLLNAME").getAsString(), query);
			if (app$Json != null) {
				try {
					// #00000044 begins
					// get the communication Id
					if (I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_RE_KYC_WRKFLOW")) {
						unqComId = getUnqCommID(app$Json, "CBS_CUST_UPDATE", "unqCommID");
						retry_mode = "CBS_CUST_UPDATE";

					} else if (I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_ACCOUNT_CREATION_WRKFLOW")) {
						unqComId = getUnqCommID(app$Json, "ACC_CREATION", "unqCommID");
						retry_mode = "ACC_CREATION";

					} else if (I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_FIXED_DEPOSIT_WORKFLOW")) {       //#PKY00023 changes
						unqComId = getUnqCommID(app$Json, "FD_CREATION", "unqCommID");
						retry_mode = "FD_CREATION";

					} else if (I$utils.$iStrFuzzyMatch(workFlowId, "IMPACTO_LEAD_WRKFLOW")) {                //#PKY00023 changes
						unqComId = getUnqCommID(app$Json, "LEAD_CREATION", "unqCommID");
						retry_mode = "LEAD_CREATION";

					}  else {
						String KYC_REF_NO = getUnqCommID(app$Json, "CBS_KYCMN", "KYC_REF_NO");
						if (KYC_REF_NO != null) {

							unqComId = getUnqCommID(app$Json, "CIF_CREATION", "unqCommID");
							retry_mode = "CIF_CREATION";
							if(unqComId==null) {//#MVT00103 changes begins
								unqComId = getUnqCommID(app$Json, "CBS_KYCMN", "unqCommID");
								retry_mode = "CBS_KYCMN";
							}//#MVT00103 changes ends
						} else {
							retry_mode = "CBS_KYCMN";
							// retry both Kcymn and Cif creation
							// JsonArray preflght$Opr = control$Json.get("RETRY").getAsJsonObject()
							// .get("POSTFLIGHT_OPRS").getAsJsonArray();
//						JsonObject i$res = funcCaller(preflght$Opr, thread$isonheader, thread$isonMpJson);
//						if (I$utils.$iStrFuzzyMatch(
//								i$res.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(),
//								"i-SUCC")) {
//							return i$ResM.iHandleResStat(isonMsg, i$ResM.I_MSGTEXT,
//									"SUCCESS IN POSTFLIGHT OPERATION");
//						}	
						}
					}
					return isonMsg = retry_helper(app$Json, control$Json, isonMsg, retry_mode, unqComId);
					// #00000044 Ends
				} catch (Exception e) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "EXCEPTION IN RETRY EXCTRY001");
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID UNIQ COMM ID EXCINAPP001");
			}
		} catch (Exception e) {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "EXCEPTION IN RETRY EXCTRY002");
		}
	}
	// #00000026 ends

	// #00000029 Starts
	public boolean ifCifSuccess(JsonObject app$Json, String oprName) {
		String cif = null;
		try {
			cif = icbsbody.get("CIF_CREATION").getAsJsonObject().get("CIF").getAsString();
			logger.info(" is: " + cif);

			if (I$utils.$iStrFuzzyMatch(cif, null) || I$utils.$iStrFuzzyMatch(cif, "")) {
				return false;
			} else
				return true;

		} catch (Exception e) {
			JsonObject reslt$body = new JsonObject();
			reslt$body.addProperty("Err_Msg", "Failed in Cif Creation");
			icbsbody.add(oprName, reslt$body);
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
			$tsk$Filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
			JsonObject task$Json = new JsonObject();
			task$Json.add("cbsDetails", icbsbody);
			db$Ctrl.db$UpdateRow(rCollName, task$Json, $tsk$Filter); // #00000015 Change
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter); // #00000015 Change
			return false;
		}
	}

	// log the icbsBody
	public void logiCbsBody(JsonObject app$Json, String oprName, String isSuccess) {
		JsonObject reslt$body = new JsonObject();
		if (I$utils.$iStrFuzzyMatch(isSuccess, "N")) {
			reslt$body.addProperty("Err_Msg", "Error in Performing " + oprName);
			icbsbody.add(oprName, reslt$body);
		} else {
			// pass
		}
		icbsbody.add(oprName, reslt$body);
		JsonObject $tsk$Filter = new JsonObject();
		$tsk$Filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
		$tsk$Filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
		JsonObject task$Json = new JsonObject();
		task$Json.add("cbsDetails", icbsbody);
		db$Ctrl.db$UpdateRow(rCollName, task$Json, $tsk$Filter); // #00000015 Change
		db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter); // #00000015 Change
	}

	// #00000029 Ends
	// for updating the cif and cif status
	public boolean logcbsCifData(JsonObject cbsresJson) {
		logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ log cif started$");
		if (icbsbody != null) {
			String cif = null;
			JsonObject task$json = new JsonObject();
			String errorMsg = null; // #00000027 change
			try {
				errorMsg = icbsbody.get("cbsMsg").getAsJsonObject().get("cbsMsg2").getAsString();
			} catch (Exception e) {
				// pass
			}
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("referenceNo", cbsresJson.get("referenceNo").getAsString());
			$tsk$Filter.addProperty("applicationId", cbsresJson.get("applicationId").getAsString());
			if (cbsresJson.has("CIF")) {
				cif = cbsresJson.get("CIF").getAsString();
				if (cif != null && !(errorMsg != null)) {
					task$json.addProperty("cbsCif", cif);
					task$json.addProperty("cbsStatus", "Success");
				} else {
					task$json.addProperty("cbsCif", "NaN");
					task$json.addProperty("cbsStatus", "Failed");
				}
				db$Ctrl.db$UpdateRow(rCollName, task$json, $tsk$Filter); // #00000015 Change
				db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$json, $tsk$Filter); // #00000015 Change
				return true;
			}
		}
		return false;
	}

	// #BVB00174 Starts
	private JsonObject buildIdCardDetails(JsonObject app$Json, JsonObject trnData) {
		try {
			String priDocName = app$Json.get("personalInfo").getAsJsonObject().get("priDocName").getAsString();
			String secDocName = i$ResM.getStrfromObj(app$Json.get("personalInfo").getAsJsonObject(), "secDocName");

			String idName = "p";
			if (I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_PASSPORT)) {
				idName = "sec";
			} else if (I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_PASSPORT)) {
				idName = "pri";
			}

			try {
				trnData.addProperty("pptNo",
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocId").getAsString()); // #BVB00198
				trnData.addProperty("pptIssDt", Im$utils.dateFormatter(
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOI").getAsString()));
				trnData.addProperty("pptExpDt", Im$utils.dateFormatter(
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOE").getAsString()));
				try {
					if (I$utils.$iStrFuzzyMatch(idName, "pri")) {
						trnData.addProperty("pptIssCtry", app$Json.get("personalInfo").getAsJsonObject()
								.get("priDocIssuanceCountry").getAsString());
					} else {
						trnData.addProperty("pptIssCtry", app$Json.get("personalInfo").getAsJsonObject()
								.get("secDocIssuanceCountry").getAsString());
					}
				} catch (Exception e) {
					trnData.addProperty("pptIssCtry", "TT");
				}
			} catch (Exception e) {
				trnData.addProperty("pptNo", "");
				trnData.addProperty("pptIssDt", "");
				trnData.addProperty("pptExpDt", "");
				trnData.addProperty("pptIssCtry", "");
			}
			idName = "p";
			if (I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_DRIVERPERMIT)
					|| I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_DRIVERSPERMIT)) {
				idName = "sec";
			} else if (I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_DRIVERPERMIT)
					|| I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_DRIVERSPERMIT)) {
				idName = "pri";
			}
			try {
				trnData.addProperty("dpId",
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocId").getAsString()); // #BVB00198
				trnData.addProperty("dpIssDt", Im$utils.dateFormatter(
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOI").getAsString()));
				trnData.addProperty("dpExpDt", Im$utils.dateFormatter(
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOE").getAsString()));
				// #BVB00185 Starts
				try {
					if (I$utils.$iStrFuzzyMatch(idName, "pri")) {
						trnData.addProperty("dpIssCtry", app$Json.get("personalInfo").getAsJsonObject()
								.get("priDocIssuanceCountry").getAsString());
					} else {
						trnData.addProperty("dpIssCtry", app$Json.get("personalInfo").getAsJsonObject()
								.get("secDocIssuanceCountry").getAsString());
					}
				} catch (Exception e) {
					trnData.addProperty("dpIssCtry", "TT");
				}

				// #BVB00185 Ends
			} catch (Exception e) {
				trnData.addProperty("dpId", "");
				trnData.addProperty("dpIssDt", "");
				trnData.addProperty("dpExpDt", "");
				trnData.addProperty("dpIssCtry", "");
			}

			idName = "p";
			if (I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_NATIONALID)) {
				idName = "sec";
			} else if (I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_NATIONALID)) {
				idName = "pri";
			}
			try {
				trnData.addProperty("nationalId",
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocId").getAsString()); // #BVB00198
				trnData.addProperty("nationalIdIssDt", Im$utils.dateFormatter(
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOI").getAsString()));
				trnData.addProperty("nationalIdExpDt", Im$utils.dateFormatter(
						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOE").getAsString()));
				// #BVB00185 Starts

				try {
					if (I$utils.$iStrFuzzyMatch(idName, "pri")) {
						trnData.addProperty("nationalIdIssueCntry", app$Json.get("personalInfo").getAsJsonObject()
								.get("priDocIssuanceCountry").getAsString());
					} else {
						trnData.addProperty("nationalIdIssueCntry", app$Json.get("personalInfo").getAsJsonObject()
								.get("secDocIssuanceCountry").getAsString());
					}
				} catch (Exception e) {
					trnData.addProperty("nationalIdIssueCntry", "TT");
				}
//				trnData.addProperty("nationalIdIssueCntry", app$Json.get("primaryOCrResult").getAsJsonObject()
//						.get("issuingStateCode").getAsString().substring(0, 2));
				// #BVB00185 Ends
			} catch (Exception e) {
				trnData.addProperty("nationalId", "");
				trnData.addProperty("nationalIdIssDt", "");
				trnData.addProperty("nationalIdExpDt", "");
				trnData.addProperty("nationalIdIssueCntry", "");
			}

		} catch (Exception e) {

		}
		return trnData;

	}
	// #BVB00174 Ends

	// #00000033 begins
	public JsonObject $releaseTask(JsonObject isonMsg) {
		JsonObject rec$Id = new JsonObject();
		String workFlowId = null;
		String reqKeyFld = null;
		String applicationId = null;
		String reqObjId = null;
		JsonObject i$body = i$ResM.getBody(isonMsg);
		try {
			workFlowId = i$body.get("WorkFlowId").getAsString();
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		if (i$body.has("ReqObjId")) {
			reqObjId = i$body.get("ReqObjId").getAsString();
		} else
			reqObjId = null;
		if (i$body.has("ReqKeyFld")) {
			reqKeyFld = i$body.get("ReqKeyFld").getAsString();
		}
		if (i$body.has("applicationId")) {
			applicationId = i$body.get("applicationId").getAsString();
		}
		JsonObject arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", "{\"WORKFLOWID\":\"" + workFlowId + "\"}");
		if (!(arg$Json != null)) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
		}
		JsonObject filt$obj = new JsonObject();
		filt$obj.addProperty("applicationId", applicationId);
		filt$obj.addProperty("referenceNo", reqKeyFld);
		filt$obj.addProperty("WorkFlowId", workFlowId);

		/*
		 * task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",
		 * "{\"$or\":[{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\"" +
		 * control$Json.get("RECKEYFLD").getAsString() + "\":\"" + reqKeyFld + "\"}]},"
		 * + "{\"$and\" :[{\"WorkFlowId\":\"" + workFlowId + "\"}," + "{\"" +
		 * control$Json.get("RECOBJIDFLD").getAsString() + "\":\"" + reqObjId +
		 * "\"}]}]}");
		 */
		JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", filt$obj);
		if (task$Json != null) {
			rec$Id.add("_id", task$Json.get("_id").getAsJsonObject()); // #00000018 change
			JsonObject i$aqrs = i$releaseLock(rec$Id);
			try {
				JsonObject ires$stat = i$aqrs.get("i-stat").getAsJsonObject();
				String istateMsg = ires$stat.get("i-statMsg").getAsString();
				if (I$utils.$iStrFuzzyMatch(istateMsg, "i-ERROR")) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							ires$stat.get("i-error").getAsJsonObject().get("msgtext").getAsString());
				} else
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RELEASED SUCCESSFULY");
			} catch (Exception e) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERROR, "EXPC0001 IN RELEASING THE RECORD");
			}
		} else {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERROR, "EXPC0002 RECORD DOES NOT EXIST");
		}
	}

// #00000033 Ends
// #00000037 change begins
	public JsonObject getWorkflowAllHeldAppls(JsonObject isonMsg) {
		try {
			String WorkFlowId = null;
			int totalHeldAppls = 0;
			JsonObject jBody = i$ResM.getBody(isonMsg);
			if (jBody.has("WorkFlowId")) {
				WorkFlowId = jBody.get("WorkFlowId").getAsString();
			} else
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "BAD REQUEST");
			String qryString = "{\"WorkFlowId\":\"" + WorkFlowId
					+ "\", \"isCurrVer\":\"Y\", \"Queue\":{$nin:[\"QE#APPROVE\", \"QE#REFAPPROVE\", \"QE#REFAUTHORIZE\", \"QE#AUTHORIZE\", \"QE#INITIALDEPOSIT\", \"QE#INIT\", \"QE#DLQ\"]}}";		// #DVJ00041 Change
			JsonObject app$proj = new JsonObject();
			int skip = 0;
			int limit = 20;
			try {
				skip = jBody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				// pass
			}
			;
			try {
				limit = jBody.get("intRecs").getAsInt();
			} catch (Exception e) {
				// pass
			}
			;
			app$proj.addProperty("TaskId", 1);
			app$proj.addProperty("applicationId", 1);
			app$proj.addProperty("referenceNo", 1);
			app$proj.addProperty("CurrentTask", 1);
			app$proj.addProperty("CurrentTskStage", 1);
			app$proj.addProperty("NxtTskStage", 1);
			app$proj.addProperty("WorkFlowId", 1);
			app$proj.addProperty("InitiatedAt", 1);
			app$proj.addProperty("createdAt", 1);
			/* Proj.addProperty("CurrentTask", 1) */;
			app$proj.addProperty("Queue", 1);
			app$proj.addProperty("CurrentStageName", 1);
			app$proj.addProperty("InitiatedBy", 1);
			app$proj.addProperty("ScanDetails", 1);
			app$proj.addProperty("TaskAssignedQueue", 1);
			app$proj.addProperty("ApprovedBy", 1);
			app$proj.addProperty("AuthorizedBy", 1);
			app$proj.addProperty("APPROVED_BY", 1);
			app$proj.addProperty("AUTHORIZED_BY", 1);
			app$proj.addProperty("OPENED_BY", 1);
			app$proj.addProperty("ASSIGNED_BY", 1);
			app$proj.addProperty("WIPD_BY", 1);
			app$proj.addProperty("CONVERTD_BY", 1);
			// #DVJ00041 Starts
			app$proj.addProperty("applicantName", 1);
			app$proj.addProperty("initiatorId", 1);
			app$proj.addProperty("verifierId", 1);
			app$proj.addProperty("approverId", 1);
			app$proj.addProperty("initialDepositorId", 1);
			app$proj.addProperty("osvId", 1);
			app$proj.addProperty("completerId", 1);
			// #DVJ00041 Ends
			app$proj.addProperty("opened", 1);
			app$proj.addProperty("workedby", 1);
			app$proj.addProperty("converted", 1);
			app$proj.addProperty("assigner", 1);
			app$proj.addProperty("workedby", 1);
			app$proj.addProperty("convertedby", 1);
			app$proj.addProperty("authorizer", 1);
			app$proj.addProperty("iLeadSource", 1);
			totalHeldAppls = db$Ctrl.db$GetCountI("ICOR_IBM_PROCESS", qryString);
			JsonObject wrk$flwHeldTasks = db$Ctrl.db$GetRows("ICOR_IBM_PROCESS", qryString, app$proj.toString(), skip,
					limit);
			JsonObject res$blder = new JsonObject();
			res$blder.add("PaginatedApplicationsInQueue", wrk$flwHeldTasks.get("i-body").getAsJsonArray());
			res$blder.addProperty("TotalApplsInQueue", "" + totalHeldAppls);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
		} catch (Exception e) {
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERROR, "EXPC0001 IN GETTING THE HELD TASKS");
		}
	};

//
//	private JsonObject buildIdCardDetails_re_Kyc(JsonObject app$Json, JsonObject trnData) {
//		try {
//			String priDocName = app$Json.get("personalInfo").getAsJsonObject().get("priDocName").getAsString();
//			String secDocName = app$Json.get("personalInfo").getAsJsonObject().get("secDocName").getAsString();
//
//			String idName = "p";
//			if (Im$utils.fuzzyWuzzy(secDocName, "PASSPORT") > 40) {
//				idName = "sec";
//			} else if (Im$utils.fuzzyWuzzy(priDocName, "PASSPORT") > 40) {
//				idName = "pri";
//			}
//			try {
//				trnData.addProperty("pptNo",
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocID").getAsString());
//				trnData.addProperty("pptIssDt", Im$utils.dateFormatter(
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOI").getAsString()));
//				trnData.addProperty("pptExpDt", Im$utils.dateFormatter(
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOE").getAsString()));
//				trnData.addProperty("pptIssCtry", app$Json.get("primaryOCrResult").getAsJsonObject()
//						.get("issuingStateCode").getAsString().substring(0, 2));
//			} catch (Exception e) {
//				trnData.addProperty("pptNo", "");
//				trnData.addProperty("pptIssDt", "");
//				trnData.addProperty("pptExpDt", "");
//				trnData.addProperty("pptIssCtry", "");
//			}
//			idName = "p";
//			if (Im$utils.fuzzyWuzzy(secDocName, "Driver's Permit") > 40) {
//				idName = "sec";
//			} else if (Im$utils.fuzzyWuzzy(priDocName, "Driver's Permit") > 40) {
//				idName = "pri";
//			}
//			try {
//				trnData.addProperty("dpId",
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocID").getAsString());
//				trnData.addProperty("dpIssDt", Im$utils.dateFormatter(
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOI").getAsString()));
//				trnData.addProperty("dpExpDt", Im$utils.dateFormatter(
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOE").getAsString()));
//				// #BVB00185 Starts
//				try {
//					trnData.addProperty("dpIssCtry", app$Json.get("primaryOCrResult").getAsJsonObject()
//							.get("ISSUING STATE CODE").getAsString().substring(0, 2));
//				} catch (Exception e) {
//					trnData.addProperty("dpIssCtry", "TT");
//				}
//				// #BVB00185 Ends
//			} catch (Exception e) {
//				trnData.addProperty("dpId", "");
//				trnData.addProperty("dpIssDt", "");
//				trnData.addProperty("dpExpDt", "");
//				trnData.addProperty("dpIssCtry", "");
//			}
//
//			idName = "p";
//			if (Im$utils.fuzzyWuzzy(secDocName, "National Id") > 40) {
//				idName = "sec";
//			} else if (Im$utils.fuzzyWuzzy(priDocName, "National Id ") > 40) {
//				idName = "pri";
//			}
//			try {
//				trnData.addProperty("nationalId",
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocID").getAsString());
//				trnData.addProperty("nationalIdIssDt", Im$utils.dateFormatter(
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOI").getAsString()));
//				trnData.addProperty("nationalIdExpDt", Im$utils.dateFormatter(
//						app$Json.get("personalInfo").getAsJsonObject().get(idName + "DocDOE").getAsString()));
//				// #BVB00185 Starts
//				try {
//					trnData.addProperty("nationalIdIssueCntry", app$Json.get("primaryOCrResult").getAsJsonObject()
//							.get("ISSUING STATE CODE").getAsString().substring(0, 2));
//				} catch (Exception e) {
//					trnData.addProperty("nationalIdIssueCntry", "TT");
//				}
//
////				trnData.addProperty("nationalIdIssueCntry", app$Json.get("primaryOCrResult").getAsJsonObject()
////						.get("issuingStateCode").getAsString().substring(0, 2));
//				// #BVB00185 Ends
//			} catch (Exception e) {
//				trnData.addProperty("nationalId", "");
//				trnData.addProperty("nationalIdIssDt", "");
//				trnData.addProperty("nationalIdExpDt", "");
//				trnData.addProperty("nationalIdIssueCntry", "");
//			}
//
//		} catch (Exception e) {
//
//		}
//		return trnData;
//
//	}
//// 00000047
	public JsonObject processNotifications(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonObject i$Resp = new JsonObject();
			String eol = System.getProperty("line.separator");

			JsonObject i$NotificationCommMode = null;
			try {
				i$NotificationCommMode = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"iNotificationCommMode\":1}");
			} catch (Exception E) {
			}
			;
			JsonObject email$cnfdb = new JsonObject();

			if (i$NotificationCommMode != null) {
				email$cnfdb = i$NotificationCommMode.get("iNotificationCommMode").getAsJsonObject();

				int iSend = 0;
				String sMedia = "";
				String sFailedText = "";
				if (I$utils.$strValNullIf(email$cnfdb.get("iSendSmsOtp").getAsString(), "").equals("Y")) {
					i$Resp = sendSMS(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp))
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
					iSend++;
					sMedia = sMedia + "SMS:";
				}
				if (I$utils.$strValNullIf(email$cnfdb.get("iSendMailOtp").getAsString(), "").equals("Y")) {
					i$Resp = sendEmail(argJson, isonMsg);
					if (!i$ResM.isRespSucc(i$Resp))
						sFailedText = sFailedText + i$ResM.getMsgtext(i$Resp) + eol;
					iSend++;
					sMedia = sMedia + "EMAIL:";
				}
				if (iSend < 1) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Otp Service is Disabled",
							"Contact Adminstrator");
				} else {
					if (I$utils.$iStrBlank(sFailedText)) {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
								"Notification Triggered Successfully Via :" + sMedia);
					} else {
						return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_WRN,
								"Notification Triggered Successfully  Via :" + sMedia + " with warnings " + eol
										+ sFailedText);
					}
				}
			} else {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Notification Service is Disabled",
						"Contact Adminstrator");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in Sending Notification or Notification Service is disabled", "Contact Adminstrator");

		}
	};

	private JsonObject sendSMS(JsonObject argJson, JsonObject isonMsg) {
		try {
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("cif", argJson.get("cif").getAsString());
			map$Data.addProperty("fullName", argJson.get("fullName").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmp$name").getAsString());
			argJson.add("map$Data", map$Data);
			// Forward to Otp Service
			i$SmsSrvc.sendSMS(argJson);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS OTP Sent Successfully ");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending SMS ");
		}

	};

	private JsonObject sendEmail(JsonObject argJson, JsonObject isonMsg) {
		try {

			JsonObject i$resBody = new JsonObject();

			argJson.addProperty("key$Type", "otp");
			JsonObject emailId = new JsonObject();
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("fullName", argJson.get("fullName").getAsString());
			map$Data.addProperty("cif", argJson.get("cif").getAsString());
			map$Data.addProperty("tmp$name", argJson.get("tmp$name").getAsString());
			argJson.add("map$Data", map$Data);

			i$Email.sendEmail(argJson);

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Notification Sent Successfully ");

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in Sending Email ");
		}

	}; // 00000047 ends
	//MSA00050 starts
	public JsonObject emailTriggering(JsonObject isonMsg) {
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		JsonObject dataSetFilter = new JsonObject();
		String applicationId =ibody.get("applicationId").getAsString(); 
//		String queueCompliance =ibody.get("queueCompliance").getAsString();
		JsonObject datasetProjection = new JsonObject();
		JsonObject emailDataset$Data = new JsonObject();
		String keyE = new String();
		String keyM = new String();
		JsonObject argJson = new JsonObject();
		dataSetFilter.addProperty("datasetId", "Dataset_19326");
		datasetProjection.addProperty("userDetails", 1);
		datasetProjection.addProperty("sendEmail", 1);
		datasetProjection.addProperty("sendSms", 1);
		emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
		
			if (!I$utils.$isNull(emailDataset$Data)) {
				JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
				boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
				boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
				for (int i1 = 0; i1 < userDet.size(); i1++) {
					try {
						if (sendEmail) {
							JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							keyE = keyE.concat(Email);
							if (i1 < userDet.size() - 1) {
								keyE = keyE.concat(",");
							}
						}
						if (sendSMS) {
							JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							keyM = keyM.concat(SMS);
							if (i1 < userDet.size() - 1) {
								keyM = keyM.concat(",");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					map$Data.addProperty("tmp$name", "TMPL#TT#QUEUE#COMPLIANCE#MAIL");
					map$Data.addProperty("applicationId", applicationId);
					argJson.add("map$Data", map$Data);
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					if (!I$utils.$iStrBlank(keyE)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
//					JsonObject statusMsg = i$resE.get("i-stat").getAsJsonObject();
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
			}
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Triggered Successfully");
		return isonMsg;
	}//MSA00050 ends

	// #00000042 starts
	public boolean ifKYMSuccess(JsonObject app$Json, String oprName) {
		String KYC_REF_NO = null;
		try {
			KYC_REF_NO = icbsbody.get("CBS_KYCMN").getAsJsonObject().get("KYC_REF_NO").getAsString();
			logger.info(" is: " + KYC_REF_NO);

			if (I$utils.$iStrFuzzyMatch(KYC_REF_NO, null) || I$utils.$iStrFuzzyMatch(KYC_REF_NO, "")) {
				return false;
			} else
				return true;

		} catch (Exception e) {
			JsonObject reslt$body = new JsonObject();
			reslt$body.addProperty("Err_Msg", "Failed in Kycmn Creation");
			icbsbody.add(oprName, reslt$body);
			JsonObject $tsk$Filter = new JsonObject();
			$tsk$Filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
			$tsk$Filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
			JsonObject task$Json = new JsonObject();
			task$Json.add("cbsDetails", icbsbody);
			db$Ctrl.db$UpdateRow(rCollName, task$Json, $tsk$Filter);
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
			return false;
		}
	}

	public String getUnqCommID(JsonObject app$Json, String Type, String Id) {
		try {
			return app$Json.get("cbsDetails").getAsJsonObject().get(Type).getAsJsonObject().get(Id).getAsString();

		} catch (Exception e) {
			return null;

		}
	}

	// #00000044 begins
	public JsonObject retry_helper(JsonObject app$Json, JsonObject control$Json, JsonObject isonMsg, String retry_mode,
			String unqComId) throws NoSuchMethodException, SecurityException, ClassNotFoundException,
			InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		if (unqComId != null) {
			JsonObject i$Body = new JsonObject();
			JsonObject isonBody = control$Json.get("RETRY").getAsJsonObject().get("IsonBody").getAsJsonObject();
			rCollName = control$Json.get("RECCOLLNAME").getAsString(); //// #00000046 change
			i$Body = isonBody.get("i-body").getAsJsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "tranId", app$Json.get("referenceNo").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "unqCommID", unqComId); // BVB00162
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, i$ResM.I_BDYTAG, i$Body);
			// Mirroring method
			String ScrCtrlClass = control$Json.get("RETRY").getAsJsonObject().get("Controller").getAsString();
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);

			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonBody, thread$isonheader, thread$isonMapJson);
			JsonObject ires$stat = new JsonObject();
			String istateMsg = null;
			try {
				ires$stat = result$.get("i-stat").getAsJsonObject();
				istateMsg = ires$stat.get("i-statMsg").getAsString();
			} catch (Exception e) {
				// pass
				istateMsg = null;
			}
			JsonObject reslt$body = new JsonObject();
			try {
				String cif = "";
				reslt$body = i$ResM.getBody(result$);
				reslt$body.addProperty("message", istateMsg);
				icbsbody = app$Json.getAsJsonObject("cbsDetails");
				if (I$utils.$iStrFuzzyMatch(retry_mode, "CBS_KYCMN")) {
					icbsbody.add("CBS_KYCMN", reslt$body);
				} else if (I$utils.$iStrFuzzyMatch(retry_mode, "CBS_CUST_UPDATE")) {
					icbsbody.add("CBS_CUST_UPDATE", reslt$body);
				} else if (I$utils.$iStrFuzzyMatch(retry_mode, "ACC_CREATION")) {
					icbsbody.add("ACC_CREATION", reslt$body);
				}else if (I$utils.$iStrFuzzyMatch(retry_mode, "FD_CREATION")) {    //#PKY00023 changes    
					icbsbody.add("FD_CREATION", reslt$body);
				}else if (I$utils.$iStrFuzzyMatch(retry_mode, "LEAD_CREATION")) {    //#PKY00023 changes    
					icbsbody.add("LEAD_CREATION", reslt$body);
				} else {
					icbsbody.add("CIF_CREATION", reslt$body);
					if (reslt$body.has("CIF")) {
						cif = reslt$body.get("CIF").getAsString();
						if ((cif != "") && (I$utils.$iStrFuzzyMatch(istateMsg, "i-SUCC"))) { // #00000046 change
							// call document tracker update
							idocTracker(reslt$body.get("CIF").getAsString(), app$Json, "KYC");
						}
					}
				}
				JsonObject $tsk$Filter = new JsonObject();
				$tsk$Filter.addProperty("referenceNo", app$Json.get("referenceNo").getAsString());
				$tsk$Filter.addProperty("applicationId", app$Json.get("applicationId").getAsString());
				JsonObject task$Json = new JsonObject();
				task$Json.add("cbsDetails", icbsbody);
				int retryCnt = 0;
				if (app$Json.has("cbsRetryCnt")) {
					retryCnt = app$Json.get("cbsRetryCnt").getAsInt();
					retryCnt++;
				}
				task$Json.addProperty("cbsRetryCnt", retryCnt);
				db$Ctrl.db$UpdateRow(control$Json.get("RECCOLLNAME").getAsString(), task$Json, $tsk$Filter);
				db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, $tsk$Filter);
				JsonArray flght$Opr = control$Json.get("RETRY").getAsJsonObject().get("POSTFLIGHT_OPRS")
						.getAsJsonArray();

				// Forward to Thread pool controller
				if (I$utils.$iStrFuzzyMatch(retry_mode, "CIF_CREATION")) {

					flght$Opr.remove(0);
				}
				if (I$utils.$iStrFuzzyMatch(istateMsg, "i-SUCC")) { // #00000052 Change
					String id;
					if ((reslt$body.has("CIF")|| reslt$body.has("KYC_REF_NO")) && !(I$utils.$iStrFuzzyMatch(retry_mode, "ACC_CREATION"))) {
						try {//#MVT00105 changes begins
							id = reslt$body.get("CIF").getAsString();
						} catch (Exception e) {
							id = reslt$body.get("KYC_REF_NO").getAsString();
						}
						if ((id!="") && (I$utils.$iStrFuzzyMatch(istateMsg, "i-SUCC"))) {//#MVT00105 changes ends
							ExecutorService executorpst = Executors.newFixedThreadPool(3);
							for (int i = 0; i < 1; i++) {
								Runnable worker = new postflightOprThread(flght$Opr, isonMsg, app$Json, i$ResM.getAllGobal());
								executorpst.execute(worker);// calling execute method of ExecutorService
							}
							executorpst.shutdown();
							while (!executorpst.isTerminated()) {
							}
							logger.debug("Finished all threads");
						}
					}
					String suc$msg = "Application successfully submitted for CBS processing. Please visit the Summary Screen for details post CBS approval";
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, suc$msg);
				} else {
					String failed$msg = "ERROR IN RETRY";
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, failed$msg); // // #00000052 Change
				}
			} catch (Exception e) {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN POSTFLIGHT OPERATION");
			}
		} else {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNIQUE COMMUNICATION ID IS BLANK");
		}
	}
	// #00000044 begins
	// #BVB00174 Ends

	// 00000048 changes Begins
	public String fecthValueFormJson(JsonObject app$json, String key, String defVal) {
		String retValue = defVal;
		if (app$json.has(key)) {
			retValue = app$json.get(key).getAsString();
		}
		return retValue;
	}

	public String fecthJsonValWithDefault(JsonObject app$json, String key, String defVal, String foundVal) {

		String retValue = defVal;
		if (app$json.has(key)) {
			retValue = app$json.get(key).getAsString();
			if (I$utils.$iStrFuzzyMatch(retValue, foundVal)) {
				retValue = defVal;
			}

		}
		return retValue;
	}

	public JsonObject refineIsdCodes(JsonObject trnData) {
		try {
			String number = "";
			number = i$ResM.getStrfromObj(trnData, "mobileNumber");
			if (I$utils.$iStrFuzzyMatch(number, "")) {
				trnData.addProperty("mobileISD", "");
			}
			;
			number = "";
			number = i$ResM.getStrfromObj(trnData, "homePhoneNumber");
			if (I$utils.$iStrFuzzyMatch(number, "")) {
				trnData.addProperty("homephoneExtension", "");
			}
			;
			number = "";
			number = i$ResM.getStrfromObj(trnData, "faxNumber");
			if (I$utils.$iStrFuzzyMatch(number, "")) {
				trnData.addProperty("faxNumberExtension", "");
			}
			;

			number = "";
			number = i$ResM.getStrfromObj(trnData, "employerWorkPhoneNumber");
			if (I$utils.$iStrFuzzyMatch(number, "")) {
				trnData.addProperty("employerExtension", "");
			}
			;

		} catch (Exception e) {
			logger.debug("Failed in refineIsdCodes: " + e.getMessage());
		}
		return trnData;

	}

	private JsonObject buildIdCardDetailsNom(JsonObject app$Json, JsonObject trnData) {
		try { 
			JsonObject nom1OCr = new JsonObject();
			JsonObject nom2OCr = new JsonObject();
			JsonObject nom3OCr = new JsonObject();
			JsonObject nomObj = i$ResM.getObjfromObj(app$Json, "nomnationOfBenificiary");

			if (!I$utils.$isNull(i$ResM.getObjfromObj(app$Json, "nomineeDocument1OcrResult"))) {
				nom1OCr = i$ResM.getObjfromObj(app$Json, "nomineeDocument1OcrResult");
			}
			if (!I$utils.$isNull(i$ResM.getObjfromObj(app$Json, "nomineeDocument2OcrResult"))) {
				nom2OCr = i$ResM.getObjfromObj(app$Json, "nomineeDocument2OcrResult");
			}
			if (!I$utils.$isNull(i$ResM.getObjfromObj(app$Json, "nomineeDocument3OcrResult"))) {
				nom3OCr = i$ResM.getObjfromObj(app$Json, "nomineeDocument3OcrResult");
			}
			String nom1Type = "";
			String nom2Type = "";
			String nom3Type = "";
			nom1Type = i$ResM.getStrfromObj(nom1OCr, "Document Type");
			nom2Type = i$ResM.getStrfromObj(nom2OCr, "Document Type");
			nom3Type = i$ResM.getStrfromObj(nom3OCr, "Document Type");

			if (I$utils.$iStrFuzzyMatch(nom1Type, i$ResM.I_NATIONALID)) {
				trnData.addProperty("nomDocNaId", i$ResM.getStrfromObj(nomObj, "document1"));
			} else if (I$utils.$iStrFuzzyMatch(nom1Type, i$ResM.I_DRIVERSPERMIT)) {
				trnData.addProperty("nomDocDLId", i$ResM.getStrfromObj(nomObj, "document1"));
			} else if (I$utils.$iStrFuzzyMatch(nom1Type, i$ResM.I_PASSPORT)) {

				trnData.addProperty("nomDocId", i$ResM.getStrfromObj(nomObj, "documentId1"));
				// app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocId"));
				trnData.addProperty("nomDocIssDate", Im$utils.dateFormatter(
						i$ResM.getStrfromObj(nom1OCr, "DATE OF ISSUE")));
				trnData.addProperty("nomDocExpDate", Im$utils.dateFormatter(
						i$ResM.getStrfromObj(nom1OCr, "DATE OF EXPIRY")));
				trnData.addProperty("nomDocCountryIssue",
						i$ResM.getStrfromObj(nom1OCr, "ISSUING STATE CODE")
								.substring(0, 2));
			}

			if (I$utils.$iStrFuzzyMatch(nom2Type, i$ResM.I_NATIONALID)) {
				trnData.addProperty("nomDocNaId", i$ResM.getStrfromObj(nomObj, "documentId2"));
			} else if (I$utils.$iStrFuzzyMatch(nom2Type, i$ResM.I_DRIVERSPERMIT)) {
				trnData.addProperty("nomDocDLId", i$ResM.getStrfromObj(nomObj, "documentId2"));
			} else if (I$utils.$iStrFuzzyMatch(nom2Type, i$ResM.I_PASSPORT)) {
				trnData.addProperty("nomDocId", i$ResM.getStrfromObj(nomObj, "documentId2"));
				// app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocId"));
				trnData.addProperty("nomDocIssDate", Im$utils.dateFormatter(
						i$ResM.getStrfromObj(nom2OCr, "DATE OF ISSUE")));
				trnData.addProperty("nomDocExpDate", Im$utils.dateFormatter(
						i$ResM.getStrfromObj(nom2OCr, "DATE OF EXPIRY")));
				trnData.addProperty("nomDocCountryIssue",
						i$ResM.getStrfromObj(nom2OCr, "ISSUING STATE CODE")
								.substring(0, 2));
			}

			if (I$utils.$iStrFuzzyMatch(nom3Type, i$ResM.I_NATIONALID)) {
				trnData.addProperty("nomDocNaId", i$ResM.getStrfromObj(nomObj, "documentId3"));
			} else if (I$utils.$iStrFuzzyMatch(nom3Type, i$ResM.I_DRIVERSPERMIT)) {
				trnData.addProperty("nomDocDLId", i$ResM.getStrfromObj(nomObj, "documentId3"));
			} else if (I$utils.$iStrFuzzyMatch(nom3Type, i$ResM.I_PASSPORT)) {
				trnData.addProperty("nomDocId", i$ResM.getStrfromObj(nomObj, "documentId3"));
				// app$Json.get("nomnationOfBenificiary").getAsJsonObject(), "nomDocId"));
				trnData.addProperty("nomDocIssDate", Im$utils.dateFormatter(
						i$ResM.getStrfromObj(nom3OCr, "DATE OF ISSUE")));
				trnData.addProperty("nomDocExpDate", Im$utils.dateFormatter(
						i$ResM.getStrfromObj(nom3OCr, "DATE OF EXPIRY")));
				trnData.addProperty("nomDocCountryIssue",
						i$ResM.getStrfromObj(nom3OCr, "ISSUING STATE CODE")
								.substring(0, 2));
			}
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(trnData, "nomDocNaId"), "")){
				trnData.addProperty("nomDocNaId", "");
			}; 
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(trnData, "nomDocDLId"), "")){
				trnData.addProperty("nomDocDLId", "");
			}; 
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(trnData, "nomDocId"), "")){
				trnData.addProperty("nomDocId", "");
				trnData.addProperty("nomDocIssDate", "");
				trnData.addProperty("nomDocExpDate", "");
				trnData.addProperty("nomDocCountryIssue", ""); 
			}; 
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(trnData, "nomDocIssDate"), "")){
				trnData.addProperty("nomDocIssDate", "");
			}; 
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(trnData, "nomDocExpDate"), "")){
				trnData.addProperty("nomDocExpDate", "");
			}; 
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(trnData, "nomDocCountryIssue"), "")){
				trnData.addProperty("nomDocCountryIssue", "");
			}; 
			
			
		} catch (Exception e) {
			trnData.addProperty("nomDocNaId", "");
			trnData.addProperty("nomDocDLId", "");
			trnData.addProperty("nomDocId", "");
			trnData.addProperty("nomDocIssDate", "");
			trnData.addProperty("nomDocExpDate", "");
			trnData.addProperty("nomDocCountryIssue", ""); 
		}
		return trnData;
	}

// 00000048 Change ends
	public IMbpmContorller() {
		super();

	}
}
//#00000001 Ends