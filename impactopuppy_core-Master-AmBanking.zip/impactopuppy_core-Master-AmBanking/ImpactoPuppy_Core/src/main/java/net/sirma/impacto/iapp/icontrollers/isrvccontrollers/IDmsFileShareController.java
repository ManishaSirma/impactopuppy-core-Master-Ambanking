/*
Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
Sirma Business Consulting India reserves all rights to this code . No part of this code should 
be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
take all reasonable precautions to protect the source code and documentation, and preserve its
confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
and permanent injunctive relief in addition to such remedies as may otherwise be available.

//But by the grace of God We are what we are, and his grace to us was not without effect. No, 
//We worked harder than all of them--yet not We, but the grace of God that was with us.
----------------------------------------------------------------------------------------------
|Version No  | Changed by | Date         | Change Tag  | Changes Done
----------------------------------------------------------------------------------------------
|0.5 Beta    | Pruthvi 	| Sept 13, 2021 | #YPR00108   | Initial writing
|0.5 Beta    | Pruthvi 	| Sept 14, 2021 | #YPR00108   | Added Gdrive shared file data logging
|0.5 Beta    | Pappu    | Dec 21, 2022  | #PKY00001   | Handled to get doc under page range
|0.5 Beta    | Sindhu   | Mar 08, 2023  | #SRM00029   | Handled code to recover the base64
|0.5 Beta    | Sumit    | Aug 18, 2023  | #SKG00023   |Added code for Sharing history
----------------------------------------------------------------------------------------------

*/
//#00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;



public class IDmsFileShareController {
// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IDmsFileShareController.class);
	private IEmailService i$Email = new IEmailService();
	private IGDriveAPIController I$GDrive = new IGDriveAPIController();

// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "shareViaEmail")
					&& I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "shareFiles")) {
				return sendDmsFileEmls(isonMsg); // #YPR00108 changes
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};
	
	// #YPR00108  Starts
	private JsonObject sendDmsFileEmls( JsonObject isonMsg) {
		try {
			
			String sTmplName = null;
			String sMsgAnnote = null;
			Gson gson = new Gson();
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);			
			
			if (isonMsg.has("Msg_Annotation"))
			{	
				//sMsgAnnote = i$ResM.getSrvcName(isonMsg)+"_"+i$ResM.getSrvcopr(isonMsg); 
				sTmplName = db$Ctrl.db$GetRow("ICOR_M_MSG_TMPL_MAP", "{\"MSG_ANNOTATION\":\""+isonMsg.get("Msg_Annotation").getAsString()
							+"\"}", "{\"MESSAGE_TMPL\":1}").get("MESSAGE_TMPL").getAsString();
			}
			else {
				sTmplName = "TMPL#AFG#DMS#FILE#SHARE";
			}
			argJson.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			argJson.addProperty("tmplName",sTmplName);
			
			filter.addProperty("EmpMail", i$body.get("frmUsrEml").getAsString());
			projection.addProperty("userId", 1);
			projection.addProperty("EmpMail", 1);
			projection.addProperty("name", 1);
			projection.addProperty("MobNum", 1);
			projection.addProperty("IsdMobNum", 1);
			projection.addProperty("_id", 0);
			
			JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter,projection);
			
			JsonObject map$Data = new JsonObject();
			map$Data.addProperty("username", usrData.get("name").getAsString());
			map$Data.addProperty("email", usrData.get("EmpMail").getAsString());
			map$Data.addProperty("tmp$name", sTmplName);
			try {
				JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
						"{ Template_ID: \"" + argJson.get("tmplName").getAsString() + "\" }");
				if(i$emailtmpl.has("getKeysFrmBody")) {
//					JsonArray Keys = i$emailtmpl.get("getKeysFrmBody").getAsJsonArray();
//					for (int k = 0; k < Keys.size(); k++) {
//						String key = Keys.get(k).getAsString();
//						map$Data.addProperty(key, i$ResM.getStrfromObj(i$body, key));
//					}
				}
			} catch (Exception e) {
				// Eat up
			}
			argJson.add("map$Data", map$Data);

			JsonArray toEmailsArr =  i$body.get("toEmailIds").getAsJsonArray();
			String toEmlsStr = String.join(",", gson.fromJson(toEmailsArr, ArrayList.class));
			
			argJson.addProperty("key$Type", "notification");
			argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\""+ toEmlsStr +"\"}"));
//			argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\""+ sKeyM +"\"}"));
			JsonObject attachmentObj = new JsonObject();
			attachmentObj.addProperty("docType", i$body.get("mimeType").getAsString());
			attachmentObj.addProperty("fileName",i$body.get("FileName").getAsString());
//			String content = I$utils.getBase64(i$body.get("I#FileData").getAsString());
			String content = i$body.get("I#FileData").getAsString();
			//PKY00001 starts
			try {
				if(I$utils.$iStrFuzzyMatch(i$body.get("FileExtn").getAsString(), ".zip") || I$utils.$iStrFuzzyMatch(i$body.get("FileExtn").getAsString(), ".pdf")) {
					if(i$body.has("pageRange") && !I$utils.$iStrBlank(i$body.get("pageRange").getAsString())) {
						String base64str = I$GDrive.getDocUnderPageRange( content, i$body.get("pageRange").getAsString(), i$body.get("FileExtn").getAsString());
						attachmentObj.addProperty("template", base64str);
					}else {
						byte[] pdf = Base64.decodeBase64(content.getBytes());// #SRM00029 changes
						String strBase64 = Base64.encodeBase64String(pdf);// #SRM00029 changes
						attachmentObj.addProperty("template", strBase64);
					}
				}else {
					attachmentObj.addProperty("template", content);
				}
			}catch(Exception e) {
				attachmentObj.addProperty("template", content);
			}
			//PKY00001 ends
			JsonArray attachment = new JsonArray();
			attachment.add(attachmentObj);
			argJson.add("attachment",attachment);
			i$body.remove("I#FileData");

			if (toEmailsArr.size() > 0) {
//				JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				
				Boolean i$resE = i$Email.sendEmail(argJson);
				if (i$resE) {
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
					db$Ctrl.db$logDmsHstry(isonMsg);//SKG00023 changes 
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "File Sent Successfully");
				} else {
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Error in Sending Email or Email Service is disabled");
				}
			} else {
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No recipients were found");
			}
			
		} catch (Exception e) {
			logger.debug("Error in Sending Email");
			logger.debug(e.getLocalizedMessage());
			return isonMsg;
		}

	};
	// #YPR00108  Ends
	
	public IDmsFileShareController() {

	}
}
