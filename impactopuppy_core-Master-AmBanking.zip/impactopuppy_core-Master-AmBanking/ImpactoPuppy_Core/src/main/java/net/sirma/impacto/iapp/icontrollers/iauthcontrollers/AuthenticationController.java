/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Nov 1, 2018  | #BVB00011   | Adding Encryption From LinCU Logic 
      |0.1 Beta    | Vijay 		| Nov 27, 2018 | #BVB00015   | Sending the Function Access of a user as a part of Authentication Response 
      |0.1 Beta    | Niegil 	| Jan 15, 2019 | #00000002   | Source Code Validation FrameWork Changes 
      |0.1 Beta    | Niegil 	| Jan 16, 2019 | #00000003   | Source Code Validation FrameWork - Login Changes
      |0.2.1       | Vijay 		| Jan 25, 2019 | #BVB00042   | Site Key validations moved from GenericAppController to IScreeningController
      |0.2.1       | Vijay 		| Jan 25, 2019 | #BVB00043   | Audit Login for Users 
      |0.2.1       | Vijay 		| Feb 01, 2019 | #BVB00047   | Ambassador banking Login Rights
      |0.2.1       | Niegil 	| Feb 06, 2019 | #NYE00047   | Ambassador banking Login Rights - Fine Tune
      |0.2.1       | Niegil 	| Feb 06, 2019 | #NYE00048   | Passcode Changes, And Encryption Changes
      |0.2.1       | Niegil 	| Feb 09, 2019 | #NYE00049   | Passcode Changes, And Encryption Changes  
      |0.2.1       | Vijay 	    | Feb 19, 2019 | #BVB00065   | Mapping session Id and Token Validator
      |0.2.1       | Vijay 	    | Feb 23, 2019 | #BVB00072   | Institution ID Commented as most of the applications not sending the same 
      |0.2.1       | Bhuvi      | Feb 24, 2019 | #BHUVI001   | Force Password Change and cummulative succesive logins 
      |0.2.1       | Bhuvi      | Feb 28, 2019 | #A0000001   | Error FrameWork Changes
      |0.2.1       | Vijay  	| Mar 17, 2019 | #BVB00095   | Adding Biometrics For Authorization
      |0.2.1       | Vijay  	| Mar 27, 2019 | #BVB00103   | fix for lastpassword change is being considered for Last login. 
      |0.2.1       | Vijay  	| Apr 11, 2019 | #BVB00112   | Sending back Profile Pic during Authentication, Other details added
      |0.3.6       | Vijay  	| Apr 26, 2019 | #BVB00129   | Fix for returning QueAccess during Authentication
      |0.3.6       | Baz  	    | May 08, 2019 | #BZ000130   | Fix for returning QueAccess for Role
      |0.3.15      | Vijay 	    | Jun 18, 2019 | #BVB00170   | Adding SrcID to the request
      |0.3.16.322  | Syed 		| Jul 24, 2019 | #MAQ00022   | Added check for inactive users
      |0.3.17      | Vijay 		| Aug 16, 2019 | #BVB00200   | Verification for Ambassador existence before login
      |0.4.1.367   | Bhuvi 		| Aug 29, 2019 | #BHUVI003   | Is current version Added
	  |2.3.1       | Vijay 		| Sep 23, 2019 | #BVB00211   | User Favourites while logging in.
	  |3.1.0.427   | Syed       | Nov 20, 2019 | #MAQ00051   | Added Decoding code
	  |0.0.1.4     | Syed       | Apr 15, 2021 | #MAQ00105   | Handled DMS user token expiration
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.iauthcontrollers;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.*;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;
import com.nimbusds.jose.JOSEException;

import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IScreeningController;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.BiometricsRegController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IpasscodeController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.*;

@RestController
@RequestMapping("auth")
public class AuthenticationController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private Logger logger = LoggerFactory.getLogger(AuthenticationController.class);
	// Name
	// always
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IpasscodeController i$Pass = new IpasscodeController();// #NYE00048
	private IAppMessageHandler I$AppMessageHandler = new IAppMessageHandler(); // #A0000001
	private BiometricsRegController i$bioVer = new BiometricsRegController(); // #BVB00095
	// **********************************************************************//
	@Autowired
	private AuthenticationManager authenticationManager;

	@SuppressWarnings({ "unused", "rawtypes" })
	@RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.POST)
	public ResponseWrapper authenticationRequest(@Valid @RequestBody AuthenticationRequest authenticationRequest,
			HttpServletRequest request) throws AuthenticationException, IOException, JOSEException {
		try {
			// #00000002 Begin
			IScreeningController I$ScrnCntr = new IScreeningController();
			SentryGuardController I$SntryCntr = new SentryGuardController();
			// #00000002 Ends
			logger.info("WelCome to IMPACTO");
			
			// #MAQ00051 starts
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonParser parser = new JsonParser();
			String decoReq = gson.toJson(authenticationRequest);
			ResponseWrapper jResponseWrapper = null;
			Boolean blckChar = I$ScrnCntr.i$NonEncChars(decoReq);
			decoReq = decoReq.replaceAll("\\+","%2B");
			decoReq = URLDecoder.decode((decoReq), "UTF-8");
		    authenticationRequest = gson.fromJson(decoReq, AuthenticationRequest.class);
		    // #MAQ00051 ends
		    
			Thread currentThread = Thread.currentThread();
			logger.debug("Executing  thread : " + currentThread.getName()); 
			logger.debug("id of the thread is " + currentThread.getId());
			String sessionID = "";
			JsonObject isonBody = new JsonObject();
			// #NYE00048 Begin
			try {
				JsonParser parserM = new JsonParser();
				sessionID = i$impactoUtil.passwordDecrypt(authenticationRequest.getSessionID());// #NYE00048
				JsonObject setter = new JsonObject();
				setter.addProperty("sessionId", sessionID);
				try {
					
					i$ResM.setGobalVals("sessionId", sessionID);
					i$ResM.setGobalVals("JSessionDets",
							db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", setter).getAsJsonObject());

					try {
						i$ResM.setGobalVals("deCryptKey",
								i$ResM.getGobalValJObj("JSessionDets").get("privateKey").getAsString());
					} catch (Exception e) {
						i$ResM.setGobalVals("deCryptKey",
								i$ResM.getGobalValJObj("JSessionDets").get("sessionKeyVal").getAsString());
					}
					;

				} catch (Exception e) {
					String token = "UNAUTH";
					String tokenJStr = "{token:\"" + token + "\"}";
					JsonObject isonReq = new JsonObject();

					isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", tokenJStr); // #A0000001

					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message(// #A0000001
							i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "UNKNOWN SESSION")));
					return new ResponseWrapper(isonMap, HttpStatus.UNAUTHORIZED, null);

				}
				;
				// #NYE00048 End

				String username = i$impactoUtil.decryptPkey(authenticationRequest.getUsername());// #NYE00048
				IResManipulator.iloggedUser.set(username);// #NYE00048
				String password = i$impactoUtil.decryptPkey(authenticationRequest.getPassword());// #NYE00048
				// String InstIndetifier =
				// i$impactoUtil.decryptPkey(authenticationRequest.getInstIndetifier());//
				// #00000002
				// Changes//#NYE00048
				String secCode = i$impactoUtil.decryptPkey(authenticationRequest.getSecCode());// #NYE00048
				String captchaID = i$impactoUtil.decryptPkey(authenticationRequest.getcaptchaID());// #NYE00048
				// #00000002 Begins
				String clientApp = i$impactoUtil.decryptPkey(authenticationRequest.getclientApp());// #NYE00048
				String ime = i$impactoUtil.decryptPkey(authenticationRequest.getIme());// #NYE00048
				String srcApiKey = i$impactoUtil.decryptPkey(authenticationRequest.getsrcApiKey());// #NYE00048
				String SiteKey = i$impactoUtil.decryptPkey(authenticationRequest.getSitekey());// #NYE00048
				String ReqID = i$impactoUtil.decryptPkey(authenticationRequest.getReqid());// #NYE00048
				String SrcID = clientApp;  // #BVB00170
				// String sessionID =
				// i$impactoUtil.decryptPkey(authenticationRequest.getSessionID());//#NYE00048
				// #BVB00095 Starts 
				String ipassCode = null; 

				if (!i$impactoUtil.isNull(authenticationRequest.getipassCode())) {
					ipassCode = i$impactoUtil.decryptPkey(authenticationRequest.getipassCode());// #NYE00048
				} else {
					ipassCode = null;
				}
				String iBio = authenticationRequest.getiBio();
				// #BVB00095 Ends
				authenticationRequest.setUsername(username);// #NYE00048
				authenticationRequest.setPassword("**************");// #NYE00048
				// if (i$impactoUtil.isNullempty(InstIndetifier)) { //BVB00072
				// authenticationRequest.setInstIndetifier(InstIndetifier);// #00000002
				// Changes//#NYE00048 // #BVB00072
				// }BVB00072
				authenticationRequest.setSecCode(secCode);// #NYE00048
				authenticationRequest.setcaptchaID(captchaID);// #NYE00048
				authenticationRequest.setclientApp(clientApp);// #NYE00048
				authenticationRequest.setSrcID(clientApp);// #BVB00170
				authenticationRequest.setIme(ime);// #NYE00048
				authenticationRequest.setsrcApiKey(srcApiKey);// #NYE00048
				authenticationRequest.setSitekey(SiteKey);// #NYE00048
				authenticationRequest.setReqid(ReqID);// #NYE00048
				authenticationRequest.setipassCode(ipassCode);// #NYE00048
				authenticationRequest.setiBio(iBio); // #BVB00095
				isonBody = parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, "i-body",
						parserM.parse(gson.toJson(authenticationRequest)).getAsJsonObject());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-config"), "clientApp", clientApp);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-config"), "imecd", ime);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-header"), "srvcname",
						"IMPACTOAUTH");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-header"), "srvcopr", "LOGIN");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-config"), "sitekey", SiteKey);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-header"), "msg-id", ReqID);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-config"), "srcApiKey", srcApiKey);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-config"), "sessionID", sessionID);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody.getAsJsonObject("i-config"), "SrcID", SrcID);// #BVB00170 
				i$ResM.setHeadersInfo(request); // #00000002 Changes
				Enumeration<String> headerNames = request.getHeaderNames();
				JsonObject jReqHeader = I$SntryCntr.getReqHeader(request, headerNames);
				I$SntryCntr.setScrisonMapJson("IMPACTOAUTH");
				I$SntryCntr.logRequest(request, isonBody, jReqHeader);
				// #MAQ00051 starts
				if (blckChar) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(i$ResM.iHandleResStat(isonBody, i$ResM.I_ERR, "INVALID REQUEST"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;
				// #MAQ00051 ends
				// #BVB00042 Starts
				// Check Site Key
				/*
				 * if (I$utils.$iStrBlank(SiteKey) || !I$SntryCntr.ValidateSiteKey(SiteKey)) {
				 * LinkedTreeMap isonMap = i$ResM
				 * .getisonMap(i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).
				 * getAsJsonObject(), i$ResM.I_ERR,
				 * "ACCESS RESTRICTION - INVALID OR UNKNOWN SITE KEY")); jResponseWrapper = new
				 * ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
				 * I$SntryCntr.logResponse(jResponseWrapper,
				 * HttpStatus.NETWORK_AUTHENTICATION_REQUIRED); return jResponseWrapper; };
				 */
				// #BVB00042 Ends

				// Check Msg-ID/Req-ID
				if (I$utils.$iStrBlank(ReqID)) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
							i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
									"ACCESS RESTRICTION - MISSING OR UN-IDENTIFIED REQ ID")));

					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
					I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
					return jResponseWrapper;
				}
				;

				// #00000002 Ends
				// String ip = request.getRemoteAddr(); // #00000002 Comments 

				// #00000002 Adds
				// Check if Format OK
				if (!I$ScrnCntr.i$ReqOk(isonBody)) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler
							.get$Message(i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, I$ScrnCntr.IDataValMsg)));// #A0000001
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;
				// Check if I know the Source

				JsonObject J$kys = I$ScrnCntr.i$KYSRec(isonBody);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(J$kys), i$ResM.I_ERR)) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
							i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
									"ACCESS RESTRICTION - NON_AUTHORITATIVE_INFORMATION")));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NON_AUTHORITATIVE_INFORMATION, null);
					I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NON_AUTHORITATIVE_INFORMATION);
					return jResponseWrapper;
				}
				;
				// #00000002 Ends

				// #00000003 Begins - Adding User Information to Globals
				try {
					JsonObject J$userdet = db$Ctrl.db$GetRow("ICOR_M_USER_PRF",
							"{\"userId\":\"" + username + "\",\"active\":\"A\",\"authStat\":\"A\"}");
					// #MAQ00022 starts
					if (I$utils.$isNull(J$userdet)) {
						LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
								i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
										"ACCESS RESTRICTION - INACTIVE OR UNKNOWN USER")));
						jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
						I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
						return jResponseWrapper;
					} else
						i$ResM.setGobalVals("usrJson", J$userdet);
					// #MAQ00022 ends
				} catch (Exception e) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
							i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
									"ACCESS RESTRICTION - INVALID OR UNKNOWN USER")));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
					I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
					return jResponseWrapper;
				}
				;
				// #00000003 Ends - Adding User Information to Globals
				// ToDO
				// if android request
				// getting the pre-config from system Param

				// JsonObject sParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{ system: \"" +
				// "SYSTEM_PARAMS" + "\" }"); // Moved the Validation to the Src
				// if (sParam != null) { // #00000003 comments
				// if (I$utils.$strValNullIf(sParam.get("B2U_isMpinRequired").getAsString(),
				// "").equals("Y")) { // Comments
				// #BVB00095 Starts 
				String sLogin2FAReq = "";
				String sLoginCapReq = null;
				String sLogipassCodeReq = null;
				String sLogiBioReq = null;
				// #BVB00095 Ends
				try {
					sLoginCapReq = i$ResM.getGobalValJObj("srcJson").get("LoginCaptcha").getAsString();
				} catch (Exception E) {
					sLoginCapReq = "N"; //
				}
				;
				// #BVB00095 Starts
				try {
					sLogin2FAReq = i$ResM.getGobalValJObj("srcJson").get("Login2FA").getAsString();
				} catch (Exception E) {
					sLogin2FAReq = "N";
				}
				;
				// #BVB00095 Ends
				try {
					sLogipassCodeReq = i$ResM.getGobalValJObj("srcJson").get("LoginipassCode").getAsString();
				} catch (Exception E) {
					sLogipassCodeReq = "N";
				}
				;
				// #BVB00095 Starts
				try {
					sLogiBioReq = i$ResM.getGobalValJObj("srcJson").get("LoginiBio").getAsString();
				} catch (Exception E) {
					sLogiBioReq = "N";
				}
				;

				if (I$utils.$iStrFuzzyMatch(sLogin2FAReq, "Y")) {
					if (!i$impactoUtil.isNull(ipassCode)) {
						// #BVB00095 Ends
						// #NYE00048 Begins
						
						if (I$utils.$iStrFuzzyMatch(sLogipassCodeReq, "Y")) { // #NYE00048 Comments
							try {
								if (!i$Pass.Verify$PassCode(ipassCode)) {
									LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
											i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
													i$ResM.I_ERR,
													"ACCESS RESTRICTION - INVALID OR ALREADY USED PASSCODE")));
									jResponseWrapper = new ResponseWrapper(isonMap,
											HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
									I$SntryCntr.logResponse(jResponseWrapper,
											HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
									return jResponseWrapper;

								}
							} catch (Exception Ex) {
								LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
										i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
												i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN USER KEY")));
								jResponseWrapper = new ResponseWrapper(isonMap,
										HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
								I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
								return jResponseWrapper;
							}
						}
						;
						// #BVB00095 Starts
					} else if (!i$impactoUtil.isNull(iBio)) {
						if (I$utils.$iStrFuzzyMatch(sLogiBioReq, "Y")) {
							try {
								if (!i$bioVer.isBioValid(iBio, "UID")) {
									LinkedTreeMap isonMap = i$ResM
											.getisonMap(I$AppMessageHandler.get$Message(i$ResM.iHandleResStat(
													parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
													"ACCESS RESTRICTION - INVALID OR UNKNOWN BIOMETRICS")));
									jResponseWrapper = new ResponseWrapper(isonMap,
											HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
									I$SntryCntr.logResponse(jResponseWrapper,
											HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
									return jResponseWrapper;

								}
							} catch (Exception Ex) {
								LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
										i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
												i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN BIOMETRICS")));
								jResponseWrapper = new ResponseWrapper(isonMap,
										HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
								I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
								return jResponseWrapper;
							}
						}
						;
						// #BVB00095 Ends
					} else {
						LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message(
								i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
										i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN 2FA METHOD")));
						jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED,
								null);
						I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
						return jResponseWrapper;
					}

				}

				// #NYE00048 Ends

				if (I$utils.$iStrFuzzyMatch(sLoginCapReq, "Y")) // #00000003 Changes for Src Validations
				{
					if (I$utils.$iStrBlank(captchaID) || I$utils.$iStrBlank(secCode)
							|| db$Ctrl.db$GetRowCnt("ICOR_S_CAPTCHA_VALIDATOR",
									"{ secCode: \"" + secCode + "\", captchaID: \"" + captchaID + "\" }") < 1) {
						//if (I$utils.$iStrFuzzyMatch(secCode, "")) {
							String token = "INVALID CAPTCHA";
							String tokenJStr = "{token:\"" + token + "\"}";
							JsonObject isonReq = new JsonObject();
							isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
									parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", tokenJStr);
							LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
									i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR,
											"AUTHENTICATION FAILED : INVALID CAPTCHA")));
							return new ResponseWrapper(isonMap, HttpStatus.UNAUTHORIZED, null);

						//}
					}
				}
				; // #VD000003 ends...

				// First Time Login Changes
				String CollName = ("ICOR_M_USER_PRF");
				JsonObject Jfilter = new JsonObject();
				Jfilter.addProperty("userId", username);
				JsonObject icorMUserPrf = db$Ctrl.db$GetRow(CollName, Jfilter.toString()); // #BVB00034

				// #BVB00011 Starts

				String userPassDecrypt = password; // #NYE00048

				// #BVB00036
				// Decrypting the given password with session Private Key
				// userPassDecrypt = i$RSA.decryptText(password);
				// Encrypting it with the Salt now for further verification
				userPassDecrypt = i$impactoUtil.generateSecurePassword(userPassDecrypt,
						icorMUserPrf.get("salt").getAsString());
				// #BVB00036 Ends

				Authentication authentication = this.authenticationManager
						.authenticate(new UsernamePasswordAuthenticationToken(username, userPassDecrypt));
				/*
				 * String s=icorMUserPrf.get("ForcePasswordChange").getAsString(); 
				 * 
				 * return new ResponseWrapper("OK", HttpStatus.NOT_MODIFIED, null); }
				 */

				/*
				 * Authentication authentication = this.authenticationManager.authenticate( new
				 * UsernamePasswordAuthenticationToken(username, password) );
				 */
				// #BVB00011 Ends

				SecurityContextHolder.getContext().setAuthentication(authentication);
				logger.debug("authenticated" + authentication.isAuthenticated());
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());
				//#MAQ00105 starts
				float expirationInMinutes = 720;
				if (I$utils.$iStrFuzzyMatch(username, "PIYUSH_3")) {
					expirationInMinutes = expirationInMinutes * 2 * 3650;
				}//#MAQ00105 ends
				String token = net.sirma.impacto.iapp.iutils.JwtUtils.generateHMACToken(username,
						authentication.getAuthorities(), secret, expirationInMinutes); 
				String tokenJStr = "{token:\"" + token + "\"}";
				
				JsonObject isonReq = new JsonObject();

				// #BVB00015 Starts

				JsonObject i$body = new JsonObject();
				i$body.addProperty("token", token);

				// #BVB00047 Starts
				// Check if normal User or AMBASSADOR
				/*
				 * if (db$Ctrl.db$hasModuleRights(username, i$regModules)) { // #BVB00047 Ends
				 * JsonArray i$funcAcc = db$Ctrl.db$getRights(username); if (i$funcAcc != null)
				 * i$body.add("access", i$funcAcc); else i$body.addProperty("access", "[]"); //
				 * #BVB00047 Starts } else { JsonObject i$funcAcc =
				 * db$Ctrl.db$getAmbRights(username); if (i$funcAcc != null)
				 * i$body.add("access", i$funcAcc); else i$body.addProperty("access", "{}"); }
				 */ // #NYE00047 Comments

				// #NYE00047 Begins
				// Check for AB
				JsonArray i$regModules = new JsonArray();
				if (!I$utils.$iStrBlank(ime)) {
					i$regModules.add("AB");
					if (db$Ctrl.db$hasModuleRights(username, i$regModules)) {
						JsonObject i$funcAcc = db$Ctrl.db$getAmbRights(username);
						if (i$funcAcc != null)
							i$body.add("accessAB", i$funcAcc);
						else
						{
							// #BVB00200 Starts 
							//i$body.add("accessAB", new JsonObject());
							LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message(
									i$ResM.iHandleResStat(parserM.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
											i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID AMBASSADOR USER")));
							jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.UNAUTHORIZED,
									null);
							I$SntryCntr.logResponse(jResponseWrapper, HttpStatus.UNAUTHORIZED);
							return jResponseWrapper;
						}
						// #BVB00200 Ends
					}
					;
				}
				;

				// Check for IW
				if (I$utils.$iStrBlank(ime)) {
					i$regModules = new JsonArray();
					i$regModules.add("IW");
					if (db$Ctrl.db$hasModuleRights(username, i$regModules)) {
						// #BVB00047 Ends
						JsonArray i$funcAcc = db$Ctrl.db$getRights(username);
						if (i$funcAcc != null)
							i$body.add("access", i$funcAcc);
						
						else
							i$body.add("access", new JsonArray());
						// JsonArray i$queAcc = db$Ctrl.db$getQRights(username); //BVB00129
						JsonArray i$queAcc = db$Ctrl.db$getQRights(username); //BVB00129  //#BZ000130 change
						if (i$queAcc != null)
							i$body.add("accessWFQ", i$queAcc);
						else
							i$body.add("accessWFQ", new JsonArray());
						// #BVB00047 Starts
					}
					;
				}
				;
				// #NYE00047 Ends

				// #BVB00047 Ends
				// #BVB00034 Starts
				if (icorMUserPrf != null) {
					i$body.add("modules", icorMUserPrf.get("modules").getAsJsonArray());
					i$body.addProperty("name", icorMUserPrf.get("name").getAsString());
					i$body.addProperty("username", icorMUserPrf.get("userId").getAsString());
				} else {
					i$body.addProperty("modules", "[]");
					i$body.addProperty("name", "");
				}
				// #BVB00034 Ends
				// #BVB00112 Starts				
				if(icorMUserPrf.has("prfPic")) {
					i$body.addProperty("prfPic", icorMUserPrf.get("prfPic").getAsString());
				}
				if(icorMUserPrf.has("usrIcon")) {
                 i$body.addProperty("usrIcon", icorMUserPrf.get("usrIcon").getAsString());
                }
				i$body.addProperty("name", icorMUserPrf.get("name").getAsString());
				i$body.addProperty("lastLogin", icorMUserPrf.get("lastLogin").getAsString());
				i$body.addProperty("EmpMail", icorMUserPrf.get("EmpMail").getAsString());
				i$body.addProperty("MobNum", icorMUserPrf.get("MobNum").getAsString());
				i$body.add("loginTime", i$ResM.adddate(new Date()));

				// #BVB00112 Ends
				
				// #BVB00211 Starts 
				// Adding Favourites to Login Response 
				Jfilter = new JsonObject();
				Jfilter.addProperty("userId", username);
				JsonObject icorMUseFav = db$Ctrl.db$GetRow("ICOR_M_USER_FAVOURITE_LEDGER", Jfilter);
				i$body.add("userFavourite", i$ResM.getArrfromObj(icorMUseFav, "favorites"));
				i$body.addProperty("favEnabled", i$ResM.getStrfromObjWithDefault(icorMUseFav, "favEnabled", "N"));
				i$body.addProperty("theme", i$ResM.getStrfromObj(icorMUseFav, "theme"));
				// #BVB00211 Ends
				
				// BHUVI001 Starts
				i$body.addProperty("ForcePasswordChange", icorMUserPrf.get("ForcePasswordChange").getAsString());
				isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
						parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", i$body);
				LinkedTreeMap isonMap = null;

				if (icorMUserPrf.get("ForcePasswordChange").getAsString().equalsIgnoreCase("Y")) {
					isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
							i$ResM.iHandleResStat(isonReq, i$ResM.I_WRN, "FORCE PASSWORD CHANGE")));
				}

				else if (passwordPolicy(i$body)) {
					isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
							i$ResM.iHandleResStat(isonReq, i$ResM.I_ERROR, "USER ACCOUNT IS LOCKED")));
				} else {
					isonMap = i$ResM.getisonMap(I$AppMessageHandler.get$Message( // #A0000001
							i$ResM.iHandleResStat(isonReq, i$ResM.I_SUCC, "AUTHENTICATED")));
					validateLogin("valid", isonBody);
				}

				isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
						parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", i$body);

				logUserLogin(isonReq);

				/*
				 * isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
				 * parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", tokenJStr);
				 */
				// #BVB00015 Ends

				// Nye Changes lastLoginat

				//

				/*
				 * LinkedTreeMap isonMap = i$ResM .getisonMap(i$ResM.iHandleResStat(isonReq,
				 * i$ResM.I_SUCC, "AUTHENTICATED"));
				 */
				// BHUVI001 ENDS
				return new ResponseWrapper(isonMap, HttpStatus.OK, null);
			} catch (Exception e) {
				//e.printStackTrace();
				logger.debug("Authentication Failed with: "+ e.getMessage());
				// BHUVI001 Begin
				validateLogin("invalid", isonBody);
				// BHUVI001 Ends
				String token = "UNAUTH";
				String tokenJStr = "{token:\"" + token + "\"}";
				JsonObject isonReq = new JsonObject();
				JsonObject ibody = new JsonObject();
				ibody = i$ResM.getBody(isonBody);
				isonReq = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
						parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), "i-body", tokenJStr);
				LinkedTreeMap isonMap = null;
				// BHUVI001 Begin
				if (passwordPolicy(ibody)) {
					isonMap = i$ResM.getisonMap(i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "USER ACCOUNT IS LOCKED"));
					// BHUVI001 Ends
				} else {
					isonMap = i$ResM.getisonMap(i$ResM.iHandleResStat(isonReq, i$ResM.I_ERR, "AUTHENTICATION FAILED"));

				}

				return new ResponseWrapper(isonMap, HttpStatus.UNAUTHORIZED, null);
			}
		} finally {
			i$ResM.cleanThreadLocals();// #NYE00049

		}
	}

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		String strUserId, lastLoginTime = null;
		try {
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			logger.info("WelCome to Password Controller");
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "RESET$PASSWORD")) {
				JsonObject jBody;
				jBody = i$ResM.getBody(isonMsg);
				strUserId = jBody.get("username").getAsString();

				String CollName = ("ICOR_M_USER_PRF");
				JsonObject Jfilter = new JsonObject();
				Jfilter.addProperty("userId", strUserId);

				JsonObject rspJson = db$Ctrl.db$GetRow(CollName, Jfilter.toString());
				lastLoginTime = rspJson.get("lastLoginTime").getAsString();
				if (lastLoginTime != null) {
					JsonObject Jdoc = new JsonObject();
					Jdoc.addProperty("lastLoginTime", new Date().toString());
					JsonObject responseJson = db$Ctrl.db$UpdateRow(CollName, Jdoc.toString(), Jfilter);
					isonMsg = i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC, "DATA SUCCESSFULLY UPDATED");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
					return isonMsg;
				}
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "FORGOT$PASSWORD")) {
				JsonObject jBody;
				jBody = i$ResM.getBody(isonMsg);
				strUserId = jBody.get("username").getAsString();

				String CollName = ("ICOR_M_USER_PRF");
				JsonObject Jfilter = new JsonObject();
				Jfilter.addProperty("userId", strUserId);

				JsonObject rspJson = db$Ctrl.db$GetRow(CollName, Jfilter.toString());
				if (rspJson != null) {
					JsonObject Jdoc = new JsonObject();
					Jdoc.addProperty("lastPasswordChange", new Date().toString());
					Jdoc.addProperty("userPwd", "");
					JsonObject responseJson = db$Ctrl.db$UpdateRow(CollName, Jdoc.toString(), Jfilter);
					isonMsg = i$ResM.iHandleResStat(responseJson, i$ResM.I_SUCC, "DATA SUCCESSFULLY UPDATED");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i$body", responseJson);
					return isonMsg;
				}
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN EXCEPTION OF FIRST TIME LOGIN",
					e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

	// #BVB00043 Starts

	private JsonObject logUserLogin(JsonObject isonMsg) {
		JsonObject icorMPresentUsers = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject setter = new JsonObject();
		try {

			filter.addProperty("userId", IResManipulator.iloggedUser.get());
			db$Ctrl.db$Remove("ICOR_S_SESSION_VALIDATOR", filter);
			db$Ctrl.db$Remove("ICOR_S_TOKEN_VALIDATOR", filter);

			// Add to Session Validator
			filter = new JsonObject();
			filter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId"));
			setter.addProperty("userId", IResManipulator.iloggedUser.get());
			setter.add("lastActivityAt", i$ResM.addDateTime(new Date()));
			db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", setter, filter);

			// Add Token to Token validator
			setter.addProperty("token", i$ResM.getBodyElementS(isonMsg, "token"));
			setter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId")); // #BVB00065

			JsonObject in$ =  db$Ctrl.db$InsertRow("ICOR_S_TOKEN_VALIDATOR", setter);

			//JsonObject in$ = db$Ctrl.db$InsertRow("ICOR_S_USER_ACT_LOG", icorMPresentUsers);
			return in$;
		} catch (Exception e) {
			logger.debug("Failed while logging Wser Login with:" + e.getMessage());
			return null;
		}

	}

	// #BVB00043 Ends

	public boolean passwordPolicy(JsonObject isonBody) {
		// BHUVI001 START
		try {
			JsonObject J$userdet = db$Ctrl.db$GetRow("ICOR_M_PWD_PLCY", "{}");
			String CollName = ("ICOR_M_USER_PRF");
			JsonObject Jfilter = new JsonObject();
			String username = isonBody.get("username").getAsString();
			Jfilter.addProperty("userId", username);
			JsonObject icorMUserPrf = db$Ctrl.db$GetRow(CollName, Jfilter);

			int cummLogin = icorMUserPrf.get("cummulativeLogin").getAsInt();
			int succLogin = icorMUserPrf.get("successiveLogin").getAsInt();

			//String lastLoginDate = icorMUserPrf.get("LastPasswordChange").getAsString(); // #BVB00103  
			String lastLoginDate = icorMUserPrf.get("lastLogin").getAsString(); // #BVB00103 
			String todayDate = I$utils.currentDateinString();
			int DiffinDays = I$utils.getDateDifference(lastLoginDate, todayDate); 

			if (cummLogin > J$userdet.get("cumulative").getAsInt()) {
				{
					updateUser(Jfilter, 1);
					return true;
				}
			}
			if (succLogin > J$userdet.get("successive").getAsInt()) {
				{
					updateUser(Jfilter, 2);
					return true;

				}
			}
			if (DiffinDays > J$userdet.get("dormancyDays").getAsInt()) {
				{
					updateUser(Jfilter, 3);
					return true;

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	public void validateLogin(String state, JsonObject isonBody) {
		try {
			JsonObject ibody = i$ResM.getBody(isonBody);
			String CollName = ("ICOR_M_USER_PRF");
			String CollName_L = ("ICOR_M_USER_PRF_LEDGER");
			JsonObject Jfilter = new JsonObject(); 
			Jfilter.addProperty("userId", ibody.get("username").getAsString());
			JsonObject icorMUserPrf = db$Ctrl.db$GetRow(CollName, Jfilter.toString());

			int cummLogin = 0;
			int succLogin = 0;
			JsonObject iDoc = new JsonObject();
			if (!icorMUserPrf.isJsonNull()) {
				if (state.equals("invalid")) {
					cummLogin = icorMUserPrf.get("cummulativeLogin").getAsInt();
					succLogin = icorMUserPrf.get("successiveLogin").getAsInt();

					cummLogin = cummLogin + 1;
					succLogin = succLogin + 1;
					iDoc.addProperty("cummulativeLogin", cummLogin);
					iDoc.addProperty("successiveLogin", succLogin);

				}
				if (state.equals("valid")) { 
					iDoc.add("lastLogin", i$ResM.adddate(new Date()));
					iDoc.addProperty("successiveLogin", succLogin);
				}
			}

			db$Ctrl.db$UpdateRow(CollName, iDoc, Jfilter, "true");
			Jfilter.addProperty("isCurrVer", "Y");// #BHUVI003 
			db$Ctrl.db$UpdateRow(CollName_L, iDoc, Jfilter, "true");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void updateUser(JsonObject Jfilter, int Type) {
		try {
			JsonObject iDoc = new JsonObject();
			String CollName = ("ICOR_M_USER_PRF");
			String CollName_L = ("ICOR_M_USER_PRF_LEDGER");

			iDoc.addProperty("active", "I");
			iDoc.addProperty("lockedStatus", Type);

			db$Ctrl.db$UpdateRow(CollName, iDoc, Jfilter, "true");
			iDoc.addProperty("isCurrVer", "Y");// #BHUVI003
			db$Ctrl.db$UpdateRow(CollName_L, iDoc, Jfilter, "true");
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	// BHUVI001 ends

}
// #00000001 Ends ICOR_M_APP_USER