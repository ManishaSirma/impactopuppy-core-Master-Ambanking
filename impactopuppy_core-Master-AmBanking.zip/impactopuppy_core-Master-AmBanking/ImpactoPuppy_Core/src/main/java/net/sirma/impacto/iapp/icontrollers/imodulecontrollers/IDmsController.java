/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Jab 1, 2019  | #00000001   | Initial writing
      |0.3.6       | Vijay 		| Apr 15, 2019 | #BVB00113   | Making DMS a 2 step with ID as immediate response and later processing
      |0.3.6       | Vijay 		| Apr 19, 2019 | #BVB00123   | File Upload Status Check function
      |0.3.6       | Vijay 		| Apr 23, 2019 | #BVB00125   | DMS Upload will return more details. Status check have two modes (List and Single)
      |0.3.6       | Pappu      | Nov 21, 2022 | #PKY00080   | Implemented Printer to print DMS docs.
      |0.3.6       | Sindhu     | Dec 08, 2022 | #SRM00014   | Handled code for multiple files download
      |0.3.6       | Sumit      | Aug 02, 2023 | #SKG00017   | Added code for preview the documents history reflecting multiple times  
      |0.3.6       | Sumit      | Sep 05, 2023 | #SKG00028   | Added code for modify by & user name is not coming at the time of upload the manual documents 
      |0.3.6       | Sumit      | Sep 12, 2023 | #SKG00029   | Added code for  showing history for preview password protected   
      |0.5 Beta    | karthik    | Dec 04 2023  | #NK00068    | added code for validation for initiator               
      -----------------------------------------------------------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.awt.print.PrinterJob;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.AttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.HashPrintServiceAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.attribute.standard.PrinterName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.CaptchaController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.ILogicalDocController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class IDmsController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(CaptchaController.class); // Nye- Change Class Name
	private IDocumentsController i$doc = new IDocumentsController(); // always
	private IResPreFlightHandler i$resPre = new IResPreFlightHandler();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	// **********************************************************************//

	@SuppressWarnings("unused")
	private IDataValidator I$DataValidator = new IDataValidator();
	@SuppressWarnings("unused")
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private ILogicalDocController iLDoc$Con = new ILogicalDocController();

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();
			JsonObject jWrkArgs = new JsonObject();

			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String srvcName = i$ResM.getSrvcName(isonMsg);
			String srvcOpr = i$ResM.getSrvcopr(isonMsg);
			
			if ((I$utils.$iStrFuzzyMatch(Scr, "FDMFLUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) || (I$utils.$iStrFuzzyMatch(Scr, "FABFLUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) || (I$utils.$iStrFuzzyMatch(Scr, "FDMAPUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE"))) {
				// return uploadFile2Dms(isonMsg); // #BVB00113
				String DMSLDOC = "N";
				try {
					DMSLDOC = isonMsg.getAsJsonObject("i-body").get("DMSLDOC").getAsString();
				} catch (Exception e) {
					// no body
				}
//				if(I$utils.$iStrFuzzyMatch(DMSLDOC,"Y")) {//#YPR00044 changes
////					isonMsg = iLDoc$Con.processMsg(isonMsg);
//					// #YPR00080 Changes
//					jWrkArgs.add("isonMsg", isonMsg.deepCopy());
//					jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.isrvccontrollers.ILogicalDocController");
//					jWrkArgs.addProperty("funcName", "processMsg");
//
//					IThreadController IThread$worker = new IThreadController(jWrkArgs);
//					Thread t = new Thread(IThread$worker);
//					// threads Started
//					t.start();
//				}

				if (I$utils.$iStrFuzzyMatch(DMSLDOC, "Y")) {
					JsonObject docsMsg = null;
					JsonObject ibody = i$ResM.getBody(isonMsg);
					if((I$utils.$iStrFuzzyMatch(Scr, "FABFLUPD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) || (I$utils.$iStrFuzzyMatch(Scr, "FDMFLUPD") && (ibody.has("workspaceId") && I$utils.$iStrFuzzyMatch(ibody.get("workspaceId").getAsString(), "IWS10002")))) {
						docsMsg = i$doc.docCreate(isonMsg);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(docsMsg), i$ResM.I_SUCC)) {
							isonMsg = i$resPre.processMsg(i$Annotate, docsMsg);
						}
					}else if(I$utils.$iStrFuzzyMatch(Scr, "FDMAPUPD")){
						docsMsg = i$doc.createWorkspaceFldr(isonMsg);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(docsMsg), i$ResM.I_SUCC)) {
							i$resPre.processMsg(i$Annotate, docsMsg);
							return uploadMultipleFile2DmsHandler(docsMsg);
						}
					}
					else if (I$Imputils.hasStringInKey(ibody, "parentFolderId") && I$Imputils.hasStringInKey(ibody, "workspaceId")) { // #YPR00094 Changes
						docsMsg = i$doc.processMsg(isonMsg, isonheader, isonMapJson);// Regular DMS Upload
					} 
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(docsMsg), i$ResM.I_SUCC)) {
						return uploadFile2DmsHandler(docsMsg);
					} else {
						return docsMsg;
					}
				}
				return uploadFile2DmsHandler(isonMsg); // #BVB00113
			} else if (I$utils.$iStrFuzzyMatch(Scr, "FDMFLDLD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				return downloadFileDms(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "GETDOCS")) {
				return i$doc.getDocsCount(isonMsg);
			} else if(I$utils.$iStrFuzzyMatch(Scr, "FDSFLARR") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				JsonArray fileUrlTokens = isonMsg.get("i-body").getAsJsonObject().get("FileUrlToken").getAsJsonArray();
				if(fileUrlTokens.size() == 1) {
					return downloadFileDms(isonMsg);
				}else {
					return dwnldMultipleFiles(isonMsg);
				}
				
			} //SRM00014
			// #BVB00123 Starts
			else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				return queryDmsFlStatusHandler(isonMsg);
			}// #BVB00123 Ends
			//#PKY00080 starts
			else if(I$utils.$iStrFuzzyMatch(srvcName, "PRINTER") && I$utils.$iStrFuzzyMatch(srvcOpr, "initiatePrinting")) {
				return initiatePrinting(isonMsg);
			}//#PKY00080 ends
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

// #BVB00113 Starts 
	private JsonObject uploadFile2DmsHandler(JsonObject isonMsg) {
		JsonObject i$res = new JsonObject();
		JsonObject jWrkArgs = new JsonObject();
		String fileUrlToken = "";
		try {
			if(i$ResM.getBody(isonMsg).has("FileUrlToken")) {
				fileUrlToken = i$ResM.getBodyElementS(isonMsg, "FileUrlToken"); 
			}else {
				fileUrlToken = I$Imputils.generateRandomKey();
			}
			// i$res = i$ResM.getBody(isonMsg).deepCopy();
			i$res.addProperty("FileUrlToken", fileUrlToken);

			// add DMS Mapper -- ICOR_M_DMS_LOGGER
			// submit the upload in thread and update the logger at the end of completion
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlToken", fileUrlToken);
			//SKG00028 starts
			try {
				isonMsg.get("i-body").getAsJsonObject().addProperty("tempUser", IResManipulator.iloggedUser.get());
			}catch(Exception e) {
				e.printStackTrace();
				
			}	//SKG00028 end
			jWrkArgs.add("isonMsg", isonMsg.deepCopy());
			jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController");
			jWrkArgs.addProperty("funcName", "uploadFile2Dms");

			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker);
			// threads Started
			t.start();

			// Log and respond back
			i$res.add("createdAt", i$ResM.addDateTime(new Date()));
			db$Ctrl.db$InsertRow("ICOR_M_DMS_LOGGER", i$res);
			i$res = I$Imputils.mergeJsonObject(i$res, i$ResM.getBody(isonMsg)); 
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "FILE UPLOAD INITIATED");

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED WHILE UPLOADING THE FILE");
		}
		return isonMsg;
	}

	private JsonObject uploadMultipleFile2DmsHandler(JsonObject isonMsg) {
		JsonObject i$res = new JsonObject();
		JsonObject jWrkArgs = new JsonObject();
		JsonArray fileUrlToken = null;
		try {
			fileUrlToken = isonMsg.get("i-body").getAsJsonObject().get("files").getAsJsonArray(); 
			for(int i = 0 ; i < fileUrlToken.size() ; i++) {
				i$res.addProperty("FileUrlToken", fileUrlToken.get(i).getAsJsonObject().get("FileUrlToken").getAsString());
				i$res.add("createdAt", i$ResM.addDateTime(new Date()));
				db$Ctrl.db$InsertRow("ICOR_M_DMS_LOGGER", i$res);
			}
			

			// add DMS Mapper -- ICOR_M_DMS_LOGGER
			// submit the upload in thread and update the logger at the end of completion
			//isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlToken", fileUrlToken);

			jWrkArgs.add("isonMsg", isonMsg.deepCopy());
			jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController");
			jWrkArgs.addProperty("funcName", "uploadMultipleFile2Dms");

			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker);
			// threads Started
			t.start();

			// Log and respond back
			i$res = I$Imputils.mergeJsonObject(i$res, i$ResM.getBody(isonMsg)); 
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "FILE UPLOAD INITIATED");
		}catch(Exception e) {
			
		}
		return isonMsg;
	}
	
	public JsonObject uploadMultipleFile2Dms(JsonObject isonMsg) {
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		JsonObject i$Annotate = null, i$body = null;
		// YPR00099 Changes
		String DMSLDOC = "N";
		try {
			DMSLDOC = isonMsg.getAsJsonObject("i-body").get("DMSLDOC").getAsString();
		} catch (Exception e) {
			// no body
		}

		// Annotate Validate
		i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR", "{\"ANNOTATION\":\"" + ScrID + "_" + SOpr + "\"}");
		if (i$Annotate == null) {
			Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD ANNOTATE");
			// return isonMsg;
		} else {
			// Data Validator
			i$body = isonMsg.getAsJsonObject("i-body");
			I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
			try {
				if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
					// #BVB00113 Starts
					// if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrID, SOpr)) {
					// Forwarding Request to DBController for DMS Upload
					isonMsg = db$Ctrl.db$MultiGrdFSUpld(isonMsg);
					/*
					 * } // end of if has db$hasRights else { Sentry$Controller.isonResHTPPStat =
					 * HttpStatus.BAD_REQUEST; isonMsg = i$ResM.iHandleResStat(isonMsg,
					 * i$ResM.I_ERR, "ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS"); //return
					 * isonMsg; }
					 */
					;
					// #BVB00113 Ends
				} // End of If DataVal
				else {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
					// return isonMsg;
				}
			} // End of try
			catch (Exception excep) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
						excep.getMessage().toString());
				excep.printStackTrace();
				// return isonMsg;
			}
			;
		}
		if ((I$utils.$iStrFuzzyMatch(DMSLDOC, "Y") && I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) || (I$utils.$iStrFuzzyMatch(DMSLDOC, "N") && I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC))) {//#TKS00014 chnages
			isonMsg.get("i-body").getAsJsonObject().addProperty("historyOnFile", true);
			db$Ctrl.db$logDmsHstry(isonMsg); // #YPR00099 Changes
			isonMsg.get("i-body").getAsJsonObject().remove("historyOnFile");
		}
		logMultiDMSResponse(isonMsg); // #BVB00113
		return isonMsg;
	}
	
	// #BVB00113 Ends
	public JsonObject uploadFile2Dms(JsonObject isonMsg) {
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		JsonObject i$Annotate = null, i$body = null;
		// YPR00099 Changes
		String DMSLDOC = "N";
		//SKG00028 starts
		try {
			IResManipulator.iloggedUser.set(isonMsg.getAsJsonObject("i-body").get("tempUser").getAsString());
			isonMsg.getAsJsonObject("i-body").remove("tempUser");
		}catch(Exception e) {
			e.printStackTrace();
		}	//SKG00028 end
		try {
			DMSLDOC = isonMsg.getAsJsonObject("i-body").get("DMSLDOC").getAsString();
		} catch (Exception e) {
			// no body
		}

		// Annotate Validate
		i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR", "{\"ANNOTATION\":\"" + ScrID + "_" + SOpr + "\"}");
		if (i$Annotate == null) {
			Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD ANNOTATE");
			// return isonMsg;
		} else {
			// Data Validator
			i$body = isonMsg.getAsJsonObject("i-body");
			I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
			try {
				if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
					// #BVB00113 Starts
					// if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrID, SOpr)) {
					// Forwarding Request to DBController for DMS Upload
					isonMsg = db$Ctrl.db$GrdFSUpld(isonMsg);
					/*
					 * } // end of if has db$hasRights else { Sentry$Controller.isonResHTPPStat =
					 * HttpStatus.BAD_REQUEST; isonMsg = i$ResM.iHandleResStat(isonMsg,
					 * i$ResM.I_ERR, "ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS"); //return
					 * isonMsg; }
					 */
					;
					// #BVB00113 Ends
				} // End of If DataVal
				else {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
					// return isonMsg;
				}
			} // End of try
			catch (Exception excep) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
						excep.getMessage().toString());
				excep.printStackTrace();
				// return isonMsg;
			}
			;
		}
		if ((I$utils.$iStrFuzzyMatch(DMSLDOC, "Y") && I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) || (I$utils.$iStrFuzzyMatch(DMSLDOC, "N") && I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC))) {//#TKS00014 chnages
			db$Ctrl.db$logDmsHstry(isonMsg); // #YPR00099 Changes
		}
		logDMSResponse(isonMsg); // #BVB00113
		return isonMsg;
	};

	// #BVB00113 Starts
	private void logDMSResponse(JsonObject isonMsg) {
		try {
			JsonObject setter = new JsonObject();
			JsonObject filter = new JsonObject();

			setter.addProperty("FileUrlId", i$ResM.getBodyElementS(isonMsg, "FileUrlId"));
			setter.add("completedAt", i$ResM.addDateTime(new Date()));
			setter.addProperty("isCurrVer", "Y");
			setter.addProperty("DocNo" , isonMsg.get("i-body").getAsJsonObject().get("DocNo").getAsString());
			setter.add("i-stat", i$ResM.getiStat(isonMsg));
			// setter.addProperty("status", i$ResM.getStatMsg(isonMsg));
			// setter.addProperty("errMsg", i$ResM.getMsgtext(isonMsg));

			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			db$Ctrl.db$UpdateRow("ICOR_M_DMS_LOGGER", setter, filter, "true");
		} catch (Exception e) {

		}
	}
	
	private void logMultiDMSResponse(JsonObject isonMsg) {
		try {
			JsonObject setter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonArray fileUrlIds = new JsonArray();
			fileUrlIds = isonMsg.get("i-body").getAsJsonObject().get("FileUrlIds").getAsJsonArray();
			for(int i = 0 ; i < fileUrlIds.size() ; i++) {
				setter.addProperty("FileUrlId", fileUrlIds.get(i).getAsString());
				setter.add("completedAt", i$ResM.addDateTime(new Date()));
				setter.addProperty("isCurrVer", "Y");
				setter.addProperty("DocNo" , isonMsg.get("i-body").getAsJsonObject().get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocNo").getAsString());
				setter.add("i-stat", i$ResM.getiStat(isonMsg));
				filter.addProperty("FileUrlToken", isonMsg.get("i-body").getAsJsonObject().get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileUrlToken").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_M_DMS_LOGGER", setter, filter, "true");
			}
			
		} catch (Exception e) {

		}
	}
// #SRM00014 Starts
	private JsonObject dwnldMultipleFiles(JsonObject isonMsg) {
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		JsonObject i$Annotate = null, i$body = null;
		JsonObject filter = new JsonObject();
		JsonArray fileUrlArray = new JsonArray();
		// Annotate Validate
		i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR", "{\"ANNOTATION\":\"" + ScrID + "_" + SOpr + "\"}");
		if (i$Annotate == null) {
			Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD ANNOTATE");
			return isonMsg;
		}
		// Data Validator
		i$body = isonMsg.getAsJsonObject("i-body");
		I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
		JsonObject icorMDmsLogger = new JsonObject();
		JsonArray urlDetl= new JsonArray();
		JsonArray UrlArr = new JsonArray();
		JsonObject tokenDetls = new JsonObject();
		JsonArray UrlDetls = new JsonArray();
		I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
		try {
			if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
				if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrID, SOpr)) {
					// Forwarding Request to DBController for DMS Upload
					// Getting the FileUrlId from ICOR_M_DMS_LOGGER using FileUrlToken
					fileUrlArray = i$body.get("FileUrlToken").getAsJsonArray();
					for(int i = 0 ; i <fileUrlArray.size() ; i++){
						i$body = new JsonObject();
						String fileUrlToken = fileUrlArray.get(i).getAsString();
						JsonObject fileData1 = db$Ctrl.db$GetRow("fs.files", "{'metadata.FileUrlToken':'" + fileUrlToken + "','metadata.isCurrVer':'Y'}");
						// #NK00068 starts
//						if (!(I$utils.$iStrFuzzyMatch(fileData1.get("metadata").getAsJsonObject().get("initiator").getAsString(),IResManipulator.iloggedUser.get())) && (I$utils.$iStrFuzzyMatch(fileData1.get("metadata").getAsJsonObject().get("workspaceId").getAsString(),"IWRKSP469371"))) {
//							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can amend the records ");
//							return isonMsg;
//						} //NK00068 ends
							filter.addProperty("FileUrlToken", fileUrlToken);
							icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
						if (!I$utils.$isNull(icorMDmsLogger)) {
							if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(icorMDmsLogger), i$ResM.I_SUCC)) {
								isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId",
										icorMDmsLogger.get("FileUrlId").getAsString());
								isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlToken",
									                  icorMDmsLogger.get("FileUrlToken").getAsString());
								isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
								if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
									i$body = i$ResM.getBody(isonMsg);
									JsonObject fileData = db$Ctrl.db$GetRowWithId("fs.files",
											icorMDmsLogger.get("FileUrlId").getAsString());
									JsonObject fileDataMeta = fileData.getAsJsonObject("metadata");
									fileDataMeta.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
									fileDataMeta.addProperty("FileContent", i$body.get("FileContent").getAsString());
									fileDataMeta.addProperty("tranId", i$body.get("tranId").getAsString());
									urlDetl.add(fileDataMeta);								} else {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(isonMsg));
								}
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(icorMDmsLogger));
							}
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID FILETOKEN");
					}
						
					}
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, urlDetl);
				}
				else {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
					return isonMsg;
				};
			} 
			else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
				return isonMsg;
			}
		} 
		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		};
		UrlDetls.add(urlDetl);
		return isonMsg;
	} // #SRM00014 ends
	// #BVB00113 Ends
	public JsonObject downloadFileDms(JsonObject isonMsg) {
		String SOpr = i$ResM.getOpr(isonMsg);//SKG00017 changes
		String SOpr2 = i$ResM.getOpr2(isonMsg);
		String ScrID = i$ResM.getScreenID(isonMsg);
		JsonObject i$Annotate = null, i$body = null;
		JsonObject filter = new JsonObject();
		// Annotate Validate
		i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR", "{\"ANNOTATION\":\"" + ScrID + "_" + SOpr + "\"}");
		if (i$Annotate == null) {
			Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD ANNOTATE");
			return isonMsg;
		}
		// Data Validator
		i$body = isonMsg.getAsJsonObject("i-body");
		I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrID, SOpr);
		try {
			if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
//				if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrID, SOpr)) {
				// Forwarding Request to DBController for DMS Upload
				// #BVB00113 Starts
				// Getting the FileUrlId from ICOR_M_DMS_LOGGER using FileUrlToken
				filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
				JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
//				JsonObject fileData1 = db$Ctrl.db$GetRow("fs.files", "{'metadata.FileUrlToken':'" + i$body.get("FileUrlToken").getAsString() + "','metadata.isCurrVer':'Y'}");
				// #NK00068 starts
//				if (!(I$utils.$iStrFuzzyMatch(fileData1.get("metadata").getAsJsonObject().get("initiator").getAsString(),IResManipulator.iloggedUser.get())) && (I$utils.$iStrFuzzyMatch(fileData1.get("metadata").getAsJsonObject().get("workspaceId").getAsString(),"IWRKSP469371"))) {
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can amend the records");
//					return isonMsg;
//				} //NK00068 ends
				if (!I$utils.$isNull(icorMDmsLogger)) {
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(icorMDmsLogger), i$ResM.I_SUCC)) {
						isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId",icorMDmsLogger.get("FileUrlId").getAsString());
						// #BVB00113 Ends
						// #YPR00101 Starts
						if (!i$body.has("fileKey")) {
							JsonObject fileData = db$Ctrl.db$GetRow("fs.files", "{'metadata.FileUrlToken':'" + i$body.get("FileUrlToken").getAsString() + "','metadata.isCurrVer':'Y'}");
							if (I$utils.$isNull(fileData)) {
								i$body = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsg.getAsJsonObject("i-body"),"FileUrlId");
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FileUrlToken Doesn't Exist");
								return isonMsg;
							}
							JsonObject mtdta = fileData.get("metadata").getAsJsonObject();
							if (mtdta.has("isPswrdPrctd")) {
								if (mtdta.get("isPswrdPrctd").getAsBoolean()) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"File is Password Protected");
									return isonMsg;
								} else {
									isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);//SKG00017 changes
//									if(I$utils.$iStrFuzzyMatch(SOpr2, ""))
										//db$Ctrl.db$logDmsHstry(isonMsg);//#TKS00015 changes
								}
							} else {
								isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);//SKG00017 changes
								if(I$utils.$iStrFuzzyMatch(SOpr2, ""))
									db$Ctrl.db$logDmsHstry(isonMsg);//#TKS00015 changes
							}
						} else {
							if (db$Ctrl.db$DocPassVerify(isonMsg)) {
								isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
								if(I$utils.$iStrFuzzyMatch(SOpr2, ""))//SKG00029 changes
								db$Ctrl.db$logDmsHstry(isonMsg);
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Correct File Password");//#TKS00015 changes
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");
								return isonMsg;
							}
						}
						// #YPR00101 Ends
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
							// #BVB00057 Starts
							i$body = i$ResM.getBody(isonMsg);
							// Adding code to get the complete MetaData

//							JsonObject fileData = db$Ctrl.db$GetRowWithId("fs.files",
//									i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
							JsonObject fileData = db$Ctrl.db$GetRowWithId("fs.files",
									icorMDmsLogger.get("FileUrlId").getAsString());
							JsonObject fileDataMeta = fileData.getAsJsonObject("metadata");
							if (I$Imputils.hasStringInKey(fileDataMeta, "dmsApi")) {
								fileDataMeta.remove("parentFolderId");
								fileDataMeta.remove("workspaceId");
								fileDataMeta.remove("parentFolderName"); // #YPR00101 Changes
								fileDataMeta.remove("folderIdPath");
								fileDataMeta.remove("initiator");
								fileDataMeta.remove("dmsApi");
								fileDataMeta.remove("Archive");
								fileDataMeta.remove("isCurrVer");
							}
							fileDataMeta.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
							fileDataMeta.addProperty("FileContent", i$body.get("FileContent").getAsString());
							fileDataMeta.addProperty("tranId", i$body.get("tranId").getAsString());

								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, fileDataMeta);
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(isonMsg));
							}
						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(icorMDmsLogger));
						}
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID FILETOKEN");
					}
					// #BVB00057 Ends
				 // end of if has db$hasRights
//				} else {
//					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//							"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
//					return isonMsg;
//				};
			} // End of If DataVal
			else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
				return isonMsg;
			}
		} // End of try
		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
		;
		return isonMsg;
	};
	// #BVB00123 Starts
	// #TKS00010 starts
	public void documentDownload(JsonObject isonBody) {
		JsonObject i$body = new JsonObject();
		JsonObject i$header = new JsonObject();
		JsonObject folderData = new JsonObject();
		i$body = isonBody.get("i-body").getAsJsonObject();
		folderData = i$body.get("folderData").getAsJsonObject();
		String applicationId = i$body.get("applicationId").getAsString();
		String folderId = folderData.get("folderId").getAsString();
		String cifId = i$body.get("cifId").getAsString();
		String cntCode = i$body.get("cntCode").getAsString();
		String typeOfProd = i$body.get("typeOfProduct").getAsString();
		String accNo = i$body.get("accNo").getAsString();
		String referenceNo = i$body.get("referenceNo").getAsString();
		JsonObject fldrData = new JsonObject();
		JsonObject query = new JsonObject();
		JsonArray documents = new JsonArray();
		query.addProperty("workspaceId", "IWS10001");
		query.addProperty("isCurrVer", "Y");
		query.addProperty("folderName", applicationId);
		fldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", query);
		i$body.remove("applicationId");
		i$body.remove("folderId");
		i$body.remove("cifId");
		i$body.remove("cntCode");
		i$body.remove("typeOfProduct");
		i$body.remove("accNo");
		i$body.remove("referenceNo");
		i$body.remove("folderData");
		try {
			documents = fldrData.get("documents").getAsJsonArray();
			for (int j = 0; j < documents.size(); j++) {
				JsonObject runningObj = documents.get(j).getAsJsonObject();
				if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonBody), "FDMFLUPD")) {
					i$header = isonBody.get("i-header").getAsJsonObject();
					i$header.addProperty("screenid", "FDMFLDLD");
					i$body.addProperty("tranId", isonBody.get("i-body").getAsJsonObject().get("tranId").getAsString());
					isonBody = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, "i-header", i$header);
					isonBody = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonBody, "i-stat");
				}
				i$body.addProperty("FileUrlToken", runningObj.get("FileUrlToken").getAsString());
				isonBody = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonBody, "i-body", i$body);
				JsonObject isonMsg = downloadFileDms(isonBody);
				String fileUrlToken = null;
				if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "FDMFLDLD")) { // #SKP00001 Changes Starts
					fileUrlToken = I$utils.$randomAplhanumeric(50);
					i$body.remove("folderId");
					i$header = isonMsg.get("i-header").getAsJsonObject();
					i$header.addProperty("screenid", "FDMFLUPD");
					i$body = isonMsg.get("i-body").getAsJsonObject();
					String fileData = i$body.get("FileContent").getAsString();
					i$body.remove("initiator");
					i$body.remove("isPswrdPrctd");
					i$body.remove("isCurrVer");
					i$body.remove("Archive");
					i$body.remove("UpldSvrDateTime");
					i$body.remove("StorageType");
					i$body.remove("AccessToken");
					i$body.remove("FileContent");
					i$body.remove("verNo");
					i$body.remove("folderId");
					i$body.remove("dmsApi");
					i$body.remove("folderIdPath");
					i$body.remove("docUpload");
					i$body.addProperty("FileUrlToken", fileUrlToken);
					i$body.addProperty("workspaceId", folderData.get("workspaceId").getAsString());
					i$body.addProperty("parentFolderName", folderData.get("folderName").getAsString());
					i$body.addProperty("parentFolderId", folderData.get("folderId").getAsString());
					i$body.addProperty("Key1", cntCode);
					i$body.addProperty("Key2", typeOfProd);
					i$body.addProperty("Key3", cifId);
					i$body.addProperty("Key4", accNo);
					i$body.addProperty("Key5", applicationId);
					i$body.addProperty("Key6", referenceNo);
					i$body.addProperty("I#FileData", fileData);
					i$body.addProperty("DMSLDOC", "Y");
					i$body.addProperty("verNo", 1);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-header", i$header);
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				}
				isonMsg = uploadFile2DmsHandler(isonMsg);
				i$body = isonMsg.get("i-body").getAsJsonObject();
				i$body.addProperty("folderId", folderId);
				i$body.addProperty("docUpload", "true");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				//isonMsg = i$doc.addDocApi(isonMsg);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsg, "i-stat"); // #SKP00001 Changes Ends
				i$body = new JsonObject();
			}
		} catch (Exception e) {

		}

	}// #TKS00010 ends

	public JsonObject queryDmsFlStatusHandler(JsonObject isonMsg) {
		try {
			// #BVB00125 Starts 
			// queryDmsFlStatusS(isonMsg);
			String mode = "S";
			mode = i$ResM.getBodyElementS(isonMsg, "mode");
			if (I$utils.$iStrBlank(mode)) {
				mode = "S";
			}

			if (I$utils.$iStrFuzzyMatch(mode, "S")) {
				queryDmsFlStatusS(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(mode, "L")) {
				queryDmsFlStatusL(isonMsg);
			}
			// #BVB00125 Ends 
		} catch (Exception e) {

		}
		return isonMsg;
	}

	public JsonObject queryDmsFlStatusS(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		try {
			// #BVB00125 Starts
//			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
//			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);

			JsonObject fileUpdDet = queryDmsFile(i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			// #BVB00125 Ends
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$ResM.getBody(fileUpdDet));

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG, i$ResM.getiStat(fileUpdDet));

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_ERR,
					"FAILED WITH: " + e.getMessage());
		}
		return isonMsg;
	}
	// #BVB00123 Ends
	// #BVB00125 Starts
	public JsonObject queryDmsFile(String FileUrlToken) {
		JsonObject filter = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
		JsonObject i$body = new JsonObject();
		try {
			filter.addProperty("FileUrlToken", FileUrlToken);
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);

			if (!I$utils.$isNull(icorMDmsLogger)) {
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(icorMDmsLogger), i$ResM.I_SUCC)) {
					isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
					isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlToken",
							icorMDmsLogger.get("FileUrlToken").getAsString());

					// #BVB00113 Ends
					isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
						// #BVB00057 Starts
						i$body = i$ResM.getBody(isonMsg);
						// Adding code to get the complete MetaData

						JsonObject fileData = db$Ctrl.db$GetRowWithId("fs.files",
								icorMDmsLogger.get("FileUrlId").getAsString());
						JsonObject fileDataMeta = fileData.getAsJsonObject("metadata");

						fileDataMeta.addProperty("FileUrlToken", i$body.get("FileUrlToken").getAsString());
						// fileDataMeta.addProperty("FileContent", ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS
						// i$body.get("FileContent").getAsString());
						// fileDataMeta.addProperty("tranId", i$body.get("tranId").getAsString());

						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, fileDataMeta);
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(isonMsg));
					}
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(icorMDmsLogger));
				}
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID FILETOKEN");
			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED WITH: " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject queryDmsFlStatusL(JsonObject isonMsg) {
		JsonArray i$res = new JsonArray();
		int totalNoOfSuccDocs = 0 ;
		int totalNoOfErrDocs = 0 ;
		JsonObject i$body = new JsonObject(); 
		try {
			JsonArray fileUrlTokens = i$ResM.getBodyElementA(isonMsg, "FileUrlToken"); 
			for (int i = 0; i < fileUrlTokens.size(); i++) {
				String fileUrlToken = fileUrlTokens.get(i).getAsString();
				JsonObject fileUpdDet = queryDmsFile(fileUrlToken);
				JsonObject i$runningObj = new JsonObject();
				i$runningObj.addProperty("FileUrlToken", fileUrlToken);
				i$runningObj.add("metadata", i$ResM.getBody(fileUpdDet));
				if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(fileUpdDet), i$ResM.I_SUCC) ) {
					totalNoOfSuccDocs ++; 
				} else {
					totalNoOfErrDocs ++;
				}
				i$runningObj = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$runningObj, i$ResM.I_STATTAG,
						i$ResM.getiStat(fileUpdDet));
				i$res.add(i$runningObj);
			}
			i$body.addProperty("totalNoOfRecs", i$res.size());
			i$body.addProperty("totalNoOfSuccRecs", totalNoOfSuccDocs);
			i$body.addProperty("totalNoOfErrRecs", totalNoOfErrDocs);
			i$body.add("docsStatus", i$res);
			
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "FILES STATUS RETRIEVED SUCCESSFULLY");
			 
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED DURING RETREIVING FILE UPLOAD STATUS");
		}
		return isonMsg;
	}
	// #BVB00125 Ends
	
	//#PKY00080 starts
	public JsonObject initiatePrinting(JsonObject isonMsg) throws IOException, PrintException {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		try {
			String FileUrlToken = i$body.get("FileUrlToken").getAsString();
			String printerName = i$body.get("printerName").getAsString();
			i$ResM.setGobalVals("printerName", printerName);
			String printer$Name = i$ResM.getGobalValStr("printerName");
			isonMsg.get("i-header").getAsJsonObject().addProperty("screenid", "FDMFLDLD");
			isonMsg.get("i-header").getAsJsonObject().addProperty("operation1", "FILEDWLD");
			isonMsg.get("i-header").getAsJsonObject().addProperty("operation", "CREATE");
			isonMsg.get("i-body").getAsJsonObject().remove("printerName");
			JsonObject dwnldDmsFile = downloadFileDms(isonMsg);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(dwnldDmsFile), i$ResM.I_SUCC)) {
				JsonObject i$bodyAfterDwnldDms = i$ResM.getBody(dwnldDmsFile);
				String doc = i$bodyAfterDwnldDms.get("FileContent").getAsString();
				PrinterJob job = PrinterJob.getPrinterJob();
				job.setJobName("Doc Printing");
				PrintRequestAttributeSet attr_set = new HashPrintRequestAttributeSet();
				AttributeSet attributes = new HashPrintServiceAttributeSet(new PrinterName(printerName, Locale.getDefault()));
				PrintService[] services = PrintServiceLookup.lookupPrintServices(DocFlavor.SERVICE_FORMATTED.PRINTABLE, attributes);
				PrintService printService = null;
				for (int index = 0; printService == null && index < services.length; index++) {
					String checkPrinterName = services[index].getName();
					if (services[index].getName().equalsIgnoreCase(printerName)) {
						printService = services[index];
						break;
					}
				}
				job.setPrintService(printService);
//				PrintService printService = job.getPrintService();
				DocFlavor docType = DocFlavor.INPUT_STREAM.AUTOSENSE;
				DocPrintJob printJob = printService.createPrintJob();
				PrintingJobCompletionMonitor monitor = new PrintingJobCompletionMonitor();
				printJob.addPrintJobListener(monitor);
//				PrintService[] service = PrintServiceLookup.lookupPrintServices(docType, attr_set);
				byte[] byteStream = Base64.getDecoder().decode(doc);
				Doc documentToBePrinted = new SimpleDoc(new ByteArrayInputStream(byteStream), docType, null);
				printJob.print(documentToBePrinted, attr_set);
				monitor.waitForJobCompletion();
				i$body.addProperty("printingInitiated", "success");
				i$body.remove("FileContent");
				i$body.remove("FileUrlId");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PRINTING SUCCESSFULLY INITIATED ");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID FILETOKEN");
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, i$ResM.getMsgtext(dwnldDmsFile));
				return isonMsg;
			}
		} catch (Exception e) {
			i$body.addProperty("printingInitiated", "failed");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "PRINTING FAILED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
	}
	//#PKY00080 ends
}

//#00000001 Ends
