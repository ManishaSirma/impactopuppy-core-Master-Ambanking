/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |3.2.2.443   | Hasan 		| Jan 31, 2020 | #HASAN001   | Initial writing	
      |3.2.2.443   | MAQ 		| May 17, 2021 | #MAQ00112   | Giga blast changes	
      |3.2.2.443   | Tarun      | May 28, 2021 | #TKS00001   | removed entire search method and added code to remove lines from wiki search
      |3.2.2.443   | Pappu      | Nov 24, 2021 | #PKY00064   | handled websearch for dilisense json data
      ----------------------------------------------------------------------------------------------
#HASAN001 Starts
*/
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Iterator;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;
import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;


public class IWebSearchController {
    private static final String JsonObject = null;
	private DBController db$Ctrl = new DBController();
    private Ioutils I$utils = new Ioutils();
    private ImpactoUtil i$impactoUtil = new ImpactoUtil();
    private IResManipulator i$ResM = new IResManipulator();
    private Logger logger = LoggerFactory.getLogger(IWiKiController.class);
    private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
    private ISdnScanWorker i$sdnScanWorker = new ISdnScanWorker();
    private ImpactoUtil I$Imputils = new ImpactoUtil();

    public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
        try {
            String SOpr = i$ResM.getOpr(isonMsg);
            String Scr = i$ResM.getScreenID(isonMsg);
            JsonObject i$body = new JsonObject();

            if (I$utils.$iStrFuzzyMatch(Scr, "OB2WIKIS") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
                isonMsg = doWebsearch(isonMsg, "WikiSearch");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2WIKIS") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
                //isonMsg = webQuery(isonMsg,"ICOR_M_WIKI_SCAN");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2DDGOS") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
                isonMsg = doWebsearch(isonMsg, "duckDuckGoSearch");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2DDGOS") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
                //isonMsg = webQuery(isonMsg,"ICOR_M_DUCKDUCKGO_SCAN");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2GIGAB") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
                isonMsg = doWebsearch(isonMsg, "gigabLastGoSearch");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2GIGAB") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
                //isonMsg = webQuery(isonMsg,"ICOR_M_GIGABLAST_SCAN");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2EWEBS") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
                isonMsg = doWebsearch(isonMsg, "entireWebSearch");
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2EWEBS") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
                //isonMsg = webQuery(isonMsg,"ICOR_M_ENTIREWEB_SCAN");
            } else {
                isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPERATION");
            }
        } catch (Exception e) {
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
            e.printStackTrace();
            return isonMsg;
        }
        return isonMsg;
    }

    private JsonObject webQuery(JsonObject isonMsg, String collName) {
        JsonObject icorMRisk = new JsonObject();
        JsonObject filter = new JsonObject();
        try {

            String ScanId = i$ResM.getBodyElementS(isonMsg, "ScanId");
            filter.addProperty("ScanId", ScanId);

            icorMRisk = db$Ctrl.db$GetRow(collName, filter);

            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorMRisk);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
        } catch (Exception e) {
            e.printStackTrace();
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
        }

        return isonMsg;
    }

    private JsonObject doWebsearch(JsonObject isonMsg, String typeOfSearch) {
        JsonObject argJson = new JsonObject();

        try {
            String key = i$ResM.getBodyElementS(isonMsg, "key");
            argJson.addProperty("searchKey", key);
            argJson.addProperty("trnCd", typeOfSearch);
            JsonObject i$webRes = processToWebSearch(argJson);
            JsonObject i$webStat = i$ResM.getiStat(i$webRes);
            i$webRes.remove("i-stat").getAsJsonObject();
            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$webRes);
            isonMsg.add("i-stat", i$webStat);
        } catch (Exception e) {
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WEB SEARCH FAILED", e.getMessage());
        }

        return isonMsg;
    }

    public void doWebsearch(JsonObject argJson) {

        JsonObject isonMsg = new JsonObject();
        JsonObject filter = new JsonObject();
        JsonObject icorMSdn = new JsonObject();
        try {
            String searchKey = argJson.get("searchKey").getAsString();
            String tpeOfWebSearch = argJson.get("trnCd").getAsString();
            String uniqueScanId = argJson.get("uniqueScanId").getAsString();
            String webScan = argJson.get("webScan").getAsString();
            String applicationId = argJson.get("applicationId").getAsString();
            isonMsg = processToWebSearch(argJson);
            if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "WikiSearch")) {
                icorMSdn.add(webScan + "." + "wikiHits", isonMsg);
            } else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "duckDuckGoSearch")) {
                icorMSdn.add(webScan + "." + "duckDuckGo", isonMsg);
            } else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "gigabLastGoSearch")) {
                icorMSdn.add(webScan + "." + "gigabHits", isonMsg);
            }else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "diliSdnScan")) { //#PKY00064 changes
                icorMSdn.add(webScan + "." + "diliScanHits", isonMsg);
            }
          //#TKS00001 starts
//            else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "entireWebSearch")) {
//                icorMSdn.add(webScan + "." + "entireWebHits", isonMsg);
//            }
          //#TKS00001 ends
            filter.addProperty("applicationId", applicationId);
            filter.addProperty("ScanId", uniqueScanId);
            db$Ctrl.db$UpdateRow("ICOR_M_SDN_SCAN", icorMSdn, filter, "true");
        } catch (Exception e) {
            e.printStackTrace();
            logger.debug("Error : Fail To Scan The Web");
        }
    }

    private JsonObject processToWebSearch(JsonObject searchData) {
        JsonObject argJson = new JsonObject();
        JsonObject filter = new JsonObject();
        String extUrl = "";
        String reqBody = "";
        String resBody = "";
        JsonObject JResp = new JsonObject();
        JsonArray blackListWords = new JsonArray();
        String key = searchData.get("searchKey").getAsString();
        String tpeOfWebSearch = searchData.get("trnCd").getAsString();
        try {
            if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "WikiSearch")) {
                filter.addProperty("trnCd", tpeOfWebSearch);
            } else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "duckDuckGoSearch")) {
                filter.addProperty("trnCd", tpeOfWebSearch);
            } else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "gigabLastGoSearch")) {
                filter.addProperty("trnCd", tpeOfWebSearch);
            }else if(I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "diliSdnScan")) {   //#PKY00064 changes
            	return diliSdnScan(searchData);
            }
          //#TKS00001 starts
//            else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "entireWebSearch")) {
//                filter.addProperty("trnCd", tpeOfWebSearch);
//            }
          //#TKS00001 ends
            argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
            argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
            argJson.add("reqBody", new JsonObject()); // #MAQ00112
            extUrl = argJson.get("extUrl").getAsString();            
            extUrl = extUrl.replaceAll("###IMP1###key###IMP2###", key);
            argJson.addProperty("extUrl", extUrl);
            JResp = I$EWSLnchr.ILaunchReq(argJson);
            // #MAQ00112 starts
            if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "gigabLastGoSearch")) {
            	 Document html = Jsoup.parse(JResp.get("resBody").getAsString());
                 String htmlBody = html.toString();
                 htmlBody = htmlBody.replace("&amp;", "&");
                 String rand = htmlBody.split("rand=")[1].substring(0, 15);
              	 String uxrl = htmlBody.split("uxrl=uxrl")[1].substring(2, 7);
                 extUrl = extUrl + "&rand=" + rand + uxrl;
	             	System.out.println(rand);
	             	System.out.println(uxrl);
            	argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());                
                argJson.add("reqBody", new JsonObject());          
               
                argJson.addProperty("extUrl", extUrl);
                JResp = I$EWSLnchr.ILaunchReq(argJson);
            }
            // #MAQ00112 ends
            filter = new JsonObject();
            filter.addProperty("PARAM", "BlackListWords");
            blackListWords = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");
            resBody = JResp.get("resBody").getAsString();
        } catch (Exception e) {
            // TODO: handle exception
        }


        return callTypeOfWebSearch(resBody, blackListWords, key, tpeOfWebSearch);
    }


    private JsonObject callTypeOfWebSearch(String resBody, JsonArray blackListWords, String key, String tpeOfWebSearch) {
        JsonObject isonMsg = new JsonObject();
        try {
            if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "WikiSearch")) {
                isonMsg = doWikiSearch(resBody, blackListWords);
            } else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "duckDuckGoSearch")) {
                isonMsg = doDuckDuckGoSearch(resBody, blackListWords);
            } else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "gigabLastGoSearch")) {
                isonMsg = dogigabLastSearch(resBody, blackListWords, key);
            } 
          //#TKS00001 starts
//            else if (I$utils.$iStrFuzzyMatch(tpeOfWebSearch, "entireWebSearch")) {
//                isonMsg = doEntireWebSearch(resBody, blackListWords, key);
//            }
          //#TKS00001 ends
        } catch (Exception e) {
            e.printStackTrace();
        }

        return isonMsg;
    }

    //Wiki search start from here   
    private JsonObject doWikiSearch(String resBody, JsonArray blackListWords) {
        JsonParser parser = new JsonParser();
        JsonArray hits = new JsonArray();
        JsonObject isonMsg = new JsonObject();
        JsonObject filter = new JsonObject();
        JsonObject icorMSdn = new JsonObject();
        try {
            JsonObject query = parser.parse(resBody).getAsJsonObject().get("query").getAsJsonObject();
            JsonObject pages = query.get("pages").getAsJsonObject();
            String key = pages.keySet().toArray()[0].toString();
            JsonObject respObj = pages.get(key).getAsJsonObject();
            if (respObj.has("extract")) {
                for (int i = 0; i < blackListWords.size() && hits.size() < 3; i++) {
                    // Do Fuzzy Wuzzy 
                    JsonObject i$runningBlkList = blackListWords.get(i).getAsJsonObject();
                    JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(i$runningBlkList.get("key").getAsString(), respObj.get("extract").getAsString(), i$runningBlkList.get("cutOff").getAsDouble()); // add to
                    if (searchHits.getAsJsonArray("hits").size() > 0) {
                        // Once found, build the list
                        JsonObject i$runningObj = new JsonObject();
                        i$runningObj.addProperty("name", respObj.get("title").getAsString());
                        //#TKS00001 starts
                        String details = respObj.get("extract").getAsString();
                        try {
                        	details = details.substring(0,200).concat("...");
                        }catch(Exception e) {}
                        //#TKS00001 ends
                        i$runningObj.addProperty("detail", details);
                        i$runningObj.addProperty("reference", "https://en.wikipedia.org/?curid=" + key);
                        hits.add(i$runningObj);
                    }
                }
            }
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg.add("hits", hits);
            db$Ctrl.db$InsertRow("ICOR_M_WIKI_SCAN", isonMsg);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "WIKI SEARCH COMPLETED");
        } catch (Exception e) {
            e.printStackTrace();
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "WIKI SEARCH FAILED", e.getMessage());
        }
        return isonMsg;
    }

    //Duckduckgo search start from here     
    public JsonObject doDuckDuckGoSearch(String resBody, JsonArray blackListWords) {
        JsonParser parser = new JsonParser();
        JsonArray hits = new JsonArray();
        JsonObject isonMsg = new JsonObject();
        JsonObject filter = new JsonObject();
        JsonObject icorMSdn = new JsonObject();
        try {
            JsonObject jsonObject = parser.parse(resBody).getAsJsonObject();
            if (!I$utils.$iStrFuzzyMatch(jsonObject.get("Abstract").getAsString(), "")) {
                for (int i = 0; i < blackListWords.size() && hits.size() < 3; i++) {
                    // Do Fuzzy Wuzzy 
                    JsonObject i$runningBlkList = blackListWords.get(i).getAsJsonObject();
                    JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(i$runningBlkList.get("key").getAsString(), jsonObject.get("Abstract").getAsString(), i$runningBlkList.get("cutOff").getAsDouble()); // add to
                    if (searchHits.getAsJsonArray("hits").size() > 0) {
                        // Once found, build the list
                        JsonObject i$runningObj = new JsonObject();
                        i$runningObj.addProperty("name", jsonObject.get("Heading").getAsString());
                        i$runningObj.addProperty("detail", jsonObject.get("Abstract").getAsString());
                        i$runningObj.addProperty("reference", jsonObject.get("AbstractURL").getAsString());
                        // i$runningObj.addProperty("Found As", i$runningBlkList.get("key").getAsString());
                        hits.add(i$runningObj);
                    }
                }
            }
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg.add("hits", hits);
            db$Ctrl.db$InsertRow("ICOR_M_DUCKDUCKGO_SCAN", isonMsg);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DUCKDUCKGO SEARCH COMPLETED");
        } catch (Exception e) {
            e.printStackTrace();
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "DUCKDUCKGO SEARCH FAILED", e.getMessage());
        }
        return isonMsg;
    }

    //Gigiablast search start from here     
    private JsonObject dogigabLastSearch(String resBody, JsonArray blackListWords, String key) {
        JsonParser parser = new JsonParser();
        JsonArray hits = new JsonArray();
        JsonObject isonMsg = new JsonObject();
        JsonObject filter = new JsonObject();
        JsonObject icorMSdn = new JsonObject();
        try {
            JsonObject resJsonObj = parser.parse(resBody).getAsJsonObject();
            JsonArray resJsonArr = resJsonObj.get("results").getAsJsonArray();

            if (resJsonArr.size() > 0) {
                try {
                    for (int i = 0; i < blackListWords.size(); i++) {
                        // Do Fuzzy Wuzzy                   
                        JsonObject i$runningBlkList = blackListWords.get(i).getAsJsonObject();
                        for (int j = 0; j < resJsonArr.size() && hits.size() < 3; j++) { // #MAQ00112
                            JsonObject jsonTemp = resJsonArr.get(j).getAsJsonObject();
                            JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(i$runningBlkList.get("key").getAsString(), jsonTemp.get("sum").getAsString(), i$runningBlkList.get("cutOff").getAsDouble()); // add to                     
                            if (searchHits.getAsJsonArray("hits").size() > 0) {
                                // Once found, build the list
                                JsonObject i$runningObj = new JsonObject();
                                //                                  i$runningObj.addProperty("name", queryJson.get("originalQuery").getAsString());
                                i$runningObj.addProperty("name", key);
                                //  i$runningObj.addProperty("title", jsonTemp.get("title").getAsString());
                                i$runningObj.addProperty("detail", jsonTemp.get("sum").getAsString());
                                i$runningObj.addProperty("reference", jsonTemp.get("url").getAsString());
                                hits.add(i$runningObj);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg.add("hits", hits);
            db$Ctrl.db$InsertRow("ICOR_M_GIGABLAST_SCAN", isonMsg);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "GIGABLAST SEARCH COMPLETED");
        } catch (Exception e) {
            e.printStackTrace();
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "GIGABLAST SEARCH FAILED", e.getMessage());
        }
        return isonMsg;
    }
  //#TKS00001 starts
    //Entireweb search start from here        
//    private JsonObject doEntireWebSearch(String resBody, JsonArray blackListWords, String key) {
//        JsonParser parser = new JsonParser();
//        JsonArray hits = new JsonArray();
//        JsonObject isonMsg = new JsonObject();
//        JsonObject filter = new JsonObject();
//        JsonObject icorMSdn = new JsonObject();
//        JsonArray headersArr = new JsonArray();
//        try {
//            Document html = Jsoup.parse(resBody);
//            Elements elements = html.select("div.site-result");
//            headersArr = getTheContent(elements);
//            if (headersArr != null) {
//                try {
//                    if (!(headersArr.size() == 0)) {
//                        for (int i = 0; i < blackListWords.size(); i++) {
//                            // Do Fuzzy Wuzzy
//                            JsonObject i$runningBlkList = blackListWords.get(i).getAsJsonObject();
//                            for (int j = 0; j < headersArr.size() && hits.size() < 3; j++) {
//                                JsonObject jsonTemp = headersArr.get(j).getAsJsonObject();
//                                JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(i$runningBlkList.get("key").getAsString(), jsonTemp.get("Desc").getAsString(), i$runningBlkList.get("cutOff").getAsDouble());
//                                if (searchHits.getAsJsonArray("hits").size() > 0) {
//                                    // Once found, build the list
//                                    JsonObject i$runningObj = new JsonObject();
//                                    i$runningObj.addProperty("name", key);
//                                    //i$runningObj.addProperty("title", jsonTemp.get("title").getAsString());
//                                    i$runningObj.addProperty("detail", jsonTemp.get("Desc").getAsString());
//                                    i$runningObj.addProperty("reference", jsonTemp.get("url").getAsString());
//                                    hits.add(i$runningObj);
//                                }
//                            }
//                        }
//                    }
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//            }
//            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
//            isonMsg.add("hits", hits);
//            db$Ctrl.db$InsertRow("ICOR_M_ENTIREWEB_SCAN", isonMsg);
//            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ENTIREWEB SEARCH COMPLETED");
//        } catch (Exception e) {
//            e.printStackTrace();
//            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
//            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ENTIREWEB SEARCH FAILED", e.getMessage());
//        }
//        return isonMsg;
//    }
  //#TKS00001 ends
    public JsonArray getTheContent(Elements elements) {
        JsonArray headersArr = new JsonArray();
        try {
            for (Element header: elements) {
                JsonObject contentBody = new JsonObject();
                Elements site$Title = header.select("div.site-title");
                site$Title = site$Title.select("a");
                Elements site$Desc = header.select("div.site-description");
                Elements site$Url = header.select("div.site-url");
                site$Url = site$Url.select("a");
                contentBody.addProperty("title", site$Title.text());
                contentBody.addProperty("Desc", site$Desc.text());
                contentBody.addProperty("url", site$Url.text());
                headersArr.add(contentBody);
                if (headersArr.size() == 3) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.debug(e.toString());
            return null;
        }
        return headersArr;
    }
    //#PKY00064 starts
    private JsonObject diliSdnScan(JsonObject argJson) {
        JsonArray hits = new JsonArray();
        JsonObject isonMsg = new JsonObject();
        try {
            String value = argJson.get("searchKey").getAsString();
            String key = argJson.get("fieldName").getAsString();
            if (key.equalsIgnoreCase("FullName")) {
                key = "name";
            } else if (key.equalsIgnoreCase("FName")) {
                key = "givenNames";
            } else if (key.equalsIgnoreCase("LName")) {
                key = "lastNames";
            }
            String filter = "{" + key + ": {'$regex': '" + value + "','$options': 'i' } }";
            JsonObject Json$DbDetails = db$Ctrl.db$GetRows("ICOR_M_SDN_DETAILS_JSON", filter, 0, 3);
            JsonArray icorJsonDetails = Json$DbDetails.get("i-body").getAsJsonArray();
            for (int i = 0; i < icorJsonDetails.size(); i++) {
                try {
                    double cutOff = 0.4;
                    JsonObject json$DbData = icorJsonDetails.get(i).getAsJsonObject();
                    json$DbData.remove("_id");
                    Set < String > keys = json$DbData.keySet();
                    String sumOfValue = "";
                    for (String res: keys) {
                        sumOfValue = sumOfValue.concat(I$utils.fecthValue$FormJson(json$DbData, res, ""));
                        sumOfValue = sumOfValue.concat("\n");
                    }
                    if (json$DbData.has("sourceId")) {
                        String sourceId = json$DbData.get("sourceId").getAsString().toUpperCase().replace("_", " ");
                        json$DbData.addProperty("sourceId", sourceId);
                    }
                    JsonObject json$DbDetails =  json$DbData.deepCopy();
                    json$DbDetails.remove("links");
                    String sum = json$DbDetails.toString();
                    String ScanCriteria = argJson.get("fieldName").getAsString();
                    if (I$utils.$iStrFuzzyMatch(ScanCriteria, "FullName")) {
                        cutOff = 1;
                    }
                    JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(value, sumOfValue, cutOff); // add to      
                    if (searchHits.get("score").getAsInt() >= 80) {
                        JsonObject i$runningObj = new JsonObject();
                        i$runningObj.addProperty("name", value);
                        i$runningObj.addProperty("detail", sum);
                        if (json$DbData.has("links")) {
                            i$runningObj.addProperty("reference", json$DbData.get("links").getAsString());
                        }
                        hits.add(i$runningObj);
                    }
                } catch (Exception e) {

                }
            }
        } catch (Exception e) {

        }
        isonMsg.addProperty("ScanId", argJson.get("uniqueScanId").getAsString());
        isonMsg.add("hits", hits);
        db$Ctrl.db$InsertRow("ICOR_M_DILISENSE_SCAN", isonMsg);
        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DILISENSE SEARCH COMPLETED");
        return isonMsg;
    }
    //#PKY00064 ENDS
    public IWebSearchController() {
        // Cons
    }
}
//#HASAN001 Ends