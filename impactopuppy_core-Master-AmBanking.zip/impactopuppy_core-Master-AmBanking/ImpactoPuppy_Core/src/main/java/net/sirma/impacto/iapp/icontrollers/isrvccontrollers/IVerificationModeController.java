/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Pruthvi 	| Feb 9, 2021  | #YPR00048   | Initial writing
      |0.1 Beta    | Pruthvi 	| Feb 9, 2021  | #YPR00048   | Added verification mode change functionality
      |0.1 Beta    | Pruthvi 	| Feb 17,2021  | #YPR00051   | Updating of Verification results into application.
      |0.1 Beta    | Pruthvi 	| Mar 03,2021  | #YPR00054   | Added Verify Application Operation form Smartphone.
      |0.1 Beta    | Pruthvi 	| Mar 06,2021  | #YPR00055   | Added Termination of Application for Tests Failed Appls.
      |0.1 Beta    | Pruthvi 	| Mar 11,2021  | #YPR00059   | Updating DocumentDetails from verify stage.
      |0.1 Beta    | Syed 	    | Mar 11,2021  | #MAQ00104   | Handled Retry for failed Appls
      |0.1 Beta    | Devraj     | Mar 18,2021  | #DVJ00045   | Added the status of payment receipt in InitialDeposit stage
      |0.1 Beta    | Pruthvi    | Mar 22,2021  | #YPR00061   | Added Documents updation in OSV stage
      |0.3 Beta    | Pruthvi    | Apr 15,2021  | #YPR00073   | Added Payment deposit success notification changes
      |0.3 Beta    | Pappu      | Apr 17,2021  | #PKY00009   | Added code for online verification notification.
      |2.1 Beta    | Pappu      | Apr 27,2021  | #PKY00010   | Added new service for verification mode
      |2.1 Beta    | Pruthvi    | May 25,2021  | #YPR00081   | Added JobSrvc for Holding applications
      |0.4 Beta    | Pruthvi    | Jun 08,2021  | #YPR00085   | Added Smartphone Verification field changes
      |0.4 Beta    | Sindhu     | Sep 27,2023  | #SRM00060   | Added initial deposit and OSV deposit stage changes
      ----------------------------------------------------------------------------------------------
      
*/
// #YPR00048 Begins

package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IVerificationModeController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;
public class IVerificationModeController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	
	private DBController db$Ctrl = new DBController();
	private OtpController i$otpC = new OtpController();
	private static final Logger logger = LoggerFactory.getLogger(IVerificationModeController.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private OtpController i$otp = new OtpController();   //PKY00009 changes
	
	// **********************************************************************//

	
	
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SvrOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SvrOpr, "switchVMode")) {
				isonMsg = switchVerfMode(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(SvrOpr, "upVerfRslts")) {
				isonMsg = updteVerfStats(isonMsg, isonheader, isonMapJson);
			}else if (I$utils.$iStrFuzzyMatch(SvrOpr, "trmnateFailAppl")) {
				isonMsg = terminateAppl(isonMsg);
			}// #DVJ00045 Starts
			else if (I$utils.$iStrFuzzyMatch(SvrName, "PAYMENT_RECEIPT")) {
				isonMsg = updatePaymentStatus(isonMsg, isonheader, isonMapJson);
			}// #DVJ00045 Ends
			else if (I$utils.$iStrFuzzyMatch(SvrName, "OSVDOCOPS")&&I$utils.$iStrFuzzyMatch(SvrOpr, "updateosvdocs")) {
				isonMsg = updateOSVDocs(isonMsg); //#YPR00061 changes
			}//PKY00010 Starts
			else if (I$utils.$iStrFuzzyMatch(SvrOpr, "checkVMode")) {
				isonMsg = checkVerfMode(isonMsg);
			}//PKY00010 Ends
			else if (I$utils.$iStrFuzzyMatch(SvrName, "AUTO_HOLD")&&I$utils.$iStrFuzzyMatch(SvrOpr, "holdApplncs")) {
				isonMsg = autoHoldApplns(isonMsg); //#YPR00080 changes
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}
	//PKY00010 Starts
	public JsonObject checkVerfMode(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		int  Doc$Count = 0;
		
		try {
			String applicationId =isonMsg.getAsJsonObject("i-body").get("applicationId").getAsString();
			
				filter.addProperty("applicationId",applicationId );
				filter.addProperty("verificationMode","Smartphone" );
				filter.addProperty("smartphoneVerification","Pending" ); // #YPR00085 Changes
				filter.addProperty("WorkFlowStatus","VERIFY APPLICATION" );
				Doc$Count = db$Ctrl.db$GetCountI("ICOR_C_B2U_CIF_APPLICATION",filter);
				if(Doc$Count > 0) {
			        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Continue to verify your application");
				}
				else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please visit branch to verify your application");
				}
		}catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation not allowed");
			e.printStackTrace();
		}
		return isonMsg;
	}
	//PKY00010 Ends
	
	public JsonObject switchVerfMode(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		Gson gson = new Gson();
		try {
			filter.addProperty("applicationId", isonMsg.getAsJsonObject("i-body").get("applicationId").getAsString());
			JsonObject lRemarks = new JsonObject();
			lRemarks.addProperty("Action","QE#INIT");
			lRemarks.addProperty("Remarks","Switched verificationMode to Visit Branch");
			lRemarks.addProperty("Current Queue","QE#INIT");
			lRemarks.addProperty("Date",i$ResM.getdateTime(new Date()));
			String i$Doc =  "{ 'verificationMode': 'Visit Branch'}";
			
			String i$DocA = "{'WorkFlowLatestRemarks':"+gson.toJson(lRemarks)+"}";
            db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION",i$Doc,filter);
            db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_CIF_APPLICATION", i$DocA, filter, "false", "push");
            
            i$DocA = "{'latestRemarks':"+gson.toJson(lRemarks)+"}";			
            db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS",i$Doc,filter);
			db$Ctrl.db$UpdateRowOperator("ICOR_IBM_PROCESS", i$DocA, filter, "true", "push");

			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PLEASE VISIT BRANCH TO VERIFY YOUR APPLICATION");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}
	
	//#YPR00051 Starts
	public JsonObject updteVerfStats(JsonObject isonMsg,JsonObject isonheader,JsonObject isonMapJson ) {
		JsonObject filter = new JsonObject();
		JsonObject i$Doc = new JsonObject();
		JsonObject i$body = i$ResM.getBody(isonMsg);
		Gson gson = new Gson();
		// #MAQ00104 starts
		Integer RetryCnt = 0;
		Boolean veriSuccess = false;
		// #MAQ00104 ends

		try {			
			filter.addProperty("applicationId", i$body.get("applicationId").getAsString());
			i$Doc.add("verificationResults", i$body.get("verificationResults").getAsJsonObject());
			// #MAQ00104 starts
            db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS",i$Doc,filter);  
			try {
				JsonObject m$x = db$Ctrl.db$GetTopRow("ICOR_C_B2U_CIF_APPLICATION", filter, "RetryCnt");				
				RetryCnt = db$Ctrl.db$GetColI(m$x, "RetryCnt");
				i$Doc.addProperty("RetryCnt", RetryCnt + 1);				
			} catch (Exception e) {
			}
			// #MAQ00104 ends
            db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION",i$Doc,filter);

            //#YPR00054 Starts
    		// #MAQ00104 starts
            try {
			if(I$utils.$iStrFuzzyMatch(i$body.get("verificationResults").getAsJsonObject().get("verificationResult").getAsString(), "Success")) 
				veriSuccess = true;
            } catch(Exception e) {}	
            
            if(veriSuccess) {
            	if(i$body.has("documents")) { //#YPR00059 Starts
	    		    String documentDetails = gson.toJson(i$body.get("documents").getAsJsonObject().get("documentDetails").getAsJsonArray());
	    		    String i$DocS = "{'documents.documentDetails':{'$each':   " + documentDetails + "   }}";
	    		
	    			db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_CIF_APPLICATION",i$DocS,filter,"false","addtoSet");
                }//#YPR00059 Ends
        		// #MAQ00104 ends
            	//#YPR00085 Starts
            	i$Doc = new JsonObject();
            	i$Doc.addProperty("smartphoneVerification","Completed");
            	
            	db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS",i$Doc,filter);
            	db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION",i$Doc,filter); //#YPR00085 Ends
//				ExecutorService executor = Executors.newFixedThreadPool(1);// creating a pool of threads
//				for (int i = 0; i < 1; i++) {
//					Runnable worker = new imbpmFwdThread(isonMsg, isonheader, isonMapJson);
//					executor.execute(worker);// calling execute method of ExecutorService
//				}
				
				i$otp.sendNotificFN(i$body,"TMPL#TT#SUCCESS#NOTIFICATION#MAIL");   //PKY00009 changes
//				logger.debug("Finished all threads");

				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
			}else {
				// #MAQ00104 starts
				if(RetryCnt>=2) {
					switchVerfMode(isonMsg);
					i$otp.sendNotificFN(i$body,"TMPL#TT#FAILED#NOTIFICATION#MAIL"); //PKY00009  changes
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Retry Verification or Switch to Visit Branch Verification");
				}
				// #MAQ00104 ends
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}

	//#YPR00051 Ends
	
	//#YPR00055 Starts
	public JsonObject terminateAppl(JsonObject isonMsg) {
		JsonObject appln$Json = new JsonObject();
		JsonObject $tsk$Filter = new JsonObject();
		try {			

			$tsk$Filter.addProperty("applicationId", isonMsg.getAsJsonObject("i-body").get("applicationId").getAsString());
			$tsk$Filter.addProperty("referenceNo", isonMsg.getAsJsonObject("i-body").get("referenceNo").getAsString());
			
			if(!I$utils.$iStrFuzzyMatch(db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", $tsk$Filter).get("verificationResults").getAsJsonObject().get("verificationResult").getAsString(), "Success")) {
			appln$Json.addProperty("Queue", "QE#DLQ");
			appln$Json.addProperty("CurrentTask", "TERMINATE");
			appln$Json.addProperty("CurrentTskStage", "2");
			appln$Json.addProperty("CurrentStageName", "TERMINATE");
			appln$Json.addProperty("NxtTskStage", "3");
			appln$Json.addProperty("PreTskStage", "1");
			appln$Json.addProperty("NewTskStage", "100");
			appln$Json.addProperty("TerminatedBy", "dvotr@sirmaindia.com");
			appln$Json.addProperty("isCurrVer", "Y");
			appln$Json.addProperty("O_Id", "NULL");
			appln$Json.addProperty("latestRemarks", "Failed in Verification Tests..Terminated");
			appln$Json.addProperty("remarks", "Failed in Verification Tests..Terminated");
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", appln$Json, $tsk$Filter,"true");
			
			
			JsonObject app$Json = new JsonObject();
			app$Json.addProperty("RecordStat", "T_TERMINATE");
			app$Json.addProperty("WorkFlowStatus","TERMINATE");
			app$Json.addProperty("WorkFlowRemarks", "Failed in Verification Tests..Terminated");
			app$Json.addProperty("WorkFlowLatestRemarks", "Failed in Verification Tests..Terminated");
			appln$Json.addProperty("TerminatedBy", "dvotr@sirmaindia.com");
			app$Json.addProperty("isCurrVer", "Y");
			
			db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION", app$Json, $tsk$Filter,"true");
			
			$tsk$Filter.addProperty("CurrentStageName", "TERMINATE");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, $tsk$Filter);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION TERMINATED SUCCESSFULLY");
			}else {
			 isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
			
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}
	//#YPR00055 Ends
	
	//#YPR00081 Starts
	private JsonObject autoHoldApplns(JsonObject isonMsg) {
	
		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
		int holdApplicationInDays = cParam.get("holdApplicationInDays").getAsInt();
		try {
			JsonArray iSetterData = new JsonArray();
			JsonObject Qfilter = new JsonObject();
			JsonObject projection = new JsonObject();
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonParser parser = new JsonParser();
			Date modDate = I$utils.changeDate(holdApplicationInDays, "SUB", "D");
//			Date lsrDate = I$utils.changeDate(holdApplicationInDays - 1, "SUB", "D");
			String modDateS = I$utils.changeDateFormat(modDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//			String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//			JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
			JsonObject temp = new JsonObject();
//			temp.add("$gte", iso$date);
//			Qfilter.add("ModifiedAt", temp);
			JsonObject iso$date = Ioutils.dateFromatter(modDateS);
			temp.add("$lt", iso$date);
			Qfilter.add("ModifiedAt", temp);
			Qfilter.add("CurrentStageName", parser.parse("{$in:['INITIATION','VERIFY APPLICATION','APPROVE APPLICATION','OSV APPLICATION','INITIAL DEPOSIT APPLICATION']}").getAsJsonObject());
			Qfilter.addProperty("isCurrVer", "Y");
			projection.addProperty("applicationId", 1);
			projection.addProperty("ModifiedAt", 1);
			projection.addProperty("_id", 0);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_IBM_PROCESS", Qfilter, projection);
			JsonArray app$JsonArr = new JsonArray();
			for(int i=0;i<i$Body.size();i++) {
				try {
				 app$JsonArr.add(i$Body.get(i).getAsJsonObject().get("applicationId").getAsString());
				}catch(Exception e) {}
			}

			try {

				JsonObject appln$Json = new JsonObject();
				appln$Json.addProperty("Queue", IResManipulator.iloggedUser.get());
				appln$Json.addProperty("CurrentTask", "HOLD");
				appln$Json.addProperty("CurrentStageName", "APPLICATION HOLD");
				appln$Json.addProperty("isCurrVer", "Y");
				appln$Json.addProperty("O_Id", "NULL");
//			appln$Json.addProperty("latestRemarks", "Auto Terminated");
				appln$Json.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
				appln$Json.addProperty("HeldBy", IResManipulator.iloggedUser.get());
				iSetterData.add(appln$Json);

				JsonArray IFilter = new JsonArray();
				IFilter.add(Qfilter);

				db$Ctrl.db$UpdateMany("ICOR_IBM_PROCESS", iSetterData, IFilter, "true");

				JsonObject app$Json = new JsonObject();
				iSetterData = new JsonArray();

				app$Json.addProperty("RecordStat", "H_HOLD");
				app$Json.addProperty("WorkFlowStatus", "APPLICATION HOLD");

				Qfilter = new JsonObject();
				IFilter = new JsonArray();
				String applcs = "{'$in':   " + gson.toJson(app$JsonArr) + "   }";
				Qfilter.add("applicationId",parser.parse(applcs).getAsJsonObject());
				IFilter.add(Qfilter);
				
				iSetterData.add(app$Json);

				db$Ctrl.db$UpdateMany("ICOR_C_B2U_CIF_APPLICATION", iSetterData, IFilter, "true");

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$Body);
				String suc$msg = "Job Executed Successfully";
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, suc$msg);

			} catch (Exception e) {
				logger.debug(e.getMessage().toString());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed To Execute");
				e.printStackTrace();
				return isonMsg;

			}
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed To Execute");
			e.printStackTrace();
			return isonMsg;

		}
	}
	//#YPR00081 Ends
	
	// #DVJ00045 Starts
	public JsonObject updatePaymentStatus(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject filter = new JsonObject();
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject up$status = new JsonObject();
		String SvrOpr = i$ResM.getSrvcopr(isonMsg);
		Gson gson = new Gson();
		try {

			filter.addProperty("applicationId", i$body.get("applicationId").getAsString());
			filter.addProperty("referenceNo", i$body.get("referenceNo").getAsString());
			filter.addProperty("isCurrVer", "Y");
			up$status.addProperty("paymentStatus", i$body.get("paymentStatus").getAsString());

			JsonObject appData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter);

			if (I$utils.$iStrFuzzyMatch(SvrOpr, "paymentReceived")) {
				if (!I$utils.$iStrFuzzyMatch(appData.get("paymentStatus").getAsString(), "Payment Received")) { // #YPR00073
																												// changes

					if (i$body.get("documents").getAsJsonObject().get("documentDetails").getAsJsonArray().size() > 0) {

						if (I$utils.$iStrFuzzyMatch(i$body.get("paymentStatus").getAsString(), "Payment Received")) {

							try {
								db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", up$status, filter);
								up$status.addProperty("paymentVia", i$body.get("paymentVia").getAsString()); // #YPR00062 Changes
								up$status.addProperty("paymentViaDesc", i$body.get("paymentViaDesc").getAsString()); // #YPR00062 Changes
								up$status.addProperty("initialDepositeAmount",i$body.get("initialDepositeAmount").getAsString());
								db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION", up$status, filter);
								// #YPR00059 Starts
								if (i$body.has("documents")) {
									String documentDetails = gson.toJson(i$body.get("documents").getAsJsonObject().get("documentDetails").getAsJsonArray());
									String i$Docs = "{ 'documents.documentDetails': { '$each': " + documentDetails+ "   }}";
									db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_CIF_APPLICATION", i$Docs, filter, "false","addtoSet");
								}
								// #YPR00059 Ends
								i$otpC.sendNotificFN(appData, "TMPL#TT#RECIVE#DDEPOST#RCPT"); // #YPR00073 changes
								return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Payment Updated Successfully");
							} catch (Exception e) {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update Payment");
							}

						} else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update Payment");
						}
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please upload Payment receipt");
					}
				} else {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Proof of deposit  has already been Updated");
				}
			} else {
				if (I$utils.$iStrFuzzyMatch(i$body.get("paymentStatus").getAsString(), "Payment Received")) {
					try {
						db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", up$status, filter);
						up$status.addProperty("paymentVia", i$body.get("paymentVia").getAsString());
						up$status.addProperty("paymentViaDesc", i$body.get("paymentViaDesc").getAsString());
						up$status.addProperty("initialDepositeAmount",i$body.get("initialDepositeAmount").getAsString());
						db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION", up$status, filter);
						// #YPR00059 Starts
						if (i$body.has("documents")) {
							String documentDetails = gson.toJson(i$body.get("documents").getAsJsonObject().get("documentDetails").getAsJsonArray());
							String i$Docs = "{ 'documents.documentDetails': { '$each': " + documentDetails + "   }}";
							db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_CIF_APPLICATION", i$Docs, filter, "false","addtoSet");
						}
						i$otpC.sendNotificFN(appData, "TMPL#TT#RECIVE#DDEPOST#RCPT");
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Payment Updated Successfully");
					} catch (Exception e) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update Payment");
					}
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update Payment");
				}
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Not Allowed");
			logger.debug(e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}
	// #DVJ00045 Ends
	
	// #YPR00061 Starts
	public JsonObject updateOSVDocs(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject up$status = new JsonObject();
		Gson gson = new Gson();
		try {

			filter.addProperty("applicationId", i$body.get("applicationId").getAsString());
			filter.addProperty("referenceNo", i$body.get("referenceNo").getAsString());
			filter.addProperty("isCurrVer", "Y");
			
			
			if(I$utils.$iStrFuzzyMatch(db$Ctrl.db$GetRow("ICOR_IBM_PROCESS",filter).get("CurrentStageName").getAsString(), "INITIAL DEPOSIT APPLICATION AND OSV")) {  // #SRM00060 changes

				if(i$body.has("documents")) {
					String documentDetails = gson.toJson(i$body.get("documents").getAsJsonObject().get("documentDetails").getAsJsonArray());
					String i$Docs = "{ 'documents.documentDetails': { '$each': " + documentDetails + "   }}";
					db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_CIF_APPLICATION", i$Docs, filter, "false", "addtoSet");
				}
				
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");

			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			logger.debug(e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}
	// #YPR00061 Ends
	
	// Threading for calling IMBPM Controller 
	class imbpmFwdThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject isonMapJson;
		JsonObject isonheader;

		public imbpmFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
			this.message = "RUN";
			this.iosnMsg = isonMsg;
			this.isonMapJson = isonMapJson;
			this.isonheader = isonheader;

		}

		public void run() {
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
			logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
			JsonObject i$res = mirrorController(iosnMsg, isonMapJson, isonheader);// call process message method that
																					// sleeps the
			// logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}

	}

	// #Va000029 change begins
	public JsonObject mirrorController(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

		try {
			JsonObject Jbdy = new JsonObject();
			JsonObject jBody = new JsonObject();
			jBody = i$ResM.getBody(isonMsg);
			String sRef = null;
			String Coll_Name = "";
			String DcStatus = null;
			String ScrCtrlClass = null;
			String sAppNumber = null;

			JsonObject jFilter = new JsonObject();
			JsonObject remarksObj = new JsonObject();
			JsonArray remarksArr = new JsonArray();
			

			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			remarksObj.addProperty("User", "dvotr@sirmaindia.com");
			remarksObj.addProperty("Current Queue", "QE#VERIFY");
			remarksObj.addProperty("Action", "ACCEPT");
			remarksObj.addProperty("Date", i$ResM.getdateTime(new Date()));
			remarksObj.addProperty("Remarks", "Verified from Applicaton");
			remarksArr.add(remarksObj);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId",
					"dvotr@sirmaindia.com");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
					"ACCEPT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
					"IMPACTO_CIF_WFLW_NEW");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
					"2");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "CurrentStageName",
					"VERIFY APPLICATION");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
					"XWFIMPWF");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
					"PROCESS_TASK");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
					"ACCEPT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "LatestRemarks",remarksArr);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			// Fwd the Control to Workflow COntroller.
			ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller";
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
				if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
				}
			} else {

				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				return isonMsg;
			}

		} catch (Exception e) {
			return null;
		}
	}

	// #Va000029 change ends

	public IVerificationModeController() {
		// constructor
	}

}
// #YPR00048 Ends