///*
//      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
//      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
//      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
//      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
//      take all reasonable precautions to protect the source code and documentation, and preserve its
//      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
//      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
//      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
//      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
//      and permanent injunctive relief in addition to such remedies as may otherwise be available.
// 
//      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
//      //We worked harder than all of them--yet not We, but the grace of God that was with us.
//      ----------------------------------------------------------------------------------------------
//      |Version No  | Changed by | Date         | Change Tag  | Changes Done
//      ----------------------------------------------------------------------------------------------
//      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
//      |0.1 Beta    | Vijay 		| Sep 27, 2018 | #BVB00002   | Encryption and Decryption
//      |0.1 Beta    | Vijay 		| Oct 30, 2018 | #BVB00009   | Temp FIX For disabling the JBPM 
//      ----------------------------------------------------------------------------------------------
//      
//*/
//// #00000001 Begins
////JBPM Configuration
//package net.sirma.impacto.iapp.iconfig;
//
//
//import org.kie.server.client.KieServicesClient;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//
//import net.sirma.impacto.iapp.JBPM.kieserver.ConnectionInitializer;
//import net.sirma.impacto.iapp.iutils.ImpactoUtil;
//
//@Configuration
//@PropertySource("classpath:application.properties")
//@ComponentScan("net.sirma.impacto.iapp")
//public class JBPMInit {
//
//    @Value("${jbpm.host}")
//    private String host;
//    
//    
//    @Value("${jbpm.user}")
//	private String user;
//    
//    @Value("${jbpm.password}")
//    private String password;
//    
//    public static KieServicesClient kieServicesClient;
//    @Bean
//    public KieServicesClient JBPMConnection() {
//    	
//    	//#BVB00002 Starts
//    	ImpactoUtil impactoUtil = new ImpactoUtil(); 
//    	user = impactoUtil.decrypt(user); 
//    	password = impactoUtil.decrypt(password);
//    	//#BVB00002 Ends    	
//    	
//    	
//    	// #BVB00009 Starts  
//    /*	kieServicesClient = ConnectionInitializer.getConnection(host, user, password);
//		
//		return kieServicesClient;*/
//    	return null; 
//    	
//    	// #BVB00009 Ends 
//    }
//  
//}
////#00000001 Ends