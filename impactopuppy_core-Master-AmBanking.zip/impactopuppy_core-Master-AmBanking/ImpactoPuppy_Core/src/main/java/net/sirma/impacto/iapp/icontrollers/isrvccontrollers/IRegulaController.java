/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Sep 27, 2018 | #BVB00003   | Captcha Service Property Implementation
      |0.1 Beta    | Valla 		| Dec 20, 2018 | #V0000004   | Captcha Service Property from Collection Implementation
      |0.1 Beta    | Niegil 	| feb 08, 2019 | #NYE00004   | Capthca ID Changes
      |0.3.6       | Vijay	 	| Apr 17, 2019 | #BVB00121   | Captcha ID Length now is 5. 
      |0.3.9       | Vijay	 	| May 20, 2019 | #BVB00152   | Captcha Id overflow fix. Revert of BVB00121
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.*;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IWiKiController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.*;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.Request.Builder;

public class IRegulaController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IRegulaController.class);
	private ImpactoUtil i$Outils = new ImpactoUtil(); // #NYE00004
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "getDocData")) {
				return getDocData(isonMsg);			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

	private JsonObject getDocData(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		String transactionId = "";
		String extUrl = "";
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson(); 
		JsonParser parser = new JsonParser(); 
		JsonObject i$res = new JsonObject(); 
		JsonArray hits = new JsonArray();
		JsonObject jOkHttp = new JsonObject();
		String resBody = ""; 		
		
		try {
			filter.addProperty("trnCd", "TransactionIDfromDocUpload");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
			argJson.addProperty("reqBody", gson.toJson(isonMsg.getAsJsonObject("i-body").get("imgData").getAsJsonArray()));
			isonMsg.getAsJsonObject("i-body").remove("imgData");
//			JResp = I$EWSLnchr.ILaunchReq(argJson);

			jOkHttp.addProperty("unqCommID", argJson.get("unqCommID").getAsString());

			
			OkHttpClient client = new OkHttpClient.Builder().connectTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
			        .readTimeout(120, TimeUnit.SECONDS).build();
			MediaType mediaType  = null; 
			try {
				mediaType = MediaType.parse(argJson.get("mediaType").getAsString());	
			} catch (Exception e) {
				 
			}
			
			RequestBody reqBody = null;			
			try {
				reqBody = RequestBody.create(mediaType,argJson.get("reqBody").getAsString());
			} catch (Exception Ex) {
				// No Body
				// reqBody = null;
				reqBody = RequestBody.create(null, new byte[0]);  
			}
			
			Builder ReqBldr = new Request.Builder();
			
			ReqBldr.url(argJson.get("extUrl").getAsString()); // #BVB00040
			
			ReqBldr.post(reqBody);
			// #BVB00132 Ends
			
			Request request = ReqBldr.build();
			Response response = client.newCall(request).execute();			
			resBody= response.body().string(); 		
			
			argJson = new JsonObject(); 
			reqBody = null;  
	        System.gc(); 
//			if (JResp.has("resBody") && !I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) {
			if (!I$utils.$iStrFuzzyMatch(resBody, "")) {
//				transactionId = JResp.get("resBody").getAsString();
				transactionId = resBody;
				try {
					filter.addProperty("trnCd", "TextFromTransactionID");
					argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
					argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
					argJson.add("reqBody", new JsonObject());
					extUrl = argJson.get("extUrl").getAsString();
					extUrl = extUrl.replaceAll("###IMP1###transactionId###IMP2###", transactionId);
					argJson.addProperty("extUrl", extUrl);
					JResp = I$EWSLnchr.ILaunchReq(argJson);
					if (!I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) { 
						String resp = JResp.get("resBody").getAsString();
						resp = resp.replace("\\\"","'");
						i$res.add("TextFromTransactionID", parser.parse(resp).getAsJsonArray());
						resp = null;
					} else { 
						i$res.add("TextFromTransactionID", new JsonArray());
					}
					System.gc(); 
				} catch (Exception e) {
					e.printStackTrace();
				}
				try {
					filter.addProperty("trnCd", "TextDocTypeFromTransactionID");
					argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
					argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
					argJson.add("reqBody", new JsonObject());
					extUrl = argJson.get("extUrl").getAsString();
					extUrl = extUrl.replaceAll("###IMP1###transactionId###IMP2###", transactionId);
					argJson.addProperty("extUrl", extUrl);
					JResp = I$EWSLnchr.ILaunchReq(argJson);
					if (!I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) { 
						String resp = JResp.get("resBody").getAsString();
						resp = resp.replace("\\\"","'");
						i$res.add("TextDocTypeFromTransactionID", parser.parse(resp).getAsJsonArray());
						resp = null;
					} else { 
						i$res.add("TextDocTypeFromTransactionID", new JsonArray());
					}			
				} catch (Exception e) {
					e.printStackTrace();
				}
				try {
					filter.addProperty("trnCd", "GraphicalResFromTransactionID");
					argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
					argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
					argJson.add("reqBody", new JsonObject());
					extUrl = argJson.get("extUrl").getAsString();
					extUrl = extUrl.replaceAll("###IMP1###transactionId###IMP2###", transactionId);
					argJson.addProperty("extUrl", extUrl);
					JResp = I$EWSLnchr.ILaunchReq(argJson);
					if (!I$utils.$iStrFuzzyMatch(JResp.get("resBody").getAsString(), "")) { 
						String resp = JResp.get("resBody").getAsString();
						resp = resp.replace("\\\"","'");
						i$res.add("GraphicalResFromTransactionID", parser.parse(resp).getAsJsonArray());
						resp = null;
					} else { 
						i$res.add("GraphicalResFromTransactionID", new JsonArray());
					}
					System.gc(); 				
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else { 
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "Something went wrong");
			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			return isonMsg;

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}

	};

}