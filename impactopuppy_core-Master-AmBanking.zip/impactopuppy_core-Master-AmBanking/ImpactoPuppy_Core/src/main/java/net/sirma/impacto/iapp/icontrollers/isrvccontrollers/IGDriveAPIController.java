/*
Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
Sirma Business Consulting India reserves all rights to this code . No part of this code should 
be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
take all reasonable precautions to protect the source code and documentation, and preserve its
confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
and permanent injunctive relief in addition to such remedies as may otherwise be available.

//But by the grace of God We are what we are, and his grace to us was not without effect. No, 
//We worked harder than all of them--yet not We, but the grace of God that was with us.
----------------------------------------------------------------------------------------------
|Version No  | Changed by | Date         | Change Tag  | Changes Done
----------------------------------------------------------------------------------------------
|0.5 Beta    | Pruthvi 	| Sept 07, 2021 | #YPR00106   | Initial writing
|0.5 Beta    | Pruthvi 	| Sept 08, 2021 | #YPR00106   | Added Changes to generate Gdrive Access token
|0.5 Beta    | Pruthvi 	| Sept 09, 2021 | #YPR00107   | Added Gdrive shared file data logging
|0.5 Beta    | Sushmita | Sept 07, 2021 | #SKP00001   | Added code for Upload a file to drive
|0.5 Beta    | Sushmita | Sept 08, 2021 | #SKP00002   | Added code for Set Permissions 
|0.5 Beta    | Sushmita | Sept 08, 2021 | #SKP00003   | Added code to get file download link
|0.5 Beta    | Sindhu   | Dec 09, 2022  | #SRM00015   | Handled code for shareDrive link to anyone
|0.5 Beta    | Sindhu   | Dec 17, 2022  | #SRM00016   | Handled code for shareDrive link using zip file for public access and particular user
|0.5 Beta    | Pappu    | Dec 21, 2022  | #PKY00001   | Handled to get doc under page range
|0.5 Beta    | Sindhu   | Jan 25, 2023  | #SRM00023   | Handled code for decoding base64 for pdfs with page range 
|0.5 Beta    | Sumit    | Aug 24, 2023  | #SKG00025   | Added code for  google drive generate history
----------------------------------------------------------------------------------------------

*/
//#00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.compress.utils.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;


public class IGDriveAPIController {
// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil i$Outils = new ImpactoUtil(); // #NYE00004
	private Logger logger = LoggerFactory.getLogger(IGDriveAPIController.class);
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();

// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "shareViaDrive")
					&& I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "shareddl")) {
				return gdriveAPICrudOps(isonMsg);
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};
	
	// #YPR00106  Starts
	private String getAccessToken() {

		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		String access_token = null;
		long diffMinutes = 60;

		try {

			JsonObject i$GdriveTkn = db$Ctrl.db$GetRow("ICOR_M_DMS_GDTOKEN_VALIDATOR", "{}");
			if (!I$utils.$isNull(i$GdriveTkn)){

				SimpleDateFormat ISO8601DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'");
				Date startDate = null;
				Date endDate = null;
				try {
					startDate = ISO8601DATEFORMAT.parse(i$GdriveTkn.get("CreatedOn").getAsString());
					endDate = ISO8601DATEFORMAT.parse(i$ResM.getdateTime(new Date()));
					long diff = endDate.getTime() - startDate.getTime();
					diffMinutes = (diff / 1000) / 60;
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}

			if (diffMinutes > 50 || i$GdriveTkn == null) {
				JsonObject i$GdriveParams = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{'GDriveApiSettings'=1}");
				JsonObject driveApikeys = i$GdriveParams.get("GDriveApiSettings").getAsJsonObject();
				String clntId = i$impactoUtil.decrypt(driveApikeys.get("ClientID").getAsString());
				String clntScrt = i$impactoUtil.decrypt(driveApikeys.get("ClientSecret").getAsString());
				String AuthTokn = i$impactoUtil.decrypt(driveApikeys.get("RefreshToken").getAsString());
				filter.addProperty("trnCd", "CreateGDriveAccessToken");
				argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
				argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
				String requestBody = String.format(
						"client_id=%s&client_secret=%s&grant_type=refresh_token&refresh_token=%s", clntId, clntScrt,
						AuthTokn);

				argJson.addProperty("reqBody", requestBody);

				JResp = I$EWSLnchr.ILaunchReq(argJson);

				logger.debug("JResp: " + gson.toJson(JResp));
				JsonObject resBody = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
				JsonObject queryfilter = new JsonObject();
				queryfilter.addProperty("isCurrVer", 'Y');
				JsonObject i$Doc = new JsonObject();
				i$Doc.addProperty("isCurrVer", 'Y');
				i$Doc.addProperty("CreatedOn", i$ResM.getdateTime(new Date()));
				i$Doc.addProperty("access_token",resBody.get("access_token").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_M_DMS_GDTOKEN_VALIDATOR", i$Doc, queryfilter, "true");
				access_token = resBody.get("access_token").getAsString();
				return access_token;

			} else {
				access_token = i$GdriveTkn.get("access_token").getAsString();
				return access_token;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return access_token;
		}

	}
	// #YPR00106  Ends
	
	// #YPR00107  Starts
	private JsonObject gdriveAPICrudOps(JsonObject isonMsg) {
		JsonObject ibody = i$ResM.getBody(isonMsg);
		try {
			String fileUrlToken = ibody.get("FileUrlToken").getAsString();
			String workspaceId = ibody.get("workspaceId").getAsString();
			String parentFolderId = ibody.get("parentFolderId").getAsString();
			JsonObject i$Filter = new JsonObject();
			if (ibody.has("LinkedCustNo")) { // #SRM00015 changes
				String LinkedCustNo = ibody.get("LinkedCustNo").getAsString();
				i$Filter.addProperty("metadata.LinkedCustNo", LinkedCustNo);
			}
			if(ibody.has("fileKey")) {
				JsonObject obj = new JsonObject();
				JsonObject i$body = new JsonObject();
				obj.addProperty("FileUrlToken", ibody.get("FileUrlToken").getAsString());
				obj.addProperty("fileKey", ibody.get("fileKey").getAsString());
				i$body.add("i-body", obj);
        		if (!db$Ctrl.db$DocPassVerify(i$body)) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");//#TKS00015 changes
					return isonMsg;
				}
        	}
			JsonObject gdfleDataLogObj = new JsonObject();
			JsonObject i$Update = new JsonObject();
			i$Filter.addProperty("metadata.FileUrlToken", fileUrlToken);
			i$Filter.addProperty("metadata.workspaceId", workspaceId);
			i$Filter.addProperty("metadata.parentFolderId", parentFolderId);
			i$Filter.addProperty("metadata.isCurrVer", "Y");

			JsonObject ifsfleData = db$Ctrl.db$GetRow("fs.files", i$Filter);
			if (!I$utils.$isNull(ifsfleData) || (ibody.has("multiple") && ibody.get("multiple").getAsBoolean())) { // #SRM00016 changes
																													

				if ((ibody.has("multiple") && I$utils.$iStrFuzzyMatch(ibody.get("multiple").getAsString(), "true"))
						|| (ifsfleData.has("metadata") // #SRM00016 changes
								&& !ifsfleData.get("metadata").getAsJsonObject().has("fileSharedViaGD"))) {
					JsonObject gdriveFilesData = uploadToDrive(isonMsg);
					JsonArray gdrivePermissionsDetails = setSharePermissions(isonMsg,
							gdriveFilesData.get("id").getAsString());
					String fileddl = getDDL(isonMsg, gdriveFilesData.get("id").getAsString());
					if (i$impactoUtil.matchRegEx(fileddl,
							"^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]")) {
						gdriveFilesData.addProperty("fileDwnldLink", fileddl);
						ibody.addProperty("fileDwnldLink", fileddl);
						i$Update.addProperty("metadata.fileSharedViaGD", true);
						if ((ibody.has("multiple") && ibody.get("multiple").getAsBoolean())) { // #SRM00016 changes
							gdfleDataLogObj.addProperty("GdriveFileId", gdriveFilesData.get("id").getAsString());
							gdfleDataLogObj.addProperty("Filename", ibody.get("FileName").getAsString());
							gdfleDataLogObj.addProperty("FileUrlToken", ibody.get("FileUrlToken").getAsString());
							gdfleDataLogObj.addProperty("workspaceId", ibody.get("workspaceId").getAsString());
							gdfleDataLogObj.addProperty("parentFolderId", ibody.get("parentFolderId").getAsString());
							gdfleDataLogObj.addProperty("publicAccess", ibody.get("publicAccess").getAsString());
							gdfleDataLogObj.addProperty("multiple", ibody.get("multiple").getAsString());
							gdfleDataLogObj.add("gdriveFilesData", gdriveFilesData);
							gdfleDataLogObj.add("gdrivePermissionsDetails", gdrivePermissionsDetails);
							db$Ctrl.db$InsertRow("ICOR_M_DMS_GD_SHARED_FILES", gdfleDataLogObj);
						} else {
//			i$Update.addProperty("metadata.GdriveFileId", gdriveFilesData.get("id").getAsString());
							db$Ctrl.db$UpdateRow("fs.files", i$Update, i$Filter);
							gdfleDataLogObj.addProperty("GdriveFileId", gdriveFilesData.get("id").getAsString());
							gdfleDataLogObj.addProperty("Filename", ibody.get("FileName").getAsString());
							gdfleDataLogObj.addProperty("FileUrlToken", ibody.get("FileUrlToken").getAsString());
							gdfleDataLogObj.addProperty("LinkedCustNo", ibody.get("LinkedCustNo").getAsString());
							gdfleDataLogObj.addProperty("workspaceId", ibody.get("workspaceId").getAsString());
//			gdfleDataLogObj.addProperty("parentFolderName", ibody.get("parentFolderName").getAsString());
							gdfleDataLogObj.addProperty("parentFolderId", ibody.get("parentFolderId").getAsString());
							gdfleDataLogObj.addProperty("publicAccess", ibody.get("publicAccess").getAsString());
							gdfleDataLogObj.add("gdriveFilesData", gdriveFilesData);
							gdfleDataLogObj.add("gdrivePermissionsDetails", gdrivePermissionsDetails);
							db$Ctrl.db$InsertRow("ICOR_M_DMS_GD_SHARED_FILES", gdfleDataLogObj);
						}
					} else {
						ibody.remove("I#FileData");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Generate Download Link");
						return isonMsg;
					}
				} else {
					JsonObject queryFilter = new JsonObject();
					queryFilter.addProperty("FileUrlToken", fileUrlToken);
					queryFilter.addProperty("workspaceId", workspaceId);
					queryFilter.addProperty("parentFolderId", parentFolderId);
					JsonObject gdriveShrdFle = db$Ctrl.db$GetRow("ICOR_M_DMS_GD_SHARED_FILES", queryFilter);

//				queryFilter.addProperty("LinkedCustNo",  LinkedCustNo);
					if (ibody.has("publicAccess")  //#SRM00016 changes
							&& I$utils.$iStrFuzzyMatch(ibody.get("publicAccess").getAsString(), "false")) {
						//if (I$utils.$iStrFuzzyMatch(gdriveShrdFle.getAsJsonObject().get("publicAccess").getAsString(), "false")) {
						JsonObject gdriveFilesData = uploadToDrive(isonMsg);
						String fileddl = getDDL(isonMsg, gdriveFilesData.get("id").getAsString());
						JsonArray gdrivePermissionsDetails = setSharePermissions(isonMsg,
								gdriveFilesData.get("id").getAsString());
						gdriveFilesData.addProperty("fileDwnldLink", fileddl);
						String i$Doc = "{'gdrivePermissionsDetails':{'$each':   " + gdrivePermissionsDetails + "   }}";
						db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_GD_SHARED_FILES", i$Doc, queryFilter, "false",
								"addtoSet");
						ibody.addProperty("fileDwnldLink", gdriveFilesData.get("fileDwnldLink").getAsString());
					//} 
				} else if (ibody.has("publicAccess")
						&& I$utils.$iStrFuzzyMatch(ibody.get("publicAccess").getAsString(), "true")) {
//					if (I$utils.$iStrFuzzyMatch(gdriveShrdFle.getAsJsonObject().get("publicAccess").getAsString(),
//							"true")) {
						JsonObject gdriveFilesData = uploadToDrive(isonMsg);
						String fileddl = getDDL(isonMsg, gdriveFilesData.get("id").getAsString());
						JsonArray gdrivePermissionsDetails = setSharePermissions(isonMsg,
								gdriveFilesData.get("id").getAsString());
						gdriveFilesData.addProperty("fileDwnldLink", fileddl);
						String i$Doc = "{'gdrivePermissionsDetails':{'$each':   " + gdrivePermissionsDetails + "   }}";
						db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_GD_SHARED_FILES", i$Doc, queryFilter, "false",
								"addtoSet");
						ibody.addProperty("fileDwnldLink", gdriveFilesData.get("fileDwnldLink").getAsString());
					}
//				}
				} //#SRM00016 changes end
			} else {
				ibody.remove("I#FileData");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "File Doesn't Exist");
				return isonMsg;
			}
			ibody.remove("I#FileData");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "File Download Link Generated Successfully ");

		} catch (Exception e) {
			e.printStackTrace();
			ibody.remove("I#FileData");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
		}
		db$Ctrl.db$logDmsHstry(isonMsg);//SKG00025 changes 
		return isonMsg;
	}
	// #YPR00107  Ends

	// #SKP00001  Starts
	private JsonObject uploadToDrive(JsonObject isonMsg) {
		JsonParser parser = new JsonParser();
		JsonObject ibody = i$ResM.getBody(isonMsg);
		JsonObject filter = new JsonObject();
		JsonObject argJson = new JsonObject();
		JsonObject JResp = new JsonObject();
		JsonObject headerObj = new JsonObject();
		JsonObject gdriveFilesData = new JsonObject();
		Gson gson = new Gson();

		try {
			String filename = ibody.get("FileName").getAsString();
			JsonArray parentFolders = new JsonArray();
			JsonObject i$GdriveParams = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{'GDriveApiSettings'=1}");
			JsonObject driveApikeys = i$GdriveParams.get("GDriveApiSettings").getAsJsonObject();
			String parentFolderId = driveApikeys.get("ParentFolderId").getAsString();
			filter.addProperty("trnCd", "UploadToDriveGDrive");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
			String accessToken = getAccessToken();
			headerObj.addProperty("Content-Type", "application/json");
			headerObj.addProperty("Authorization", "Bearer " + accessToken);
			argJson.add("headerTags", headerObj);
			String iFileData = ibody.get("I#FileData").getAsString();
			//PKY00001 starts
			byte[] decoded_FData = null;
			try {
				if(I$utils.$iStrFuzzyMatch(ibody.get("FileExtn").getAsString(), ".zip") || I$utils.$iStrFuzzyMatch(ibody.get("FileExtn").getAsString(), ".pdf")) {
					if(ibody.has("pageRange") && !I$utils.$iStrBlank(ibody.get("pageRange").getAsString())) {
						String base64str = getDocUnderPageRange(iFileData, ibody.get("pageRange").getAsString(), ibody.get("FileExtn").getAsString());
						decoded_FData = Base64.decodeBase64(base64str.getBytes());
					}else {
						decoded_FData = Base64.decodeBase64(iFileData.getBytes());
					}
				}else {
					decoded_FData = Base64.decodeBase64(iFileData.getBytes());
				}
			}catch(Exception e) {
				decoded_FData = Base64.decodeBase64(iFileData.getBytes());
			}
			//PKY00001 ends
			JsonObject reqBodyobj = new JsonObject();
			parentFolders.add(parentFolderId);
			reqBodyobj.addProperty("name", filename);
			reqBodyobj.add("parents", parentFolders);
			RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
					.addFormDataPart("", null,
							RequestBody.create(MediaType.parse("application/octet-stream"), decoded_FData))
					.addFormDataPart("", null,
							RequestBody.create(MediaType.parse("application/json"), gson.toJson(reqBodyobj).getBytes()))
					.build();

			JResp = I$EWSLnchr.ILaunchReq(argJson, body);

			logger.debug("JResp: " + gson.toJson(JResp));
			gdriveFilesData = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
			return gdriveFilesData;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return gdriveFilesData;

	};
	// #SKP00001  Ends

	// #SKP00002  Starts
	private JsonArray setSharePermissions(JsonObject isonMsg, String fileId) {
		JsonArray gdrivePermissionsDetails = new JsonArray();		
		try {
			JsonObject reqObj = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject headerObj = new JsonObject();
			JsonObject JResp = new JsonObject();
			String fleId = null;
			JsonParser parser = new JsonParser();
			JsonObject ibody = i$ResM.getBody(isonMsg);
			Gson gson = new Gson();
			MediaType mediaType = MediaType.parse("application/json");
			String accessToken = getAccessToken();
			filter.addProperty("trnCd", "SetPermissionGDrive");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
			reqObj.addProperty("role", argJson.get("role").getAsString());
			boolean publicAccess = ibody.get("publicAccess").getAsBoolean();
			if (publicAccess == true) {
				reqObj.addProperty("type", "anyone");
			} else {
				reqObj.addProperty("type", "user");
			}
			headerObj.addProperty("Content-Type", "application/json");
			headerObj.addProperty("Authorization", "Bearer " + accessToken);
			headerObj.addProperty("Accept", "application/json");
			argJson.add("headerTags", headerObj);

			String permsnUrl = String.format(argJson.get("extUrl").getAsString(), fileId,
					argJson.get("sendNotificationEmail").getAsString());

			argJson.addProperty("extUrl", permsnUrl);

			JsonArray emailAddressArr = ibody.get("toEmailIds").getAsJsonArray();

			if (emailAddressArr.size() == 0) { //#SRM00015 start
				RequestBody body = RequestBody.create(mediaType, gson.toJson(reqObj));
				JResp = I$EWSLnchr.ILaunchReq(argJson, body);
				logger.debug("JResp: " + gson.toJson(JResp));
				JsonObject permsnObj = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
				gdrivePermissionsDetails.add(permsnObj);
			} else {
				for (int i = 0; i < emailAddressArr.size(); i++) {
					{
						reqObj.addProperty("emailAddress", emailAddressArr.get(i).getAsString());
						RequestBody body = RequestBody.create(mediaType, gson.toJson(reqObj));
						JResp = I$EWSLnchr.ILaunchReq(argJson, body);
						logger.debug("JResp: " + gson.toJson(JResp));
						JsonObject permsnObj = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
						permsnObj.addProperty("emaiId", emailAddressArr.get(i).getAsString());
						gdrivePermissionsDetails.add(permsnObj);
					}
				}
			} //#SRM00015 end
			
			return gdrivePermissionsDetails;
		} catch (Exception e) {
			e.printStackTrace();
			return gdrivePermissionsDetails;
		}

	};
	// #SKP00002  Ends

	// #SKP00003  Starts
	private String getDDL(JsonObject isonMsg,String fileId) {
		String ddl = null;
		try {
			JsonObject argJson = new JsonObject();
			JsonObject headerObj = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject JResp = new JsonObject();
			JsonObject lnkdtls = new JsonObject();
			JsonObject drFiles = new JsonObject();
			JsonParser parser = new JsonParser();
			Gson gson = new Gson();
			String accessToken = getAccessToken();
			filter.addProperty("trnCd", "GetDDLGDrive");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
			headerObj.addProperty("Content-Type", "application/json");
			headerObj.addProperty("Authorization", "Bearer " + accessToken);
			argJson.add("headerTags", headerObj);
			String extUrl = String.format(argJson.get("extUrl").getAsString(), fileId);
			argJson.addProperty("extUrl", extUrl);
			
			JResp = I$EWSLnchr.ILaunchReq(argJson);

			logger.debug("JResp: " + gson.toJson(JResp));

			lnkdtls = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
			ddl = lnkdtls.get("webContentLink").getAsString();
			return ddl;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ddl;

	};
	// #SKP00003  Ends
	
	//PKY00001 starts
	public String getDocUnderPageRange(String base64Pdf, String pageRange, String FileExtn) throws IOException, DocumentException {
		String base64Str = null;
		try {
			List<File> files = new ArrayList<File>();
			if (I$utils.$iStrFuzzyMatch(FileExtn, ".zip")) {
				Map<String, String> base64Entries = new LinkedHashMap<>();
				try (ZipInputStream zipIn = new ZipInputStream(new ByteArrayInputStream(java.util.Base64.getDecoder().decode(base64Pdf)))) {
					java.util.Base64.Encoder encoder = java.util.Base64.getEncoder();
					for (java.util.zip.ZipEntry entry; (entry = zipIn.getNextEntry()) != null;) {
						base64Entries.put(entry.getName(), encoder.encodeToString(zipIn.readAllBytes()));
					}
				}
				Set<String> keys = base64Entries.keySet();
				for (String key : keys) {
					if (key.contains(".pdf")) {
						String value = base64Entries.get(key);
						String finalDoc = docBetweenPageRange(value, pageRange);
						File file = base64ToFile(key, finalDoc);
						files.add(file);
					} else {
						String value = base64Entries.get(key);
						File file = base64ToFile(key, value);
						files.add(file);
					}
				}
				base64Str = zipBase64(files);
			} else {
				String base64StrPdf = docBetweenPageRange(base64Pdf, pageRange);
				return base64StrPdf;
			}
		} catch (Exception e) {
			logger.debug("Failed to zip docs.");
			return null;
		}
		return base64Str;
	}

	private static String zipBase64(List<File> files) throws IOException {
		try {
			byte[] buffer = new byte[1024];
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try (ZipOutputStream zos = new ZipOutputStream(baos)) {
				for (File f : files) {
					try (FileInputStream fis = new FileInputStream(f)) {
						zos.putNextEntry(new ZipEntry(f.getName()));
						int length;
						while ((length = fis.read(buffer)) > 0) {
							zos.write(buffer, 0, length);
						}
						zos.closeEntry();
					}
				}
			}
			byte[] bytes = baos.toByteArray();
			return java.util.Base64.getEncoder().encodeToString(bytes);
		}catch(Exception e) {
			return null;
		}
	}

	public File base64ToFile(String key, String base64Str) throws IOException {
		try {
			byte[] data = Base64.decodeBase64(base64Str);
			ByteArrayInputStream bis = new ByteArrayInputStream(data);
			bis.close();
			File file = new File(key);
			FileOutputStream fop = new FileOutputStream(file);
			fop.write(data);
			fop.flush();
			fop.close();
			return file;
		} catch (Exception e) {
			return null;
		}
	}

	public String docBetweenPageRange(String base64Pdf, String pageRange) {
		String base64Str = null;
		try { //SRM00023 changes
			byte[] decodedPdf = null;
			try {
				decodedPdf = java.util.Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = Base64.decodeBase64(base64Pdf);
			}  
			if(decodedPdf == null) {
				logger.debug("Failed to fetch doc under page range.");
				return null; //#SRM00023 changes
			} else {

				PdfReader reader = new PdfReader(decodedPdf);
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				Document document = new Document();
				PdfCopy copy = new PdfCopy(document, outputStream);
				document.open();
				PdfStamper stamper = new PdfStamper(reader, outputStream);
				if (pageRange.isBlank()) {
					logger.debug("Field pageRange should not be blank or empty.");
//					return null;
				} else {
					try {
						if (pageRange.contains("-")) {
							String[] pageArr = pageRange.split("-");
							int lowerLimit = Integer.parseInt(pageArr[0]);
							int upperLimit = Integer.parseInt(pageArr[1]);
							for (int i = lowerLimit; i <= reader.getNumberOfPages() && i <= upperLimit; i++) {
								PdfImportedPage importedPage = stamper.getImportedPage(reader, i);
								copy.addPage(importedPage);
							}
						} else if (pageRange.contains(",")) {
							JsonArray pageArr = new JsonArray();
							String[] pageArrStr = pageRange.split(",");
							for (int i = 0; i < pageArrStr.length; i++) {
								pageArr.add(Integer.parseInt(pageArrStr[i]));
							}
							for (int i = 1; i <= reader.getNumberOfPages(); i++) {
								for (int j = 0; j < pageArr.size(); j++) {
									if (pageArr.get(j).getAsInt() == i) {
										PdfImportedPage importedPage = stamper.getImportedPage(reader, i);
										copy.addPage(importedPage);
									}
								}
							}
						} else {
							int pageNo = Integer.parseInt(pageRange);
							for (int i = 1; i <= reader.getNumberOfPages(); i++) {
								if (i == pageNo) {
									PdfImportedPage importedPage = stamper.getImportedPage(reader, i);
									copy.addPage(importedPage);
								}
							}
						}
					} catch (Exception e) {
						logger.debug("Error to find page range.");
						return null;
					}
					copy.freeReader(reader);
					outputStream.flush();
					document.close();
					byte[] pdfBytes = outputStream.toByteArray();
					base64Str = java.util.Base64.getEncoder().encodeToString(pdfBytes);
					return base64Str;
				}
			}
		} catch (Exception e) {
			logger.debug("Failed to fetch doc under page range.");
			return null;
		}
		return base64Str;
	}
	//PKY00001 ends
	
	//to delete the file with fileid
//	private String deleteFile(JsonObject isonMsg, String fileId) {
//		try {
//			JsonObject argJson = new JsonObject();
//			JsonObject headerObj = new JsonObject();
//			JsonObject filter = new JsonObject();
//			JsonObject JResp = new JsonObject();
//			JsonObject drFiles = new JsonObject();
//			JsonParser parser = new JsonParser();
//			Gson gson = new Gson();
//			String accessToken = getAccessToken();
//			filter.addProperty("trnCd", "deleteFileGDrive");
//			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
//			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
//			headerObj.addProperty("Content-Type", "application/json");
//			headerObj.addProperty("Authorization", "Bearer " + accessToken);
//			argJson.add("headerTags", headerObj);
//			String extUrl = String.format(argJson.get("extUrl").getAsString() + fileId);
//			argJson.addProperty("extUrl", extUrl);
//
//			OkHttpClient client = new OkHttpClient().newBuilder().build();
//			MediaType mediaType = MediaType.parse("application/json");
//			RequestBody body = RequestBody.create(mediaType, "");
//			
//			JResp = I$EWSLnchr.ILaunchReq(argJson,body);
//
//			logger.debug("JResp: " + gson.toJson(JResp));
//
//		} catch (Exception e) {
//
//		}
//		return fileId;
//	}

	public IGDriveAPIController() {

	}
}
