/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Baz 		| Mar 25, 2019 | #0000001   | Initial writing
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ILoanAppController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(ILoanAppController.class);

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OLZLNAPP") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				return createLNAPApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OLZLNAPP") && I$utils.$iStrFuzzyMatch(SOpr, "PARTIAL_SAVE")) {
				return partialSaveLNAPApln(isonMsg, isonheader, isonMapJson);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OLZLNAPP") && I$utils.$iStrFuzzyMatch(SOpr, "GET_REC")) {
				return getVersionRecords(isonMsg, isonheader, isonMapJson);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	private JsonObject getVersionRecords(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject query = new JsonObject();
			query.addProperty("isCurrVer", "Y");

			query.addProperty("WorkFlowId", i$body.get("WorkFlowId").getAsString());
			query.addProperty("applicationId", i$body.get("applicationId").getAsString());
			query.addProperty("referenceNo", i$body.get("referenceNo").getAsString());

//		JsonObject app$proj = new JsonObject();
//		app$proj.addProperty("applicationId", 1);
//		app$proj.addProperty("referenceNo", 1);
			JsonArray inc$appls = db$Ctrl.db$GetRows("ICOR_C_B2U_LOAN_APPLICATIONS_LEDGER", query);
			return i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, inc$appls);

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
		}

		return isonMsg;
	}

	public JsonObject createLNAPApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String ScrCtrlClass = null;
		String sAppNumber = null;
		jBody = i$ResM.getBody(isonMsg);
		String Scr = i$ResM.getScreenID(isonMsg);
		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;
			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "isCurrVer", "Y");
			
			jFilter.addProperty("referenceNo", sRef);
			jFilter.addProperty("applicationId", sAppNumber);
			
			// Insert the data to the version history logger/ledger.
			db$Ctrl.db$InsertRow("ICOR_C_B2U_LOAN_APPLICATIONS_LEDGER", jBody);
			
			// WOrkflow Status
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);


			if (!(Appl$Json != null)) {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "O_OPEN"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}

			jBody.addProperty("referenceNo", sRef);
			// trigger Workflow
			if (I$utils.$iStrFuzzyMatch(DcStatus, "COMPLETED")) {
				JsonObject Jbdy = new JsonObject();

				// update the referDc Applicaiton
				updateReferDcStatus(sAppNumber, Coll_Name);
				JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP", "{\"SCRID\":\"" + Scr + "\"}",
						"{\"WORKFLOW\":1}");

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
						i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);

				// Fwd the Control to Workflow COntroller.
				ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
				Class<?> ctrlClass;
				ctrlClass = Class.forName(ScrCtrlClass);
				JsonObject result$ = null;
				Method ctrlFunc = null;
				ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
				Object ctrl$Caller = ctrlClass.newInstance();
				result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
					if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
					} else {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
					}
				} else {
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
					return isonMsg;
				}
			} // Workflow loop End
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");

			// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,jBody);
			return isonMsg;
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			jBody.addProperty("referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION REGISTRATION");
			return isonMsg;
		}
	}

	public void updateReferDcStatus(String sAppNumber, String Coll_Name) {

		// app$Json.addProperty("DcStatus", "ReferDcIncomplete");
		try {
			JsonObject jFlter = new JsonObject();
			jFlter.addProperty("applicationId", sAppNumber);
			JsonObject Apl$Json = new JsonObject();
			Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
			if (Apl$Json != null) {
				if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
					jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
					JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
					if (task$Json != null) {
						task$Json.addProperty("Queue", "ReferDcResubmit");
						db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);

					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private JsonObject partialSaveLNAPApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String sAppNumber = null;
		int VersionNumber = 0;
		jBody = i$ResM.getBody(isonMsg);
		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;

			JsonObject query = new JsonObject();

			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			query.addProperty("referenceNo", sRef);
			query.addProperty("applicationId", sAppNumber);

			VersionNumber = db$Ctrl.db$GetCountI("ICOR_C_B2U_CIF_APPLICATION", query.toString());

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "version", "V" + "" + VersionNumber);
			jFilter.addProperty("referenceNo", sRef);
			jFilter.addProperty("applicationId", sAppNumber);

			// WOrkflow Status
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);

			// Insert the data to the version history logger.
			db$Ctrl.db$InsertRow("ICOR_C_B2U_LOAN_APPLICATIONS_LOGGER", jBody);
			try {
				jBody.remove("version");
			} catch (Exception e) {
				// Pass
			}
			// Update the main loan application collection
			if (!(Appl$Json != null)) {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "O_OPEN"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}

			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "LOAN APPLICATION UPDATED SUCCESSFULLY");

		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			jBody.addProperty("referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION REGISTRATION");
			return isonMsg;
		}

	}

	public ILoanAppController() {
		// Cons
	}
}
// #0000001 Ends