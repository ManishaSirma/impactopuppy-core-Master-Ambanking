/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | #00000002 	| Jan 11, 2019 | #00000001   | Initial writing
      |0.1 Beta    | #00000002 	| Jan 18, 2019 | #00000002   | Added Session Validation
      |0.1 Beta    | Niegil 	| Jan 22, 2019 | #00000003   | Added Global Var for ResCols
      |0.2.1       | Vijay 		| Jan 25, 2019 | #BVB00042   | Site Key validations moved from GenericAppController to IScreeningController
      |0.2.1       | Vijay 		| Jan 30, 2019 | #BVB00043   | Audit Login for Users 
      |0.2.1       | Niegil 	| Feb 04, 2019 | #NYE00001   | Global Constants for Pubkey,EncryptKeys , Decrypt keys, Sanitize Changes
      |0.2.1       | Vijay 		| Feb 19, 2019 | #BVB00067   | Token validation now added with User Id and Session Id
      |0.2.1       | Niegil 	| Feb 22, 2019 | #NYE50001   | Validate Incomming Request Against DB
      |0.2.1       | Vijay  	| Mar 02, 2019 | #BVB50081   | User Validity Check
      |0.2.1       | Vijay  	| Mar 02, 2019 | #BVB00109   | For Auth requests versions are not coming. Handling for the same
      |0.3.6       | Vijay   	| May 04, 2019 | #BVB00143   | Dual key pair Encrypt/Decrypt from all applications
      |0.3.6       | Niegil   	| Jun 05, 2019 | #NYE00100   | Black List Character Validations
      |0.3.9       | Vijay   	| May 26, 2019 | #BVB00157   | Version, OS validation will respond with Upgrade Required
      |0.3.12      | Vijay   	| Jun 03, 2019 | #BVB00159   | Adding User and Ambassador To globals 
      |0.3.15      | Vijay  	| Jun 18, 2019 | #BVB00171   | Session Handling for SessionTracking SrcId
      |0.3.16      | Vijay  	| Jul 04, 2019 | #BVB00175   | Introducing Mode at Global
      |0.3.16      | Vijay  	| Jul 06, 2019 | #BVB00178   | BlackList chars onlyInKey search
      |2.3.0.3     | Vijay  	| Sep 17, 2019 | #BVB00210   | Extending BVB00175 to Token as well
      |3.1.0.427   | Syed       | Nov 20, 2019 | #MAQ00051   | Added Decoding code
      |3.1.1       | Devraj     | Jan 23, 2020 | #DVJ00015   | Added bearer token into db
      |3.1.1	   | Manikanta  | May 22, 2023 | #MVT00117   | Added code to validate imecd and session in digi app 
      |3.1.1	   | Sindhu     | Jun 02, 2023 | #SRM00040   | Added code to validate login from other devices          
      |3.1.1	   | Manikanta  | Jun 20, 2023 | #MVT00124   | Added code to handle password validation before otp triggering
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.internal.constraintvalidators.hv.ISBNValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.CaptchaController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IpasscodeController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.OtpController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.SdnScanController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;

@SuppressWarnings("unused")
public class IScreeningController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IScreeningController.class); // #00000003- Change Class
	// Name
	private IDataValidator I$DataValidator = new IDataValidator();
	private IDBDataValidator I$DBDataValidator = new IDBDataValidator(); // #NYE00002
	private SentryGuardController I$SntryCntr = new SentryGuardController();
	public String IDataValMsg = null;
	public boolean IOTPValStat = true;
	private ImpactoUtil I$impactoUtil = new ImpactoUtil(); // #NYE00001
	private IpasscodeController I$passcode = new IpasscodeController(); // #NYE00048
	private static final SdnScanController i$sdnCtrl = new SdnScanController();
	private OtpController OtpCntrlr = new OtpController();
	// **********************************************************************//

	// #NYE00001 Begins

	// #NYE00100 Revamped the Logic
	public boolean i$NoSqlInject(JsonObject isonMsg) {
		try {
			JsonArray JList = new JsonArray();
			// #BVB00178 Starts
			JsonObject flattenedIsonMsg = isonMsg.deepCopy();

			flattenedIsonMsg = I$impactoUtil.flattenJsonObject(isonMsg);
			if (I$utils.$isNull(flattenedIsonMsg)) {
				flattenedIsonMsg = isonMsg;
			}
			// #BVB00178 Ends
			JsonObject JTemp;
			JList = db$Ctrl.db$GetRows("ICOR_S_BLACKLIST_CHARS", "{\"searchTxt.on\":1}");
			for (int i = 0; i < JList.size(); i++) {
				JTemp = new JsonObject();
				JTemp = JList.get(i).getAsJsonObject();
				// #BVB00178 Starts
				String onlyInKey = "0";
				try {
					onlyInKey = JTemp.getAsJsonObject("searchTxt").get("onlyInKey").getAsString();
				} catch (Exception e) {
					onlyInKey = "0";
				}
				if (I$utils.$iStrFuzzyMatch(onlyInKey, "0")) {
					// #BVB00178 Ends
					if (StringUtils.containsIgnoreCase(isonMsg.toString(),
							(JTemp.get("searchTxt").getAsJsonObject()).get("text").getAsString()))
						return true;
				} else {
					if (I$impactoUtil.hasStringInKey(flattenedIsonMsg,
							JTemp.get("searchTxt").getAsJsonObject().get("text").getAsString())) {
						return true;
					}
				}
			}
			return false;
		} catch (Exception e) {
			logger.debug(e.getMessage());
			return true;
		}
	};
	// #NYE00100 Revamped the Logic Ends
	// #NYE00001 Ends
	
	// #MAQ00051 Checking Invalid chars
	public boolean i$NonEncChars(String isonMsg) {
		try {
			JsonObject filter = new JsonObject();
			filter.addProperty("SrcID", "ImpactoCore");
			JsonObject projection = new JsonObject();
			projection.addProperty("EncRequired", "1");
			projection.addProperty("_id", "0");
			try {
				JsonObject Res = db$Ctrl.db$GetRow("ICOR_S_EXT_SRC_MAP", filter);
				if (I$utils.$iStrFuzzyMatch(Res.get("EncRequired").getAsString(), "N")) {
					return false;
				}
			} catch(Exception e){
				return false;
			}
			JsonArray JList = new JsonArray();
			JsonObject JTemp;
			JList = db$Ctrl.db$GetRows("ICOR_S_NON_ENC_CHARS", "{\"searchTxt.on\":1}");
			for (int i = 0; i < JList.size(); i++) {
				JTemp = new JsonObject();
				JTemp = JList.get(i).getAsJsonObject();
				// #BVB00178 Starts
				String onlyInKey = "0";
				try {
					onlyInKey = JTemp.getAsJsonObject("searchTxt").get("onlyInKey").getAsString();
				} catch (Exception e) {
					onlyInKey = "0";
				}
				String curChar = JTemp.get("searchTxt").getAsJsonObject().get("text").getAsString(); 
				if (isonMsg.contains(curChar)) {
					System.out.println("Invalid character " + curChar);
					return true;
				}
				
			}
			return false;
		} catch (Exception e) {
			logger.debug(e.getMessage());
			return true;
		}
	};
	// #MAQ00051 Ends
	
	public boolean i$ReqOk(JsonObject isonMsg) // Request Ok
	{
		JsonObject filter = new JsonObject();
		JsonParser parser = new JsonParser();
		// Setting Globals 
		i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
		// #NYE00001 Begins
		// Validate Config
		if (isonMsg.has("i-config"))
			i$ResM.setGobalVals("i-config", isonMsg.getAsJsonObject("i-config").deepCopy()); // NYE Adding Config and header to

		// Validate Header
		// Globals
		if (isonMsg.has("i-header"))
			i$ResM.setGobalVals("i-header", isonMsg.getAsJsonObject("i-header").deepCopy());
		// #NYE00001 Ends

		// #BVB00042 Starts

		if (i$NoSqlInject(isonMsg)) {
			i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
			IDataValMsg = "INVALID OR CORRUPTED MESSAGE";
			I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
			return false;
		}
		;
		// #BVB00175 Starts
		try {
			JsonObject projection = new JsonObject();
			//projection.addProperty("mode", "1");
			//projection.addProperty("trustedOrNot", "1");
			JsonObject icorCParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter, projection);
			i$ResM.setGobalVals("mode", icorCParam.get("mode").getAsString());
			i$ResM.setGobalVals("trustedOrNot", icorCParam.get("trustedOrNot").getAsString());
			i$ResM.setGobalVals("icorCParam", icorCParam);
		} catch (Exception e) {
			i$ResM.setGobalVals("mode", "PROD");
			i$ResM.setGobalVals("trustedOrNot", "0");
		}
		// #BVB00175 Ends
		// Check Site Key
		String SiteKey = i$ResM.getSiteKey(isonMsg);

		JsonObject setter = new JsonObject();
		if (I$utils.$iStrBlank(SiteKey) || !ValidateSiteKey(SiteKey)) {
			i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
			IDataValMsg = "INVALID OR UNKNOWN SITE KEY";
			return false;
		}
		;
		// #BVB00042 Ends
		// #00000002 Changes Begin
		// Setting the Session Details To Globals
		if (!I$utils.$iStrFuzzyMatch(i$ResM.getSrvcName(isonMsg), "SessionKey")) {
			// Checking if the request is from Knock or Aperture

			// #BVB00043 Starts
			if (IResManipulator.JReqheader.get().get("RequestURI").getAsString().contains("knock")
					|| IResManipulator.JReqheader.get().get("RequestURI").getAsString().contains("galaxy")) {
				try {

					i$ResM.setGobalVals("sessionId", i$ResM.getClientSessionID(isonMsg));
					setter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId"));
					setter.addProperty("userId", IResManipulator.iloggedUser.get());
					// #BVB00171 Starts
					String sessionTracking = "Y";
					try {
						sessionTracking = I$impactoUtil
								.decrypt(i$ResM.getGobalValJObj("srcJson").get("SessionTrackReq").getAsString());
					} catch (Exception e) {
						sessionTracking = "Y";
					}
					if (I$utils.$iStrFuzzyMatch(sessionTracking, "Y")) {
						i$ResM.setGobalVals("JSessionDets",
								db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", setter).getAsJsonObject());
					} else {
						i$ResM.setGobalVals("JSessionDets", parser.parse(i$ResM.I_CORE_SESSION).getAsJsonObject());
					}
					// #BVB00171 Ends
				} catch (Exception e) {
					i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
					IDataValMsg = "UNKOWN SESSION";
					I$SntryCntr.isonResHTPPStat = HttpStatus.GATEWAY_TIMEOUT;
					return false;

				}
				;

				// Call Token Validation

				if (!ValidateToken(IResManipulator.JReqheader.get().get("Authorization").getAsString(),
						IResManipulator.iloggedUser.get())) {
					i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
					IDataValMsg = "INVALID TOKEN";
					I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					return false;
				}

				// #BVB50081 Starts
				// Checking if User Is valid or not.
				if(!IResManipulator.iloggedUser.get().contains("@")  &&
						I$impactoUtil.matchRegEx(IResManipulator.iloggedUser.get(),"[a-zA-Z]+")) {		// DVJ00015 Added
					if (!db$Ctrl.isUserValid()) {
						i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
						IDataValMsg = "INVALID OR UNKNOWN USER ID";
						I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
						return false;
					}
					// #BVB00159 Starts
					else {
						try {
							filter = new JsonObject();
							filter.addProperty("userId", IResManipulator.iloggedUser.get());
							JsonObject icorMUsrPrf = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter);
							i$ResM.setGobalVals("USER_PRF", icorMUsrPrf);
						} catch (Exception e) {
							i$ResM.setGobalVals("USER_PRF", new JsonObject());
						}

						try {
							filter = new JsonObject();
							filter.addProperty("Amd_Id", IResManipulator.iloggedUser.get());
							JsonObject icorMUsrPrf = db$Ctrl.db$GetRow("ICOR_M_B2U_AMBASSADOR", filter);
							i$ResM.setGobalVals("AMBASSADOR", icorMUsrPrf);
						} catch (Exception e) {
							i$ResM.setGobalVals("AMBASSADOR", new JsonObject());
						}
						// #BVB00159 Ends
					}
				} 
				// #DVJ00015 Starts
				else {
					try {
						filter = new JsonObject();
						filter.addProperty("key", IResManipulator.iloggedUser.get());
						JsonObject icorMUsrPrf = db$Ctrl.db$GetRow("ICOR_M_WEBPORTAL_USERS", filter);
						i$ResM.setGobalVals("USER_PRF", icorMUsrPrf);
						i$ResM.setGobalVals("AMBASSADOR", icorMUsrPrf);
					} catch (Exception e) {
						i$ResM.setGobalVals("USER_PRF", new JsonObject());
						i$ResM.setGobalVals("AMBASSADOR", new JsonObject());
					}
				}
				// #DVJ00015 Ends
				// #BVB50081 Ends
			} else {
				// #BVB00043 Ends
				try {
					i$ResM.setGobalVals("sessionId", i$ResM.getClientSessionID(isonMsg));
					// #BVB00171 Starts
					String sessionTracking = "Y";
					try {
						sessionTracking = I$impactoUtil
								.decrypt(i$ResM.getGobalValJObj("srcJson").get("SessionTrackReq").getAsString());
					} catch (Exception e) {
						sessionTracking = "Y";
					}
					i$ResM.setGobalVals("sessionTracking", sessionTracking); // #BVB00210
					if (I$utils.$iStrFuzzyMatch(sessionTracking, "Y")) {
						i$ResM.setGobalVals("JSessionDets",
								db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR",
										"{\"sessionId\":\"" + i$ResM.getGobalValStr("sessionId") + "\"}")
										.getAsJsonObject());
					} else {
						i$ResM.setGobalVals("JSessionDets", parser.parse(i$ResM.I_CORE_SESSION).getAsJsonObject());
					}
					// #BVB00171 Ends
				} catch (Exception e) {
					i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
					IDataValMsg = "The current session has been terminated due to timeout or bad internet connectivity or someone else would have logged In with same user on another device.";
					I$SntryCntr.isonResHTPPStat = HttpStatus.GATEWAY_TIMEOUT;
					return false;

				}
				;
			}

			try {
				i$ResM.setGobalVals("deCryptKey",
						i$ResM.getGobalValJObj("JSessionDets").get("privateKey").getAsString());
			} catch (Exception e) {
				i$ResM.setGobalVals("deCryptKey",
						i$ResM.getGobalValJObj("JSessionDets").get("sessionKeyVal").getAsString());
			}
			;
			// #NYE00001 Begins
			try {
				// #BVB00143 Starts
				// i$ResM.setGobalVals("enCryptKey",
				// i$ResM.getGobalValJObj("JSessionDets").get("SVal").getAsString());
				i$ResM.setGobalVals("enCryptKey",
						i$ResM.getGobalValJObj("JSessionDets").get("publicKeyE").getAsString());
			} catch (Exception e) {
//				i$ResM.setGobalVals("enCryptKey",
//						i$ResM.getGobalValJObj("JSessionDets").get("publicKey").getAsString());
				// #BVB00143 Ends
			}
			// #NYE00001 Ends
			;
		}
		;
		// #00000002 Changes Ends
		// Data Validator
		JsonObject i$Annotate = null, i$body = null;
		try {
			i$body = isonMsg.getAsJsonObject("i-body");
		} catch (Exception e) {
			i$body = null;
		}
		;
		String sMathScr, sMatchOpr, sScrID, sSvr = null, sSvrOpr = null, sOpr = null;
		sScrID = i$ResM.getScreenID(isonMsg);
		if (I$utils.$iStrBlank(sScrID)) {
			// The Call is a Service Call
			sSvr = i$ResM.getSrvcName(isonMsg);
			sSvrOpr = i$ResM.getSrvcopr(isonMsg);
			sMathScr = sSvr;
			sMatchOpr = sSvrOpr;
		} else {
			sOpr = i$ResM.getOpr(isonMsg);
			sMathScr = sScrID;
			sMatchOpr = sOpr;
		}
		;

		// #00000002 Added Code for Global Vars Begins
		i$ResM.setGobalVals("iAnnote", sMathScr + "_" + sMatchOpr);
		i$ResM.setGobalVals("screenid", sScrID);
		i$ResM.setGobalVals("srvcname", sSvr);
		i$ResM.setGobalVals("operation", sOpr);
		i$ResM.setGobalVals("srvcopr", sSvrOpr);
		// #00000002 Added Code for Global Vars Ends

		// Annotate Validate
		i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
				"{\"ANNOTATION\":\"" + sMathScr + "_" + sMatchOpr + "\"}");
		if (i$Annotate == null) {
			i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
			I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
			IDataValMsg = "MISSING OR UNKNOWN ANNOTE";
			return false;
		}

		// #00000003 begins
		// Set Res Column Vals
		try {
			i$ResM.setGobalVals("REMOVE_RES_COLS", i$Annotate.get("REMOVE_RES_COLS").getAsJsonObject()); // #00000003
																											// Move Re
																											// Cols to
																											// Annote
		} catch (Exception ex) {

		}
		;
		// #00000003 Ends

		// #NYE00001 begins

		// Set Encrypt Columns
		try {
			i$ResM.setGobalVals("DCYPT_REQ_COLS", i$Annotate.get("DCYPT_REQ_COLS").getAsJsonObject());
		} catch (Exception ex) {

		}
		;

		// Set Encrypt Columns
		try {
			i$ResM.setGobalVals("ECYPT_RES_COLS", i$Annotate.get("ECYPT_RES_COLS").getAsJsonObject());
		} catch (Exception ex) {

		}
		;
		try {
			i$ResM.setGobalVals("DCYPT_NESTED_REQ_COLS", i$Annotate.get("DCYPT_NESTED_REQ_COLS").getAsJsonObject());
		} catch (Exception ex) {

		}
		;
		try {
			i$ResM.setGobalVals("ECYPT_NESTED_RES_COLS", i$Annotate.get("ECYPT_NESTED_RES_COLS").getAsJsonObject());
		} catch (Exception ex) {

		}
		;
		try {
			i$ResM.setGobalVals("REMOVE_NESTED_RES_COLS", i$Annotate.get("REMOVE_NESTED_RES_COLS").getAsJsonObject());
		} catch (Exception ex) {

		}
		;

		if (i$body != null) {
			try {
				JsonObject JRemCols = i$ResM.getGobalValJObj("DCYPT_REQ_COLS");
				if (JRemCols != null) {
					Set<Entry<String, JsonElement>> entrySet = JRemCols.entrySet();
					String strKey, strVal;
					for (Map.Entry<String, JsonElement> entry : entrySet) {
						strKey = entry.getKey();
						strVal = JRemCols.get(entry.getKey()).getAsString();
						if (I$utils.$iStrFuzzyMatch(strVal, "1"))
							if (i$body.has(strKey)) {
								if (!I$utils.$iStrFuzzyMatch(i$body.get(strKey).getAsString(), ""))
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$body, strKey,
											I$impactoUtil.decryptPkey(i$body.get(strKey).getAsString()));

							}
					}
				}
				;
			} catch (Exception e) {
				logger.debug(e.getMessage());
			}
			
			try {
                JsonObject JNesRemCols = i$ResM.getGobalValJObj("DCYPT_NESTED_REQ_COLS");
                if (JNesRemCols != null) {
                    Set<String> keys = JNesRemCols.keySet();
                    for (String key : keys) {
                        if (JNesRemCols.get(key).isJsonArray() && !I$utils.$isNull(JNesRemCols.get(key))) {
                            JsonArray iBodyData = i$body.get(key).getAsJsonArray();
                            JsonArray nesArr = JNesRemCols.get(key).getAsJsonArray();
                            for (int i = 0; i < nesArr.size(); i++) {
                                try {
                                    JsonObject currentObj = nesArr.get(i).getAsJsonObject();
                                    Set<String> currKeys = currentObj.keySet();
                                    for (String currKey : currKeys) {
                                        String value = currentObj.get(currKey).getAsString();
                                        if (I$utils.$iStrFuzzyMatch(value, "1")) {
                                            for(int j=0; j<iBodyData.size(); j++) {
                                                if (iBodyData.get(j).getAsJsonObject().has(currKey) && !I$utils.$iStrFuzzyMatch(
                                                        iBodyData.get(j).getAsJsonObject().get(currKey).getAsString(),
                                                        "")) {
                                                    i$body.get(key).getAsJsonArray().get(j).getAsJsonObject()
                                                            .addProperty(currKey, I$impactoUtil.decryptPkey(iBodyData.get(j)
                                                                    .getAsJsonObject().get(currKey).getAsString()));
                                                }
                                            }
                                            
                                        }
                                    }
                                } catch (Exception e) {
                                }
                            }
                        }
                        if (JNesRemCols.get(key).isJsonObject() && !I$utils.$isNull(JNesRemCols.get(key))) {
                            JsonObject nesObj = JNesRemCols.get(key).getAsJsonObject();
                            JsonObject iBodyData = i$body.get(key).getAsJsonObject();
                            Set<String> currKeys = nesObj.keySet();
                            for (String currKey : currKeys) {
                                String value = nesObj.get(currKey).getAsString();
                                if (I$utils.$iStrFuzzyMatch(value, "1")) {
                                    if (iBodyData.has(currKey) && !I$utils.$iStrFuzzyMatch(iBodyData.get(currKey).getAsString(), "")) {
                                        i$body.get(key).getAsJsonObject().addProperty(currKey, I$impactoUtil
                                                .decryptPkey(iBodyData.getAsJsonObject().get(currKey).getAsString()));
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                logger.debug(e.getMessage());
            }

		}
		;
		// #NYE00001 Ends

		if (i$body != null) {
			// Check for Field Validations in Incomming Request
			I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, sMathScr, sMatchOpr);
			try {
				// Check for Field Validations Within
				if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() < 1) {
					I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					IDataValMsg = IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString();
					return false;
				}

			} catch (Exception Ex) {
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				IDataValMsg = "FAILED TO PARSE - " + Ex.getMessage();
				return false;
			}

			// Check for Field Validations in Comparing to the Database //#NYE50001 begins
			JsonObject jDbValidator = I$DBDataValidator.$validateDB_isonAnnote(i$Annotate, i$body, sMathScr, sMatchOpr);
			try {
				// Check for Field Validations Within
				if (jDbValidator.get("i-stat").getAsInt() < 1) {
					I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					JsonObject JeMsgs = jDbValidator.get("Messages").getAsJsonObject();
					int ierrCnt = 0;
					IDataValMsg = "";
					Set<Entry<String, JsonElement>> entrySet = JeMsgs.entrySet();
					String strKey, strVal;
					for (Map.Entry<String, JsonElement> entry : entrySet) {
						++ierrCnt;
						strKey = entry.getKey();
						if (ierrCnt <= 10) {
							if (ierrCnt == 1)
								IDataValMsg = strKey + "::" + JeMsgs.get(entry.getKey()).getAsString();
							else
								IDataValMsg = IDataValMsg + System.getProperty("line.separator") + strKey + "::"
										+ JeMsgs.get(entry.getKey()).getAsString();
						} else
							break;
					}
					return false;
				}
			} catch (Exception Ex) {
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				IDataValMsg = "FAILED TO PARSE - " + Ex.getMessage();
				return false;
			}

			return true; // #NYE50001 Ends
		} else {
			return true;
		}
		// Add any Other Common Validations here

	}
	
	// #MVT00117 begins
	public Boolean checkDigiRequest(JsonObject isonMsg) {
		try {
			JsonObject filtr = new JsonObject();
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");
			JsonObject iconfig = isonMsg.getAsJsonObject("i-config");
//          try {
//          filtr.addProperty("key", ibody.get("key").getAsString());
//          JsonObject digi$usr = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filtr);
//          if (!I$utils.$iStrFuzzyMatch(digi$usr.get("sessionID").getAsString(),iconfig.get("sessionID").getAsString())) {
//              return false;
//          }
//      }catch(Exception e) {
//          e.printStackTrace();
//      }
			
			if(checkRequestId(isonMsg)) {
				if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcopr").getAsString(),
						"DIGI_LOGIN")) {
					filtr.addProperty("key", ibody.get("key").getAsString());
					JsonObject digi$usr = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filtr);
					if (digi$usr == null) {
						i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
						IDataValMsg = "It looks like you are not registered on the system, please complete the registration process first before login";
						I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
						return false;
					} else { //#MVT00124 changes starts
						String loginMode = ibody.get("Mode").getAsString();
						String key = ibody.get("key").getAsString();

						if (I$utils.$iStrFuzzyMatch(loginMode, "M")) { // #SRM00040 changes start
							try {
								String userPassDecrypt = ibody.get("mpin").getAsString();
								userPassDecrypt = I$impactoUtil.generateSecurePassword(userPassDecrypt,
										digi$usr.get("msalt").getAsString());
								
								if (!I$utils.$iStrFuzzyMatch(userPassDecrypt, digi$usr.get("mpin").getAsString())) {
									int failedAttempts = digi$usr.get("noOfFailedLogins").getAsInt();
									if (failedAttempts >= 3) {
										i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
										IDataValMsg = "Too many invalid login attempts, please reset the mpin password to continue";
										
										I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
										return false;
									}
									JsonObject updateObject = new JsonObject();
									failedAttempts++;
									i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
									IDataValMsg = "Invalid Credentials." + " You have " + (3 - failedAttempts) + " attempt/attempts left";
									updateObject.addProperty("noOfFailedLogins", failedAttempts);// #MVT00119 changes
									db$Ctrl.db$UpdateRow("ICOR_M_B2U_DIGI_USERS", updateObject, filtr);	//#MVT00122 changes ends
									
									I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
									return false; // #SRM00040 changes end
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							if (digi$usr.has("logoutStatus")
									&& I$utils.$iStrFuzzyMatch(digi$usr.get("logoutStatus").getAsString(), "false")) {
								filtr.addProperty("imei", iconfig.get("imecd").getAsString());
							} else {
								return true;
							}
						}//#MVT00124 changes ends
					}
				} else if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcopr").getAsString(),
						"DIGI_UPDATESECURITYQUESTIONS")) {//SBCID1179 Changes
					filtr.addProperty("key", ibody.get("key").getAsString());
					JsonObject digi$usr = db$Ctrl.db$GetRow("ICOR_M_B2U_DIGI_USERS", filtr);
					if (digi$usr == null) {
						i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
						IDataValMsg = "It looks like you are not registered on the system, please complete the registration process first before login";
						I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
						return false;
					} else {
						return true;
					}		
				}else if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcopr").getAsString(),
						"DIGIRESET_IME")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcname").getAsString(),
								"SessionKey")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcname").getAsString(),
								"Iotp")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcopr").getAsString(),
								"DIGI_REGISTER")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcopr").getAsString(),
								"DIGIRESET_MPIN")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcname").getAsString(),
								"LABSECQU")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcname").getAsString(),
								"OABSECQU")
						|| I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("srvcname").getAsString(),
								"OABRTCNT")
					 ) {
					return true;
				} 
				else if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("screenid").getAsString(), "XEXCBRFD")
						&& I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-header").get("operation").getAsString(), "CREATE")) {
					String trncd = isonMsg.getAsJsonObject("i-body").get("trnCd").getAsString();
					if(I$utils.$iStrFuzzyMatch(trncd, "IFT") || I$utils.$iStrFuzzyMatch(trncd, "LINCU") || I$utils.$iStrFuzzyMatch(trncd, "ACH")) {
					if (isonMsg.getAsJsonObject("i-body").has("sdnCheck") && I$utils
							.$iStrFuzzyMatch(isonMsg.getAsJsonObject("i-body").get("sdnCheck").getAsString(), "N")) {
						return true;
					} else {
						if (ibody.has("otp")) {//MSA00085 changes starts
							JsonObject isonMsgOTP = OtpCntrlr.verifyOTP(ibody, isonMsg);
							if (I$utils.$iStrFuzzyMatch(
									isonMsgOTP.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(), "i-ERROR")) {
//								isonMsg.remove("i-body");
								IOTPValStat = false;
								I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
								return false;
							} //MSA00085 changes ends
						}
						i$sdnCtrl.sdnCheck(isonMsg);
						return false;
					}
					}else {
						return true;
					}

				}

				else {
					filtr.addProperty("sessionID", iconfig.get("sessionID").getAsString());
					filtr.addProperty("imei", iconfig.get("imecd").getAsString());
				}
				if (db$Ctrl.db$GetRowCnt("ICOR_M_B2U_DIGI_USERS", filtr) < 1) {
					i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
					IDataValMsg = "Member already logged in other device";
					I$SntryCntr.isonResHTPPStat = HttpStatus.NON_AUTHORITATIVE_INFORMATION;
					return false;
				}
			}else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	
		return true;
	}
	// #MVT00117 ends

	public JsonObject i$KYSRec(JsonObject isonMsg) // know You Source
	{
		try {
			String SrcID = i$ResM.getClientApp(isonMsg);
			String SrcApiKey = i$ResM.getSrcApiKey(isonMsg);
			String sMatchRec = "{\"$and\":[{\"SrcID\":\"" + SrcID + "\"},{\"SrcApiKey\":\"" + SrcApiKey + "\"},\r\n"
					+ "{\"Suspended\":\"N\"},{ $or : [ { ApiKeyisLifeTime :\"Y\" }, { \"ApiKeyValidEndDt\":{\"$gte\" : {\"$date\" :\""
					+ I$utils.$getISONow() + "\"}} } ] }]}";
			JsonObject row$det = db$Ctrl.db$GetRow("ICOR_S_EXT_SRC_MAP", sMatchRec);
			i$ResM.setGobalVals("srcJson", row$det); // #00000002 Added For Global Save
			if (row$det == null) {
				JsonParser parser = new JsonParser();
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				I$SntryCntr.isonResHTPPStat = HttpStatus.BAD_REQUEST; // #BVB00157
				return i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
						"401 UNAUTHORIZED");
			}
			;
			i$ResM.setGobalVals("srcJson", row$det); // #00000002 Added Src Json to Globals

			ArrayList<String> arrModuleList = new ArrayList<String>();
			// Now Am Checking if the Current user Has access to the Identity Module (Module
			// which is used recong the access eg AB for AM Banking
			if (!I$utils.$iStrBlank(IResManipulator.iloggedUser.get())
					&& I$utils.$iStrFuzzyMatch(row$det.get("IdentityModulesValRequired").getAsString(), "Y")) {
				if (I$utils.$iStrFuzzyMatch(row$det.get("IdentityModulesValMode").getAsString(), "A")) {
					JsonObject JIdentityModules = row$det.get("IdentityModules").getAsJsonObject();
					for (int i = 0; i < JIdentityModules.size(); i++) {
						try {
							Map<String, Object> attributes = new HashMap<String, Object>();
							Set<Entry<String, JsonElement>> entrySet = JIdentityModules.entrySet();
							String strKey, strVal;
							for (Map.Entry<String, JsonElement> entry : entrySet) {
								strKey = entry.getKey();
								strVal = JIdentityModules.get(strKey).getAsString();
								if (I$utils.$iStrFuzzyMatch(strVal, "1"))
									arrModuleList.add(strKey);
							}
						} catch (Exception ex) {

						}
					}
					;
					if (!I$utils.$iStrBlank(IResManipulator.iloggedUser.get())
							&& !db$Ctrl.db$hasModuleAccessAll(IResManipulator.iloggedUser.get(), arrModuleList)) {
						i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
						row$det = i$ResM.iHandleResStat(row$det, i$ResM.I_ERR, "403 FORBIDDEN");
					}
					;
				} else if (I$utils.$iStrFuzzyMatch(row$det.get("IdentityModulesValMode").getAsString(), "D")) {
					JsonObject JIdentityModules = row$det.get("IdentityModules").getAsJsonObject();
					for (int i = 0; i < JIdentityModules.size(); i++) {
						try {
							Set<Entry<String, JsonElement>> entrySet = JIdentityModules.entrySet();
							String strKey, strVal;
							for (Map.Entry<String, JsonElement> entry : entrySet) {
								strKey = entry.getKey();
								strVal = JIdentityModules.get(strKey).getAsString();
								if (I$utils.$iStrFuzzyMatch(strVal, "1"))
									arrModuleList.add(strKey);
							}
						} catch (Exception ex) {

						}
					}
					;
					if (!db$Ctrl.db$NoModuleAccessAll(IResManipulator.iloggedUser.get(), arrModuleList)) {
						i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
						row$det = i$ResM.iHandleResStat(row$det, i$ResM.I_ERR, "403 FORBIDDEN");
					}
					;
				}
			}
			;
			if (!valIME(row$det, isonMsg)) {
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				row$det = i$ResM.iHandleResStat(row$det, i$ResM.I_ERR,
						"ACCESS RESTRICTION - NON_AUTHORITATIVE_INFORMATION"); // BVB00157
				return row$det;
			}
			;

			if (!valIPs(row$det, isonMsg)) {
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				row$det = i$ResM.iHandleResStat(row$det, i$ResM.I_ERR,
						"ACCESS RESTRICTION - NON_AUTHORITATIVE_INFORMATION"); // BVB00157
				return row$det;
			}
			;

			if (!isClientVersionValid(row$det, isonMsg)) {
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				// #BVB00157
				I$SntryCntr.isonResHTPPStat = HttpStatus.UPGRADE_REQUIRED;
				row$det = i$ResM.iHandleResStat(row$det, i$ResM.I_ERR, "APPLICATION UPGRADE REQUIRED");
				// #BVB00157
				return row$det;
			}

			if (!isClientOsValid(row$det, isonMsg)) {
				i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
				// #BVB00157
				I$SntryCntr.isonResHTPPStat = HttpStatus.UPGRADE_REQUIRED;
				row$det = i$ResM.iHandleResStat(row$det, i$ResM.I_ERR, "APPLICATION UPGRADE REQUIRED");
				// #BVB00157
				return row$det;
			}

			return row$det;
		} catch (Exception E) {
			i$ResM.setGobalVals(i$ResM.I_SUP_LOC_MSG, false);
			JsonParser parser = new JsonParser();
			return i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
					"501 NOT-IMPLEMENTED");
		}

	};

	public boolean valIME(JsonObject row$det, JsonObject isonMsg) {
		String sIME = i$ResM.getIME(isonMsg);
		if (I$utils.$iStrFuzzyMatch(row$det.get("ImeValRequired").getAsString(), "Y")) {
			try {
				return (db$Ctrl.db$GetRowCnt("ICOR_M_B2U_DEVICES",
						"{\"Device_IMEI_Number\":\"" + sIME + "\",\"active\":\"A\",\"recordStat\":\"O\"}") > 0);
			} catch (Exception E) {
				return false;
			}
		}
		// Check for Black List
		if (db$Ctrl.db$GetRowCnt("ICOR_S_BLKLIST", "{\"Key\":\"" + sIME + "\",\"KeyType\":\"IME\"}") > 0)
			return false;

		return true;
	};

	public boolean valIPs(JsonObject row$det, JsonObject isonMsg) {
		if (I$utils.$iStrFuzzyMatch(row$det.get("IPValRequired").getAsString(), "Y")) {
			try {
				JsonObject JIPList = row$det.get("IPList").getAsJsonObject();
				Set<Entry<String, JsonElement>> entrySet = JIPList.entrySet();
				String strKey, strVal;
				for (Map.Entry<String, JsonElement> entry : entrySet) {
					strKey = entry.getKey();
					strVal = JIPList.get(strKey).getAsString();
					/*
					 * Match Types 0 - Ignore 1 - Starts With // like "IP%" 2 - Ends With // like
					 * "%IP" 3 - Contains // like "%IP%" 4 - Equals // Full Match
					 */

					if (I$utils.$iStrFuzzyMatch(row$det.get("IPValMode").getAsString(), "D")) {
						if (I$utils.$iStrFuzzyMatch(strVal, "1")) {
							if (IResManipulator.JReqheader.get().get("RemoteAddr").getAsString().startsWith(strKey))
								return false;
						} else if (I$utils.$iStrFuzzyMatch(strVal, "2")) {
							if (IResManipulator.JReqheader.get().get("RemoteAddr").getAsString().endsWith(strKey))
								return false;
						} else if (I$utils.$iStrFuzzyMatch(strVal, "3")) {
							if (IResManipulator.JReqheader.get().get("RemoteAddr").getAsString().contains(strKey))
								return false;
						} else if (I$utils.$iStrFuzzyMatch(strVal, "4")) {
							if (I$utils.$iStrFuzzyMatch(strKey,
									IResManipulator.JReqheader.get().get("RemoteAddr").getAsString()))
								return false;
						}
					} else // allowed logic
					{
						if (I$utils.$iStrFuzzyMatch(strVal, "1")) {
							if (!IResManipulator.JReqheader.get().get("RemoteAddr").getAsString().startsWith(strKey))
								return false;
						} else if (I$utils.$iStrFuzzyMatch(strVal, "2")) {
							if (!IResManipulator.JReqheader.get().get("RemoteAddr").getAsString().endsWith(strKey))
								return false;
						} else if (I$utils.$iStrFuzzyMatch(strVal, "3")) {
							if (!IResManipulator.JReqheader.get().get("RemoteAddr").getAsString().contains(strKey))
								return false;
						} else if (I$utils.$iStrFuzzyMatch(strVal, "4")) {
							if (!I$utils.$iStrFuzzyMatch(strKey,
									IResManipulator.JReqheader.get().get("RemoteAddr").getAsString()))
								return false;
						}
					}
				}
			} catch (Exception ex) {
				return false;
			}
		}
		// Check for Black List
		if (db$Ctrl.db$GetRowCnt("ICOR_S_BLKLIST", "{\"Key\":\""
				+ IResManipulator.JReqheader.get().get("RemoteAddr").getAsString() + "\",\"KeyType\":\"IP\"}") > 0)
			return false;

		return true;
	};
	// #00000002 Ends

	// #BVB00042 Starts
	public boolean ValidateSiteKey(String SiteKey) {
		try {
			// String sKey = db$Ctrl.db$GetRow("ICOR_C_SITE",
			// "{}").get("sitekey").toString();
			String sKey = db$Ctrl.db$GetRow("ICOR_C_SITE", "{'sitekey': '"+SiteKey+"'}").get("sitekey").getAsString();
		    return I$utils.$iStrFuzzyMatch(sKey, SiteKey);
		} catch (Exception e) {
			return false;
		}
	};

	private boolean ValidateToken(String token, String userId) {
		boolean isValidateToken = false;
		try {
			JsonObject filter = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValStr("sessionTracking"), "Y")) { // #BVB00210 
				// #BVB00067 Starts
				filter.addProperty("sessionId", i$ResM.getGobalValStr("sessionId"));
				filter.addProperty("userId", userId);
				// #BVB00067 Ends
				int count = db$Ctrl.db$GetCountI("ICOR_S_TOKEN_VALIDATOR", filter);
				if (count > 0) {
					isValidateToken = true;
				} else {
					isValidateToken = false;
				}
				// #BVB00210 Starts 
			} else {
				isValidateToken = true;
			}
			// #BVB00210 Ends
		} catch (Exception e) {
			logger.debug("Failed in Validate Token: " + e.getMessage());
			isValidateToken = false;
		}

		return isValidateToken;
	}

	// #BVB00043 Ends

	public boolean isClientDeviceValid(JsonObject row$det, JsonObject isonMsg) {
		boolean isClientDeviceValid = false;
		try {
			if (valIME(row$det, isonMsg)) {
				// Check if the time variance is acceptable

			}
		} catch (Exception e) {
			isClientDeviceValid = false;
		}
		return isClientDeviceValid;
	}

	public boolean isClientVersionValid(JsonObject row$det, JsonObject isonMsg) {
		boolean isClientVersionValid = false;

		try {
			if (I$utils.$iStrFuzzyMatch(row$det.get("CltVerValReq").getAsString(), "Y")) {
				String cliVer = i$ResM.getIWebVer(isonMsg);
				// #BVB00109 Starts
				if (!I$utils.$iStrFuzzyMatch(cliVer, "")) {
					if (I$utils.$iExistsInArrayJ(row$det.getAsJsonArray("CltVerAlw"), cliVer)) {
						isClientVersionValid = true;
					}
				} else {
					// #BVB00109 Ends
					isClientVersionValid = true;
				}
			} else {
				isClientVersionValid = true;
			}
		} catch (Exception e) {
			isClientVersionValid = false;
		}
		return isClientVersionValid;
	}

	public boolean isClientOsValid(JsonObject row$det, JsonObject isonMsg) {
		boolean isClientOSValid = false;

		try {
			if (I$utils.$iStrFuzzyMatch(row$det.get("CltOSValReq").getAsString(), "Y")) {
				String osVer = i$ResM.getOSVer(isonMsg);
				// #BVB00109 Starts
				if (!I$utils.$iStrFuzzyMatch(osVer, "")) {
					if (I$utils.$iExistsInArrayJ(row$det.getAsJsonArray("CltOSAlw"), osVer)) {
						isClientOSValid = true;
					}
				} else {
					// #BVB00109 Ends
					isClientOSValid = true;
				}

			} else {
				isClientOSValid = true;
			}
		} catch (Exception e) {
			isClientOSValid = false;
		}
		return isClientOSValid;
	}

	public boolean isClientTimeValid(JsonObject row$det, JsonObject isonMsg) {
		boolean isClientTimeValid = false;
		try {

		} catch (Exception e) {
			// TODO: handle exception
		}

		return isClientTimeValid;
	}
	
	public boolean checkRequestId(JsonObject isonMsg) {
		Gson gson = new Gson();
		try {
			if(I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr(isonMsg), "handShake")) {
                return true;
            }else {
            	JsonObject i$Projection = new JsonObject();
    			i$Projection.addProperty("privateKey", 1);
    			i$Projection.addProperty("checkRequestId", 1);
    			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(i$Projection));
    			if (cParam.get("checkRequestId").getAsBoolean()) {
    				String privateKey = cParam.get("privateKey").getAsString();
    				JsonObject filter =  new JsonObject();
    				JsonObject projection =  new JsonObject();
    				projection.addProperty("requestId", 1);
    				projection.addProperty("_id", 0);
    				JsonObject sessionResponse =  new JsonObject();
    				filter.addProperty("sessionId", i$ResM.getClientSessionID(isonMsg));
    				if(!I$utils.$iStrBlank(IResManipulator.iloggedUser.get())) {
    					filter.addProperty("userId", IResManipulator.iloggedUser.get());
    				}
    				sessionResponse = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", filter, projection);
    				if(I$utils.$iStrFuzzyMatch(I$impactoUtil.decrypt(i$ResM.getBodyElementS(isonMsg, "requestId"), privateKey), i$ResM.getTranId(isonMsg))){
    					if(!I$utils.$iExistsInArrayJ(sessionResponse.get("requestId").getAsJsonArray(), i$ResM.getTranId(isonMsg))){
    						JsonArray requestIdArr = new JsonArray();
                            JsonObject requestDet = new JsonObject();
                            JsonObject requestId = new JsonObject();
                            requestIdArr.add(i$ResM.getTranId(isonMsg));
                            requestId.add("$each", requestIdArr);
                            requestDet.add("requestId", requestId);
                            String requestId$Doc = gson.toJson(requestDet);
                            db$Ctrl.db$UpdateRowOperator("ICOR_S_SESSION_VALIDATOR", requestId$Doc, filter, "true", "push");
    						return true;
    					}else {
    						return false;
    					}
    				}else {
    					return false;
    				}
    			}else {
    				return true;
    			}
            }
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
// #00000001 Ends