/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil     | Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Sep 26, 2018 | #BVB00001   | 1) Log Request and Response 2) Response Handler 
      |0.1 Beta    | Vijay 		| Dec 01, 2018 | #BVB00019   | Adding Constructor 
      |0.1 Beta    | Niegil 	| Dec 14, 2018 | #BVB00031   | Adding Endpoints for mobile operations 
      |0.1 Beta    | Niegil 	| Jan 09, 2019 | #00000002   | Logger Changes 
      |0.1 Beta    | Niegil	    | Jan 15, 2019 | #00000003   | Source Code Validation FrameWork Changes  
      |0.1 Beta    | Niegil	    | Jan 21, 2019 | #00000004   | Changes for Remove Column From Response  
      |0.2.1       | Vijay 		| Jan 25, 2019 | #BVB00042   | Site Key validations moved from GenericAppController to IScreeningController
      |0.2.1       | Vijay 		| Jan 30, 2019 | #BVB00043   | Audit Login for Users
      |0.2.1       | Niegil 	| Feb 04, 2019 | #NYE00001   | Encrypt,Decrypt Global Level
      |0.2.1       | Niegil 	| Feb 09, 2019 | #NYE00049   | Reset Globals
      |0.2.1       | Vijay	 	| Feb 09, 2019 | #BVB00063   | LastActivityAt Fix 
      |0.2.1       | Vijay	 	| Feb 20, 2019 | #BVB00068   | isonMapJson Global Issue causing mising in request, made it public
      |0.2.1       | Niegil	 	| Feb 20, 2019 | #A0000001   | Changes for Error Framework
      |0.2.1       | Vijay	 	| Mar 30, 2019 | #BVB00104   | Logging variables moving to global, during response logging, msg-id will be take from global now
      |0.3.6       | Vijay   	| May 04, 2019 | #BVB00143   | Dual key pair Encrypt/Decrypt from all applications
      |0.3.8       | Vijay   	| May 10, 2019 | #BVB00149   | Session tracking at source level with encryption
      |0.3.9       | Vijay   	| May 26, 2019 | #BVB00157   | Version, OS validation will respond with Upgrade Required & Response going as object instead of Array
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes
      |0.3.16      | Vijay  	| Jul 04, 2019 | #BVB00176   | Temp debugs for file Upload issue
      |0.3.16      | Vijay  	| Jul 04, 2019 | #BVB00182   | Removing I-Match while responding as it is giving the command away to outside world 
      |0.3.17      | Vijay  	| Aug 13, 2019 | #BVB00197   | If request is Broken, Error Response instead of Internel Server Error
      |0.4.2       | Vijay  	| Sep 04, 2019 | #BVB00206   | Response Logging Else condition missing
      |3.1.0.427   | Syed       | Nov 20, 2019 | #MAQ00051   | Added Decoding code
      |3.2.5       | Vijay   	| Jan 28, 2020 | #BVB00219   | Adding Host IP Address for session storing. 
      |3.2.5       | Pappu      | Mar 06, 2021 | #PKY00002   | Code for show DataBase Connection failed if connection not establish.
      |3.2.5       | Pappu      | Oct 05, 2021 | #PKY00050   | Added condition to log request and response in Request Logger
      |3.2.5       | Manikanta  | May 22, 2023 | #MVT00116   | Added code for digi app session and imecd validations
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isentrycontroller;

import static java.util.Collections.singletonMap;
import static org.apache.commons.httpclient.HttpStatus.SC_FORBIDDEN;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.ws.rs.Consumes;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

import java.lang.reflect.Type;
import java.net.URLDecoder;
import java.security.PrivateKey;
import java.text.SimpleDateFormat;

import com.google.gson.reflect.TypeToken;
import com.mongodb.MongoClient;
import com.mongodb.TransactionOptions;
import com.mongodb.WriteConcern;
import com.mongodb.client.ClientSession;

import net.sirma.impacto.iapp.iconfig.MongoConfig;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IScreeningController;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IThreadController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.*;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;

@SuppressWarnings("unused")
@RestController
@RequestMapping("/sentryguard")
public class SentryGuardController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private IReqManipulator i$ReqM = new IReqManipulator(); // BVBCURR
	private MongoConfig i$mongoConfig = new MongoConfig();
	// private JsonObject isonMapJson = null; // #BVB00068
	// #BVB00104 Starts
	// #00000002 Starts
	// private boolean I$LargeReq = false;
	// private boolean I$LogReqAsFS = false, I$SkipLogRes = false;
	// private boolean I$LogResAsFS = false, I$SkipLogReq = false;
	// #00000002 Ends
	// #BVB00104 Ends
	private Logger logger = LoggerFactory.getLogger(SentryGuardController.class); // #00000002 - Change
	private IAppMessageHandler I$AppMessageHandler = new IAppMessageHandler(); // #A0000001

	// Class Name
	// always
	// **********************************************************************//
	public HttpStatus isonResHTPPStat = null;

	// #BVB00031 Starts
	// aperture
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/gravity", produces = MediaType.APPLICATION_JSON_VALUE)
	@Consumes("multipart/form-data") // #00000002 Changes
	public ResponseWrapper gravity(HttpServletRequest request) throws IOException {
		return aperture(request);
	}

	// knock
	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/galaxy", produces = MediaType.APPLICATION_JSON_VALUE)
	@Consumes("multipart/form-data") // #00000002 Changes
	public ResponseWrapper galaxy(HttpServletRequest request) throws IOException {
		return knock(request);
	}

	// #BVB00031 Ends

	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/knock", produces = MediaType.APPLICATION_JSON_VALUE)
	@Consumes("multipart/form-data") // #00000002 Changes
	public ResponseWrapper knock(HttpServletRequest request) throws IOException {
		try {
			// #00000003 Begin
			IScreeningController I$ScrnCntr = new IScreeningController();
			Gson gson = new GsonBuilder().serializeNulls().create();
			// #00000003 Ends
			JsonObject isonMapJson = new JsonObject(); // #BVB00068
			ResponseWrapper jResponseWrapper = null;
			JsonObject filter = new JsonObject(); 
			try {
				IResManipulator.iloggedUser.set(I$impactoUtil.getUserId(request));
				i$ResM.setHeadersInfo(request);// #00000003 Changes
				Enumeration<String> headerNames = request.getHeaderNames();
				JsonParser parser = new JsonParser();
				// #BVB00176 Starts 
				Date date = new Date();
				 // #BVB00197 Starts 
				// JsonObject isonBody =  parser.parse(request.getReader()).getAsJsonObject();
				// #MAQ00051 starts
				JsonObject isonBody = new JsonObject();
				String istrBody = new String();
				Boolean blckChar = true;
				try {
					BufferedReader rd = request.getReader();
				    String line = null;
				    while ((line = rd.readLine()) != null) {
				    	istrBody += line;
				    }
				    blckChar = I$ScrnCntr.i$NonEncChars(istrBody);
				    istrBody = istrBody.replaceAll("\\+","%2B");
				    String strReq = URLDecoder.decode((istrBody), "UTF-8");
					isonBody = parser.parse(strReq).getAsJsonObject();
					// #MAQ00051 ends
				}catch (Exception e) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - BAD REQUEST"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					//logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				
				// #BVB00197 Ends
				 //JsonObject isonBody = parser.parse(request.getReader()).getAsJsonObject();
				// #BVB00176 Ends
				JsonObject jReqHeader = getReqHeader(request, headerNames);
				/*
				 * i$ResM.setGobalVals("I$LargeReq", false); i$ResM.setGobalVals("I$LogReqAsFS",
				 * false); i$ResM.setGobalVals("I$SkipLogRes", false);
				 * i$ResM.setGobalVals("I$LogResAsFS", false);
				 * i$ResM.setGobalVals("I$SkipLogReq", false);
				 */
				
				// #MAQ00051 starts
				if (blckChar) {
					logRequest(request, isonBody, jReqHeader);
					LinkedTreeMap isonMap = i$ResM.getisonMap(i$ResM.iHandleResStat(isonBody, i$ResM.I_ERR, "INVALID REQUEST"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				};
				// #MAQ00051 ends
				
				String ScrId = i$ResM.getScreenID(isonBody);
				String SiteKey = i$ResM.getSiteKey(isonBody);
				String ScrOpr = i$ResM.getOpr(isonBody);

				// Checking Bankend Config
				// setScrisonMapJson(ScrId); // Nye Changes
				isonMapJson = setScrisonMapJson(ScrId); // #BVB00068

				// Log Request
				logRequest(request, isonBody, jReqHeader); // Nye Changes
				i$mongoConfig.createSession();
				i$ResM.setCommit();
				// Check if the Parent Is there.. if so, then add it to the global 
				if(!I$utils.$iStrBlank(i$ResM.getkeyHash(isonBody))) {
					filter.addProperty("msg-id", i$ResM.getkeyHash(isonBody));
					filter.addProperty("processed", "N");
					JsonObject parentMsg =  db$Ctrl.db$GetRow("ICOR_S_REQUEST_CONF", filter);
					i$ResM.setGobalVals("parentMsg", parentMsg.getAsJsonObject("request"));
					i$ResM.setGobalVals("parentMsgs", i$ResM.getMsgtextArr(parentMsg.getAsJsonObject("request")));
					
				}
				i$ResM.setGobalVals("request", isonBody);
				// Check Screen ID Blank
				if (I$utils.$iStrBlank(ScrId)) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN SERVICE"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;
				// #00000003 Adds

				// Check if Format OK
				if (!I$ScrnCntr.i$ReqOk(isonBody)) {

					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, I$ScrnCntr.IDataValMsg));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;

				;//#MVT00116 begins
				if (I$utils.$iStrFuzzyMatch(i$ResM.getSrcId(isonBody), "TecuDigiApp")|| (I$utils.$iStrFuzzyMatch(i$ResM.getSrcId(isonBody), "TecuDigiAppIOS"))) {
					LinkedTreeMap isonMap = null ;
					if (!I$ScrnCntr.checkDigiRequest(isonBody)) {
						if(!I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonBody),"XEXCBRFD")) {
							 isonMap = i$ResM
								.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
										i$ResM.I_ERR, I$ScrnCntr.IDataValMsg));
//						jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NON_AUTHORITATIVE_INFORMATION, null);
//						logResponse(jResponseWrapper, HttpStatus.NON_AUTHORITATIVE_INFORMATION);
//						return jResponseWrapper;
							//MSA00085 changes starts
						}else if(I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonBody),"XEXCBRFD") && I$ScrnCntr.IOTPValStat == false &&  i$ResM.getBody(isonBody).has("otp")) {
							 isonMap = i$ResM
										.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
												i$ResM.I_ERR, "OPERATION FAILED - INVALID OTP"));
						}//MSA00085 changes ends
						else {
							isonMap = i$ResM
									.getisonMap(i$ResM.iHandleResStat(i$ResM.getGobalValJObj("refrenceNoData"),
											i$ResM.I_SUCC, "Please note that the transaction has been initiated and will be reviewed by the Credit Union. Once approved, the transaction will be processed on the core banking system."));
						}
						jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NON_AUTHORITATIVE_INFORMATION, null);
						logResponse(jResponseWrapper, HttpStatus.NON_AUTHORITATIVE_INFORMATION);
						return jResponseWrapper;
					}
				} // #MVT00116 ends
				// Check if I know the Source
				JsonObject J$kys = I$ScrnCntr.i$KYSRec(isonBody);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(J$kys), i$ResM.I_ERR)) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									// #BVB00157 Starts
									// i$ResM.I_ERR, "ACCESS RESTRICTION - NON_AUTHORITATIVE_INFORMATION"));
									i$ResM.I_ERR, I$ScrnCntr.IDataValMsg));
					// #BVB00157 Ends
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NON_AUTHORITATIVE_INFORMATION, null);
					logResponse(jResponseWrapper, HttpStatus.NON_AUTHORITATIVE_INFORMATION);
					return jResponseWrapper;
				}
				;
				// #00000003 Ends

				if (isonMapJson == null) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNHANDLED OPERATION"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.METHOD_NOT_ALLOWED, null);
					logResponse(jResponseWrapper, HttpStatus.METHOD_NOT_ALLOWED);
					return jResponseWrapper;
				}
				;
				// #BVB00042 Starts
				// Check Site Key
				/*
				 * if (I$utils.$iStrBlank(SiteKey) || !ValidateSiteKey(SiteKey)) { LinkedTreeMap
				 * isonMap = i$ResM
				 * .getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).
				 * getAsJsonObject(), i$ResM.I_ERR,
				 * "ACCESS RESTRICTION - INVALID OR UNKNOWN SITE KEY")); jResponseWrapper = new
				 * ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
				 * logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
				 * return jResponseWrapper; } ;
				 */
				// #BVB00042 Ends
				// Check Screen Operation Configured
				// Screen Opr Blank ?
				if (I$utils.$iStrBlank(ScrOpr)) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN OPERATION"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.METHOD_NOT_ALLOWED, null);
					logResponse(jResponseWrapper, HttpStatus.METHOD_NOT_ALLOWED);
					return jResponseWrapper;
				}
				;
				// Operation Config ??
				JsonObject allw$Opn = new JsonObject();
				String allw$Ind = "0";
				try {
					allw$Opn = isonMapJson.getAsJsonObject("ALLW_OPRS"); // isonMapJson.get("ALLW_OPRS").getAsJsonObject();

					allw$Ind = I$utils.strip$Dquote(allw$Opn.get(ScrOpr).getAsString());
				} catch (Exception E) {
					allw$Opn = null;
					allw$Ind = "0";
				}
				if (allw$Opn == null || !I$utils.$iStrFuzzyMatch(allw$Ind, "1")) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN OPERATION"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.METHOD_NOT_ALLOWED, null);
					logResponse(jResponseWrapper, HttpStatus.METHOD_NOT_ALLOWED);
					return jResponseWrapper;
				}
				;
				// Checking Rights
				// if (db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, ScrOpr)) {
				// Forwarding Request to the Controller
				String ScrCtrlClass = getScrControllerName(isonMapJson); // #BVB00068
				logger.debug("Fowarding Request to " + ScrCtrlClass);
				LinkedTreeMap isonMap = i$ResM
						.getisonMap(isonResponse(ScrCtrlClass, isonBody, jReqHeader, isonMapJson)); // #BVB00068
				isonResHTPPStat = (isonResHTPPStat == null ? HttpStatus.OK : isonResHTPPStat);
				jResponseWrapper = new ResponseWrapper(isonMap, isonResHTPPStat, null);
				// i$ResponseLogger(isonBody);
				logResponse(jResponseWrapper, isonResHTPPStat);
				/*
				 * } else { logger.debug("User doesnot have rights"); LinkedTreeMap isonMap =
				 * i$ResM .getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).
				 * getAsJsonObject(), i$ResM.I_ERR,
				 * "ACCESS RESTRICTION - USER DOESNOT HAVE RIGHTS")); jResponseWrapper = new
				 * ResponseWrapper(isonMap, HttpStatus.UNAUTHORIZED, null);
				 * logResponse(jResponseWrapper, HttpStatus.UNAUTHORIZED); };
				 */
				return jResponseWrapper;
			} catch (Exception e) {
				e.printStackTrace();
				JsonParser parser = new JsonParser();
				LinkedTreeMap isonMap = i$ResM
						.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
								i$ResM.I_ERR, "FAILED - FAILED TO EXECUTE"));
				jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.INTERNAL_SERVER_ERROR, null);
				logResponse(jResponseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
				return jResponseWrapper;
			}
		} finally {
			i$ResM.cleanThreadLocals();// #NYE00049

		}
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(method = RequestMethod.POST, value = "/aperture", produces = "application/json")
	@Consumes("multipart/form-data") // #00000002 Changes
	public ResponseWrapper aperture(HttpServletRequest request) throws IOException {
		try {
			// #00000003 Begin
			IScreeningController I$ScrnCntr = new IScreeningController();
			DBController dbCtr= new DBController();
			Gson gson = new GsonBuilder().serializeNulls().create();
			// #00000003 Ends
			JsonObject filter = new JsonObject(); 
			JsonObject isonMapJson = new JsonObject();
			ResponseWrapper jResponseWrapper = null;
			try {
				// IResManipulator.iloggedUser.get() = null;
				i$ResM.setHeadersInfo(request);// #00000003 Changes
				Enumeration<String> headerNames = request.getHeaderNames();
				JsonParser parser = new JsonParser();
				// #BVB00176 Starts 
				//JsonObject isonBody = parser.parse(request.getReader()).getAsJsonObject();
				// #MAQ00051 starts
				JsonObject isonBody = new JsonObject();
				String istrBody = new String();
				Boolean blckChar = true;
				try {
					BufferedReader rd = request.getReader();
				    String line = null;
				    while ((line = rd.readLine()) != null) {
				    	istrBody += line;
				    }
				    blckChar = I$ScrnCntr.i$NonEncChars(istrBody);
				    istrBody = istrBody.replaceAll("\\+","%2B");
				    String strReq = URLDecoder.decode((istrBody), "UTF-8");
					isonBody = parser.parse(strReq).getAsJsonObject();				
				}catch (Exception e) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - BAD REQUEST"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					//logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				// #MAQ00051 ends
				// #BVB00176 Ends
				JsonObject jReqHeader = getReqHeader(request, headerNames);
				
				// #PKY00002 Starts
				if(!dbCtr.checkDBConnection(isonBody) ) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(i$ResM.iHandleResStat(isonBody, i$ResM.I_ERR, "DataBase Connection Failed"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				// #PKY00002 Ends
				
				// #MAQ00051 starts
				if (blckChar) {
					logRequest(request, isonBody, jReqHeader);
					LinkedTreeMap isonMap = i$ResM.getisonMap(i$ResM.iHandleResStat(isonBody, i$ResM.I_ERR, "INVALID REQUEST"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				};
				// #MAQ00051 ends
				
				// #BVB00104 Starts
				/*
				 * i$ResM.setGobalVals("I$LargeReq", false); i$ResM.setGobalVals("I$LogReqAsFS",
				 * false); i$ResM.setGobalVals("I$SkipLogRes", false);
				 * i$ResM.setGobalVals("I$LogResAsFS", false);
				 * i$ResM.setGobalVals("I$SkipLogReq", false);
				 */
				// #BVB00104 Ends
				String SrvName = i$ResM.getSrvcName(isonBody);
				String SiteKey = i$ResM.getSiteKey(isonBody);
				String SrvOpr = i$ResM.getSrvcopr(isonBody);

				// Checking Bankend Config
				// setSvrisonMapJson(SrvName);// Nye Changes // #BVB00068 commented
				isonMapJson = setSvrisonMapJson(SrvName);// #BVB00068
				logRequest(request, isonBody, jReqHeader); // Nye Changes
				i$mongoConfig.createSession();
				i$ResM.setCommit();
				// Check if the Parent Is there.. if so, then add it to the global 
				if(!I$utils.$iStrBlank(i$ResM.getkeyHash(isonBody))) {
					filter.addProperty("msg-id", i$ResM.getkeyHash(isonBody));
					filter.addProperty("processed", "N");
					JsonObject parentMsg =  db$Ctrl.db$GetRow("ICOR_S_REQUEST_CONF", filter);
					i$ResM.setGobalVals("parentMsg", parentMsg.getAsJsonObject("request"));
					i$ResM.setGobalVals("parentMsgs", i$ResM.getMsgtextArr(parentMsg.getAsJsonObject("request")));
					
				}
				i$ResM.setGobalVals("request", isonBody);
				// Check Service Allowed
				// Is Srv Name Blank
				if (I$utils.$iStrBlank(SrvName)) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN SERVICE"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;
				if (isonMapJson == null) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNHANDLED SERVICE"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;

				// #BVB00042 Starts
				/*
				 * // Check Site Key if (I$utils.$iStrBlank(SiteKey) ||
				 * !ValidateSiteKey(SiteKey)) { LinkedTreeMap isonMap = i$ResM
				 * .getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).
				 * getAsJsonObject(), i$ResM.I_ERR,
				 * "ACCESS RESTRICTION - INVALID OR UNKNOWN SITE KEY")); jResponseWrapper = new
				 * ResponseWrapper(isonMap, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED, null);
				 * logResponse(jResponseWrapper, HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
				 * return jResponseWrapper; } ;
				 */
				// #BVB00042 Ends
				// #00000003 Adds

				// Check if Format OK
				if (!I$ScrnCntr.i$ReqOk(isonBody)) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, I$ScrnCntr.IDataValMsg));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.SERVICE_UNAVAILABLE, null);
					logResponse(jResponseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
					return jResponseWrapper;
				}
				;
				;//#MVT00116 begins
				if (I$utils.$iStrFuzzyMatch(i$ResM.getSrcId(isonBody), "TecuDigiApp")
						|| (I$utils.$iStrFuzzyMatch(i$ResM.getSrcId(isonBody), "TecuDigiAppIOS"))) {
					if (!I$ScrnCntr.checkDigiRequest(isonBody)) {
						LinkedTreeMap isonMap = i$ResM
								.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
										i$ResM.I_ERR, I$ScrnCntr.IDataValMsg));
						jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.NON_AUTHORITATIVE_INFORMATION, null);
						logResponse(jResponseWrapper, HttpStatus.NON_AUTHORITATIVE_INFORMATION);
						return jResponseWrapper;
					}
				}//#MVT00116 ends
				// Check if I know the Source
				JsonObject J$kys = I$ScrnCntr.i$KYSRec(isonBody);
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(J$kys), i$ResM.I_ERR)) {
					// #BVB00157 Starts
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler
							.get$Message(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, i$ResM.getMsgtext(J$kys))));
					// BVB00157 Ends
					isonResHTPPStat = (isonResHTPPStat == null ? HttpStatus.NON_AUTHORITATIVE_INFORMATION
							: isonResHTPPStat);
					jResponseWrapper = new ResponseWrapper(isonMap, isonResHTPPStat, null);
					logResponse(jResponseWrapper, isonResHTPPStat);
					return jResponseWrapper;
				}
				;
				// #00000003 Ends

				// Check Service Operation
				// Check Opr blank
				if (I$utils.$iStrBlank(SrvOpr)) {
					LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler
							.get$Message(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN OPERATION")));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.METHOD_NOT_ALLOWED, null);
					logResponse(jResponseWrapper, HttpStatus.METHOD_NOT_ALLOWED);
					return jResponseWrapper;
				}
				;
				// Check Service Operation Configured
				JsonObject allw$Opn = new JsonObject();
				String allw$Ind = "0";
				try {
					allw$Opn = isonMapJson.get("ALLW_OPRS").getAsJsonObject();
					allw$Ind = I$utils.strip$Dquote(allw$Opn.get(SrvOpr).getAsString());
				} catch (Exception E) {
					allw$Opn = null;
					allw$Ind = "0";
				}
				if (allw$Opn == null || !I$utils.$iStrFuzzyMatch(allw$Ind, "1")) {
					LinkedTreeMap isonMap = i$ResM
							.getisonMap(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
									i$ResM.I_ERR, "ACCESS RESTRICTION - INVALID OR UNKNOWN OPERATION"));
					jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.METHOD_NOT_ALLOWED, null);
					logResponse(jResponseWrapper, HttpStatus.METHOD_NOT_ALLOWED);
					return jResponseWrapper;
				}
				;

				// Check for Rights

				// Forwarding to Controller
				// String SrvCtrlClass = getSrvControllerName(); //#BVB00068
				String SrvCtrlClass = getSrvControllerName(isonMapJson); // #BVB00068
				logger.debug("Fowarding Request to " + SrvCtrlClass);
				LinkedTreeMap isonMap = i$ResM
						.getisonMap(isonResponse(SrvCtrlClass, isonBody, jReqHeader, isonMapJson));// #BVB00068
				isonResHTPPStat = (isonResHTPPStat == null ? HttpStatus.OK : isonResHTPPStat);

				jResponseWrapper = new ResponseWrapper(isonMap, isonResHTPPStat, null);
				logResponse(jResponseWrapper, isonResHTPPStat);
				return jResponseWrapper;
			} catch (Exception e) {
				e.printStackTrace();
				JsonParser parser = new JsonParser();
				// #BVB00157 Starts
				LinkedTreeMap isonMap = i$ResM.getisonMap(I$AppMessageHandler
						.get$Message(i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(),
								i$ResM.I_ERR, "FAILED - FAILED TO EXECUTE")));
				// #BVB00157 Ends
				jResponseWrapper = new ResponseWrapper(isonMap, HttpStatus.INTERNAL_SERVER_ERROR, null);
				logResponse(jResponseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
				return jResponseWrapper;
			}
		} finally {
			i$ResM.cleanThreadLocals();// #NYE00049

		}
	}

	// #BVB00042 Starts
	/*
	 * public boolean ValidateSiteKey(String SiteKey) { try { // String sKey =
	 * db$Ctrl.db$GetRow("ICOR_C_SITE", "{}").get("sitekey").toString(); String sKey
	 * = db$Ctrl.db$GetRow("ICOR_C_SITE", "{}").get("sitekey").getAsString(); return
	 * I$utils.$iStrFuzzyMatch(sKey, SiteKey); } catch (Exception e) { return false;
	 * } };
	 */
	// #BVB00042 Ends
	// private void setScrisonMapJson(String SCRID) { //#BVB00068
	public JsonObject setScrisonMapJson(String SCRID) { // #BVB00068
		JsonObject isonMapJson = new JsonObject(); // #BVB00068
		try {
			isonMapJson = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP", "{\"SCRID\":\"" + SCRID + "\"}");
			i$ResM.setGobalVals("isonMapJson", isonMapJson);// #BVB00167
			// #00000002 Begins
			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("LOGREQASFS").getAsString(), "1"))
					// I$LogReqAsFS = true; // #BVB00104
					i$ResM.setGobalVals("I$LogReqAsFS", true);// #BVB00104
				else {
					i$ResM.setGobalVals("I$LogReqAsFS", false);// #BVB00104
				}
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$LogReqAsFS", false);// #BVB00104
			}
			;
			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("LOGRESASFS").getAsString(), "1"))
					// I$LogResAsFS = true;// #BVB00104
					i$ResM.setGobalVals("I$LogResAsFS", true);// #BVB00104
				// #BVB00206 Starts 
				else {
					i$ResM.setGobalVals("I$LogResAsFS", false);// #BVB00104
				}
				// #BVB00206 Ends
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$LogResAsFS", false);// #BVB00104
			}
			;

			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("SKIPLOGRES").getAsString(), "1"))
					// I$SkipLogRes = true;// #BVB00104
					i$ResM.setGobalVals("I$SkipLogRes", true); // #BVB00104
				// #BVB00206 Starts 
				else {
					i$ResM.setGobalVals("I$SkipLogRes", false); // #BVB00104
				}
				// #BVB00206 Ends
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$SkipLogRes", false);// #BVB00104
			}
			;

			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("SKIPLOGREQ").getAsString(), "1")) // Nye Changes
					// I$SkipLogReq = true;// #BVB00104
					i$ResM.setGobalVals("I$SkipLogReq", true);// #BVB00104
				// #BVB00206 Starts 
				else {
					i$ResM.setGobalVals("I$SkipLogReq", false);// #BVB00104
				}
				// #BVB00206 Ends
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$SkipLogReq", false);// #BVB00104
			}
			;
			// #00000002 Ends

			// #00000004 Starts
			/*
			 * // Nye Changes Begins try { JRemCols =
			 * isonMapJson.get("REMOVE_RES_COLS").getAsJsonObject(); } catch (Exception EX)
			 * { // eat; JRemCols = null; } ; // #00000004 Ends
			 */

			logger.debug("isonMapJson: " + isonMapJson);
		} catch (Exception e) {
			e.printStackTrace();
			isonMapJson = null;
		}

		return isonMapJson; // #BVB00068
	};

	private JsonObject setSvrisonMapJson(String SVRNAME) {
		JsonObject isonMapJson = new JsonObject(); // #BVB00068
		try {
			isonMapJson = db$Ctrl.db$GetRow("ICOR_C_SVR_OPR_MAP", "{\"SVRNAME\":\"" + SVRNAME + "\"}");
			i$ResM.setGobalVals("isonMapJson", isonMapJson); // #BVB00167
			// #00000002 Begins
			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("LOGREQASFS").getAsString(), "1"))
					// I$LogReqAsFS = true;// #BVB00104
					i$ResM.setGobalVals("I$LogReqAsFS", true);// #BVB00104
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$LogReqAsFS", false);// #BVB00104
			}
			;
			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("LOGRESASFS").getAsString(), "1"))
					// I$LogResAsFS = true;// #BVB00104
					i$ResM.setGobalVals("I$LogResAsFS", true);// #BVB00104
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$LogResAsFS", false);// #BVB00104
			}
			;

			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("SKIPLOGRES").getAsString(), "1"))
					// I$SkipLogRes = true;// #BVB00104
					i$ResM.setGobalVals("I$SkipLogRes", true);// #BVB00104
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$SkipLogRes", false);// #BVB00104
			}
			;

			try {
				if (I$utils.$iStrFuzzyMatch(isonMapJson.get("SKIPLOGREQ").getAsString(), "1")) // Nye Changes
					// I$SkipLogReq = true;// #BVB00104
					i$ResM.setGobalVals("I$SkipLogReq", true);// #BVB00104
			} catch (Exception EX) {
				// eat;
				i$ResM.setGobalVals("I$SkipLogReq", false);// #BVB00104
			}
			;
			// #00000002 Ends

			// #00000004 Begins
			/*
			 * try { JRemCols = isonMapJson.get("REMOVE_RES_COLS").getAsJsonObject(); }
			 * catch (Exception EX) { // eat; JRemCols = null; } ;
			 */
			// #00000004 Ends

		} catch (Exception e) {
			e.printStackTrace();
			isonMapJson = null;
		}

		return isonMapJson; // #BVB00068
	};

	private String getScrControllerName(JsonObject isonMapJson) {// #BVB00068
		try {

			String Cls = isonMapJson.get("CONTROLLER").getAsString();
			// String Cls = I$utils.strip$Dquote(isonMapJson.get("CONTROLLER").toString());
			return I$utils.$strValNullIf(Cls,
					"net.sirma.impacto.iapp.icontrollers.imodulecontrollers.GenericAppController");
		} catch (Exception e) {
			return "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.GenericAppControllerr";
		}
	};

	private String getSrvControllerName(JsonObject isonMapJson) { // #BVB00068
		try {
			String Cls = I$utils.strip$Dquote(isonMapJson.get("CONTROLLER").toString());
			return I$utils.$strValNullIf(Cls,
					"net.sirma.impacto.iapp.icontrollers.isrvccontrollers.GenericSrvcController");
		} catch (Exception e) {
			return "net.sirma.impacto.iapp.icontrollers.isrvccontrollers.GenericSrvcController";
		}
	};

	public JsonObject getReqHeader(HttpServletRequest request, Enumeration<String> headerNames) {
		Gson gson = new GsonBuilder().create();
		JsonObject jHeader = new JsonObject();
		try {
			String headerMsg = new String("{");
			while (headerNames.hasMoreElements()) {
				String headerName = headerNames.nextElement();
				String headerValue = request.getHeader(headerName);
				if (headerValue != null) {
					headerMsg = headerMsg + (String.format("{\"%s\":\"%s\"}", headerName, headerValue));
					headerMsg = headerMsg + ",";
				}
			}
			headerMsg = headerMsg + "}";
			JsonParser parser = new JsonParser();
			jHeader = parser.parse(headerMsg).getAsJsonObject();
			return jHeader;
		} catch (Exception e) {
			JsonParser parser = new JsonParser();
			jHeader = parser.parse("{}").getAsJsonObject();
			return jHeader;
		}
	}

	private JsonObject isonResponse(String clsName, JsonObject isonReqBdy, JsonObject isonReqhead,
			JsonObject isonMapJson) { // #BVB00068
		try {

			logger.debug("clsName: " + clsName);
			Class<?> ctrlClass;
			ctrlClass = Class.forName(clsName);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonReqBdy, isonReqhead, isonMapJson); // #BVB00068
			// #BVB00001 Starts
			// Adding Success Error Message to I-Stat
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-SUCC")) {
				if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
					i$ResM.iHandleResStat(result$, i$ResM.I_SUCC, i$ResM.getBodyElementS(result$, "errorMsg"));
				}
			}
			;

			// #BVB00001 Ends

			// #00000004 Changes Begin
			try {
				JsonObject JRemCols = i$ResM.getGobalValJObj("REMOVE_RES_COLS");
				if (JRemCols != null) {
					Set<Entry<String, JsonElement>> entrySet = JRemCols.entrySet();
					String strKey, strVal;
					for (Map.Entry<String, JsonElement> entry : entrySet) {
						strKey = entry.getKey();
						strVal = JRemCols.get(entry.getKey()).getAsString();
						if (I$utils.$iStrFuzzyMatch(strVal, "1"))
							i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, result$.get("i-body").getAsJsonObject(), strKey);
					}
				}
				;
			} catch (Exception e) {
				logger.debug(e.getMessage());
			}
			;
			// #00000004 Changes End
			
			try {
				JsonObject JNesRemCols = i$ResM.getGobalValJObj("REMOVE_NESTED_RES_COLS");
				if (JNesRemCols != null) {
					Set<String> keys = JNesRemCols.keySet();
					for (String key : keys) {
						if (JNesRemCols.get(key).isJsonArray() && !I$utils.$isNull(JNesRemCols.get(key))) {
							JsonArray iBodyData = result$.get("i-body").getAsJsonObject().get(key).getAsJsonArray();
							JsonArray nesArr = JNesRemCols.get(key).getAsJsonArray();
							for (int i = 0; i < nesArr.size(); i++) {
								try {
									JsonObject currentObj = nesArr.get(i).getAsJsonObject();
									Set<String> currKeys = currentObj.keySet();
									for (String currKey : currKeys) {
										String value = currentObj.get(currKey).getAsString();
										if (result$.get("i-body").getAsJsonObject().has(currKey) && I$utils.$iStrFuzzyMatch(value, "1")) {
											result$.get("i-body").getAsJsonObject().get(key).getAsJsonArray().get(i)
													.getAsJsonObject().remove(currKey);
										}
									}
								} catch (Exception e) {
								}
							}
						}
						if (JNesRemCols.get(key).isJsonObject() && !I$utils.$isNull(JNesRemCols.get(key))) {
							JsonObject nesObj = JNesRemCols.get(key).getAsJsonObject();
							JsonObject iBodyData = result$.get("i-body").getAsJsonObject().get(key).getAsJsonObject();
							Set<String> currKeys = nesObj.keySet();
							for (String currKey : currKeys) {
								String value = nesObj.get(currKey).getAsString();
								if (iBodyData.has(currKey) && I$utils.$iStrFuzzyMatch(value, "1")) {
									result$.get("i-body").getAsJsonObject().get(key).getAsJsonObject().remove(currKey);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				logger.debug(e.getMessage());
			}

			// #NYE00001 Begins
			try {
				JsonObject JRemCols = i$ResM.getGobalValJObj("ECYPT_RES_COLS");
				if (JRemCols != null) {
					Set<Entry<String, JsonElement>> entrySet = JRemCols.entrySet();
					String strKey, strVal;
					for (Map.Entry<String, JsonElement> entry : entrySet) {
						strKey = entry.getKey();
						strVal = JRemCols.get(entry.getKey()).getAsString();
						if (I$utils.$iStrFuzzyMatch(strVal, "1"))
							// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON,
							// result$.get("i-body").getAsJsonObject(),
							// strKey,I$impactoUtil.encryptPkey(result$.get("i-body").getAsJsonObject().get(strKey).getAsString()));
							// // BVB00143
							if (!I$utils.$iStrFuzzyMatch(
									result$.get("i-body").getAsJsonObject().get(strKey).getAsString(), ""))
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, result$.get("i-body").getAsJsonObject(),
										strKey, I$impactoUtil.encryptPrikey(
												result$.get("i-body").getAsJsonObject().get(strKey).getAsString()));// BVB00143
					}
				}
				;
			} catch (Exception e) {
				logger.debug(e.getMessage());
			}
			;
			// #NYE00001 Ends
			try {
				JsonObject JNesRemCols = i$ResM.getGobalValJObj("ECYPT_NESTED_RES_COLS");
				if (JNesRemCols != null) {
					Set<String> keys = JNesRemCols.keySet();
					for (String key : keys) {
						if (JNesRemCols.get(key).isJsonArray() && !I$utils.$isNull(JNesRemCols.get(key))) {
							JsonArray iBodyData = result$.get("i-body").getAsJsonObject().get(key).getAsJsonArray();
							JsonArray nesArr = JNesRemCols.get(key).getAsJsonArray();
							for (int j = 0; j < iBodyData.size(); j++) {
								for (int i = 0; i < nesArr.size(); i++) {
									try {
										JsonObject currentObj = nesArr.get(i).getAsJsonObject();
										Set<String> currKeys = currentObj.keySet();
										for (String currKey : currKeys) {
											try {
												String value = currentObj.get(currKey).getAsString();
												if (I$utils.$iStrFuzzyMatch(value, "1")) {
													if (iBodyData.get(j).getAsJsonObject().has(currKey)
															&& !I$utils.$iStrFuzzyMatch(iBodyData.get(j)
																	.getAsJsonObject().get(currKey).getAsString(),
																	"")) {
														result$.get("i-body").getAsJsonObject().get(key)
																.getAsJsonArray().get(j).getAsJsonObject()
																.addProperty(currKey,
																		I$impactoUtil.encryptPrikey(
																				iBodyData.get(j).getAsJsonObject()
																						.get(currKey).getAsString()));
													}
												}
											} catch (Exception e) {}
										}
									} catch (Exception e) {}
								}
							}
						}
						if (JNesRemCols.get(key).isJsonObject() && !I$utils.$isNull(JNesRemCols.get(key))) {
							JsonObject nesObj = JNesRemCols.get(key).getAsJsonObject();
							JsonObject iBodyData = result$.get("i-body").getAsJsonObject().get(key).getAsJsonObject();
							Set<String> currKeys = nesObj.keySet();
							for (String currKey : currKeys) {
								String value = nesObj.get(currKey).getAsString();
								if (I$utils.$iStrFuzzyMatch(value, "1")) {
									if (iBodyData.has(currKey)
											&& !I$utils.$iStrFuzzyMatch(iBodyData.get(currKey).getAsString(), "")) {
										result$.get("i-body").getAsJsonObject().get(key).getAsJsonObject()
												.addProperty(currKey, I$impactoUtil.encryptPrikey(
														iBodyData.getAsJsonObject().get(currKey).getAsString()));
									}
								}
							}
						}
					}
				}
			} catch (Exception e) {
				logger.debug(e.getMessage());
			}

			// #A0000001 Build the Message
			I$AppMessageHandler.get$Message(result$);
			
			// Need to change this somehow.. 
//			if (I$utils.$iStrFuzzyMatch(i$ResM.getTCLStatus(), "C")) {
//				i$mongoConfig.commitSession();
//			} else {
//				i$mongoConfig.abortSession();
//			}
			
			// Setting the same header as request 
			
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, result$, i$ResM.I_HEADER, i$ResM.getGobalValJObj("i-header")); 
 	
			
			 try {
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), i$ResM.I_SUCC)) {
				i$mongoConfig.commitSession();
			} else {
				i$mongoConfig.abortSession();
			}
			 }catch (Exception e) {
				
			}
			 
			// Check if the RequestConf is true.. if so insert into the capped collection
			// for follow up request.
			if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValStr("RequestConf"), "Y")) {
				JsonObject reqConf = new JsonObject();
				reqConf.addProperty("msg-id", i$ResM.getMsgID(result$));
				reqConf.add("request", result$);
				reqConf.addProperty("processed", "N"); 
				db$Ctrl.db$InsertRow("ICOR_S_REQUEST_CONF", reqConf);
			}

			// if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$),i$ResM.I_SUCC)) {
			// i$mongoConfig.commitSession();
//			}else if(I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$),i$ResM.I_ERR) ||
//					I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$),i$ResM.I_WRN)) {
//				i$mongoConfig.abortSession(); 
//			}
			result$.remove(i$ResM.I_CONF); 
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, result$, i$ResM.I_MATCH, "{}");
			return result$;
		} catch (Exception e) {
			e.printStackTrace();
			JsonParser parser = new JsonParser();
			return i$ResM.iHandleResStat(parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject(), i$ResM.I_ERR,
					"FAILED - FAILED TO EXECUTE");
		}
	};

	public void logRequest(HttpServletRequest request, JsonObject isonBody, JsonObject isonHeader) throws IOException { // #00000003
		
		try {
			
		
		JsonObject filter = new JsonObject();
		JsonObject setter = new JsonObject();
																											// Changed
		// #BVB00063 Starts
		// String sessionId = i$ResM.getGobalValStr("sessionId");
		String sessionId = i$ResM.getConfigElementS(isonBody, "sessionID");
		filter.addProperty("SrcID", i$ResM.getConfigElementS(isonBody, "SrcID"));
		JsonObject row$det = db$Ctrl.db$GetRow("ICOR_S_EXT_SRC_MAP", filter);
		i$ResM.setGobalVals("srcJson", row$det); // #00000002 Added For Global Save
		// #BVB00063 Ends																										// //
																														// Public

		// #00000002 Begins
		// if (I$SkipLogReq) {// #BVB00104
		try {
		if (i$ResM.getGobalValBol("I$SkipLogReq")) {// #BVB00104
			return;
		};
		} catch(Exception e) {}
		// #00000002 Ends
		// #BVB00001 Starts
		JsonObject up$, up$bdy = null;
		JsonObject i$request = new JsonObject();
		Gson gson = new Gson();
		long objBodySize = request.getContentLengthLong(); // #00000002 Add
		// #BVB00001 Ends
		// if ((objBodySize > 0 && objBodySize < 1000000) && logger.isDebugEnabled() &&
		// (!I$LogReqAsFS)) {// #BVB00104
		if ((objBodySize > 0 && objBodySize < 100000) && logger.isDebugEnabled()
				&& (!i$ResM.getGobalValBol("I$LogReqAsFS"))) {// #BVB00104
			logger.debug("===========================request begin================================================");
			logger.debug("URI         : {}", request.getRequestURI());
			logger.debug("Method      : {}", request.getMethod());
			logger.debug("Headers     : {}", gson.toJson(isonHeader));
			logger.debug("Request body: {}", gson.toJson(isonBody));
			logger.debug("==========================request end================================================");
		}
		;
		// #BVB00001 Starts
		i$request.addProperty("msg-id", i$ResM.getMsgID(isonBody));
		i$request.addProperty("userId", I$utils.$strValNullIf(IResManipulator.iloggedUser.get(), "")); // #BVB00043
		i$request.add("requestInTime", i$ResM.addDateTime(new Date()));
		// #BVB00001 Ends
		// #00000002 Begin
		// if (objBodySize < 0 || objBodySize > 1000000 || I$LogReqAsFS) {// #BVB00104
		if (objBodySize < 0 || objBodySize > 10000000 || i$ResM.getGobalValBol("I$LogReqAsFS")) {// #BVB00104 //10MB
			i$request.addProperty("MsgData", gson.toJson(isonBody));
			up$ = db$Ctrl.db$GrdFSReqUpld(i$request);
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, up$, "MsgData");
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, up$, "i-stat");
			i$request.addProperty("requestLocateToken", up$.get("MsgLocateToken").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, i$request, "MsgLocateToken");
			JsonObject reqBody = new JsonObject();  //#PKY00050 starts
			reqBody = isonBody.get("i-body").getAsJsonObject();
			long iBodySize = reqBody.toString().length();
			JsonObject ison$Body = new JsonObject();
			ison$Body = isonBody.deepCopy();
			ison$Body.remove("i-body");
			i$request.add("request", ison$Body);//#//#PKY00050 ends
			i$request.addProperty("RemoteHost", request.getRemoteHost()); // #BVB00219
			JsonObject jWrkArgs = new JsonObject(); 
			JsonObject isonMsg = new JsonObject(); 
			isonMsg.addProperty("collectionName", "ICOR_M_REQUEST_LOGGER");
			isonMsg.add("i$request", i$request);
			isonMsg.addProperty("type", "Req");
			jWrkArgs.add("isonMsg", isonMsg);
 			jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController");
			jWrkArgs.addProperty("funcName", "updateRequestLogger");
			jWrkArgs.add("globals", i$ResM.getAllGobal());
				
			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker); 
			t.start(); 
			
			//up$ = db$Ctrl.db$InsertRow("ICOR_M_REQUEST_LOGGER", i$request);
			// I$LargeReq = true; // #00000002 adds// #BVB00104
			i$ResM.setGobalVals("I$LargeReq", true);// #BVB00104
		} else {
			// #BVB00001 Starts
			i$request.add("request", isonBody);
			i$request.addProperty("requestLocateToken", "Self");
			i$request.addProperty("RemoteHost", request.getRemoteHost());// #BVB00219
			JsonObject jWrkArgs = new JsonObject(); 
			JsonObject isonMsg = new JsonObject(); 
			isonMsg.addProperty("collectionName", "ICOR_M_REQUEST_LOGGER");
			isonMsg.add("i$request", i$request);
			
			isonMsg.addProperty("type", "Req");
			jWrkArgs.add("isonMsg", isonMsg);
 			jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController");
			jWrkArgs.addProperty("funcName", "updateRequestLogger");
			jWrkArgs.add("globals", i$ResM.getAllGobal());
				
			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker); 
			t.start(); 
			
			//up$ = db$Ctrl.db$InsertRow("ICOR_M_REQUEST_LOGGER", i$request);

			// #BVB00001 Ends
			// I$LargeReq = false; // #00000002 adds// #BVB00104
			i$ResM.setGobalVals("I$LargeReq", false);// #BVB00104
		}
		;
		// #00000002 End

		// #BVB00043 Starts
		// Update the session Activity
		if (IResManipulator.iloggedUser.get() != null) {
		
			// if (sessionId != null ){
			if (sessionId != null && I$utils
					.$iStrFuzzyMatch(I$impactoUtil.decrypt(row$det.get("SessionTrackReq").getAsString()), "Y")) { // BVB00149
				filter = new JsonObject();
				filter.addProperty("sessionId", sessionId);
				setter.add("lastActivityAt", i$ResM.addDateTime(new Date()));
				db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", setter, filter);
			}
		}
		} catch (Exception e) {
			logger.debug("Failed in Logging the request with: " + e.getMessage());
		}
		// #BVB00043 Ends
	}
	 
	public void logResponse(ResponseWrapper response, HttpStatus HttpStat) throws IOException { // #00000003 Changed
																								// AccessSpecifiers to
				try {																				// Public
		// #00000002 Begins
		// if (I$SkipLogRes) {// #BVB00104
		if (i$ResM.getGobalValBol("I$SkipLogRes")) {// #BVB00104
			return;
		}
		;
		// #00000002 Ends
		// #BVB00001 Starts
		JsonObject up$, isonBody = null;
		JsonObject i$response = new JsonObject();
		// #BVB00001 Ends
		// if (!I$LargeReq && logger.isDebugEnabled() && !I$LogResAsFS) {// #BVB00104
		if (!i$ResM.getGobalValBol("I$LargeReq") && logger.isDebugEnabled() && !i$ResM.getGobalValBol("I$LogResAsFS")) {// #BVB00104
			logger.debug("============================response begin==========================================");
			logger.debug("Status code  : {}", HttpStat.value());
			logger.debug("Status text  : {}", HttpStat.toString());
			logger.debug("Response body: {}", response.getData());
			logger.debug("=======================response end=================================================");
		}
		;

		// #BVB00001 Starts
		Gson gson = new GsonBuilder().serializeNulls().create();
		JsonParser parser = new JsonParser();
		isonBody = parser.parse(gson.toJson(response.getData())).getAsJsonObject();
		// i$response.add("response", isonBody);//#00000002 Changes
		i$response.add("responseOutTime", i$ResM.addDateTime(new Date()));
		// #00000002 Begin
		// if (I$LargeReq || I$LogResAsFS) {// #BVB00104
		if (i$ResM.getGobalValBol("I$LargeReq") || i$ResM.getGobalValBol("I$LogResAsFS")) {// #BVB00104
			i$response.addProperty("msg-id", i$ResM.getMsgID(isonBody));
			i$response.addProperty("MsgData", gson.toJson(isonBody));
			up$ = db$Ctrl.db$GrdFSReqUpld(i$response);
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, up$, "MsgData");
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, up$, "i-stat");
			i$response.addProperty("responseLocateToken", up$.get("MsgLocateToken").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, i$response, "MsgLocateToken");
			JsonObject resBody = new JsonObject();  //#PKY00050 starts
			resBody = isonBody.get("i-body").getAsJsonObject();
			long iBodySize = resBody.toString().length();			
			JsonObject ison$Body = new JsonObject();
			ison$Body = isonBody.deepCopy();
			ison$Body.remove("i-body");
			i$response.add("response", ison$Body);  ////#PKY00050 ends
			JsonObject jWrkArgs = new JsonObject(); 
			JsonObject isonMsg = new JsonObject(); 
			isonMsg.addProperty("collectionName", "ICOR_M_REQUEST_LOGGER");
			isonMsg.add("i$response", i$response);
			isonMsg.addProperty("query",  "{\"msg-id\":\"" + i$ResM.getMsgID(isonBody) + "\"}");
			
			isonMsg.addProperty("type", "Resp");
			jWrkArgs.add("isonMsg", isonMsg);
 			jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController");
			jWrkArgs.addProperty("funcName", "updateRequestLogger");
			jWrkArgs.add("globals", i$ResM.getAllGobal());
				
			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker); 
			t.start(); 
			
//			up$ = db$Ctrl.db$UpdateRow("ICOR_M_REQUEST_LOGGER", i$response,
//					"{\"msg-id\":\"" + i$ResM.getMsgID(isonBody) + "\"}");
		} // #00000002 End
		else {
			String msgId ;
			try {
				msgId = i$ResM.getGobalValJObj("i-header").get("msg-id").getAsString();
			} catch(Exception e) {
				msgId = i$ResM.getMsgID(isonBody);
			}
			// #BVB00001 Starts
			i$response.add("response", isonBody);
			i$response.addProperty("responseLocateToken", "Self");

			JsonObject jWrkArgs = new JsonObject(); 
			JsonObject isonMsg = new JsonObject(); 
			isonMsg.addProperty("collectionName", "ICOR_M_REQUEST_LOGGER");
			isonMsg.add("i$response", i$response);
			isonMsg.addProperty("query",  "{\"msg-id\":\"" + msgId + "\"}");
			isonMsg.addProperty("type", "Resp");
			
			jWrkArgs.add("isonMsg", isonMsg);
 			jWrkArgs.addProperty("clsName", "net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController");
			jWrkArgs.addProperty("funcName", "updateRequestLogger");
			jWrkArgs.add("globals", i$ResM.getAllGobal());
				
			IThreadController IThread$worker = new IThreadController(jWrkArgs);
			Thread t = new Thread(IThread$worker); 
			t.start(); 
			
//			up$ = db$Ctrl.db$UpdateRow("ICOR_M_REQUEST_LOGGER", i$response,
//					 "{\"msg-id\":\"" + msgId + "\"}");
					//"{\"msg-id\":\"" + i$ResM.getGobalValJObj("i-header").get("msg-id").getAsString() + "\"}");// #BVB00104
			// #BVB00001 Ends
		}
		// #BVB00001 Ends
				} catch (Exception e) {
					logger.debug("Failed in Logging the response with: " + e.getMessage());
				}
	}

	public JsonObject updateRequestLogger(JsonObject isonMsg) {
		try {
			String type = i$ResM.getStrfromObj(isonMsg, "type");
			if(I$utils.$iStrFuzzyMatch(type, "Resp")) {
			JsonObject response = i$ResM.getObjfromObj(isonMsg, "i$response"); 
			String collectionName = i$ResM.getStrfromObj(isonMsg, "collectionName");
			String query = i$ResM.getStrfromObj(isonMsg, "query");
			
			return db$Ctrl.db$UpdateRow(collectionName, response, query);
			}else {
				JsonObject i$request = i$ResM.getObjfromObj(isonMsg, "i$request"); 
				String collectionName = i$ResM.getStrfromObj(isonMsg, "collectionName");
				JsonObject filter = new JsonObject(); 
				filter.addProperty("msg-id", i$request.get("msg-id").getAsString());
				
			//return db$Ctrl.db$InsertRow(collectionName, i$request);
				return db$Ctrl.db$UpdateRow(collectionName, i$request, filter, "true");
			}
			
		} catch (Exception e) {
			return null;
		}
		
	}
	
	// #BVB00036 Starts
	private JsonObject getAnnotate(String ScrId, String ScrOpr) {
		JsonObject i$Annotate = new JsonObject();
		try {
			i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR", "{\"ANNOTATION\":\"" + ScrId + "_" + ScrOpr + "\"}");

		} catch (Exception e) {
			i$Annotate = null; 
		}
		return i$Annotate;
	}

	private String getSessionKey(String sessionId) {
		String i$privateKey = "";
		JsonObject filter = new JsonObject();
		// PrivateKey privateKey;
		// byte[] privateKeyB ;
		try {
			filter.addProperty("sessionId", sessionId);
			i$privateKey = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", filter).get("privateKey").getAsString();
			// privateKeyB = I$impactoUtil.base64Decode(i$privateKey);

			// privateKey = i$RSAAsy.getPrivate(privateKeyB, 1);

		} catch (Exception e) {
			// e.printStackTrace();
			logger.debug("Failed with error: " + e.getMessage());
			i$privateKey = null;
		}

		return i$privateKey;

	}

	// #BVB00036 Ends
	// Dashboard Response Logger
//	public void i$ResponseLogger(JsonObject isonMsg) // Logging the response to dashboard coll
//	{
//
//		JsonObject res$logger = new JsonObject();
//
//		String scrId = null;
//		String ScrOpr = null;
//		String operation = null;
//		String Opr1 = null;
//		String Opr2 = null;
//		String Opr3 = null;
//		String SOpr = null;
//		String Scr = null;
//		String scr$identity = null;
//		String userId = null;
//		String ScrnId = null;
//		String getMsgtext = null;
//
//		JsonObject i$body = i$ResM.getBody(isonMsg);
//		if (i$body != null) {
//
//		} else {
//			try {
//				com.google.gson.JsonArray i$arry = isonMsg.get("i-body").getAsJsonArray();
//				i$body = i$arry.get(0).getAsJsonObject();
//			} catch (Exception e) {
//				// pass
//			}
//
//		}
//		// Checking if the request is from Knock or Aperture
//		try {
//
//			if (IResManipulator.JReqheader.get().get("RequestURI").getAsString().contains("knock")
//					|| IResManipulator.JReqheader.get().get("RequestURI").getAsString().contains("galaxy")) {
//				try {
//					scrId = i$ResM.getGobalValStr("screenid");
//				} catch (Exception e) {
//					// pass
//				}
//				;
//				try {
//					userId = IResManipulator.iloggedUser.get();
//				} catch (Exception e) {
//					// pass
//				}
//				;
//				try {
//					ScrOpr = i$ResM.getSrvcopr(isonMsg);
//				} catch (Exception e) {
//					ScrOpr = null;
//				}
//				;
//
//				try {
//					operation = i$ResM.getOpr(isonMsg);
//				} catch (Exception e) {
//					// pass
//				}
//				try {
//					Opr1 = i$ResM.getOpr1(isonMsg);
//				} catch (Exception e) {
//					// pass
//				}
//				;
//				try {
//					Opr2 = i$ResM.getOpr2(isonMsg);
//				} catch (Exception e) {
//					// pass
//				}
//				;
//				try {
//					Opr3 = i$ResM.getOpr2(isonMsg);
//				} catch (Exception e) {
//					// pass
//				}
//				;
//				try {
//					ScrnId = i$ResM.getScreenID(isonMsg);
//				} catch (Exception e) {
//					// pass
//				}
//				;
//				try {
//					getMsgtext = i$ResM.getMsgtext(isonMsg);
//				} catch (Exception e) {
//					// pass
//				}
//				;
//
//				// check if the screen id's are not in dash board logger No list
//				// scrId.startsWith("X") ||
//
//				if (scrId.startsWith("L") || scrId.startsWith("W")) {
//					return;
//				} else {
//					// Construc the upsert Query
//					JsonObject dsh$fltr = new JsonObject();
//					String i$strKey = null;
//					String pKey = null;
//
//					JsonObject i$key = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP", "{\"SCRID\":\"" + scrId + "\"}");
//					try {
//						JsonArray i$match = i$key.get("I_MATCH").getAsJsonArray();
//						i$strKey = i$match.get(0).getAsString();
//					} catch (Exception e) {
//						// pass
//					}
//					JsonObject dsh$bdy = new JsonObject();
//					try {
//						dsh$fltr.addProperty(i$strKey, i$body.get(i$strKey).getAsString());
//					} catch (Exception e) {
//						dsh$fltr.addProperty(i$strKey, "None");
//					}
//					dsh$fltr.addProperty("SCRID", ScrnId);
//					if (ScrOpr != null) {
//						dsh$fltr.addProperty("SCROPR", ScrOpr);
//					}
//					try {
//						if (ScrOpr != null && !ScrOpr.equals("")) {
//							pKey = ScrnId + "~" + ScrOpr + "~" + i$strKey;
//						} else {
//							pKey = ScrnId + "~" + operation + "~" + i$strKey;
//						}
//						dsh$fltr.addProperty("USERID", userId);
//						dsh$bdy.addProperty(i$strKey, i$body.get(i$strKey).getAsString());
//						dsh$bdy.addProperty("USERID", userId);
//						dsh$bdy.addProperty("SCRID", ScrnId);
//						dsh$bdy.addProperty("SCROPR", ScrOpr);
//						dsh$bdy.addProperty("OPERATION", operation);
//						dsh$bdy.addProperty("OPR1", Opr1);
//						dsh$bdy.addProperty("OPR2", Opr2);
//						dsh$bdy.addProperty("OPR3", Opr3);
//						dsh$bdy.addProperty("pKey", pKey);
//						dsh$bdy.addProperty("LATESTSTATUS", getMsgtext);
//						dsh$bdy.add("UPDATEDATE", i$ResM.adddate(new Date()).getAsJsonObject());
//						db$Ctrl.db$UpdateRow("ICOR_M_DASHBOARD", dsh$bdy, dsh$fltr, "true");
//
//					} catch (Exception e) {
//						// pass
//					}
//
//				}
//			} // Screen Id loop ends
//		} catch (Exception e) {
//			e.printStackTrace();
//			// pass
//		}
//		return;
//
//	}

	// #BVB00019 Starts
	public SentryGuardController() {
		// Constructor
	}
	// #BVB00019 Ends
}

// #00000001 Begins