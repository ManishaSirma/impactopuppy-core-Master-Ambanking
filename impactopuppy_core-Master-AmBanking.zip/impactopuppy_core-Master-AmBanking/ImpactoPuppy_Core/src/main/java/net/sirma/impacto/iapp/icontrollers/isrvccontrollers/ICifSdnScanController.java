/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      1.0.0.1      | Pappu      | 14-Dec-2021  | #PKY00065    | Initial writing
      1.0.0.1      | Manikanta  | 16-Feb-2022  | #MVT00035 	  | Added code for member name update in scanning
      1.0.0.1	   | Manikanta  | 23-Feb-2022  | #MVT00036    | Added code to update the scanning status
      1.0.0.1      | Manikanta  | 25-Feb-2022  | #MVT00037    | Added code for not applicable member name
      1.0.0.1	   | Manikanta  | 02-Mar-2022  | #MVT00038	  | Added code to store data in temporary collection
      1.0.0.1	   | Manikanta  | 08-Mar-2022  | #MVT00044    | Added code to upload the data in fs files
      1.0.0.1 	   | Manikanta  | 10-Mar-2022  | #MVT00045    | Added code to cif  and Risc scan download scanned data
      1.0.0.1	   | Manikanta  | 10-Mar-2022  | #MVT00046    | Added code for screen id and operation
      1.0.0.1	   | Manikanta  | 18-Mar-2022  | #MVT00047	  | Added code to update status for each thread in collection
      1.0.0.1      | Manikanta  | 18-Mar-2022  | #MVT00048    | Added code To update each thread scanned data
      1.0.0.1	   | Manikanta  | 18-Mar-2022  | #MVT00049    | Added code to handle failed data in scanning
      1.0.0.1	   | Manikanta  | 23-Mar-2022  | #MVT00050    | Added code to to change namings of array
      1.0.0.1	   | Manikanta  | 12-Apr-2022  | #MVT00051	  | Added code for whitelist member validation
      1.0.0.1	   | Manikanta  | 13-Apr-2022  | #MVT00052	  |	Added code to add scan result in collection
      1.0.0.1      | Manikanta  | 14-Apr-2022  | #MVT00053	  | Added code to store in new collection and creating indexes for those colections
      1.0.0.1	   | Manikanta  | 21-Apr-2022  | #MVT00054	  | Added code to update customer status and to add whitelist members
      1.0.0.1	   | Manikanta  | 27-Apr-2022  | #MVT00055    | Added code for getting count data of scanned records
      1.0.0.1	   | Manikanta  | 25-May-2022  | #MVT00059    | Added code to call customer risc profiling function
	  1.0.0.1	   | Manikanta  | 01-Jun-2022  | #MVT00060	  | added code to handle single customer view data in risc profiling
	  1.0.0.1      | Pappu      | 08-Jun-2022  | #PKY00074    | handled add_to_blacklist for blackListed members.
	  1.0.0.1      | Pappu      | 09-Jun-2022  | #PKY00075    | Handled blacklisted member in kyc check.
	  1.0.0.1	   | Manikanta  | 13-Jun-2022  | #MVT00061	  | Added code for Release the Hold Applications
	  1.0.0.1 	   | Manikanta  | 13-Jun-2022  | #MVT00062    | Added code to avoid functionalities for Hold Applications
      1.0.0.1      | Pappu      | 16-Jun-2022  | #PKY00077    | handled KYC job view API issue.
      1.0.0.1      | Samadhan   | 13-Jul-2022  | #SRP00075    | Added Code for Sdn Scanning Alert and Notification
      1.0.0.1      | Sindhu     | 16-Jun-2023  | #SRM00044    | Added Code for fetching total scanned records
      1.0.0.1      | Pavithra   | 08-Aug-2023  | #PAV00012    | Added Opr3 field validation and called exportSummaryData
      1.0.0.1	   | Manikanta  | 11-Aug-2023  | #MVT00135    | Added code to handle sdn scan namings
      1.0.0.1      | Srikanth   | 26-SEP-2023  | #SRI00006    | Added Opr3 field validation for the exportSummaryData     
      1.0.0.1       | Pavithra   | 28-Sep-2023  | #PAV00017    | Handled Changes of 12 parameters of KYC_AML Changes 
      1.0.0.1      | Pavithra   | Oct 06, 2023 | #PAV00019   | Risk Profiling job optimization changes
      1.0.0.1      | Sindhu     | 09-Oct-2023  | #SRM00061    | Handled Changes KYC JOB summary screen 
      1.0.0.1      | Sindhu     | 09-Oct-2023  | #SRM00063    | Handled code changes for data set filter 
      1.0.0.1      | Sindhu     | 27-OCT-2023  | #SRM00067    | Handled code to trigger email for KYM and riskprofiling jobs
      1.0.0.1      | Sindhu     | 06-Nov-2023  | #SRM00072    | Handled code for failed CIF array  in KYM job details summary
      1.0.0.1      | Srikanth   | 06-Nov-2023  | #SRI00018    | Handled code for the PC and The FY for the Reports.
      1.0.0.1      | Pavithra   | Nov 15, 2023 | #PAV00022    | Handled code for AddtoWhitelist and AddtoBlackList 
      1.0.0.1      | Pavithra   | Nov 17, 2023 | #PAV00023    | Handled response fields for KYM Checks summary
      1.0.0.1      | Pavithra   | Nov 20, 2023 | #PAV00025    | Handled Total item field in kym check details
      1.0.0.1      | Pavithra   | Nov 24, 2023 | #PAV00027    | Handled code for Member Ignore Once, Member Hold and Member Release for cifsdnscan job
      1.0.0.1      | Srikanth   | Mar 05, 2024 | #SRI00038    | Handled code for  Added Code for Sdn Scanning Alert and Notification
      ----------------------------------------------------------------------------------------------
      
*/

package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.GenericAppController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IKYCController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRepoController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IThreadController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICifSdnScanController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(ICifSdnScanController.class);
//	private IRepoController i$irepoCtrl = new IRepoController(); //PAV00019 Changes
	private DBController db$Ctrl = new DBController();
	private Ioutils i$outis = new Ioutils();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
//	private SdnScanController I$sdn = new SdnScanController(); //PAV00019 Changes
	private Ioutils I$Ioutils = new Ioutils();//#SRP00075 Starts
	private IEmailService i$Email = new IEmailService();
	private ISmsService I$ISmsService = new ISmsService();//#SRP00075 Ends
	private IResPreFlightHandler  i$preflight = new IResPreFlightHandler();
	private IKYCController i$kyc = new IKYCController();
	private GenericAppController i$genericCntrlr = new GenericAppController();
	private IFuncSrvcController srvcFunction = new IFuncSrvcController();
	private IMbpmContorller imbpm = new IMbpmContorller();

	// ##PKY00065 starts
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
	    try {
	        String SvrOpr = i$ResM.getSrvcopr(isonMsg);
	        String SvrName = i$ResM.getSrvcName(isonMsg);
	        String SOpr = i$ResM.getOpr(isonMsg);	//#MVT00046 changes starts
	        String Scr = i$ResM.getScreenID(isonMsg);
	        String SrvOpr = i$ResM.getSrvcopr(isonMsg);//#SRP00075 Starts
			String Opr3 = i$ResM.getOpr3(isonMsg);//#PAV00012 Changes
	        if (I$utils.$iStrFuzzyMatch(SvrName, "cifSdnScan") && I$utils.$iStrFuzzyMatch(SvrOpr, "CREATE")) {
	            isonMsg = CreateCifSdnScan(isonMsg);
	        } else if(I$utils.$iStrFuzzyMatch(Scr, "SB2DWLND") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")){
	        	isonMsg = fsDownload(isonMsg);	//#MVT00046 changes ends
	        	if(I$utils.$iStrFuzzyMatch(Opr3, "export")||(I$utils.$iStrFuzzyMatch(Opr3, "exportCsv"))){//#PAV00012 Changes starts  //SRI00006 Changes
	        		isonMsg = i$preflight.exportSummaryData(isonMsg);
	        	}//#PAV00012 Changes ends
	        }else if(I$utils.$iStrFuzzyMatch(Scr, "OB2MUPDT") && I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {	//#MVT00054 changes
	        	updateMemberStatus(isonMsg);
	        }else if(I$utils.$iStrFuzzyMatch(Scr, "OB2GTDAT") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {	//#MVT00055 changes
	        	getCountData(isonMsg);
	        }else if(I$utils.$iStrFuzzyMatch(Scr, "OB2CSTVW") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {	//#MVT00060 changes
	        	getMember(isonMsg);
	        }else if (I$utils.$iStrFuzzyMatch(SrvOpr, "SDN_REPORT")) {//#SRP00075 Starts
				isonMsg = sdnScanningReport(isonMsg);//#SRP00075 Ends
			}else if(I$utils.$iStrFuzzyMatch(Scr, "SB2DLSCN") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {	//#SRM00060 changes
	        	scanSummary(isonMsg);
			}else{
	            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
	        }
	    } catch (Exception e) {
	        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
	        e.printStackTrace();
	        return isonMsg;
	    }
	    return isonMsg;
	}
	//#MVT00045 starts
	public JsonObject fsDownload(JsonObject isonMsg) {
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			Gson gson = new Gson();
			int intPgNo, intRecs;
			String sort = "{'_id':-1}";
			try {
				intPgNo = ibody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = ibody.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 0; //#PAV00014 Changes
			}
			JsonObject proj = new JsonObject();
			JsonObject flter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject projtion = new JsonObject();
			JsonObject count = new JsonObject();
			String modelClass = ibody.get("ScanResult").getAsString();
			//To handle risc scan view summary screen data
			if (I$utils.$iStrFuzzyMatch(ibody.get("scanType").getAsString(), "RiskProfiling")) {
				try {
					proj.addProperty("_id", 0);
					proj.addProperty("CustomerId", 1);
					proj.addProperty("CustomerFullName", 1);
					proj.addProperty("MODEL_CLASS", 1);
					proj.addProperty("BranchName", 1);
					proj.addProperty("CustomerBranch", 1);
					proj.addProperty("ScanType", 1);
					projtion.addProperty("_id", 0);
					projtion.addProperty("TotalScannedRecordsCount", 1);
					flter.addProperty("ScanId", ibody.get("scanId").getAsString());

					if (I$utils.$iStrFuzzyMatch(modelClass, "All")) {

						JsonArray result = db$Ctrl.db$GetSummRowsArray("ICOR_M_EXIT_RISK_SCAN", gson.toJson(flter),
								proj, intPgNo, intRecs, sort);
						flter.remove("MODEL_CLASS");
						int counts = db$Ctrl.db$GetRow("ICOR_M_EXIT_RISK_SCAN_LOG", flter, projtion).getAsJsonObject()
								.get("TotalScannedRecordsCount").getAsInt();
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", counts);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result);
					} else {
						flter.addProperty("MODEL_CLASS", modelClass);
						JsonArray result = db$Ctrl.db$GetSummRowsArray("ICOR_M_EXIT_RISK_SCAN", gson.toJson(flter),
								proj, intPgNo, intRecs, sort);
						flter.remove("MODEL_CLASS");
						int counts = db$Ctrl.db$GetRow("ICOR_M_EXIT_RISK_SCAN_LOG", flter, projtion).getAsJsonObject()
								.get("TotalScannedRecordsCount").getAsInt();
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", counts);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result);
					}
					return isonMsg;
				} catch (Exception e) {
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO GET THE DATA");
					return isonMsg;
				}
			}
			proj.addProperty("_id", 0);
			String colName = "ZKYC_" + ibody.get("scanId").getAsString();
			JsonArray result = new JsonArray();
			JsonArray result2 = new JsonArray();
			int resultCount =0;

			if (I$utils.$iStrFuzzyMatch(ibody.get("ScanResult").getAsString(), "Total")) { //#SRM00044 changes starts
				try {
					result = db$Ctrl.db$GetSummRowsArray(colName, gson.toJson(flter), proj, intPgNo, intRecs, sort);
					for(int i = 0; i < result.size(); i++) {
						JsonObject elem = result.get(i).getAsJsonObject();
						if(elem.has("failedCifs")) {
							continue;
						}
						result2.add(elem);	// SRM00072 changes					
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				flter.addProperty("ScanResult", ibody.get("ScanResult").getAsString());
				result = db$Ctrl.db$GetSummRowsArray(colName, gson.toJson(flter), proj, intPgNo, intRecs, sort);
				resultCount = db$Ctrl.db$GetRowCnt(colName, gson.toJson(flter));//#PAV00025 Changes
			}
			filter.addProperty("unqId", ibody.get("uniqueId").getAsString());
			projtion.addProperty(ibody.get("scanType").getAsString(), 1);
			JsonObject countValues = db$Ctrl.db$GetRow("ICOR_M_CUSTOMER_SCAN_LOG", filter, projtion);
			count.add("iCountData", countValues.get(ibody.get("scanType").getAsString()).getAsJsonObject());
//			result.add(count);

			if (I$utils.$iStrFuzzyMatch(ibody.get("ScanResult").getAsString(), "Total")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", count.get("iCountData").getAsJsonObject()
						.getAsJsonObject().get("totalScannedRecordsCount").getAsInt()); 
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result2); // SRM00072 changes
			} //#SRM00044 changes end
			else {
//			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", count.get("iCountData").getAsJsonObject()
//					.get(ibody.get("ScanResult").getAsString() + "Count").getAsInt());
//			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", result.size());// #SRM00066 Changes
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt",resultCount );//#PAV00025 Changes
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result);
			}
//			isonMsg = db$Ctrl.db$GrdFSScanDwld(isonMsg).getAsJsonObject();
			return isonMsg;
		} catch (Exception e) {
			e.printStackTrace();
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE THE DATA");
			return isonMsg;
		}
	} // #MVT00045 ends

	public JsonObject updateMemberStatus(JsonObject isonMsg) {		//#MVT00054 starts
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonParser parser = new JsonParser();
			
			//To handle release the Hold ids #MVT00061 starts
			if (!I$utils.$iStrBlank(isonMsg.get("i-header").getAsJsonObject().get("operation1").getAsString()) && I$utils
					.$iStrFuzzyMatch(isonMsg.get("i-header").getAsJsonObject().get("operation1").getAsString(),
							"RELEASE_TASK")) {
				try {
					JsonObject hold$Object = new JsonObject();
					JsonObject Json$filter = new JsonObject();

					Json$filter.addProperty("memberId", ibody.get("memberId").getAsString());
					String stats = db$Ctrl.db$GetRow("ZKYC_" + ibody.get("scanId").getAsString(), Json$filter).getAsJsonObject()
							.get("status").getAsString();
					if(!I$utils.$iStrFuzzyMatch(stats, "Hold")) {
						i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Cannot perform release operation This is not a hold application");
						return isonMsg;
					}
					hold$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					hold$Object.addProperty("lastActionAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
					hold$Object.addProperty("status", "Open");
					db$Ctrl.db$UpdateRow("ZKYC_" + ibody.get("scanId").getAsString(), hold$Object, Json$filter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
					return isonMsg;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}	//#MVT00061 ends
			if (I$utils.$iStrFuzzyMatch(ibody.get("type").getAsString(), "single")) { //PAV00022 Changes Starts
				if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_WhiteList")|| I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_BlackList")) {
					try {
						JsonObject ftr = new JsonObject();
						JsonObject ftr1 = new JsonObject();
						JsonObject prj = new JsonObject();
						JsonObject white$blackListData = new JsonObject();
						prj.addProperty("CustomerBranch",1);
						ftr.addProperty("CustomerId",ibody.get("memberId").getAsString());
						JsonObject branchData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",ftr,prj);
						JsonObject branch = new JsonObject();
						branch.addProperty("KeyId",branchData.get("CustomerBranch").getAsString());
						prj.addProperty("CurrentPeriod",1);
						JsonObject perCodeData = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA",branch ,prj);
						String flePerCode = perCodeData.get("CurrentPeriod").getAsString();
						String pCode = ibody.get("periodCode").getAsString();
						JsonObject pCodeFtr = new JsonObject();
						pCodeFtr.addProperty("periodCode",ibody.get("periodCode").getAsString());
						int result = flePerCode.compareTo(pCode);
						if (result > 0) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Date is Outdated");
							return isonMsg;
					    }  	
						prj.addProperty("periodStartDate", 1);
						prj.addProperty("periodEndDate", 1);
						JsonObject perData = db$Ctrl.db$GetRow("ICOR_M_B2U_PERIOD_CODE", pCodeFtr ,prj);
						white$blackListData.addProperty("customerId",ibody.get("memberId").getAsString());
						white$blackListData.addProperty("customerName",ibody.get("memberName").getAsString());
						white$blackListData.addProperty("tranId",ibody.get("tranId").getAsString());
						white$blackListData.addProperty("active", "A");
						white$blackListData.addProperty("recordStat", "O");
						white$blackListData.addProperty("statustoggle", "false");
						white$blackListData.addProperty("operation", i$ResM.getOpr(isonMsg).toUpperCase());
						white$blackListData.addProperty("authStat", "U");
						white$blackListData.addProperty("verNo", 1);
						white$blackListData.addProperty("isCurrVer", "Y");
						white$blackListData.addProperty("authorizer", "");
						white$blackListData.addProperty("authPrfPic", "");
						white$blackListData.addProperty("iniPrfPic", "");
						white$blackListData.addProperty("reason", "OK");
						white$blackListData.addProperty("remarks", "");
						white$blackListData.addProperty("initiator", IResManipulator.iloggedUser.get());
						white$blackListData.addProperty("authorizedOnSrvDate", "");
						white$blackListData.addProperty("errorMsg", "Record Successfully Saved");
						white$blackListData.addProperty("initiatedDate", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
						ftr1.addProperty("customerId",ibody.get("memberId").getAsString());
						if(I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_WhiteList")) { 
							int iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_WHITELISTED_MEMBER_LEDGER", ftr1);
								try {
									if(iRowCnt!=0) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Already Exists");
										return isonMsg;
									}
									white$blackListData.addProperty("whiteStartDate",perData.get("periodStartDate").getAsString());
									white$blackListData.addProperty("whiteEndDate", perData.get("periodEndDate").getAsString());
									isonMsg = db$Ctrl.db$InsertRow("ICOR_M_WHITELISTED_MEMBER_LEDGER",white$blackListData);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD ADDED SUCCESSFULLY");
								}catch(Exception e) {
									e.printStackTrace();
								}
							}
							else { 
								int iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_BLACK_LIST_LEDGER", ftr1);
									try {
										if(iRowCnt!=0) {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Already Exists");
											return isonMsg;
										}
								        white$blackListData.addProperty("blackStartDate",perData.get("periodStartDate").getAsString());
										white$blackListData.addProperty("blackEndDate", perData.get("periodEndDate").getAsString());
										isonMsg = db$Ctrl.db$InsertRow("ICOR_M_BLACK_LIST_LEDGER",white$blackListData);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD ADDED SUCCESSFULLY");
									}catch(Exception e) {
										e.printStackTrace();
									}
								}
						}catch (Exception e) {
							e.printStackTrace();
						}
		     }//PAV00022 Changes Ends
//				JsonObject filter = new JsonObject();
//				filter.addProperty("memberId", ibody.get("memberId").getAsString()); // #MVT00062 changes starts
//				String stats = db$Ctrl.db$GetRow("ZKYC_" + ibody.get("scanId").getAsString(), filter).getAsJsonObject()
//						.get("status").getAsString();
//				if (I$utils.$iStrFuzzyMatch(stats, "Hold")) {
//					i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Cannot perform any operation application is on Hold");
//					return isonMsg;
//				} // #MVT00062 changes ends
//				if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_WhiteList")
//						|| I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_BlackList")) {
//					try {
//						JsonObject white$blackListData = new JsonObject(); // PKY00074 changes
//						JsonObject flter = new JsonObject();
//
//						filter.addProperty("memberId", ibody.get("memberId").getAsString());
//						JsonObject dbKYCData=db$Ctrl.db$GetRow("ZKYC_" + ibody.get("scanId").getAsString(), filter);
//						white$blackListData.addProperty("active", "A");
//						white$blackListData.addProperty("financialCycle", "ALL");
//						white$blackListData.addProperty("isCurrVer", "Y");
//						white$blackListData.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
//						white$blackListData.addProperty("lastActionAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
//						white$blackListData.addProperty("customerFullName", dbKYCData.get("memberName").getAsString());
//						white$blackListData.addProperty("customerId", dbKYCData.get("memberId").getAsString());
//						white$blackListData.addProperty("remarks", ibody.get("remarks").getAsString());
//						flter.addProperty("customerId", dbKYCData.get("memberId").getAsString());
//						if(I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_WhiteList")) {  //PKY00074 starts
//							white$blackListData.addProperty("whitelistPeriod", "ALL");
//							db$Ctrl.db$UpdateRow("ICOR_M_WHITELISTED_MEMBER", white$blackListData, flter, "true");
//						}else {
//							white$blackListData.addProperty("blacklistPeriod", "ALL");
//							db$Ctrl.db$UpdateRow("ICOR_M_BLACKLISTED_MEMBERS", white$blackListData, flter, "true");
//						}
//						//PKY00074 ends
//						i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				}else {
//					JsonObject memberStatus = new JsonObject();
//
//					memberStatus.addProperty("status", ibody.get("status").getAsString());
//					memberStatus.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
//					memberStatus.addProperty("lastActionAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
//							.format(Calendar.getInstance().getTime()));
//					if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_DC")){	//To update Queue stage in ZKYC collections
//						memberStatus.addProperty("QueueStage", ibody.get("QueueStage").getAsString());
//					}
//					String colName = "ZKYC_" + ibody.get("scanId").getAsString();
//					JsonObject dbData = db$Ctrl.db$UpdateRow(colName, memberStatus, filter, "true");
//					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
//				}
			} else if (I$utils.$iStrFuzzyMatch(ibody.get("type").getAsString(), "multiple")) {

				if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_WhiteList") || I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_BlackList")) {
					JsonObject fltr = new JsonObject();
					JsonObject flter = new JsonObject();
					JsonObject white$blackListData = new JsonObject(); //PKY00074 changes
					JsonArray memberIds = ibody.get("memberIds").getAsJsonArray();

					for (int i = 0; i < memberIds.size(); i++) {
						fltr.addProperty("memberId", memberIds.get(i).getAsString());
						JsonObject dbKYCData = db$Ctrl.db$GetRow("ZKYC_" + ibody.get("scanId").getAsString(),fltr);
						String stats = dbKYCData.get("status").getAsString();// #MVT00062 changes starts
						if (I$utils.$iStrFuzzyMatch(stats, "Hold")) {
							continue;
						} // #MVT00062 changes ends
						white$blackListData.addProperty("active", "A");
						white$blackListData.addProperty("financialCycle", "ALL");
						white$blackListData.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
						white$blackListData.addProperty("lastActionAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
						white$blackListData.addProperty("customerFullName", dbKYCData.get("memberName").getAsString());
						white$blackListData.addProperty("customerId", dbKYCData.get("memberId").getAsString());
						white$blackListData.addProperty("isCurrVer", "Y");
						white$blackListData.addProperty("remarks", ibody.get("remarks").getAsString());
						flter.addProperty("customerId", dbKYCData.get("memberId").getAsString());
						if(I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Add_To_WhiteList")) {  //PKY00074 starts
							white$blackListData.addProperty("whitelistPeriod", "ALL");
							db$Ctrl.db$UpdateRow("ICOR_M_WHITELISTED_MEMBER", white$blackListData, flter, "true");
						}else {
							white$blackListData.addProperty("blacklistPeriod", "ALL");
							db$Ctrl.db$UpdateRow("ICOR_M_BLACKLISTED_MEMBERS", white$blackListData, flter, "true");
						}
						//PKY00074 ends
						i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
					}
				} else {
					JsonArray flter = new JsonArray();
					JsonArray status = new JsonArray();
					JsonArray memberIds = new JsonArray();	//#MVT00062 changes starts
					JsonObject proj = new JsonObject();
					JsonObject memberObject = new JsonObject();
					JsonObject memberObjects = new JsonObject();
					JsonObject memberStatus = new JsonObject();
					String addIds = null;

					proj.addProperty("_id", 0);
					proj.addProperty("memberId", 1);
					proj.addProperty("status", 1);
					String ids = "{'$in':   " + gson.toJson(ibody.get("memberIds").getAsJsonArray()) + "   }";
					memberObject.add("memberId", parser.parse(ids).getAsJsonObject());
					JsonArray Array$ids = db$Ctrl.db$GetRows("ZKYC_" + ibody.get("scanId").getAsString(), memberObject, proj);
					if (I$utils.strInJsonArray("Hold", Array$ids)) {
						for (int i = 0; i < Array$ids.size(); i++) {
							if (!I$utils.$iStrFuzzyMatch(Array$ids.get(i).getAsJsonObject().get("status").getAsString(),
									"Hold")) {
								memberIds.add(Array$ids.get(i).getAsJsonObject().get("memberId").getAsString());
							}
						}
						addIds = "{'$in':   " + memberIds + "   }";
					} else {
						addIds = "{'$in':   " + gson.toJson(ibody.get("memberIds").getAsJsonArray()) + "   }";
					}
					memberObjects.add("memberId", parser.parse(addIds).getAsJsonObject());
					memberStatus.addProperty("status", ibody.get("status").getAsString());
					memberStatus.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					memberStatus.addProperty("lastActionAt",
							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
					status.add(memberStatus);
					flter.add(memberObjects);//#MVT00062 changes ends
					db$Ctrl.db$UpdateMany("ZKYC_" + ibody.get("scanId").getAsString(), status, flter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
				}
			} else if (I$utils.$iStrFuzzyMatch(ibody.get("type").getAsString(), "All")) {
				/*
				 * if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(),"Add_To_WhiteList")) {
				 * 
				 * }
				 */
				if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "Accept")) {
					JsonArray status = new JsonArray();
					JsonArray flter = new JsonArray();
					JsonArray memer$Id = new JsonArray();	//#MVT00062 changes starts
					JsonObject fltr = new JsonObject();
					JsonObject projection = new JsonObject();
					JsonObject memberStatus = new JsonObject();
					JsonObject memberObject = new JsonObject();

					projection.addProperty("memberId", 1);
					projection.addProperty("_id", 0);
					fltr.addProperty("status", "Hold");
					JsonArray holdIds = db$Ctrl.db$GetRows("ZKYC_" + ibody.get("scanId").getAsString(), fltr, projection);
					for(int i=0;i<holdIds.size();i++) {
						memer$Id.add(holdIds.get(i).getAsJsonObject().get("memberId"));			
					}
					String hold$Ids = "{'$nin': "+ gson.toJson(memer$Id)+"}";				
					memberObject.add("memberId", parser.parse(hold$Ids).getAsJsonObject());
					memberObject.addProperty("ScanResult", ibody.get("ScanResult").getAsString());	//#MVT00062 changes ends
					memberObject.addProperty("ScanResult", ibody.get("ScanResult").getAsString());
					memberStatus.addProperty("status", "Accept");
					memberStatus.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
					memberStatus.addProperty("lastActionAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
					status.add(memberStatus);
					flter.add(memberObject);
					db$Ctrl.db$UpdateMany("ZKYC_" + ibody.get("scanId").getAsString(), status, flter, "true");
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATED SUCCESSFULY");
				}
				else {
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation is not allowed");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}	//#MVT00054 ends
	//#MVT00060 starts
	public JsonObject getMember(JsonObject isonMsg) {
		try {
			JsonObject flter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			projection.addProperty("_id", 0);
			projection.addProperty("INDIVIDUAL_WEIGHT", 1); 
			projection.addProperty("CustomerId", 1); 
			projection.addProperty("CustomerFullName", 1); 
			projection.addProperty("MODEL_CLASS", 1); 
			projection.addProperty("MODEL_COLOR", 1); 
			projection.addProperty("MODEL_RATING", 1); 
			projection.addProperty("MODEL_VALUE", 1); 
			projection.addProperty("totalWeight",1);//#PAV00017 Changes
			flter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			flter.addProperty("ScanId", ibody.get("ScanId").getAsString());
			JsonObject customer = db$Ctrl.db$GetRow("ICOR_M_EXIT_RISK_SCAN", flter, projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", customer);
			return isonMsg;
		}catch(Exception e) {
			e.printStackTrace();
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO DATA FOUND");
			return isonMsg;
		}
	}//#MVT00060 ends
	//#MVT00055 Starts
	public JsonObject getCountData(JsonObject isonMsg) {
		try {
			JsonObject flter = new JsonObject();

			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			
				//To get the count data of ris scan
			//PKY00077 starts
			if(ibody.has("scanType")) {
				if (i$outis.$iStrFuzzyMatch(ibody.get("scanType").getAsString(), "RiskProfiling")) {
					try {
						JsonObject projction = new JsonObject();
						projction.addProperty("_id", 0);
						projction.addProperty("CompletedThreads", 0);
						flter.addProperty("ScanId", ibody.get("uniqueId").getAsString());
						JsonObject countValue = db$Ctrl.db$GetRow("ICOR_M_EXIT_RISK_SCAN_LOG", flter, projction);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", countValue);
						return isonMsg;
					}catch(Exception e) {
						i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO GET THE DATA");
						return isonMsg;
					}
				}//PKY00077 ends
			}
			flter.addProperty("unqId", ibody.get("uniqueId").getAsString());
			JsonObject countValues = db$Ctrl.db$GetRow("ICOR_M_CUSTOMER_SCAN_LOG", flter);
			countValues.remove("_id");
			isonMsg.add("i-body", countValues);
		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO GET THE DATA");
			return isonMsg;
		}
		return isonMsg;
	} // #MVT00055 ends
	//SRM00061 changes
	public JsonObject scanSummary(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject projectn = new JsonObject();
		JsonObject updateObj = new JsonObject();
		JsonArray jArray = new JsonArray();
		JsonObject sort = new JsonObject();
		JsonObject filt = new JsonObject();
		Gson gson = new Gson();
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		int iRowCnt = 0;
		int intPgNo, intRecs;

		try {
			intPgNo = ibody.get("intPgNo").getAsInt();
		} catch (Exception e) {
			intPgNo = 0;
		}
		try {
			intRecs = ibody.get("intRecs").getAsInt();
		} catch (Exception e) {
			intRecs = 20;
		}
		sort.addProperty("_id", -1);
		try {
			Date currentDateTime = new Date();
			Date dbDateTime = null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
			projection.addProperty("_id", 0);
			filter.addProperty("scanningStatus", "Initiated");
			JsonArray jData = db$Ctrl.db$GetRows$Sort("ICOR_M_CUSTOMER_SCAN_LOG", filter, projection, sort);
			projectn.addProperty("totalHoursOfJobCompletion", 1);
			projectn.addProperty("_id", 0);
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}",projectn);
			if (jData.size() > 0) {
				for (int i = 0; i < jData.size(); i++) {
					try {
						String updatedDate = jData.get(i).getAsJsonObject().get("lastUpdatedAt").getAsString();
						dbDateTime = dateFormat.parse(updatedDate);
						long timeDiff = currentDateTime.getTime() - dbDateTime.getTime();
						double totalDiff = timeDiff / (1000 * 60 * 60);

						if (totalDiff >= cParam.get("totalHoursOfJobCompletion").getAsDouble()) {
							updateObj.addProperty("scanningStatus", "Failed");
	                      db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG", updateObj, filter);
						} 
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} else if(ibody.has("dataSetFltr")){ //SRM00063 changes start
				try {
					try {//PAV00023 Changes Starts
						JsonArray filterArr = isonMsg.get("i-body").getAsJsonObject().get("dataSetFltr").getAsJsonObject().get("data").getAsJsonArray();
						for(int i=0; i<filterArr.size();i++) {
							if(filterArr.get(i).getAsJsonObject().get("iField").getAsString().contains(".")) {
								projection.addProperty(filterArr.get(i).getAsJsonObject().get("iField").getAsString().split("\\.")[0], 1);
								projection.addProperty("unqId",1);
								projection.addProperty("initiatedDate",1);
								projection.addProperty("scanningStatus",1);
								projection.addProperty("unqRunId",1);
								projection.addProperty("lastUpdatedAt",1);
							}
						}
					}catch(Exception e) {
						e.printStackTrace();
					}//PAV00023 Changes Ends
				JsonObject j$DataFilter = i$genericCntrlr.get$FrmDataSetFilter(isonMsg);
				JsonObject filterData = db$Ctrl.db$GetRows$Sort("ICOR_M_CUSTOMER_SCAN_LOG", gson.toJson(j$DataFilter), projection, intPgNo, intRecs, sort);
				ibody.addProperty("iRowCnt", String.valueOf(iRowCnt));
				ibody.add("iRowData", filterData.get("i-body").getAsJsonArray());	
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

				ibody.addProperty("iRowCnt", iRowCnt);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", ibody);
				return isonMsg;
				} catch(Exception e) {
					e.printStackTrace();
				} //SRM00063 changes end
			}
			iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_CUSTOMER_SCAN_LOG", filt);
			jArray = db$Ctrl.db$GetRows$Sort("ICOR_M_CUSTOMER_SCAN_LOG", projection, sort);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", iRowCnt);
			ibody.add("iRowData", jArray);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);

		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEM + " Data Scanned failed with: " + e.getMessage());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jArray);

		}
		return isonMsg;
	}
//SRM00061 changes end
	public JsonObject CreateCifSdnScan(JsonObject isonMsg) {
	    try {
	    	JsonObject scanObject = new JsonObject(); //#MVT00059 Changes starts  //PAV00019 Changes
		    int noOfThread = 10;
	        String sUniqueId = null;
		    String referenceNo = null;
	        JsonObject i$body = isonMsg.get("i-body").getAsJsonObject();
	        if(i$body.has("referenceNo")) {
	        	sUniqueId = i$body.get("uniqueId").getAsString();
		        referenceNo = i$body.get("referenceNo").getAsString();
	        }else {
	        	sUniqueId = I$Imputils.generateRandomKey();
	 	        referenceNo = I$Imputils.getAlphaNumericId(50);
	 	        i$body.addProperty("referenceNo",  referenceNo);
	 	        i$body.addProperty("uniqueId",  sUniqueId);
	        }
	        JsonObject result$ = null;
	        scanObject.addProperty("scanId", sUniqueId);
	        scanObject.addProperty("threads", noOfThread);
			try {
				if (i$outis.$iStrFuzzyMatch(i$body.get("ScanType").getAsString(), "RiskProfiling")) {
					scanObject.addProperty("ScanType",i$body.get("ScanType").getAsString());//SKP00001 Changes
					String ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IKYCController";
					Class<?> ctrlClass;
					ctrlClass = Class.forName(ScrCtrlClass);
					Method ctrlFunc = null;
					ctrlFunc = ctrlClass.getMethod("riskScan", JsonObject.class);
					Object ctrl$Caller = ctrlClass.newInstance();
					result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, scanObject);
					return isonMsg;
				}
			} catch (Exception e) {	//To handle exception
				e.printStackTrace();
			}// #MVT00059 Changes ends
	        if(i$outis.isInArray(i$body.get("scanningParam").getAsJsonArray(), "Member")){
	        	 String fYear = null;
	 	         String pCode = null;
	 	        try {
	 	            Calendar calendar = Calendar.getInstance();
	 	            int month = calendar.get(Calendar.MONTH) + 1;
	 	            int year = calendar.get(Calendar.YEAR);
	 	            if (month <= 9) {
	 	                pCode = "M0" + month;
	 	            } else {
	 	                pCode = "M" + month;
	 	            }
	 	            fYear = "FY" + year;
	 	        } catch (Exception e) {

	 	        }
	 	        i$body.addProperty("peroidCode", pCode);
	 	        i$body.addProperty("financialYear", fYear);
	 	       try { // #SRM00067 Changes start
                   srvcFunction.jobEmailNotification("KYM", "Initiated", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
               } catch (Exception e) {
               	e.printStackTrace();
               }
	        }// #SRM00067 changes end
	        JsonObject filter = new JsonObject();	//#MVT00038 starts
			filter.addProperty("unqId", sUniqueId);
	        JsonArray scanParams = i$body.get("scanningParam").getAsJsonArray();
			String scanParam = i$body.get("scanningParam").getAsJsonArray().get(0).getAsString();
			if (scanParam.equals("Member")) {
				for (int i = 0; i < scanParams.size(); i++) {
					JsonObject paramsStatus = new JsonObject();
					paramsStatus.addProperty(scanParams.get(i).getAsString() + "Scan" + "." + "status", "Pending");
//					db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", paramsStatus, filter, "true");
					db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", paramsStatus, filter, "true");
				}
			}	//#MVT00038 starts ends
			JsonObject jobStatus = new JsonObject();  //#MVT00036 Changes starts
			jobStatus.addProperty(scanParam + "Scan" + "." + "status", "WIP");
			jobStatus.addProperty(scanParam + "Scan" + "." + "initiatedTime",
					new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
//			db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", jobStatus, filter, "true");
			db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", jobStatus, filter, "true");    //#MVT00036 Changes ends
			try {
				JsonObject reportObj = new JsonObject();
    			JsonObject reportFltr = new JsonObject();
    			JsonArray reportResults = new JsonArray();
    			reportFltr.addProperty("ReportType", "List of all "+scanParam+" with Scan results of a specific KYM Job run.");
    			reportFltr.addProperty("ScanId", sUniqueId);
    			reportObj.addProperty("ReportType", "List of all "+scanParam+" with Scan results of a specific KYM Job run.");
    			reportObj.addProperty("ScanId", sUniqueId);
    			reportObj.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
    			reportObj.addProperty("fileName", scanParam+"_report_for_KYM_job_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
						.format(Calendar.getInstance().getTime())+ ".pdf");
    			reportObj.addProperty("Status","WIP");
    			reportObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
    			reportObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
    			reportObj.add("reportResults", reportResults);
    			db$Ctrl.db$UpdateRow("ICOR_M_KYM_REPORT", reportObj, reportFltr, "true");
			}catch(Exception e) {
			}
//	        Thread t = null;
	        for (int i = 0; i < noOfThread; i++) {
	            JsonObject jWrkArgs = new JsonObject();
	            JsonObject jArgs = new JsonObject();
	            jArgs.add("scanningParam", i$body.get("scanningParam").getAsJsonArray());
	            jArgs.add("isonMsg", isonMsg);
	            jArgs.addProperty("threadCount", i);
	            jArgs.addProperty("uniqueId", sUniqueId);
	            jArgs.addProperty("totalNumberOfThreads", noOfThread);
	            jWrkArgs.add("isonMsg", jArgs.deepCopy());
	            jWrkArgs.addProperty("clsName",
	                "net.sirma.impacto.iapp.icontrollers.isrvccontrollers.ICifSdnScanController");
	            jWrkArgs.addProperty("funcName", "ISdnThreadProcess");
	            IThreadController IThread$worker = new IThreadController(jWrkArgs);
	            Thread t = new Thread(IThread$worker);
	            t.start();
	        }
	    } catch (Exception e) {
	        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
	            i$ResM.I_CUSMEM + " Data Scanned failed with: " + e.getMessage());
	    }
	    return isonMsg;
	}

	 public void ISdnThreadProcess(JsonObject argJson) {
	     int threadCount = argJson.get("threadCount").getAsInt();
	     int noOfThread = argJson.get("totalNumberOfThreads").getAsInt();
	     int count = argJson.get("threadCount").getAsInt();
	     JsonArray scanningParam = argJson.get("scanningParam").getAsJsonArray();
	     
			try {
				JsonObject fieldMapper = new JsonObject();
				JsonObject filter = new JsonObject();
				JsonObject projection = new JsonObject();
				JsonArray icorMB2USdn = db$Ctrl.db$GetRows("ICOR_M_B2U_SDN", filter, projection);
				for (int i = 0; i < icorMB2USdn.size(); i++) {
					JsonObject i$runningObj = icorMB2USdn.get(i).getAsJsonObject();
					fieldMapper.add(i$runningObj.get("Sdn_List_Id").getAsString(), i$runningObj);
				}
				i$ResM.setGobalVals("fieldMapper", fieldMapper);
			} catch (Exception e) {

			}
			try {
				JsonObject wproj = new JsonObject();
				wproj.addProperty("_id", 0);	//#MVT00051 changes starts
				wproj.addProperty("customerId", 1);
				wproj.addProperty("financialCycle", 1);
				JsonArray i$whiteListedMem = db$Ctrl.db$GetSummRowsArray("ICOR_M_WHITELISTED_MEMBER", "{'active':'A','authStat':'A'}", wproj, 0, 0);	//#MVT00051 changes ends
				i$ResM.setGobalVals("i$whiteListedMem", i$whiteListedMem);
			} catch (Exception e) {
			}
			//PKY00075 starts
			try {
				JsonObject bProj = new JsonObject();
				bProj.addProperty("_id", 0);
				bProj.addProperty("customerId", 1);
				bProj.addProperty("financialCycle", 1);
				JsonArray i$blackListedMem = db$Ctrl.db$GetSummRowsArray("ICOR_M_BLACKLISTED_MEMBERS", "{'active':'A','authStat':'A'}", bProj, 0, 0);
				i$ResM.setGobalVals("i$blackListedMem", i$blackListedMem);
			} catch (Exception e) {
			}
			//PKY00075 ends
			try {//PAV00027 Changes Starts
				JsonObject bProj = new JsonObject();
				bProj.addProperty("_id", 0);
				bProj.addProperty("CustomerId", 1);
				bProj.addProperty("CustomerFullName", 1);
				JsonArray IgnoreOnceMem = db$Ctrl.db$GetSummRowsArray("ICOR_M_KYM_CHECKS_IGNORE", "{}", bProj, 0, 0);
				i$ResM.setGobalVals("i$IgnoreOnceMem", IgnoreOnceMem);
			} catch (Exception e) {
			}
			try {
				JsonObject bProj = new JsonObject();
				bProj.addProperty("_id", 0);
				bProj.addProperty("CustomerId", 1);
				bProj.addProperty("recordStat", 1);
				JsonArray HoldMemScan = db$Ctrl.db$GetSummRowsArray("ICOR_M_KYM_CHECKS_HOLD", "{recordStat:O}", bProj, 0, 0);
				i$ResM.setGobalVals("i$HoldMemScan", HoldMemScan);
			} catch (Exception e) {
			}//PAV00027 Changes Ends
	     try {
	         if (count == 0 && i$outis.isInArray(scanningParam, "Member")) {
					JsonObject filterthreadLog = new JsonObject();
					filterthreadLog.addProperty("unqId", argJson.get("uniqueId").getAsString());
					JsonObject beforeUpdate = new JsonObject();
					beforeUpdate.addProperty("unqRunId", argJson.get("isonMsg").getAsJsonObject().get("i-body").getAsJsonObject().get("referenceNo").getAsString());
					beforeUpdate.addProperty("initiatedDate", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
					beforeUpdate.addProperty("scanningStatus", "Initiated");//#MVT00036 Changes
					beforeUpdate.addProperty("lastUpdatedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime()));
					db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG", beforeUpdate, filterthreadLog, "true");
//					db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", beforeUpdate, filterthreadLog, "true");
					db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", beforeUpdate, filterthreadLog, "true");//#MVT00038 Changes
					count++;
					logger.debug("Empty data inserted successfully");
	         }
	     } catch (Exception e) {
	         logger.debug("Failed to insert empty data in db: " + e.getMessage());
	     }
	    
	     if (i$outis.isInArray(scanningParam, "Member") || i$outis.isInArray(scanningParam, "SpouseName") || i$outis.isInArray(scanningParam, "JointPartner")) {
	    	 int noOfIterThread = 0;
		     int runEntriesCount = 0;
		     double i$noOfIter = 0.0;
		     int i$noOfIterInt = 0;
	         try {
	             runEntriesCount = db$Ctrl.db$GetCountI("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}");
	             double i$noOfIterThreadDbl = Double.valueOf(runEntriesCount) / noOfThread;
	             noOfIterThread = (int) Math.ceil(i$noOfIterThreadDbl);
	             
	             if (noOfIterThread < 100) {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / noOfIterThread;
	                 i$noOfIter = Math.ceil(i$noOfIter);
	             } else {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / 100;
	                 i$noOfIterInt = (int) Math.ceil(i$noOfIter) * 100;
	                 i$noOfIter = Double.valueOf(i$noOfIterInt) / 100;
	             }
	             argJson.addProperty("noOfIter", i$noOfIter);
	             argJson.addProperty("noOfIterThreadmem", noOfIterThread);
	             argJson.addProperty("threadCount", threadCount);
	             argJson.addProperty("noOfIterInt", i$noOfIterInt);
	             argJson.addProperty("scanningData", scanningParam.get(0).getAsString());
	             memberScanning(argJson);
	         } catch (Exception e) {
	             runEntriesCount = 0;
	         }
	     }else if(i$outis.isInArray(scanningParam, "Nominee")) {
	    	 int noOfIterThread = 0;
		     int runEntriesCount = 0;
		     double i$noOfIter = 0.0;
		     int i$noOfIterInt = 0;
	         try {
	             runEntriesCount = db$Ctrl.db$GetCountI("ICOR_M_CBS_NOMINEE_DATA", "{}");
	             double i$noOfIterThreadDbl = Double.valueOf(runEntriesCount) / noOfThread;
	             noOfIterThread = (int) Math.ceil(i$noOfIterThreadDbl);
	             
	             if (noOfIterThread < 100) {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / noOfIterThread;
	                 i$noOfIter = Math.ceil(i$noOfIter);
	             } else {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / 100;
	                 i$noOfIterInt = (int) Math.ceil(i$noOfIter) * 100;
	                 i$noOfIter = Double.valueOf(i$noOfIterInt) / 100;
	             }
	             argJson.addProperty("noOfIter", i$noOfIter);
	             argJson.addProperty("noOfIterThreadmem", noOfIterThread);
	             argJson.addProperty("threadCount", threadCount);
	             argJson.addProperty("noOfIterInt", i$noOfIterInt);
	             argJson.addProperty("scanningData", scanningParam.get(0).getAsString());
	             memberScanning(argJson);
	         } catch (Exception e) {
	             runEntriesCount = 0;
	         }
	    	 
	     }else if(i$outis.isInArray(scanningParam, "CunaBen")) {
	    	 int noOfIterThread = 0;
		     int runEntriesCount = 0;
		     double i$noOfIter = 0.0;
		     int i$noOfIterInt = 0;
	         try {
	             runEntriesCount = db$Ctrl.db$GetCountI("ICOR_M_CBS_CUNA_BEN_DATA", "{}");
	             double i$noOfIterThreadDbl = Double.valueOf(runEntriesCount) / noOfThread;
	             noOfIterThread = (int) Math.ceil(i$noOfIterThreadDbl);
	             
	             if (noOfIterThread < 100) {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / noOfIterThread;
	                 i$noOfIter = Math.ceil(i$noOfIter);
	             } else {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / 100;
	                 i$noOfIterInt = (int) Math.ceil(i$noOfIter) * 100;
	                 i$noOfIter = Double.valueOf(i$noOfIterInt) / 100;
	             }
	             argJson.addProperty("noOfIter", i$noOfIter);
	             argJson.addProperty("noOfIterThreadmem", noOfIterThread);
	             argJson.addProperty("threadCount", threadCount);
	             argJson.addProperty("noOfIterInt", i$noOfIterInt);
	             argJson.addProperty("scanningData", scanningParam.get(0).getAsString());
	             memberScanning(argJson);
	         } catch (Exception e) {
	             runEntriesCount = 0;
	         }
	     }else if(i$outis.isInArray(scanningParam, "ClicoBen")) {
	    	 int noOfIterThread = 0;
		     int runEntriesCount = 0;
		     double i$noOfIter = 0.0;
		     int i$noOfIterInt = 0;
	         try {
	             runEntriesCount = db$Ctrl.db$GetCountI("ICOR_M_CBS_CLICO_BEN_DATA", "{}");
	             double i$noOfIterThreadDbl = Double.valueOf(runEntriesCount) / noOfThread;
	             noOfIterThread = (int) Math.ceil(i$noOfIterThreadDbl);
	             
	             if (noOfIterThread < 100) {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / noOfIterThread;
	                 i$noOfIter = Math.ceil(i$noOfIter);
	             } else {
	                 i$noOfIter = Double.valueOf(noOfIterThread) / 100;
	                 i$noOfIterInt = (int) Math.ceil(i$noOfIter) * 100;
	                 i$noOfIter = Double.valueOf(i$noOfIterInt) / 100;
	             }
	             argJson.addProperty("noOfIter", i$noOfIter);
	             argJson.addProperty("noOfIterThreadmem", noOfIterThread);
	             argJson.addProperty("threadCount", threadCount);
	             argJson.addProperty("noOfIterInt", i$noOfIterInt);
	             argJson.addProperty("scanningData", scanningParam.get(0).getAsString());
	             memberScanning(argJson);
	         } catch (Exception e) {
	             runEntriesCount = 0;
	         }
	     }
	 }
	
	 public void memberScanning(JsonObject argJson) {
		    Gson gson = new Gson();
		    JsonObject filterthreadLog = new JsonObject();
		    JsonObject tempFilter = new JsonObject();	//#MVT00047 Changes starts
		    JsonObject isonMsg = argJson.get("isonMsg").getAsJsonObject();
		    JsonObject jobStatus1 = new JsonObject();  //#MVT00036 Changes starts
		    jobStatus1.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "status", "WIP");
		    int i$noOfIterThread = argJson.get("noOfIterThreadmem").getAsInt();
		    int threadCount = argJson.get("threadCount").getAsInt();
		    filterthreadLog.addProperty("unqId", argJson.get("uniqueId").getAsString());
		    tempFilter.addProperty("unqId", argJson.get("uniqueId").getAsString()+"_Thread"+threadCount);
			db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", jobStatus1, tempFilter, "true");	//#MVT00047 Changes ends
		    try {
		        double i$noOfIter = 0.0;
		        i$noOfIter = argJson.get("noOfIter").getAsDouble();
		        int i$noOfIterInt = 0;
		        i$noOfIterInt = argJson.get("noOfIterInt").getAsInt();
		        for (int i = 0; i < i$noOfIter; i++) {
		        	try {
		        	     JsonArray runEntries = new JsonArray();
				            JsonObject projection = new JsonObject();
				            int skip = 0;
				            if(i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "JointPartner") || i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member") || i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "SpouseName")) {
				            	 
					                if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "JointPartner")) {
					                    projection.addProperty("_id", 0);
					                    projection.addProperty("FirstNameJp", 1);
					                    projection.addProperty("MiddleNameJp", 1);
					                    projection.addProperty("LastNameJp", 1);
					                    projection.addProperty("CustomerId", 1);
					                    projection.addProperty("CustomerBranch", 1);
					                    projection.addProperty("BranchName", 1);
					                } else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
					                    projection.addProperty("_id", 0);
					                    projection.addProperty("CustomerFullName", 1);
					                    projection.addProperty("CustomerId", 1);
					                    projection.addProperty("CustomerBranch", 1);
					                    projection.addProperty("BranchName", 1);
					                } else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "SpouseName")) {
					                    projection.addProperty("_id", 0);
					                    projection.addProperty("SpouseName", 1);
					                    projection.addProperty("CustomerId", 1);
					                    projection.addProperty("CustomerBranch", 1);
					                    projection.addProperty("BranchName", 1);
					                }
					                if (i$noOfIterThread < 100) {
					                    skip = i$noOfIterThread * i;
					                    skip = skip + (i$noOfIterThread * threadCount);
					                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}", projection, skip, i$noOfIterThread, "Y");
					                } else {
					                    skip = 100 * i;
					                    skip = skip + (i$noOfIterInt * threadCount);
					                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}", projection, skip, 100, "Y");
					                }
				            }else {
				            	 if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Nominee")) {
					                    projection.addProperty("_id", 0);
					                    projection.addProperty("NomineeFName", 1);
					                    projection.addProperty("NomineeMName", 1);
					                    projection.addProperty("NomineeLName", 1);
					                    projection.addProperty("CustomerId", 1);  
					                    projection.addProperty("CustomerBranch", 1);
					                    projection.addProperty("BranchName", 1);
					                    
					                    if (i$noOfIterThread < 100) {
						                    skip = i$noOfIterThread * i;
						                    skip = skip + (i$noOfIterThread * threadCount);
						                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_NOMINEE_DATA","{}", projection, skip, i$noOfIterThread, "Y");
						                } else {
						                    skip = 100 * i;
						                    skip = skip + (i$noOfIterInt * threadCount);
						                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_NOMINEE_DATA", "{}", projection, skip, 100, "Y");
						                }
					                } else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "CunaBen")) {
					                	projection.addProperty("_id", 0);
					                    projection.addProperty("CunaBenFName", 1);
					                    projection.addProperty("CunaBenMName", 1);
					                    projection.addProperty("CunaBenLName", 1);
					                    projection.addProperty("CustomerId", 1);  
					                    projection.addProperty("CustomerBranch", 1);
					                    projection.addProperty("BranchName", 1);
					                    
					                    if (i$noOfIterThread < 100) {
						                    skip = i$noOfIterThread * i;
						                    skip = skip + (i$noOfIterThread * threadCount);
						                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CUNA_BEN_DATA", "{}", projection, skip, i$noOfIterThread, "Y");
						                } else {
						                    skip = 100 * i;
						                    skip = skip + (i$noOfIterInt * threadCount);
						                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CUNA_BEN_DATA", "{}", projection, skip, 100, "Y");
						                }
					                } else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "ClicoBen")) {
					                	projection.addProperty("_id", 0);
					                    projection.addProperty("ClicoBenFName", 1);
					                    projection.addProperty("ClicoBenMName", 1);
					                    projection.addProperty("ClicoBenLName", 1);
					                    projection.addProperty("CustomerId", 1); 
					                    projection.addProperty("CustomerBranch", 1);
					                    projection.addProperty("BranchName", 1);
					                    
					                    if (i$noOfIterThread < 100) {
						                    skip = i$noOfIterThread * i;
						                    skip = skip + (i$noOfIterThread * threadCount);
						                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CLICO_BEN_DATA", "{}", projection, skip, i$noOfIterThread, "Y");
						                } else {
						                    skip = 100 * i;
						                    skip = skip + (i$noOfIterInt * threadCount);
						                    runEntries = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CLICO_BEN_DATA", "{}", projection, skip, 100, "Y");
						                }
					                }
				            }
				            try {
//				                JsonObject thradCount = new JsonObject();
//				                thradCount.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "threadCount" + (threadCount + 1), runEntries.size());
//				                String i$CustomerIdDoc1 = gson.toJson(thradCount);
//				                db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CustomerIdDoc1, filterthreadLog, "true", "inc");
				                
						        int Critical1 = 0, High1 = 0, Significant1 = 0, Medium1 = 0, Low1 = 0, Very_Low1 = 0, Clean1 = 0,
				    		            totalScannedRecordsCount = 0, failureCount = 0, ignoreOnceCount=0, onHoldCount=0, notApplicable = 0;	//#MVT00051 changes //#PAV00027 Changes
				                JsonArray Critical = new JsonArray();
				                JsonArray High = new JsonArray();
				                JsonArray Significant = new JsonArray();
				                JsonArray Medium = new JsonArray();
				                JsonArray Low = new JsonArray();
				                JsonArray Very_Low = new JsonArray();
				                JsonArray Clean = new JsonArray();
				                JsonArray failed = new JsonArray();
				                JsonArray ignoredOnce = new JsonArray();//#PAV00027 Changes
				                JsonArray onHold = new JsonArray();//#PAV00027 Changes
				                JsonArray notApplicableMem = new JsonArray();
				                JsonArray totalScannedRecords = new JsonArray();
				                JsonArray reportsRecords = new JsonArray();
				                for (int j = 0; j < runEntries.size(); j++) {
				                	 String CustomerId = null;
				                    try {
				                        String sCustomerName = null;
//				                        JsonObject runEntries.get(j).getAsJsonObject() = runEntries.get(j).getAsJsonObject();
				                        try {
				                            CustomerId = runEntries.get(j).getAsJsonObject().get("CustomerId").getAsString();
				                        } catch (Exception e) {
				                            CustomerId = null;
				                        }
				                        JsonObject report = new JsonObject();
		           			            try {
		           			                report.addProperty("Branch Code", i$ResM.getStrfromObj(runEntries.get(j).getAsJsonObject(), "CustomerBranch"));
		           			                report.addProperty("Branch Name", i$ResM.getStrfromObj(runEntries.get(j).getAsJsonObject(), "BranchName"));
		           			                report.addProperty("Member Id", i$ResM.getStrfromObj(runEntries.get(j).getAsJsonObject(), "CustomerId"));
		           			            }catch(Exception e) {
		           			            }
				                        if (i$outis.strInJsonArray(CustomerId, i$ResM.getGobalValArr("i$whiteListedMem"))) {
				                        	if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
				                        		try {	//#MVT00051 changes starts
				                        			int whiteListedMemCount = 0;
				                        		  	Calendar calendar = Calendar.getInstance();
						        	 	            int year = calendar.get(Calendar.YEAR);
						                            JsonObject CustomerIdObj = new JsonObject();
						                            JsonArray  CustomerObj= i$ResM.getGobalValArr("i$whiteListedMem");
						                            JsonObject whitelistPeriod = I$Imputils.objFromArrWithSearch(CustomerObj , "customerId", CustomerId).getAsJsonObject();
						                            
						                            String financialCycle = whitelistPeriod.get("financialCycle").getAsString().substring(2);
						                            int yearPeriod = Integer.parseInt(financialCycle);
						                            if(yearPeriod==year) {
						                            	whiteListedMemCount++;
						                            	CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "whiteListedMemCount", whiteListedMemCount);
							                            String i$CustomerIdDoc = gson.toJson(CustomerIdObj);
							                            db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CustomerIdDoc, filterthreadLog, "true", "inc");
							                            db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$CustomerIdDoc, filterthreadLog, "true", "inc");	//#MVT00038 Changes

							                            CustomerIdObj = new JsonObject();
							                            CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "whiteListedMem", CustomerId);
							                            String whiteListedMemID = gson.toJson(CustomerIdObj);
							                            db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", whiteListedMemID, filterthreadLog, "true", "push");	//#MVT00038 Changes
							                            continue;
						                            }
				                        		}catch(Exception e) {
				                        			e.printStackTrace();
				                        		}	//#MVT00051 changes ends
				                        	}else {
				                        		continue;
				                        	}
				                        }if (i$outis.strInJsonArray(CustomerId, i$ResM.getGobalValArr("i$IgnoreOnceMem"))) {//PAV00027 Changes Starts
				                        	if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
				                        		try {
				                        				 JsonObject CustomerIdObj = new JsonObject();
				                        				 ignoreOnceCount++;
				                        				 totalScannedRecordsCount++;
				                        				 JsonObject member2 = new JsonObject();	
				                        				 sCustomerName = runEntries.get(j).getAsJsonObject().get("CustomerFullName").getAsString();
						                                 member2.addProperty("memberId",CustomerId);
						                                 member2.addProperty("memberName",sCustomerName);
						                                 member2.addProperty("status", "OPEN");
							                             member2.addProperty("ScanResult", "IgnoredOnce");
						                                 ignoredOnce.add(member2);
				                        				 CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "ignoredOnceMemCount", ignoreOnceCount);
								                         String i$CustomerIdDoc = gson.toJson(CustomerIdObj);
								                         db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CustomerIdDoc, filterthreadLog, "true", "inc");
								                         db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$CustomerIdDoc, filterthreadLog, "true", "inc");
								                         CustomerIdObj = new JsonObject();
								                         CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "ignoredOnceMem", CustomerId);
								                         String ignoredOnceMemID = gson.toJson(CustomerIdObj);
								                         db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", ignoredOnceMemID, filterthreadLog, "true", "push");	
								                         JsonObject ftr2=new JsonObject();
				        								 ftr2.addProperty("CustomerId",runEntries.get(j).getAsJsonObject().get("CustomerId").getAsString());
				        								 db$Ctrl.db$Remove("ICOR_M_KYM_CHECKS_IGNORE",ftr2) ;
							                             continue;
							                           
				                        		}catch(Exception e) {
				                        			e.printStackTrace();
				                        		}	
				                        	}
				                        }
				                        if (i$outis.strInJsonArray(CustomerId, i$ResM.getGobalValArr("i$HoldMemScan"))) {
				                        		if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
				                        			try {	
				                        					JsonObject CustomerIdObj5 = new JsonObject();
				                        					onHoldCount++;
				                        					totalScannedRecordsCount++;
				                        					JsonObject member = new JsonObject();
					                        				sCustomerName = runEntries.get(j).getAsJsonObject().get("CustomerFullName").getAsString();
							                                member.addProperty("memberId",CustomerId);
							                                member.addProperty("memberName",sCustomerName);
							                                member.addProperty("status", "OPEN");
							                                member.addProperty("ScanResult", "OnHold");
							                                onHold.add(member);
							                                CustomerIdObj5.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "onHoldMemCount", onHoldCount);
									                        String i$CustomerIdDoc5 = gson.toJson(CustomerIdObj5);
									                        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CustomerIdDoc5, filterthreadLog, "true", "inc");
									                        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$CustomerIdDoc5, filterthreadLog, "true", "inc");
									                        CustomerIdObj5 = new JsonObject();
									                        CustomerIdObj5.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "onHoldMem", CustomerId);
									                        String onHoldMemID = gson.toJson(CustomerIdObj5);
									                        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", onHoldMemID, filterthreadLog, "true", "push");
				                        					continue;
				                        					}catch(Exception e) {
				                        				e.printStackTrace();
				                        			}
				                        		}
				                        }//#PAV00027 Changes Ends
				                        //PKY00075 starts
				                        if (i$outis.strInJsonArray(CustomerId, i$ResM.getGobalValArr("i$blackListedMem"))) {
				                        	if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
				                        		try {
				                        			int blackListedMemCount = 0;
				                        		  	Calendar calendar = Calendar.getInstance();
						        	 	            int year = calendar.get(Calendar.YEAR);
						                            JsonObject CustomerIdObj = new JsonObject();
						                            JsonArray  CustomerObj= i$ResM.getGobalValArr("i$blackListedMem");
						                            JsonObject blacklistPeriod = I$Imputils.objFromArrWithSearch(CustomerObj , "customerId", CustomerId).getAsJsonObject();
						                            
						                            String financialCycle = blacklistPeriod.get("financialCycle").getAsString().substring(2);
						                            int yearPeriod = Integer.parseInt(financialCycle);
						                            if(yearPeriod==year) {
						                            	blackListedMemCount++;
						                            	CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "blackListedMemCount", blackListedMemCount);
							                            String i$CustomerIdDoc = gson.toJson(CustomerIdObj);
							                            db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CustomerIdDoc, filterthreadLog, "true", "inc");
							                            db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$CustomerIdDoc, filterthreadLog, "true", "inc");	//#MVT00038 Changes

							                            CustomerIdObj = new JsonObject();
							                            CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "blackListedMem", CustomerId);
							                            String blackListedMemID = gson.toJson(CustomerIdObj);
							                            db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", blackListedMemID, filterthreadLog, "true", "push");	//#MVT00038 Changes
							                            continue;
						                            }
				                        		}catch(Exception e) {
				                        			e.printStackTrace();
				                        		}	//#MVT00051 changes ends
				                        	}else {
				                        		continue;
				                        	}
				                        }
				                        //PKY00075 ends
				                        if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "JointPartner")) {
				                            try {
				                                if (i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("FirstNameJp").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("MiddleNameJp").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("LastNameJp").getAsString())) {
				                                    notApplicable++;
				                                    /*JsonObject id = new JsonObject(); //#MVT00037 Changes starts
				                                    id.addProperty("memberId",CustomerId);
				                                    notApplicableMem.add(id);*/ //#MVT00037 Changes ends
				                                    continue;
				                                } else {
				                                    StringBuilder fullName = new StringBuilder();
				                                    if (runEntries.get(j).getAsJsonObject().has("FirstNameJp") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("FirstNameJp").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("FirstNameJp").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("MiddleNameJp") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("MiddleNameJp").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("MiddleNameJp").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("LastNameJp") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("LastNameJp").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("LastNameJp").getAsString());
				                                    }
				                                    sCustomerName = fullName.toString().trim();
					                            	report.addProperty("Member Name", sCustomerName);

				                                }
				                            } catch (Exception e) {
												notApplicable++;
//												notApplicableMem.add(CustomerId); //#MVT00037 Changes
												continue;
				                            }
				                        } else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "SpouseName")) {
				                            try {
				                                if (i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("SpouseName").getAsString())) {
				                                	notApplicable++;
				                                	/*JsonObject id = new JsonObject(); //#MVT00037 Changes starts
				                                    id.addProperty("memberId",CustomerId);
				                                    notApplicableMem.add(id);*/ //#MVT00037 Changes ends
													continue;
				                                } else {
				                                    sCustomerName = runEntries.get(j).getAsJsonObject().get("SpouseName").getAsString();
					                            	report.addProperty("Member Name", sCustomerName);

				                                }
				                            } catch (Exception e) {
				                            	notApplicable++;
//												notApplicableMem.add(CustomerId); //#MVT00037 Changes
												continue;
				                            }
				                        } else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
				                            try {
				                                if (i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CustomerFullName").getAsString())) {
				                                	notApplicable++;
				                                	JsonObject member = new JsonObject();	//#MVT00037 Changes starts
				                                	member.addProperty("memberId",CustomerId);
				                                	member.addProperty("memberName"," ");
				                                    notApplicableMem.add(member);
				                                	continue;
				                                } else {
				                                    sCustomerName = runEntries.get(j).getAsJsonObject().get("CustomerFullName").getAsString();
				           			                report.addProperty("Member Name", sCustomerName);

				                                }
				                            } catch (Exception e) {
				                            	notApplicable++;
				                            	JsonObject member = new JsonObject();
			                                	member.addProperty("memberId",CustomerId);
			                                    member.addProperty("memberName"," ");
			                                    notApplicableMem.add(member);	//#MVT00037 Changes ends
				                            	continue;
				                            }
				                        }else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Nominee")) {
				                            try {
				                                if (i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("NomineeFName").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("NomineeMName").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("NomineeLName").getAsString())) {
				                                	notApplicable++;
				                                	/*JsonObject id = new JsonObject(); //#MVT00037 Changes starts
				                                    id.addProperty("memberId",CustomerId);
				                                    notApplicableMem.add(id);*/ //#MVT00037 Changes ends
													continue;
				                                } else {
				                                    StringBuilder fullName = new StringBuilder();
				                                    if (runEntries.get(j).getAsJsonObject().has("NomineeFName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("NomineeFName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("NomineeFName").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("NomineeMName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("NomineeMName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("NomineeMName").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("NomineeLName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("NomineeLName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("NomineeLName").getAsString());
				                                    }
				                                    sCustomerName = fullName.toString().trim();
					                            	report.addProperty("Member Name", sCustomerName);

				                                }
				                            } catch (Exception e) {
				                            	notApplicable++;
//												notApplicableMem.add(CustomerId);	//#MVT00037 Changes
												continue;
				                            }
				                        }else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "CunaBen")) {
				                            try {
				                                if (i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CunaBenFName").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CunaBenMName").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CunaBenLName").getAsString())) {
				                                	notApplicable++;
				                                	/*JsonObject id = new JsonObject();	//#MVT00037 Changes starts
				                                    id.addProperty("memberId",CustomerId);
				                                    notApplicableMem.add(id);*/	//#MVT00037 Changes ends
													continue;
				                                } else {
				                                    StringBuilder fullName = new StringBuilder();
				                                    if (runEntries.get(j).getAsJsonObject().has("CunaBenFName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CunaBenFName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("CunaBenFName").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("CunaBenMName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CunaBenMName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("CunaBenMName").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("CunaBenLName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("CunaBenLName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("CunaBenLName").getAsString());
				                                    }
				                                    sCustomerName = fullName.toString().trim();
					                            	report.addProperty("Member Name", sCustomerName);

				                                }
				                            } catch (Exception e) {
				                            	notApplicable++;
//												notApplicableMem.add(CustomerId); //#MVT00037 Changes
												continue;
				                            }
				                        }else if (i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "ClicoBen")) {
				                            try {
				                                if (i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("ClicoBenFName").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("ClicoBenMName").getAsString()) && i$outis.$iStrBlank(runEntries.get(j).getAsJsonObject().get("ClicoBenLName").getAsString())) {
				                                	notApplicable++;
				                                	/*JsonObject id = new JsonObject();	//#MVT00037 Changes starts
				                                    id.addProperty("memberId",CustomerId);
				                                    notApplicableMem.add(id);*/	//#MVT00037 Changes
													continue;
				                                } else {
				                                    StringBuilder fullName = new StringBuilder();
				                                    if (runEntries.get(j).getAsJsonObject().has("ClicoBenFName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("ClicoBenFName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("ClicoBenFName").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("ClicoBenMName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("ClicoBenMName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("ClicoBenMName").getAsString());
				                                        fullName.append(" ");
				                                    }
				                                    if (runEntries.get(j).getAsJsonObject().has("ClicoBenLName") && !I$utils.$iStrBlank(runEntries.get(j).getAsJsonObject().get("ClicoBenLName").getAsString())) {
				                                        fullName.append(runEntries.get(j).getAsJsonObject().get("ClicoBenLName").getAsString());
				                                    }
				                                    sCustomerName = fullName.toString().trim();
					                            	report.addProperty("Member Name", sCustomerName);

				                                }
				                            } catch (Exception e) {
				                            	notApplicable++;
//												notApplicableMem.add(CustomerId); //#MVT00037 Changes
												continue;
				                            }
				                        }
				                        String custName = sCustomerName;
				                        JsonObject searchFields = new JsonObject();
				                        JsonObject isonMsgCopy = isonMsg.deepCopy();
				                        JsonObject j$body = isonMsgCopy.get("i-body").getAsJsonObject();
				                        try { //#MVT00135 changes begins
											if (!i$outis.$iStrFuzzyMatch(argJson.get("scanningData").getAsString(), "Member")) {
												JsonObject match = new JsonObject();
												JsonObject uni = new JsonObject();
												String memId = runEntries.get(j).getAsJsonObject().get("CustomerId")
														.getAsString();
												match.addProperty("CustomerId", memId);
												uni.addProperty("_id", 0);
												uni.addProperty("CustomerFullName", 1);
												JsonObject custObj = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", match, uni);
					                            j$body.addProperty("", custObj.get("CustomerFullName").getAsString());
					                            custName = custObj.get("CustomerFullName").getAsString();
											}
				                        	
				                            searchFields.addProperty("FullName", sCustomerName);
				                            j$body.add("searchFields", searchFields);
				                            j$body.addProperty("ScanType", argJson.get("scanningData").getAsString()+ "Scan");
				                            j$body.addProperty("CustomerId", CustomerId);
				                            j$body.addProperty("applicationId", "SDN_" + I$Imputils.generateRandomString(8));
				                        } catch (Exception e) {} //#MVT00135 changes ends
				                        i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_BDYTAG, j$body);
//				                        JsonObject result$ = I$sdn.sdnScanInitiator(isonMsgCopy);
				                        
				                        String ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.isrvccontrollers.SdnScanController";
										Class<?> ctrlClass;
										ctrlClass = Class.forName(ScrCtrlClass);
										JsonObject result$ = null;
										Method ctrlFunc = null;
										ctrlFunc = ctrlClass.getMethod("sdnScanInitiator", JsonObject.class);
										Object ctrl$Caller = ctrlClass.newInstance();
										result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsgCopy);
				                        
				                       try {
				                            if (I$utils.$iStrFuzzyMatch(result$.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(), "i-SUCC")) {  //#MVT00035 Changes starts
				           			            double score = result$.get("i-body").getAsJsonObject().get("ScanResultsF").getAsJsonObject().get("MaxPercent").getAsDouble();
				           			            JsonObject cif = new JsonObject();
				           			            String cifId = result$.get("i-body").getAsJsonObject().get("CustomerId").getAsString();
				           			            cif.addProperty("memberId", cifId);
				           			            cif.addProperty(argJson.get("scanningData").getAsString()+"Name", sCustomerName);
				           			            cif.addProperty("memberName", custName);
				           			            cif.addProperty("status", "OPEN");	//#MVT00051 changes
			           			                report.addProperty("Scan Type", argJson.get("scanningData").getAsString() +"Scan");
				                                if (score >= 75) {	//#MVT00035 Changes ends #MVT00052 Changes starts
				                		            cif.addProperty("ScanResult", "Critical");
				                		            report.addProperty("Scan Result", "Critical");
				                		            Critical.add(cif);
				                		            totalScannedRecords.add(cif);
				                		            reportsRecords.add(report);
				                		            Critical1++;
				                		            totalScannedRecordsCount++;
				                		        } else if (score >= 65 & score < 75) {
				                		            cif.addProperty("ScanResult", "High");
				                		            report.addProperty("Scan Result", "High");
				                		        	High.add(cif);
				                		        	totalScannedRecords.add(cif);
				                		        	reportsRecords.add(report);
				                		            High1++;
				                		            totalScannedRecordsCount++;
				                		        } else if (score >= 45 & score < 65) {
				                		        	cif.addProperty("ScanResult", "Significant");
				                		        	report.addProperty("Scan Result", "Significant");
				                		        	Significant.add(cif);
				                		        	totalScannedRecords.add(cif);
				                		        	reportsRecords.add(report);
				                		        	Significant1++;
				                		        	totalScannedRecordsCount++;
				                		        } else if (score >= 30 & score < 45) {
				                		            cif.addProperty("ScanResult", "Medium");
				                		            report.addProperty("Scan Result", "Medium");
				                		        	Medium.add(cif);
				                		        	totalScannedRecords.add(cif);
				                		        	reportsRecords.add(report);
				                		            Medium1++;
				                		            totalScannedRecordsCount++;
				                		        } else if (score >= 15 & score < 30) {
				                		        	cif.addProperty("ScanResult", "Low");
				                		        	report.addProperty("Scan Result", "Low");
				                		        	Low.add(cif);
				                		        	totalScannedRecords.add(cif);
				                		        	reportsRecords.add(report);
				                		        	Low1++;
				                		        	totalScannedRecordsCount++;
				                		        } else if (score > 0 & score < 15) {
				                		        	cif.addProperty("ScanResult", "Very_Low");
				                		        	report.addProperty("Scan Result", "Very_Low");
				                		        	Very_Low.add(cif);
				                		        	totalScannedRecords.add(cif);
				                		        	reportsRecords.add(report);
				                		        	Very_Low1++;
				                		        	totalScannedRecordsCount++;
				                		        } else {
				                		        	cif.addProperty("ScanResult", "Clean");
				                		        	report.addProperty("Scan Result", "Clean");
				                		        	Clean.add(cif);
				                		        	totalScannedRecords.add(cif);
				                		        	reportsRecords.add(report);
				                		        	Clean1++;
				                		        	totalScannedRecordsCount++;
				                		        }	//#MVT00052 Changes starts
				                            } else {
				                                failureCount++;
				                                failed.add(CustomerId);
				                            }
				                        } catch (Exception e) {
				                        	failureCount++;
				                        	failed.add(CustomerId);
				                            e.getMessage();
				                        } 
				                    } catch (Exception e) {
				                    	failureCount++;
			                        	failed.add(CustomerId);
			                            e.getMessage();
				                        logger.debug("Failed to forward the controller: " + e.getMessage());
				                    }
				                }
				                JsonObject CustomerIdObj1 = new JsonObject();
				                JsonObject CustomerIdObj2 = new JsonObject();
				                JsonObject dateObj = new JsonObject();
				                JsonObject Critical2 = new JsonObject();
				                JsonObject High2 = new JsonObject();
				                JsonObject Significant2 = new JsonObject();
				                JsonObject Medium2 = new JsonObject();
				                JsonObject Low2 = new JsonObject();
				                JsonObject Very_Low2 = new JsonObject();
				                JsonObject Clean2 = new JsonObject();
				                JsonObject failed2 = new JsonObject();
				                JsonObject ignoredOnce2 = new JsonObject();//#PAV00027 Changes
				                JsonObject onHold2 = new JsonObject();//#PAV00027 Changes
				                JsonObject notApplicableMem2 = new JsonObject();
				                JsonObject totalScannedRecords2 = new JsonObject();
				                JsonObject reportRecords2 = new JsonObject();
				                reportRecords2.add("$each", reportsRecords);
				                Critical2.add("$each", Critical);
				                High2.add("$each", High);
				                Significant2.add("$each", Significant);
				                Medium2.add("$each", Medium);
				                Low2.add("$each", Low);
				                Very_Low2.add("$each", Very_Low);
				                Clean2.add("$each", Clean);
				                failed2.add("$each", failed);
				                ignoredOnce2.add("$each", ignoredOnce); //#PAV00027 Changes
				                onHold2.add("$each", onHold);//#PAV00027 Changes
				                notApplicableMem2.add("$each", notApplicableMem);
				                totalScannedRecords2.add("$each", totalScannedRecords);
				                
		    	    			 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Critical", Critical2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "High", High2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Significant", Significant2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Medium", Medium2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Low", Low2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Very_Low", Very_Low2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Clean", Clean2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "failed", failed2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "ignoredOnce", ignoredOnce2);//#PAV00027 Changes
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "onHold", onHold2);//#PAV00027 Changes
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "notApplicableMem", notApplicableMem2);
		    	                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "totalScannedRecords",totalScannedRecords2);
		    	 		         String i$CustomerIdDoc = gson.toJson(CustomerIdObj1);
		    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$CustomerIdDoc, tempFilter, "true", "push");
		    	        		try {
		    	        			JsonObject reportObj = new JsonObject();
		    	        			JsonObject reportFltr = new JsonObject();
		    	        			reportFltr.addProperty("ReportType", "List of all "+argJson.get("scanningData").getAsString()+" with Scan results of a specific KYM Job run.");
		    	        			reportFltr.addProperty("ScanId", argJson.get("uniqueId").getAsString());
		    	        			reportObj.add("reportResults", reportRecords2);
		    	        			String i$reportsDoc = gson.toJson(reportObj);
			    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_KYM_REPORT", i$reportsDoc, reportFltr, "true", "push");
		    	        		}catch(Exception e) {
		    	        		}
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "CriticalCount", Critical1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "HighCount", High1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "SignificantCount", Significant1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "MediumCount", Medium1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "LowCount", Low1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "Very_LowCount", Very_Low1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "CleanCount", Clean1);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "successCount", totalScannedRecordsCount);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "totalScannedRecordsCount", totalScannedRecordsCount);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "notApplicableMemCount", notApplicable);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "failureCount", failureCount);
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "ignoreOnceCount", ignoreOnceCount);//#PAV00027 Changes
		    	 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "onHoldCount", onHoldCount);//#PAV00027 Changes
		    	 		        String i$CountDoc = gson.toJson(CustomerIdObj2);
		    	 		        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CountDoc, filterthreadLog, "true", "inc");
//		    	 		        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", i$CountDoc, filterthreadLog, "true", "inc");	//#MVT00036  changes
		    	 		        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$CountDoc, filterthreadLog, "true", "inc");	//#MVT00038 changes
		    	 		        dateObj.addProperty("lastUpdatedAt", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
		    							.format(Calendar.getInstance().getTime()));
		    	        		db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG", dateObj, filterthreadLog);	//#SRM00061 changes
		    	 		        
				            } catch (Exception e) {
				                logger.debug("Failed to retrieve data: " + e.getMessage());
				            }
		        	}catch(Exception e) {
		        		
		        	}
		       
		        }
		        threadCount = threadCount + 1;
		        JsonObject CompletedThreads = new JsonObject();
		        CompletedThreads.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "completedThreads", threadCount);
		        String i$ThreadDoc = gson.toJson(CompletedThreads);
		        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", i$ThreadDoc, filterthreadLog, "true", "push");	//#MVT00038 changes

		        JsonObject projection3 = new JsonObject();
		        projection3.addProperty("_id", 0);
		        projection3.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "completedThreads", 1);
		        projection3.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "failureCount", 1);// #MVT00049 changes
		        JsonArray CompletedThreadsSize = db$Ctrl.db$GetSummRowsArray("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", filterthreadLog, projection3, 0, 0);	//#MVT00038 changes
		        int completed$Threads = CompletedThreadsSize.get(0).getAsJsonObject().get(argJson.get("scanningData").getAsString() + "Scan").getAsJsonObject().get("completedThreads").getAsJsonArray().size();
		        if (completed$Threads <= 9) {
		            try {
		                Thread.currentThread().interrupt();
		            } catch (Exception e) {

		            }
		        }
		        if (completed$Threads >= 10) {
		            try {
		            	/*
		            	int failed$Count = CompletedThreadsSize.get(0).getAsJsonObject().get(argJson.get("scanningData").getAsString() + "Scan").getAsJsonObject().get("failureCount").getAsInt();// #MVT00049 changes starts
						if (failed$Count > 0) {
							try {
								JsonArray fail = new JsonArray();
								JsonObject proj1 = new JsonObject();
								proj1.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "failed",1);
								for (int i = 0; i < completed$Threads; i++) {
									JsonObject fltr = new JsonObject();
									fltr.addProperty("unqId", argJson.get("uniqueId").getAsString() + "_Thread" + i);
									JsonObject faileddData = db$Ctrl.db$GetRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP",fltr, proj1);
									if (I$utils.$isNullOrEmpty(faileddData)) {
										JsonArray tempFailed = faileddData.get("failed").getAsJsonArray();
										fail.addAll(tempFailed);
									}
								}
								JsonObject reScan = new JsonObject();
								reScan.addProperty("unqRunId",isonMsg.get("i-body").getAsJsonObject().get("referenceNo").getAsString());
								reScan.add("filterthreadLog", filterthreadLog);
								reScan.add("failed$Count", fail);
								reScan.addProperty("scanningData", argJson.get("scanningData").getAsString());
								ReLogging$OfFailedDocs(reScan);
							} catch (Exception e) {
								e.printStackTrace();
							}	// #MVT00049 changes ends
							
						}*/
						try {
							JsonObject jobStatus = new JsonObject(); // #MVT00036 Changes starts
							JsonObject proj = new JsonObject();
							JsonObject scannedParam = new JsonObject();	// #MVT00048 changes starts
							JsonObject tempFlter = new JsonObject();
							JsonObject scannedParams = new JsonObject();
							JsonArray clean = new JsonArray();
							JsonArray critical = new JsonArray();
							JsonArray high = new JsonArray();
							JsonArray significant = new JsonArray();
							JsonArray low = new JsonArray();
							JsonArray meduim = new JsonArray();
							JsonArray veryLow = new JsonArray();
							JsonArray failed = new JsonArray();
							JsonArray ignoredOnce = new JsonArray();//#PAV00027 Changes
							JsonArray onHold = new JsonArray();//#PAV00027 Changes

							String scan = argJson.get("scanningData").getAsString();
							proj.addProperty(scan + "Scan", 1);
							jobStatus.addProperty(scan + "Scan" + "." + "status", "Completed");
							jobStatus.addProperty(scan + "Scan" + "." + "completedTime",
									new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()));
							db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", jobStatus, filterthreadLog,"true");	// #MVT00044 changes starts
//							db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", jobStatus, filterthreadLog,"true");
							
							for (int i = 0; i < completed$Threads; i++) {
								try {
									jobStatus.remove(scan+"Scan"+"."+"completedTime");// #MVT00050 changes starts
									tempFlter.addProperty("unqId", argJson.get("uniqueId").getAsString()+"_Thread"+i);
									JsonObject scannedData = db$Ctrl.db$GetRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP",tempFlter, proj);

									db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", jobStatus, tempFlter,"true");
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("Clean")) {
										JsonArray tempClean = scannedData.get(scan+"Scan").getAsJsonObject().get("Clean").getAsJsonArray();
										clean.addAll(tempClean);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("Critical")) {
										JsonArray tempCritical = scannedData.get(scan+"Scan").getAsJsonObject().get("Critical").getAsJsonArray();
										critical.addAll(tempCritical);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("High")) {
										JsonArray tempHigh = scannedData.get(scan+"Scan").getAsJsonObject().get("High").getAsJsonArray();
										high.addAll(tempHigh);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("Significant")) {
										JsonArray tempSignificant = scannedData.get(scan+"Scan").getAsJsonObject().get("Significant").getAsJsonArray();
										significant.addAll(tempSignificant);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("Low")) {
										JsonArray tempLow = scannedData.get(scan+"Scan").getAsJsonObject().get("Low").getAsJsonArray();
										low.addAll(tempLow);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("Medium")) {
										JsonArray tempMedium = scannedData.get(scan+"Scan").getAsJsonObject().get("Medium").getAsJsonArray();
										meduim.addAll(tempMedium);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("Very_Low")) {
										JsonArray tempVery_Low = scannedData.get(scan+"Scan").getAsJsonObject().get("Very_Low").getAsJsonArray();
										veryLow.addAll(tempVery_Low);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("failed")) {
										JsonArray tempfailed = scannedData.get(scan+"Scan").getAsJsonObject().get("failed").getAsJsonArray();
										failed.addAll(tempfailed);
									}	// #MVT00050 changes ends
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("ignoredOnce")) {//#PAV00027 Changes Starts
										JsonArray tempignoreONce = scannedData.get(scan+"Scan").getAsJsonObject().get("ignoredOnce").getAsJsonArray();
										ignoredOnce.addAll(tempignoreONce);
									}
									if(scannedData.has(scan+"Scan") && scannedData.get(scan+"Scan").getAsJsonObject().has("onHold")) {
										JsonArray temponHold = scannedData.get(scan+"Scan").getAsJsonObject().get("onHold").getAsJsonArray();
										onHold.addAll(temponHold);
									}//#PAV00027 Changes Ends
								}catch(Exception e) {
									e.printStackTrace();
								}
							}	//#MVT00053 Changes starts
							JsonArray memberdata = new JsonArray();
							JsonObject failedCifs = new JsonObject();
							failedCifs.add("failedCifs", failed);  // #SRM00062 changes
							memberdata.addAll(clean);
							memberdata.addAll(critical);
							memberdata.addAll(high);
							memberdata.addAll(significant);
							memberdata.addAll(low);
							memberdata.addAll(meduim);
							memberdata.addAll(veryLow);
							memberdata.add(failedCifs); // #SRM00062 changes
							memberdata.addAll(ignoredOnce);//#PAV00027 Changes
							memberdata.addAll(onHold);//#PAV00027 Changes
//							scannedParam.add("MsgData", scannedParams);	// #MVT00048 changes ends
//							scannedParam.addProperty("scanId", argJson.get("uniqueId").getAsString()+"_"+ scan + "Scan");
							db$Ctrl.db$InsertMany("ZKYC_"+scan + "Scan_"+argJson.get("uniqueId").getAsString(), memberdata);
							
							JsonObject indexfltr = new JsonObject();
							indexfltr.addProperty("INDEXCOlNAME", "ScanResult");
							db$Ctrl.db$createIndex("ZKYC_"+scan + "Scan_"+argJson.get("uniqueId").getAsString(), gson.toJson(indexfltr));
//							JsonObject upldData = db$Ctrl.db$GrdFSScanUpld(scannedParam);
//							JsonObject dwnldData = db$Ctrl.db$GrdFSScanDwld(scannedParam); //#MVT00044 changes ends #MVT00053 Changes ends
		
							JsonArray cScanningParam = isonMsg.get("i-body").getAsJsonObject().get("scanningParam")
									.getAsJsonArray();
							isonMsg.get("i-body").getAsJsonObject().get("scanningParam").getAsJsonArray().remove(0);
							if (cScanningParam.size() > 0) {
								String ScrCtrlClass = null;
								JsonObject isonheader = new JsonObject();
								JsonObject isonMapJson = new JsonObject();
								ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.isrvccontrollers.ICifSdnScanController";
								Class<?> ctrlClass;
								ctrlClass = Class.forName(ScrCtrlClass);
								JsonObject result$ = null;
								Method ctrlFunc = null;
								ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
								Object ctrl$Caller = ctrlClass.newInstance();
								result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
								if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
									logger.debug("JAVA METHOD CALLED SUCCESSFULLY");
								}
							}else {
								try { // #SRM00067 Changes start
					                srvcFunction.jobEmailNotification("KYM", "Completed", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()));
					            } catch (Exception e) {
					            	e.printStackTrace();
					            } // #SRM00067 Changes end
								JsonObject beforeUpdate = new JsonObject();
								beforeUpdate.addProperty("completedDate", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
										.format(Calendar.getInstance().getTime()));
								beforeUpdate.addProperty("scanningStatus", "Completed");
								db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG", beforeUpdate, filterthreadLog, "true");
//								db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", beforeUpdate, filterthreadLog, "true");
								db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS_TEMP", beforeUpdate, filterthreadLog, "true");
								try {
									JsonObject isonMsg1 = new JsonObject();
									isonMsg1.addProperty("scanId", argJson.get("uniqueId").getAsString());
									i$kyc.reportsHandler(isonMsg1, "KYM");
								} catch (Exception e) {
								}
							}//#MVT00036 Changes ends
							 try {
					                Thread.currentThread().interrupt();
					            } catch (Exception e) {
					            }
						} catch (Exception e) {
							e.printStackTrace();
						}
		            } catch (Exception e) {
		            	e.printStackTrace();
		            }
		        }

		    } catch (Exception e) {
		        e.getMessage();
		    }
		}

	 public void ReLogging$OfFailedDocs(JsonObject argJson) {
		 Gson gson = new Gson();
		    try {
		        JsonObject projection = new JsonObject();
		        projection.addProperty("ScanResultsF", 1);
		        projection.addProperty("CustomerId", 1);
		        projection.addProperty("_id", 0);
		        
		        int Critical1 = 0, High1 = 0, Significant1 = 0, Medium1 = 0, Low1 = 0, Very_Low1 = 0, Clean1 = 0,
		        		totalLoggedRecordsCount = 0, failureCount = 0, notApplicable = 0;
                JsonArray Critical = new JsonArray();
                JsonArray High = new JsonArray();
                JsonArray Significant = new JsonArray();
                JsonArray Medium = new JsonArray();
                JsonArray Low = new JsonArray();
                JsonArray Very_Low = new JsonArray();
                JsonArray Clean = new JsonArray();
                JsonArray failed = new JsonArray();
                JsonArray notApplicableMem = new JsonArray();
                JsonArray totalLoggedRecords = new JsonArray();
		        
		        JsonArray reScan = argJson.get("failed$Count").getAsJsonArray();
		        for (int k = 0; k < reScan.size(); k++) {
		        	JsonObject db$ScanData = new JsonObject();
		            try {
		                String custNo = reScan.get(k).getAsString();
		                JsonObject filter = new JsonObject();
		                filter.addProperty("referenceNo", argJson.get("unqRunId").getAsString());
		                filter.addProperty("CustomerId", custNo);
		                filter.addProperty("ScanType", argJson.get("scanningData").getAsString() + "Scan");
		                db$ScanData = db$Ctrl.db$GetRow("ICOR_M_SDN_SCAN", filter, projection);
		                double score = db$ScanData.get("ScanResultsF").getAsJsonObject().get("MaxPercent").getAsDouble();
   			            String cif = db$ScanData.get("CustomerId").getAsString();
                        if (score >= 75) {
        		            Critical.add(cif);
        		            totalLoggedRecords.add(cif);
        		            Critical1++;
        		            totalLoggedRecordsCount++;
        		        } else if (score >= 65 & score < 75) {
        		        	High.add(cif);
        		        	totalLoggedRecords.add(cif);
        		            High1++;
        		            totalLoggedRecordsCount++;
        		        } else if (score >= 45 & score < 65) {
        		        	Significant.add(cif);
        		        	totalLoggedRecords.add(cif);
        		        	Significant1++;
        		        	totalLoggedRecordsCount++;
        		        } else if (score >= 30 & score < 45) {
        		        	Medium.add(cif);
        		        	totalLoggedRecords.add(cif);
        		            Medium1++;
        		            totalLoggedRecordsCount++;
        		        } else if (score >= 15 & score < 30) {
        		        	Low.add(cif);
        		        	totalLoggedRecords.add(cif);
        		        	Low1++;
        		        	totalLoggedRecordsCount++;
        		        } else if (score > 0 & score < 15) {
        		        	Very_Low.add(cif);
        		        	totalLoggedRecords.add(cif);
        		        	Very_Low1++;
        		        	totalLoggedRecordsCount++;
        		        } else {
        		        	Clean.add(cif);
        		        	totalLoggedRecords.add(cif);
        		        	Clean1++;
        		        	totalLoggedRecordsCount++;
        		        }
		                
		            } catch (Exception e) {
		            	 failureCount++;
                         failed.add(db$ScanData.get("CustomerId").getAsString());
		            }
		        }
		        
		        JsonObject CustomerIdObj1 = new JsonObject();
                JsonObject CustomerIdObj2 = new JsonObject();
                JsonObject Critical2 = new JsonObject();
                JsonObject High2 = new JsonObject();
                JsonObject Significant2 = new JsonObject();
                JsonObject Medium2 = new JsonObject();
                JsonObject Low2 = new JsonObject();
                JsonObject Very_Low2 = new JsonObject();
                JsonObject Clean2 = new JsonObject();
                JsonObject failed2 = new JsonObject();
                JsonObject notApplicableMem2 = new JsonObject();
                JsonObject totalLoggedRecords2 = new JsonObject();
                Critical2.add("$each", Critical);
                High2.add("$each", High);
                Significant2.add("$each", Significant);
                Medium2.add("$each", Medium);
                Low2.add("$each", Low);
                Very_Low2.add("$each", Very_Low);
                Clean2.add("$each", Clean);
                failed2.add("$each", failed);
                notApplicableMem2.add("$each", notApplicableMem);
                totalLoggedRecords2.add("$each", totalLoggedRecords);
                
    			 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Critical", Critical2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "High", High2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Significant", Significant2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Medium", Medium2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Low", Low2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Very_Low", Very_Low2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "Clean", Clean2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "failed", failed2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "notApplicableMem", notApplicableMem2);
                 CustomerIdObj1.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "totalScannedRecords",totalLoggedRecords2);
 		        String i$CustomerIdDoc = gson.toJson(CustomerIdObj1);
        		db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", i$CustomerIdDoc, argJson.get("filterthreadLog").getAsJsonObject(), "true", "push");
 		        
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "CriticalCount", Critical1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "HighCount", High1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "SignificantCount", Significant1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "MediumCount", Medium1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "LowCount", Low1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "Very_LowCount", Very_Low1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "CleanCount", Clean1);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "successCount", totalLoggedRecordsCount);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "totalScannedRecordsCount", totalLoggedRecordsCount);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "notApplicableMemCount", notApplicable);
 		        CustomerIdObj2.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "failureCount", failureCount);
 		        String i$CountDoc = gson.toJson(CustomerIdObj2);
 		        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG", i$CountDoc, argJson.get("filterthreadLog").getAsJsonObject(), "true", "inc");
 		        db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", i$CountDoc, argJson.get("filterthreadLog").getAsJsonObject(), "true", "inc");
 		        
				JsonObject CustomerPull = new JsonObject();
				JsonObject totalLoggedRecords3 = new JsonObject();
				totalLoggedRecords3.add("$in", totalLoggedRecords);
				CustomerPull.add(argJson.get("scanningData").getAsString() + "Scan" + "." + "failed", totalLoggedRecords3);
				String i$CustomerIdDoc1 = gson.toJson(CustomerPull);
				db$Ctrl.db$UpdateRowOperator("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", i$CustomerIdDoc1, argJson.get("filterthreadLog").getAsJsonObject(), "true", "pull");
		        
		        JsonObject projection3 = new JsonObject();
		        projection3.addProperty("_id", 0);
		        projection3.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "failed", 1);
		        JsonArray CompletedThreadsSize = db$Ctrl.db$GetSummRowsArray("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", argJson.get("filterthreadLog").getAsJsonObject(), projection3, 0, 0);
		        int failedArrsize = 0;
		        failedArrsize = CompletedThreadsSize.get(0).getAsJsonObject().get(argJson.get("scanningData").getAsString() + "Scan").getAsJsonObject().get("failed").getAsJsonArray().size();
		        if (failedArrsize <= 0) {
		            JsonObject CustomerIdObj = new JsonObject();
		            CustomerIdObj.addProperty(argJson.get("scanningData").getAsString() + "Scan" + "." + "failureCount", failedArrsize);
		            db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG_DETAILS", CustomerIdObj, argJson.get("filterthreadLog").getAsJsonObject());
		            db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_SCAN_LOG", CustomerIdObj, argJson.get("filterthreadLog").getAsJsonObject());
		        }
		    } catch (Exception e) {

		        logger.debug("Failed to reInserting the scanned result: " + e.getMessage());
		    }
		}
	   private JsonObject sdnScanningReport(JsonObject isonMsg) {//#SRP00075 Starts
		   try {
				JsonObject date = new JsonObject();
				JsonArray date1 = new JsonArray();
				JsonObject preFilter = new JsonObject();
				JsonObject preFilter1 = new JsonObject();
				JsonObject filter = new JsonObject();
				JsonArray preFilter2 = new JsonArray();
				JsonArray preFilter3 = new JsonArray();
				JsonObject projection = new JsonObject();
				JsonObject ScanId=new JsonObject();
				JsonObject filter2=new JsonObject();
				JsonObject projection1=new JsonObject();
				JsonObject attachmentData = new JsonObject();
				JsonObject unqId=new JsonObject();
				String intPgNo;
				int intRecs;
				int skip = 0;
				int limit=0;
				Date grtrDate = I$utils.changeDate(1, "SUB", "D");
				Date lsrDate = I$utils.changeDate(0, "SUB", "D");
				String grtrDateS = I$utils.changeDateFormat(grtrDate, "dd-MMM-yyyy HH:mm:ss");
				String lsrDateS = I$utils.changeDateFormat(lsrDate, "dd-MMM-yyyy HH:mm:ss");
				date.addProperty("$gt", grtrDateS);
				date.addProperty("$lte", lsrDateS);
				preFilter.add("initiatedDate", date);
				preFilter2.add(preFilter);
				filter.add("$or", preFilter2);
															//SRI00038 start changes 
				date1.add("high");
				date1.add("Critical");
//				date1.add("Clean");
				preFilter1.add("$in", date1);
				filter2.add("ScanResult", preFilter1);
				projection.addProperty("unqId", 1);
				projection.addProperty("initiatedDate", 1);
				projection.addProperty("MemberScan.CleanCount", 1);
				projection.addProperty("MemberScan.CriticalCount", 1);
				projection.addProperty("MemberScan.HighCount", 1);
				projection.addProperty("MemberScan.totalScannedRecordsCount", 1);
				projection.addProperty("_id", 0);
				projection1.addProperty("memberId", 1);
				projection1.addProperty("MemberName", 1); 
				projection1.addProperty("status", 1);
				projection1.addProperty("ScanResult", 1);
				projection1.addProperty("_id", 0);
				JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_M_CUSTOMER_SCAN_LOG", filter, projection);				
				for (int i = 0; i < i$Body.size(); i++) {
					JsonObject jsonObject = i$Body.get(i).getAsJsonObject();
						if (jsonObject.has("unqId")) {
						    String CollectionName = "ZKYC_MemberScan_" + jsonObject.get("unqId").getAsString();
						    JsonArray i$Body1 = db$Ctrl.db$GetRows(CollectionName, filter2, projection1);
						    StringBuilder pdfContent = new StringBuilder();

						    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
						    Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
						    PdfWriter.getInstance(document, byteArrayOutputStream);
						    document.open();

						    try {
						        Font font = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
						        Font font2 = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
						        Paragraph titleParagraph = new Paragraph("Alert For SDN Scanning", font2);
						        titleParagraph.setAlignment(Element.ALIGN_CENTER);
						        document.add(titleParagraph);

						        Paragraph dateParagraph = new Paragraph();
						        dateParagraph.setFont(font2);
						        dateParagraph.add("SDN Scanning Run Date: ");
						        dateParagraph.add(new Phrase(I$Ioutils.$getISONow().replace("T", ", ").replace("Z", "")));
						        dateParagraph.setAlignment(Element.ALIGN_RIGHT);
						        document.add(dateParagraph);

						        document.add(new Paragraph("\n"));
						        PdfPTable table = new PdfPTable(new float[]{2, 2, 2, 2}); // 4 columns
						        table.setWidthPercentage(100);

						        table.addCell(new PdfPCell(new Phrase("Member ID", font2)));
						        table.addCell(new PdfPCell(new Phrase("Member Name", font2)));
						        table.addCell(new PdfPCell(new Phrase("Status", font2)));
						        table.addCell(new PdfPCell(new Phrase("Scan Result", font2)));

						        // Add data from i$Body1 to the table
						        for (int j = 0; j < i$Body1.size(); j++) {
						            JsonObject data = i$Body1.get(j).getAsJsonObject();
						            table.addCell(new PdfPCell(new Phrase(data.get("memberId").getAsString(), font)));
						            table.addCell(new PdfPCell(new Phrase(data.get("MemberName").getAsString(), font)));
						            table.addCell(new PdfPCell(new Phrase(data.get("status").getAsString(), font)));
						            table.addCell(new PdfPCell(new Phrase(data.get("ScanResult").getAsString(), font)));
						        }

						        document.add(table);

						    } catch (Exception e) {
						        e.printStackTrace();
						    } finally {
						        document.close();

						        byte[] pdfBytes = byteArrayOutputStream.toByteArray();
						        String base64Str = Base64.getEncoder().encodeToString(pdfBytes);

						        attachmentData.addProperty("docType", "application/pdf");
						        attachmentData.addProperty("fileName", "Sdn Scanning report.pdf");
						        attachmentData.addProperty("template", base64Str);

						    }
							JsonObject dataSetFilter = new JsonObject();
							JsonObject datasetProjection = new JsonObject();
							JsonObject emailDataset$Data = new JsonObject();
							String keyE = new String();
							String keyM = new String();
							JsonObject argJson = new JsonObject();
							dataSetFilter.addProperty("datasetId", "Dataset_5680");
							datasetProjection.addProperty("userDetails", 1);
							datasetProjection.addProperty("sendEmail", 1);
							datasetProjection.addProperty("sendSms", 1);
							emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
							if (!I$utils.$isNull(emailDataset$Data)) {
								JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
								boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
								boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
								for (int i1 = 0; i1 < userDet.size(); i1++) {
									try {
										if (sendEmail) {
											JsonObject jsonObject1 = userDet.get(i1).getAsJsonObject();
											String Email = jsonObject1.get("userEmailId").getAsString();
											keyE = keyE.concat(Email);
											if (i1 < userDet.size() - 1) {
												keyE = keyE.concat(",");
											}
										}
										if (sendSMS) {
											JsonObject jsonObject2 = userDet.get(i1).getAsJsonObject();
											String SMS = jsonObject2.get("userMobileNo").getAsString();
											keyM = keyM.concat(SMS);
											if (i1 < userDet.size() - 1) {
												keyM = keyM.concat(",");
											}
										}
									} catch (Exception e) {
									}
								}
								try {
									JsonObject map$Data = new JsonObject();
									JsonArray attachment = new JsonArray();
									map$Data.addProperty("tmp$name", "TMPL#TT#SDN#SCANNING#ALERT#MAIL");
									int siz = i$Body.size();
									for (int i2 = 0; i2 < i$Body.size(); i2++) {
										try {
											JsonObject db$Docs = i$Body.get(i2).getAsJsonObject();
									        map$Data.addProperty("totalScannedRecordsCount", db$Docs.get("MemberScan").getAsJsonObject().get("totalScannedRecordsCount").getAsString());
									        map$Data.addProperty("CleanCount", db$Docs.get("MemberScan").getAsJsonObject().get("CleanCount").getAsString());
									        map$Data.addProperty("CriticalCount", db$Docs.get("MemberScan").getAsJsonObject().get("CriticalCount").getAsString());
									        map$Data.addProperty("HighCount", db$Docs.get("MemberScan").getAsJsonObject().get("HighCount").getAsString());
										}catch(Exception e) {}
									}
									argJson.add("map$Data", map$Data);
									argJson.addProperty("key$Type", "notification");
									argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
									argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
									attachment.add(attachmentData);
									argJson.add("attachment", attachment);
									if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
										JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
										JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
									}
								} catch (Exception e) {
									logger.debug("Failed to send email and sms" + e.getMessage());
									return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
								}
							} else {
								logger.debug("Failed to find Email/Mobile for Alert.");
								return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
							}
						} 
					}
				}catch (Exception e) {
					logger.debug("Error in sending Sdn Scanning Alert Notification");
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in sending Sdn Scanning Alert Notification");
				}
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	   }	
	 //SRI00038  changes Ends
	public ICifSdnScanController() {
	    // Constructor
	}
	// ##PKY00065 ends
}