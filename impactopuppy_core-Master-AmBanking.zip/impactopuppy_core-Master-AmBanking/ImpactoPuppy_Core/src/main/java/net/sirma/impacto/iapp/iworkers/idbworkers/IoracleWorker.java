/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Jan 24, 2019 | #00000001   | Initial writing
      |0.2.1       | Vijay 		| Mar 06, 2019 | #BVB00088   | Changes for Generic Adapter response handling
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins

package net.sirma.impacto.iapp.iworkers.idbworkers;

import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.iconfig.OracleConfig;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IoracleWorker {
	private static final Logger logger = LoggerFactory.getLogger(ImongoWorker.class);
	private static final Ioutils I$utils = new Ioutils();
	private static final IResManipulator I$ResMan = new IResManipulator();

	private int getType(String sType) {
		if (I$utils.$iStrFuzzyMatch(sType, "ARRAY"))
			return Types.ARRAY;
		else if (I$utils.$iStrFuzzyMatch(sType, "BIGINT"))
			return Types.BIGINT;
		else if (I$utils.$iStrFuzzyMatch(sType, "BIT"))
			return Types.BIT;
		else if (I$utils.$iStrFuzzyMatch(sType, "BLOB"))
			return Types.BLOB;
		else if (I$utils.$iStrFuzzyMatch(sType, "BOOLEAN"))
			return Types.BOOLEAN;
		else if (I$utils.$iStrFuzzyMatch(sType, "CHAR"))
			return Types.CHAR;
		else if (I$utils.$iStrFuzzyMatch(sType, "CLOB"))
			return Types.CLOB;
		else if (I$utils.$iStrFuzzyMatch(sType, "DATALINK"))
			return Types.DATALINK;
		else if (I$utils.$iStrFuzzyMatch(sType, "DATE"))
			return Types.DATE;
		else if (I$utils.$iStrFuzzyMatch(sType, "DECIMAL"))
			return Types.DECIMAL;
		else if (I$utils.$iStrFuzzyMatch(sType, "DISTINCT"))
			return Types.DISTINCT;
		else if (I$utils.$iStrFuzzyMatch(sType, "DOUBLE"))
			return Types.DOUBLE;
		else if (I$utils.$iStrFuzzyMatch(sType, "FLOAT"))
			return Types.FLOAT;
		else if (I$utils.$iStrFuzzyMatch(sType, "INTEGER"))
			return Types.INTEGER;
		else if (I$utils.$iStrFuzzyMatch(sType, "JAVA_OBJECT"))
			return Types.JAVA_OBJECT;
		else if (I$utils.$iStrFuzzyMatch(sType, "LONGNVARCHAR"))
			return Types.LONGNVARCHAR;
		else if (I$utils.$iStrFuzzyMatch(sType, "LONGVARBINARY"))
			return Types.LONGVARBINARY;
		else if (I$utils.$iStrFuzzyMatch(sType, "LONGVARCHAR"))
			return Types.LONGVARCHAR;
		else if (I$utils.$iStrFuzzyMatch(sType, "NCHAR"))
			return Types.NCHAR;
		else if (I$utils.$iStrFuzzyMatch(sType, "NCLOB"))
			return Types.NCLOB;
		else if (I$utils.$iStrFuzzyMatch(sType, "NULL"))
			return Types.NULL;
		else if (I$utils.$iStrFuzzyMatch(sType, "NUMERIC"))
			return Types.NUMERIC;
		else if (I$utils.$iStrFuzzyMatch(sType, "NVARCHAR"))
			return Types.NVARCHAR;
		else if (I$utils.$iStrFuzzyMatch(sType, "REAL"))
			return Types.REAL;
		else if (I$utils.$iStrFuzzyMatch(sType, "REF"))
			return Types.REF;
		else if (I$utils.$iStrFuzzyMatch(sType, "REF_CURSOR"))
			return Types.REF_CURSOR;
		else if (I$utils.$iStrFuzzyMatch(sType, "ROWID"))
			return Types.ROWID;
		else if (I$utils.$iStrFuzzyMatch(sType, "SMALLINT"))
			return Types.SMALLINT;
		else if (I$utils.$iStrFuzzyMatch(sType, "SQLXML"))
			return Types.SQLXML;
		else if (I$utils.$iStrFuzzyMatch(sType, "STRUCT"))
			return Types.STRUCT;
		else if (I$utils.$iStrFuzzyMatch(sType, "TIME"))
			return Types.TIME;
		else if (I$utils.$iStrFuzzyMatch(sType, "TIME_WITH_TIMEZONE "))
			return Types.TIME_WITH_TIMEZONE;
		else if (I$utils.$iStrFuzzyMatch(sType, "TIMESTAMP"))
			return Types.TIMESTAMP;
		else if (I$utils.$iStrFuzzyMatch(sType, "TIMESTAMP_WITH_TIMEZONE"))
			return Types.TIMESTAMP_WITH_TIMEZONE;
		else if (I$utils.$iStrFuzzyMatch(sType, "TINYINT"))
			return Types.TINYINT;
		else if (I$utils.$iStrFuzzyMatch(sType, "VARBINARY"))
			return Types.VARBINARY;
		else if (I$utils.$iStrFuzzyMatch(sType, "VARCHAR"))
			return Types.VARCHAR;
		else
			return Types.OTHER;
	};

	@SuppressWarnings("unused")
	private CallableStatement setProcVals(CallableStatement call$, String sType, String sParamName, String sObjVal,
			String sMode) {
		try {
			if (I$utils.$iStrFuzzyMatch(sMode, "OUT")) {
				call$.registerOutParameter(sParamName, getType(sType));
				return call$;
			} else if (I$utils.$iStrFuzzyMatch(sMode, "INOUT")) {
				call$.registerOutParameter(sParamName, getType(sType));
			}
			;

			if (I$utils.$iStrFuzzyMatch(sType, "CLOB")) {
				if (sObjVal != null)
					call$.setCharacterStream(sParamName, new StringReader(sObjVal), (sObjVal).length());
				else
					call$.setNull(sParamName, getType(sType));
			} else if (I$utils.$iStrFuzzyMatch(sType, "STRING")) {
				if (sObjVal != null)
					call$.setString(sParamName, sObjVal);
				else
					call$.setNull(sParamName, getType("VARCHAR"));
			} else if (I$utils.$iStrFuzzyMatch(sType, "VARCHAR")) {
				if (sObjVal != null)
					call$.setString(sParamName, sObjVal);
				else
					call$.setNull(sParamName, getType(sType));
			} else if (I$utils.$iStrFuzzyMatch(sType, "INTEGER")) {
				Integer iVal = Integer.parseInt(sObjVal);
				if (sObjVal != null)
					call$.setInt(sParamName, iVal);
				else
					call$.setNull(sParamName, getType(sType));
			} else if (I$utils.$iStrFuzzyMatch(sType, "DOUBLE")) {
				Double dVal = Double.parseDouble(sObjVal);
				if (sObjVal != null)
					call$.setDouble(sParamName, dVal);
				else
					call$.setNull(sParamName, getType(sType));
			} else if (I$utils.$iStrFuzzyMatch(sType, "FLOAT")) {
				Float fVal = Float.parseFloat(sObjVal);
				if (sObjVal != null)
					call$.setFloat(sParamName, fVal);
				else
					call$.setNull(sParamName, getType(sType));
			} else if (I$utils.$iStrFuzzyMatch(sType, "DATE")) { // Format is ddMMyyyy HH:mm:SS.sss
				SimpleDateFormat formatter = null;

				try {
					formatter = new SimpleDateFormat("ddMMyyyy HH:mm:ss.SSS");
				} catch (Exception o) {
					try {
						formatter = new SimpleDateFormat("ddMMyyyy HH:mm:ss");
					} catch (Exception ox) {
						formatter = new SimpleDateFormat("ddMMyyyy");
					}
				}
				java.util.Date utilDate = formatter.parse(sObjVal);
				Date sqlDate = new Date(utilDate.getTime()); // to be tested
				if (sObjVal != null)
					call$.setDate(sParamName, sqlDate);
				else
					call$.setNull(sParamName, getType(sType));
			}
			return call$;
		} catch (Exception e) {
			logger.debug(e.getMessage());
			e.printStackTrace();
			return call$;
		}
	};

	private JsonObject callProc(JsonObject reqJson, JsonObject argJson) {
		CallableStatement call$ = null;
		Connection con$ = null;
		List<String> respFlds = new ArrayList<String>();
		JsonObject jParamObj = new JsonObject();
		try {
			con$ = OracleConfig.getConn();

			if (con$ != null) { // #BVB00088 Starts

				String sProcName = argJson.get("OrclProcName").getAsString();
				int iParamCounts = 0;
				JsonObject i$Body = reqJson.get("i-body").getAsJsonObject();
				try {
					jParamObj = argJson.get("Paramters").getAsJsonObject();
					iParamCounts = jParamObj.size();
				} catch (Exception e) {
					iParamCounts = 0;
				}
				;
				String ParamQMrk = "";

				for (int i = 0; i < iParamCounts; i++) {
					if (i == 0)
						ParamQMrk = "?";
					else
						ParamQMrk = ParamQMrk + ",?";
				}
				String sCallStmt = "{ call " + sProcName + "(" + ParamQMrk + ") }";
				call$ = con$.prepareCall(sCallStmt);
				try {
					Set<Entry<String, JsonElement>> entrySet = jParamObj.entrySet();
					String strKey, sObjVal;
					JsonObject jVal;
					for (Map.Entry<String, JsonElement> entry : entrySet) {
						strKey = entry.getKey();
						jVal = jParamObj.get(strKey).getAsJsonObject();
						if (i$Body.has(strKey))
							sObjVal = i$Body.get(strKey).getAsString();
						else
							sObjVal = "";
						call$ = setProcVals(call$, jVal.get("Type").getAsString(), strKey, sObjVal,
								jVal.get("Mode").getAsString());
						if (I$utils.$iStrFuzzyMatch(jVal.get("ResFld").getAsString(), "1"))
							respFlds.add(strKey);
					}
				} catch (Exception ex) {
					logger.debug(ex.getMessage());
					reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO EXECUTE THE PROC");
					return reqJson;
				}

				call$.execute();
				JsonObject j$Result = new JsonObject();
				String sValue = null;
				for (String sKey : respFlds) {
					if (I$utils.$iStrFuzzyMatch(jParamObj.get(sKey).getAsJsonObject().get("Type").getAsString(),
							"CLOB")) {
						Clob clob = call$.getClob(sKey);
						if (clob != null) {
							int size = (int) clob.length();
							sValue = clob.getSubString(1, size);
						} else {
							sValue = "";
						}
						j$Result.addProperty(sKey, sValue);
					} else {
						j$Result.addProperty(sKey, call$.getString(sKey));
					}
				}
				;
				reqJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson, "i-body", j$Result);
				reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "SUCCESS IN WS EXECUTION");
			}
			// #BVB00088 Starts
			else {
				reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "NETWORK CONNECTION FAILED");
			}
			// #BVB00088 Ends
			return reqJson;

		} catch (Exception e) {
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO EXECUTE THE PROC",
					e.getMessage().toString());
			e.printStackTrace();
		} finally {
			if (call$ != null) {
				try {
					call$.close();
				} catch (Exception sqle) {
				}
			}
			if (con$ != null) {
				try {
					con$.close();
				} catch (Exception sqle) {
				}
			}
		}
		;
		return reqJson;
	};

	private JsonObject callProcBody(JsonObject reqJson, JsonObject argJson) {
		CallableStatement call$ = null;
		Connection con$ = null;
		List<String> respFlds = new ArrayList<String>();
		JsonObject jParamObj = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject isonReq = new JsonObject();
		try {

			con$ = OracleConfig.getConn();
			if (con$ != null) { // #BVB00088
				String sProcName = argJson.get("OrclProcName").getAsString();
				int iParamCounts = 0;
				JsonObject i$Body = reqJson;
				isonReq = parser.parse(I$ResMan.I_REQTPL_NBDY).getAsJsonObject();

				try {
					jParamObj = argJson.get("Paramters").getAsJsonObject();
					iParamCounts = jParamObj.size();
				} catch (Exception e) {
					iParamCounts = 0;
				}
				;
				String ParamQMrk = "";

				for (int i = 0; i < iParamCounts; i++) {
					if (i == 0)
						ParamQMrk = "?";
					else
						ParamQMrk = ParamQMrk + ",?";
				}
				String sCallStmt = "{ call " + sProcName + "(" + ParamQMrk + ") }";
				call$ = con$.prepareCall(sCallStmt);
				try {
					Set<Entry<String, JsonElement>> entrySet = jParamObj.entrySet();
					String strKey, sObjVal;
					JsonObject jVal;
					for (Map.Entry<String, JsonElement> entry : entrySet) {
						strKey = entry.getKey();
						jVal = jParamObj.get(strKey).getAsJsonObject();
						if (i$Body.has(strKey))
							sObjVal = i$Body.get(strKey).getAsString();
						else
							sObjVal = "";
						call$ = setProcVals(call$, jVal.get("Type").getAsString(), strKey, sObjVal,
								jVal.get("Mode").getAsString());
						if (I$utils.$iStrFuzzyMatch(jVal.get("ResFld").getAsString(), "1"))
							respFlds.add(strKey);
					}
				} catch (Exception ex) {
					logger.debug(ex.getMessage());
					isonReq = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO EXECUTE THE PROC");
					return isonReq;
				}

				call$.execute();
				JsonObject j$Result = new JsonObject();
				String sValue = null;
				for (String sKey : respFlds) {
					if (I$utils.$iStrFuzzyMatch(jParamObj.get(sKey).getAsJsonObject().get("Type").getAsString(),
							"CLOB")) {
						Clob clob = call$.getClob(sKey);
						if (clob != null) {
							int size = (int) clob.length();
							sValue = clob.getSubString(1, size);
						} else {
							sValue = "";
						}
						j$Result.addProperty(sKey, sValue);
					} else {
						j$Result.addProperty(sKey, call$.getString(sKey));
					}
				}
				;
				// reqJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson,
				// "i-body",j$Result);

				isonReq = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, isonReq, "i-body", j$Result);
				isonReq = I$ResMan.iHandleResStat(isonReq, I$ResMan.I_SUCC, "SUCCESS IN WS EXECUTION");
				return isonReq;
			}
			// #BVB00088 Starts
			else {
				isonReq = I$ResMan.iHandleResStat(isonReq, I$ResMan.I_ERR, "NETWORK CONNECTION FAILED");
			}
			// #BVB00088 Ends
		} catch (Exception e) {
			isonReq = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO EXECUTE THE PROC",
					e.getMessage().toString());
			e.printStackTrace();
		} finally {
			if (call$ != null) {
				try {
					call$.close();
				} catch (Exception sqle) {
				}
			}
			if (con$ != null) {
				try {
					con$.close();
				} catch (Exception sqle) {
				}
			}
		}
		;
		return isonReq;
	};

	public JsonObject processDBOpr(JsonObject reqMsg, JsonObject argJson) {
		JsonObject resMsg = new JsonObject();
		resMsg = reqMsg;
		if (I$utils.$iStrFuzzyMatch(argJson.get("OrclOprMode").getAsString(), "CallProc"))
			resMsg = callProc(resMsg, argJson);
		if (I$utils.$iStrFuzzyMatch(argJson.get("OrclOprMode").getAsString(), "CallProcBody"))
			resMsg = callProcBody(resMsg, argJson);

		return resMsg;
	};
}
//#00000001 Ends
