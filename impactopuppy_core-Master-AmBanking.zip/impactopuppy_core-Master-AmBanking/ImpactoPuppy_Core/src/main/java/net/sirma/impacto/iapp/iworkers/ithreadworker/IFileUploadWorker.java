/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1         | Vijay 	| Jan 17, 2019 | #BVB00039   | Initial writing
      |0.2.1         | Vijay 	| Jan 17, 2019 | #BVB00045   | File Error Handling
      |0.2.1         | Vijay 	| Feb 11, 2019 | #BVB00072   | PDF Upload
      |0.2.1         | Vijay 	| Mar 16, 2019 | #BVB00095   | Saving SDN List Type to SDN upload data
      |0.2.1         | Vijay 	| Mar 23, 2019 | #BVB00102   | Validation for file type against maintenance
	  |0.3.15        | Vijay  	| Jun 17, 2019 | #BVB00168   | HTML File Upload Changes
	  |0.3.15        | Pappu    | Nov 24, 2021 | #PKY00064   | changed collection name for json file
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB00039 Begins
package net.sirma.impacto.iapp.iworkers.ithreadworker;

import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IFileUploadController;
import net.sirma.impacto.iapp.ihelpers.IConstants;
//import net.sirma.impacto.iapp.icontrollers.iworkers.ithreadworker;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IFileUploadWorker {
	private Logger logger = LoggerFactory.getLogger(IFileUploadWorker.class);
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private IFileUploadController i$FileUplCon = new IFileUploadController();
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();

	public void processFile(JsonObject argJson) {
		String fileContent = "";
		JsonObject icorMSDN = new JsonObject();
		JsonArray fieldMapping = new JsonArray();
		String collectionName = "";
		String fileType = "";
		String fileStream = "";
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject setter = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject i$body = new JsonObject();
		String errMsg = "";
		String L_Coll_Name = "";
		String SdnListId = "";
		JsonObject i$res = new JsonObject();
		String fileTypeMain = ""; // #BVB00102
		String sdnImportId = "";
		String fetchOnlineData = "N"; // #BVB00168
		try {
			icorMSDN = argJson.getAsJsonObject("icorMSDN");
			collectionName = argJson.get("collectionName").getAsString();
			isonMsg = argJson.getAsJsonObject("isonMsg");
			L_Coll_Name = argJson.get("L_Coll_Name").getAsString();
			i$body = i$ResM.getBody(isonMsg);
			sdnImportId = i$body.get("Sdn_import_id").getAsString();
			SdnListId = i$body.get("Sdn_lst_id").getAsString();
			argJson.addProperty("SdnListId", SdnListId); // #BVB00095
			// #BVB00168 Starts
			try {
				fetchOnlineData = icorMSDN.get("FetchOnlineData").getAsString();
			} catch (Exception e) {
				fetchOnlineData = "N";
			}
			if (I$utils.$iStrFuzzyMatch(fetchOnlineData, "N")) {
				// #BVB00168 Ends
				fileStream = i$body.get("Sdn_file").getAsString();
				fileType = I$impactoUtil.getFileType(fileStream);
				fileContent = fileStream.split("\\,")[1];
				fieldMapping = icorMSDN.get("Field_Mapper").getAsJsonArray();

				if (I$utils.$iStrFuzzyMatch(fileType, IConstants.I_ZIP.toString())) {
					if (!I$utils.$iStrFuzzyMatch(fileContent, "") || !I$utils.$iStrFuzzyMatch(collectionName, "")) {
						byte[] zipData = I$impactoUtil.base64Decode(fileContent);
						ZipInputStream zipIn = i$FileUplCon.getZipContent(zipData);
						ZipEntry entry = zipIn.getNextEntry();
						logger.info("Size: " + entry.getSize());
						logger.info("Name of the File: " + entry.getName());
						String ext = FilenameUtils.getExtension(entry.getName());
						// #BVB00102 Starts
						// Check for file type matching
						fileTypeMain = icorMSDN.get("File_Type").getAsString();
						if (I$utils.$iStrFuzzyMatch(fileTypeMain, ext)) {
							// #BVB00102 Ends
							if (I$utils.$iStrFuzzyMatch(ext, "CSV")) {
								argJson.add("fieldMapping", fieldMapping); // #BVB00095

								i$res = i$FileUplCon.processCSVContent(collectionName, zipIn, argJson);
								if (i$res.get("i-stat").getAsInt() > 0) {
									// Sucess came back
								} else {
									errMsg = i$res.get("i-Msg").getAsString();
								}
							} else if (I$utils.$iStrFuzzyMatch(ext, "XML")) {
								JsonArray parentNode = icorMSDN.get("parentNode").getAsJsonArray();
								String repeatNode = icorMSDN.get("repeatNode").getAsString();
								JsonObject sdnDetail = new JsonObject();
								sdnDetail.add("parentNode", parentNode);
								sdnDetail.addProperty("repeatNode", repeatNode);
								sdnDetail.add("Field_Mapper", fieldMapping);
								argJson.add("sdnDetail", sdnDetail); // #BVB00095

								i$res = i$FileUplCon.processXMLContent(collectionName, zipIn, argJson);// xmlContent,
																										// argJson);
																										// // #BVB00095
								if (i$res.get("i-stat").getAsInt() > 0) {
									// Sucess came back
								} else {
									errMsg = i$res.get("i-Msg").getAsString();
								}
							}
							// #BVB00072 Starts
							else if (I$utils.$iStrFuzzyMatch(ext, "PDF")) {
								argJson.addProperty("collName", "ICOR_M_SDN_DETAIL"); // #BVB00095
								i$res = i$FileUplCon.processPDFContent(argJson, zipIn);
								if (i$res.get("i-stat").getAsInt() > 0) {
									// Sucess came back
								} else {
									errMsg = i$res.get("i-Msg").getAsString();
								}
							} // #BVB00072 Ends
							else if (I$utils.$iStrFuzzyMatch(ext, "JSON")) {
								argJson.addProperty("collName", "ICOR_M_SDN_DETAILS_JSON"); // #BVB00095  //PKY00064 changes
								i$FileUplCon.processJSONContent(argJson, zipIn);
							} else {

								errMsg = "Invalid File Type"; // #BVB00045
							}

						}
						// #BVB00102 Starts
						else {
							errMsg = "Invalid File Type";
						}
						// #BVB00102 Ends
					} else {
						// Handle empty input data here
						errMsg = "Invalid File Content"; // #BVB00045
					}
				}
				// errMsg = "";
				else {
					errMsg = "Invalid Compression Type"; // #BVB00045
				}

			}
			// #BVB00168 Starts
			else {
				// Call ExtWsLauncher and get the data. Check if it is a Html.

				String extUrl = icorMSDN.get("Sdn_Source_Link").getAsString();
				filter = new JsonObject();
				filter.addProperty("trnCd", icorMSDN.get("Sdn_List_Id").getAsString());
				JsonObject transmitter = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
				argJson = I$impactoUtil.mergeJsonObject(argJson, transmitter);
				argJson.addProperty("unqCommID", I$impactoUtil.generateRandomKey());
				argJson.add("reqBody", new JsonObject());
				argJson.addProperty("extUrl", extUrl);

				JsonObject JResp = I$EWSLnchr.ILaunchReq(argJson);

				// If Html, then parse it using the new code and insert the data
				// logger.debug(gson.toJson(JResp));
				if (I$utils.$iStrFuzzyMatch(JResp.get("resCode").getAsString(), "200")) {
					argJson.addProperty("fileContent", JResp.get("resBody").getAsString()); // #BVB00095
					i$res = i$FileUplCon.processHTMLContent(argJson);
					if (i$res.get("i-stat").getAsInt() > 0) {
						// Success came back
						errMsg = "";
					} else {
						errMsg = i$res.get("i-Msg").getAsString();
					}
				} else {
					errMsg = JResp.get("resExp").getAsString();
				}
				// #BVB00168 Ends
			}

		} catch (

		Exception e) {
			errMsg = "Failed in FIle Uplaod with: " + e.getMessage();

		} finally {
			filter = new JsonObject();
			filter.addProperty("Sdn_lst_id", SdnListId);
			filter.addProperty("Sdn_import_id", sdnImportId);
			setter = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(errMsg, "")) {
				setter.addProperty("JobStatus", "Completed");
			} else {
				setter.addProperty("JobStatus", "Failed");
			}
			setter.addProperty("errorMsg", errMsg);
			JsonObject up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, setter, filter);
		}

	}

	public IFileUploadWorker() {
		// Constructor
	}

}

// #BVB00039 Ends