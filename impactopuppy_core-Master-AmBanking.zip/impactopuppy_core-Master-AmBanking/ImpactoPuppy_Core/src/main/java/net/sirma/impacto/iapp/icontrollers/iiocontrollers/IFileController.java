/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 02, 2019 | #BVB00050   | Initial writing 
      ----------------------------------------------------------------------------------------------
*/
// #BVB00050 Begins
package net.sirma.impacto.iapp.icontrollers.iiocontrollers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IFileController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IFileController.class);

	public File createFile(String content) {
		try {
			// Create file
			byte[] imageByte = Base64.decodeBase64(content);
			String fileName = i$impactoUtil.getAlphaNumericId(15);
			ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
			BufferedImage image = ImageIO.read(bis);
			bis.close();
			String path = System.getProperty("user.dir");
			path = path + "/temp/";
			path = path + fileName;
			File outputfile = new File(path);
			ImageIO.write(image, "png", outputfile);
			File sourceFile = new File(path);

			return sourceFile;
		} catch (Exception e) {
			return null;
		}
	}

	public void deleteFile(String fileName) {
		
		// Need to do
		String path = System.getProperty("user.dir");
		path = path + "/temp/";
		path = path + fileName;
		// File outputfile = new File(path);
		try {
			Files.deleteIfExists(Paths.get(path));
		} catch (NoSuchFileException e) {
			logger.debug("No such file/directory exists");
		} catch (DirectoryNotEmptyException e) {
			logger.debug("Directory is not empty.");
		} catch (IOException e) {
			logger.debug("Invalid permissions.");
		}

	}
	
	public String getFile(String fileName) {
		try {
			String path = System.getProperty("user.dir");
			path = path + "/temp/";
			path = path + fileName;
			File file = new File(path); 
			byte[] bytesArray = new byte[(int) file.length()]; 
			  FileInputStream fis = new FileInputStream(file);
			  fis.read(bytesArray); //read file into bytes[]
			  fis.close(); 
			  return Base64.encodeBase64String(bytesArray); 
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null; 
	}

	// #BVB00056 Ends
	public IFileController() {
		// Cons
	}
}
// #BVB00050 Ends
