/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Valla 		|Jan 08, 2019  | #00000001   | Initial writing
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		|Jan 17, 2019  | #00000002   | Thread Implementation
      |0.1 Beta    | Nye 		|May 06, 2019  | #00000003   | SendInBlueInterface
      |0.3.16.327  | BHUVI 		|Jul 26, 2019  | #BHUVI001   | Add method to call sendMail without threading
      |0.1 Beta    | Pruthvi    |Apr 08, 2021  | #YPR00069   | Added DB call for email settings
      |0.3 Beta    | Pruthvi    |MAy 28, 2021  | #YPR00082   | Added Email Subject Formatting
      |0.1 Beta    | Pruthvi    |Jul 07, 2021  | #MAQ00134   | Added success msg when Email disabled
      |0.1 Beta    | Pappu      |Sep 01, 2021  | #PKY00045   | handled sendgrid API
      |0.1 Beta    | Samadhan   |sep 08, 2021  | #SRP00021   | Added Code for To send Email to multiple Recepient
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icommunication.iemail;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
//import com.amazonaws.services.simpleemail.model.Message;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sendgrid.Method;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Attachments;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
 
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
//import net.sirma.impacto.core.security.communication.MailService;
//import software.amazon.awssdk.core.exception.SdkException;

//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicAWSCredentials;
//import com.amazonaws.regions.Regions;
//import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
//import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
//import com.amazonaws.services.simpleemail.model.Body;
//import com.amazonaws.services.simpleemail.model.Content;
//import com.amazonaws.services.simpleemail.model.Destination;
//import com.amazonaws.services.simpleemail.model.SendEmailRequest;
//import com.amazonaws.services.simpleemail.model.SendEmailResult;

import com.sendgrid.Method;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Email;


public class IEmailService {
	private DBController db$Ctrl = new DBController();
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil imp$utils = new ImpactoUtil();
	private JsonObject JEmailArgJson = new JsonObject();
	private Ioutils I$utils = new Ioutils(); // #00000003

	public Boolean sendEmail(JsonObject argJson) throws MessagingException {
		try {
			argJson.add("globals", i$ResM.getAllGobal());
			JEmailArgJson = argJson;
			triggerEmailThread.start();
			return true;
		} catch (Exception ex) {
			return false;
		}
	};

	@SuppressWarnings("unused")
	// Begin #00000003
	private JsonObject sendInBlueEmailTrg(JsonObject jEmailargs, JsonObject to$emailIds, JsonObject cc$emailIds,
			JsonObject bcc$emailIds, JsonObject statusMsg, String msgBody, String sPrimaryKey, String sPrimaryOpr) {
		JsonObject jOkHttp = new JsonObject();
		try {
			OkHttpClient client = new OkHttpClient();
			JsonObject jEmailReq = new JsonObject();
			JsonObject jSender = new JsonObject();
			JsonArray jTo = new JsonArray();
			JsonObject jToObj = new JsonObject();

			JsonArray jCc = new JsonArray();
			JsonObject jCcObj = new JsonObject();

			JsonArray jBcc = new JsonArray();
			JsonObject jBccObj = new JsonObject();

			JsonObject JSendInBlueSettings = new JsonObject();
			Gson gson = new Gson();

			// Getting SendInBlueSettings
			JSendInBlueSettings = jEmailargs.get("SendInBlueSettings").getAsJsonObject();
			MediaType mediaType = MediaType.parse("application/json");

			// Building Sender
			/*
			 * Mandatory if 'templateId' is not passed. Pass name (optional) and email of
			 * sender from which emails will be sent. For example, {'name':'IMPACTO',
			 * 'email':'no-reply@impacto.com'}
			 */
			jSender = JSendInBlueSettings.get("sender").getAsJsonObject();
			jEmailReq.add("sender", jSender);

			// Building To
			/*
			 * REQUIRED List of email addresses and names (optional) of the recipients. For
			 * example, [{'name':'Jimmy', 'email':'jimmy98@example.com'}, {'name':'Joe',
			 * 'email':'joe@example.com'}]
			 */

			for (int k = 1; k <= to$emailIds.size(); k++) {
				jToObj.addProperty("name", to$emailIds.get("toemailid" + k).getAsString());
				jToObj.addProperty("email", to$emailIds.get("toemailid" + k).getAsString());
				jTo.add(jToObj);
			}
			jEmailReq.add("to", jTo);

			// Building CC
			/*
			 * List of email addresses and names (optional) of the recipients. For example,
			 * [{'name':'Jimmy', 'email':'jimmy98@example.com'}, {'name':'Joe',
			 * 'email':'joe@example.com'}]
			 */

			if (cc$emailIds != null) {
				for (int k = 1; k <= cc$emailIds.size(); k++) {
					jCcObj.addProperty("name", cc$emailIds.get("ccemailid" + k).getAsString());
					jCcObj.addProperty("email", cc$emailIds.get("ccemailid" + k).getAsString());
					jCc.add(jCc);
				}
				jEmailReq.add("cc", jCc);
			}

			// Building BCC
			/*
			 * List of email addresses and names (optional) of the recipients. For example,
			 * [{'name':'Jimmy', 'email':'jimmy98@example.com'}, {'name':'Joe',
			 * 'email':'joe@example.com'}]
			 */
			if (bcc$emailIds != null) {
				for (int k = 1; k <= bcc$emailIds.size(); k++) {
					jBccObj.addProperty("name", bcc$emailIds.get("bccemailid" + k).getAsString());
					jBccObj.addProperty("email", bcc$emailIds.get("bccemailid" + k).getAsString());
					jBcc.add(jBcc);
				}
				jEmailReq.add("bcc", jBcc);
			}
			// Subject * REQUIRED
			jEmailReq.addProperty("subject", jEmailargs.get("subject").getAsString());

			// Body
			if (msgBody.toUpperCase().indexOf("HTML>") > -1)
				jEmailReq.addProperty("htmlContent", msgBody); // HTML Message
			else
				jEmailReq.addProperty("textContent", msgBody);

			// Attachement
			/*
			 * Pass the absolute URL (no local file) or the base64 content of the attachment
			 * along with the attachment name (Mandatory if attachment content is passed).
			 * For example, [{'url':'https://attachment.domain.com/myAttachmentFromUrl.jpg',
			 * 'name':'My attachment 1'}, {'content':'base64 exmaple content', 'name':'My
			 * attachment 2'}]. Allowed extensions for attachment file: xlsx, xls, ods,
			 * docx, docm, doc, csv, pdf, txt, gif, jpg, jpeg, png, tif, tiff, rtf, bmp,
			 * cgm, css, shtml, html, htm, zip, xml, ppt, pptx, tar, ez, ics, mobi, msg,
			 * pub, eps and odt ( If 'templateId' is passed and is in New Template Language
			 * format then only attachment url is accepted. If template is in Old template
			 * Language format, then 'attachment' is ignored )
			 */
			if (jEmailargs.has("attachment"))
				jEmailReq.add("attachment", jEmailargs.get("attachment").getAsJsonArray());

			RequestBody reqBody = null;
			String strJson = jEmailReq.toString();
			try {
				reqBody = RequestBody.create(mediaType, strJson);
			} catch (Exception Ex) {
				// No Body
				reqBody = null;
			}

			// "https://api.sendinblue.com/v3/smtp/email"
			// "api-key" :
			// "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"
			Request request = new Request.Builder().url(JSendInBlueSettings.get("url").getAsString()).post(reqBody)
					.addHeader("Content-Type", "application/json")
					.addHeader("api-key", JSendInBlueSettings.get("api-key").getAsString())
					.addHeader("cache-control", "no-cache").build();

			Response response = client.newCall(request).execute();
			if (response.isSuccessful()) {
				jOkHttp.addProperty("resStat", i$ResM.I_SUCC);
				jOkHttp.addProperty("resCode", response.code());
				jOkHttp.addProperty("resBody", response.body().string().toString());
				String sCommId = null;

				try {
					JsonParser jsonParser = new JsonParser();
					String sResp = jOkHttp.get("resBody").getAsString();
					JsonObject jo = (JsonObject) jsonParser.parse(jOkHttp.get("resBody").getAsString());
					sCommId = jo.get("messageId").getAsString();
					sCommId = sCommId.replaceAll("<", "");
					sCommId = sCommId.replaceAll(">", "");
				} catch (Exception e) {
					sCommId = null;
					// eat
				}
				;
				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, sCommId, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
				return jOkHttp; // Nye Fix
			} else {
				// jOkHttp.addProperty("resStat", i$ResM.I_ERR);
				jOkHttp.addProperty("resCode", response.code());
				try {
					jOkHttp.addProperty("resBody", response.body().string());
					logger.debug("Success ::" + response.body().string());
				} catch (Exception Ex) {
					// Eating up the Exception
					jOkHttp.addProperty("resBody", "");
					logger.debug("No resBody ::" + Ex.getMessage());
				}
				;
				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
				return jOkHttp;
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			jOkHttp.addProperty("resStat", i$ResM.I_ERR);
			jOkHttp.addProperty("resCode", "400");
			jOkHttp.addProperty("resExp", ex.getMessage());
			jOkHttp.addProperty("resBody", "");
			log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
			logger.debug(ex.getMessage());
			return jOkHttp;
		}

	}
	// #00000003 End
	
//	private JsonObject AmazonSESEmailTrg(JsonObject jEmailargs, JsonObject to$emailIds, JsonObject cc$emailIds,
//			JsonObject bcc$emailIds, JsonObject statusMsg, String msgBody, String sPrimaryKey, String sPrimaryOpr) {
//		JsonObject jOkHttp = new JsonObject();
//
//		try {
//
//			 	JsonObject JSESSettings = jEmailargs.get("AmazonSESSettings").getAsJsonObject();
// 
//			SendEmailResult response = null;
//			try {
//				BasicAWSCredentials awsCreds = new BasicAWSCredentials(JSESSettings.get("accessKey").getAsString(), JSESSettings.get("secretKey").getAsString());
//				String Region ;
//				if(JSESSettings.has("emailRegion")) {
//					Region = JSESSettings.get("emailRegion").getAsString();
//				} else {
//					Region = "ap-south-1";
//				}
//
// 	            AmazonSimpleEmailService client =
//	                AmazonSimpleEmailServiceClientBuilder.standard()
//	                .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
//	                .withRegion(Region).build();
//	            SendEmailRequest request = new SendEmailRequest()
//	                .withDestination(
//	                    new Destination().withToAddresses(to$emailIds.get("toemailid1").getAsString()))
//	                .withMessage(new Message()
//	                    .withBody(new Body()
//	                        .withHtml(new com.amazonaws.services.simpleemail.model.Content()
//	                            .withCharset("UTF-8").withData(msgBody)))
//	                    .withSubject(new com.amazonaws.services.simpleemail.model.Content()
//	                        .withCharset("UTF-8").withData(jEmailargs.get("subject").getAsString())))
//	                .withSource(JSESSettings.get("sender").getAsString());
//	           response=   client.sendEmail(request);
//	           
//	           response.getSdkResponseMetadata(); 
//			} catch (SdkException e) {
//				e.getStackTrace();
//			}
//
//			//Response response = client.newCall(request).execute();
//			if (I$utils.$iStrFuzzyMatch(Integer.toString(response.getSdkHttpMetadata().getHttpStatusCode()) , "200")) {
//				jOkHttp.addProperty("resStat", i$ResM.I_SUCC);
//				jOkHttp.addProperty("resCode", "200");
//				jOkHttp.addProperty("resBody", response.getMessageId() );
//				String sCommId = response.getMessageId();
//
//				try {
//					JsonParser jsonParser = new JsonParser();
//					String sResp = jOkHttp.get("resBody").getAsString();
//					JsonObject jo = (JsonObject) jsonParser.parse(jOkHttp.get("resBody").getAsString());
//					sCommId = jo.get("messageId").getAsString();
//					sCommId = sCommId.replaceAll("<", "");
//					sCommId = sCommId.replaceAll(">", "");
//				} catch (Exception e) {
//					sCommId = response.getMessageId();
//					// eat
//				}
//				;
//				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, sCommId, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
//				return jOkHttp; // Nye Fix
//			} else {
//				// jOkHttp.addProperty("resStat", i$ResM.I_ERR);
//				jOkHttp.addProperty("resCode", "400");
//				try {
//					jOkHttp.addProperty("resBody", "");
//					logger.debug("Success ::" + "");
//				} catch (Exception Ex) {
//					// Eating up the Exception
//					jOkHttp.addProperty("resBody", "");
//					logger.debug("No resBody ::" + Ex.getMessage());
//				}
//				;
//				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
//				return jOkHttp;
//			}
//		} catch (Exception ex) {
//			ex.printStackTrace();
//			jOkHttp.addProperty("resStat", i$ResM.I_ERR);
//			jOkHttp.addProperty("resCode", "400");
//			jOkHttp.addProperty("resExp", ex.getMessage());
//			jOkHttp.addProperty("resBody", "");
//			log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
//			logger.debug(ex.getMessage());
//			return jOkHttp;
//		}
//
//	}

	private JsonObject sendGridEmailTrg(JsonObject jEmailargs, JsonObject to$emailIds, JsonObject cc$emailIds,
			JsonObject bcc$emailIds, JsonObject statusMsg, String msgBody, String sPrimaryKey, String sPrimaryOpr) {
		JsonObject jOkHttp = new JsonObject();
	 	JsonObject JSESSettings = jEmailargs.get("sendGridSettings").getAsJsonObject();

		try {
			String SEND_GRID_API_KEY = JSESSettings.get("SEND_GRID_API_KEY").getAsString();
			 //#PKY00045 starts
		            Mail mail = new Mail();
		            Email from = new Email(JSESSettings.get("fromEmail").getAsString());
		            mail.setFrom(from);
		            String subject = jEmailargs.get("subject").getAsString();
		            mail.setSubject(subject);
					// #SRP00021 Start
					String toEmails = to$emailIds.get("toemailid1").getAsString();
					Personalization personalization = new Personalization();
					String[] toEmailsArr = toEmails.split(",");
					for (int i = 0, size = toEmailsArr.length; i < size; i++) {
						personalization.addTo(new Email(toEmailsArr[i]));
					}
					mail.addPersonalization(personalization);
					// #SRP00021 Ends
		            
		            com.sendgrid.helpers.mail.objects.Content content = new com.sendgrid.helpers.mail.objects.Content("text/html", msgBody);
		            mail.addContent(content);
		            
		            if(jEmailargs.has("attachment")) {
			        	   JsonArray attachments = jEmailargs.get("attachment").getAsJsonArray();
				            if(attachments.size()>0) {
				            	for(int i=0;i<attachments.size();i++) {
				            		try {
				            			Attachments attachment = new Attachments();
					            		JsonObject doc = attachments.get(i).getAsJsonObject();
					                    attachment.setContent(doc.get("template").getAsString());
					                    attachment.setType(doc.get("docType").getAsString()); //"image/png"
					                    attachment.setFilename(doc.get("fileName").getAsString());
					                    attachment.setDisposition("attachment");
//					                    attachment.setContentId("Balance Sheet");
					                    mail.addAttachments(attachment);
				            		}catch(Exception e) {
				            			
				            		}
				            		
				            	}
				            }
			           }
		            SendGrid sg = new SendGrid(SEND_GRID_API_KEY);
		            com.sendgrid.Request requestEmail = new com.sendgrid.Request();
		                requestEmail.setMethod(Method.POST);
		                requestEmail.setEndpoint("mail/send");
		                requestEmail.setBody(mail.build());
		                com.sendgrid.Response responseEmail = sg.api(requestEmail);
		                logger.debug("Status Code from sendGrid "+responseEmail.getStatusCode());
		                
		                if (Integer.toString(responseEmail.getStatusCode()).startsWith("20")) {
		    				jOkHttp.addProperty("resStat", i$ResM.I_SUCC);
		    				jOkHttp.addProperty("resCode", "200");
		    				jOkHttp.addProperty("resBody", responseEmail.getBody());
		    				String sCommId = responseEmail.getBody();
		    				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, responseEmail.getBody(), msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
		    				return jOkHttp; // Nye Fix
		    			} else {
		    				// jOkHttp.addProperty("resStat", i$ResM.I_ERR);
		    				jOkHttp.addProperty("resCode", "400");
		    				try {
		    					jOkHttp.addProperty("resBody", "");
		    					logger.debug("Success ::" + "");
		    				} catch (Exception Ex) {
		    					// Eating up the Exception
		    					jOkHttp.addProperty("resBody", "");
		    					logger.debug("No resBody ::" + Ex.getMessage());
		    				}
		    				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
		    				return jOkHttp;
		    			}
		             //#PKY00045 ends
/*	        Email from = new Email(JSESSettings.get("fromEmail").getAsString());
	        
	        String subject = jEmailargs.get("subject").getAsString();
	        Email to = new Email(to$emailIds.get("toemailid1").getAsString());
	        com.sendgrid.helpers.mail.objects.Content content = new com.sendgrid.helpers.mail.objects.Content("text/html", msgBody);

	        Mail mail = new Mail(from, subject, to, content);

	        SendGrid sg = new SendGrid(SEND_GRID_API_KEY);
	        com.sendgrid.Request requestEmail = new com.sendgrid.Request();
	       
	          requestEmail.setMethod(Method.POST);
	          requestEmail.setEndpoint("mail/send");
	          requestEmail.setBody(mail.build());
	          com.sendgrid.Response responseEmail = sg.api(requestEmail);
	          logger.debug("Status Code from sendGrid "+responseEmail.getStatusCode());
	       

			if (Integer.toString(responseEmail.getStatusCode()).startsWith("20")) {
				jOkHttp.addProperty("resStat", i$ResM.I_SUCC);
				jOkHttp.addProperty("resCode", "200");
				jOkHttp.addProperty("resBody", responseEmail.getBody());
				String sCommId = responseEmail.getBody();
				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, responseEmail.getBody(), msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
				return jOkHttp; // Nye Fix
			} else {
				// jOkHttp.addProperty("resStat", i$ResM.I_ERR);
				jOkHttp.addProperty("resCode", "400");
				try {
					jOkHttp.addProperty("resBody", "");
					logger.debug("Success ::" + "");
				} catch (Exception Ex) {
					// Eating up the Exception
					jOkHttp.addProperty("resBody", "");
					logger.debug("No resBody ::" + Ex.getMessage());
				}
				;
				log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
				return jOkHttp;
			}*/
		} catch (Exception ex) {
			ex.printStackTrace();
			jOkHttp.addProperty("resStat", i$ResM.I_ERR);
			jOkHttp.addProperty("resCode", "400");
			jOkHttp.addProperty("resExp", ex.getMessage());
			jOkHttp.addProperty("resBody", "");
			log(to$emailIds, cc$emailIds, bcc$emailIds, jOkHttp, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
			logger.debug(ex.getMessage());
			return jOkHttp;
		}

	}
	
	@SuppressWarnings("unused")
	private String getFormattedTmpl(String sTmpl, JsonObject J$vals) {
		try {
			Map<String, Object> attributes = new HashMap<String, Object>();
			Set<Entry<String, JsonElement>> entrySet = J$vals.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = "#" + entry.getKey() + "#";
				strVal = J$vals.get(entry.getKey()).getAsString();
				sTmpl = sTmpl.replaceAll(strKey, strVal);
			}
		} catch (Exception ex) {

		}
		return sTmpl;
	}

	// #00000003 Begins
	public void log(JsonObject to$emailIds, JsonObject cc$emailIds, JsonObject bcc$emailIds, JsonObject statusMsg,
			String commID, String msgBody, String sPrimaryKey, String sPrimaryOpr) {
		// Building Logger Json Object
		JsonObject email$logger = new JsonObject();
		email$logger.addProperty("CommunicationMode", "Email");

		if (I$utils.$iStrBlank(commID))
			email$logger.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
		else
			email$logger.addProperty("communicationId", commID);

		email$logger.addProperty("CommunicationBody", msgBody);

		email$logger.add("ToEmailIds", to$emailIds.getAsJsonObject());

		try {
			email$logger.add("CcEmailId", cc$emailIds.getAsJsonObject());
		} catch (Exception e) {
			email$logger.addProperty("CcEmailIds", "NA");
		}

		try {
			email$logger.add("BccEmailId", cc$emailIds.getAsJsonObject());
		} catch (Exception e) {
			email$logger.addProperty("BccEmailIds", "NA");
		}

		email$logger.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
		email$logger.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());
		try {
			email$logger.addProperty("ReAttempts", JEmailArgJson.get("ResendAttempt").getAsNumber());
		} catch (Exception e) {
			email$logger.addProperty("ReAttempts", 0);
		}
		email$logger.add("StatusMsg", statusMsg);
		email$logger.addProperty("PrimaryKey", sPrimaryKey);
		email$logger.addProperty("PrimaryOpr", sPrimaryOpr);
		db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", email$logger);
	};
	// #00000003 Ends

	// #00000002 begins
	Thread triggerEmailThread = new Thread(new Runnable() {
		@Override
		public void run() {
			i$ResM.setAllGlobal(JEmailArgJson.getAsJsonObject("globals"));
			SendEmailWOThread(JEmailArgJson);// // #BHUVI001 Added
		}
	}); // #00000002 Ends

	// #BHUVI001 Starts
	public JsonObject SendEmailWOThread(JsonObject JEmailArgJson) {
		JsonParser parser = new JsonParser();
		JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();  
		try {
			 
			// JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();  
			// Check if IPIsAllowed or not.
//			JsonObject icorCParam = i$ResM.getGobalValJObj("icorCParam");
			// #YPR00069 Starts
			JsonObject i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}",
					"{'emailsettings'=1, 'iOtpSystemValidations'=1, 'emailEnabled'=1}"); // #MAQ00131 
			JsonObject sysValidations = i$Param.get("iOtpSystemValidations").getAsJsonObject();
			// Fetch email conf details and setup the email configurations
//			JsonObject i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"emailsettings\"=1}");
			JsonObject email$cnfdb = i$Param.get("emailsettings").getAsJsonObject();
			// #YPR00069 Ends
	    	Boolean emailEnabled = true; // #MAQ00131
			 // #MAQ00131 starts
			if(i$Param.has("emailEnabled"))
				emailEnabled = i$Param.get("emailEnabled").getAsBoolean();
			 // #MAQ00131 ends
			
			    // Read all the email Ids
				JsonObject to$emailIds = JEmailArgJson.get("toemailIds").getAsJsonObject();
				JsonObject bcc$emailIds = new JsonObject();
				JsonObject cc$emailIds = new JsonObject();
				JsonObject statusMsg = new JsonObject();
				// Read the Template and construct the email template
				JsonObject template$Data = JEmailArgJson.get("map$Data").getAsJsonObject();
				JsonObject JSendinBlueArgs = new JsonObject(); // #00000003
				//
				String sPrimaryKey = "";
				String sPrimaryOpr = "";

				if (JEmailArgJson.has("PrimaryKey"))
					sPrimaryKey = JEmailArgJson.get("PrimaryKey").getAsString();

				if (JEmailArgJson.has("PrimaryOpr"))
					sPrimaryOpr = JEmailArgJson.get("PrimaryOpr").getAsString();

				try {
					cc$emailIds = JEmailArgJson.get("ccemailIds").getAsJsonObject();
				} catch (Exception e) {
					cc$emailIds = null;
				}

				try {
					bcc$emailIds = JEmailArgJson.get("bccemailIds").getAsJsonObject();
				} catch (Exception e) {
					bcc$emailIds = null;
				}


				// Reading the email template from DB

				JsonObject i$emailtmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
						"{ Template_ID: \"" + template$Data.get("tmp$name").getAsString() + "\" }");
				// String eml$tmp = s$emailtemp.get("Template").getAsString();

				// Get the Formatted String
				String msgBody = getFormattedTmpl(i$emailtmpl.get("Template").getAsString(), template$Data);
				String emailSubject = getFormattedTmpl(i$emailtmpl.get("Email_Subject").getAsString(), template$Data); // #YPR00082 Changes
				
				if (imp$utils.isValIp(sysValidations) && emailEnabled) { //#MAQ00131 changes
				// #00000003 Begin - Checking if SendInBlue Interface is enabled
				if (email$cnfdb.has("SendInBlueApi")
						&& I$utils.$iStrFuzzyMatch(email$cnfdb.get("SendInBlueApi").getAsString(), "1")) {
					logger.info("Triggering Send In Blue..");
					if (JEmailArgJson.has("attachment"))
						JSendinBlueArgs.add("attachment", JEmailArgJson.get("attachment").getAsJsonArray());
					JSendinBlueArgs.addProperty("subject", emailSubject); // #YPR00082 Changes
					JSendinBlueArgs.add("SendInBlueSettings", email$cnfdb.get("SendInBlueSettings").getAsJsonObject());
					JsonObject i$resm = sendInBlueEmailTrg(JSendinBlueArgs, to$emailIds, cc$emailIds, bcc$emailIds, statusMsg, msgBody,
							sPrimaryKey, sPrimaryOpr);
					// add the stat msg using the above
					if(I$utils.$iStrFuzzyMatch(i$resm.get("resStat").getAsString(), i$ResM.I_SUCC)){
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Successfully Sent"); 
					}
					logger.info("Done Triggering Send In Blue.. Returning");
					return isonMsg;
//				}else if (email$cnfdb.has("AmazonSESApi")
//						&& I$utils.$iStrFuzzyMatch(email$cnfdb.get("AmazonSESApi").getAsString(), "1")) {
//					logger.info("Triggering AmazonSES..");
//					if (JEmailArgJson.has("attachment"))
//						JSendinBlueArgs.add("attachment", JEmailArgJson.get("attachment").getAsJsonArray());
//					JSendinBlueArgs.addProperty("subject", emailSubject); // #YPR00082 Changes
//					JSendinBlueArgs.add("AmazonSESSettings", email$cnfdb.get("AmazonSESSettings").getAsJsonObject());
//					JsonObject i$resm = AmazonSESEmailTrg(JSendinBlueArgs, to$emailIds, cc$emailIds, bcc$emailIds,
//							statusMsg, msgBody, sPrimaryKey, sPrimaryOpr);
//					// add the stat msg using the above
//					if (I$utils.$iStrFuzzyMatch(i$resm.get("resStat").getAsString(), i$ResM.I_SUCC)) {
//						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Successfully Sent");
//					}
//					logger.info("Done Triggering Send In Amazon.. Returning");
//					return isonMsg;
				} else if (email$cnfdb.has("sendGridApi")
						&& I$utils.$iStrFuzzyMatch(email$cnfdb.get("sendGridApi").getAsString(), "1")) {
					logger.info("Triggering sendGrid Mail..");
					if (JEmailArgJson.has("attachment"))
						JSendinBlueArgs.add("attachment", JEmailArgJson.get("attachment").getAsJsonArray());
					JSendinBlueArgs.addProperty("subject",  emailSubject); // #YPR00082 Changes
					JSendinBlueArgs.add("sendGridSettings", email$cnfdb.get("sendGridSettings").getAsJsonObject());
					JsonObject i$resm = sendGridEmailTrg(JSendinBlueArgs, to$emailIds, cc$emailIds, bcc$emailIds,
							statusMsg, msgBody, sPrimaryKey, sPrimaryOpr);
					// add the stat msg using the above
					if (I$utils.$iStrFuzzyMatch(i$resm.get("resStat").getAsString(), i$ResM.I_SUCC)) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Successfully Sent");
					}
					logger.info("Done Triggering Send Grid Mail.. Returning");
					return isonMsg;
				}				
				// #00000003 End

				JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

				// Using Gmail SMTP configuration.
				mailSender.setHost(email$cnfdb.get("Email_Host").getAsString());
				mailSender.setPort(email$cnfdb.get("Email_Port").getAsInt());
				mailSender.setUsername(email$cnfdb.get("From_Email_Id").getAsString());
				mailSender.setPassword(email$cnfdb.get("Password").getAsString());

				Properties javaMailProperties = new Properties();
				javaMailProperties.put("mail.smtp.starttls.enable", email$cnfdb.get("startttls").getAsString());
				javaMailProperties.put("mail.smtp.auth", email$cnfdb.get("authentication").getAsString());
				javaMailProperties.put("mail.transport.protocol",
						email$cnfdb.get("mailtransportprotocol").getAsString());
				javaMailProperties.put("mail.debug", email$cnfdb.get("maildebug").getAsString());

				mailSender.setJavaMailProperties(javaMailProperties);
				MimeMessage mimeMessage = mailSender.createMimeMessage();
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, false, "utf-8");
				for (int k = 1; k <= to$emailIds.size(); k++) {
					mimeMessageHelper.setTo(to$emailIds.get("toemailid" + k).getAsString());
				}
				if (cc$emailIds != null) {
					for (int k = 0; k < cc$emailIds.size(); k++) {
						mimeMessageHelper.setCc(cc$emailIds.get("ccemailid" + k).getAsString());
					}
				}
				if (bcc$emailIds != null) {
					for (int k = 0; k < bcc$emailIds.size(); k++) {
						mimeMessageHelper.setBcc(bcc$emailIds.get("bccemailid" + k).getAsString());
					}
				}
				mimeMessageHelper.setSubject(emailSubject);// #YPR00082 Changes
				mimeMessageHelper.setText(msgBody, true);
				JEmailArgJson.add("SendDtTime", i$ResM.adddate(new Date()).getAsJsonObject());

				try {
					mailSender.send(mimeMessage);
					statusMsg.addProperty("i_SUCC", "Email Successfully Sent");
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Email Successfully Sent");
					log(to$emailIds, cc$emailIds, bcc$emailIds, statusMsg, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
					// isonMsg 
					// db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", email$logger);//#00000003
				} catch (Exception e) {
					e.printStackTrace();
					statusMsg.addProperty("i_ERROR", "Email Sent Failed");
					// email$logger.add("StatusMsg",
					// statusMsg.get("i_ERROR").getAsJsonObject());//#00000003
					// isonMsg 
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Email Sent Failed");
					log(to$emailIds, cc$emailIds, bcc$emailIds, statusMsg, null, msgBody, sPrimaryKey, sPrimaryOpr);// #00000003
					// db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", email$logger);
				}
				// #MAQ00131 starts
				} else if (!emailEnabled){
					JEmailArgJson.addProperty("CommunicationMode", "SMS");
					JEmailArgJson.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
					JEmailArgJson.addProperty("CommunicationBody", msgBody);
					JEmailArgJson.add("ToEmailds", to$emailIds);
					JEmailArgJson.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
					JEmailArgJson.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());
					JEmailArgJson.addProperty("StatusMsg", "Email settings disabled, default success msg shown");
					//#MAQ000033 ends
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SMS Successfully Sent via Impacto");
					db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", JEmailArgJson);
					return isonMsg;
				}  // #MAQ00131 ends
				 else {
				 
				if (JEmailArgJson.has("PrimaryKey"))
					sPrimaryKey = JEmailArgJson.get("PrimaryKey").getAsString();
				if (JEmailArgJson.has("PrimaryOpr"))
					sPrimaryOpr = JEmailArgJson.get("PrimaryOpr").getAsString();
				statusMsg.addProperty("i_ERROR", "IP Address Validation Failed");
				// isonMsg 
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Email Service Disabled. Contact Admin");
				log(to$emailIds, null, null, statusMsg, null, msgBody, sPrimaryKey,
						sPrimaryOpr);// #00000003
			}
		} catch (Exception e) {
			JsonObject to$emailIds = JEmailArgJson.get("toemailIds").getAsJsonObject();
			JsonObject statusMsg = new JsonObject();
			String sPrimaryKey = "";
			String sPrimaryOpr = "";
			if (JEmailArgJson.has("PrimaryKey"))
				sPrimaryKey = JEmailArgJson.get("PrimaryKey").getAsString();
			if (JEmailArgJson.has("PrimaryOpr"))
				sPrimaryOpr = JEmailArgJson.get("PrimaryOpr").getAsString();
			statusMsg.addProperty("i_ERROR", "UnCaught Exception~" + e.getMessage());
			// isonMsg 
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UnCaught Exception~");
			log(to$emailIds, null, null, statusMsg, null, "UnCaught Exception~" + e.getMessage(), sPrimaryKey,
					sPrimaryOpr);// #00000003
			e.printStackTrace();

		}
		
		return isonMsg; 

	}
	// #BHUVI001 Ends

	public IEmailService() {
		super();
		// TODO Auto-generated constructor stub
	}

	 

}//// #00000001 Ends