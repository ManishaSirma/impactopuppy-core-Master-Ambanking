/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Mar 05, 2019 | #BVB00082   | Initial writing
      |0.3.6       | Vijay 		| May 04, 2019 | #BVB00142   | Making heartbeat POST instead of GET
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB00082 Begins

package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;

/**
 * HeartBeat to Inform server the current status
 */
@Controller
public class HeartBeat {

	public HttpStatus isonResHTPPStat = null;
	private IResManipulator i$ResM = new IResManipulator();
	private DBController db$Ctrl = new DBController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private Ioutils I$utils = new Ioutils();

	//@RequestMapping(value = "/heartBeat", method = RequestMethod.GET)
	@RequestMapping(value = "/heartBeat", method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper generateReport(HttpServletRequest request) {
		JsonObject filter = new JsonObject();
		JsonObject setter = new JsonObject();
		try {
			IResManipulator.iloggedUser.set(I$impactoUtil.getUserId(request));

			if (!I$utils.$iStrFuzzyMatch(IResManipulator.iloggedUser.get(), "")) {
				filter.addProperty("userId", IResManipulator.iloggedUser.get());
				setter.add("lastActivityAt", i$ResM.addDateTime(new Date()));
				db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", setter, filter);
			} else {
				isonResHTPPStat = HttpStatus.EXPECTATION_FAILED;
			}

		} catch (Exception e) {
			isonResHTPPStat = HttpStatus.EXPECTATION_FAILED;
		}
		isonResHTPPStat = (isonResHTPPStat == null ? HttpStatus.OK : isonResHTPPStat);
		return new ResponseWrapper(null, isonResHTPPStat, null);

	}

}

// #BVB00082 Ends