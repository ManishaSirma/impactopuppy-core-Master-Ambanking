/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Baz 		| Jan 17, 2019 | #00000001   | Initial writing
      |0.1 Beta    | Niegil 	| Jan 18, 2019 | #00000002   | Fine Tuning the Code
      |----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IpinController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil $imputils = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IpinController.class); // Nye- Change Class Name
	// always
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			new Gson();

			i$ResM.getSrvcopr(isonMsg);
			i$ResM.getSrvcName(isonMsg);
			String ScrId = i$ResM.getScreenID(isonMsg);
			i$ResM.getSiteKey(isonMsg);
			String ScrOpr = i$ResM.getOpr(isonMsg);

			if (I$utils.$iStrFuzzyMatch(ScrId, "XIDTRNPN") && I$utils.$iStrFuzzyMatch(ScrOpr, "CREATE")) {
				return sendIpin(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(ScrId, "XIDTPVRY") && I$utils.$iStrFuzzyMatch(ScrOpr, "CREATE")) {
				return verifyIpin(isonMsg);
			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
	};

	@SuppressWarnings("null")
	private JsonObject sendIpin(JsonObject isonMsg) {
		try {
				//Forwarding Request to DBController for Registration 

				//1 . Decrypt the Key
				String iKey = null;
				JsonObject argJson = new JsonObject();
				// Read the Key from Session key  from ICOR_S_SESSION_VALIDATOR 
				iKey = $imputils.decrypt(i$ResM.getBodyElementS(isonMsg, "iKey"), i$ResM.getGobalValStr("deCryptKey"));

				//2.  Check if Key exists
				if (! (iKey != null) || db$Ctrl.db$GetRowCnt("ICOR_M_ECOMM_REPO", "{ \"Key\":\"" + iKey + "\"}") < 1) {
					return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "TYPE ERROR");
				} else {
					//3.  Send Identity Pin through Configured method
					int I_Pin = $imputils.generateRandom(100005, 999999);
					String ISecuredpin = $imputils.encrypt(Integer.toString(I_Pin), i$ResM.getGobalValStr("deCryptKey"));
					// Protect user's password. The generated value can be stored in DB.
					// String mySecurePassword = ImpactoUtil.generateSecurePassword(Identity_Pin, salt);	
					argJson.addProperty("IPin", Integer.toString(I_Pin));
					//argJson.addProperty("Salt", salt);
					argJson.addProperty("Key", iKey);
					argJson.add("CreatedAt", i$ResM.adddate(new Date()).getAsJsonObject());
					argJson.addProperty("IpinVerified", false);
					// Generate the Ipin key and Imei combination 
					JsonObject icor$Filter = new JsonObject();
					icor$Filter.addProperty("Key", iKey);
					db$Ctrl.db$UpdateRow("ICOR_S_IPIN_VALIDATOR", argJson, icor$Filter, "true");
					//Return with Encrypted Ipin  back to App	
					JsonObject i$resBody = new JsonObject();
					i$resBody.addProperty("Ipin", ISecuredpin);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Ipin Sent Successfully");
					return i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);

				}
		} // End of try
		catch(Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", excep.getMessage().toString());
			excep.printStackTrace();
			logger.debug(excep.getMessage());
			return isonMsg;
		}
	};

	private JsonObject verifyIpin(JsonObject isonMsg) {
		JsonObject i$body = null;
		i$body = isonMsg.getAsJsonObject("i-body");
		try {
				//Forwarding Request to DBController for Registration 

				//1 . Decrypt the Key
				String iKey = null;
				String iMei = i$ResM.getIME(isonMsg);
				String dec_IPin = null;
				// Read the Key from Session key  from ICOR_S_SESSION_VALIDATOR 
				String SessionId = i$ResM.getClientSessionID(isonMsg);
				JsonObject SesValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", "{\"sessionId\":\"" + SessionId + "\"}");
				if (SesValidator != null) {
					//#00000002 Changes Begin
					try
					{
						iKey = $imputils.decrypt(i$body.get("iKey").getAsString(), i$ResM.getGobalValStr("deCryptKey"));
					}
					catch(Exception e)
					{
						iKey = i$body.get("iKey").getAsString();
					};
					
					try
					{
						dec_IPin = $imputils.decrypt(i$body.get("IPin").getAsString(), i$ResM.getGobalValStr("deCryptKey"));
					}
					catch(Exception e)
					{
						dec_IPin = i$body.get("IPin").getAsString();
					};
					//#00000002 Changes End

				} else {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID SESSION ID");
				}

				if (i$body.get("Key_Mode").getAsString().startsWith("C")) {
					// handle the timings for customer here

				}
				//2.  Chekc if Keys IMEi and pin combination exists
				JsonObject ipin$query = new JsonObject();
				ipin$query.addProperty("Key", iKey);
				ipin$query.addProperty("IPin", dec_IPin);

				if (iMei != null) {
					ipin$query.addProperty("IMei", iMei);
				}
				//if (!(iKey != null) || db$Ctrl.db$GetRowCnt("ICOR_M_ECOMM_REPO", "{ \"Key\":\"" + iKey + "\" , \"IMei\":\"" + iMei + "\" }") < 1)
				if (! (iKey != null) || (db$Ctrl.db$GetRowCnt("ICOR_M_ECOMM_REPO", ipin$query.toString())) < 1) {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "KEY TYPE");
				} else {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "IPIN VERIFIED SUCCESSFULY");
				}
		} // End of try
		catch(Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", excep.getMessage().toString());
			excep.printStackTrace();
			logger.debug(excep.getMessage());
			return isonMsg;
		}
	};

	public boolean verifyIPin(JsonObject i$body) {
		try {
			//1 . Decrypt the Key
			String iKey = null;
			String dec_IPin = null;
			// Read the Key from Session key  from ICOR_S_SESSION_VALIDATOR 
			//#00000002 Changes Begin
			try
			{
				iKey = $imputils.decrypt(i$body.get("iKey").getAsString(), i$ResM.getGobalValStr("deCryptKey"));
			}
			catch(Exception e)
			{
				iKey = i$body.get("iKey").getAsString();
			};
			
			try
			{
				dec_IPin = $imputils.decrypt(i$body.get("IPin").getAsString(), i$ResM.getGobalValStr("deCryptKey"));
			}
			catch(Exception e)
			{
				dec_IPin = i$body.get("IPin").getAsString();
			};
			//#00000002 Changes End

			// Get the TKn
			String sTk = null;
			sTk = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", "{\"$or\":[{\"Key_Owner\":\""+iKey+"\"},{\"Key_Token\":\""+iKey+"\"}]}",
					"{ \"Key_Token\": 1}").get("Key_Token").getAsString();
			
			if (db$Ctrl.db$GetRowCnt("ICOR_S_IPIN_VALIDATOR", "{\"Key\":\""+sTk+"\",\"IPin\":\""+dec_IPin+"\"}") > 0) {
				return true;
			} else {
				return false;
			}

		} // End of try
		catch(Exception excep) {
			excep.printStackTrace();
			logger.debug(excep.getMessage());
			return false;
		}
	};

	public IpinController() {};
}

//#00000001 Ends
