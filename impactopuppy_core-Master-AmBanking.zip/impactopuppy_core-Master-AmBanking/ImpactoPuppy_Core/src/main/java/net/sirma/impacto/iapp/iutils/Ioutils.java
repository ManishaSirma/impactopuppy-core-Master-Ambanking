/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 			| Dec 9, 2018  | #BVB00023   | New functions for: HasMap, Rule Builder, Date Convertors
      |0.2.1       | Vijay 			| Jan 09, 2019 | #BVB00035   | Encryption Decryption based on Maintenance 
      |0.2.1	   | Syed 			| Jan 9, 2018  | #MAQ00001   | Added functions getHighPriorityValue, round, $isNull
      |0.2.1	   | Niegil 		| Jan 9, 2018  | #00000002   | Source Code Validation FrameWork Changes
      |0.2.1	   | Niegil 		| Feb 7, 2018  | #00000003   | Julian Date (5 Digits)
      |0.2.1       | Bhuvi          | Feb 25,2019  | #BHUVI001   | Added Function to get Date difference 
      |0.3.7       | Vijay 		    | May 08, 2019 | #BVB00147   | Get timeDifference with a format
      |0.3.17      | Vijay  	    | Jul 25, 2019 | #BVB00189   | Generic Function for Checking mandatory Fields
      |0.4.2       | Vijay 		    | Sep 02, 2019 | #BVB00205   | Random generation with max min acceptance
      |3.1.9       | Vijay 		    | Jan 03, 2020 | #BVB00217   | Julian Date adding extra 0   
	  |3.1.10      | Devraj 	    | Mar 05, 2021 | #DVJ00037   | Added changeDate and changeDateFormat for auto appln kill
	  |0.3 Beta    | Pruthvi 	    | Apr 09, 2021 | #YPR00070   | Get DateString in required format.
	  |0.3 Beta    | Pruthvi 	    | Apr 21  2021 | #YPR00077   | Added dateFormater functions to get ISO date Object
	  |0.3 Beta    | Pappu          | Nov 24, 2021 | #PKY00064   | Added function for fetch value from json in case of string and array
	  |0.3 Beta    | Pappu          | Dec 23, 2021 | #PKY00068   | Added function to find string in array
	  |0.3 Beta    | Madhura        | Nov 10, 2022 | #MSA00001   | Added for ISO date format including seconds
	  |0.3 Beta    | Sindhu         | Jan 18, 2023 | #SRM00020   | Added code for getting Base64 string
	  |0.3 Beta    | Madhura        | Apr 24, 2023 | #MSA00002   | Added code for ISO date format with AM/PM
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
//#MAQ00001 start 
import java.math.BigDecimal;
import java.math.RoundingMode;
//#MAQ00001 end
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.github.junrar.Archive;
import com.github.junrar.exception.RarException;
import com.github.junrar.impl.FileVolumeManager;
import com.github.junrar.rarfile.FileHeader;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.mongodb.BasicDBObject;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;

public class Ioutils {
	private Logger logger = LoggerFactory.getLogger(Ioutils.class);
	
	private static SimpleDateFormat dateFormat= null;
	//#00000003 Begins
	public int convertToJulian(String sDDMMYYYY)
    {
    int resultJulian = 0;
    if(sDDMMYYYY.length() > 0)
    {
     /*Days of month*/
     int[] monthValues = {31,28,31,30,31,30,31,31,30,31,30,31};

     String dayS, monthS, yearS;
     dayS = sDDMMYYYY.substring(0,2);
     monthS = sDDMMYYYY.substring(2, 4);
     yearS = sDDMMYYYY.substring(4, 8);

     /*Convert to Integer*/
     int day = Integer.valueOf(dayS);
     int month = Integer.valueOf(monthS);
     int year = Integer.valueOf(yearS); 

         //Leap year check
         if(year % 4 == 0)
         {
          monthValues[1] = 29;    
         }
         //Start building Julian date
         String julianDate = "1";
         //last two digit of year: 2012 ==> 12
         julianDate += yearS.substring(2,4);

         int julianDays = 0;
         for (int i=0; i < month-1; i++)
         {
          julianDays += monthValues[i];
         }
         julianDays += day;

             if(String.valueOf(julianDays).length() < 2)
             {
              julianDate += "00";
             }
             //if(String.valueOf(julianDays).length() < 3)// #BVB00217
             else if(String.valueOf(julianDays).length() < 3) // #BVB00217
             {
              julianDate += "0";
             }

        julianDate += String.valueOf(julianDays);
    resultJulian =  Integer.valueOf(julianDate);    
 }
 return resultJulian;
}
	//#00000003 Ends
	//#SRM00020 starts
	public String getBase64(String str) {
		String encoded = "";
		try {
			Base64.Encoder enc = Base64.getEncoder();
			encoded = enc.encodeToString(str.getBytes());

		} catch(Exception e) {
			e.printStackTrace();
		}
		return encoded;
	} // #SRM00020 ends
	public boolean iStrNoCaseSenMatchT(String str1, String str2) {
		try {
			str1 = (str1 == null) ? "~" : str1;
			str2 = (str2 == null) ? "~" : str2;
			return (str1.toUpperCase()).trim().equals((str2.toUpperCase()).trim());
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return null != null;
		}
	};

	public boolean $iStrCaseSenMatchT(String str1, String str2) {
		try {
			str1 = (str1 == null) ? "~" : str1;
			str2 = (str2 == null) ? "~" : str2;
			return str1.trim().equals(str2.trim());
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return null != null;
		}
	};

	public boolean $iStrNoCaseSenMatch(String str1, String str2) {
		try {
			str1 = (str1 == null) ? "~" : str1;
			str2 = (str2 == null) ? "~" : str2;
			return (str1.toUpperCase()).equals((str2.toUpperCase()));
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return null != null;
		}
	};

	public boolean $iStrCaseSenMatch(String str1, String str2) {
		try {
			str1 = (str1 == null) ? "~" : str1;
			str2 = (str2 == null) ? "~" : str2;
			return str1.equals(str2);
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return null != null;
		}
	};

	public String strip$Dquote(String str) {
		if (!$iStrBlank(str))
			str = str.replaceAll("^\"|\"$", "");
		return str;
	}

	public boolean $iStrFuzzyMatch(String str1, String str2) {
		try {
			str1 = (str1 == null) ? "~" : str1;
			str2 = (str2 == null) ? "~" : str2;
			str1 = str1.replaceAll("(?i)UNAUTHORISED", "UNAUTHORIZED");
			str2 = str2.replaceAll("(?i)UNAUTHORISED", "UNAUTHORIZED");
			str1 = str1.replaceAll("(?i)COLOUR", "COLOR");
			str2 = str2.replaceAll("(?i)COLOUR", "COLOR");
			str1 = str1.replaceAll("(?i)CENTER", "CENTRE");
			str2 = str2.replaceAll("(?i)CENTER", "CENTRE");
			str1 = str1.replaceAll("^\"|\"$", "");
			str2 = str2.replaceAll("^\"|\"$", "");
			str1 = str1.toUpperCase().replaceAll("\\s+", "");
			str2 = str2.toUpperCase().replaceAll("\\s+", "");
			return str1.equals(str2);
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return null != null;
		}
	};

	public boolean $iStrBlank(String str1) {
		try {
			return (str1 == null || "".equals(str1));
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return null != null;
		}
	};

	public int $igetRandonNum(int factor) {
		try {
			return (int) Math.floor((Math.random() * factor) + 1);
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return -999;
		}
	};
	// #BVB00205 Starts 
	public int $igetRandonNum(int max, int min) {
		try {
			return (int)    Math.round( Math.random() * (max - min) + min); 
		} catch (Exception e) {
			logger.debug(e.getMessage().toString());
			return 999;
		}
	};
	// #BVB00205 Ends
	public boolean $iExistsInArrayJ(JsonArray array, String element) {
		boolean found = false;
		try {
			for (int i = 0; i < array.size(); i++) {
				if ($iStrFuzzyMatch(array.get(i).getAsString(), element)) {
					found = true;
					break;
				}
			}

			return found;
		} catch (Exception e) {
			e.printStackTrace();
			found = false;
		}

		return found;

	}

	// #00000002 Begins
	public String $getISONow() {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		return df.format(new Date());
	}
	//MSA00002 starts
	public String $getISONowAm() {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormatSymbols symbols = new DateFormatSymbols();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh.mm aa"); 
		symbols.setAmPmStrings(new String[] { "AM", "PM" });
		df.setDateFormatSymbols(symbols);
		df.setTimeZone(tz);
		return df.format(new Date());
	}
	//MSA00002 ends
	//#MSA00001 starts
	public String $getISONowTo() {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		return df.format(new Date());
	}
	//#MSA00001 ends
	
	public String $getISOTodayTo() {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss' '"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		return df.format(new Date());
	}
	
	public String $getISODt(Date dt) {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		return df.format(dt);
	}
	
	// #00000002 ends
	public int $intValNullIf(int val) {
		return val;
	};

	public int $intValNullIf(Integer val, int Nullif) {
		try {
			if (val != null)
				return val;
			else
				return Nullif;
		} catch (Exception e) {
			return Nullif;
		}
	};

	public int $intValNullIf(String val, int Nullif) {
		try {
			if (val != null)
				return Integer.valueOf(val);
			else
				return Integer.valueOf(Nullif);
		} catch (Exception e) {
			return Integer.valueOf(Nullif);
		}
	};

	public int $intValNullIf(String val, String Nullif) {
		try {
			if (val != null)
				return Integer.valueOf(val);
			else
				return Integer.valueOf(Nullif);
		} catch (Exception e) {
			return Integer.valueOf(Nullif);
		}
	};

	public String $strValNullIf(String val, String Nullif) {
		try {
			if (!val.equals(null) && !$iStrBlank(val))
				return val;
			else
				return Nullif;
		} catch (Exception e) {
			return Nullif;
		}
	};

	public String $strValNullIf(Integer val, String Nullif) {
		try {
			if ((val != null))
				return String.valueOf(val);
			else
				return Nullif;
		} catch (Exception e) {
			return Nullif;
		}
	};

	public String $strValNullIf(Integer val, Integer Nullif) {
		try {
			if ((val != null))
				return String.valueOf(val);
			else
				return String.valueOf(Nullif);
		} catch (Exception e) {
			return String.valueOf(Nullif);
		}
	};

	public String $CamelCase(final String init) {
		if (init == null)
			return null;

		final StringBuilder ret = new StringBuilder(init.length());

		for (final String word : init.split(" ")) {
			if (!word.isEmpty()) {
				ret.append(word.substring(0, 1).toUpperCase());
				ret.append(word.substring(1).toLowerCase());
			}
			if (!(ret.length() == init.length()))
				ret.append(" ");
		}

		return ret.toString();
	};

	// BVB Starts

	public double $roundTwoDouble(double valueIn) {
		double valueOut = 0;
		try {
			DecimalFormat df = new DecimalFormat("###.##");
			valueOut = Double.parseDouble(df.format(valueIn));

		} catch (Exception e) {
			valueOut = 0;
		}

		return valueOut;
	}

	// BVB Ends

	public JsonArray infixToPostfix(JsonArray isonMsg, JsonArray preDefVal) {

		JsonArray resMsg = new JsonArray();

		// initializing empty stack for Operators
		Stack<String> operators = new Stack<String>();
		try {
			for (int i = 0; i < isonMsg.size(); ++i) {
				String i$runningS = isonMsg.get(i).getAsString();

				// If the scanned String is an operand, add it to Res Msg
				if (!isInArray(preDefVal, i$runningS))
					resMsg.add(i$runningS);

				// If the scanned string is an '(', push it to the Operators stack.
				else if ($iStrFuzzyMatch(i$runningS, "("))
					operators.push(i$runningS);

				// If the scanned character is an ')', pop and output from the stack until an
				// '(' is encountered.
				else if ($iStrFuzzyMatch(i$runningS, ")")) {
					while (!operators.isEmpty() && !$iStrFuzzyMatch(operators.peek(), "("))
						resMsg.add(operators.pop());

					if (!operators.isEmpty() && !$iStrFuzzyMatch(operators.peek(), "(")) {

						logger.debug("Invalid Expression !! ");
						return null;
					} else
						operators.pop();
				} else // an operator is encountered
				{
					operators.push(i$runningS);
				}

			}

			// pop all the operators from the stack into Res Msg
			while (!operators.isEmpty())
				resMsg.add(operators.pop());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		// logger.debug("resMsg: " + resMsg);
		return resMsg;

	}

	public boolean isInArray(JsonArray arr, String element) {
		boolean found = false;

		try {
			for (int i = 0; i < arr.size(); i++)
				if ($iStrFuzzyMatch(arr.get(i).getAsString(), element)) {
					found = true;
					break;
				}
		} catch (Exception e) {
			e.printStackTrace();
			return false;

		}

		return found;
	}
	//PKY00068 starts
	public boolean strInJsonArray(String element, JsonArray arr) {
	    boolean found = false;
	    Gson gson = new Gson();
	    try {
	        for (int i = 0; i < arr.size(); i++) {
	            JsonObject jsonObj = arr.get(i).getAsJsonObject();
	            Set < String > key = jsonObj.keySet();
	            for (String res: key) {
	                if ($iStrFuzzyMatch(jsonObj.get(res).getAsString(), element)) {
	                    found = true;
	                    break;
	                }
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	    return found;
	}
 //PKY00068 ends
	// #BVB00023 Starts
	// Create Has Map
	public JsonArray createHashMap(JsonArray array, String element) {
		JsonArray hashMap = new JsonArray();

		try {
			for (int i = 0; i < array.size(); i++) {
				JsonObject i$runningObject = array.get(i).getAsJsonObject();
				JsonObject i$newObject = new JsonObject();
				i$newObject.add(i$runningObject.get(element).getAsString(), i$runningObject.remove(element));
				hashMap.add(i$newObject);

			}
			Gson gson = new Gson();
			Type countryMapType = new TypeToken<Map<Integer, String>>() {
			}.getType();
			Map<Integer, String> countryMap = gson.fromJson(array.toString(), countryMapType);

		} catch (Exception e) {
			e.printStackTrace();
			hashMap = null;
		}
		return hashMap;

	}

	/*
	 * Logic of Creating Mongo Query IN Parameter -- Array of Expression created in
	 * frontend OUT -- A Json Object which is a filter that can be applied on Mongo
	 * 
	 * Logic: 1) System would convert the given Infix expression to postfix using
	 * infixToPostfix function. 2) Converting the postfix expression to query
	 * follows:
	 * 
	 * 
	 */

	// public JsonObject createMongoQueryS(JsonArray reqMsg, JsonArray preDefVal) {
	public String createMongoQueryS(JsonArray reqMsg, JsonArray preDefVal) {

		Stack<String> operands = new Stack<String>();
		JsonObject i$runningQuery = new JsonObject();
		BasicDBObject queryFilter = new BasicDBObject();
		JsonParser parser = new JsonParser();
		JsonObject oper = new JsonObject();
		JsonArray list = new JsonArray();
		String l = "";
		String r = "";

		try {

			JsonArray reqMsgPostfix = infixToPostfix(reqMsg, preDefVal);
			for (int i = 0; i < reqMsgPostfix.size(); i++) {
				String i$runningS = reqMsgPostfix.get(i).getAsString();

				if (!isInArray(preDefVal, i$runningS)) {
					operands.push(i$runningS);
				} else if ($iStrFuzzyMatch(i$runningS, "&&") || $iStrFuzzyMatch(i$runningS, "||")) {
					list = new JsonArray();
					queryFilter = new BasicDBObject();
					r = operands.pop();
					l = operands.pop();

					String op = "";
					if ($iStrFuzzyMatch(i$runningS, "&&"))
						op = "#and";
					else
						op = "#or";

					list.add(parser.parse(r).getAsJsonObject());
					list.add(parser.parse(l).getAsJsonObject());

					queryFilter.put(op, list); // Failed here
					// queryFilter.put(op, )
					Gson gsonp = new Gson();

					operands.push(gsonp.toJson(queryFilter));

				} else {
					oper = new JsonObject();
					i$runningQuery = new JsonObject();
					if ($iStrFuzzyMatch(i$runningS, "===")) {
						r = operands.pop();
						l = operands.pop();
						i$runningQuery.addProperty(l, r);
						// operators.pop();
					} else if ($iStrFuzzyMatch(i$runningS, ">=")) {
						r = operands.pop();
						l = operands.pop();
						oper.addProperty("#gte", Integer.parseInt(r));

						i$runningQuery.add(l, oper);
						// operators.pop();
					} else if ($iStrFuzzyMatch(i$runningS, "<=")) {
						r = operands.pop();
						l = operands.pop();

						oper.addProperty("#lte", Integer.parseInt(r));

						i$runningQuery.add(l, oper);
						// operators.pop();
					} else if ($iStrFuzzyMatch(i$runningS, "<")) {
						r = operands.pop();
						l = operands.pop();
						oper.addProperty("#lt", Integer.parseInt(r));

						i$runningQuery.add(l, oper);
						// operators.pop();
					} else if ($iStrFuzzyMatch(i$runningS, ">")) {
						r = operands.pop();
						l = operands.pop();
						oper.addProperty("#gt", Integer.parseInt(r));
						i$runningQuery.add(l, oper);
						// operators.pop();
					}

					operands.push(i$runningQuery.toString());

				}
			}

			logger.debug("operands: " + operands);

			// return parser.parse(operands.pop()).getAsJsonObject();

			return operands.pop();

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public JsonArray convertRulesToQuery(JsonArray rules, JsonArray preDefVal, String setField) {

		JsonObject runningObj = new JsonObject();
		JsonArray rulesUpdated = new JsonArray();

		for (int i = 0; i < rules.size(); i++) {
			try {
				runningObj = new JsonObject();
				JsonObject i$runningRuleObj = rules.get(i).getAsJsonObject();
				String resFilter = createMongoQueryS(i$runningRuleObj.get("condition").getAsJsonArray(), preDefVal);

				runningObj.addProperty("ruleFilter", resFilter);

				String setterS = "{\"" + setField + "\":\"" + i$runningRuleObj.get("set").getAsString() + "\"}";

				runningObj.addProperty("set", setterS);
				runningObj.addProperty("priority", i$runningRuleObj.get("prority").getAsInt());

				rulesUpdated.add(runningObj);
			} catch (Exception e) {
				e.printStackTrace();
				// Eat Up
				logger.debug("Failed in Converting rule of: " + i + " with: " + e.getMessage());
			}
		}

		return rulesUpdated;
	}

	// BVB Starts
	public String getDate() {
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Calendar cal = Calendar.getInstance();
			return dateFormat.format(cal.getTime());

			// dateFormat.format(date);
		} catch (Exception e) {

			return null;
		}

	};

	public String getDateOneYear() {
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.YEAR, 1);
			return dateFormat.format(cal);
		} catch (Exception e) {

			return null;
		}

	}

	// #MAQ00001 start
	public double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	public JsonObject getHighPriorityValue(JsonArray inArray) {
		int highestPriority = -1;
		// String highestValue = "";
		int priorityIndex = -1;
		JsonObject priorityObj = new JsonObject();

		try {
			if (inArray.size() > 0) {
				// highestValue = inArray.get(0).getAsJsonObject().get("value").getAsString();
				highestPriority = inArray.get(0).getAsJsonObject().get("priority").getAsInt();
				priorityIndex = 0;
				for (int i = 0; i < inArray.size(); i++) {
					JsonObject i$runningObj = inArray.get(i).getAsJsonObject();

					if (!$iStrFuzzyMatch(i$runningObj.get("value").getAsString(), "")) {

						if ($iStrFuzzyMatch(
								inArray.get(priorityIndex).getAsJsonObject().get("value").getAsString(), "")) {
							highestPriority = i$runningObj.get("priority").getAsInt();
							priorityIndex = i;
						} else {
							if (i$runningObj.get("priority").getAsInt() > highestPriority) {
								// highestValue = i$runningObj.get("value").getAsString();
								highestPriority = i$runningObj.get("priority").getAsInt();
								priorityIndex = i;
							}
						}
					}

				}
				priorityObj = inArray.get(priorityIndex).getAsJsonObject();

			} else {
				priorityObj = null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			priorityObj = null;
		}

		return priorityObj;
	}
	
	public String fetchValueFromJsonObj(JsonObject app$json, String key, String defVal) {
		String retValue = defVal;
		if (app$json.has(key)) {
			retValue = app$json.get(key).getAsString();
		}
		return retValue;
	}

	public boolean $isNull(JsonElement element) {
		boolean iNull = true;
		try {
			if (element != null) {
				if (element.isJsonArray()) {
					JsonArray arrElem = element.getAsJsonArray();
					if (arrElem.size() > 0) {
						iNull = false;
					}
				} else if (element.isJsonObject()) {
					JsonObject objElem = element.getAsJsonObject();
					if (objElem.size() > 0) {
						iNull = false;
					}
				} else {
					if (!(element.isJsonNull())) {
						iNull = false;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			iNull = true;
		}
		return iNull;
	}
	// V0000025 File reading related changes

	// #V000004 starts
	public File extractRAR(String FileName, JsonObject argJson) throws IOException {

		File rarFile = new File(FileName);
		Archive a = null;
		try {
			a = new Archive(new FileVolumeManager(rarFile));
		} catch (RarException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (a != null) {
			a.getMainHeader().print();
			FileHeader fh = a.nextFileHeader();
			while (fh != null) {
				try {
					File out = new File("D:/Extract/" + fh.getFileNameString().trim());
 					// FileInputStream is = new FileInputStream(out);

					FileOutputStream os = new FileOutputStream(out);
					a.extractFile(fh, os);
					os.close();
					a.close();
					// Delete the Rar file
					/*
					 * try { rarFile.delete(); }catch(Exception e) { e.printStackTrace(); }
					 */
					return out;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
					return null;
				} catch (RarException e) {
					e.printStackTrace();
					return null;
				} catch (IOException e) {
					e.printStackTrace();

				}
				fh = a.nextFileHeader();
			}
		}
		return null;

	}

	@SuppressWarnings("unused")
	private File unzip(String zipFilePath, String destDir) {
		File dir = new File(destDir);
		// create output directory if it doesn't exist
		if (!dir.exists())
			dir.mkdirs();
		FileInputStream fis;
		// buffer for read and write data to file
		byte[] buffer = new byte[1024];
		try {
			fis = new FileInputStream(zipFilePath);
			ZipInputStream zis = new ZipInputStream(fis);
			ZipEntry ze = zis.getNextEntry();
			File newFile = null;
			while (ze != null) {
				String fileName = ze.getName();
				newFile = new File(destDir + File.separator + fileName);
 				// create directories for sub directories in zip
				new File(newFile.getParent()).mkdirs();
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				// close this ZipEntry
				zis.closeEntry();
				ze = zis.getNextEntry();
			}
			// close last ZipEntry
			zis.closeEntry();
			zis.close();
			fis.close();

			return newFile;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;

	}

	// XML parser functionalities

	public void XmlFileParser(String FileName) {

		try {

			// File file = new File("/Users/mkyong/staff.xml");
			File file = new File(FileName);
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

			Document doc = (Document) dBuilder.parse(file);

 
			if (((Node) doc).hasChildNodes()) {

				printNote(((Node) doc).getChildNodes());

			}

		} catch (Exception e) {
			logger.debug(e.getMessage());
		}

	}

	private void printNote(NodeList nodeList) {

		for (int count = 0; count < nodeList.getLength(); count++) {

			Node tempNode = nodeList.item(count);

			// make sure it's element node.
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				// get node name and value
				logger.debug("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
				logger.debug("Node Value =" + tempNode.getTextContent());

				if (tempNode.hasAttributes()) {

					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();

					for (int i = 0; i < nodeMap.getLength(); i++) {

						Node node = nodeMap.item(i);
						logger.debug("attr name : " + node.getNodeName());
						logger.debug("attr value : " + node.getNodeValue());

					}

				}

				if (tempNode.hasChildNodes()) {

					// loop again if has child nodes
					printNote(tempNode.getChildNodes());

				}

				logger.debug("Node Name =" + tempNode.getNodeName() + " [CLOSE]");

			}

		}

	}

	// #MAQ00001 start

	// #BVB00023 Ends
	// #BVB00035 Starts
	public String $randomAplhanumeric(int length) {

		StringBuilder randAplNumB = new StringBuilder();
		randAplNumB = new StringBuilder();
		String randAplNumS = "";
		try {
			String RANDOMCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

			Random rnd = new Random();
			while (randAplNumB.length() < length) { // length of the random string.
				int index = (int) (rnd.nextFloat() * RANDOMCHARS.length());
				randAplNumB.append(RANDOMCHARS.charAt(index));
			}
			randAplNumS = randAplNumB.toString();
		} catch (Exception e) {
			e.printStackTrace();
			randAplNumS = null;

		}

		return randAplNumS;

	}
	// #BVB00035 Ends

	//#BHUVI001 Start
	public int getDateDifference(String dateStart, String dateStop)
	{

		SimpleDateFormat ISO8601DATEFORMAT = new SimpleDateFormat("MMM dd,yyyy hh:mm:ss a");
       
		Date startDate = null;
	    Date endDate = null;
	    try {
	    	startDate = ISO8601DATEFORMAT.parse(dateStart);
	    	endDate = ISO8601DATEFORMAT.parse(dateStop);
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
		
	    long diff = endDate.getTime() - startDate.getTime();
      // long diffSeconds = diff / 1000 % 60;
     //  long diffMinutes = diff / (60 * 1000) % 60;
     //  long diffHours = diff / (60 * 60 * 1000);
       int diffInDays = (int) ((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
       
      
	return diffInDays;
		
	}
	//MSA starts
	public int getDateDifferencesInYears(String dateStart, String dateStop)
	{

		SimpleDateFormat ISO8601DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
       
		Date startDate = null;
	    Date endDate = null;
	    try {
	    	startDate = ISO8601DATEFORMAT.parse(dateStart);
	    	endDate = ISO8601DATEFORMAT.parse(dateStop);
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
		
	    long diff = endDate.getTime() - startDate.getTime();
      // long diffSeconds = diff / 1000 % 60;
     //  long diffMinutes = diff / (60 * 1000) % 60;
     //  long diffHours = diff / (60 * 60 * 1000);
       int diffInDays = (int) ((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
       int years = diffInDays / 365;
      
	return years;
		
	}
	//MSA ends
	// #BVB00147 Starts 
	public int getDateDifference(String dateStart, String dateStop, String format)
	{

		SimpleDateFormat ISO8601DATEFORMAT = new SimpleDateFormat(format);
       
		Date startDate = null;
	    Date endDate = null;
	    int diffInDays = -99; 
	    try {
	    	startDate = ISO8601DATEFORMAT.parse(dateStart);
	    	endDate = ISO8601DATEFORMAT.parse(dateStop);
	        long diff = endDate.getTime() - startDate.getTime();
	        // long diffSeconds = diff / 1000 % 60;
	       //  long diffMinutes = diff / (60 * 1000) % 60;
	       //  long diffHours = diff / (60 * 60 * 1000);
	         diffInDays = (int) ((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
	         
	    } catch (ParseException e) {
	        //e.printStackTrace();
	        logger.debug("Failed in getDateDifference with: " + e.getMessage());
	        diffInDays  = -999; 
	        
	    } 
      
	return diffInDays;
		
	}
	// #BVB00147 Ends
	public Date changeTodaysDate(int num, String mod, String dayOrMonthOrYear) {
	    // num- Number of Time or Date or Month or Year
	    // mod- Define the Addition(ADD) or Subtraction(SUB)
	    // dayOrMonthOrYear- Define the Time(MM) or Date(D) or Month(M) or Year(Y) dayOrMonthOrYear
	    Date diffDate = new Date();
	    Calendar calendar = Calendar.getInstance();
	    if ($iStrFuzzyMatch("SUB", mod)) {
	        num = -1 * num;
	    }
	    if ($iStrFuzzyMatch("MM", dayOrMonthOrYear)) {
	        calendar.add(Calendar.MINUTE, num);
	        diffDate = calendar.getTime();
	    } else if ($iStrFuzzyMatch("D", dayOrMonthOrYear)) {
	        calendar.add(Calendar.DATE, num);
	        diffDate = calendar.getTime();
	    } else if ($iStrFuzzyMatch("M", dayOrMonthOrYear)) {
	        calendar.add(Calendar.MONTH, num);
	        diffDate = calendar.getTime();
	    } else if ($iStrFuzzyMatch("Y", dayOrMonthOrYear)) {
	        calendar.add(Calendar.YEAR, num);
	        diffDate = calendar.getTime();
	    }
	    return diffDate;
	}

	public Date changeInputDate(int num, String mod, String dayOrMonthOrYear, Date inputDate) {
	    // num- Number of Time or Date or Month or Year
	    // mod- Define the Addition(ADD) or Subtraction(SUB)
	    // dayOrMonthOrYear- Define the Time(MM) or Date(D) or Month(M) or Year(Y) dayOrMonthOrYear
	    Date diffDate = new Date();
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(inputDate);
	    if ($iStrFuzzyMatch("SUB", mod)) {
	        num = -1 * num;
	    }
	    if ($iStrFuzzyMatch("MM", dayOrMonthOrYear)) {
	        calendar.add(Calendar.MINUTE, num);
	        diffDate = calendar.getTime();
	    } else if ($iStrFuzzyMatch("D", dayOrMonthOrYear)) {
	        calendar.add(Calendar.DATE, num);
	        diffDate = calendar.getTime();
	    } else if ($iStrFuzzyMatch("M", dayOrMonthOrYear)) {
	        calendar.add(Calendar.MONTH, num);
	        diffDate = calendar.getTime();
	    } else if ($iStrFuzzyMatch("Y", dayOrMonthOrYear)) {
	        calendar.add(Calendar.YEAR, num);
	        diffDate = calendar.getTime();
	    }
	    return diffDate;
	}

	// #DVJ00037 Starts
	public Date changeDate(int num , String mod, String dayOrMonthOrYear) {
		// num- Number of Time or Date or Month or Year
		// mod- Define the Addition(ADD) or Subtraction(SUB)
		// dayOrMonthOrYear- Define the Time(MM) or Date(D) or Month(M) or Year(Y) dayOrMonthOrYear
		Date diffDate = new Date();
		Calendar calendar = Calendar.getInstance();
		if($iStrFuzzyMatch("SUB", mod)) {
			num = -1 * num;
		}
		if($iStrFuzzyMatch("MM", dayOrMonthOrYear)) {
			calendar.add(Calendar.MINUTE, num);
			diffDate = calendar.getTime();
		} else if($iStrFuzzyMatch("D", dayOrMonthOrYear)) {
			calendar.add(Calendar.DATE, num);
			diffDate = calendar.getTime();
		} else if($iStrFuzzyMatch("M", dayOrMonthOrYear)) {
			calendar.add(Calendar.MONTH, num);
			diffDate = calendar.getTime();
		} else if($iStrFuzzyMatch("Y", dayOrMonthOrYear)) {
			calendar.add(Calendar.YEAR, num);
			diffDate = calendar.getTime();
		}
		return diffDate;
	}
	
	public String changeDateFormat(Date date, String format) {
		try {
			// format => yyyy-MMM-dd hh:mm:ss ==> 2021-Mar-05 06:15:30
			// format => MMM dd, yyyy ==> Mar 05, 2021
			// format => MMMM dd, yyyy ==> March 05, 2021
			// format => yyyy-MMM-dd ==> 2021-Mar-05
			String formatDate = "";
			SimpleDateFormat formatter = new SimpleDateFormat(format);
			formatDate = formatter.format(date);
			return formatDate.toString();
		} catch(Exception e) {
			return date.toString();
		}
	}
	// #DVJ00037 Ends
	
	public String currentDateinString()
	{
		Date date = new Date(System.currentTimeMillis());

		SimpleDateFormat sdf;
		sdf = new SimpleDateFormat("MMM dd,yyyy hh:mm:ss a");
		sdf.setTimeZone(TimeZone.getTimeZone("CET"));
		String text = sdf.format(date);
		return text;
	}
	///#BHUVI001 Ends
	// #BVB00189 Starts 
	public boolean $isNullOrEmpty(JsonElement element) {
		boolean iNull = true;
		try {
			if (element != null) {
				if (element.isJsonArray()) {
					JsonArray arrElem = element.getAsJsonArray();
					if (arrElem.size() > 0) {
						iNull = false;
					}
				} else if (element.isJsonObject()) {
					JsonObject objElem = element.getAsJsonObject();
					if (objElem.size() > 0) {
						iNull = false;
					}
				} else {
					if (element.isJsonNull() || $iStrFuzzyMatch(element.getAsString(), "")) {
						iNull = false;
					}
				}
			}else {
				iNull = true; 
			}
		} catch (Exception e) {
			e.printStackTrace();
			iNull = true;
		}
		return iNull;
	}
	// #BVB00189 Ends
	
	public Ioutils() {
		// Constructor
	};
	
	//  #Sandeep Start
	
	public HashMap<String,String> findKeys(JsonObject obj){
		HashMap<String,String> keys= new HashMap<String, String>();
		 Set<String> keysFromObj=obj.keySet();

	        for(String key:keysFromObj){
	            if(obj.get(key).getClass()==JsonObject.class){
	                findKeys(obj.get(key).getAsJsonObject());
	            }else{
	                keys.put(key,obj.get(key).getAsString());
	            }
	        }

	        return keys;
	}
	
	 public  String customerDate(Date date) {
	        dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ROOT);
	        try {
	            return dateFormat.format(date);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }
	
	
	// #Sandeep End
	 
	// #YPR00070 Starts
	public String changeDateFormatS(String dateString, String inputFormat, String outputFormat) {
		/*
		 * DateString: 2020-10-26T00:00:00.000Z 
		 * inputFormat:yyyy-MM-dd'T'HH:mm:ss.SSS'Z' 
		 * outputFormat: yyyy/MM/dd
		  
		 * Result: 2020/10/26
		 * Supports Multiple Date Formats
		 */
		
		try {
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(inputFormat, Locale.ENGLISH);
			DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(outputFormat, Locale.ENGLISH);
			LocalDate date = LocalDate.parse(dateString, inputFormatter);
			return outputFormatter.format(date);
		} catch (Exception e) {
			return dateString;
		}
	}
	
	// #YPR00070 Ends
	
	// #YPR00077 Starts
	// used for getting ISO date Object
	// To be used for Querying iso date
	public static JsonObject dateFromatter(String date) {
	    IResManipulator i$ResM = new IResManipulator();
	    SimpleDateFormat dmyFormat = new SimpleDateFormat("yyyy-MM-dd");
	    SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
	    Date orDate;
	    JsonObject retDate = new JsonObject();
	    try {
	      orDate = dmyFormat.parse(date);
	      retDate = i$ResM.adddate(orDate);
	      return retDate;
	    } catch (Exception e) {
	      return null;
	    }

	  }	
	// #YPR00077 Ends
	//#PKY00064 starts
	public String fecthValue$FormJson(JsonObject element, String value, String preDefVal) {
	
		String returnValue = preDefVal;
			
			
			if (element.has(value)) {
				try {
					returnValue = element.get(value).getAsString();
				}catch(Exception e) {
					returnValue = null;
				}
				
			}
             if(element.has(value) && $iStrFuzzyMatch(returnValue,null)) {
            	 returnValue = element.get(value).getAsJsonArray().toString();
			}
			return returnValue;
	}//#PKY00064 ends
}
// #00000001 Ends