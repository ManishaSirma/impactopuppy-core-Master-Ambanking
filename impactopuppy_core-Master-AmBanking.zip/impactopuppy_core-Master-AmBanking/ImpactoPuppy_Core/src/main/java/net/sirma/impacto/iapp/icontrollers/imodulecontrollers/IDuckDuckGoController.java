/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date          | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |3.1.2.419   | Hasan 		| Sept 16, 2019 | #HASAN002   | Initial writing & DuckDuckGo Search separate Function      
      ----------------------------------------------------------------------------------------------
*/
// #HASAN002 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;

import org.apache.commons.codec.language.Soundex;
public class IDuckDuckGoController {
    // *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

    private DBController db$Ctrl = new DBController();
    private Ioutils I$utils = new Ioutils();
    private ImpactoUtil i$impactoUtil = new ImpactoUtil();
    private IResManipulator i$ResM = new IResManipulator();
    private Logger logger = LoggerFactory.getLogger(IDuckDuckGoController.class);
    private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();

    public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
        try {
            String SOpr = i$ResM.getOpr(isonMsg);
            String Scr = i$ResM.getScreenID(isonMsg);
            JsonObject i$body = new JsonObject();

            if (I$utils.$iStrFuzzyMatch(Scr, "OB2DDGOS") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
                isonMsg = doDuckDuckGoSearch(isonMsg);
            } else if (I$utils.$iStrFuzzyMatch(Scr, "OB2DDGOS") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
                isonMsg = duckDuckGoQuery(isonMsg);
            } else {
                isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPERATION");
            }
        } catch (Exception e) {
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
            e.printStackTrace();
            return isonMsg;
        }
        return isonMsg;
    }

    public JsonObject doDuckDuckGoSearch(JsonObject isonMsg) {
        JsonObject argJson = new JsonObject();
        JsonObject filter = new JsonObject();
        String extUrl = "";
        JsonObject JResp = new JsonObject();
        Gson gson = new Gson();
        JsonParser parser = new JsonParser();
        JsonObject i$res = new JsonObject();
        JsonArray hits = new JsonArray();
        try {
            filter.addProperty("trnCd", "duckDuckGoSearch");
            argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
            String key = i$ResM.getBodyElementS(isonMsg, "key"); // argJson.get("searchVal").getAsString();

            // Call the duckduckgo Link and get the response
            argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

            argJson.add("reqBody", new JsonObject());
            extUrl = argJson.get("extUrl").getAsString();

            extUrl = extUrl.replaceAll("###IMP1###key###IMP2###", key);

            argJson.addProperty("extUrl", extUrl);
            // argJson.addProperty("extUrl","http://api.duckduckgo.com/?q=VIJAY%20MALLYA&format=json&pretty=1&no_redirect=1&no_html=1&skip_disambig=1&atb=v145-1");

            JResp = I$EWSLnchr.ILaunchReq(argJson);
            // get the blacklisted words and scan them against the list using fuzzy wuzzy
            filter = new JsonObject();
            filter.addProperty("PARAM", "BlackListWords");
            JsonArray blackListWords = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");
            String resBody = JResp.get("resBody").getAsString();
            JsonObject jsonObject = parser.parse(resBody).getAsJsonObject();


            if (!I$utils.$iStrFuzzyMatch(jsonObject.get("Abstract").getAsString(), "")) {
                for (int i = 0; i < blackListWords.size(); i++) {
                    // Do Fuzzy Wuzzy 
                    JsonObject i$runningBlkList = blackListWords.get(i).getAsJsonObject();
                    JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(i$runningBlkList.get("key").getAsString(), jsonObject.get("Abstract").getAsString(), i$runningBlkList.get("cutOff").getAsDouble()); // add to
                    if (searchHits.getAsJsonArray("hits").size() > 0) {
                        // Once found, build the list
                        JsonObject i$runningObj = new JsonObject();
                        i$runningObj.addProperty("name", jsonObject.get("Heading").getAsString());
                        i$runningObj.addProperty("detail", jsonObject.get("Abstract").getAsString());
                        i$runningObj.addProperty("reference", jsonObject.get("AbstractURL").getAsString());
//                        i$runningObj.addProperty("Found As", i$runningBlkList.get("key").getAsString());
                        hits.add(i$runningObj);
                    }
                }
            } 
            i$res.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            i$res.add("hits", hits);

            db$Ctrl.db$InsertRow("ICOR_M_DUCKDUCKGO_SCAN", i$res);

            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DUCKDUCKGO SEARCH COMPLETED");
        } catch (Exception e) {
            e.printStackTrace();
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "DUCKDUCKGO SEARCH FAILED", e.getMessage());
        }

        return isonMsg;
    }

    public JsonObject doDuckDuckGoSearch(String key) {
        JsonObject argJson = new JsonObject();
        JsonObject filter = new JsonObject();
        String extUrl = "";
        JsonObject JResp = new JsonObject();
        Gson gson = new Gson();
        JsonParser parser = new JsonParser();
        JsonObject isonMsg = new JsonObject();
        JsonArray hits = new JsonArray();
        //JsonObject isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
        try {
            filter.addProperty("trnCd", "duckDuckGoSearch");
            argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
            //String key = i$ResM.getBodyElementS(isonMsg, "key"); // argJson.get("searchVal").getAsString();

            // Call the duckduckgo Link and get the response
            argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

            argJson.add("reqBody", new JsonObject());
            extUrl = argJson.get("extUrl").getAsString();

            extUrl = extUrl.replaceAll("###IMP1###key###IMP2###", key);

            argJson.addProperty("extUrl", extUrl);
            // argJson.addProperty("extUrl","http://api.duckduckgo.com/?q=VIJAY%20MALLYA&format=json&pretty=1&no_redirect=1&no_html=1&skip_disambig=1&atb=v145-1");

            JResp = I$EWSLnchr.ILaunchReq(argJson);
            // get the blacklisted words and scan them against the list using fuzzy wuzzy
            filter = new JsonObject();
            filter.addProperty("PARAM", "BlackListWords");
            JsonArray blackListWords = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", filter).getAsJsonArray("value");
            String resBody = JResp.get("resBody").getAsString();
            JsonObject jsonObject = parser.parse(resBody).getAsJsonObject();
            
            if (!I$utils.$iStrFuzzyMatch(jsonObject.get("Abstract").getAsString(), "")) {
                for (int i = 0; i < blackListWords.size(); i++) {
                    // Do Fuzzy Wuzzy 
                    JsonObject i$runningBlkList = blackListWords.get(i).getAsJsonObject();
                    JsonObject searchHits = i$impactoUtil.fuzzyWuzzy(i$runningBlkList.get("key").getAsString(), jsonObject.get("Abstract").getAsString(), i$runningBlkList.get("cutOff").getAsDouble()); // add to
                    if (searchHits.getAsJsonArray("hits").size() > 0) {
                        // Once found, build the list
                        JsonObject i$runningObj = new JsonObject();
                        i$runningObj.addProperty("name", jsonObject.get("Heading").getAsString());
                        i$runningObj.addProperty("detail", jsonObject.get("Abstract").getAsString());
                        i$runningObj.addProperty("reference", jsonObject.get("AbstractURL").getAsString());
                       // i$runningObj.addProperty("Found As", i$runningBlkList.get("key").getAsString());
                        hits.add(i$runningObj);
                    }
                }
            } 
            isonMsg.addProperty("ScanId", i$impactoUtil.generateRandomKey());
            isonMsg.add("hits", hits);

            db$Ctrl.db$InsertRow("ICOR_M_DUCKDUCKGO_SCAN", isonMsg);

//            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, isonMsg);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DUCKDUCKGO SEARCH COMPLETED");
        } catch (Exception e) {
            e.printStackTrace();
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "DUCKDUCKGO SEARCH FAILED", e.getMessage());
        }

        return isonMsg;
    }

    public JsonObject duckDuckGoQuery(JsonObject isonMsg) {
        JsonObject icorMRisk = new JsonObject();
        JsonObject filter = new JsonObject();
        try {

            String ScanId = i$ResM.getBodyElementS(isonMsg, "ScanId");
            filter.addProperty("ScanId", ScanId);

            icorMRisk = db$Ctrl.db$GetRow("ICOR_M_DUCKDUCKGO_SCAN", filter);

            isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorMRisk);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
        } catch (Exception e) {
            // TODO: handle exception
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
        }

        return isonMsg;

    }

	public void doDuckDuckGosearch(JsonObject argJson) {
		JsonObject isonMsg = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject icorMSdn = new JsonObject();
		try {
			String searchKey = argJson.get("searchKey").getAsString();
			String sdnId = argJson.get("sdnId").getAsString();
			isonMsg = doDuckDuckGoSearch(searchKey);
			filter.addProperty("applicationId", sdnId);
			int sdnResultCount =  db$Ctrl.db$GetCountI("ICOR_M_SDN_SCAN", filter);
			if(sdnResultCount > 0) {
				icorMSdn.add("duckDuckGo", isonMsg);
				db$Ctrl.db$UpdateRow("ICOR_M_SDN_SCAN", icorMSdn, filter,"true");							
			}else {
				logger.debug("Fail To Update in DB");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
    public IDuckDuckGoController() {
        // Cons
    }
}

//#HASAN002 Ended