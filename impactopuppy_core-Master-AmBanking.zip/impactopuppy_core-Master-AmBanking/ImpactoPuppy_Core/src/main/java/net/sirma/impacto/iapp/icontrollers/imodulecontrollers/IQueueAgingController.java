/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.16.327  | BHUVI 		| Jun 29, 2019 | #BHUVI001   |  Controller for Queue Ageing
      ----------------------------------------------------------------------------------------------
      
*/
// #BHUVI001 Starts

package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IQueueAgingController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

		private DBController db$Ctrl = new DBController();
		private Ioutils I$utils = new Ioutils();
		private IResManipulator i$ResM = new IResManipulator();
		private static final Logger logger = LoggerFactory.getLogger(IRepoController.class);
		private ImpactoUtil I$impactoUtil = new ImpactoUtil();
		private ImpactoUtil I$Imputils = new ImpactoUtil();


	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "OB2SDNEX") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				//isonMsg = QueryRepo(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OB2QUAGE") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = LoadQueueData(isonMsg);
			}
			else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}
	
	public JsonObject LoadQueueData(JsonObject isonMsg)
	{
		try {
			String collectionName1 = "ICOR_IBM_PROCESS";
			String feildName="Queue";
			JsonArray runAllQueue =db$Ctrl.db$Distinct(collectionName1, "{Queue:{$nin:['QE#COMPLETED','QE#AUTHORIZE','QE#DLQ','QE#INIT','QE#APPROVE','QE#CONVERT','QE#OPEN',"
					+ "'QE#ASSIGN','QE#REFAPPROVE','QE#HOLD','QE#WIP','QE#REFAUTHORIZE','QE#REFRISK']}})",feildName);

		     for(int i=0;i<runAllQueue.size();i++)
		     {
					String i$runningStr = runAllQueue.get(i).getAsString();
					
					getAllQueue(i$runningStr);
		     }
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, i$ResM.I_CUSMEM + " Data Updated ");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEMCAPS + " Data Update failed with: " + e.getMessage());
		}
		return isonMsg;
	}


	private void getAllQueue(String i$runningStr) {
		try
		{
		JsonObject argJson = new JsonObject();
		JsonObject ibody = new JsonObject();
		ibody.addProperty("QueueName", i$runningStr);
		ibody.addProperty("queryId", "QAGEING");
		argJson.add("i-body",ibody);

		IQueryExecutor query = new IQueryExecutor();
		JsonObject isonmsg=query.executeQuery(argJson);
		JsonObject istat=isonmsg.get("i-stat").getAsJsonObject();
		
		if(I$utils.$iStrFuzzyMatch(istat.get("i-statMsg").getAsString(), "i-SUCC"))
		{
			if(isonmsg.has("i-body"))
			{
				JsonArray i$body=isonmsg.get("i-body").getAsJsonArray();
				JsonObject ageWiseCount= i$body.get(0).getAsJsonObject();
				
				JsonArray  arrAgeCount=ageWiseCount.get("AGE_WISE_COUNT").getAsJsonArray();
				for(int i=0;i<ageWiseCount.size();i++)
				{
					JsonObject runnObject=arrAgeCount.get(i).getAsJsonObject();
					runnObject.addProperty("userId", ageWiseCount.get("_id").getAsString());
					if(queuAgeing(runnObject,argJson));
					{
						if(argJson.has("exccedsAll"))
						{
							expiredQueue(runnObject,i$runningStr);
						}
						else
						{
							SendNotification(runnObject,argJson);
						}
					}
					
				}
			}
		}
		
		System.out.println("");
	}catch(Exception e)
	{
		e.getMessage();
	}
 }

	private void expiredQueue(JsonObject runnObject,String i$runningStr) {
		try {

			JsonArray arrAppId = runnObject.get("applicationid").getAsJsonArray();

			for (int i = 0; i < arrAppId.size(); i++) {
				JsonObject ObjAppId = arrAppId.get(i).getAsJsonObject();
				JsonObject filter = new JsonObject();
				filter.addProperty("Queue", i$runningStr);
				filter.addProperty("applicationId", ObjAppId.get("applicationId").getAsString());

				JsonObject getQueue = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", filter);

				getQueue.add("UpdatedAt", i$ResM.adddate(new Date()));
				getQueue.add("ModifiedAt", i$ResM.adddate(new Date()));
				getQueue.addProperty("Queue", "QE#EXPRIRED");

				db$Ctrl.db$UpdateRow("ICOR_M_QUEUE_EXPIRED", getQueue, filter, "true");
			}

		} catch (Exception e) {
			e.getMessage();
		}
	}

	private boolean queuAgeing(JsonObject runnObject,JsonObject argJson) {
		try {
			
		
		int ageing=runnObject.get("AGE").getAsInt();
		
		JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
		JsonObject threshold = cParam.get("Threshold").getAsJsonObject();
		int threshold1=threshold.get("threshold1").getAsInt();
		int threshold2=threshold.get("threshold2").getAsInt();
		int threshold3=threshold.get("threshold3").getAsInt();
		int threshold4=threshold.get("threshold4").getAsInt();
		
		JsonObject to$emailIds = new JsonObject();
		JsonObject cc$emailIds = new JsonObject();

		
		if(ageing>=threshold1 && ageing<=threshold2)
		{	
			JsonObject ObjUsrprf=getMailId(runnObject.get("userId").getAsString());
			
			if (ObjUsrprf.has("EmpMail")) {
				to$emailIds.addProperty("toemailid1", ObjUsrprf.get("EmpMail").getAsString());
			}
			if (ObjUsrprf.has("supervisorEmail")) {
				cc$emailIds.addProperty("ccemailid1", ObjUsrprf.get("supervisorEmail").getAsString());
			}
			
			argJson.add("toemailIds", to$emailIds);
			argJson.add("ccemailIds", cc$emailIds);
	
			return true;
		}
		else if(ageing>threshold2 && ageing<=threshold3) 
		{
			JsonObject ObjUsrprf=getMailId(runnObject.get("userId").getAsString());
            JsonObject ObjUsrprfSuper= new JsonObject();
			if(ObjUsrprf.has("supervisorName"))
			{
			 ObjUsrprfSuper=getMailId(ObjUsrprf.get("supervisorName").getAsString());
			}

			if (ObjUsrprf.has("supervisorEmail")) {
				to$emailIds.addProperty("toemailid1", ObjUsrprf.get("supervisorEmail").getAsString());
			}
			if (ObjUsrprf.has("EmpMail")) {
				cc$emailIds.addProperty("ccemailid1", ObjUsrprf.get("EmpMail").getAsString());
			}
			if (ObjUsrprfSuper.has("supervisorEmail")) {
				cc$emailIds.addProperty("ccemailid2", ObjUsrprfSuper.get("supervisorEmail").getAsString());
			}
			argJson.add("toemailIds", to$emailIds);
			argJson.add("ccemailIds", cc$emailIds);

			return true;

		}
		else if(ageing>threshold3 && ageing<=threshold4)
		{   
			JsonObject ObjUsrprf=getMailId(runnObject.get("userId").getAsString());
			JsonObject ObjUsrprfSuper= new JsonObject();
			
			if(ObjUsrprf.has("supervisorName"))
			{
			 ObjUsrprfSuper=getMailId(ObjUsrprf.get("supervisorName").getAsString());
			}
			if (ObjUsrprf.has("EmpMail")) {
				to$emailIds.addProperty("toemailid1", ObjUsrprf.get("EmpMail").getAsString());
			}
			if (ObjUsrprf.has("supervisorEmail")) {
				to$emailIds.addProperty("toemailid2", ObjUsrprf.get("supervisorEmail").getAsString());
			}
			if (ObjUsrprfSuper.has("supervisorEmail")) {
				to$emailIds.addProperty("toemailid3", ObjUsrprfSuper.get("supervisorEmail").getAsString());
			}	
			argJson.add("toemailIds", to$emailIds);
			
			return true;

		}
		else if(ageing>threshold4)
		{
			argJson.addProperty("exccedsAll", true);
			return true;

		}
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
			
		}
		return false;
		
	}

	private void SendNotification(JsonObject runnObject,JsonObject argJson) {
		try {
			IEmailService i$Email = new IEmailService();

			JsonObject map$Data = new JsonObject();
            JsonArray arrAppId=runnObject.get("applicationid").getAsJsonArray();
            String strAppId="";
            for(int i=0;i<arrAppId.size();i++)
            {
            	JsonObject ObjAppId=arrAppId.get(i).getAsJsonObject();
            	strAppId=ObjAppId.get("applicationId").getAsString()+" "+strAppId;
            }
            map$Data.addProperty("applicationId", strAppId);
            map$Data.addProperty("QUEUE", runnObject.get("userId").getAsString());
            map$Data.addProperty("days", runnObject.get("AGE").getAsInt());
			map$Data.addProperty("tmp$name", "IMPACTO_QUEUE_AGEING");

			JsonObject projection = new JsonObject();
			projection.addProperty("iOtpCommMode", 1);
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendMailOtp").getAsString(), "Y")) {
				try {
					JsonObject argJsonPass = new JsonObject();
					
					argJsonPass.add("toemailIds", argJson.get("toemailIds").getAsJsonObject());
					if(argJson.has("ccemailIds"))
					{
					if(!argJson.get("ccemailIds").getAsJsonObject().isJsonNull());
					{
					argJsonPass.add("ccemailIds", argJson.get("ccemailIds").getAsJsonObject());
					}
					}
					argJsonPass.add("map$Data", map$Data);
					i$Email.sendEmail(argJsonPass);


				} catch (Exception e) {
					e.getMessage();
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public JsonObject getMailId(String userId) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			filter.addProperty("userId", userId);
			projection.addProperty("EmpMail", 1);
			projection.addProperty("supervisorEmail", 1);
			projection.addProperty("supervisorName", 1);
			JsonObject ObjUsrprf = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter, projection);

			return ObjUsrprf;
		} catch (Exception e) {

			e.getMessage();
			return null;

		}

	}
}
// #BHUVI001 Ends