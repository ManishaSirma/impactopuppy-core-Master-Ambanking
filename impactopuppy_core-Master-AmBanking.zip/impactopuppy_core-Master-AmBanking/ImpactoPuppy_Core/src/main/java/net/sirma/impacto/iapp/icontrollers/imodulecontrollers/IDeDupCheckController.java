/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 02, 2019 | #BVB00050   | Initial writing
      |0.2.1       | Vijay 		| Feb 12, 2019 | #BVB00056   | Added Query and Response format Changed for Scanning
      |0.2.1       | Vijay 		| Feb 12, 2019 | #BVB00087   | DeDup verdict added
      |0.2.1       | Vijay 		| Mar 11, 2019 | #BVB00089   | DeDup Issue for No hits
      |0.2.1       | Vijay 		| Mar 11, 2019 | #BVB00105   | Soundex Fixes when not applicable
      |0.4.1.366   | Syed 		| Aug 21, 2019 | #MAQ000029  | Fix for Blank values of filter
      |0.4.1.371   | Syed 		| Aug 31, 2019 | #MAQ000030  | Fix for Blank values of currField
      |0.4.1.371   | Samadhan   | mar 10, 2022 | #SRP00051   | Added code Update ScanId
      ----------------------------------------------------------------------------------------------
*/
// #BVB00050 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;

import org.apache.commons.codec.language.Soundex;

public class IDeDupCheckController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IDeDupCheckController.class);
	private ISdnScanWorker i$sdnScanWorker = new ISdnScanWorker();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			JsonObject i$body = new JsonObject();

			if (I$utils.$iStrFuzzyMatch(Scr, "OB2DEDUP") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = DeDupCheck(isonMsg);
				// #BVB00056 Starts
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OB2DEDUP") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				isonMsg = DeDupeQuery(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
			// #BVB00056 Ends
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject DeDupCheck(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		String searchCollectionName = "";
		JsonArray deDupCheckFields = new JsonArray();
		String filterS = "";
		String compareWith = "";
		String compare = "";
		String compareWithAc = "";
		String compareAc = "";
		double score = 0.0;
		JsonArray i$res = new JsonArray();
		JsonObject i$body = new JsonObject();
		JsonArray i$finalRes = new JsonArray();
		Gson gson = new Gson();
		String referenceNo = "";
		String applicationId = "";
		try {
			i$body = i$ResM.getBody(isonMsg);
			JsonObject request = i$body.getAsJsonObject("request");
			String deDupCheckId = i$body.get("deDupCheckId").getAsString();
			referenceNo = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			applicationId = i$ResM.getBodyElementS(isonMsg, "applicationId");
			// Get data from ICOR_M_DEDUP_CHECK for the rule Id
			filter.addProperty("deDupCheckId", deDupCheckId);
			JsonObject icorMDedup = db$Ctrl.db$GetRow("ICOR_M_DEDUP_CHECK", filter);

			// Get the collection name, Mongo Rules from the Rule Data
			searchCollectionName = icorMDedup.get("collectionName").getAsString();
			deDupCheckFields = icorMDedup.getAsJsonArray("deDupCheckFields");
			
			JsonArray currValArr;
			for (int i = 0; i < deDupCheckFields.size(); i++) {
				JsonObject i$runningObj = deDupCheckFields.get(i).getAsJsonObject();
				// String type = i$runningObj.get("type").getAsString();
				JsonArray fields = i$runningObj.get("fields").getAsJsonArray();
				String soundexSearchReq = i$runningObj.get("soundexSearchReq").getAsString();
				String fieldsS = "";
				filterS = "";
				i$res = new JsonArray();
				currValArr = new JsonArray();
				for (int j = 0; j < fields.size(); j++) {
					String currField = fields.get(j).getAsString();
					// MAQ000030 starts
					String currVal = "";
					if(request.has(currField)) {
						currVal = request.get(currField).getAsString();
						if (!I$utils.$iStrBlank(currVal))
							currValArr.add(currVal);
					} else {
						logger.debug("Field value null for "+ fields.get(j).getAsString());
					}
					// MAQ000030 ends
					if (I$utils.$iStrFuzzyMatch(soundexSearchReq, "Y")) {
						if (I$utils.$iStrFuzzyMatch(filterS, "")) {
							filterS = "'" + "Soundex" + currField + "' : {$regex:'" + i$impactoUtil.getSoundex(currVal)
									+ "', $options: 'i' }";
						} else {
							filterS = filterS + ",'" + "Soundex" + currField + "' : {$regex:'"
									+ i$impactoUtil.getSoundex(currVal) + "', $options: 'i' }";
						}
					} else {
						if (I$utils.$iStrFuzzyMatch(filterS, "")) {
							filterS = "'" + currField + "' : {$regex:'" + currVal + "', $options: 'i' }";
						} else {
							filterS = filterS + ",'" + currField + "' : {$regex:'" + currVal + "', $options: 'i' }";
						}
					}
					fieldsS = currField + '~' + fieldsS;
				}

				filterS = "{" + filterS + "}";
				if(currValArr.size() > 0) {
					// MAQ000029 starts
					JsonObject db$Result = db$Ctrl.db$GetRows(searchCollectionName, filterS, 0, 100);
					JsonArray searchResults = db$Result.getAsJsonArray("i-body");
					// MAQ000029 ends
	
					if (searchResults.size() > 0) {
						for (int k = 0; k < searchResults.size(); k++) {
							JsonObject i$runningSearch = searchResults.get(k).getAsJsonObject();
							JsonObject i$runningRes = new JsonObject();
							compareWith = "";
							compare = "";
							compareWithAc = "";
							compareAc = "";
							// for (int l = 0; l < deDupCheckFields.size(); l++) {
	
							JsonObject i$runningDeDup = deDupCheckFields.get(i).getAsJsonObject();
							fields = i$runningDeDup.get("fields").getAsJsonArray();
							score = i$runningDeDup.get("matchScore").getAsDouble();
							for (int n = 0; n < fields.size(); n++) {
								String currField = fields.get(n).getAsString();
								// #BVB00105
								if (I$utils.$iStrFuzzyMatch(soundexSearchReq, "Y")) {
									compareWith = i$runningSearch.get("Soundex" + currField).getAsString() + '~'
											+ compareWith;
									compare = i$impactoUtil.getSoundex(request.get(currField).getAsString()) + '~'
											+ compare;
								} else {
									compareWith = i$runningSearch.get(currField).getAsString() + '~' + compareWith;
									compare = request.get(currField).getAsString() + '~' + compare;
								}
								compareWithAc = i$runningSearch.get(currField).getAsString() + '~' + compareWithAc;
								// #BVB00105 Ends
	
								compareAc = request.get(currField).getAsString() + '~' + compareAc;
							}
							double fuzzyScore = i$impactoUtil.fuzzySearch(compareWith, compare);
							// Get ColorCode
	
							if (fuzzyScore * 100 >= score) {
								i$runningRes.addProperty("score", fuzzyScore * 100);
								i$runningRes.addProperty("color", fuzzyScore * 100);
								i$runningRes.addProperty("compareWith", compareWithAc);
								i$runningRes.addProperty("compare", compareAc);
								i$res.add(i$runningRes);
							}
						}	
					}
				}
				JsonObject temp = new JsonObject();
				temp.addProperty("elements", fieldsS);
				temp.add("results", i$res);
				i$finalRes.add(temp);
				

			}
			// #BVB00087 Starts
			// Have to create DeDupe Verdict
			JsonObject deDupVerdict = new JsonObject();
			String deDupHitElements = "";
			double dedDupscore = 0.0;
			int noOfHits = 0;
			// #BVB00087 Ends
			for (int i = 0; i < i$finalRes.size(); i++) {
				JsonObject i$runningObj = i$finalRes.get(i).getAsJsonObject();
				JsonArray results = i$runningObj.getAsJsonArray("results");
				if (results.size() > 0) {
					if (I$utils.$iStrFuzzyMatch(deDupHitElements, "")) {
						deDupHitElements = i$runningObj.get("elements").getAsString();
					} else {
						deDupHitElements = deDupHitElements + ", " + i$runningObj.get("elements").getAsString();
					}

					// Get the avg of the scores

					for (int j = 0; j < results.size(); j++) {
						JsonObject i$runningRes = results.get(j).getAsJsonObject();
						dedDupscore = dedDupscore + i$runningRes.get("score").getAsDouble();
						noOfHits++;
					}

				}

			}
			// #BVB00087 Starts
			// #BVB00089 Starts
			// dedDupscore = dedDupscore/noOfHits ;
			try {
				if (noOfHits > 0) {
					dedDupscore = dedDupscore / noOfHits;
				} else {
					dedDupscore = 0;
				}
			} catch (Exception e) {
				dedDupscore = 0;
			}
			// #BVB00089 Ends
			deDupVerdict.addProperty("deDupHitElements", deDupHitElements);
			deDupVerdict.addProperty("dedDupscore", dedDupscore);
			String scoreClass = i$sdnScanWorker.scoreClass("DEDUP", dedDupscore * 100);
			deDupVerdict.addProperty("dedDupScoreClass", scoreClass);
			deDupVerdict.addProperty("dedDupColor", i$sdnScanWorker.colorCode(scoreClass));
			// #BVB00087 Ends
			JsonObject i$resF = new JsonObject();
			i$resF.addProperty("referenceNo", referenceNo);
			i$resF.addProperty("applicationId", applicationId);
			// #BVB00056 Starts
			i$resF.addProperty("ScanType", "DEDUPE");
			i$resF.addProperty("ScanId", i$impactoUtil.generateRandomKey());
			// #BVB00056 Ends
			i$resF.add("DeDupResults", i$finalRes);
			i$resF.add("DeDupVerdict", deDupVerdict); // #BVB00087
			filter = new JsonObject();//#SRP00051 Start
			filter.addProperty("applicationId", applicationId);
			filter.addProperty("referenceNo", referenceNo);
			db$Ctrl.db$UpdateRow("ICOR_M_DEDUP_SCAN", i$resF,filter,"true");//#SRP00051 End

			// #BVB00056 Starts
			// Removing the variables from Response
			i$resF.remove("referenceNo");
			i$resF.remove("applicationId");
			i$resF.remove("DeDupResults");
			i$resF.remove("DeDupVerdict"); // #BVB00087
			// #BVB00056 Ends
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resF);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "De Dup Check Sucessful");

		} catch (

		Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "De Dup Check Failed");
		}

		return isonMsg;
	}

	// #BVB00056 Starts
	public JsonObject DeDupeQuery(JsonObject isonMsg) {
		JsonObject icorMDeDup = new JsonObject();
		JsonObject filter = new JsonObject();
		try {

			String ScanId = i$ResM.getBodyElementS(isonMsg, "ScanId");
			filter.addProperty("ScanId", ScanId);

			icorMDeDup = db$Ctrl.db$GetRow("ICOR_M_DEDUP_SCAN", filter);
			if (!I$utils.$isNull(icorMDeDup)) {
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorMDeDup);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Sucessfully Retrieved");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_WARNING, "NO RECORDS FOUND");
			}
		} catch (Exception e) {
			logger.debug("Failed in Dedup Query with: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE DATA");
		}

		return isonMsg;

	}

	// #BVB00056 Ends
	public IDeDupCheckController() {
		// Cons
	}
}
// #BVB00050 Ends
