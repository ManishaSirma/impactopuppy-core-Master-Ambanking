/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ---------------------------------------------------------------------------------------------- 
           |0.4 Beta    | Sindhu     | Nov 25, 2022 | #SRM0011    | 
		   |0.5 Beta    | karthik    | Aug 17, 2023 | #NK00002    | Added code for adding the folderId to favorites collection
		   |0.5 Beta    | Sumit      | Aug 29, 2023 | #SKG00027   |  Added code for  FAVOURITE & UNFAVOURITE history
		   |0.5 Beta    | karthik    | sep 06, 2023 | #NK00013    | added code for password protection for un-favorite
		   |0.5 Beta    | karthik    | Sep 12, 2023 | #NK00014    | made the common request for password protection and unfavorites
		   |0.5 Beta    | Sumit      | Oct 12, 2023 | #SKG00033   |  Added code for  Data Set Filter in Favorite module 
		   |0.5 Beta    | karthik    | Nov 20, 2023 | #NK00065    | Added code for amending the favorites and unfavorites records
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
//import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.iEmailService;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IDmsFavouritesController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IWorkspacesController.class);
//	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
//	private IgenericWorker igenericWorker = new IgenericWorker();
	private JsonObject i$Annotate = null;
//	private ISeqConsistencyController i$seqConsCtrl = new ISeqConsistencyController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		i$body = isonMsg.getAsJsonObject("i-body");
		String Coll_Name, L_Coll_Name;

		Gson gson = new GsonBuilder().serializeNulls().create();
		JsonObject projection = new JsonObject();

		JsonObject i$Match = i$ResM.getMatch(isonMsg);
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();
		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
				
		try {
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY"))
			{
				
				JsonObject j$DataFilter = get$FrmDataSetFilter(isonMsg);
				if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr")))
				{

					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,j$DataFilter.get("Invalid$Expr").getAsString() );
					return isonMsg;
				}
				else if (j$DataFilter != null)
				{
					i$Match = j$DataFilter;
				}
			}
			
			try {
				if (hasRights) {
					if (i$Match == null) {
						JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
						i$Match = new JsonObject();
						try {
							if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
									&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") 
							)) {
								for (int i = 0; i < i$MatchMap.size(); i++) {
									 JsonElement matchElm = i$ResM.getBodyElement(isonMsg,i$MatchMap.get(i).getAsString());
									 if(!I$utils.$isNull(matchElm) ) { 
									 if(matchElm.isJsonPrimitive()) {
										 i$Match.addProperty(i$MatchMap.get(i).getAsString(),
											i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
									 }else if(matchElm.isJsonArray()) { 
										 JsonArray matchArr = matchElm.getAsJsonArray();
										 String iMatchStr = "{'$in': ['"; 
										 for(int j =0; j< matchArr.size(); j++) {
											 if(j<matchArr.size()-1)
											 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"','"; 
											 else {
												 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"']}";
											 }
										 }
										 
										 i$Match.add(i$MatchMap.get(i).getAsString(), parser.parse(iMatchStr).getAsJsonObject()); 
										 
									 }
									 }else {
										 isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
											return isonMsg;
									 }
								}
								;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
							} else {
								i$Match = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
							}
						} catch (Exception e) {
							logger.error("Error description : ", e);
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
						}
						;
					}
					;
					if (i$ProjectionArray != null) {
						for (int i = 0; i < i$ProjectionArray.size(); i++) {
							i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
						}
					} else {
						JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
						if (i$ProjectionMap != null) {
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
									for (int i = 0; i < i$ProjectionMap.size(); i++) {
										i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
									}
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
								} else {
									i$Projection = null;
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
								}
							} catch (Exception e) {
								e.printStackTrace();
								i$Projection = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
							}
							;
						} else {
							i$Projection = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
						}
					}
					projection = new JsonObject();
					projection.addProperty("privateKey", 1);
					JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
					String privateKey = cParam.get("privateKey").getAsString();
					JsonObject sfilter = new JsonObject();
					sfilter.addProperty("sessoinId", i$ResM.getClientSessionID(isonMsg));
					JsonObject sessionValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", gson.toJson(sfilter),
							gson.toJson(projection));
					Integer i$MaxRow = -1;
					JsonObject i$recordDetails = new JsonObject();
					JsonObject i$validateRes = new JsonObject();
					JsonObject i$ledgerCurVer = new JsonObject();
					try {
						i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
					} catch (Exception e) {
						try {
							i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
						} catch (Exception ex) {
							i$MaxRow = -1;
						}
						;
					}
					;
					try {
						Coll_Name = isonMapJson.get("COLLNAME").getAsString();
					} catch (Exception e) {
						Coll_Name = null;
					}
					;
					if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
							|| (I$utils.$iStrBlank(gson.toJson(i$Match)))) { 
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
						return isonMsg;
					}
					;
					try {
						L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
					} catch (Exception e) {
						L_Coll_Name = null;
					}
					;
					if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
						return isonMsg;
					}
					;
					try {
						String SOpr1 = i$ResM.getOpr1(isonMsg);
						String SOpr2 = i$ResM.getOpr2(isonMsg);
						String SOpr3 = i$ResM.getOpr3(isonMsg);
						try {
							i$body = isonMsg.getAsJsonObject("i-body");
						} catch (Exception e) {
							i$body = null;
						}
					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}");
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) { 
							// Forwarding Request to DB Handler for SUMMARY
							logger.debug("Forwarding Request to DB Controller for Summary");
							isonMsg.add("i-body", i$body);
							int intPgNo, intRecs;
							try {
								intPgNo = i$body.get("intPgNo").getAsInt();
							} catch (Exception e) {
								intPgNo = 0;
							}
							try {
								intRecs = i$body.get("intRecs").getAsInt();
							} catch (Exception e) {
								intRecs = 0;
							}
							String sort = "";
							try {
								String sortField = i$body.get("sort").getAsString();
								sort = "{'"+sortField+"':1}";
							} catch (Exception e) {
								sort = "{'_id':-1}";
							}
							if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {
								int iRowCnt = 0;
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
								try {
									if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
										if (i$Match != null) {
											i$Match.addProperty("isCurrVer", "Y");
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); 
										}
										else
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, "{\"isCurrVer\"=\"Y\"}");
									} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
											|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
										if (i$Match != null)
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));
										else
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
									}
								} catch (Exception e) {
								}
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

								i$body.addProperty("iRowCnt", iRowCnt);
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
								return isonMsg;
							} else if(I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
								int iRowCnt = 0;
								JsonObject db$res = null;
								JsonArray db$res1 = null;
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
								try {
									if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
										JsonArray accWsArr = db$Ctrl.db$getDMSAccessWS();   
										if (i$Match != null) {
											i$Match.addProperty("isCurrVer", "Y");
											i$Match.addProperty("Favourites", "Y");
//											i$Match.add("metadata.workspaceId",parser.parse("{'$in':" + accWsArr + "}").getAsJsonObject());//SKG00032 changes
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match));
											 db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
													 i$Projection, intPgNo, intRecs, sort);								
										}
										else {
											i$Match = new JsonObject();
											i$Match.addProperty("isCurrVer", "Y");
											i$Match.addProperty("Favourites", "Y");
											iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match));
											db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
													i$Projection, intPgNo, intRecs, sort);
										}
									}  else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
										if (i$Match != null) {
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));
											db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
													intPgNo, intRecs, sort);											
										}
										else {
											iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
											db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
													i$Projection, intPgNo, intRecs, sort);
											
										}
									}
								} catch (Exception e) {
								}
								
								i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
								i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());	
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

								i$body.addProperty("iRowCnt", iRowCnt);
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
								return isonMsg;
							}
							else {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort));
									}
									else {
										i$Match = new JsonObject();
										i$Match.addProperty("isCurrVer", "Y");
										return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort));
									}
								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null)
										return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
												intPgNo, intRecs, sort));
									else
										return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
												i$Projection, intPgNo, intRecs, sort));
								} else {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
									return isonMsg;
								}
							}
						     }else {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
							return isonMsg;
						}
						;	
						I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrId, SOpr);
						if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
							if (I$utils.$iStrFuzzyMatch(ScrId, "ODSFAVRT") && I$utils.$iStrFuzzyMatch(SOpr, "FAVOURITE")) {
								try {
									JsonArray flData = new JsonArray();
									JsonObject filter = new JsonObject();
									JsonObject fldrUpdate = new JsonObject();
									JsonObject data = new JsonObject();
									JsonObject fsUpdate = new JsonObject();
									JsonObject fldrArr1 = new JsonObject();
									JsonObject docFilter = new JsonObject();
									JsonObject proj = new JsonObject();
									JsonObject doc = new JsonObject();
									i$body = isonMsg.getAsJsonObject("i-body");
                                    JsonArray fileList = i$body.get("FileUrlToken").getAsJsonArray();
                                    for(int i = 0; i < fileList.size(); i++) {
                                    	String currToken = fileList.get(i).getAsString();
                                    	if(i$body.has("fileKey")) {
                                    		if (!db$Ctrl.db$DocPassVerify(isonMsg)) {
                								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");//#TKS00015 changes
                								return isonMsg;
                							}
                                    	}
                                    	filter.addProperty("metadata.FileUrlToken", currToken);
                                    	docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'"+ currToken + "'}}").getAsJsonObject());
                                		proj.addProperty("documents.$", 1);
                                		proj.addProperty("_id", 0);
                                		JsonObject i$Data = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", docFilter,proj);
                                		data = i$Data.get("documents").getAsJsonArray().get(0).getAsJsonObject();
                                		// NK00065 starts
                                		if(!I$utils.$iStrFuzzyMatch(data.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
    										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Only initiator can Add the record to Favourite");
    										 return isonMsg;
    									} // NK00065 ends
                                		data.addProperty("Favourites","Y");
                            			data.addProperty("likedBy" , IResManipulator.iloggedUser.get());
                            			doc.add("documents.$", data);
                            			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", gson.toJson(doc), docFilter, "false","N");
                            			data.addProperty("isCurrVer", "Y");
                            			data.addProperty("folderId", i$body.get("folderId").getAsString()); //#NK00002 
                            			db$Ctrl.db$InsertRow("ICOR_M_DMS_FAVOURITE" , data);
										fsUpdate.addProperty("metadata.Favourites" , "Y");
										db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , filter);
                                    }
                                    isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Documents Successfully Added to Favorites");
                                    db$Ctrl.db$logDmsHstry(isonMsg);//SKG00027 changes
									return isonMsg;
								} catch (Exception e) {
									e.printStackTrace();
								}
							}else if(I$utils.$iStrFuzzyMatch(ScrId, "ODSFAVRT") && I$utils.$iStrFuzzyMatch(SOpr, "UNFAVOURITE")) {
								try {
									JsonArray flData = new JsonArray();
									JsonObject filter = new JsonObject();
									JsonObject docUpdate = new JsonObject();
									JsonObject docFltr = new JsonObject();
									JsonObject data = new JsonObject();
									JsonObject fsUpdate = new JsonObject();
									JsonObject fldrArr1 = new JsonObject();
									JsonObject docFilter = new JsonObject();
									JsonObject proj = new JsonObject();
									JsonObject doc = new JsonObject();
									i$body = isonMsg.getAsJsonObject("i-body");
                                    JsonArray fileList = i$body.get("FileUrlToken").getAsJsonArray();
                                    for(int i = 0; i < fileList.size(); i++) {
                                    	String currToken = fileList.get(i).getAsString();
                                    	filter.addProperty("metadata.FileUrlToken", currToken);
                                    	if(i$body.has("fileKey")) {
                                    		if (!db$Ctrl.db$DocPassVerify(isonMsg)) {
                								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Incorrect File Password");//#TKS00015 changes
                								return isonMsg;
                							}
//                                    		else {#NK00014 changes
//                								i$body.addProperty("key", true);
//                				            	return isonMsg; // #NK00013 changes
//                							}
                                    	}
                                    	docFilter.add("documents",parser.parse("{'$elemMatch': {'sides.FileUrlToken':'"+ currToken + "'}}").getAsJsonObject());
                                		proj.addProperty("documents.$", 1);
                                		proj.addProperty("_id", 0);
                                		JsonObject i$Data = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", docFilter,proj);
                                		data = i$Data.get("documents").getAsJsonArray().get(0).getAsJsonObject();
                                		// NK00065 starts
                                		if(!I$utils.$iStrFuzzyMatch(data.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
    										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Only initiator can unfavourite the record");
    										 return isonMsg;
    									} // NK00065 ends
                            			data.addProperty("Favourites","N");
                            			doc.add("documents.$", data);
                            			db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_FOLDERS", gson.toJson(doc), docFilter, "false","N");
                            			docFltr.addProperty("FileUrlToken" , currToken);
                            			docUpdate.addProperty("Favourites", "N");
                            			db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE" , docUpdate , docFltr);
										fsUpdate.addProperty("metadata.Favourites" , "N");
										db$Ctrl.db$UpdateRow("fs.files" , fsUpdate , filter);
                                    }
                                    isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Documents Successfully Removed from Favorites");
                                    db$Ctrl.db$logDmsHstry(isonMsg);//SKG00027 changes
									return isonMsg;
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							
						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
							return isonMsg;
						}
					} catch (Exception e) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
								e.getMessage().toString());
						e.printStackTrace();
						return isonMsg;
					}
				} else {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
					return isonMsg;
				}
			} catch (Exception excep) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
						excep.getMessage().toString());
				excep.printStackTrace();
				return isonMsg;
			}
		}
		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
			try {
			IDmsFavouritesController i$genAppCon = new IDmsFavouritesController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			isonMsg = i$genAppCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg) {
		try {
			return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));
		} catch (Exception e) {
			logger.debug(" Error in get$FrmDataSetFilter -" + e.getMessage());
			return null;
		}
	}
	public IDmsFavouritesController() {			
	}
}
