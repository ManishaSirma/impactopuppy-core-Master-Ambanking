/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Oct 2, 2018  | #BVB00005   | Initial writing
      |0.1 Beta    | Vijay 		| Dec 1, 2018  | #BVB00018   | Commented else caluse as that validation is not required anymore. 
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins

package net.sirma.impacto.iapp.iworkers.iappworkers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICycleWorker {

	private Logger logger = LoggerFactory.getLogger(ICycleWorker.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();

	// Generic Validator
	public JsonObject validateRequest(String SOpr, String SOpr1, String SOpr2, JsonObject isonMsgIn) {
		Gson gson = new Gson();
		String errorMsg = "";
		JsonObject isonMsg = isonMsgIn.deepCopy();
		Boolean validation = true;
		try {
			logger.debug("SOpr" + SOpr);

			// No of Curr Ver Records validations
			if (isonMsg.getAsJsonArray("i$ledgerCurrVer").size() != 1 && !SOpr.equalsIgnoreCase("CREATE")) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Check Curr version records");
				validation = false;
			}

			if (validation) {
				if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(SOpr1, "ICYCLEMAPPING")
						&& I$utils.$iStrFuzzyMatch(SOpr2, "CREATE")) {
					if (!I$utils.$iStrFuzzyMatch(gson.toJson(isonMsg.get("i$master")), "{}")
							|| isonMsg.getAsJsonArray("i$Ledger").size() > 0) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Already
						// Exists");
						errorMsg = errorMsg + "Record Already Exists";
					}
					;

					// Need to add more validations for other steppers

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE") && I$utils.$iStrFuzzyMatch(SOpr1, "")
						&& I$utils.$iStrFuzzyMatch(SOpr2, "")) {
					if (isonMsg.getAsJsonArray("i$ledgerUnAuth").size() > 0
							&& !I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0)
									.getAsJsonObject().get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Un-Authorized
						// Records Exists");
						// errorMsg = errorMsg + "Un-Authorized Records Exists";

						errorMsg = errorMsg + "Only the Initiator can Amend the record";
					}
					;

					if (!I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("recordStat").getAsString(), "O")) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Closed Record
						// cannot be Updated");
						errorMsg = errorMsg + "Closed Record cannot be Updated";
					}

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
					if (!I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("authStat").getAsString(), "U")) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Un-Auth
						// records exists");
						errorMsg = errorMsg + "No Un-Auth records exists";
					}
					;
					if (!I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Only Initiator
						// can Delete the record");
						errorMsg = errorMsg + "Only Initiator can Delete the record";
					}
					;

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {
					if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("authStat").getAsString(), "U")) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Un-Auth records
						// exists");
						errorMsg = errorMsg + "Un-Auth records exists";
					}
					;

					if (!I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("recordStat").getAsString(), "O")) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Not is
						// Closed State");
						errorMsg = errorMsg + "Record Not is Closed State";
					}

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
					if (I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("initiator").getAsString(), IResManipulator.iloggedUser.get())) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Initiator and
						// Authorizer are same");
						errorMsg = errorMsg + "Initiator and Authorizer are same";
					}
					;
					if (!I$utils.$iStrFuzzyMatch(isonMsg.getAsJsonArray("i$ledgerCurrVer").get(0).getAsJsonObject()
							.get("authStat").getAsString(), "U")) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Un-Auth
						// records exists");
						errorMsg = errorMsg + "No Un-Auth records exists";
					}
					;

				} else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") || I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ")
						|| I$utils.$iStrFuzzyMatch(SOpr, "RELEASELOCK")) {
					if ((I$utils.$iStrFuzzyMatch(gson.toJson(isonMsg.get("i$master")), "{}"))
							&& (I$utils.$iStrFuzzyMatch(gson.toJson(isonMsg.get("i$ledger")), "{}"))) {
						// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Record Doenot
						// Exists");
						errorMsg = errorMsg + "Record Doesnot Exists";
					}
					;
				}
				// #BVB00018 Starts
				/*
				 * else { errorMsg = errorMsg + "Invalid Operation"; }
				 */
				// #BVB00018 Ends

			}

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsg, "i$master");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsg, "i$Ledger");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsg, "i$ledgerCurrVer");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsg, "i$ledgerUnAuth");
			if (I$utils.$iStrFuzzyMatch(errorMsg, "")) {
				isonMsg.addProperty("i-stat", "1");
				isonMsg.addProperty("i-Msg", "ALL GOOD");
			} else {
				isonMsg.addProperty("i-stat", "0");
				isonMsg.addProperty("i-Msg", errorMsg);

			}
			logger.debug("isonMsg: " + isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg.addProperty("i-stat", "0");
			isonMsg.addProperty("i-Msg", e.getMessage());
		}

		return isonMsg;
	};

	public ICycleWorker() {
			// Constructor
	}

}