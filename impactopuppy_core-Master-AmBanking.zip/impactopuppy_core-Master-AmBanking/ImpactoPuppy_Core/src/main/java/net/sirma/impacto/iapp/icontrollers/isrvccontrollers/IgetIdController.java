/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Valla 		| Jan 15, 2019 | #00000001   | Initial writing
      |----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class IgetIdController {

	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil $$imputils = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IgetIdController.class); // Nye- Change Class Name
																							// always
	// **********************************************************************//

	@SuppressWarnings("unused")
	private IDataValidator I$DataValidator = new IDataValidator();
	@SuppressWarnings("unused")
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	@SuppressWarnings("unused")
	private IgenericWorker igenericWorker = new IgenericWorker();

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
            logger.info("Get Id Service Started");
			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();

			String SvrOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			String ScrId = i$ResM.getScreenID(isonMsg);
			String SiteKey = i$ResM.getSiteKey(isonMsg);
			String ScrOpr = i$ResM.getOpr(isonMsg);

			if (I$utils.$iStrFuzzyMatch(ScrId, "XIDGETID") && I$utils.$iStrFuzzyMatch(ScrOpr, "CREATE")) {
				return getMId(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(ScrId, "XIDVRYID") && I$utils.$iStrFuzzyMatch(ScrOpr, "CREATE")) {
				return vryMId(isonMsg);
			} else
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
	};

	private JsonObject getMId(JsonObject isonMsg) {

		JsonObject i$body = null;
		i$body = isonMsg.getAsJsonObject("i-body");

		try {
			// Forwarding Request to DBController for Registration

			// 1 . Decrypt the Key
			String iKey = null;
			String iMei = i$ResM.getIME(isonMsg);

			// Read the Key from Session key from ICOR_S_SESSION_VALIDATOR
			String SessionId = i$ResM.getClientSessionID(isonMsg);
			JsonObject SesValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR",
					"{\"sessionId\":\"" + SessionId + "\"}");
			if (SesValidator != null) {
				iKey = $$imputils.decrypt(i$body.get("iKey").getAsString(),
						SesValidator.get("sessionKeyVal").getAsString());

			} else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID SESSION ID");
			}

			// 2. Chekc if Key exists
			JsonObject Ecom$Repo = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
					"{ \"Key\":\"" + iKey + "\", \"IMei\":\"" + iMei + "\" }");
			if (!(iKey != null) || !(Ecom$Repo != null)) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "TYPE ERROR");
			} else {
				// Retreive the ID based on the Mode
				String key_Owner = $$imputils.encrypt(Ecom$Repo.get("key_Owner").getAsString(),
						SesValidator.get("sessionKeyVal").getAsString());
				JsonObject i$resBody = new JsonObject();
				i$resBody.addProperty("key_Owner", key_Owner);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Data Retreived Successfuly.");
				return i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$resBody);

			}

		} // End of try
		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	};

	private JsonObject vryMId(JsonObject isonMsg) {

		JsonObject i$body = null;
		i$body = isonMsg.getAsJsonObject("i-body");

		try {

			// 1 . Decrypt the Key
			String iKey = null;
			String iMei = i$ResM.getIME(isonMsg);

			// Read the Key from Session key from ICOR_S_SESSION_VALIDATOR
			String SessionId = i$ResM.getClientSessionID(isonMsg);
			JsonObject SesValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR",
					"{\"sessionId\":\"" + SessionId + "\"}");
			
			iKey = $$imputils.decrypt(i$body.get("iKey").getAsString(), i$ResM.getGobalValStr("deCryptKey"));
			// 2. Chekc if Key exists
			String Key_Owner = null;
			JsonObject Ecom$Repo = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
					"{ \"Key\":\"" + iKey + "\", \"IMei\":\"" + iMei + "\" , \"Key_Owner\":\"" + Key_Owner + "\"}");
			if (!(iKey != null) || !(Ecom$Repo != null)) {
				return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "TYPE ERROR");
			} else {
				// Retreive the ID based on the Mode
				String key_Owner = $$imputils.encrypt(Ecom$Repo.get("Key_Owner").getAsString(),
						SesValidator.get("sessionKeyVal").getAsString());
				JsonObject i$resBody = new JsonObject();
				i$resBody.addProperty("key_Owner", key_Owner);
				i$resBody.addProperty("iKey", iKey);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Key Validated Successfuly.");

			}

		} // End of try
		catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}
	}

	public IgetIdController() {
		super();
		// TODO Auto-generated constructor stub
	};

}

//#00000001 Ends