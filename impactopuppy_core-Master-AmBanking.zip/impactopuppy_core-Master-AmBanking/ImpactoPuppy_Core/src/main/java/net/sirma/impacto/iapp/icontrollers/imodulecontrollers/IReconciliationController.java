/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 02, 2019 | #BVB00050   | Initial writing
      |0.2.2       | Baz 		| Feb 03, 2019 | #Va000026   | Workflow Related changes and cleaning of unused imports
      |0.2.2       | Baz 		| Mar 23, 2019 | #Va000027   | ReferDc Application Functionalities
      |0.2.2       | Baz 		| Apr 25, 2019 | #Va000028   | Date Format Change 
      |0.2.2       | Baz 		| May 15, 2019 | #Va000029   | Date Format Change
      |0.2.3       | Devraj 	| Feb 19, 2021 | #DVJ00032   | Fixed application display issue from TECU
      |0.2.3	   | Manikanta  | May 25, 2022 | #MVT00057   | Added code for risk profiling of existing customer 
      |0.2.3	   | Manikanta  | Sep 13, 2022 | #MVT00075	 | Added code For Risk scanning Of single existing customer
      |0.2.3       | Sindhu R   | Nov 12, 2022 | #SRM00008   | Added code for storing signature in the db
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.itextpdf.text.Image;
import com.spire.ms.System.DateTime;

import ch.qos.logback.core.net.SyslogOutputStream;
import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IRKYCController.imbpmFwdThread;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IReconciliationController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil Im$utils = new ImpactoUtil();
	private IExtWSLauncher i$EWslancher = new IExtWSLauncher();
	private IWebSearchController i$webSrvc = new IWebSearchController();
	private IModelEvaluationController risc= new IModelEvaluationController();
	private static final Logger logger = LoggerFactory.getLogger(IReconciliationController.class);
	private IAppMessageHandler iAppMsgHandler = new IAppMessageHandler();
	private IFuncSrvcController srvcFunction = new IFuncSrvcController();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	JsonObject thread$isonMsg = new JsonObject();
	JsonObject thread$isonheader = new JsonObject();
	JsonObject thread$isonMapJson = new JsonObject();
	JsonObject ibody = new JsonObject();
	JsonObject icbsbody = new JsonObject();
	String rCollName = null;
	String userid = null;

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String srvName = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && I$utils.$iStrFuzzyMatch(Scr, "ORCRECON") ) {	//#MVT00075 changes starts
				userid = IResManipulator.iloggedUser.get();
				thread$isonMsg = isonMsg;
				thread$isonheader = isonheader;
				thread$isonMapJson = isonMapJson;
				return createKYCApln(isonMsg, isonheader, isonMapJson);
			}else if(I$utils.$iStrFuzzyMatch(Scr, "ORCRECON") && I$utils.$iStrFuzzyMatch(SOpr, "LOADFLEXCUBE")) {
				return reconciliationLoadFlexcube(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(Scr, "ORCRECON") && I$utils.$iStrFuzzyMatch(SOpr, "LOADPDF")) {
				return reconciliationLoadPdf(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(SOpr, "COMPARISON") && I$utils.$iStrFuzzyMatch(Scr, "ORCRECON")) {
				return reconciliationCompare(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(SOpr, "OUTPUT") && I$utils.$iStrFuzzyMatch(Scr, "ORCRECON")) {
				return reconciliationIndividualCompare(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(SOpr, "UPDATE") && I$utils.$iStrFuzzyMatch(Scr, "ORCRECON")) {
				return reconciliationUpdate(isonMsg);
			}
			else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;	//#MVT00075 changes ends
	}

	public JsonObject createKYCApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String ScrCtrlClass = null;
		String sAppNumber = null;
		jBody = i$ResM.getBody(isonMsg);
		// remove the _id from the body if it exist
		try {
			jBody.remove("_id");
		} catch (Exception e) {
			// pass
		}

		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;
			// #Va000026 Begins
			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "reconciliationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			ZonedDateTime now = ZonedDateTime.now();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
					i$ResM.adddate(Date.from(now.toInstant())).getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());

			JsonObject subqry = new JsonObject();
			subqry.addProperty("$ne", sRef);
			jFilter.add("referenceNo", subqry.getAsJsonObject());
			jFilter.addProperty("applicationId", sAppNumber);
			// String ftr$qry = "{\"applicationId\":\""+sAppNumber+"\",\"referenceNo\":{$ne:
			// \""+sRef+"\"}}";

			JsonObject $update = new JsonObject();
			$update.addProperty("isCurrVer", "N");
			db$Ctrl.db$UpdateRow(Coll_Name, $update, jFilter);
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", $update, jFilter);

			// WOrkflow Status
			jFilter = new JsonObject();
			jFilter.addProperty("applicationId", sAppNumber);
			jFilter.addProperty("referenceNo", sRef);
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);

			if (!(Appl$Json != null)) {
				jBody.addProperty("isCurrVer", "Y");
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}

			jBody.addProperty("referenceNo", sRef);
			JsonObject Jbdy = new JsonObject();
			// trigger Workflow
			if (I$utils.$iStrFuzzyMatch(DcStatus, "COMPLETED")) {
				// #BZ00002 change begins

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", IResManipulator.iloggedUser.get());	// #DVJ00032
				JsonObject date$convert = new JsonObject();
				if (jBody.has("personalInfo")) {
					date$convert = jBody.get("personalInfo").getAsJsonObject();
				}

				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("priDocDOI").getAsString());
					date$convert.add("priDocDOI_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;

				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("priDocDOE").getAsString());
					date$convert.add("priDocDOE_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("secDocDOI").getAsString());
					date$convert.add("secDocDOI_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("secDocDOE").getAsString());
					date$convert.add("secDocDOE_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}

				jFilter.addProperty("applicationId", sAppNumber);
				jFilter.addProperty("referenceNo", sRef);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
				int noOfDocs = 2; 
				
				try {
					noOfDocs = jBody.getAsJsonObject("documents").get("numberOfDocUploaded").getAsInt(); 
				}catch (Exception e) {
					noOfDocs = 2; 
				}
				
				
				if (noOfDocs > 1
						|| !iAppMsgHandler.checkAdd$Msg("12121218")) {
					ExecutorService executor = Executors.newFixedThreadPool(1);// creating a pool of threads
					for (int i = 0; i < 1; i++) {
						Runnable worker = new imbpmFwdThread(isonMsg, isonheader, isonMapJson);
						executor.execute(worker);// calling execute method of ExecutorService
					}
//				executor.shutdown();
//				while (!executor.isTerminated()) {
//				}

					logger.debug("Finished all threads");

					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				} else {
					iAppMsgHandler.add$Msg("12121218", new JsonArray());
					
				}
				// #BZ00002 Ends

			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");

		}

	}
	
	public JsonObject reconciliationUpdate(JsonObject isonMsg) {
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			String applicationId = i$body.get("applicationId").getAsString();
			JsonObject filter = new JsonObject();
			JsonArray entries = new JsonArray();
			entries = i$body.get("entries").getAsJsonArray();
			filter.addProperty("applicationId", applicationId);
			filter.addProperty("isCurrVer", "Y");
			String i$Doc = "{'individualDifference': {'$each':" + entries + "}}";
			db$Ctrl.db$UpdateRowOperator("ICOR_M_RC_RECONCILIATION", i$Doc, filter, "false","push");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Updated");
		}catch(Exception e) {
			
		}
		return isonMsg;
	}
	
	public JsonObject reconciliationLoadPdf(JsonObject isonMsg) {
		try {
			JsonObject i$body = new JsonObject();
			JsonObject query = new JsonObject();
			JsonArray tableContent = new JsonArray();
			JsonArray filterArray = new JsonArray();
			i$body = i$ResM.getBody(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String date = "";
			if(!i$body.has("finYear"))
				date = i$body.get("fromDate").getAsString();
			String day = "";
			String month = "";
			String year = "";
			String pdfId = i$body.get("pdfId").getAsString();
			query.addProperty("pdfTableId", pdfId);
			JsonObject pdfData =  db$Ctrl.db$GetRow("ICOR_M_PDF_TABLE_DATA", query);
			tableContent = pdfData.get("tableContent").getAsJsonArray();
			if(i$body.has("finYear") && i$body.get("finYear").getAsBoolean()) {
				year = i$body.get("year").getAsString().substring(2 , 6);
				for(int i = 0 ; i < tableContent.size() ; i++) {
					JsonObject runningObject = tableContent.get(i).getAsJsonObject();
					String tableDate = runningObject.get("DATE").getAsString();
					String pdfDate = "";
					try {
						DateTime Date = DateTime.parse(tableDate);
						pdfDate = Date.toString("yyyy-MM-dd");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					if (pdfDate.contains(year + "-"))
						filterArray.add(runningObject);
				}
			}else if(i$body.has("periodCode") && i$body.get("periodCode").getAsBoolean()) {
				if(i$body.has("fullPeriodCode") && i$body.get("fullPeriodCode").getAsBoolean()) {
					month = date.split("-")[1];
					for(int i = 0 ; i < tableContent.size() ; i++) {
						JsonObject runningObject = tableContent.get(i).getAsJsonObject();
						String tableDate = runningObject.get("DATE").getAsString();
						String pdfDate = "";
						try {
							DateTime Date = DateTime.parse(tableDate);
							pdfDate = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(pdfDate.contains("-" + month + "-"))
							filterArray.add(runningObject);
					}
				}else if(i$body.has("partialPeriodCode") && i$body.get("partialPeriodCode").getAsBoolean()) {
					day = date.split("-")[2];
					month = date.split("-")[1];
					for(int i = 0 ; i < tableContent.size() ; i++) {
						JsonObject runningObject = tableContent.get(i).getAsJsonObject();
						String tableDate = runningObject.get("DATE").getAsString();
						String pdfDate = "";
						try {
							DateTime Date = DateTime.parse(tableDate);
							pdfDate = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(pdfDate.contains(month + "-" + day))
							filterArray.add(runningObject);
					}
				}
			}
			
			if(filterArray.size() == 0) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "PLease enter the valid date to continue");
				return isonMsg;
			}
			double tableCreditAmount = 0;
			double tableDebitAmount = 0;
			String error = "";
			for(int i = 0 ; i < filterArray.size(); i++) {
				JsonObject runningObject = filterArray.get(i).getAsJsonObject();
				if(runningObject.get("DEBITS").getAsString().equals("0.00")) {
					try {
						double credits =  Double.parseDouble(runningObject.get("CREDITS").getAsString().replace(",", ""));
						tableCreditAmount += credits;
					}catch(Exception e) {
						e.printStackTrace();
					}
				}else if(runningObject.get("CREDITS").getAsString().equals("0.00")) {
					try {
						double debits =  Double.parseDouble(runningObject.get("DEBITS").getAsString().replace(",", ""));
						tableDebitAmount += debits;
					}catch(Exception e) {
						e.printStackTrace();
					}
				}
			}
			double totalPdfCreditDebitAmount = Math.abs(tableCreditAmount - tableDebitAmount);
			if (totalPdfCreditDebitAmount != 0.0) {
				error = "Total Pdf mismatch of credit and debit : " + totalPdfCreditDebitAmount;
			}
			if(error.equals(""))
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "No Difference in the Flexcube Data");
			else
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, error);
			i$body = new JsonObject();
			i$body.addProperty("TotalDifference", totalPdfCreditDebitAmount);
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, error);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
		}catch(Exception e) {
			
		}
		return isonMsg;
	}
	
	
	public JsonObject reconciliationLoadFlexcube(JsonObject isonMsg) {
		try {
			JsonObject i$body = new JsonObject();
			JsonObject query = new JsonObject();
			JsonArray filterArray = new JsonArray();
			i$body = i$ResM.getBody(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String date = "";
			if(!i$body.has("finYear"))
				date = i$body.get("fromDate").getAsString();
			String day = "";
			String month = "";
			String year = "";
			JsonArray flexcubeData = i$body.get("flexcubeData").getAsJsonArray();
			if(i$body.has("finYear") && i$body.get("finYear").getAsBoolean()) {
				year = i$body.get("year").getAsString().substring(2 , 6);
				for(int i = 0 ; i < flexcubeData.size() ; i++) {
					JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
					String flexcubeDate = runningObject.get("Date").getAsString();
					String flexcubeDt = "";
					try {
						DateTime Date = DateTime.parse(flexcubeDate);
						flexcubeDt = Date.toString("yyyy-MM-dd");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					if(flexcubeDt.contains(year))
						filterArray.add(runningObject);
				}
			}else if(i$body.has("periodCode") && i$body.get("periodCode").getAsBoolean()) {
				if(i$body.has("fullPeriodCode") && i$body.get("fullPeriodCode").getAsBoolean()) {
					month = date.split("-")[1];
					for(int i = 0 ; i < flexcubeData.size() ; i++) {
						JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
						String flexcubeDate = runningObject.get("Date").getAsString();
						String flexcubeDt = "";
						try {
							DateTime Date = DateTime.parse(flexcubeDate);
							flexcubeDt = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(flexcubeDt.contains("-" + month + "-"))
							filterArray.add(runningObject);
					}
				}else if(i$body.has("partialPeriodCode") && i$body.get("partialPeriodCode").getAsBoolean()) {
					day = date.split("-")[2];
					month = date.split("-")[1];
					for(int i = 0 ; i < flexcubeData.size() ; i++) {
						JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
						String flexcubeDate = runningObject.get("Date").getAsString();
						String flexcubeDt = "";
						try {
							DateTime Date = DateTime.parse(flexcubeDate);
							flexcubeDt = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(flexcubeDt.contains(month + "-" + day))
							filterArray.add(runningObject);
					}
				}
			}
			
			if(filterArray.size() == 0) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "PLease enter the valid date to continue");
				return isonMsg;
			}
			
			double flexcubeCreditAmount = 0;
			double flexcubeDebitAmount = 0;
			String error = "";
			for(int i = 0 ; i < filterArray.size() ; i++) {
				String data = filterArray.get(i).getAsJsonObject().get("Transaction type").getAsString();
				if(data.equals("C"))
					flexcubeCreditAmount += Double.parseDouble(filterArray.get(i).getAsJsonObject().get("Amount").getAsString());
				else if(data.equals("D"))
					flexcubeDebitAmount += Double.parseDouble(filterArray.get(i).getAsJsonObject().get("Amount").getAsString());
			}
			double totalFlexcubeCreditDebitAmount = Math.abs(flexcubeCreditAmount - flexcubeDebitAmount);
			i$body = new JsonObject();
			i$body.addProperty("TotalDifference", totalFlexcubeCreditDebitAmount);
				if(totalFlexcubeCreditDebitAmount != 0.0) {
					error = "Total Flexcube mismatch of credit and debit : " + totalFlexcubeCreditDebitAmount + "/n";
				}
				if(error.equals(""))
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "No Difference in the Flexcube Data");
				else
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, error);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
		}catch(Exception e) {
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in loading");
		}
		return isonMsg;
	}
	
	public JsonObject reconciliationCompare(JsonObject isonMsg) {
		try {
			JsonObject i$body = new JsonObject();
			JsonObject query = new JsonObject();
			JsonArray tableContent = new JsonArray();
			JsonArray filterArray = new JsonArray();
			i$body = i$ResM.getBody(isonMsg);
			String date = "";
			if(!i$body.has("finYear"))
				date = i$body.get("fromDate").getAsString();
			String day = "";
			String month = "";
			String year = "";
			String pdfId = i$body.get("pdfId").getAsString();
			query.addProperty("pdfTableId", pdfId);
			JsonArray flexcubeData = i$body.get("flexcubeData").getAsJsonArray();
			JsonObject pdfData =  db$Ctrl.db$GetRow("ICOR_M_PDF_TABLE_DATA", query);
			tableContent = pdfData.get("tableContent").getAsJsonArray();
			if(i$body.has("finYear") && i$body.get("finYear").getAsBoolean()) {
				year = i$body.get("year").getAsString().substring(2 , 6);
				for(int i = 0 ; i < flexcubeData.size() ; i++) {
					JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
					String flexcubeDate = runningObject.get("Date").getAsString();
					String flexcubeDt = "";
					try {
						DateTime Date = DateTime.parse(flexcubeDate);
						flexcubeDt = Date.toString("yyyy-MM-dd");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					if(flexcubeDt.contains(year))
						filterArray.add(runningObject);
				}
				for(int i = 0 ; i < tableContent.size() ; i++) {
					JsonObject runningObject = tableContent.get(i).getAsJsonObject();
					String tableDate = runningObject.get("DATE").getAsString();
					String pdfDate = "";
					try {
						DateTime Date = DateTime.parse(tableDate);
						pdfDate = Date.toString("yyyy-MM-dd");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					if(pdfDate.contains(year))
						filterArray.add(runningObject);
				}
			}else if(i$body.has("periodCode") && i$body.get("periodCode").getAsBoolean()) {
				if(i$body.has("fullPeriodCode") && i$body.get("fullPeriodCode").getAsBoolean()) {
					month = date.split("-")[1];
					for(int i = 0 ; i < flexcubeData.size() ; i++) {
						JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
						String flexcubeDate = runningObject.get("Date").getAsString();
						String flexcubeDt = "";
						try {
							DateTime Date = DateTime.parse(flexcubeDate);
							flexcubeDt = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(flexcubeDt.contains("-" + month + "-"))
							filterArray.add(runningObject);
					}
					for(int i = 0 ; i < tableContent.size() ; i++) {
						JsonObject runningObject = tableContent.get(i).getAsJsonObject();
						String tableDate = runningObject.get("DATE").getAsString();
						String pdfDate = "";
						try {
							DateTime Date = DateTime.parse(tableDate);
							pdfDate = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(pdfDate.contains("-" + month + "-"))
							filterArray.add(runningObject);
					}
				}else if(i$body.has("partialPeriodCode") && i$body.get("partialPeriodCode").getAsBoolean()) {
					day = date.split("-")[2];
					month = date.split("-")[1];
					for(int i = 0 ; i < flexcubeData.size() ; i++) {
						JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
						String flexcubeDate = runningObject.get("Date").getAsString();
						String flexcubeDt = "";
						try {
							DateTime Date = DateTime.parse(flexcubeDate);
							flexcubeDt = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(flexcubeDt.contains(month + "-" + day))
							filterArray.add(runningObject);
					}
					for(int i = 0 ; i < tableContent.size() ; i++) {
						JsonObject runningObject = tableContent.get(i).getAsJsonObject();
						String tableDate = runningObject.get("DATE").getAsString();
						String pdfDate = "";
						try {
							DateTime Date = DateTime.parse(tableDate);
							pdfDate = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(pdfDate.contains(month + "-" + day))
							filterArray.add(runningObject);
					}
				}
			}
			
			if(filterArray.size() == 0) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "PLease enter the valid date to continue");
				return isonMsg;
			}
			
			JsonArray filteredFlexcubeData = new JsonArray();
			JsonArray filteredTableContent = new JsonArray();
			for(int i = 0 ; i < filterArray.size() ; i++) {
				if(!filterArray.get(i).getAsJsonObject().has("Transaction Ref No"))
					filteredTableContent.add(filterArray.get(i).getAsJsonObject());
				else
					filteredFlexcubeData.add(filterArray.get(i).getAsJsonObject());
			}
			
			double flexcubeCreditAmount = 0;
			double tableCreditAmount = 0;
			double flexcubeDebitAmount = 0;
			double tableDebitAmount = 0;
			String error = "";
			
			for(int i = 0 ; i < filteredFlexcubeData.size() ; i++) {
				String data = filteredFlexcubeData.get(i).getAsJsonObject().get("Transaction type").getAsString();
				if(data.equals("C"))
					flexcubeCreditAmount += Double.parseDouble(filteredFlexcubeData.get(i).getAsJsonObject().get("Amount").getAsString());
				else if(data.equals("D"))
					flexcubeDebitAmount += Double.parseDouble(filteredFlexcubeData.get(i).getAsJsonObject().get("Amount").getAsString());
			}
			
			for(int i = 0 ; i < filteredTableContent.size(); i++) {
				JsonObject runningObject = filteredTableContent.get(i).getAsJsonObject();
				if(runningObject.get("DEBITS").getAsString().equals("0.00") && runningObject.has("BALANCE")) {
					try {
						double credits =  Double.parseDouble(runningObject.get("CREDITS").getAsString().replace(",", ""));
						tableCreditAmount += credits;
					}catch(Exception e) {
						e.printStackTrace();
					}
				}else if(runningObject.get("CREDITS").getAsString().equals("0.00") && runningObject.has("BALANCE"))
					try {
						double debits =  Double.parseDouble(runningObject.get("DEBITS").getAsString().replace(",", ""));
						tableDebitAmount += debits;
					}catch(Exception e) {
						e.printStackTrace();
					}
			}
			double totalCreditAmount = Math.abs(flexcubeCreditAmount - tableCreditAmount);
			double totalDebitAmount = Math.abs(flexcubeDebitAmount - tableDebitAmount);
			double totalFlexcubeCreditDebitAmount = Math.abs(flexcubeCreditAmount - flexcubeDebitAmount);
			double totalPdfCreditDebitAmount = Math.abs(tableCreditAmount - tableDebitAmount);
			double totalDiffBetPdfFlexcubeAmount = Math.abs(totalFlexcubeCreditDebitAmount - totalPdfCreditDebitAmount);
			if(totalCreditAmount != 0.0)
				error = "Total mismatch of credit : " + totalCreditAmount + "/n";
			if(totalDebitAmount != 0.0)
				error += "Total mismatch of debit : " + totalDebitAmount + "/n";
			if(totalDiffBetPdfFlexcubeAmount != 0.0)
				error += "Total mismatch of credit and debit : " + totalDiffBetPdfFlexcubeAmount;
			if(error.equals(""))
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "No Mistmatch in Flexcube and Pdf Data");
			else
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, error);
			i$body = new JsonObject();
			i$body.addProperty("TotalDifferenceCredit", totalCreditAmount);
			i$body.addProperty("TotalDifferenceDebit", totalDebitAmount);
			i$body.addProperty("TotalDifferenceCreditDebit", totalDiffBetPdfFlexcubeAmount);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
		}catch(Exception e) {
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in comparison");
		}
		return isonMsg;
	}
	
	public JsonObject reconciliationIndividualCompare(JsonObject isonMsg) {
		try {
			JsonObject i$body = new JsonObject();
			JsonObject query = new JsonObject();
			JsonArray tableContent = new JsonArray();
			JsonArray filterArray = new JsonArray();
			JsonArray result = new JsonArray();
			i$body = i$ResM.getBody(isonMsg);
			String date = "";
			if(!i$body.has("finYear"))
				date = i$body.get("fromDate").getAsString();
			Set<String> set = new HashSet<>();
			String day = "";
			String month = "";
			String year = "";
			String pdfId = i$body.get("pdfId").getAsString();
			query.addProperty("pdfTableId", pdfId);
			JsonArray flexcubeData = i$body.get("flexcubeData").getAsJsonArray();
			JsonObject pdfData =  db$Ctrl.db$GetRow("ICOR_M_PDF_TABLE_DATA", query);
			tableContent = pdfData.get("tableContent").getAsJsonArray();
			if(i$body.has("finYear") && i$body.get("finYear").getAsBoolean()) {
				year = i$body.get("year").getAsString().substring(2 , 6);
				for(int i = 0 ; i < flexcubeData.size() ; i++) {
					JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
					String flexcubeDate = runningObject.get("Date").getAsString();
					String flexcubeDt = "";
					try {
						DateTime Date = DateTime.parse(flexcubeDate);
						flexcubeDt = Date.toString("yyyy-MM-dd");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					if(flexcubeDt.contains(year))
						filterArray.add(runningObject);
				}
				for(int i = 0 ; i < tableContent.size() ; i++) {
					JsonObject runningObject = tableContent.get(i).getAsJsonObject();
					String tableDate = runningObject.get("DATE").getAsString();
					String pdfDate = "";
					try {
						DateTime Date = DateTime.parse(tableDate);
						pdfDate = Date.toString("yyyy-MM-dd");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					if(pdfDate.contains(year))
						filterArray.add(runningObject);
				}
			}else if(i$body.has("periodCode") && i$body.get("periodCode").getAsBoolean()) {
				if(i$body.has("fullPeriodCode") && i$body.get("fullPeriodCode").getAsBoolean()) {
					month = date.split("-")[1];
					for(int i = 0 ; i < flexcubeData.size() ; i++) {
						JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
						String flexcubeDate = runningObject.get("Date").getAsString();
						String flexcubeDt = "";
						try {
							DateTime Date = DateTime.parse(flexcubeDate);
							flexcubeDt = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(flexcubeDt.contains("-" + month + "-"))
							filterArray.add(runningObject);
					}
					for(int i = 0 ; i < tableContent.size() ; i++) {
						JsonObject runningObject = tableContent.get(i).getAsJsonObject();
						String tableDate = runningObject.get("DATE").getAsString();
						String pdfDate = "";
						try {
							DateTime Date = DateTime.parse(tableDate);
							pdfDate = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(pdfDate.contains("-" + month + "-"))
							filterArray.add(runningObject);
					}
				}else if(i$body.has("partialPeriodCode") && i$body.get("partialPeriodCode").getAsBoolean()) {
					day = date.split("-")[2];
					month = date.split("-")[1];
					for(int i = 0 ; i < flexcubeData.size() ; i++) {
						JsonObject runningObject = flexcubeData.get(i).getAsJsonObject();
						String flexcubeDate = runningObject.get("Date").getAsString();
						String flexcubeDt = "";
						try {
							DateTime Date = DateTime.parse(flexcubeDate);
							flexcubeDt = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(flexcubeDt.contains(month + "-" + day))
							filterArray.add(runningObject);
					}
					for(int i = 0 ; i < tableContent.size() ; i++) {
						JsonObject runningObject = tableContent.get(i).getAsJsonObject();
						String tableDate = runningObject.get("DATE").getAsString();
						String pdfDate = "";
						try {
							DateTime Date = DateTime.parse(tableDate);
							pdfDate = Date.toString("yyyy-MM-dd");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						if(pdfDate.contains(month + "-" + day))
							filterArray.add(runningObject);
					}
				}
			}
			
			if(filterArray.size() == 0) {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "PLease enter the valid date to continue");
				return isonMsg;
			}
			
			JsonArray filteredFlexcubeData = new JsonArray();
			JsonArray filteredTableContent = new JsonArray();
			for(int i = 0 ; i < filterArray.size() ; i++) {
				if(!filterArray.get(i).getAsJsonObject().has("Transaction Ref No"))
					filteredTableContent.add(filterArray.get(i).getAsJsonObject());
				else
					filteredFlexcubeData.add(filterArray.get(i).getAsJsonObject());
			}
			
			for(int i = 0 ; i < filteredTableContent.size() ; i++) {
				String accountNumber = filteredTableContent.get(i).getAsJsonObject().get("CHEQUE NO").getAsString();
				double flexcubeCreditTotal = 0;
				double flexcubeDebitTotal = 0;
				double pdfCreditTotal = 0;
				double pdfDebitTotal = 0;
				if(filteredFlexcubeData.size() > 0) {
					for(int j = 0 ; j < filteredFlexcubeData.size() ; j++) {
						String data = filteredFlexcubeData.get(j).getAsJsonObject().get("Account No").getAsString();
						if(data.equals(accountNumber) && !I$utils.$iStrFuzzyMatch( accountNumber , "") && !set.contains(accountNumber)) {
							if(filteredFlexcubeData.get(j).getAsJsonObject().get("Transaction type").getAsString().equals("C")) {
								double credit = Double.parseDouble(filteredFlexcubeData.get(j).getAsJsonObject().get("Amount").getAsString());
								flexcubeCreditTotal += credit;
							}else if(filteredFlexcubeData.get(j).getAsJsonObject().get("Transaction type").getAsString().equals("D")) {
								double debit = Double.parseDouble(filteredFlexcubeData.get(j).getAsJsonObject().get("Amount").getAsString());
								flexcubeDebitTotal += debit;
							}
						}
					}
					
				}
				for(int k = 0 ; k < filteredTableContent.size() ; k++) {
					JsonObject runningObject = filteredTableContent.get(k).getAsJsonObject();
					if(I$utils.$iStrFuzzyMatch(runningObject.get("CHEQUE NO").getAsString(), accountNumber) && !I$utils.$iStrFuzzyMatch( accountNumber , "") && !set.contains(accountNumber)) {
						if(runningObject.get("DEBITS").getAsString().equals("0.00")) {
							try {
								double credits =  Double.parseDouble(runningObject.get("CREDITS").getAsString().replace(",", ""));
								pdfCreditTotal += credits;
							}catch(Exception e) {
								e.printStackTrace();
							}
						}else if(runningObject.get("CREDITS").getAsString().equals("0.00"))
							try {
								double debits =  Double.parseDouble(runningObject.get("DEBITS").getAsString().replace(",", ""));
								pdfDebitTotal += debits;
							}catch(Exception e) {
								e.printStackTrace();
							}
					}
				}
				double creditSum = flexcubeCreditTotal + pdfCreditTotal;
				double debitSum = flexcubeDebitTotal + pdfDebitTotal;
				JsonObject resultObj = new JsonObject();
				if(creditSum - debitSum > 0 && !set.contains(accountNumber)) {
					resultObj.addProperty("AccountNumber", accountNumber);
					resultObj.addProperty("TransactionType", "C");
					resultObj.addProperty("Mismatch Amount", creditSum - debitSum);
					resultObj.addProperty("Date", date);
					result.add(resultObj);
				}else if(creditSum - debitSum < 0 && !set.contains(accountNumber)) {
					resultObj.addProperty("AccountNumber", accountNumber);
					resultObj.addProperty("TransactionType", "D");
					resultObj.addProperty("Mismatch Amount", creditSum - debitSum);
					resultObj.addProperty("Date", date);
					result.add(resultObj);
				}
				set.add(accountNumber);
			}
			i$body = new JsonObject();
			i$body.add("result", result);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Reconciliation Completed");
		}catch(Exception e) {
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation is not completed");
		}
		return isonMsg;
	}
	
	
	//#MVT00057 Starts
	public JsonObject riskScan(JsonObject isonMsg) {
		try {
			JsonObject ftr = new JsonObject();
			JsonObject status = new JsonObject();

			int threads = isonMsg.get("threads").getAsInt();
			String scanId = isonMsg.get("scanId").getAsString();
			status.addProperty("initiatedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			status.addProperty("ScanId", scanId);
			ftr.addProperty("ScanId", scanId);
			db$Ctrl.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN_LOG", status, ftr, "true");
			for (int i = 0; i < threads; i++) {
				JsonObject jWrkArgs = new JsonObject();
				
	            jWrkArgs.add("isonMsg", isonMsg);
	    		jWrkArgs.addProperty("scanId", scanId);
	            jWrkArgs.addProperty("threadCount", i);
	            jWrkArgs.addProperty("totalNumberOfThreads", threads);
	            jWrkArgs.add("isonMsg", jWrkArgs.deepCopy());
				jWrkArgs.addProperty("clsName",
						"net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IKYCController");
				jWrkArgs.addProperty("funcName", "riskThreadProcess");
				IThreadController IThread$worker = new IThreadController(jWrkArgs);
				Thread t = new Thread(IThread$worker);
				t.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation is not completed");
		}
		return isonMsg;
	}

	// #SRM00008 changes start
	public JsonObject appSignature(JsonObject isonMsg) {
		try {
			JsonObject jBody = new JsonObject();
			JsonObject filter = new JsonObject();
			if (isonMsg.has("i-body")) {
				jBody = isonMsg.getAsJsonObject("i-body");
				JsonElement sign = jBody.get("signature");
				if(sign!=null) {
					db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION",filter,"true");
				}
			} 
		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATE SIGNATURE");

		}
		return isonMsg;
	}  //#SRM00008 changes end
	
	
	// #Va000027 Begins
	public void updateReferDcStatus(String sAppNumber, String Coll_Name) {
		// Change the rejected application queue so that application may not appear in
		// rejected list
		try {
			JsonObject jFlter = new JsonObject();
			jFlter.addProperty("applicationId", sAppNumber);
			JsonObject Apl$Json = new JsonObject();
			Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
			if (Apl$Json != null) {
				if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
					jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
					JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
					if (task$Json != null) {
						task$Json.addProperty("Queue", "ReferDcResubmit");
						db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);

					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// #Va000027 Ends
	// #BVB00033 Ends

//Date Format Change 
// #00000013 ends
	public JsonObject dateFromatter(String date) {
		SimpleDateFormat dmyFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
		Date orDate;
		JsonObject retDate = new JsonObject();
		try {
			orDate = dmyFormat.parse(date);
			retDate = i$ResM.adddate(orDate);
			return retDate;
		} catch (Exception e) {
			return null;
		}

	}

	// Threading for calling IMBPM Controller // #BZ00002 change begins
	class imbpmFwdThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject isonMapJson;
		JsonObject isonheader;

		public imbpmFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
			this.message = "RUN";
			this.iosnMsg = isonMsg;
			this.isonMapJson = isonMapJson;
			this.isonheader = isonheader;

		}

		public void run() {
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
			logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
			JsonObject i$res = mirrorController(iosnMsg, isonMapJson, isonheader);// call processmessage method that
																					// sleeps the
			// logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}

	}

	// #Va000029 change begins
	public JsonObject mirrorController(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

		try {
			JsonObject Jbdy = new JsonObject();
			JsonObject jBody = new JsonObject();
			jBody = i$ResM.getBody(isonMsg);
			String sRef = null;
			String Coll_Name = "";
			String DcStatus = null;
			String ScrCtrlClass = null;
			String sAppNumber = null;

			JsonObject jFilter = new JsonObject();
			
			// Redirecting to Create KYC application workflow
			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			// DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			// update the referDc Applicaiton
			JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP",
					"{\"SCRID\":" + i$ResM.getScreenID(isonMsg) + "}", "{\"WORKFLOW\":1}");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			// #DVJ00032 Starts
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", 
					i$ResM.getBody(isonMsg).get("userId").getAsString());
			// #DVJ00032 Ends
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			// Fwd the Control to Workflow COntroller.
			ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
				if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
				}
			} else {

				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				return isonMsg;
			}

		} catch (Exception e) {
			return null;
		}
	}

	// #Va000029 change ends

	public IReconciliationController() {
		// Cons
	}
}
// #00000001 Ends 