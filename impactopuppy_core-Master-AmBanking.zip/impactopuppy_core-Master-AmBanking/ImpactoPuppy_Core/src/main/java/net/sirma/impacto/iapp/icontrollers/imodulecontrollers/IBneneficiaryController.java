/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Oct 5, 2018  | #BVB00005   | 1) 2) Making i-Match available in DB
      |0.1 Beta    | Vijay 		| Nov 29, 2018 | #BVB00016   | Feature I-Projection added 
      |0.1 Beta    | Vijay 		| Dec 1, 2018  | #BVB00019   | Rights should not be checked for LOV Screen Id's  
      |0.1 Beta    | Vijay 		| Dec 9, 2018  | #BVB00021   | 1) Added SOpr1, SOpr2 to in parameters to validate Request 2) Macro Economical Changes to calc pdMacroValue
      |0.1 Beta    | Vijay 		| Dec 11, 2018 | #BVB00027   | Moving QUERYMASTER to operation2 rather than in operation 
      |0.1.6       | Vijay 		| Dec 14, 2018 | #BVB00029   | Adding isonMsg to call DB Controller 
      |0.2.1       | Vijay 		| Jan 07, 2018 | #BVB00033   | 1) Adding Process Message Handler 
      														   2) Moved individual screen validation to iReqManipulator 
      														   3) Added ResPreFlightHandler for handling post actions of reponse  
      														   4) IProjectionMap Null check added. 
      |0.2.1       | Vijay 		| Jan 09, 2019 | #BVB00035   | Encryption Decryption based on Maintenance , Removed Duplicate ScrID 
      |0.2.1       | Syed 		| Jan 07, 2018 | #MAQ00001   | Adding I match condition for Summary  
      |0.1.6       | Valla 		| Dec 26, 2018 | #V0000030   | Import functionalities code   		
      |0.2.1       | Syed 		| Jan 31, 2018 | #MAQ00002   | Adding Pagination code
      |0.2.1       | Syed 		| Feb 07, 2018 | #MAQ00003   | Commented one Condition for I-Match of Summary calls
      |MVP 2.0     | Syed 		| Mar 18, 2019 | #MAQ00004   | Added Get$Count function
      |0.3.3	   | Syed 		| Apr 06, 2019 | #MAQ00005   | Added Sorting function for all Summary pages
      |0.3.6       | Vijay 		| Apr 17, 2019 | #BVB00119   | Release And Acquire Feature Release 
      |0.3.2.202   | Syed 		| Apr 08, 2019 | #MAQ00009   | Changed GET$COUNT function for Summary calls 
      |0.3.6       | Vijay 		| Apr 24, 2019 | #BVB00127   | Adding IProjection to Query
      |0.3.9.240   | Syed 		| May 18, 2019 | #MAQ00013   | Sort function made dynamic based of field
      |0.3.9.240   | Syed 		| May 18, 2019 | #MAQ00014   | GetCount and GetData response merged for operation2='GET$PAG'
      |0.3.9.241   | Niegil 	| May 22, 2019 | #NYE00014   | LOV Dataset Filter Changes       
      |0.3.9.241   | Niegil 	| May 27, 2019 | #NYE00015   | Changes for $Where handling Dataset       
      |0.3.9.241   | Niegil 	| May 28, 2019 | #NYE00016   | Changes for Ends With DataSet Filter     
      |0.3.14      | Vijay 	    | Jun 10, 2019 | #BVB00164   | NoSqlInjection Correction Changes
      |0.3.14      | Vijay 	    | Jun 10, 2019 | #BVB00165   | No records found is giving exception during Query
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes
      |0.3.15.293  | Syed 		| Jun 21, 2019 | #MAQ00020   | Changed Gson to Gson Builder
      |0.3.16      | Vijay  	| Jul 10, 2019 | #BVB00183   | IMatch will accept an Array for Summary
      |0.3.17      | Vijay  	| Jul 22, 2019 | #BVB00188   | IMatch should match with Body Request
      |0.3.18      | Pappu      | Mar 18, 2021 | #PKY00004   | Sort function made dynamic based on object
      |0.3.18      | Pappu      | May 18, 2022 | #PKY00071   | Handled check issuance and letter Request services
      |0.3.18	   | Sindhu		| Oct 11, 2022 | #SRM00003	 | Added code for retrieving individual details for letter request and issue of cheque summary in dashboard
      |0.3.18	   | Manikanta  | Oct 14, 2022 | #MVT00080	 | Added Code To handle letter Request and issue of cheque DashBoard 
      |0.3.18	   | Manikanta  | Feb 09, 2022 | #MVT00105   | Added code for payee details summary
      |0.3.18	   | Srikanth   | Jan 05, 2023 | #SRI00028   | Added code for filter the Records in the Payee detailes 
----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder; // #MAQ00020 
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.ISeqConsistencyController;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
//import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.iEmailService;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.*;

public class IBneneficiaryController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(GenericAppController.class);
	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
    private GenericAppController i$genAppCtrl = new GenericAppController();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private IgenericWorker igenericWorker = new IgenericWorker();
	private JsonObject i$Annotate = null;
	private IEmailService i$Email = new IEmailService();
	private ISeqConsistencyController i$seqConsCtrl = new ISeqConsistencyController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private Ioutils I$ioutil = new Ioutils();
	private ICoreSysReqFwderController I$coreSys = new ICoreSysReqFwderController();
	private IFuncSrvcController I$FuncSrv = new IFuncSrvcController();
	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		// JsonObject i$Annotate = null;
		String Coll_Name, L_Coll_Name;
//		Gson gson = new Gson();
	    Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonObject projection = new JsonObject();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();
		 
		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
		//PKY00071 starts
		String SrvcName = i$ResM.getSrvcName(isonMsg);
		String Srvcopr = i$ResM.getSrvcopr(isonMsg);
		try {
			if(I$utils.$iStrFuzzyMatch(SrvcName, "CHEQUE_ISSUANCE_STMT")) {
				return isonMsg = chequeIssuanceDet(isonMsg, isonMapJson);
			}
            if(I$utils.$iStrFuzzyMatch(SrvcName, "REQUEST_FOR_LETTER_STMT")) {
            	return isonMsg = requestForLetterDet(isonMsg, isonMapJson);
			}
            if(I$utils.$iStrFuzzyMatch(ScrId, "SB2LTREQ") || I$utils.$iStrFuzzyMatch(ScrId, "SB2ISOCS")) {	//#MVT00080 changes
            	return isonMsg = dashBoardFunction(isonMsg, isonMapJson);
			}
            if(I$utils.$iStrFuzzyMatch(ScrId, "SABPAYDT")) {//#MVT00105 changes
            	return isonMsg = transferSummary(isonMsg, isonMapJson);
			}
            else if(I$utils.$iStrFuzzyMatch(ScrId, "OABBENEDT")) {
				return isonMsg = addUpdBeneficiary(isonMsg, isonMapJson);
			}
            //PKY00071 ends
			// #BVB00019 Starts
//			boolean hasRights = false;
//			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
//				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
//			else
//				hasRights = true;

			// #NYE00014 Rebuild IMatch if "dataSetFltr" Key is Present and Operation is Summary
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY"))
			{
				
				JsonObject j$DataFilter = get$FrmDataSetFilter(isonMsg);
				if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr")))
				{

					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,j$DataFilter.get("Invalid$Expr").getAsString() );
					return isonMsg;
				}
				// #NYE00015 Begin
				else if (j$DataFilter != null)
				{
					// Get Formated I-MATCH Dataset Filter
					i$Match = j$DataFilter;
				}
				// #NYE00015 End
			}
			//	#NYE00014
			
			// if (db$Ctrl.db$hasRights(i$ResM.iloggedUser, ScrId, SOpr)) {
			//if (hasRights) {

				// #BVB00019 Ends

				if (i$Match == null) {
					JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
					i$Match = new JsonObject();
					try {
						// if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
								&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") // #MAQ00001
						)) {

							for (int i = 0; i < i$MatchMap.size(); i++) {
								// #BVB00183 Starts 
								 JsonElement matchElm = i$ResM.getBodyElement(isonMsg,i$MatchMap.get(i).getAsString());
								 if(!I$utils.$isNull(matchElm) ) { // #BVB00188 
								 if(matchElm.isJsonPrimitive()) {
									 i$Match.addProperty(i$MatchMap.get(i).getAsString(),
										i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
								 }else if(matchElm.isJsonArray()) { 
									 JsonArray matchArr = matchElm.getAsJsonArray();
									 String iMatchStr = "{'$in': ['"; 
									 for(int j =0; j< matchArr.size(); j++) {
										 if(j<matchArr.size()-1)
										 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"','"; 
										 else {
											 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"']}";
										 }
									 }
									 
									 i$Match.add(i$MatchMap.get(i).getAsString(), parser.parse(iMatchStr).getAsJsonObject()); 
									 
								 }
								 // #BVB00183 Ends
								 // #BVB00188 Starts 
								 }else {
									 isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
										return isonMsg;
								 }
								 // #BVB00188 Ends
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
						} else {
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
						}
					} catch (Exception e) {
						logger.error("Error description : ", e);
						i$Match = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}"); // #MAQ00001
					}
					;

				}
				;

				// #BVB00005 Ends
				// #BVB00016 Starts
				if (i$ProjectionArray != null) {
					for (int i = 0; i < i$ProjectionArray.size(); i++) {
						i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
					}
				} else {
					JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
					JsonArray i$NonProjectionmap = i$ResM.getINonProjection(isonMapJson);
					if (i$ProjectionMap != null || i$NonProjectionmap != null) {// #BVB00033
						try {
							if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
								for (int i = 0; i < i$ProjectionMap.size(); i++) {
									i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
								}
								for (int j = 0; j < i$NonProjectionmap.size(); j++) {
									i$Projection.addProperty(i$NonProjectionmap.get(j).getAsString(), 0);
								}
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
							} else {
								i$Projection = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
							}
						} catch (Exception e) {
							e.printStackTrace();
							i$Projection = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
						}
						;// #BVB00033 Starts
					}else {
						i$Projection = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
					}
					// #BVB00033 Ends
					// i$Projection = new JsonObject();
				}
				// #BVB00016 Ends

				// #BVB00035 Starts
				projection = new JsonObject();
				projection.addProperty("privateKey", 1);
				JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
				String privateKey = cParam.get("privateKey").getAsString();
				JsonObject filter = new JsonObject();
				filter.addProperty("sessoinId", i$ResM.getClientSessionID(isonMsg));
				JsonObject sessionValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", gson.toJson(filter),
						gson.toJson(projection));

				// #BVB00035 Ends

				Integer i$MaxRow = -1;
				// #BVB00005 Starts
				JsonObject i$recordDetails = new JsonObject();
				JsonObject i$validateRes = new JsonObject();
				JsonObject i$ledgerCurVer = new JsonObject();
				// #BVB00005 Ends
				try {
					i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
				} catch (Exception e) {
					try {
						i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
					} catch (Exception ex) {
						i$MaxRow = -1;
					}
					;
				}
				;

				try {
					Coll_Name = isonMapJson.get("COLLNAME").getAsString();
				} catch (Exception e) {
					Coll_Name = null;
				}
				;

				if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
						|| (I$utils.$iStrBlank(gson.toJson(i$Match)))
				/* || I$utils.$iStrFuzzyMatch(gson.toJson(i$Match), "{}") */ ) { // #MAQ00003
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
					return isonMsg;
				}
				;

				try {
					L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
				} catch (Exception e) {
					L_Coll_Name = null;
				}
				;

				if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
					return isonMsg;
				}
				;

				try {
					// String ScrID = i$ResM.getScreenID(isonMsg); // #BVB00035
					String SOpr1 = i$ResM.getOpr1(isonMsg);
					String SOpr2 = i$ResM.getOpr2(isonMsg);
					String SOpr3 = i$ResM.getOpr3(isonMsg);
					/*
					 * if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY") &&
					 * !I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ") && !I$utils.$iStrFuzzyMatch(SOpr,
					 * "QUERY")) {
					 */
					// #MAQ00002 start
					try {
						i$body = isonMsg.getAsJsonObject("i-body");
					} catch (Exception e) {
						i$body = null;
					}
					// #MAQ00002 end

					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}"); // #BVB00035 changes ScrID to ScrId
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;

					} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						// Forwarding Request to DB Handler for SUMMARY
						logger.debug("Forwarding Request to DB Controller for Summary");
						// #MAQ00002 start
						isonMsg.add("i-body", i$body);
						int intPgNo, intRecs;
						try {
							intPgNo = i$body.get("intPgNo").getAsInt();
						} catch (Exception e) {
							intPgNo = 0;
						}
						try {
							intRecs = i$body.get("intRecs").getAsInt();
						} catch (Exception e) {
							intRecs = 0;
						}
						// #MAQ00013 starts
						// #PKY00004 starts
						Gson gsonp = new GsonBuilder().serializeNulls().create();
						String sort = "";
						try {
//							String sortField = i$body.get("sort").getAsString();
//							sort = "{'"+sortField+"':1}";
							
							sort = gsonp.toJson(isonMsg.get("i-sort").getAsJsonObject());
							
						} catch (Exception e) {
							sort = "{'_id':-1}";
						}
						// #PKY00004 ends
						// #MAQ00013 starts

						// #MAQ00004 starts
						if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {

							// #MAQ00009 starts
							int iRowCnt = 0;
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
									}
									// Added
									// Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, "{\"isCurrVer\"=\"Y\"}"); // #BVB00016

								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null)
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
									// Added Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends
						// #MAQ00014 starts
						} else if(I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
							// #MAQ00009 starts
							int iRowCnt = 0;
							JsonObject db$res = null;
							
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										 db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);								
									}
									// Added
									// Projection
									else {
										i$Match = new JsonObject();
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);// #BVB00016 Added
																						// Projection
										
									}
								}  else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null) {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
												intPgNo, intRecs, sort);
									// Added Projection
										
									}
									else {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
												i$Projection, intPgNo, intRecs, sort);
										
									}
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}
							
							i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
							i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());	
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends
							
						}
						// #MAQ00014 ends
						// #MAQ00004 ends
						else {
							// #MAQ00005 code starts
							if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
								if (i$Match != null) {
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort)); // #BVB00016
								}

								else {
									i$Match = new JsonObject();
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort));// #BVB00016 Added
																					// Projection
								}
							} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
									|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
								if (i$Match != null)
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
											intPgNo, intRecs, sort));// #BVB00016
																		// Added
																		// Projection
								else
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
											i$Projection, intPgNo, intRecs, sort));// #BVB00016

								// #MAQ00005 code ends
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
								return isonMsg;
							}
						}
					} /*
						 * else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ")) {
						 * 
						 * logger.debug("Forwarding Request to DB Controller for Query Accquire"); try {
						 * JsonObject u$pdate = null; i$ledgerCurVer.addProperty("errorMsg",
						 * "Record Sucessfully Retrieved"); db$Ctrl.db$AcqRow(L_Coll_Name, i$Match,
						 * isonMsg); isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg,
						 * i$ResM.I_BDYTAG, i$ledgerCurVer); isonMsg = i$ResM.iHandleResStat(isonMsg,
						 * i$ResM.I_SUCC,"Record Sucessfully Retrieved"); return isonMsg; } catch
						 * (Exception e) { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						 * "OPERATION FAILED"); return isonMsg; }
						 * 
						 * }
						 */ else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
						return isonMsg;
					}
					;
					I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrId, SOpr); // #BVB00035
					if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
						// #BVB00005 Starts
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$body", i$body);
						// Getting the validation data from DB
						// Getting data from Master
						JsonObject i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						String ndD = "{\"$ne\":\"D\"}";
						
						i$runningQuery.add("recordStat", parser.parse(ndD).getAsJsonObject());
						JsonObject i$master = db$Ctrl.db$GetRow(Coll_Name, i$runningQuery.toString());
						if (i$master != null) {
							logger.debug("Master Records: " + i$master);
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									i$master);
						} else {
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									"{}");
						}
						// Getting all records of Ledger Except for Deleted Records
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						ndD = "{\"$ne\":\"D\"}";
						
						i$runningQuery.add("recordStat", parser.parse(ndD).getAsJsonObject());
						JsonArray i$Ledger = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("Ledger Records: " + i$Ledger);
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$Ledger",
								i$Ledger);

						// Getting records with isCurrVer:
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("isCurrVer", "Y");
						JsonArray i$ledgerCurrVer = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerCurrVer: " + i$ledgerCurrVer + " Count: " + i$ledgerCurrVer.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerCurrVer",
								i$ledgerCurrVer);

						// Getting records of Un-Auth
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("authStat", "U");
						JsonArray i$ledgerUnAuth = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerUnAuth: " + i$ledgerUnAuth + " Count: " + i$ledgerUnAuth.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerUnAuth",
								i$ledgerUnAuth);

						i$validateRes = igenericWorker.validateRequest(SOpr, SOpr1, SOpr2, i$recordDetails); // #BVB00021
						if (i$validateRes.get("i-stat").getAsInt() > 0) {
							if (i$ledgerCurrVer.size() > 0)
								i$ledgerCurVer = i$ledgerCurrVer.get(0).getAsJsonObject();
							// #BVB00005 Ends
							// Forwarding Request to DB Handler for Insert
							if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, in$ = null;

										// u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										// i$Match);
										// if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {

										/*
										 * if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) { String userPwd =
										 * i$body.get("userPwd").getAsString(); userPwd =
										 * passwordEncoder.encode(userPwd.toString());
										 * logger.debug("Excrypted Password:", userPwd); i$body.addProperty("userPwd",
										 * userPwd);
										 * 
										 * }
										 */
										// #BVB00021 Starts
										/*
										 * if(I$utils.$iStrFuzzyMatch(ScrId, "OIFHSMES")) { double i$pdMacroValue = 1;
										 * // BVB try { JsonArray i$mVal = i$body.get("mVal").getAsJsonArray(); for(int
										 * i=0; i<i$mVal.size(); i++) { try { JsonObject i$runningValue =
										 * i$mVal.get(i).getAsJsonObject(); double featureValue =
										 * i$runningValue.get("featureValue").getAsDouble(); i$pdMacroValue =
										 * i$pdMacroValue - (featureValue/100); }catch(Exception e) { // Eat Up } }
										 * 
										 * i$pdMacroValue = I$utils.$roundTwoDouble(i$pdMacroValue);
										 * i$body.addProperty("pdMacroValue", i$pdMacroValue); }catch(Exception e) {
										 * e.printStackTrace(); i$pdMacroValue = 0; }
										 * 
										 * };
										 */
										// #BVB00021 Ends

										i$body.addProperty("isCurrVer", "Y");
										i$body.addProperty("authStat", "U");
										i$body.addProperty("recordStat", "O");
										i$body.addProperty("operation", SOpr.toUpperCase());
										i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
										i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
										// i$body.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$body.addProperty("authorizer", "");
										i$body.addProperty("errorMsg", "Record Sucessfully Saved");
										i$body.addProperty("authorizedOnSrvDate", "");
										m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
										Integer MaxVer = 0;
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
											MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
										}
										;
										i$body.addProperty("verNo", MaxVer + 1);
										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
										i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);

										in$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029

										return in$;
										// } else {
										// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										// "OPERATION FAILED #LUP0001");
										// return isonMsg;
										// }
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
									/*
									 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									 * "OPERATION FAILED"); return isonMsg; }
									 */
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// Forwarding Request to DB Handler for UPDATE
							if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);
									JsonObject rec = new JsonObject();
									JsonObject fltr = new JsonObject();
									fltr.addProperty("customerId", i$Match.get("customerId").getAsString());
									fltr.addProperty("isCurrVer" , "Y");
									rec = db$Ctrl.db$GetRow(L_Coll_Name, fltr);
									if (rec == null) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												"OPERATION FAILED #LUP0001");
										return isonMsg;
									}
									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										double i$pdMacroValue = 1; // BVB
										if (i$ledgerUnAuth.size() == 0) {
											u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
													i$Match);
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {

												/*
												 * if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) { String userPwd =
												 * i$body.get("userPwd").getAsString(); userPwd =
												 * passwordEncoder.encode(userPwd.toString());
												 * logger.debug("Excrypted Password:", userPwd);
												 * i$body.addProperty("userPwd", userPwd);
												 * 
												 * }
												 */

												/*
												 * // #BVB00021 Starts if (I$utils.$iStrFuzzyMatch(ScrId, "OIFHSMES")) {
												 * try { JsonArray i$mVal = i$body.get("mVal").getAsJsonArray(); for
												 * (int i = 0; i < i$mVal.size(); i++) { try { JsonObject i$runningValue
												 * = i$mVal.get(i) .getAsJsonObject(); double featureValue =
												 * i$runningValue.get("featureValue") .getAsDouble(); i$pdMacroValue =
												 * i$pdMacroValue - (featureValue / 100); } catch (Exception e) { // Eat
												 * Up } }
												 * 
												 * i$pdMacroValue = I$utils.$roundTwoDouble(i$pdMacroValue);
												 * i$body.addProperty("pdMacroValue", i$pdMacroValue); } catch
												 * (Exception e) { e.printStackTrace(); i$pdMacroValue = 0; }
												 * 
												 * } ; // #BVB00021 Ends
												 */
												i$body.addProperty("isCurrVer", "Y");
												i$body.addProperty("authStat", "U");
												i$body.addProperty("recordStat", "O");
												i$body.addProperty("operation", SOpr.toUpperCase());
												i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
												i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
												i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
												// i$body.addProperty("acquiredBy", i$ResM.iloggedUser);
												i$body.addProperty("acquiredBy", "");
												i$body.addProperty("authorizer", "");
												i$body.addProperty("errorMsg", "Record Sucessfully Updated");
												i$body.addProperty("authorizedOnSrvDate", "");
												m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
												Integer MaxVer = 0;
												if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
													MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
												}
												;
												i$body.addProperty("verNo", MaxVer + 1);
												// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
												// BVB Starts
												// up$ = db$Ctrl.db$InsertRow(L_Coll_Name, i$body);
												up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
												// BVB Ends
												try {
													JsonObject recIdObject = new JsonObject();
													// #BVB00167 Starts 
													// if (i$master != null) {
													if (I$utils.$isNull(i$ledgerCurVer)) {
														recIdObject = i$master.getAsJsonObject("_id");
													} else {
														recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
													}
													;
													db$Ctrl.db$ReleaseRow(recIdObject);
													//JsonObject re$ = i$releaseLock(recIdObject);
													// db$Ctrl.db$ReleaseRow(Coll_Name, i$Match, IResManipulator.iloggedUser.get());
													
													// #BVB00167 Ends
													// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
													// //
													// Release Lock
												} catch (Exception ex) {
													// Eat Up
												}
												;

												// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
												return up$;

											} else {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
														"OPERATION FAILED #LUP0001");
												return isonMsg;
											}

										} else {

											i$ledgerCurVer = i$body.deepCopy();
											/*
											 * if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) { String userPwd =
											 * i$ledgerCurVer.get("userPwd").getAsString(); userPwd =
											 * passwordEncoder.encode(userPwd.toString());
											 * logger.debug("Excrypted Password:", userPwd);
											 * i$ledgerCurVer.addProperty("userPwd", userPwd);
											 * 
											 * }
											 */
											i$ledgerCurVer.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																													// Date
											i$ledgerCurVer.addProperty("acquiredBy", "");
											i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Updated");

											i$ledgerCurVer.remove("_id");
											i$runningQuery = new JsonObject();

											i$runningQuery = i$Match.deepCopy();
											i$runningQuery.addProperty("isCurrVer", "Y");

											// up$ = db$Ctrl.db$UpdateRow(L_Coll_Name,isonMsg, i$ledgerCurVer,
											// i$runningQuery);
											up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer,
													i$runningQuery); // #BVB00029
											try {
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												// JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;

											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;

										}
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00005 Starts
							// Forwarding Request to DB Handler for AUTH
							if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$recordDetails",
											i$recordDetails);
									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$ledgerCurVer = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										// u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										// i$Match);
										// if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
										// i$ledgerCurVer.addProperty("isCurrVer", "Y");
										i$ledgerCurVer.addProperty("authStat", "A");
										// i$ledgerCurVer.addProperty("recordStat", "O");
										i$ledgerCurVer.addProperty("remarks",
												i$ResM.getBodyElementS(isonMsg, "remarks"));
										i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
										i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
										i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
										// i$ledgerCurVer.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Authorized");
										// i$body.addProperty("authBy", i$ResM.iloggedUser);
										// i$body.add("authDate", i$ResM.adddate(new Date()));

										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;

										// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											// JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;

										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();

										i$runningQuery = i$Match.deepCopy();
										i$runningQuery.addProperty("isCurrVer", "Y");

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
										i$ledgerCurVer.remove("isCurrVer");
										// Updating/ Inserting data to Master
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();

										up$ = db$Ctrl.db$UpdateRow(Coll_Name, isonMsg, i$ledgerCurVer, i$runningQuery,
												"true"); // #BVB00029

										return up$;
										/*
										 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										 * "OPERATION FAILED #LUP0001"); return isonMsg; }
										 */
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for CLOSE
							if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}", i$Match);
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
											i$body.addProperty("isCurrVer", "Y");
											i$body.addProperty("authStat", "U");
											i$body.addProperty("recordStat", "C");
											i$body.addProperty("operation", SOpr.toUpperCase());
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
											i$body.addProperty("authorizer", "");
											i$body.addProperty("errorMsg", "Record Sucessfully Closed");
											i$body.addProperty("authorizedOnSrvDate", "");
											m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
											Integer MaxVer = 0;
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
												MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
											}
											;
											i$body.addProperty("verNo", MaxVer + 1);
											// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
											up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
											try {
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												//JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;
											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;
										} else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"OPERATION FAILED #LUP0001");
											return isonMsg;
										}
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for DELETE
							if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										/*
										 * u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										 * i$Match); if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate),
										 * i$ResM.I_SUCC)) {
										 */
										i$ledgerCurVer.addProperty("isCurrVer", "N");
										i$ledgerCurVer.addProperty("authStat", "A");
										i$ledgerCurVer.addProperty("recordStat", "D");
										i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
										i$ledgerCurVer.addProperty("initiator", IResManipulator.iloggedUser.get());
										// i$ledgerCurVer.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
										i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Deleted");
										i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date()));
										i$ledgerCurVer.addProperty("remarks",
												i$ResM.getBodyElementS(isonMsg, "remarks"));

										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;

										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											//JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;
										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();

										i$runningQuery = i$Match.deepCopy();
										i$runningQuery.addProperty("isCurrVer", "Y");

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer,
												i$runningQuery); // #BVB00029
										i$ledgerCurVer.remove("isCurrVer");
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();
										if (i$master != null) {
											i$runningQuery.add("verNo", i$master.get("verNo"));
											u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
													i$runningQuery);
										}

										return up$;
										/*
										 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										 * "OPERATION FAILED #LUP0001"); return isonMsg; }
										 */
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends

								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00027 Starts
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SOpr2, "")) {
								// #BVB00027 Ends
								try {
									JsonObject u$pdate, m$x, up$ = null;
									i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Retrieved");
									// #BVB00127 Starts 
									if (!I$utils.$isNull(i$Projection)) {
										i$ledgerCurVer = I$impactoUtil.refineJsonObject(i$ledgerCurVer, i$Projection);
									}
									// #BVB00127 Ends
									/*if (I$utils.$iStrFuzzyMatch(SOpr3, "fetchRecord")) {   // #SRM00003 Changes starts
										JsonArray det = new JsonArray();
										det.add(i$ledgerCurVer);
										i$body.add("PaginatedApplicationsInQueue", det);
										return isonMsg;
									} // #SRM00003 changes end*/
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$ledgerCurVer);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Record Sucessfully Retrieved");
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00027 Starts
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYMASTER")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYMASTER")) {
									// #BVB00027 Ends
									try {
										JsonObject u$pdate, m$x, up$ = null;
										
										if(!I$utils.$isNull(i$master)) { // #BVB00165 
										i$master.addProperty("errorMsg", "Record Sucessfully Retrieved");
										// #BVB00127 Starts 
										if (!I$utils.$isNull(i$Projection)) {
											i$master = I$impactoUtil.refineJsonObject(i$master, i$Projection);
										}
										// #BVB00127 Ends
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$master);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Record Sucessfully Retrieved");
										}
										// #BVB00165 Starts 
										else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
										} 
										// #BVB00165 Ends
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}  
								// #BVB00119 Starts
								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYACQ")) {
									logger.debug("Forwarding Request to DB Controller for Query Accquire");
									try {
										JsonObject u$pdate, ac$ = null;
										// i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Retrieved");
										// #BVB00167 Starts
//										if (i$master != null) {
//											ac$ = db$Ctrl.db$AcqRow(Coll_Name, i$Match);
//										} else {
											ac$ = db$Ctrl.db$AcqRow(L_Coll_Name, i$Match);

										//}
										;
										// #BVB00167 Ends
										// if(i$ResM.getStatMsg(ac$))
										// i$ResM.getMsgtext(ac$)
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
												i$ResM.getiStat(ac$));

										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$ledgerCurVer);

										// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Record Sucessfully
										// Acquired");
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "RELEASELOCK")) {
									logger.debug("Forwarding Request to DB Controller for Query Accquire");
									try {
										JsonObject rl$ = new JsonObject();
//										JsonObject recIdObject = new JsonObject();
//										if (i$master != null) {
//											recIdObject = i$master.getAsJsonObject("_id");
//										} else {
//											recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
//										}
//										;
//										JsonObject re$ = i$releaseLock(recIdObject);
//										/*
//										 * String recID = i$ResM.convertId(recIdObject); JsonObject re$ =
//										 * db$Ctrl.db$ReleaseRow(recID);
//										 */
//										if (i$master != null) {
//											rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
//										} else {
//											rl$ = db$Ctrl.db$ReleaseRowS(L_Coll_Name, i$Match, IResManipulator.iloggedUser.get());
//
//										}
//										;
										rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
												i$ResM.getiStat(rl$));
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								;
// #BVB00119 Ends
							}

							// #BVB00005 Ends
						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									i$validateRes.get("i-Msg").getAsString());
							return isonMsg;
						}
						;

					} else {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
						return isonMsg;
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
							e.getMessage().toString());
					e.printStackTrace();
					return isonMsg;
				}
//			} else {
//				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//						"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
//				return isonMsg;
//			}

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
	//#MVT00105 starts
	public JsonObject transferSummary(JsonObject isonMsg, JsonObject isonMapJson) {
		try {
			String toDate;
			int minAmt;
			int maxAmt;
			String fromDate;
			String amtType;
			JsonObject temp = new JsonObject();
			JsonObject temp1 = new JsonObject();
			JsonObject payee = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject projcn = new JsonObject();
			JsonObject afilter = new JsonObject();
			JsonObject dfilter = new JsonObject();
			JsonObject dfilterV = new JsonObject();
			JsonObject dbData = new JsonObject();
			JsonArray qfilter = new JsonArray();
			JsonArray qfilterV = new JsonArray();
			JsonArray payeeDetails = new JsonArray();
			JsonParser parser = new JsonParser();
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			try {
				fromDate = ibody.get("fromData").getAsString();
			} catch (Exception e) {
				fromDate = I$utils.changeDateFormat(new Date(), "yyyy-MM-dd");
			}
			try {
				toDate = ibody.get("toDate").getAsString();
			} catch (Exception e) {
				toDate = I$utils.changeDateFormat(new Date(), "yyyy-MM-dd");
			}
			try {
				minAmt = ibody.get("minAmt").getAsInt();
			} catch (Exception e) {
				minAmt = 1;
			}
			try {
				maxAmt = ibody.get("maxAmt").getAsInt();
			} catch (Exception e) {
				maxAmt = 999;
			}

			if (I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "Internal Fund Transfer")) {
				amtType = "trnData.lcyAmount";
			} else {
				amtType = "trnData.txnAmt";
			}
//SRI00028 starts
			temp.addProperty("$gte", minAmt);
			afilter.add(amtType, temp);
			qfilter.add(afilter);
			temp = new JsonObject();
			afilter = new JsonObject();
			temp.addProperty("$lte", maxAmt);
			afilter.add(amtType, temp);
			qfilter.add(afilter);

//			String grtDate = "{'$gte':"+fromDate +" }";
//			String lsrDate = "{'$lte':"+toDate +" }";
			temp = new JsonObject();
			temp.addProperty("$gte", fromDate);
			dfilter.add("trnData.trnDate", temp);
			qfilter.add(dfilter);
//			dfilterV.add("trnData.valueDate", temp);
//			qfilterV.add(dfilterV);
			
			
			temp = new JsonObject();
			dfilter = new JsonObject();
			temp.addProperty("$lte", toDate);
//			dfilterV.add("trnData.valueDate", temp);
//			qfilterV.add(dfilterV);
			dfilter.add("trnData.trnDate", temp);
			qfilter.add(dfilter);
			
			
			temp1.addProperty("$gte", minAmt);
			afilter.add(amtType, temp1);
			qfilterV.add(afilter);
			temp1 = new JsonObject();
			afilter = new JsonObject();
			temp1.addProperty("$lte", maxAmt);
			afilter.add(amtType,temp1);
			qfilterV.add(afilter);
			
			temp1 = new JsonObject();
			temp1.addProperty("$gte", fromDate);
			dfilterV.add("trnData.valueDate", temp1);
			qfilterV.add(dfilterV);
			
			temp1 = new JsonObject();
			dfilterV = new JsonObject();
			temp1.addProperty("$lte", toDate);
			dfilterV.add("trnData.valueDate", temp1);
			qfilterV.add(dfilterV);	//SRI00028 Ends

			projcn.addProperty("_id", 0);
			projcn.addProperty("customerId", 1);
			projcn.addProperty("beneficiaries", 1);
			filter.addProperty("isCurrVer", "Y");
			filter.addProperty("customerId", ibody.get("customerId").getAsString());
			JsonObject benData = db$Ctrl.db$GetRow("ICOR_M_BENEDT_COLL", filter, projcn).getAsJsonObject();
			JsonArray payees = benData.get("beneficiaries").getAsJsonArray();
			projcn.remove("customerId");
			projcn.remove("beneficiaries");
			projcn.addProperty("trnData", 1);
			projcn.addProperty("tranId", 1);
			projcn.addProperty("iResMsg", 1);

			for (int i = 0; i < payees.size(); i++) {
				String cif;
				filter = new JsonObject();
				JsonObject trnObject = new JsonObject();
				JsonArray transferData = new JsonArray();
				payee = payees.get(i).getAsJsonObject();

				if ((I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "ACH Transfer")|| I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "All"))
						&& (I$utils.$iStrFuzzyMatch(payee.get("transferType").getAsString(),"ACH Transfers (TECU to Bank)")) || (I$utils.$iStrFuzzyMatch(payee.get("transferType").getAsString(),"ACH Transfer"))) {
					JsonObject sort = new JsonObject();
					sort.addProperty("_id", -1);
					try {
//						filter.add("$and", qfilter);
						filter.addProperty("trnCd", "ACH");
						filter.addProperty("trnData.achBeneficiaryAcc", payee.get("recipientAccountNo").getAsString());
						JsonArray transferDataArr = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn,sort);
						for (int m = 0; m < transferDataArr.size(); m++) {
							JsonObject currObj = transferDataArr.get(m).getAsJsonObject();
							if (currObj.get("trnData").getAsJsonObject().has("valueDate")) {
								filter.add("$and", qfilterV);
								transferData = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn, sort);
							} else {
								filter.add("$and", qfilter);
								transferData = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn, sort);
							}
							for (int j = 0; j < transferData.size(); j++) {
								try {
									String tranId = "";
									trnObject = new JsonObject();
									JsonObject resObj = new JsonObject();

									JsonObject trnData = transferData.get(j).getAsJsonObject().get("trnData").getAsJsonObject();
									cif = trnData.get("txnAcc").getAsString().substring(3, 9);
									resObj = transferData.get(j).getAsJsonObject().getAsJsonObject("iResMsg").getAsJsonObject("i-body");
									if (!I$utils.$iStrBlank(resObj.get("REFERENCE_NO").getAsString())) {
										tranId = resObj.get("REFERENCE_NO").getAsString();
									}
									if (I$utils.$iStrFuzzyMatch(ibody.get("customerId").getAsString(), cif)) {
										trnObject.addProperty("tranId", tranId);
										trnObject.addProperty("transferType", "ACH Transfer");
										if (trnData.has("valueDate")) {
											trnObject.addProperty("date", trnData.get("valueDate").getAsString());
										} else {
											trnObject.addProperty("date", trnData.get("trnDate").getAsString());
										}
										trnObject.add("amount", trnData.get("txnAmt"));
										trnObject.addProperty("recipient", payee.get("recipient").getAsString());
										trnObject.addProperty("fromAccount", trnData.get("txnAcc").getAsString());
										trnObject.addProperty("toAccount",trnData.get("achBeneficiaryAcc").getAsString());
										payeeDetails.add(trnObject);
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					} catch (Exception e) {
						logger.debug(e.getMessage());
					}
				}
				if ((I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "LinCU Transfer")
						|| I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "All"))
						&& (I$utils.$iStrFuzzyMatch(payee.get("transferType").getAsString(), "LinCU Transfer"))) {
					JsonObject sort = new JsonObject();
					sort.addProperty("_id", -1);
					try {
//						filter.add("$and", qfilter);
						filter.addProperty("trnCd", "LINCU");
						filter.addProperty("trnData.lincuCardNo", payee.get("toLinCUCardNumber").getAsString());
						JsonArray transferDataArr = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn,sort);
						for (int m = 0; m < transferDataArr.size(); m++) {
							try {
								JsonObject currObj = transferDataArr.get(m).getAsJsonObject();
								if (currObj.get("trnData").getAsJsonObject().has("valueDate")) {
									filter.add("$and", qfilterV);
									transferData = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn,sort);
								} else {
									filter.add("$and", qfilter);
									transferData = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn,sort);
								}
								for (int j = 0; j < transferData.size(); j++) {
									try {
										String tranId = "";
										trnObject = new JsonObject();
										JsonObject resObj = new JsonObject();

										JsonObject trnData = transferData.get(j).getAsJsonObject().get("trnData").getAsJsonObject();
										cif = trnData.get("acc").getAsString().substring(3, 9);
										resObj = transferData.get(j).getAsJsonObject().getAsJsonObject("iResMsg").getAsJsonObject("i-body");
										if (!I$utils.$iStrBlank(resObj.get("REFERENCE_NO").getAsString())) {
											tranId = resObj.get("REFERENCE_NO").getAsString();
										}
										if (I$utils.$iStrFuzzyMatch(ibody.get("customerId").getAsString(), cif)) {
											trnObject.addProperty("tranId", tranId);
											trnObject.addProperty("transferType", "LinCU Transfer");
											if (trnData.has("valueDate")) {
												trnObject.addProperty("date", trnData.get("valueDate").getAsString());
											} else {
												trnObject.addProperty("date", trnData.get("trnDate").getAsString());
											}
											trnObject.add("amount", trnData.get("txnAmt"));
											trnObject.addProperty("fromAccount", trnData.get("acc").getAsString());
											trnObject.addProperty("toAccount",trnData.get("lincuCardNo").getAsString());
											if (payee.has("cardHolderName")) {
												trnObject.addProperty("recipient",payee.get("cardHolderName").getAsString());
											} else {
												trnObject.addProperty("recipient",payee.get("cardHolder'sName").getAsString());
											}
											payeeDetails.add(trnObject);
										}
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} catch (Exception e) {
						logger.debug(e.getMessage());
					}
				}
				if ((I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "Internal Fund Transfer")|| I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "All"))
						&& (I$utils.$iStrFuzzyMatch(payee.get("transferType").getAsString(),"Internal Fund Transfer"))) {
					try {
						String ifilter = "";
						JsonObject sort = new JsonObject();
						sort.addProperty("_id", -1);
						filter.add("trnCd", parser.parse("{'$in':['IFT','FT']}").getAsJsonObject());
						filter.addProperty("trnData.creditAccNo", payee.get("toAccountNumber").getAsString());

						JsonArray transferDataArr = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn,sort);
						for (int m = 0; m < transferDataArr.size(); m++) {
							try {
								JsonObject currObj = transferDataArr.get(m).getAsJsonObject();
								if (I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "All")) {
									if (currObj.get("trnData").getAsJsonObject().has("valueDate")) {
										ifilter = gson.toJson(qfilterV).replace("trnData.txnAmt", "trnData.lcyAmount");
									} else {
										ifilter = gson.toJson(qfilter).replace("trnData.txnAmt", "trnData.lcyAmount");
									}
								} else {
									if (currObj.get("trnData").getAsJsonObject().has("valueDate")) {
										ifilter = gson.toJson(qfilterV);
									} else {
										ifilter = gson.toJson(qfilter);
									}

								}

//						if(I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "All")) {
//							ifilter=gson.toJson(qfilter).replace("trnData.txnAmt", "trnData.lcyAmount");
//						} else {
//							ifilter = gson.toJson(qfilter);
//						}
								filter.add("$and", parser.parse(ifilter).getAsJsonArray());
//						filter.addProperty("trnCd", "FT");
//						filter.addProperty("trnData.creditAccNo", payee.get("toAccountNumber").getAsString());
								transferData = db$Ctrl.db$GetRows$Sort("ICOR_C_TRNFWD_MONITOR", filter, projcn, sort);

								for (int j = 0; j < transferData.size(); j++) {
									try {
										String tranId = "";
										trnObject = new JsonObject();
										JsonObject resObj = new JsonObject();

										JsonObject trnData = transferData.get(j).getAsJsonObject().get("trnData").getAsJsonObject();
										cif = trnData.get("debitAccNo").getAsString().substring(3, 9);
										resObj = transferData.get(j).getAsJsonObject().getAsJsonObject("iResMsg").getAsJsonObject("i-body");
										if (!I$utils.$iStrBlank(resObj.get("REFERENCE_NO").getAsString())) {
											tranId = resObj.get("REFERENCE_NO").getAsString();
										}

										if (I$utils.$iStrFuzzyMatch(ibody.get("customerId").getAsString(), cif)) {
											trnObject.addProperty("tranId", tranId);
											trnObject.addProperty("transferType", "Internal Fund Transfer");
											if (trnData.has("valueDate")) {
												trnObject.addProperty("date", trnData.get("valueDate").getAsString());
											} else {
												trnObject.addProperty("date", trnData.get("trnDate").getAsString());
											}
											trnObject.add("amount", trnData.get("lcyAmount"));
											if(payee.has("memberName"))
											{
												trnObject.addProperty("recipient", payee.get("memberName").getAsString());
											}else {
												trnObject.addProperty("recipient", payee.get("recipient").getAsString());
											}
											
											trnObject.addProperty("toAccount",trnData.get("creditAccNo").getAsString());
											trnObject.addProperty("fromAccount",trnData.get("debitAccNo").getAsString());
											payeeDetails.add(trnObject);
										}
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} catch (Exception e) {
						logger.debug(e.getMessage());
					}
				}
			}
			dbData.add("transferDetails", payeeDetails);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, dbData);
		} catch (Exception e) {
			logger.debug(e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "No Payee History Found", e.getMessage().toString());
			return isonMsg;
		}
		return isonMsg;
	}
	//#MVT00105 starts
//	public JsonObject i$releaseLock(JsonObject recIdObject) {
//		try {
//			String recID = i$ResM.convertId(recIdObject);
//			return db$Ctrl.db$ReleaseRow(recID);
//		} catch (Exception e) {
//			return null;
//		}
//	}
	//#MVT00080 Starts
	public JsonObject dashBoardFunction(JsonObject isonMsg,JsonObject isonMapJson) {
		try {
			JsonObject res$blder = new JsonObject();
			JsonArray scanData = new JsonArray();
	           
            String collName = isonMapJson.get("COLLNAME").getAsString();
            JsonObject j$DataFilter = i$genAppCtrl.get$FrmDataSetFilter(isonMsg);
            int totalAppls = db$Ctrl.db$GetCountI(collName, j$DataFilter);
            JsonObject scanObject = db$Ctrl.db$GetRow(collName, j$DataFilter).getAsJsonObject();
            
            scanData.add(scanObject);
            res$blder.add("PaginatedApplicationsInQueue", scanData);
            res$blder.addProperty("TotalApplsInQueue", totalAppls);
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res$blder);
		}catch(Exception e) {
			e.printStackTrace();
			 return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Failed",
	                    e.getMessage().toString());
		}
		return isonMsg;		
	}//#MVT00080 ends
	
	public JsonObject addUpdBeneficiary(JsonObject isonMsg, JsonObject isonMapJson) {
		try {
			Gson gson = new Gson();
			String custId = i$ResM.getBody(isonMsg).get("customerId").getAsString();
			String Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			JsonObject filter = new JsonObject();
			JsonObject proj = new JsonObject();
			JsonObject sort = new JsonObject();
			JsonArray benArray = new JsonArray();
			JsonObject validate = new JsonObject();
			filter.addProperty("customerId", custId);
			proj.addProperty("beneficiaries", 1);
			proj.addProperty("verNo", 1);
			proj.addProperty("_id", 0);
			sort.addProperty("_id", -1);
			JsonObject benData = db$Ctrl.db$GetRow(Coll_Name, filter, proj);
			if (i$ResM.getBody(isonMsg).has("beneficiaries")) {
				benArray = i$ResM.getBody(isonMsg).get("beneficiaries").getAsJsonArray();
			}
			JsonObject insertData = new JsonObject();
			String SOpr = i$ResM.getOpr(isonMsg);
			JsonObject currObj = new JsonObject();
			JsonObject dataUpdate = new JsonObject();
			
			if (I$utils.$iStrFuzzyMatch(SOpr, "ADD")) {
				
				if (I$utils.$isNull(benData) || benData.get("beneficiaries").getAsJsonArray().size() <= 0) {
					
					insertData = isonMsg.getAsJsonObject("i-body");
					insertData.addProperty("customerId", custId);
					insertData.addProperty("isCurrVer", "Y");
					insertData.addProperty("authStat", "U");
					insertData.addProperty("recordStat", "O");
					insertData.addProperty("operation", "ADDED");
					insertData.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
					insertData.addProperty("initiator", IResManipulator.iloggedUser.get());
					insertData.addProperty("authorizer", "");
					insertData.addProperty("errorMsg", "Beneficiary Created Successfully");
					insertData.addProperty("authorizedOnSrvDate", "");
					Integer MaxVer = 0;
					insertData.addProperty("verNo", MaxVer);
					
					JsonObject insertedData = db$Ctrl.db$InsertRow(Coll_Name, isonMsg, insertData);
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(insertedData), "i-SUCC")) {
						validate.addProperty("processStat", "true");
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Beneficiary Created Successfully");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
					}else {
						validate.addProperty("processStat", "false");
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Create Beneficiary");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
					}
				
				} else {
					
					for (int i = 0; i < benArray.size(); i++) {
						
						int MaxVer = benData.get("verNo").getAsInt();
						currObj.add("beneficiaries", benArray.get(i).getAsJsonObject());
						dataUpdate.addProperty("verNo", MaxVer + 1);
						dataUpdate.addProperty("errorMsg", "Record Sucessfully Updated");
						dataUpdate.addProperty("operation", "UPDATE");
						dataUpdate.add("lastUpdatedOnSrvDate", i$ResM.adddate(new Date()));
						validate.addProperty("processStat", "true");
						JsonObject updateData = db$Ctrl.db$UpdateRowOperator(Coll_Name, gson.toJson(currObj), filter, "false", "push");
						db$Ctrl.db$UpdateRow(Coll_Name, dataUpdate, filter);
						if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(updateData), "i-SUCC")) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Beneficiary Updated Successfully");
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
						}
						else {
							validate.addProperty("processStat", "false");
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Update Beneficiary");
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
						}
					}
				}
			}else if(I$utils.$iStrFuzzyMatch(SOpr, "DELETE")){
				for (int i = 0; i < benArray.size(); i++) {
					currObj.add("beneficiaries", benArray.get(i).getAsJsonObject());
					int MaxVer = benData.get("verNo").getAsInt();
					currObj.add("beneficiaries", benArray.get(i).getAsJsonObject());
					dataUpdate.addProperty("verNo", MaxVer + 1);
					dataUpdate.addProperty("errorMsg", "Record Sucessfully Deleted");
					dataUpdate.addProperty("operation", "DELETE");
					dataUpdate.add("lastDeletedOnSrvDate", i$ResM.adddate(new Date()));
					validate.addProperty("processStat", "true");
					JsonObject deletData = db$Ctrl.db$UpdateRowOperator(Coll_Name, gson.toJson(currObj), filter, "false", "pull");
					db$Ctrl.db$UpdateRow(Coll_Name, dataUpdate, filter);
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(deletData), "i-SUCC")) {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Beneficiary Deleted Successfully");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
					}else {
						validate.addProperty("processStat", "false");
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Delete Beneficiary");
						isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
					}
				}
				
			} else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				
				String matchStr = "{'$match':" + gson.toJson(filter) + " }";
				String projStr = "{'$project':" +gson.toJson(proj) + " }";
				String reverseQry = "{$addFields: {'beneficiaries': {$reverseArray: '$beneficiaries' } } }";
				JsonArray i$AggParam = new JsonArray();
				i$AggParam.add(matchStr);
				i$AggParam.add(projStr);
				i$AggParam.add(reverseQry);
				JsonArray i$res = db$Ctrl.db$DoAggregate(Coll_Name, i$AggParam);
				JsonObject db$res = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,i$res);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, db$res.get("i-body").getAsJsonArray().get(0).getAsJsonObject());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Retrieved Successfully");
			}
		} 
			catch (Exception e) {
		}
		return isonMsg;
	}
	
//PKY00071 starts
	public JsonObject chequeIssuanceDet(JsonObject isonMsg, JsonObject isonMapJson) {

	    JsonObject db$res = new JsonObject();
	    JsonObject i$body = i$ResM.getBody(isonMsg);
	    JsonObject map$Data = new JsonObject();
	    JsonObject argJson1 = new JsonObject();
	    try {
	       // String uniqueRefNo = I$ioutil.$randomAplhanumeric(10);
	     //   i$body.addProperty("uniqueRefNo", uniqueRefNo);
	        String collName = isonMapJson.get("COLLNAME").getAsString();
	        db$res = db$Ctrl.db$InsertRow(collName, i$body);
	        String i$statMsg = i$ResM.getStatMsg(db$res);
	        try {
				String cif = i$body.get("customerId").getAsString();
				JsonObject fltr = new JsonObject();
				fltr.addProperty("CustomerId", cif);
				JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
				String sKeyE = cifData.get("CustomerEmailId").getAsString();
				String custName = cifData.get("CustomerFullName").getAsString();
				map$Data.addProperty("tmp$name", "TMPL#TT#SUCCESS#CHEQUE#REQUEST#NOTIFICATION#MAIL");
				map$Data.addProperty("custNo", i$body.get("customerId").getAsString());
				map$Data.addProperty("applicationId", i$body.get("applicationId").getAsString());
				map$Data.addProperty("memName", custName);
				argJson1.add("map$Data", map$Data);
				argJson1.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
				JsonObject i$resE = i$Email.SendEmailWOThread(argJson1);
			} catch (Exception e) {
				e.printStackTrace();
			}
	        
	        if (I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_SUCC)) {
	            String msgText = db$res.get("i-stat").getAsJsonObject().get("i-success").getAsJsonObject().get("msgtext").getAsString();
	            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, msgText);
	        } else {
	        //	i$body.addProperty("uniqueRefNo", "");
	            String msgText = db$res.get("i-stat").getAsJsonObject().get("i-error").getAsJsonObject().get("msgtext").getAsString();
	            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, msgText);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	       // i$body.addProperty("uniqueRefNo", "");
	        isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
	        return isonMsg;
	    }
	    return isonMsg;
	}

	public JsonObject requestForLetterDet(JsonObject isonMsg, JsonObject isonMapJson) {
		try {
			JsonObject db$res = new JsonObject();
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject argJson1 = new JsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject attachmentData = new JsonObject();
			JsonArray attachment = new JsonArray();
			JsonObject funcData = I$FuncSrv.exeCallOrcl(isonMsg);
			String branch = i$body.get("accountDebited").getAsString().substring(0, 3);
			JsonObject filter = new JsonObject();
			JsonObject proj = new JsonObject();
			filter.addProperty("Type", "CBS_BRANCH");
			filter.addProperty("KeyId", branch);
			proj.addProperty("BranchDate", 1);
			String branchDate = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter, proj).get("BranchDate").getAsString();
			Date dateStr = new Date();
		    SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-dd");
		    String strDate = formatter.format(dateStr);
			String base64 = funcData.get("i-body").getAsJsonObject().get("I#FileData").getAsString();
			try {
				String collName = isonMapJson.get("COLLNAME").getAsString();
				String cif = i$body.get("customerId").getAsString();
				JsonObject fltr = new JsonObject();
				fltr.addProperty("CustomerId", cif);
				JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
				try {
					String type = i$body.get("type").getAsString();
					JsonObject typeDetails = i$body.get(type + "Details").getAsJsonObject();
					i$body.remove(type + "Details");
					try {
						Set<String> keys = typeDetails.keySet();
						for (String key : keys) {
							try {
								String fieldVal = typeDetails.get(key).getAsString();
								i$body.addProperty(key, fieldVal);
							} catch (Exception e) {
							}
						}
					} catch (Exception e) {
					}
				} catch (Exception e) {
				}
				i$body.remove("letterObj");
				i$body.remove("funcDetails");
				i$body.remove("I#FileData");
				i$body.addProperty("pdfTemplate", base64);
				db$res = db$Ctrl.db$InsertRow(collName, i$body);
				String i$statMsg = i$ResM.getStatMsg(db$res);
				try {
					String sKeyE = cifData.get("CustomerEmailId").getAsString();
					String custName = cifData.get("CustomerFullName").getAsString();
					if (I$utils.$iStrFuzzyMatch(i$body.get("collectionMode").getAsString(), "email")|| I$utils.$iStrFuzzyMatch(i$body.get("collectionMode").getAsString(), "branch")) {
						try {
							map$Data.addProperty("tmp$name", "TMPL#TT#SUCCESS#LETTER#REQUEST#NOTIFICATION#MAIL");
							map$Data.addProperty("custNo", i$body.get("customerId").getAsString());
							map$Data.addProperty("applicationId", i$body.get("applicationId").getAsString());
							map$Data.addProperty("memName", custName);
							attachmentData.addProperty("docType", "application/pdf");
							attachmentData.addProperty("fileName", "Letter Request Statement" + ".pdf");
							attachmentData.addProperty("template", base64);
							attachment.add(attachmentData);
							argJson1.add("attachment", attachment);
							argJson1.add("map$Data", map$Data);
							//MSA00065 starts
							JsonObject isonCopy = isonMsg.deepCopy();
							JsonObject trnData = new JsonObject();
							JsonObject bodyData = new JsonObject();
							JsonObject headerData = new JsonObject();
							JsonObject configData = new JsonObject();
							JsonObject transmitterData = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER","{\"trnCd\":\"LETTERIFT\"}");

							trnData.addProperty("trnDate", branchDate);
							trnData.addProperty("valueDate", strDate);
							trnData.addProperty("debitAccNo", i$body.get("accountDebited").getAsString());
							trnData.addProperty("debitBranchCode", branch);
							trnData.addProperty("branchCode", branch);

							configData.addProperty("imecd",isonMsg.get("i-config").getAsJsonObject().get("imecd").getAsString());

							bodyData.add("trnData", trnData);
							bodyData.addProperty("trnCd", "LETTERIFT");
							bodyData.addProperty("ctrnCd", transmitterData.get("ctrnCd").getAsString());
							bodyData.addProperty("ctrnOpr", transmitterData.get("ctrnOpr").getAsString());
							bodyData.addProperty("ctrnOpr1", transmitterData.get("ctrnOpr1").getAsString());
							bodyData.addProperty("ctrnOpr2", transmitterData.get("ctrnOpr2").getAsString());
							bodyData.addProperty("ctrnOpr3", transmitterData.get("ctrnOpr3").getAsString());
							bodyData.addProperty("trnOpr", transmitterData.get("trnOpr").getAsString());
							bodyData.addProperty("trnOpr1", transmitterData.get("trnOpr1").getAsString());
							bodyData.addProperty("trnOpr2", transmitterData.get("trnOpr2").getAsString());
							bodyData.addProperty("trnOpr3", transmitterData.get("trnOpr3").getAsString());
							bodyData.addProperty("extSys", transmitterData.get("extSys").getAsString());
							bodyData.addProperty("tranId", i$body.get("tranId").getAsString());

							headerData.addProperty("screenid", "XEXCBRFD");
							headerData.addProperty("operation", "CREATE");
							headerData.addProperty("operation1", "@");
							headerData.addProperty("operation2", "@");
							headerData.addProperty("operation3", "@");
							headerData.addProperty("trnBrn", branch);
							headerData.addProperty("msg-id",isonMsg.get("i-header").getAsJsonObject().get("msg-id").getAsString());

							isonCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonCopy, i$ResM.I_BDYTAG, bodyData);
							isonCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonCopy, i$ResM.I_HEADER, headerData);
							isonCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonCopy, i$ResM.I_CONFIG, configData);
							JsonObject sysResp = I$coreSys.coreReqFwd(isonCopy);
							JsonObject validate = new JsonObject();
							String statMsg = i$ResM.getStatMsg(sysResp);
							if (I$utils.$iStrFuzzyMatch(statMsg, i$ResM.I_SUCC)) {
								argJson1.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
								i$Email.SendEmailWOThread(argJson1);
								String msgText = sysResp.get("i-stat").getAsJsonObject().get("i-success").getAsJsonObject().get("msgtext").getAsString();
								validate.addProperty("applicationId", i$body.get("applicationId").getAsString());
								validate.addProperty("referenceNo", i$body.get("referenceNo").getAsString());
								validate.addProperty("DcStatus", i$body.get("DcStatus").getAsString());
								validate.addProperty("DMSLDOC", i$body.get("DMSLDOC").getAsString());
								isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, msgText);
						} else {
							String msgText = sysResp.get("i-stat").getAsJsonObject().get("i-error").getAsJsonObject()
									.get("msgtext").getAsString();
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, validate);
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, msgText);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}//MSA00065 ends
					} else {
						try {
							String collectFrom = i$body.get("collectFrom").getAsString();
							map$Data.addProperty("tmp$name", "TMPL#TT#SUCCESS#LETTER#REQUEST#NOTIFICATION#BRANCH");
							map$Data.addProperty("custNo", i$body.get("customerId").getAsString());
							map$Data.addProperty("applicationId", i$body.get("applicationId").getAsString());
							map$Data.addProperty("memName", custName);
							map$Data.addProperty("collectFrom", collectFrom);
							argJson1.add("map$Data", map$Data);
							argJson1.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
							
							i$Email.SendEmailWOThread(argJson1);
							try {
								if (I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_SUCC)) {
									String msgText = db$res.get("i-stat").getAsJsonObject().get("i-success").getAsJsonObject().get("msgtext").getAsString();
									JsonObject validate = new JsonObject();
									validate.addProperty("applicationId", i$body.get("applicationId").getAsString());
									validate.addProperty("referenceNo", i$body.get("referenceNo").getAsString());
									validate.addProperty("DcStatus", i$body.get("DcStatus").getAsString());
									validate.addProperty("DMSLDOC", i$body.get("DMSLDOC").getAsString());
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,validate);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, msgText);
								} else {
									String msgText = db$res.get("i-stat").getAsJsonObject().get("i-error").getAsJsonObject().get("msgtext").getAsString();
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, msgText);
								}
							}catch(Exception e) {
								e.printStackTrace();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}catch(Exception e) {
				e.printStackTrace();
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
				return isonMsg;
			}
			} catch (Exception e) {
				e.printStackTrace();
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
				return isonMsg;
			}
		} catch (Exception e) {
		}
		return isonMsg;
	}
	//PKY00071 ends
	
	// #BVB00033 Starts
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		// JsonObject argJson = new JsonObject();

		try {
			IBneneficiaryController i$genAppCon = new IBneneficiaryController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			isonMsg = i$genAppCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			// Adding Pre Response Message Handler

			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}
    
	// #NYE00014 Begins
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg)
	{   
       try
        {
    	   return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));
    	   
		}
		catch (Exception e)
		{   
			logger.debug(" Error in get$FrmDataSetFilter -"+e.getMessage());
			return  null;
		}
	}
	
	// #NYE00014 Ends
	
	
    
	// #BVB00033 Ends
	public IBneneficiaryController() {
		// Cons
	}
}
// #00000001 Ends