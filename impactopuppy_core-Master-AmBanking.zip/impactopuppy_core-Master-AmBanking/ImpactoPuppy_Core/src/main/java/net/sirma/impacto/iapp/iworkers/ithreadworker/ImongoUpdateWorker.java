/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Baz 		| Oct 08, 2018  | #00000001   | Initial writing
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iworkers.ithreadworker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
//import net.sirma.impacto.iapp.icontrollers.iworkers.ithreadworker;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.idbworkers.ImongoWorker;

public class ImongoUpdateWorker {
	private Logger logger = LoggerFactory.getLogger(ImongoWorker.class);
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator I$ResMan = new IResManipulator();
	//private static String strJNDI = I$utils.$strValNullIf(PropLoader.env.getProperty("etl.oracle.jndi"), "java:jboss/datasources/ImpactoOrclEtlDS");
	//private EtlController etl$Ctrl = new EtlController();

    
	private void BulkDataUpdate(JsonObject argJson) {
		String strRunID = null;
		String strThNo = null;
		int iRetryConn = 0;
		boolean bJobDone = false;
		String collRevCollection = null;
		String outCollName = null;
		int noOfRecs =0;
		int noOfRecsToSkip = 0;
		
		try {
			strThNo = argJson.get("ITHRIDNO").getAsString();
		} catch(Exception e) {};
		
		try {
			collRevCollection = argJson.get("SCRCOLL").getAsString();
		} catch(Exception e) {};
		
		try {
			outCollName = argJson.get("TARCOLL").getAsString();
		} catch(Exception e) {};
		
		try {
			noOfRecs = argJson.get("#OFRECS").getAsInt();
		} catch(Exception e) {};
		
		try {
			noOfRecsToSkip = argJson.get("ITHRIDNO").getAsInt()-1;
		} catch(Exception e) {};
		
		try {
		
		collRevCollection = "#COLLREV%COLLATERAL_ENTITY28644";
		JsonObject Cfilter = new JsonObject();

		DBObject query = new BasicDBObject("COLLATERAL_VAL_CURR",
				new BasicDBObject("$exists", true));
	
		JsonObject icorCollPerdInput = new JsonObject();
	
		JsonObject projection = new JsonObject();
		projection.addProperty("EXPOSURE_ID", 1);
		projection.addProperty("COLLATERAL_VAL_CURR", 1);
	    projection.addProperty("COLLATERAL_VAL_INCEPTION", 1);
		
		JsonArray db$Result = db$Ctrl.db$GetSummRowsArray(collRevCollection, argJson,
				query.toString(), projection.toString(), noOfRecsToSkip, noOfRecs);


		
		logger.debug("Starting Thread RUNID->>" + strRunID+" THREAD -->>"+strThNo);
		
		
		for (int j = 0; j < db$Result.size(); j++) {
			JsonObject i$runningObj = db$Result.get(j).getAsJsonObject();
			JsonObject setter = new JsonObject();
			// Double newValue = i$runningObj.get("COLLATERAL_VAL_NEW").getAsDouble();
			try {
				setter.add("COLLATERAL_PROTECTION", i$runningObj.get("COLLATERAL_VAL_CURR"));
			} catch (Exception e) {
				setter.add("COLLATERAL_PROTECTION",
						i$runningObj.get("COLLATERAL_VAL_INCEPTION"));
			}
			JsonObject Coolfilter = new JsonObject();
			try {
				Coolfilter.addProperty("EXPOSURE_ID",
						i$runningObj.get("EXPOSURE_ID").getAsString());
			} catch (Exception e) {
				Coolfilter.addProperty("EXPOSURE_ID", "UN KNOWN STRING");
			}

			db$Ctrl.db$UpdateRow(outCollName, setter, Coolfilter);

		}
		logger.debug("Finished Thread Execution for  RUNID->>" + strRunID+" THREAD -->>"+strThNo);
		
		} catch(Exception e) {
			
			logger.debug(" Thread Execution is Failed for RUNID->>" + strRunID+" THREAD -->>"+strThNo);
		}
		
		;
	}

	@SuppressWarnings("unused")
	public void doCollUpdate(JsonObject argJson) {
     try
     {
		String strDBMode = null,
		strCoreBankSys = null;
 
		try {
			strDBMode = argJson.get("DBMODE").getAsString();
		} catch(Exception e) {};

	
			BulkDataUpdate(argJson);
			return;
		

		
     }
     finally
     {
    	 System.gc();
     }
	}

	
}
//#00000001 Ends
