/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |2.3.0.3     | Vijay 		| Sep 17, 2019 | #BVB00209   | Initial writing for Flex DMS Adapter
      ----------------------------------------------------------------------------------------------
      
*/
// #BVB00209 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IFlexDmsController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IFlexDmsController.class);  
 	// **********************************************************************//

	@SuppressWarnings("unused")
	private IDataValidator I$DataValidator = new IDataValidator();
	@SuppressWarnings("unused")
	private SentryGuardController Sentry$Controller = new SentryGuardController();

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			
			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();

			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "FDMFLXDL") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				return queryCIFDocs(isonMsg);
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

	public JsonObject queryCIFDocs(JsonObject isonMsg) {
		JsonArray i$res = new JsonArray();
		try { 
			JsonObject filter = new JsonObject();
 			JsonObject projection = new JsonObject();
			filter.addProperty("cif", i$ResM.getBodyElementS(isonMsg, "cif"));
			filter.addProperty("isCurrVer", "Y");
			projection.addProperty("documents", 1);
			JsonObject cifDet = db$Ctrl.db$GetRow("ICOR_M_B2U_DOC_TRACKER", filter, projection);

			JsonArray docs = cifDet.getAsJsonObject("documents").get("documentDetails").getAsJsonArray();
			for (int i = 0; i < docs.size(); i++) {
				try {
					JsonObject i$runningObj = docs.get(i).getAsJsonObject();
					JsonObject i$respObj = new JsonObject();
					

					JsonArray sides = i$runningObj.getAsJsonArray("sides");
					for (int j = 0; j < sides.size(); j++) {
						JsonObject i$runObj = sides.get(j).getAsJsonObject(); 
						i$respObj.addProperty("docName", i$runningObj.get("idType").getAsString().concat( i$runObj.get("side").getAsString()));
						i$respObj.addProperty("FileUrlToken", i$runObj.get("FileUrlToken").getAsString().concat("&"+i$runObj.get("docExtension").getAsString().replace(".", "")));
						
						i$res.add(i$respObj.deepCopy());
					}

				} catch (Exception e) {
					// TODO: handle exception
				}
			}
			isonMsg=  i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$res);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Tokens Retrieved Sucessfully");
		} catch (Exception e) {
			logger.debug("Failed while Retrieving the Docs: "  + e.getMessage());
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Failed while Retrieving Tokens " + e.getMessage());
		}

		return isonMsg;
	}

}
// #BVB00209 Ends