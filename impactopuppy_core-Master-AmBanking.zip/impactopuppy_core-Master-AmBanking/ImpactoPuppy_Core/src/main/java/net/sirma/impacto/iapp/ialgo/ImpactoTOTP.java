/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      
      //Credits and Thanks to : https://github.com/airG/java-totp/blob/master/LICENSE.txt
      -------------------------------------------------------------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      -------------------------------------------------------------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Feb 2, 2019  | #00000001   | Initial writing
      |0.3.9       | Vijay 		| May 20, 2019 | #BVB00153   | Temporary Debugs for Occasional Passcode issue ** Need to be deleted in prod
      |0.3.9       | Niegil 	| Jun 05, 2019 | #NYE00053   | CHK Algo added for Time Variance Issue
      |0.3.9       | Niegil 	| Jul 05, 2019 | #NYE00054   | Passcode Validity Checks
      -------------------------------------------------------------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ialgo;

import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base32;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class ImpactoTOTP {
	private static int TIME_STEP_SECONDS = 30;
	private static int NUM_DIGITS_OUTPUT = 6;
	private static final Logger logger = LoggerFactory.getLogger(ImpactoTOTP.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private DBController db$Ctrl = new DBController();
	Base32 base32 = new Base32();

	static String frmKey(long num, int digits) {
		String hashStr = Long.toString(num);
		String sReplChar = (new SimpleDateFormat("dd").format(Calendar.getInstance().getTime())).substring(0, 1);
		if (hashStr.length() >= digits) {
			return (hashStr.replaceAll("[^0-9]", sReplChar)).substring(0, digits);
		} else {
			StringBuilder sb = new StringBuilder(digits);
			int iMissingZeros = digits - hashStr.length();
			sb.append(String.format("%1$" + iMissingZeros + "s", "0"));
			sb.append(hashStr);

			return sb.toString().replaceAll("[^0-9]", sReplChar).substring(0, digits);
		}
	}

	public boolean verifyTOTP(String ClientOTP) throws GeneralSecurityException {
	    try {
	      JsonObject r$ec = null;
	      try {
	        r$ec = this.db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", "{\"Key_Owner\":\"" + (String)IResManipulator.iloggedUser
	            .get() + "\",\"Key_Mode\":{\"$regex\": \"UID\"}}", "{\"Key_Token\":1,\"passIME\":1}");
	      } catch (Exception e) {
	        r$ec = null;
	      } 
	      String secret = this.base32.encodeAsString(((String)IResManipulator.iloggedUser.get() + r$ec.get("passIME").getAsString() + this.i$ResM
	          .getGobalValJObj("i-config").get("sitekey").getAsString() + r$ec.get("Key_Token").getAsString()).getBytes());
	      String genTOTP = generateTOTP(secret);
	      logger.debug("secret: " + secret);
	      logger.debug("genTOTP: " + genTOTP);
	      logger.debug("ClientOTP: " + ClientOTP);
	      return this.I$utils.$iStrFuzzyMatch(genTOTP, ClientOTP);
	    } catch (Exception E) {
	      return false;
	    } 
	  }
	
	 public boolean verifyTOTP(String userId, String ClientOTP) throws GeneralSecurityException {
		    try {
		      JsonObject r$ec = null;
		      try {
		        r$ec = this.db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO", "{\"Key_Owner\":\"" + userId + "\",\"Key_Mode\":{\"$regex\": \"UID\"}}", "{\"Key_Token\":1,\"passIME\":1}");
		      } catch (Exception e) {
		        r$ec = null;
		      } 
		      String secret = this.base32.encodeAsString((userId + r$ec.get("passIME").getAsString() + this.i$ResM
		          .getGobalValJObj("i-config").get("sitekey").getAsString() + r$ec.get("Key_Token").getAsString()).getBytes());
		      String genTOTP = generateTOTP(secret);
		      logger.debug("secret: " + secret);
		      logger.debug("genTOTP: " + genTOTP);
		      logger.debug("ClientOTP: " + ClientOTP);
		      return this.I$utils.$iStrFuzzyMatch(genTOTP, ClientOTP);
		    } catch (Exception E) {
		      return false;
		    } 
		  }

	// #NYE00053 Begin
	@SuppressWarnings("unused")
	public String generateTOTPChKDG(String secret, Integer iChkdigit) throws GeneralSecurityException {
		try
		{
		try {
			String sCode = "";
			try {
				TIME_STEP_SECONDS = i$ResM.getGobalValJObj("srcJson").get("PassCodeValiditySecs").getAsInt();
			} catch (Exception e) {
				// eat
			}
			byte[] key = ImpactodecodeBase32(secret);
			// long currentTimeMillis = System.currentTimeMillis();

			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			cal.add(Calendar.HOUR, -72);
			Date Hour72Back = cal.getTime();
			int NewHr = new Random().nextInt(22) + 1;

			String sMonth = Integer.toString(cal.get(Calendar.MONTH)+1);
			String sYear = Integer.toString(cal.get(Calendar.YEAR));
			String sDay = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
			String sHr = Integer.toString(NewHr);

			sMonth = org.apache.commons.lang.StringUtils.leftPad(sMonth, 2, "0");
			sDay = org.apache.commons.lang.StringUtils.leftPad(sDay, 2, "0");

			if (iChkdigit >= 1 && iChkdigit <= 24)
				sHr = org.apache.commons.lang.StringUtils.leftPad(Integer.toString(iChkdigit), 2, "0");
			else
				sHr = org.apache.commons.lang.StringUtils.leftPad(sHr, 2, "0");

			String sSmplDate = sYear + "-" + sMonth + "-" + sDay + "T" + sHr + ":00:00";
			DateFormat sdtformatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
			cal.setTime(sdtformatter.parse(sSmplDate));

			byte[] data = new byte[8];
			long ltime = cal.getTimeInMillis() / 1000 / TIME_STEP_SECONDS;
			for (int i = 7; ltime > 0; i--) {
				data[i] = (byte) (ltime & 0xFF);
				ltime >>= 8;
			}
			SecretKeySpec signKey = new SecretKeySpec(key, "HmacSHA1");
			Mac imac = Mac.getInstance("HmacSHA1");
			imac.init(signKey);
			byte[] bhash = imac.doFinal(data);
			int ioffset = bhash[bhash.length - 1] & 0xF;
			long ltruncatedHash = 0;
			for (int i = ioffset; i < ioffset + 4; ++i) {
				ltruncatedHash <<= 8;
				ltruncatedHash |= (bhash[i] & 0xFF);
			}
			ltruncatedHash &= 0x7FFFFFFF;
			ltruncatedHash %= 1000000;

			//sCode = frmKey(ltruncatedHash, 4);
            
			
			String hashStr = Long.toString(ltruncatedHash);
			
			sCode = hashStr.substring(hashStr.length()-4, hashStr.length());
			sCode = sCode.substring(0, 2) + sHr.substring(0, 1) + sCode.substring(2, sCode.length())
					+ sHr.substring(1, sHr.length());
			
			// // #NYE00054 begins
			if (db$Ctrl.db$GetRowCnt("ICOR_S_TOTP_VALIDATOR", "{\"Secret\":\""+secret+"\",\"Totp\":\""+sCode+"\"}") > 0)
			{
				sCode = "0X";
			};
			// #NYE00054 ends
			return sCode;
		} catch (Exception e) {
			// logger.debug(e.getMessage());
			e.printStackTrace();
			return null;
		}
		}
		finally
		{
			
		}
	}
	// #NYE00053 End

	public String generateTOTP(String secret) throws GeneralSecurityException {
		try {

			try {
				TIME_STEP_SECONDS = i$ResM.getGobalValJObj("srcJson").get("PassCodeValiditySecs").getAsInt();
			} catch (Exception e) {
				// eat
			}
			byte[] key = ImpactodecodeBase32(secret);
			long currentTimeMillis = System.currentTimeMillis();
			byte[] data = new byte[8];
			long ltime = currentTimeMillis / 1000 / TIME_STEP_SECONDS;
			for (int i = 7; ltime > 0; i--) {
				data[i] = (byte) (ltime & 0xFF);
				ltime >>= 8;
			}
			SecretKeySpec signKey = new SecretKeySpec(key, "HmacSHA1");
			Mac imac = Mac.getInstance("HmacSHA1");
			imac.init(signKey);
			byte[] bhash = imac.doFinal(data);
			int ioffset = bhash[bhash.length - 1] & 0xF;
			long ltruncatedHash = 0;
			for (int i = ioffset; i < ioffset + 4; ++i) {
				ltruncatedHash <<= 8;
				ltruncatedHash |= (bhash[i] & 0xFF);
			}
			ltruncatedHash &= 0x7FFFFFFF;
			ltruncatedHash %= 1000000;
			return frmKey(ltruncatedHash, NUM_DIGITS_OUTPUT);
		} catch (Exception e) {
			logger.debug(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	byte[] ImpactodecodeBase32(String str) {
		int numBytes = ((str.length() * 5) + 4) / 8;
		byte[] result = new byte[numBytes];
		int resultIndex = 0;
		int which = 0;
		int working = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			int val;
			if (ch >= 'a' && ch <= 'z') {
				val = ch - 'a';
			} else if (ch >= 'A' && ch <= 'Z') {
				val = ch - 'A';
			} else if (ch >= '2' && ch <= '7') {
				val = 26 + (ch - '2');
			} else if (ch == '=') {
				which = 0;
				break;
			} else {
				throw new IllegalArgumentException("Unknown base-32 character: " + ch);
			}
			switch (which) {
			case 0:
				working = (val & 0x1F) << 3;
				which = 1;
				break;
			case 1:
				working |= (val & 0x1C) >> 2;
				result[resultIndex++] = (byte) working;
				working = (val & 0x03) << 6;
				which = 2;
				break;
			case 2:
				working |= (val & 0x1F) << 1;
				which = 3;
				break;
			case 3:
				working |= (val & 0x10) >> 4;
				result[resultIndex++] = (byte) working;
				working = (val & 0x0F) << 4;
				which = 4;
				break;
			case 4:
				working |= (val & 0x1E) >> 1;
				result[resultIndex++] = (byte) working;
				working = (val & 0x01) << 7;
				which = 5;
				break;
			case 5:
				working |= (val & 0x1F) << 2;
				which = 6;
				break;
			case 6:
				working |= (val & 0x18) >> 3;
				result[resultIndex++] = (byte) working;
				working = (val & 0x07) << 5;
				which = 7;
				break;
			case 7:
				working |= (val & 0x1F);
				result[resultIndex++] = (byte) working;
				which = 0;
				break;
			}
		}
		if (which != 0) {
			result[resultIndex++] = (byte) working;
		}
		if (resultIndex != result.length) {
			result = Arrays.copyOf(result, resultIndex);
		}
		return result;
	}
}
//#00000001 Ends