/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Feb 2, 2019  | #00000001   | Initial writing
      |0.1 Beta    | Niegil 	| Feb 16 2019  | #NYE00005   | BUGID:000081 - OTP not validated Fixed
      |0.1 Beta    | Vijay	 	| Feb 28 2019  | #BVB00080   | OPT Validation of Ambassador Directly Via Service -- Adding user id to logged in user
      |0.2.1       | Vijay	 	| Mar 01 2019  | #BVB00081   | User Validity Check
      |0.2.1       | Vijay	 	| Mar 01 2019  | #BVB00085   | Adding name to Passcode register response
      |0.3.12      | Vijay 		| Jun 05, 2019  | #BVB00160   | Glabal Validation Logic
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ialgo.ImpactoTOTP;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IpasscodeController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoTOTP i$TOTP = new ImpactoTOTP();
	private OtpController iotp = new OtpController();
	private Logger logger = LoggerFactory.getLogger(IpasscodeController.class); // Nye- Change Class Name
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String sSOpr = i$ResM.getSrvcopr(isonMsg);
			String sSvr = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(sSvr, "ImpactoPasscodeService") && I$utils.$iStrFuzzyMatch(sSOpr, "Register")) {
				return Register$PassCode(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(sSvr, "ImpactoPasscodeService")
					&& I$utils.$iStrFuzzyMatch(sSOpr, "Verify")) {
				return VerifyPassCode(isonMsg);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			logger.debug(e.getMessage());
			return isonMsg;
		}
		return null;
	}

	public boolean Verify$PassCode(String sPassCode) {
		new JsonObject();

		try {
			if (i$TOTP.verifyTOTP(sPassCode)) {
				return true;
			} else {
				return false;
			}
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			return false;
		}
	}

	public JsonObject VerifyPassCode(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		new JsonObject();
		String sPassCode = null;
		try {
			sPassCode = i$body.get("passCode").getAsString();
			// #BVB00080 Starts
			if (i$body.has("userId")) {
				IResManipulator.iloggedUser.set(i$body.get("userId").getAsString());
			}
			// #BVB00080 Ends
			// #BVB00160 Starts
			if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("srcJson").get("Login2FA").getAsString(), "Y")) {
				if (I$utils.$iStrFuzzyMatch(i$ResM.getGobalValJObj("srcJson").get("LoginipassCode").getAsString(), "Y")) {
					// #BVB00160 Ends
					if (i$TOTP.verifyTOTP(sPassCode)) {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS");
					} else {
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID PASSCODE");
					}
				}
			}
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SUCCESS"); // #BVB00160

		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN PASSCODE VALIDATION");
			return isonMsg;
		}
	}

	@SuppressWarnings("null")
	public JsonObject Register$PassCode(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		JsonObject jBody = new JsonObject();
		JsonObject r$ec = new JsonObject();
		JsonObject jblkBody = new JsonObject();
		String sUserID = null;
		String sSecKey = null;
		String sOTP = null;
		try {
			sUserID = i$body.get("userID").getAsString();
			sSecKey = i$body.get("Key").getAsString();
			sOTP = i$body.get("valStr").getAsString();
			if (db$Ctrl.isUserValid(sUserID)) { // #BVB00081
				try {
					r$ec = db$Ctrl.db$GetRow("ICOR_M_ECOMM_REPO",
							"{\"Key_Owner\":\"" + sUserID + "\",\"Key_Mode\":\"UID\"}");
				} catch (Exception e) {
					r$ec = null;
				}

				if (r$ec == null)
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN IMPACTO USER");
				else {
					// Verify The OTP
					JsonObject argJson = new JsonObject();
					argJson.addProperty("otp", sOTP);
					argJson.addProperty("iSecKey", sSecKey);
					if (iotp.verify$OTP(argJson)) {
						// Save to DB
						jBody.addProperty("passIME", i$ResM.getIME(isonMsg));
						db$Ctrl.db$UpdateRow("ICOR_M_ECOMM_REPO", jBody,
								"{\"Key_Owner\":\"" + sUserID + "\",\"Key_Mode\":{\"$regex\": \"[U]\"}}");

						jblkBody.addProperty("succKey", r$ec.get("Key_Token").getAsString());
						// #BVB00085 Starts
						if (r$ec.has("Name")) {
							jblkBody.addProperty("Name", r$ec.get("Name").getAsString());
						}
						// #BVB00085 Ends
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jblkBody);
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
								"USER SUCESSFULLY REGISTERED FOR IMPACTO PASSCODE");
					} else // #NYE00005
					{
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OTP");
					}
				}
			}
			// #BVB00081 Starts
			else {
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN IMPACTO USER");
			}
			// #BVB00081 Ends
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN PASSCODE REGISTRATION");
			return isonMsg;
		}
	}

}
