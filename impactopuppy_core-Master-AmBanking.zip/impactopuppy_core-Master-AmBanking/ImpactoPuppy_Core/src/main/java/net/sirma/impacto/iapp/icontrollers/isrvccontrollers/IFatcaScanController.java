/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Srikanth 	| Dec 14, 2023 | #SRI00026   | Initial writing
      |0.1 Beta    | Srikanth 	| Dec 20, 2023 | #SRI00026   | Handling FATCA profile Scanning
      ----------------------------------------------------------------------------------------------
      
*/

package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

import javax.imageio.ImageIO;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.GenericAppController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IKYCController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IThreadController;
import net.sirma.impacto.iapp.ihelpers.IPDFTextExtractor;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

//#SRI00026 Starts 
public class IFatcaScanController {
	private Logger logger = LoggerFactory.getLogger(IFatcaScanController.class);
	private IResManipulator i$ResM = new IResManipulator();
	private Ioutils I$utils = new Ioutils();
	private DBController db$Ctrl = new DBController();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	private IMbpmContorller imbpm = new IMbpmContorller();
	private IKYCController I$Kyc = new IKYCController();
	private IEmailService i$Email = new IEmailService();
	private ISmsService I$ISmsService = new ISmsService();
	private ImpactoUtil Im$utils = new ImpactoUtil();
	private GenericAppController i$genericCntrlr = new GenericAppController();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SvrOpr = i$ResM.getSrvcopr(isonMsg);
			String SvrName = i$ResM.getSrvcName(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String SOpr = i$ResM.getOpr(isonMsg);
			
			if (I$utils.$iStrFuzzyMatch(SvrName, "cifFatcaScan") && I$utils.$iStrFuzzyMatch(SvrOpr, "CREATE")) {
				isonMsg = createFatcaScan(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "SB2FASCN") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				isonMsg = fatcaScanSummary(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "SB2FADWL") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				isonMsg = fatcaScanDownload(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OB2FATVW") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				getParamterForMember(isonMsg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject createFatcaScan(JsonObject isonMsg) {
		try {
			String sUniqueId = null;
			String referenceNo = null;
			JsonObject i$body = isonMsg.get("i-body").getAsJsonObject();
			if (i$body.has("referenceNo")) {
				sUniqueId = i$body.get("scanId").getAsString();
				referenceNo = i$body.get("referenceNo").getAsString();
			} else {
				sUniqueId = I$Imputils.generateRandomKey();
				referenceNo = I$Imputils.getAlphaNumericId(50);
				i$body.addProperty("referenceNo", referenceNo);
				i$body.addProperty("scanId", sUniqueId);
			}
			int Thread = 10;
			try {
				JsonObject fltr = new JsonObject();
				JsonObject status = new JsonObject();
				String scanId = i$body.get("scanId").getAsString();
				status.addProperty("initiatedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
						.format(Calendar.getInstance().getTime()));
				status.addProperty("scanId", scanId);
				status.addProperty("ScanType", i$body.get("ScanType").getAsString());
				status.addProperty("Status", "WIP");
				fltr.addProperty("scanId", scanId);
				db$Ctrl.db$UpdateRow("ICOR_M_FATCA_SCAN_LOG", status, fltr, "true");
				try { 
	            	String dateforEmail = status.get("initiatedTime").getAsString();
	                jobEmailNotification(i$body.get("ScanType").getAsString(), "Initiated", dateforEmail,scanId);
	            } catch (Exception e) {
	            	e.printStackTrace();
	            	logger.debug("Failed to SendEmailNotification.." + e.getMessage());
	            } 
				for (int i = 0; i < Thread; i++) {
					try {
						JsonObject jWrkArgs = new JsonObject();
						JsonObject jArgs = new JsonObject();
						jArgs.add("isonMsg", isonMsg);
						jArgs.addProperty("threadCount", i);
						jArgs.addProperty("totalNumberOfThreads", Thread);
						jWrkArgs.add("isonMsg", jArgs.deepCopy());
						jWrkArgs.addProperty("clsName",
								"net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFatcaScanController");
						jWrkArgs.addProperty("funcName", "fatcaThreadProcess");
						IThreadController IThread$worker = new IThreadController(jWrkArgs);
						Thread t = new Thread(IThread$worker);
						t.start();
					}catch(Exception e) {
						e.printStackTrace();
						logger.debug("Error description :" + e.getMessage());
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.debug("Error description :" + e.getMessage());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,i$ResM.I_CUSMEM + " Data Scanned failed with: " + e.getMessage());
			}
			return isonMsg;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}
	
	public JsonObject fatcaThreadProcess(JsonObject argJson) {
		try {
			int noOfThread = 0;
			double i$noOfIter = 0;
			int i$noOfIterInt = 0;
			int noOfIterThread = 0;
			int cifCount = 0;
			int threadCount = argJson.get("threadCount").getAsInt();
			noOfThread = argJson.get("totalNumberOfThreads").getAsInt();
			cifCount = db$Ctrl.db$GetCountI("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}");
			double i$noOfIterThreadDbl = Double.valueOf(cifCount) / noOfThread;
			noOfIterThread = (int) Math.ceil(i$noOfIterThreadDbl);
			if (noOfIterThread < 100) {
				i$noOfIter = Double.valueOf(noOfIterThread) / noOfIterThread;
				i$noOfIter = Math.ceil(i$noOfIter);
			} else {
				i$noOfIter = Double.valueOf(noOfIterThread) / 100;
				i$noOfIterInt = (int) Math.ceil(i$noOfIter) * 100;
				i$noOfIter = Double.valueOf(i$noOfIterInt) / 100;
			}
			argJson.addProperty("noOfIter", i$noOfIter);
			argJson.addProperty("noOfIterThreadmem", noOfIterThread);
			argJson.addProperty("threadCount", threadCount);
			argJson.addProperty("noOfIterInt", i$noOfIterInt);
            fatcaScan(argJson);
		}catch (Exception e) {
			e.printStackTrace();
			logger.debug("Error description :" + e.getMessage());
			return i$ResM.iHandleResStat(argJson, i$ResM.I_ERR, "Operation is not completed");
		}
		return argJson;
	}
	
	public JsonObject fatcaScan(JsonObject isonMsg) {
		try {
			Gson gson = new Gson();
			JsonObject i$body = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject i$res = new JsonObject();
			JsonObject status = new JsonObject();
			double i$noOfIter = 0.0;
			i$body = isonMsg.getAsJsonObject("isonMsg").get("i-body").getAsJsonObject();
			String scanId = i$body.get("scanId").getAsString();
			int threadCount = isonMsg.get("threadCount").getAsInt();
			i$noOfIter = isonMsg.get("noOfIter").getAsDouble();
			projection.addProperty("_id", 0);
			
			for (int i = 0; i < i$noOfIter; i++) {
				try {
					JsonObject proj = new JsonObject();
					int i$noOfIterInt = 0;
					i$noOfIterInt = isonMsg.get("noOfIterInt").getAsInt();
					int noOfIterThread = isonMsg.get("noOfIterThreadmem").getAsInt();
					JsonObject cifData = new JsonObject();
					JsonArray cif = new JsonArray();
					JsonObject fltr = new JsonObject();
					JsonObject filter = new JsonObject();
					int skip = 0;
					
					proj.addProperty("_id", 0);
					proj.addProperty("CustomerId", 1); 
					proj.addProperty("CustomerFullName", 1);
					proj.addProperty("PlaceOfBirth", 1);
					proj.addProperty("CustomerNationality", 1);
					proj.addProperty("CustomerResidentCountry", 1);
					proj.addProperty("DualCitizenship", 1);
					proj.addProperty("IdIssCountry", 1);
					proj.addProperty("CustDpIssuedCountryDesc", 1);
					proj.addProperty("PassportIssuedCountry", 1);
					proj.addProperty("CustomerBcIssueCountry", 1);
					proj.addProperty("Permaddcountrydesc", 1);
					
					if (noOfIterThread < 100) {
						skip = noOfIterThread * i;
						skip = skip + (noOfIterThread * threadCount);
						cif = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}", proj, skip, noOfIterThread,"Y");
					} else {
						skip = 100 * i;
						skip = skip + (i$noOfIterInt * threadCount);
						cif = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}", proj, skip, 100, "Y");
					}
					int totalCIFsScanned = 0;
					for (int j = 0; j < cif.size(); j++) {
						try {
							totalCIFsScanned++;
							JsonArray Scan$Array = new JsonArray();
							JsonObject filterthreadLog = new JsonObject();

							cifData = cif.get(j).getAsJsonObject();
							filterthreadLog.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
							filterthreadLog.addProperty("scanId", i$body.get("scanId").getAsString());

							JsonObject beforeUpdate = new JsonObject();
							beforeUpdate.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
							beforeUpdate.addProperty("CustomerFullName", cifData.get("CustomerFullName").getAsString());
							beforeUpdate.addProperty("CreatedAt",
									new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()));
							beforeUpdate.addProperty("scanningStatus", "Initiated");
							beforeUpdate.addProperty("ScanType", i$body.get("ScanType").getAsString());
							beforeUpdate.addProperty("financialYear",
									imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
							beforeUpdate.addProperty("periodCode",
									imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
							db$Ctrl.db$UpdateRow("ICOR_M_FATCA_SCAN", beforeUpdate, filterthreadLog, "true");

							JsonObject placeOfBirthObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("PlaceOfBirth").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("PlaceOfBirth").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("PlaceOfBirth").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("PlaceOfBirth").getAsString(), "USA")) {
								placeOfBirthObject.addProperty("parameterId", "PlaceOfBirth");
								placeOfBirthObject.addProperty("value", "Y");
							} else {
								placeOfBirthObject.addProperty("parameterId", "PlaceOfBirth");
								placeOfBirthObject.addProperty("value", "N");
							}
							Scan$Array.add(placeOfBirthObject);

							JsonObject CustomerNationalityObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("CustomerNationality").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerNationality").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerNationality").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerNationality").getAsString(),
											"USA")) {
								CustomerNationalityObject.addProperty("parameterId", "CustomerNationality");
								CustomerNationalityObject.addProperty("value", "Y");
							} else {
								CustomerNationalityObject.addProperty("parameterId", "CustomerNationality");
								CustomerNationalityObject.addProperty("value", "N");
							}
							Scan$Array.add(CustomerNationalityObject);

							JsonObject CustomerResidentCountryObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("CustomerResidentCountry").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerResidentCountry").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerResidentCountry").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerResidentCountry").getAsString(),
											"USA")) {
								CustomerResidentCountryObject.addProperty("parameterId", "CustomerResidentCountry");
								CustomerResidentCountryObject.addProperty("value", "Y");
							} else {
								CustomerResidentCountryObject.addProperty("parameterId", "CustomerResidentCountry");
								CustomerResidentCountryObject.addProperty("value", "N");
							}
							Scan$Array.add(CustomerResidentCountryObject);

							JsonObject DualCitizenshipObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("DualCitizenship").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("DualCitizenship").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("DualCitizenship").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("DualCitizenship").getAsString(), "USA")) {
								DualCitizenshipObject.addProperty("parameterId", "DualCitizenship");
								DualCitizenshipObject.addProperty("value", "Y");
							} else {
								DualCitizenshipObject.addProperty("parameterId", "DualCitizenship");
								DualCitizenshipObject.addProperty("value", "N");
							}
							Scan$Array.add(DualCitizenshipObject);

							JsonObject IdIssCountryObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("IdIssCountry").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("IdIssCountry").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("IdIssCountry").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("IdIssCountry").getAsString(), "USA")) {
								IdIssCountryObject.addProperty("parameterId", "IdIssCountry");
								IdIssCountryObject.addProperty("value", "Y");
							} else {
								IdIssCountryObject.addProperty("parameterId", "IdIssCountry");
								IdIssCountryObject.addProperty("value", "N");
							}
							Scan$Array.add(IdIssCountryObject);

							JsonObject CustDpIssuedCountryDescObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("CustDpIssuedCountryDesc").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustDpIssuedCountryDesc").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustDpIssuedCountryDesc").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustDpIssuedCountryDesc").getAsString(),
											"USA")) {
								CustDpIssuedCountryDescObject.addProperty("parameterId", "CustDpIssuedCountryDesc");
								CustDpIssuedCountryDescObject.addProperty("value", "Y");
							} else {
								CustDpIssuedCountryDescObject.addProperty("parameterId", "CustDpIssuedCountryDesc");
								CustDpIssuedCountryDescObject.addProperty("value", "N");
							}
							Scan$Array.add(CustDpIssuedCountryDescObject);

							JsonObject PassportIssuedCountryObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("PassportIssuedCountry").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("PassportIssuedCountry").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("PassportIssuedCountry").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("PassportIssuedCountry").getAsString(),
											"USA")) {
								PassportIssuedCountryObject.addProperty("parameterId", "PassportIssuedCountry");
								PassportIssuedCountryObject.addProperty("value", "Y");
							} else {
								PassportIssuedCountryObject.addProperty("parameterId", "PassportIssuedCountry");
								PassportIssuedCountryObject.addProperty("value", "N");
							}
							Scan$Array.add(PassportIssuedCountryObject);

							JsonObject CustomerBcIssueCountryObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("CustomerBcIssueCountry").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerBcIssueCountry").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerBcIssueCountry").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("CustomerBcIssueCountry").getAsString(),
											"USA")) {
								CustomerBcIssueCountryObject.addProperty("parameterId", "CustomerBcIssueCountry");
								CustomerBcIssueCountryObject.addProperty("value", "Y");
							} else {
								CustomerBcIssueCountryObject.addProperty("parameterId", "CustomerBcIssueCountry");
								CustomerBcIssueCountryObject.addProperty("value", "N");
							}
							Scan$Array.add(CustomerBcIssueCountryObject);

							JsonObject PermaddcountrydescObject = new JsonObject();
							if (I$utils.$iStrFuzzyMatch(cifData.get("Permaddcountrydesc").getAsString(), "US")
									|| I$utils.$iStrFuzzyMatch(cifData.get("Permaddcountrydesc").getAsString(),
											"UNITED STATES")
									|| I$utils.$iStrFuzzyMatch(cifData.get("Permaddcountrydesc").getAsString(),
											"UNITED STATES OF AMERICA")
									|| I$utils.$iStrFuzzyMatch(cifData.get("Permaddcountrydesc").getAsString(),
											"USA")) {
								PermaddcountrydescObject.addProperty("parameterId", "Permaddcountrydesc");
								PermaddcountrydescObject.addProperty("value", "Y");
							} else {
								PermaddcountrydescObject.addProperty("parameterId", "Permaddcountrydesc");
								PermaddcountrydescObject.addProperty("value", "N");
							}
							Scan$Array.add(PermaddcountrydescObject);
							i$res.add("scannDetailes", Scan$Array);
							for (int k = 0; k < Scan$Array.size(); k++) {
								try {
									JsonObject param = Scan$Array.get(k).getAsJsonObject();
									String value = param.get("value").getAsString();
									if (I$utils.$iStrFuzzyMatch(value, "Y")) {
										i$res.addProperty("MODEL_CLASS", "FATCA PERSON");
										break;
									} else {
										i$res.addProperty("MODEL_CLASS", "NON FATCA PERSON");
									}
								} catch (Exception e) {
									e.printStackTrace();
									logger.error("Error description : ", e);
								}
							}
							i$res.addProperty("scanningStatus", "Completed");
							filter.addProperty("scanId", scanId);
							filter.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
							db$Ctrl.db$UpdateRow("ICOR_M_FATCA_SCAN", i$res, filter, "true");
							
						}catch(Exception e) {
							e.printStackTrace();
							logger.error("Error description : ", e);
						}
					}
					status.addProperty("totalCIFsScanned", totalCIFsScanned);
					fltr.addProperty("scanId", scanId);
					db$Ctrl.db$UpdateRowOperator("ICOR_M_FATCA_SCAN_LOG", gson.toJson(status), fltr, "true" , "Inc");
				}catch(Exception e) {
					e.printStackTrace();
					logger.error("Error description : ", e);
				}
			}
			
			JsonObject fltr = new JsonObject();
	        JsonObject completedThreads = new JsonObject();
	        threadCount = threadCount + 1;
	        completedThreads.addProperty("CompletedThreads", threadCount);
	        fltr.addProperty("scanId", scanId);
	        db$Ctrl.db$UpdateRowOperator("ICOR_M_FATCA_SCAN_LOG", gson.toJson(completedThreads), fltr, "true", "push");	

	        projection = new JsonObject();
			projection.addProperty("_id", 0);
			fltr.addProperty("scanId", scanId);
			JsonObject counts = db$Ctrl.db$GetRow("ICOR_M_FATCA_SCAN_LOG", fltr, projection);
			int count = counts.get("CompletedThreads").getAsJsonArray().size();
			if (count <= 9) {
	            try {
	                Thread.currentThread().interrupt();
	            } catch (Exception e) {
	            	e.printStackTrace();
	            	logger.error("Error description : ", e);
	            }
	        }
			if (count >= 10) {
				
				JsonObject filter = new JsonObject();
				JsonObject proj = new JsonObject();
				filter.addProperty("scanId", scanId);
				proj.addProperty("_id", 0);
				proj.addProperty("CustomerId", 1);
				proj.addProperty("CustomerFullName", 1);
				proj.addProperty("MODEL_CLASS", 1);
				JsonArray result = db$Ctrl.db$GetRows("ICOR_M_FATCA_SCAN", filter, proj);
				JsonArray modifiedData = new JsonArray();
				for (int i = 0; i < result.size(); i++) {
					try {
						JsonObject currentData = result.get(i).getAsJsonObject();
								try {
									if (!I$utils.$isNull(currentData)) {
										try {
											JsonObject modifiedObject = new JsonObject();
											modifiedObject.addProperty("Member Id",
													currentData.get("CustomerId").getAsString());
											modifiedObject.addProperty("Member Name",
													currentData.get("CustomerFullName").getAsString());
											modifiedObject.addProperty("Fatca Result",
													currentData.get("MODEL_CLASS").getAsString());

											currentData.remove("MODEL_CLASS");
											currentData.remove("CustomerFullName");
											currentData.remove("CustomerId");
											modifiedData.add(modifiedObject);
										} catch (Exception e) {
											e.printStackTrace();
											logger.error("Error description : ", e);
										}
									}
								} catch (Exception e) {
									e.printStackTrace();
									logger.error("Error description : ", e);
								}
					} catch (Exception e) {
						e.printStackTrace();
						logger.error("Error description : ", e);
					}
				}
				JsonArray headers = new JsonArray ();
				headers.add("Member Id");
				headers.add("Member Name");
				headers.add("Fatca Result");
				
				JsonObject reportData = new JsonObject();
				String template= new String();
				reportData.addProperty("scanId", scanId);
				reportData.add("reportResults", modifiedData);
				reportData.addProperty("ReportType", "Fatca Scanning Report");
				reportData.addProperty("fileName", "Fatca Scanning Report");
				reportData.addProperty("CreatedAt", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
				reportData.add("headers", headers);
//				reportData.add("base64Array", new JsonArray());
				db$Ctrl.db$InsertRow("ICOR_M_FATCA_REPORT", reportData);
//				reportHandler(i$body, "fatcaScanning");
				JsonObject Base64 = generateExcelReport(reportData, "fatcaScanning");
				if (Base64.has("ExcelAttachment")) {
					JsonArray excelAttachments = Base64.getAsJsonArray("ExcelAttachment");
					for (JsonElement attachmentElement : excelAttachments) {
						if (attachmentElement.isJsonObject()) {
							JsonObject attachment = attachmentElement.getAsJsonObject();
							if (attachment.has("template")) {
								try {
									JsonObject jobStatus = new JsonObject();
									jobStatus.addProperty("CompletedTime",
											new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
													.format(Calendar.getInstance().getTime()));
									jobStatus.addProperty("Status", "Completed");
									db$Ctrl.db$UpdateRow("ICOR_M_FATCA_SCAN_LOG", jobStatus, fltr, "true");
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					}
				}
					
				try {
					JsonObject projectn = new JsonObject();
					JsonObject sort = new JsonObject();
					String currentDateTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
							.format(Calendar.getInstance().getTime());
					JsonObject updateObj = new JsonObject();
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH);
					Date currentdateFormat = dateFormat.parse(currentDateTime);
							
					sort.addProperty("_id", -1);
					projectn.addProperty("totalHoursOfJobCompletion", 1);
					projectn.addProperty("_id", 0);
					JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projectn);
					filter.addProperty("ScanType", "fatcaScanning");
					JsonArray jData = db$Ctrl.db$GetRows$Sort("ICOR_M_FATCA_SCAN_LOG", filter, projection, sort);
					if (jData.size() > 0) {
							try {
								String updatedDate = jData.get(0).getAsJsonObject().get("initiatedTime").getAsString();
								Date dateUpdateFormat = dateFormat.parse(updatedDate);
								long timeDiffMillis = currentdateFormat.getTime() - dateUpdateFormat.getTime();
								long hoursDiff = TimeUnit.MILLISECONDS.toHours(timeDiffMillis);
//								double totalDiff = timeDiffMillis / (1000 * 60 * 60);
								if (hoursDiff >= cParam.get("totalHoursOfJobCompletion").getAsDouble()) {
									updateObj.addProperty("Status", "Failed");
									db$Ctrl.db$UpdateRow("ICOR_M_FATCA_SCAN_LOG", updateObj, filter);
									return isonMsg;
								}
							} catch (Exception e) {
								e.printStackTrace();
								logger.error("Error description : ", e);
							}
						}
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("Error description : ", e);
				}
				try {
					projection.addProperty("Status", 1);
					projection.addProperty("CompletedTime", 1);
					JsonObject logRec = db$Ctrl.db$GetRow("ICOR_M_FATCA_SCAN_LOG", fltr, projection);
					String job$Status = logRec.get("Status").getAsString();
					if (I$utils.$iStrFuzzyMatch(job$Status, "Completed")) {
						String dateforEmail = logRec.get("CompletedTime").getAsString();
						jobEmailNotification("fatcaScanning", "Completed", dateforEmail, scanId);
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("Error description : ", e);
				}
				}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Error description : ", e);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation is not completed");
		}
		return isonMsg;
	}
	
	public JsonObject fatcaScanSummary (JsonObject isonMsg) {

		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject projectn = new JsonObject();
		JsonArray jArray = new JsonArray();
		JsonObject sort = new JsonObject();
		Gson gson = new Gson();
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		int iRowCnt = 0;
		int intPgNo, intRecs;

		try {
			intPgNo = ibody.get("intPgNo").getAsInt();
		} catch (Exception e) {
			intPgNo = 0;
		}
		try {
			intRecs = ibody.get("intRecs").getAsInt();
		} catch (Exception e) {
			intRecs = 20;
		}
		sort.addProperty("_id", -1);
		try {
			
			projectn.addProperty("_id", 1); 
			projectn.addProperty("scanId", 1);     
			projectn.addProperty("ScanType", 1); 
			projectn.addProperty("totalCIFsScanned", 1);    
			projectn.addProperty("CompletedThreads", 1);
			projectn.addProperty("initiatedTime", 1);
			projectn.addProperty("CompletedTime", 1);
			projectn.addProperty("Status", 1);
			filter.addProperty("ScanType", "fatcaScanning");
			if (ibody.has("dataSetFltr")) {
				try {
					JsonObject j$DataFilter = i$genericCntrlr.get$FrmDataSetFilter(isonMsg);
					JsonObject filterData = db$Ctrl.db$GetRows$Sort("ICOR_M_FATCA_SCAN_LOG", gson.toJson(j$DataFilter),
							projection, intPgNo, intRecs, sort);
					iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_FATCA_SCAN_LOG", j$DataFilter);
					ibody.addProperty("iRowCnt", iRowCnt);
					ibody.add("iRowData", filterData.get("i-body").getAsJsonArray());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");
					isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", ibody);
					return isonMsg;
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("Error description : ", e);
				}
			}
			iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_FATCA_SCAN_LOG", filter);
			jArray = db$Ctrl.db$GetRows$Sort("ICOR_M_FATCA_SCAN_LOG", projectn, sort);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", iRowCnt);
			ibody.add("iRowData", jArray);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error description : ", e);
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEM + " Data Scanned failed with: " + e.getMessage());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jArray);
		}
		return isonMsg;
	}
	
	public JsonObject fatcaScanDownload(JsonObject isonMsg) {
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			Gson gson = new Gson();
			int intPgNo, intRecs;
			String sort = "{'_id':-1}";
			try {
				intPgNo = ibody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = ibody.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 0; 
			}
			JsonObject proj = new JsonObject();
			JsonObject flter = new JsonObject();
			JsonObject projtion = new JsonObject();
			String modelClass = ibody.get("ScanResult").getAsString();
			// To handle FATCA scan view summary screen data
			if (I$utils.$iStrFuzzyMatch(ibody.get("scanType").getAsString(), "fatcaScanning")) {
				try {
					proj.addProperty("_id", 0);
					proj.addProperty("CustomerId", 1);
					proj.addProperty("CustomerFullName", 1);
					proj.addProperty("MODEL_CLASS", 1);
					proj.addProperty("ScanType", 1);
					projtion.addProperty("_id", 0);
					projtion.addProperty("totalCIFsScanned", 1);
					flter.addProperty("scanId", ibody.get("scanId").getAsString());
					flter.addProperty("MODEL_CLASS", modelClass);
					JsonArray result = db$Ctrl.db$GetSummRowsArray("ICOR_M_FATCA_SCAN", gson.toJson(flter), proj,
							intPgNo, intRecs, sort);
					flter.remove("MODEL_CLASS");
					int counts = db$Ctrl.db$GetRow("ICOR_M_FATCA_SCAN_LOG", flter, projtion).getAsJsonObject()
							.get("totalCIFsScanned").getAsInt();
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", counts);
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result);
					return isonMsg;
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("Error description : ", e);
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO GET THE DATA");
					return isonMsg;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error description : ", e);
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO RETRIEVE THE DATA");
			return isonMsg;
		}
		return isonMsg;
	}
	
	public JsonObject getParamterForMember(JsonObject isonMsg) {
		try {
			JsonObject flter = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();

			projection.addProperty("_id", 0);
			projection.addProperty("scannDetailes", 1); 
			projection.addProperty("CustomerId", 1); 
			projection.addProperty("CustomerFullName", 1); 
			projection.addProperty("MODEL_CLASS", 1); 
			flter.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			flter.addProperty("scanId", ibody.get("scanId").getAsString());
			JsonObject customer = db$Ctrl.db$GetRow("ICOR_M_FATCA_SCAN", flter, projection);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", customer);
			return isonMsg;
		}catch(Exception e) {
			e.printStackTrace();
			logger.error("Error description : ", e);
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO DATA FOUND");
			return isonMsg;
		}
	}
	
	public void jobEmailNotification(String ScanType, String currentStatus, String date, String scanId) {
		try {
            JsonObject emailDataset$Data = new JsonObject();
            JsonObject filter = new JsonObject();
            JsonObject projection = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
            filter.addProperty("datasetId", "Dataset_5683");
            projection.addProperty("userDetails", 1);
            projection.addProperty("sendEmail", 1);
            projection.addProperty("sendSms", 1);
            emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
            
            if(!I$utils.$isNull(emailDataset$Data)) {
            	JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
                boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
                boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
                for (int j = 0; j < userDet.size(); j++) {
                    try {
                        if (sendEmail) {
                            JsonObject jsonObject = userDet.get(j).getAsJsonObject();
                            String Email = jsonObject.get("userEmailId").getAsString();
                            keyE = keyE.concat(Email);
                            if (j < userDet.size() - 1) {
                                keyE = keyE.concat(","); 
                            }
                        }
                        if (sendSMS) {
                            JsonObject jsonObject = userDet.get(j).getAsJsonObject();
                            String SMS = jsonObject.get("userMobileNo").getAsString();
                            keyM = keyM.concat(SMS);
                            if (j < userDet.size() - 1) {
                                keyM = keyM.concat(",");
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error("Error description : ", e);
                    }
                }
            }
            try {
            	JsonObject map$Data = new JsonObject();
            	JsonObject attachmentData = new JsonObject();
            	JsonArray attachment = new JsonArray();
                map$Data.addProperty("tmp$name", "TMPL#FATCA#JOB#STATUS#REMINDER");
                map$Data.addProperty("JobType", ScanType);
                map$Data.addProperty("status", currentStatus);
                map$Data.addProperty("initiatedAt", date);
                argJson.add("map$Data", map$Data);  
                if(I$utils.$iStrFuzzyMatch(currentStatus, "Completed")) {
                	String base64 = db$Ctrl.db$GetRow("ICOR_M_FATCA_REPORT", "{\"scanId\":\"" + scanId + "\"}").getAsJsonArray("ExcelAttachment").get(0).getAsJsonObject().get("template").getAsString();
                	argJson.addProperty("template", base64); 
                	attachmentData.addProperty("docType", "application/pdf");
                    attachmentData.addProperty("fileName", "Fatca Report" + ".xls");
                    attachmentData.addProperty("template", base64);
                    attachment.add(attachmentData);
                    argJson.add("attachment", attachment);
                }
                argJson.addProperty("key$Type", "notification");
                argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
                argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
                if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
                    JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
                    JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
                }
            } catch(Exception e) {
            	e.printStackTrace();
            	logger.error("Error description : ", e);
            }
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Error description : ", e);
		}
	}
	
	public void reportHandler(JsonObject isonMsg, String ScanType) {
        try {
            final IPDFTextExtractor I$textExtr = new IPDFTextExtractor();
            String schedulerId = Im$utils.generateRandomString(20);
            Boolean pdfCreated=false;
            String reportType = "";
                JsonObject filter = new JsonObject();
                JsonParser parser = new JsonParser();
                JsonObject projection = new JsonObject();
                projection.addProperty("_id", 0);
                projection.addProperty("reportResults", 1);
                projection.addProperty("ReportType", 1);
                projection.addProperty("fileName", 1);
                projection.addProperty("CreatedAt", 1);
                projection.addProperty("scanId", 1);
                projection.addProperty("headers", 1);
                String scanId = isonMsg.get("scanId").getAsString();
                filter.addProperty("scanId", scanId);
                JsonArray reportsData = new JsonArray();
				if (I$utils.$iStrFuzzyMatch(ScanType, "fatcaScanning")) {  
					 reportsData = db$Ctrl.db$GetRows("ICOR_M_FATCA_REPORT", filter, projection);
				}
                String date = I$utils.$getISONowAm();
                JsonArray attachment = new JsonArray();
                JsonObject filert1Copy = new JsonObject();
                int size = reportsData.size();
				for (int j = 0; j < reportsData.size(); j++) {
					JsonObject update$Data = new JsonObject();
					JsonObject filter1 = new JsonObject();
					String currentStatus = "Failed";
					try {
						JsonObject currentResult = reportsData.get(j).getAsJsonObject();
						Set<String> keyset = currentResult.keySet();
						String strKey = null;
						String fileName = null;
						String base64Str = "";
						JsonObject ibody = new JsonObject();
						JsonArray arrKey = new JsonArray();
						for (String key : keyset) {
							try {
								strKey = currentResult.get(key).getAsString();
								if (I$utils.$iStrFuzzyMatch(key, "fileName")) {
									fileName = strKey;
								} else if (I$utils.$iStrFuzzyMatch(key, "ReportType")) {
									reportType = strKey;
								}
							} catch (Exception e) {
								if (I$utils.$iStrFuzzyMatch(key, "reportResults")) {
									arrKey = currentResult.get(key).getAsJsonArray();
								}
							}
						}
						String columns = "['Sl.No',";
						String columnNames = "['Sl.No',";
						JsonObject funcData = new JsonObject();
						JsonObject attachmentData = new JsonObject();
						JsonArray clms = new JsonArray();
						JsonArray columnName = new JsonArray();
						if (arrKey.size() > 0) {
							for (int i = 0; i < 1; i++) {
								try {
									JsonObject runningObject = arrKey.get(i).getAsJsonObject();
									Set<String> keys = runningObject.keySet();
									int keysCount = 0;
									for (String key1 : keys) {
										try {
											if (keysCount == 0) {
												columns = columns + "'" + key1 + "'";
												columnNames = columnNames + "'" + key1 + "'";
												keysCount++;
											} else {
												columns = columns + "," + "'" + key1 + "'";
												columnNames = columnNames + "," + "'" + key1 + "'";
											}

										} catch (Exception e) {
										}
									}
									columns = columns + "]";
									columnNames = columnNames + "]";
								} catch (Exception e) {
								}
							}
							clms = parser.parse(columns).getAsJsonArray();
							columnName = parser.parse(columnNames).getAsJsonArray();
						} else {

							if (currentResult.has("headers")
									&& currentResult.get("headers").getAsJsonArray().size() > 0) {
								for (int i = 0; i < 1; i++) {
									try {
										JsonObject runningObject = currentResult.get("headers").getAsJsonArray().get(i)
												.getAsJsonObject();
										Set<String> keys = runningObject.keySet();
										int keysCount = 0;
										for (String key1 : keys) {
											try {
												if (keysCount == 0) {
													columns = columns + "'" + key1 + "'";
													columnNames = columnNames + "'" + key1 + "'";
													keysCount++;
												} else {
													columns = columns + "," + "'" + key1 + "'";
													columnNames = columnNames + "," + "'" + key1 + "'";
												}

											} catch (Exception e) {
											}
										}
										columns = columns + "]";
										columnNames = columnNames + "]";
									} catch (Exception e) {
									}
								}
								clms = parser.parse(columns).getAsJsonArray();
								columnName = parser.parse(columnNames).getAsJsonArray();
							}
						}
						funcData.addProperty("scanId", scanId);
						funcData.add("columns", clms);
						funcData.add("rowData", arrKey);
						funcData.add("columnNames", columnName);
						funcData.addProperty("noOfColumns", clms.size());
						funcData.addProperty("fileName", fileName);
						funcData.addProperty("ReportType", reportType);
						ibody.add("i-body", funcData);
						ibody = generatePDFReport(ibody);
//						ibody = generateExcelReport(ibody);
						base64Str = ibody.get("i-body").getAsJsonObject().get("report").getAsString();
						if (!I$utils.$iStrFuzzyMatch(base64Str, "null")) {
							pdfCreated = true;
							currentStatus = "Completed";
						}
						attachmentData.addProperty("docType", "application/pdf");
						attachmentData.addProperty("fileName", fileName);
						attachmentData.addProperty("template", base64Str);
						attachment.add(attachmentData);
						filter1.addProperty("scanId", scanId);
						filter1.addProperty("ReportType", reportType);

						currentResult.remove("reportResults");
						update$Data = currentResult.deepCopy();

						update$Data.add("completedAt", i$ResM.adddate(new Date()));
						update$Data.addProperty("schedulerId", schedulerId);
						update$Data.addProperty("financialYear",
								imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
						update$Data.addProperty("periodCode",
								imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
						update$Data.addProperty("template", base64Str);
						update$Data.addProperty("Status", currentStatus);
						if (I$utils.$iStrFuzzyMatch(ScanType, "fatcaScanning")) {
							db$Ctrl.db$Remove("ICOR_M_FATCA_REPORT", filter1);// #SRI00027 Changes
							JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_FATCA_REPORT", update$Data, filter1,
									"true");
						}
					} catch (Exception e) {
						update$Data.addProperty("Status", currentStatus);
						JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_FATCA_REPORT", update$Data, filter1, "true");
					}
				}
                
                JsonObject dataSetFilter = new JsonObject();
                JsonObject datasetProjection = new JsonObject();
                JsonObject emailDataset$Data = new JsonObject();
                String keyE = new String();
                String keyM = new String();
                JsonObject argJson = new JsonObject();
                dataSetFilter.addProperty("datasetId", "Dataset_5683");
                datasetProjection.addProperty("userDetails", 1);
                datasetProjection.addProperty("sendEmail", 1);
                datasetProjection.addProperty("sendSms", 1);
                emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
                if (!I$utils.$isNull(emailDataset$Data)) {
                    JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
                    boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
                    boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
                    for (int i1 = 0; i1 < userDet.size(); i1++) {
                        try {
                            if (sendEmail) {
                                JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
                                String Email = jsonObject.get("userEmailId").getAsString();
                                keyE = keyE.concat(Email);
                                if (i1 < userDet.size() - 1) {
                                    keyE = keyE.concat(",");
                                }
                            }
                            if (sendSMS) {
                                JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
                                String SMS = jsonObject.get("userMobileNo").getAsString();
                                keyM = keyM.concat(SMS);
                                if (i1 < userDet.size() - 1) {
                                    keyM = keyM.concat(",");
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
//                    try {
//                        JsonObject map$Data = new JsonObject();
//                        map$Data.addProperty("tmp$name", "TMPL#FATCA#JOB#STATUS#REMINDER");
//                        argJson.add("map$Data", map$Data);
//                        argJson.addProperty("key$Type", "notification");
//                        argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
//                        argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
//                        argJson.add("attachment", attachment);
//                        if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
//                            JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
//                            JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
//                            JsonObject statusMsg = i$resE.get("i-stat").getAsJsonObject();
//                            JsonObject filter2=new JsonObject();
//                            filter2.addProperty("scanId", scanId);
//                            filter2.addProperty("ReportType", reportType);
//                            	                    if (statusMsg.has("i-statMsg")) {//#PAV00018 Changes
//                            	                        JsonObject update$Data = new JsonObject();
//                            	                        update$Data.addProperty("reportsent", "true");
//                            	                        update$Data.add("reportsentAT", i$ResM.addDateTime(new Date()));
//                            	                        JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", update$Data, filter2, "true");
//                            
//                            	                    }
//                        }
//                    } catch (Exception e) {
//                        logger.debug("Failed to send email and sms" + e.getMessage());
//                    }
                } else {
                    logger.debug("Failed to find Email/Mobile for Alert.");
                }
            } catch (Exception e) {}
        
	}
	 
	public JsonObject generateExcelReport(JsonObject isonMsg, String ScanType) {
		JsonObject argJson = new JsonObject();
		JsonObject resp = new JsonObject();
		JsonObject update$Data = new JsonObject();
		JsonArray attachment = new JsonArray();
		JsonObject exlattachmentData = new JsonObject();
		JsonObject filter1 = new JsonObject();
		String dateforEmail = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
				.format(Calendar.getInstance().getTime());
		String scanId = isonMsg.get("scanId").getAsString();
		JsonArray rowData = isonMsg.getAsJsonArray("reportResults");
		try {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sh = wb.createSheet("Sheet1");
			HSSFRow row = sh.createRow(0);
			HSSFFont i$font = wb.createFont();
			sh.setColumnWidth(0, 4000);
			sh.setColumnWidth(1, 4000);
			sh.setColumnWidth(2, 4000);
			sh.setColumnWidth(3, 4000);
			sh.setColumnWidth(4, 4000);
			sh.setColumnWidth(5, 4000);
			sh.setColumnWidth(6, 4000);
			sh.setColumnWidth(7, 4000);
			sh.setColumnWidth(8, 4000);
			sh.setColumnWidth(9, 4000);
			HSSFCellStyle style = wb.createCellStyle();
			row.setRowStyle(style);
			int rowCount = 0;
			int slNoCounter = 0;
			String[] headings = { "Sl.No", "Member Id", "Member Name", "Fatca Result" };
			for (int i = 0; i < headings.length; i++) {
				row.createCell(i).setCellValue(headings[i]);
				i$font.setFontName(headings[i]);
				i$font.setColor(IndexedColors.BLACK.getIndex());
				i$font.setBold(true);

			}
			for (int i = 0; i < rowData.size(); i++) {
				String slNo = null, memID = null, memName = null, result = null;
				try {
					JsonObject rec = rowData.get(i).getAsJsonObject();
					try {
						slNo = String.valueOf(++slNoCounter);
					} catch (Exception e) {
					}
					try {
						memID = rec.get("Member Id").getAsString();
					} catch (Exception e) {
					}
					try {
						memName = rec.get("Member Name").getAsString();
					} catch (Exception e) {
					}
					try {
						result = rec.get("Fatca Result").getAsString();
					} catch (Exception e) {
					}

					row = sh.createRow(++rowCount);
					Cell cell1 = row.createCell(0);
					cell1.setCellValue(slNo);
					Cell cell2 = row.createCell(1);
					cell2.setCellValue(memID);
					Cell cell3 = row.createCell(2);
					cell3.setCellValue(memName);
					Cell cell4 = row.createCell(3);
					cell4.setCellValue(result);
				} catch (Exception e) {

				}
			}

			wb.write(outputStream);
			byte[] exlBytes = outputStream.toByteArray();
			String base64String = Base64.getEncoder().encodeToString(exlBytes);
			exlattachmentData.addProperty("docType", "application/pdf");
			exlattachmentData.addProperty("fileName", "Fatca Report" + ".xls");
			exlattachmentData.addProperty("template", base64String);
			attachment.add(exlattachmentData);
			argJson.add("ExcelAttachment", attachment);
			if (I$utils.$iStrFuzzyMatch(ScanType, "fatcaScanning")) {
				JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_FATCA_REPORT", argJson, filter1, "true");
			}
		} catch (Exception e) {

		}
		return argJson;
	}
	
	
	public JsonObject generatePDFReport(JsonObject isonMsg) {
	    try {
	        JsonObject resp = new JsonObject();
	        JsonObject ibody = isonMsg.getAsJsonObject("i-body");
	        String scanId= ibody.get("scanId").getAsString();
	        JsonArray columns = ibody.getAsJsonArray("columns");
	        JsonArray columnNames = ibody.getAsJsonArray("columnNames");
	        JsonArray rowData = ibody.getAsJsonArray("rowData");
	        String base64 = null;
	        JsonObject tempFilter = new JsonObject();
	        tempFilter.addProperty("scanId", scanId);
	        int s = 0;
	        JsonObject updateObj = new JsonObject();
	        JsonObject updateObjS = new JsonObject();
	        int batchSize = 2500; // Adjust the batch size based on your requirements
	        int totalRows = rowData.size();

	        JsonArray listofbase = new JsonArray();
	        
	        for (int start = 0; start < totalRows; start += batchSize) {
	            int end = Math.min(start + batchSize, totalRows);
	            JsonArray batchRowData = getBatchRowData(rowData, start, end);
	            JsonObject base64Data = processBatchRows(ibody, columns, columnNames, batchRowData, resp, scanId);
	            base64 = base64Data.get("report").getAsString();
	            listofbase.add(base64);
//	            updateObj.addProperty("array"+s+1, base64);
//	            base64Arr.add(updateObj);
//	            updateObjS.add("base64Array", updateObj);
			}
			
	        int index = 1;
	        for (JsonElement base64Obj : listofbase) {
	            String base64String = base64Obj.getAsString(); // Get the base64 string
	            // Add each base64 string to the update object
	            updateObj.addProperty("array" + index, base64String);
	            index++;
	        }
	        updateObjS.add("base64Array", updateObj);
	        isonMsg = db$Ctrl.db$UpdateRow("ICOR_M_FATCA_REPORT", updateObjS, tempFilter, "true");
	        return isonMsg;
	    } catch (Exception e) {
	        e.printStackTrace();
	        // Handle exceptions
	    }
	    return null;
	}
	
	public JsonArray getBatchRowData(JsonArray rowData, int start, int end) {
	    JsonArray batchRowData = new JsonArray();
	    for (int i = start; i < end; i++) {
	        batchRowData.add(rowData.get(i));
	    }
	    return batchRowData;
	}

	public JsonObject processBatchRows(JsonObject ibody, JsonArray columns, JsonArray columnNames,
	                              JsonArray batchRowData, JsonObject resp, String scanId) {
	    try {
	        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	        Document document = new Document(PageSize.A4.rotate(), 0.75F, 0.75F, 0.75F, 0.75F);
	        document.setMargins(10, 10, 150, 50);
	        PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
	        HeaderPageEvent headerEvent = new HeaderPageEvent();
	        writer.setPageEvent(headerEvent);
	        headerEvent.onStartPage(writer, document);
	        document.open();

	        PdfPTable table = new PdfPTable(ibody.get("noOfColumns").getAsInt());
	        if (ibody.get("noOfColumns").getAsInt() > 0) {
	            for (int i = 0; i < ibody.get("noOfColumns").getAsInt(); i++) {
	                try {
	                    PdfPCell cell = new PdfPCell(new Phrase(columnNames.get(i).getAsString()));
	                    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	                    cell.setBackgroundColor(BaseColor.WHITE);
	                    table.addCell(cell);
	                } catch (Exception e) {
	                }
	            }
	            if (batchRowData.size() > 0) {
	                table.setHeaderRows(1);
	            } else {
	                table.setWidthPercentage(100);
	            }
	        }

	        PdfPTable table1 = new PdfPTable(1);
	        if (batchRowData.size() <= 0) {
	            table1.setWidthPercentage(100);
	            table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	            table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table1.getDefaultCell().setFixedHeight(100);
	            table1.addCell(new Paragraph("No records found !!"));
	        } else {
	            getBatchData(table, ibody, batchRowData, document);
	        }
	        document.add(table);
	        document.add(table1);
	        document.close();

	        int pageCount = writer.getPageNumber();
	        byte[] pdfAsBytes = byteArrayOutputStream.toByteArray();
	        Font smallFont = FontFactory.getFont("Arial", 13, Font.NORMAL);
	        Font smallFont2 = FontFactory.getFont("Arial", 16, Font.BOLD);
	        PdfReader reader = new PdfReader(pdfAsBytes);
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        DataOutputStream output = new DataOutputStream(outputStream);
	        document = new Document();
	        document.open();
	        PdfStamper stamper = new PdfStamper(reader, output);
	        for (int i = 1; i <= pageCount; i++) {
	            ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_LEFT,
	                    new Phrase(ibody.get("ReportType").getAsString(), smallFont2), 10, 470, 0);

	            ColumnText.showTextAligned(stamper.getOverContent(i), Element.ALIGN_CENTER,
	                    new Phrase(i + "/" + pageCount, smallFont), 400, 30, 0);
	        }
	        stamper.close();
	        byte[] finalPdfAsBytes = outputStream.toByteArray();
	        String base64String = java.util.Base64.getEncoder().encodeToString(finalPdfAsBytes);
	        resp.addProperty("scanId", scanId);
	        resp.addProperty("fileName", ibody.get("fileName").getAsString());
	        resp.addProperty("report", base64String);
	        return resp;
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return resp;
	}
	class HeaderPageEvent extends PdfPageEventHelper {
		private Font COURIER = new Font(Font.FontFamily.COURIER, 20, Font.BOLD);

		public void onStartPage(PdfWriter writer, Document document) {
			try {
				int pageNo = writer.getPageNumber();
				Image headerImg = null;
				RenderedImage renderedImage = null;
				ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
				if (pageNo >= 0) {
					try {
						URL url = new URL("https://tech-u.tecutt.com/resources/images/logo/logo_login_lg.png");
						renderedImage = javax.imageio.ImageIO.read(url);
						ImageIO.write(renderedImage, "png", byteImg);
						byte[] byteArr = byteImg.toByteArray();
						headerImg = Image.getInstance(byteArr);
						headerImg.setAbsolutePosition(220, 500);
						headerImg.scaleAbsolute(300, 50);
						float width = headerImg.getScaledWidth();
						float height = headerImg.getScaledHeight();
						headerImg.setAlignment(Element.ALIGN_CENTER);
						writer.getDirectContent().addImage(headerImg);
					} catch (Exception e) {
						e.printStackTrace();
					}
					try {
						Paragraph p1 = new Paragraph();
						IPDFTextExtractor.leaveEmptyLine(p1, 3);
						writer.add(p1);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} catch (Exception e) {
			}
		}
	}

	public void getBatchData(PdfPTable table, JsonObject ibody, JsonArray batchRowData, Document document) {
	    try {
	        JsonArray columns = ibody.getAsJsonArray("columns");
	        int index = 1;

	        for (int i = 0; i < batchRowData.size(); i++) {
	            try {
	                JsonObject row = batchRowData.get(i).getAsJsonObject();
	                for (int j = 0; j < columns.size(); j++) {
	                    try {
	                        table.setWidthPercentage(100);
	                        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	                        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	                        if (j == 0) {
	                            table.addCell(String.valueOf(index++));
	                            continue;
	                        }
	                        table.addCell(row.get(columns.get(j).getAsString()).getAsString());
	                    } catch (Exception e) {
	                        logger.debug(e.getMessage());
	                    }
	                }
	            } catch (Exception e) {
	            }
	        }
	    } catch (Exception e) {
	        e.getMessage();
	    }
	}
		
	}
//#SRI00026 Ends 