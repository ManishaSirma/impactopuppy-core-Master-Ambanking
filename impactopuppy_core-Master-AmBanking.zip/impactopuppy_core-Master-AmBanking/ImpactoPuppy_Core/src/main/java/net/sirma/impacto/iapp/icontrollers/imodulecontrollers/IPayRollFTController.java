/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Madhura 		| Oct 12, 2022 | #MSA00001   | Initial writing
      ----------------------------------------------------------------------------------------------
*/
// #SKP00001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IPayRollFTController {
    // *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

    private DBController db$Ctrl = new DBController();
    private Ioutils I$utils = new Ioutils();
    private IResManipulator i$ResM = new IResManipulator();
    private IEmailService mail = new IEmailService();
    private static final Logger logger = LoggerFactory.getLogger(IKYCController.class);
    private IAppMessageHandler iAppMsgHandler = new IAppMessageHandler();
    JsonObject thread$isonMsg = new JsonObject();
    JsonObject thread$isonheader = new JsonObject();
    JsonObject thread$isonMapJson = new JsonObject();
    JsonObject ibody = new JsonObject();
    JsonObject icbsbody = new JsonObject();
    String rCollName = null;
    String userid = null;

    public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
        try {
            String SOpr = i$ResM.getOpr(isonMsg);
            String Scr = i$ResM.getScreenID(isonMsg);
            if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
                userid = IResManipulator.iloggedUser.get();
                thread$isonMsg = isonMsg;
                thread$isonheader = isonheader;
                thread$isonMapJson = isonMapJson;
                return createKYCApln(isonMsg, isonheader, isonMapJson);
            }else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
            	return memNoPayRl(isonMsg);
            }else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
            	return queryApln(isonMsg);
            }
            else {
                isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
            }
        } catch (Exception e) {
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
            e.printStackTrace();
            return isonMsg;
        }
        return null;
    }

    public JsonObject createKYCApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
        JsonObject jBody = new JsonObject();
        String sRef = null;
        String Coll_Name = "";
        String DcStatus = null;
        String ScrCtrlClass = null;
        String sAppNumber = null;
        jBody = i$ResM.getBody(isonMsg);
        String custAcNo = jBody.get("creditAccNo").getAsString();
        // remove the _id from the body if it exist
        try {
            jBody.remove("_id");
        } catch (Exception e) {
            // pass
        }

        try {
            JsonObject jFilter = new JsonObject();

            try {
                Coll_Name = isonMapJson.get("COLLNAME").getAsString();
            } catch (Exception e) {
                Coll_Name = null;
            };
            // #Va000026 Begins
            sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
            sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
            DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
            ZonedDateTime now = ZonedDateTime.now();
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
                i$ResM.adddate(Date.from(now.toInstant())).getAsJsonObject());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
                IResManipulator.iloggedUser.get());

            String qry$up = "{$and:[{\"applicationId\":\"" + sAppNumber + "\", \"referenceNo\" : {$ne:\"" + sRef +
                "\"}, \"isCurrVer\":\"Y\"}]}";

            String srefqry = "{$ne: \"" + sRef + "\"}";
            JsonObject subqry = new JsonObject();
            subqry.addProperty("$ne", sRef);
            jFilter.add("referenceNo", subqry.getAsJsonObject());
            jFilter.addProperty("applicationId", sAppNumber);
            // String ftr$qry = "{\"applicationId\":\""+sAppNumber+"\",\"referenceNo\":{$ne:
            // \""+sRef+"\"}}";
            JsonObject $update = new JsonObject();
            $update.addProperty("isCurrVer", "N");
            db$Ctrl.db$UpdateRow(Coll_Name, $update, jFilter);
            db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", $update, jFilter);

            // WOrkflow Status
            JsonObject fltr = new JsonObject();
            JsonObject projection = new JsonObject();
            JsonObject cifData = new JsonObject();
            fltr.addProperty("CustomerId", jBody.get("custNo").getAsString());
            fltr.addProperty("Active", "A");
            projection.addProperty("CustomerFullName", 1);
            cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr , projection);
            jFilter = new JsonObject();
            jFilter.addProperty("applicationId", sAppNumber);
            jFilter.addProperty("referenceNo", sRef);
            JsonObject Appl$Json = new JsonObject();
            Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);

            if (!(Appl$Json != null)) {
            	jBody.addProperty("CustomerFullName", cifData.get("CustomerFullName").getAsString());
            	jBody.addProperty("isCurrVer", "Y");
                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
            } else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
            } else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
            } else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED")) ||
                (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
            } else {
                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
            }

            jBody.addProperty("referenceNo", sRef);
            JsonObject Jbdy = new JsonObject();
            // trigger Workflow
            if (I$utils.$iStrFuzzyMatch(DcStatus, "Complete")) {

                updateReferDcStatus(sAppNumber, Coll_Name);
                //#PKY00025 starts
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", IResManipulator.iloggedUser.get());
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);

                jFilter.addProperty("applicationId", sAppNumber);
                jFilter.addProperty("referenceNo", sRef);
                db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");

                // Fwd the Control to Workflow COntroller.
                ExecutorService executor = Executors.newFixedThreadPool(1); // creating a pool of threads
                for (int i = 0; i < 1; i++) {
                    Runnable worker = new imbpmFromLincuFwdThread(isonMsg, isonheader, isonMapJson);
                    executor.execute(worker); // calling execute method of ExecutorService
                }
                //executor.shutdown();
                //while (!executor.isTerminated()) {
                //}

                logger.debug("Finished all threads");
                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");

            } else {
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
                return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
            } //#PKY00025 ends
            // Workflow loop End
        } catch (Exception es) {
            es.printStackTrace();
            logger.debug(es.getMessage());
            jBody.addProperty("referenceNo", sRef);
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jBody);
            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN APPLICATION REGISTRATION");
            return isonMsg;
        }
    }
    // #Va000027 Begins
    public void updateReferDcStatus(String sAppNumber, String Coll_Name) {
        // Change the rejected application queue so that application may not appear in
        // rejected list
        try {
            JsonObject jFlter = new JsonObject();
            jFlter.addProperty("applicationId", sAppNumber);
            JsonObject Apl$Json = new JsonObject();
            Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
            if (Apl$Json != null) {
                if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
                    jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
                    JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
                    if (task$Json != null) {
                        task$Json.addProperty("Queue", "ReferDcResubmit");
                        db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // #Va000027 Ends
    // #BVB00033 Ends

    public JsonObject queryApln(JsonObject isonMsg) {
    	try {
    		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
    		JsonObject filter = new JsonObject();
    		JsonObject appData = new JsonObject();
    		filter.addProperty("applicationId", ibody.get("applicationId").getAsString());
    		filter.addProperty("isCurrVer", "Y");
    		appData = db$Ctrl.db$GetRow("ICOR_C_PAYROLL_CIF_FT_COLL", filter);
    		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, appData);
    		i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Record Successfully Retrieved");
    	}catch(Exception e) {}
    	return isonMsg;
    }
    
    public JsonObject memNoPayRl(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonArray i$CustDet =new JsonArray();
		JsonObject i$row = new JsonObject();
		try {
			String keyMode = i$ResM.getBodyElementS(isonMsg, "Key_Mode");
			String keyValue = i$ResM.getBodyElementS(isonMsg, "Key_Value");
			String classType = i$ResM.getBodyElementS(isonMsg, "AccountClassType");
			String Sopr2 = i$ResM.getOpr2(isonMsg);
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			filter.addProperty("CustNo",keyValue );
			filter.addProperty("AccountClassType",classType );
			projection.addProperty("CustNo",1);
			projection.addProperty("CustAcNo",1);
			projection.addProperty("_id",0);
			try {
				if (I$utils.$iStrFuzzyMatch(keyMode, "CID")) {
					i$CustDet = db$Ctrl.db$GetRows("ICOR_M_CBS_ACCOUNT_DATA",filter,projection);
					i$body.add("iRow_Data",i$CustDet);
				}
			}catch(Exception e) {
				
			}
		}catch(Exception e) {
			
	}
	return isonMsg;
	}
    
    public JsonObject escalateApln(JsonObject isonMsg) {
    	try {

    		try {
    			JsonObject flter = new JsonObject();
    			JsonObject filter = new JsonObject();
    			JsonObject custSvr$Object = new JsonObject();
    			JsonObject control$Json = new JsonObject();
    			JsonObject stg$LfeCycle = new JsonObject();
    			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
    			flter.addProperty("applicationId", ibody.get("applicationId").getAsString());
    			flter.addProperty("referenceNo", ibody.get("referenceNo").getAsString());
    			flter.addProperty("isCurrVer", "Y");
    			JsonObject custSvrData = db$Ctrl.db$GetRow("ICOR_C_B2U_CUSTSVR_APPLICATION", flter);
    			JsonObject arg$Json = db$Ctrl.db$GetRow("ICOR_M_IM_BPM",
    					"{\"WORKFLOWID\":\"" + "IMPACTO_CUSTSVR_WORKFLOW" + "\"}");
    			control$Json = arg$Json.get("CONTROL_JSON").getAsJsonObject();
    			stg$LfeCycle = control$Json.get("STGLIFECYCLE").getAsJsonObject();
    			JsonObject stgName = stg$LfeCycle.get("2").getAsJsonObject();
    			
    			// To check hold applications
    			if (I$utils.$iStrFuzzyMatch(custSvrData.get("status").getAsString(), "Hold")) {
    				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
    						"The Operation Cannot be perform because the application is on Hold");
    				return isonMsg;
    			}
//    			if (!I$utils.$iStrFuzzyMatch(custSvrData.get("amlCheck").getAsString(), "Y")
//    					&& !I$utils.$iStrFuzzyMatch(custSvrData.get("isCurrVer").getAsString(), "Y")) {
//    				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid application");
//    				return isonMsg;
//    			}
    			// To handle escalate functionality
    			if (I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "ESCALATE") || I$utils.$iStrFuzzyMatch(ibody.get("status").getAsString(), "REFER_USER")) {
    				try {
    					JsonObject updat$Object = new JsonObject();
    					JsonObject projection = new JsonObject();
    					JsonObject argJson = new JsonObject();
    					
    					projection.addProperty("_id", 0);
    					projection.addProperty("name", 1);
    					projection.addProperty("roles", 1);
    					projection.addProperty("userId", 1);
    					projection.addProperty("EmpMail", 1);
    					filter.addProperty("userId", ibody.get("userId").getAsString());
    					JsonObject userData = db$Ctrl.db$GetRow("ICOR_M_USER_PRF", filter, projection).getAsJsonObject();
    					
    					if (!I$utils.$iExistsInArrayJ(userData.get("roles").getAsJsonArray(), "SUPER_ROLE")) {
    						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "User do not have access for this Queue");
    						return isonMsg;
    					}
    					custSvr$Object.addProperty("USER", userData.get("name").getAsString());
    					custSvr$Object.addProperty("applicationId", custSvrData.get("applicationId").getAsString());
    					custSvr$Object.addProperty("cif", custSvrData.get("cif").getAsString());
    					custSvr$Object.addProperty("criteria", custSvrData.get("criteria").getAsString());
    					custSvr$Object.addProperty("nature", custSvrData.get("nature").getAsString());
    					custSvr$Object.addProperty("priority", custSvrData.get("priority").getAsString());
    					custSvr$Object.addProperty("tmp$name", "TMPL#TT#ESCALATE#CUSTSVR#ALERT#MAIL");
    					try {
    						String mailId = userData.get("EmpMail").getAsString();
    						argJson.add("map$Data", custSvr$Object);
    						argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + mailId + "\"}"));
    						mail.SendEmailWOThread(argJson);
    					} catch (Exception e) {
    						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Please Update Your Email Id on User Profile Maintenance Screen.");
    					}
    					updat$Object.addProperty("status", ibody.get("status").getAsString());
    					updat$Object.addProperty("remarks", ibody.get("remarks").getAsString());
    					updat$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
    					updat$Object.addProperty("TaskAssignedTo", userData.get("userId").getAsString());
    					updat$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
    					updat$Object.addProperty("lastActionAt",
    							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
    									.format(Calendar.getInstance().getTime()));
    					db$Ctrl.db$UpdateRow("ICOR_C_B2U_CUSTSVR_APPLICATION", updat$Object, flter);
    					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
    				} catch (Exception e) {
    					e.printStackTrace();
    				}
    			}
    			else{
    				try {
    					JsonObject updat$Object = new JsonObject();
    					
    					if (I$utils.$iStrFuzzyMatch(custSvrData.get("status").getAsString(), "ESCALATE")
    							|| I$utils.$iStrFuzzyMatch(custSvrData.get("status").getAsString(), "REFER_USER")) {
    						if (!I$utils.$iStrFuzzyMatch(custSvrData.get("TaskAssignedTo").getAsString(), IResManipulator.iloggedUser.get())) {
    							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, IResManipulator.iloggedUser.get()
    									+ " This User Does Not Have Access for this Application. ");
    							return isonMsg;
    						}
    					}
    					updat$Object.addProperty("status", ibody.get("status").getAsString());
    					updat$Object.addProperty("remarks", ibody.get("remarks").getAsString());
    					updat$Object.addProperty("lastActionBy", IResManipulator.iloggedUser.get());
    					updat$Object.addProperty("WorkFlowStatus", stgName.get("STGNAME").getAsString());
    					updat$Object.addProperty("lastActionAt",
    							new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH)
    									.format(Calendar.getInstance().getTime()));
    					db$Ctrl.db$UpdateRow("ICOR_C_B2U_CUSTSVR_APPLICATION", updat$Object, flter);
    					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Application Updated Successfully");
    				} catch (Exception e) {
    					e.printStackTrace();
    				}
    			}
    		} catch (Exception e) {
    			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation Failed");
    			return isonMsg;
    		}
    		return isonMsg;
    	
    	}catch(Exception e) {
    		
    	}
    	return isonMsg;
    }
    
    // Threading for calling IMBPM Controller // #BZ00002 change begins
    class imbpmFromLincuFwdThread implements Runnable {
        private String message;
        JsonArray flght$Opr;
        JsonObject iosnMsg;
        JsonObject isonMapJson;
        JsonObject isonheader;

        public imbpmFromLincuFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
            this.message = "RUN";
            this.iosnMsg = isonMsg;
            this.isonMapJson = isonMapJson;
            this.isonheader = isonheader;
        }

        public void run() {
            logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
            logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
            JsonObject i$res = mirrorController(iosnMsg, isonMapJson, isonheader); // call processmessage method that
            // sleeps the
            // logger.debug("Thread Result" + i$res.toString());
            logger.debug(Thread.currentThread().getName() + " (End)"); // prints thread name
        }
    }

    // #Va000029 change begins
    public JsonObject mirrorController(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

        try {
            JsonObject Jbdy = new JsonObject();
            JsonObject jBody = new JsonObject();
            jBody = i$ResM.getBody(isonMsg);
            String sRef = null;
            String Coll_Name = "";
            String DcStatus = null;
            String ScrCtrlClass = null;
            String sAppNumber = null;

            JsonObject jFilter = new JsonObject();
            // Redirecting to Create KYC application workflow
            sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
            sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
            // DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
            // update the referDc Applicaiton
            JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP",
                "{\"SCRID\":" + i$ResM.getScreenID(isonMsg) + "}", "{\"WORKFLOW\":1}");

            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
                i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
            // #DVJ00032 Starts
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId",
                i$ResM.getBody(isonMsg).get("userId").getAsString());
            // #DVJ00032 Ends
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
            // Fwd the Control to Workflow COntroller.
            ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
            Class < ? > ctrlClass;
            ctrlClass = Class.forName(ScrCtrlClass);
            JsonObject result$ = null;
            Method ctrlFunc = null;
            ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
            Object ctrl$Caller = ctrlClass.newInstance();
            result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
            if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
                if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
                    i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
                    return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
                } else {
                    i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
                    return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
                }
            } else {

                i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
                return isonMsg;
            }

        } catch (Exception e) {
            return null;
        }
    }

    public IPayRollFTController() {
        // Cons
    }
}
// #SKP00001 Ends