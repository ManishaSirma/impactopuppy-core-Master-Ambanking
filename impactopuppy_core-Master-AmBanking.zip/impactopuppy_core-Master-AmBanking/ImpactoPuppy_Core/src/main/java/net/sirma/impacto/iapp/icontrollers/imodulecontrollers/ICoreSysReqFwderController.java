/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Jan 1, 2019  | #00000001   | Initial writing
      |0.2.1       | Vijay 		| Jan 24, 2019 | #BVB00040   | Intial Fixes For CBS Adapter 
      |0.2.1       | Vijay 		| Feb 17, 2019 | #BVB00060   | Flexcube Generic WS Adapter 
      |0.2.1       | Vijay 		| Feb 23, 2019 | #BVB00071   | Removing Static of sUnqReq
      |0.2.1       | Vijay 		| Feb 28, 2019 | #BVB00078   | Transaction monitor changes
      |0.2.1       | Vijay 		| Mar 06, 2019 | #BVB00084   | Response changes for suppressing warnings when transaction fails
      |0.2.1       | Vijay 		| Mar 06, 2019 | #BVB00088   | Changes for Generic Adapter response handling, Pre Post Controller for RT Transactions
      |0.2.1       | Vijay 		| Mar 17, 2019 | #BVB00098   | Adding Initiator and autorizer of the transaction
      |0.3.8       | Vijay 		| May 09, 2019 | #BVB00148   | Retry Functionality for Core Requests
      |0.3.9       | Vijay 		| May 27, 2019 | #BVB00158   | CData Handling in CoreReq Forwarder
      |0.3.9       | Vijay 		| May 27, 2019 | #BVB00172   | Demo Mode Handling for Transactions ** Might have to remove during release
      |0.3.17      | Vijay 		| Jul 24, 2019 | #BVB00189   | Null values handling while replacing  
      |0.3.17      | Vijay   	| Aug 07, 2019 | #BVB00193   | Replace All Function
      |0.3.17      | Vijay   	| Aug 17, 2019 | #BVB00201   | Sending empty cbsMsg2 instead of removing. Partial revert for: BVB00084 
      |0.3.17      | Vijay   	| Aug 21, 2019 | #BVB00203   | Encoding of XML before calling server 
      |0.4.2       | Vijay   	| Aug 31, 2019 | #BVB00205   | UnqCommId not in response 
      |2.3.0.3     | Vijay   	| Sep 18, 2019 | #BVB00212   | Framework for Empty Replace
      |2.3.0.3     | Pappu      | Jul 30, 2021 | #PKY00032   | handle applicationId in unqCommID 
      |2.3.0.3     | Pappu      | May 31, 2022 | #PKY00072   | handled mini statement for casa and loan.
      |2.3.0.3     | Pappu      | Jun 15, 2022 | #PKY00076   | handled flexcube server call of CW, CD and FT to log Aml transactions details in db.
      |2.3.0.3     | Samadhan   | Jul 07, 2022 | #SRP00077   | Handled Code for trnCd
      |2.3.0.3	   | Manikanta  | Feb 22, 2023 | #MVT00107   | added code to send fund transfers email notification
      |2.3.0.3	   | Manikanta  | Mar 31, 2023 | #MVT00108   | Added code to handle flexcube error in response
      |2.3.0.3	   | Madhura    | May 24, 2023 | #MSA00016   | Added code to handle self transfer email trigger
      |2.3.0.3	   | Madhura    | Jun 06, 2023 | #MSA00019   | Added code to handle decimal amount
      |2.3.0.3	   | Madhura    | Jun 20, 2023 | #MSA00020   | Added code to handle Mini statement related PDF task
      |2.3.0.3	   | Madhura    | Jun 26, 2023 | #MSA00021   | Added code to handle IFT for debit account
      |2.3.0.3	   | Sindhu     | Oct 31, 2023 | #SRM00067   | Added code to handle OTP validation along before trn create in the same call
      |2.3.0.3	   | Pavithra   | DEc 09, 2023 | #PAV00031   | Handled code for masking mail id for Internal Fund Transfer
      |2.3.0.3	   | Pavithra   | DEc 22, 2023 | #PAV00035   | Handled changes in fundTransferNotification mails
      |2.3.0.3	   | Srikanth   | Jan 05, 2024 | #SRI00029   | Code added for the convertion of the string to integer
      |2.3.0.3	   | Srikanth   | Mar 11, 2024 | #SRI00041   | handed the Transaction Monitor Screen Summary
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.common.io.Files;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.pdf.PdfDate;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64.InputStream;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;
import com.itextpdf.text.pdf.parser.clipper.Paths;
import com.mongodb.client.MongoCursor;
import com.thoughtworks.xstream.io.path.Path;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.CaptchaController;
import net.sirma.impacto.iapp.ihelpers.IConstants;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IXmlParser;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.FlexGenericWSApadter;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.OtpController;

public class ICoreSysReqFwderController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private IFuncSrvcController i$FuncSrvContr = new IFuncSrvcController();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	private static final Logger logger = LoggerFactory.getLogger(ICoreSysReqFwderController.class); // Nye- Change Class
																									// Name
	// private static String sUnqReq = null; // #BVB00071
	private JsonObject JLogger = new JsonObject();
	private IEmailService i$Email = new IEmailService();
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	private JsonObject JTransmitter = new JsonObject();
	private IXmlParser I$XmlParser = new IXmlParser();
	private FlexGenericWSApadter flexWsAdap = new FlexGenericWSApadter(); // #BVB00060
	private OtpController OtpCntrlr = new OtpController();

	// **********************************************************************//

	@SuppressWarnings("unused")
	private IDataValidator I$DataValidator = new IDataValidator();
	@SuppressWarnings("unused")
	private SentryGuardController Sentry$Controller = new SentryGuardController();

	@SuppressWarnings("unused")
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			JsonObject i$body = null;
			JsonObject i$Annotate = null;
			String Coll_Name, L_Coll_Name;
			Gson gson = new Gson();

			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "XEXCBRFD") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				return coreReqFwd(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "XEXCBRFD") && I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
				return coreReqFwdRetry(isonMsg);
			}
			else if (I$utils.$iStrFuzzyMatch(Scr, "SB2TRNMT") && I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				return transactionMonitorSummary(isonMsg);
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

	private JsonObject getLoggerJson(JsonObject isonMsg) {
		try {
//			JsonObject data$logger = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "msg-id", i$ResM.getMsgID(isonMsg));
			//#PKY00032 starts
			String sUnqReq = I$Imputils.generateRandomKey();
			try {
				 sUnqReq =  sUnqReq+"-"+isonMsg.get("i-body").getAsJsonObject().get("applicationId").getAsString();
				 isonMsg.get("i-body").getAsJsonObject().remove("applicationId");
			}catch(Exception e) {
				
			}
			IDataValidator.J$TempStorage.get().addProperty("sUnqReq", sUnqReq);// #BVB00071
			//#PKY00032 ends
			// sUnqReq = I$Imputils.generateRandomKey();// #BVB00071
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "unqCommID",
					IDataValidator.J$TempStorage.get().get("sUnqReq").getAsString());// #BVB00071
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "srcIME", i$ResM.getIME(isonMsg));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "tranId", i$ResM.getBodyElementS(isonMsg, "tranId"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extSys", i$ResM.getBodyElementS(isonMsg, "extSys"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnCd", i$ResM.getBodyElementS(isonMsg, "trnCd"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "ctrnCd", i$ResM.getBodyElementS(isonMsg, "ctrnCd"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "ctrnOpr", i$ResM.getBodyElementS(isonMsg, "ctrnOpr"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "ctrnOpr1", i$ResM.getBodyElementS(isonMsg, "ctrnOpr1"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "ctrnOpr2", i$ResM.getBodyElementS(isonMsg, "ctrnOpr2"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "ctrnOpr3", i$ResM.getBodyElementS(isonMsg, "ctrnOpr3"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnBrn", i$ResM.getBodyElementS(isonMsg, "trnBrn"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnOpr", i$ResM.getOpr(isonMsg));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnOpr1", i$ResM.getOpr1(isonMsg));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnOpr2", i$ResM.getOpr2(isonMsg));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnOpr3", i$ResM.getOpr3(isonMsg));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "procStatus", "NEW");
			// #BVB00098 Starts
			// Initiated By
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "initatedBy", IResManipulator.iloggedUser.get());
			// Authorized By Currently transaction is Auto Auth
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "authorizeddBy", IResManipulator.iloggedUser.get());
			// #BVB00098 Ends
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "impactoInDtTime", i$ResM.addDateTime(new Date()));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "retryCnt", 0);
			/*
			 * 0 - pending , 1 - wip , 2 - completed
			 */
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnStat", i$ResM.getBodyElementS(isonMsg, "0"));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnMsg", i$ResM.getBodyElementS(isonMsg, ""));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnReplyCode", "0000"); // New Message
//			i$ResM.getBody(isonMsg).get("trnData").getAsJsonObject().addProperty("lcyAmount", Integer.parseInt(i$ResM.getBody(isonMsg).get("trnData").getAsJsonObject().get("lcyAmount").getAsString()));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnData",
					i$ResM.getBody(isonMsg).get("trnData").getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extCommID", I$Imputils.generateRandomKey(50));
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extUrl", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extReqMsg", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extResMsg", "");
			return JLogger;
		} catch (Exception e) {
			return null;
		}
	};

	private boolean logReqAsNEW(JsonObject isonMsg) {
		JsonObject $up = new JsonObject();
		try {
			JLogger = getLoggerJson(isonMsg);
			$up = db$Ctrl.db$InsertRow("ICOR_C_TRNFWD_MONITOR", JLogger);
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($up), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "SYSTEM-ERROR");
				return false;
			}
			;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return false;
		}
	};

	private boolean logReqAsWIP(JsonObject isonMsg) {
		JsonObject $up = new JsonObject();
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "procStatus", "WIP");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "impactoProcDtTime", i$ResM.addDateTime(new Date()));
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnStat", "1");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnMsg", "Sent for Processing");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "oprType", JTransmitter.get("OPR_TYPE").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extReqMsg", JTransmitter.get("reqBody").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extSys", JTransmitter.get("extSys").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extUrl", JTransmitter.get("extUrl").getAsString());
		// #BVB00148 Starts
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "requestType",
				JTransmitter.get("requestType").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "connectTimeOut",
				JTransmitter.get("connectTimeOut").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "readTimeOut",
				JTransmitter.get("readTimeOut").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "mediaType", JTransmitter.get("mediaType").getAsString());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "headerTags",
				JTransmitter.get("headerTags").getAsJsonObject());
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "mediaType", JTransmitter.get("mediaType").getAsString());

		try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "p_is_req_clob",
					JTransmitter.get("p_is_req_clob").getAsString());
		} catch (Exception e) {

		}
		try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "p_is_res_clob",
					JTransmitter.get("p_is_res_clob").getAsString());
		} catch (Exception e) {

		}
		try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "p_spl_parsing",
					JTransmitter.get("p_spl_parsing").getAsString());
		} catch (Exception e) {

		}
		try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "p_blk_parsing",
					JTransmitter.get("p_blk_parsing").getAsString());
		} catch (Exception e) {

		}
		try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "p_instr_xml",
					JTransmitter.get("p_instr_xml").getAsString());
		} catch (Exception e) {

		}
		// #BVB00148 Ends
		try {
			// JsonObject JLogger = getLoggerJson(isonMsg); // #BVB00040
			$up = db$Ctrl.db$UpdateRow("ICOR_C_TRNFWD_MONITOR", JLogger,
					"{\"unqCommID\":\"" + IDataValidator.J$TempStorage.get().get("sUnqReq").getAsString() + "\"}");// #BVB00071
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($up), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "SYSTEM-ERROR");
				return false;
			}
			;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return false;
		}
	};

	// #BVB00148 Starts
	private boolean logReqAsWIPRetry(JsonObject trnFwdMonitor) {
		JsonObject $up = new JsonObject();
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, trnFwdMonitor, "procStatus", "WIP");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, trnFwdMonitor, "impactoProcDtTime", i$ResM.addDateTime(new Date()));
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, trnFwdMonitor, "trnStat", "1");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, trnFwdMonitor, "trnMsg", "Sent for Processing");

		try {
			$up = db$Ctrl.db$UpdateRow("ICOR_C_TRNFWD_MONITOR", trnFwdMonitor,
					"{\"unqCommID\":\"" + trnFwdMonitor.get("unqCommID").getAsString() + "\"}");
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($up), i$ResM.I_SUCC)) {
				return false;
			}
			;

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	};

// #BVB00148 Ends
	private boolean logReqAsDone(JsonObject isonMsg) {
		JsonObject $up = new JsonObject();
		try {
			// JsonObject JLogger = getLoggerJson(isonMsg); // #BVB00040
			$up = db$Ctrl.db$UpdateRow("ICOR_C_TRNFWD_MONITOR", JLogger,
					"{\"unqCommID\":\"" + IDataValidator.J$TempStorage.get().get("sUnqReq").getAsString() + "\"}");// #BVB00071
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($up), i$ResM.I_SUCC)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", "SYSTEM-ERROR");
				return false;
			}
			;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return false;
		}
	};

// #BVB00148 Starts 
	private boolean logReqAsDoneRetry(JsonObject trnFwdMonitor) {
		JsonObject $up = new JsonObject();
		try {
			// JsonObject JLogger = getLoggerJson(isonMsg); // #BVB00040
			$up = db$Ctrl.db$UpdateRow("ICOR_C_TRNFWD_MONITOR", trnFwdMonitor,
					"{\"unqCommID\":\"" + trnFwdMonitor.get("unqCommID").getAsString() + "\"}");// #BVB00071
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg($up), i$ResM.I_SUCC)) {
				return false;
			}
			;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	};

// #BVB00148 Ends
	@SuppressWarnings("unused")
	private String getMatchString() {

		Gson gson = new Gson();
		try {
			String sCtrnCd = "@", sCtrnOpr = "@", sCtrnOpr1 = "@", sCtrnOpr2 = "@", sCtrnOpr3 = "@";
			String sTrnCd = "@", sTrnOpr = "@", sTrnOpr1 = "@", sTrnOpr2 = "@", sTrnOpr3 = "@";

			try {
				sTrnCd = JLogger.get("trnCd").getAsString();
			} catch (Exception ex) {
				sTrnCd = "@";
			}
			;

			try {
				sTrnOpr = JLogger.get("trnOpr").getAsString();
			} catch (Exception ex) {
				sTrnOpr = "@";
			}
			;

			try {
				sTrnOpr = JLogger.get("trnOpr").getAsString();
			} catch (Exception ex) {
				sTrnOpr = "@";
			}
			;

			try {
				sTrnOpr1 = JLogger.get("trnOpr1").getAsString();
			} catch (Exception ex) {
				sTrnOpr1 = "@";
			}
			;

			try {
				sTrnOpr2 = JLogger.get("trnOpr2").getAsString();
			} catch (Exception ex) {
				sTrnOpr2 = "@";
			}
			;

			try {
				sTrnOpr3 = JLogger.get("trnOpr3").getAsString();
			} catch (Exception ex) {
				sTrnOpr3 = "@";
			}
			;

			try {
				sCtrnCd = JLogger.get("ctrnCd").getAsString();
			} catch (Exception ex) {
				sCtrnCd = "@";
			}
			;

			try {
				sCtrnOpr = JLogger.get("ctrnOpr").getAsString();
			} catch (Exception ex) {
				sCtrnOpr = "@";
			}
			;

			try {
				sCtrnOpr = JLogger.get("ctrnOpr").getAsString();
			} catch (Exception ex) {
				sCtrnOpr = "@";
			}
			;

			try {
				sCtrnOpr1 = JLogger.get("ctrnOpr1").getAsString();
			} catch (Exception ex) {
				sCtrnOpr1 = "@";
			}
			;

			try {
				sCtrnOpr2 = JLogger.get("ctrnOpr2").getAsString();
			} catch (Exception ex) {
				sCtrnOpr2 = "@";
			}
			;

			try {
				sCtrnOpr3 = JLogger.get("ctrnOpr3").getAsString();
			} catch (Exception ex) {
				sCtrnOpr3 = "@";
			}
			;

			// #BVB00040 Starts
			// Converting to JsonObject

			JsonObject sMatchObj = new JsonObject();
			sMatchObj.addProperty("impacto_annote", i$ResM.getGobalValStr("iAnnote"));
			sMatchObj.addProperty("trnCd", JLogger.get("trnCd").getAsString());
			sMatchObj.addProperty("ctrnCd", sCtrnCd);
			sMatchObj.addProperty("ctrnOpr", sCtrnOpr);
			sMatchObj.addProperty("ctrnOpr1", sCtrnOpr1);
			sMatchObj.addProperty("ctrnOpr2", sCtrnOpr2);
			sMatchObj.addProperty("ctrnOpr3", sCtrnOpr3);
			sMatchObj.addProperty("trnCd", sTrnCd);
			sMatchObj.addProperty("trnOpr", sTrnOpr);
			sMatchObj.addProperty("trnOpr1", sTrnOpr1);
			sMatchObj.addProperty("trnOpr2", sTrnOpr2);
			sMatchObj.addProperty("trnOpr3", sTrnOpr3);
			sMatchObj.addProperty("extSys", JLogger.get("extSys").getAsString());

			/*
			 * String sMatchStr =
			 * "{\"impacto_annote\" : \""+i$ResM.getGobalValStr("iAnnote")+"\"," +
			 * "\"trnCd\" : \""+JLogger.get("trnCd").getAsString()+"\"," +
			 * "\"ctrnCd\" : \""+sCtrnCd+"\"," + "\"ctrnOpr\" : \""+sCtrnOpr+"\"," +
			 * "\"ctrnOpr1\" : \""+sCtrnOpr1+"\",\"" + "ctrnOpr2\" : \""+sCtrnOpr2+"\"," +
			 * "\"ctrnOpr3\" : \""+sCtrnOpr3+"\",\"" + "\"trnCd\" : \""+sTrnCd+"\"," +
			 * "\"trnOpr\" : \""+sTrnOpr+"\"," + "\"trnOpr1\" : \""+sTrnOpr1+"\",\"" +
			 * "trnOpr2\" : \""+sTrnOpr2+"\"," + "\"trnOpr3\" : \""+sTrnOpr3+"\",\"" +
			 * "extSys\" : \""+JLogger.get("extSys").getAsString()+"\"}";
			 */

			// #BVB00040 Ends
			// return sMatchStr;
			return gson.toJson(sMatchObj);
		} catch (Exception ex) {
			return "";
		}
	};

	@SuppressWarnings("unused")
	private String getCoreReq(JsonObject isonMsg) {
		try {
//			String sMatchStr = getMatchString();
//			String sSortStr = "{\"chunkId\": -1}";
			String sReq = "";
			int i = 0;
			// JsonArray JCoreDets = db$Ctrl.db$GetRows$Sort("ICOR_C_WS_TRANSMITTER",
			// sMatchStr, sSortStr);
			JsonArray JCoreDets = getTransmitter(isonMsg);
			// Going to build the Complete Req Message
			for (i = 0; i < JCoreDets.size(); i++) {
				sReq = sReq + JCoreDets.get(i).getAsJsonObject().get("reqChunk").getAsString();
				if (i == 0) {
					JTransmitter = JCoreDets.get(i).getAsJsonObject();
					JTransmitter.remove("reqChunk");
				}
				;
			}
			;
			// Now Am Going for the Val Replace
			sReq = getFormattedTmpl(sReq, JLogger.get("trnData").getAsJsonObject());
			JTransmitter.addProperty("unqCommID", IDataValidator.J$TempStorage.get().get("sUnqReq").getAsString()); // #BVB00071
			JTransmitter.addProperty("reqBody", sReq);

			return sReq;
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
			return "";
		}
	};

	@SuppressWarnings("unused")
	private String getFormattedTmpl(String sTmpl, JsonObject J$vals) {
		// Every Field to be Replaced Should be in the format
		// ###IMP1###<JsonKey>###IMP2###
		try {
			Map<String, Object> attributes = new HashMap<String, Object>();
			Set<Entry<String, JsonElement>> entrySet = J$vals.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = "###IMP1###" + entry.getKey() + "###IMP2###";
				try { // #BVB00189
					strVal = J$vals.get(entry.getKey()).getAsString();
					// #BVB00189 Starts
				} catch (Exception e) {
					strVal = "";
				}
				// #BVB00189 Ends
				// #BVB00212 Starts
				String replaceEmpty = "Y";
				if (JTransmitter.has("replaceEmpty")) {
					replaceEmpty = JTransmitter.get("replaceEmpty").getAsString();
				}
				if (!(I$utils.$iStrFuzzyMatch(replaceEmpty, "N") && I$utils.$iStrFuzzyMatch(strVal, ""))) { // #BVB00212
																											// Ends
					sTmpl = I$Imputils.replaceAll(sTmpl, strKey, strVal); // #BVB00193
					// sTmpl = sTmpl.replaceAll(strKey, strVal); // #BVB00193
				}
			}
		} catch (Exception ex) {
			logger.debug(ex.getMessage());
		}
		return sTmpl;
	}

	private JsonObject getResultJsonJ(JsonObject J$vals) {
		JsonObject JRe$sult = new JsonObject();
		try {
			if (I$utils.$iStrFuzzyMatch(JTransmitter.get("responseFullBody").getAsString(), "Y")) {
				return J$vals;
			}
			;
			Set<Entry<String, JsonElement>> entrySet = JTransmitter.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = entry.getKey();
				strVal = JTransmitter.get(entry.getKey()).getAsString();
				if (J$vals.has(strVal))
					try {
						JRe$sult.addProperty(strKey, J$vals.get(strVal).getAsString());
					} catch (Exception e) {
						JRe$sult.add(strKey, J$vals.get(strVal));
					}
				else
					JRe$sult.addProperty(strKey, "");
			}
		} catch (Exception ex) {
			logger.debug(ex.getMessage());
		}
		return JRe$sult;
	}

	private JsonObject getCbsMsgJsonJ(JsonObject J$vals) {
		JsonObject JRe$sult = new JsonObject();
		try {
			if (I$utils.$iStrFuzzyMatch(JTransmitter.get("cbsMsgFieldTypeJ").getAsString(), "J")) {

				try {
					JRe$sult.add("cbsMsg1", JTransmitter.get("cbsMsgFieldJ1").getAsJsonObject());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg1", "");
				}
				;

				try {
					JRe$sult.add("cbsMsg2", JTransmitter.get("cbsMsgFieldJ2").getAsJsonObject());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg2", "");
				}
				;

				try {
					JRe$sult.add("cbsMsg3", JTransmitter.get("cbsMsgFieldJ3").getAsJsonObject());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg3", "");
				}
				;

				try {
					JRe$sult.add("cbsMsg4", JTransmitter.get("cbsMsgFieldJ4").getAsJsonObject());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg4", "");
				}
				;

				try {
					JRe$sult.add("cbsMsg5", JTransmitter.get("cbsMsgFieldJ5").getAsJsonObject());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg5", "");
				}
				;

			} else if (I$utils.$iStrFuzzyMatch(JTransmitter.get("cbsMsgFieldTypeJ").getAsString(), "S")) {

				try {
					JRe$sult.addProperty("cbsMsg1", JTransmitter.get("cbsMsgFieldJ1").getAsString());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg1", "");
				}
				;

				try {
					JRe$sult.addProperty("cbsMsg2", JTransmitter.get("cbsMsgFieldJ2").getAsString());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg2", "");
				}
				;

				try {
					JRe$sult.addProperty("cbsMsg3", JTransmitter.get("cbsMsgFieldJ3").getAsString());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg3", "");
				}
				;

				try {
					JRe$sult.addProperty("cbsMsg4", JTransmitter.get("cbsMsgFieldJ4").getAsString());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg4", "");
				}
				;

				try {
					JRe$sult.addProperty("cbsMsg5", JTransmitter.get("cbsMsgFieldJ5").getAsString());
				} catch (Exception e) {
					JRe$sult.addProperty("cbsMsg5", "");
				}
				;
			}
			return JRe$sult;

		} catch (Exception ex) {
			logger.debug(ex.getMessage());
			return null;
		}
	}

	private JsonObject getCbsMsgJsonX(String sXmlBody) {
		JsonObject JRe$sult = new JsonObject();
		try {
			try {
				JRe$sult.addProperty("cbsMsg1",
						I$XmlParser.getXpathValDom(JTransmitter.get("cbsMsgFieldX1").getAsString(), sXmlBody)); // #BVB00040
			} catch (Exception e) {
				JRe$sult.addProperty("cbsMsg1", "");
			}
			;

			try {
				JRe$sult.addProperty("cbsMsg2",
						I$XmlParser.getXpathValDom(JTransmitter.get("cbsMsgFieldX2").getAsString(), sXmlBody));// #BVB00040
			} catch (Exception e) {
				JRe$sult.addProperty("cbsMsg2", "");
			}
			;

			try {
				JRe$sult.addProperty("cbsMsg3",
						I$XmlParser.getXpathValDom(JTransmitter.get("cbsMsgFieldX3").getAsString(), sXmlBody));// #BVB00040
			} catch (Exception e) {
				JRe$sult.addProperty("cbsMsg3", "");
			}
			;

			try {
				JRe$sult.addProperty("cbsMsg4",
						I$XmlParser.getXpathValDom(JTransmitter.get("cbsMsgFieldX4").getAsString(), sXmlBody));// #BVB00040
			} catch (Exception e) {
				JRe$sult.addProperty("cbsMsg4", "");
			}
			;

			try {
				JRe$sult.addProperty("cbsMsg5",
						I$XmlParser.getXpathValDom(JTransmitter.get("cbsMsgFieldX5").getAsString(), sXmlBody));// #BVB00040
			} catch (Exception e) {
				JRe$sult.addProperty("cbsMsg5", "");
			}
			;

		} catch (Exception ex) {
			logger.debug(ex.getMessage());
		}
		return JRe$sult;
	}

	private JsonObject getResultJsonXml(String sXmlBody) {
		JsonObject JRe$sult = new JsonObject();

		try {
			if (I$utils.$iStrFuzzyMatch(JTransmitter.get("responseFullBody").getAsString(), "Y")) {
				return I$XmlParser.cov$XmlStr2Json(sXmlBody);
			}
			;

			JsonObject ResponseXmlMap = JTransmitter.get("responseXMLMap").getAsJsonObject();
			Set<Entry<String, JsonElement>> entrySet = ResponseXmlMap.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				strKey = entry.getKey();
				strVal = ResponseXmlMap.get(entry.getKey()).getAsString();
				// strVal should have the Xpath query
				String elemVal = I$XmlParser.getXpathValDom(strVal, sXmlBody);// #BVB00040
				JRe$sult.addProperty(strKey, elemVal);
			}
		} catch (Exception ex) {
			logger.debug(ex.getMessage());
		}
		return JRe$sult;
	}

	@SuppressWarnings("unused")
	public JsonObject coreReqFwd(JsonObject isonMsg) {
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject(); //#SRM00067 changes for OTP validation along with trn create starts
		if (ibody.has("trnData") && (ibody.get("trnData").getAsJsonObject().has("lcyAmount") || ibody.get("trnData").getAsJsonObject().has("txnAmt"))){
			try { // SRI00029 starts
//				isonMsg.get("i-body").getAsJsonObject().get("trnData").getAsJsonObject().addProperty("lcyAmount",
//						Integer.parseInt(ibody.get("trnData").getAsJsonObject().get("lcyAmount").getAsString()));
				JsonObject trnDataObject = isonMsg.get("i-body").getAsJsonObject().get("trnData").getAsJsonObject();
				if (trnDataObject.has("lcyAmount")) {
			        double lcyAmount = Double.parseDouble(trnDataObject.get("lcyAmount").getAsString());
			        trnDataObject.addProperty("lcyAmount", lcyAmount);
			    }
			    if (trnDataObject.has("txnAmt")) {
			        double txnAmt = Double.parseDouble(trnDataObject.get("txnAmt").getAsString());
			        trnDataObject.addProperty("txnAmt", txnAmt);
			    }
			} catch (Exception E) {
				E.printStackTrace();
			}
		}  //SRI00029 Ends 
		if (ibody.has("otp")) {
			JsonObject isonMsgOTP = OtpCntrlr.verifyOTP(ibody, isonMsg);
			if (I$utils.$iStrFuzzyMatch(
					isonMsgOTP.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(), "i-ERROR")) {
				isonMsg.remove("i-body");
				return isonMsg;
			} 
		} //#SRM00067 changes end
		String reqType = "";
		try {
			JsonObject i$JCoreDet = new JsonObject();
			// Am Logging the Request
			if (!logReqAsNEW(isonMsg)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN LOGGER");
				return isonMsg;
			}
			;

			String SOpr = i$ResM.getOpr(isonMsg);
			String SOpr1 = i$ResM.getOpr1(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			String SOpr3 = i$ResM.getOpr3(isonMsg);
			String ScrID = i$ResM.getScreenID(isonMsg);
			i$ResM.setGobalVals("iAnnote", ScrID + "_" + SOpr);
			String preFlightclsName = "";
			String postFlightclsName = "";
			JsonObject JResp = new JsonObject();
			JsonObject i$Annotate = null, i$body = null;

			// #BVB00088 Starts
			// Calling PreFlight here

			JsonArray JCoreDets = getTransmitter(isonMsg);
			if (JCoreDets.size() > 0) {
				i$JCoreDet = JCoreDets.get(0).getAsJsonObject();
				if (i$JCoreDet.has("preflightOprs")) {
					preFlightclsName = i$JCoreDet.getAsJsonObject("preflightOprs").get("Controller").getAsString();

					// Route the request to the given class

					isonMsg = routeRequest(preFlightclsName, "processMsg", isonMsg);
					if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnData",
								i$ResM.getBody(isonMsg).get("trnData").getAsJsonObject());
					} else {
						return isonMsg;
					}
				}

				if (i$JCoreDet.has("postflightOprs")) {
					postFlightclsName = i$JCoreDet.getAsJsonObject("postflightOprs").get("Controller").getAsString();

				}
				try {
					reqType = i$JCoreDet.get("reqType").getAsString();
				} catch (Exception e) {
					reqType = "XML";
				}
			}
			// #BVB00088 Ends
			// Prepare the Request
			String sFinalReq = getCoreReq(isonMsg);
			if (I$utils.$iStrFuzzyMatch(reqType, i$ResM.I_XML)) {
				sFinalReq = I$Imputils.xmlEscapeText(sFinalReq);
				JTransmitter.addProperty("reqBody", sFinalReq); // #BVB00205
			}
			if (I$utils.$iStrBlank(sFinalReq)) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Missing isonMsgTranmistter#045891");
				return isonMsg;
			}
			;

			// Have to add Media Type to the argJson -- BVB

			// Fire the Http Request
			if (logReqAsWIP(isonMsg)) {
				// #BVB00060 Starts
				if (I$utils.$iStrFuzzyMatch(JTransmitter.get("OPR_TYPE").getAsString(), i$ResM.I_CALLWS)) {

					JResp = I$EWSLnchr.ILaunchReq(JTransmitter);
					// #BVB00060 Starts
				} else if (I$utils.$iStrFuzzyMatch(JTransmitter.get("OPR_TYPE").getAsString(), "CALLJAVA")) {
					JResp = callWSAdapter(JTransmitter);

				}
				// #BVB00060 Ends
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "procStatus", "DONE");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "impactoDoneDtTime", i$ResM.addDateTime(new Date()));
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnStat", "2");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnReplyCode", JResp.get("resCode").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "extResMsg", JResp.get("resBody").getAsString());
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "trnMsg", JResp.get("resStat").getAsString());
			} else {
				return isonMsg;
			}
			;
			// Checking the Response Status

			JsonObject isonMsgRes = processResponse(JResp, isonMsg);
			// #BVB00088 Starts
			// Adding POSTFLIGHT_OPRS
			if (i$JCoreDet.has("postflightOprs") && !i$ResM.getBody(isonMsgRes).has("KYC_REF_NO") 
			          && !i$ResM.getBody(isonMsgRes).has("cbsMsg")) {
				// #BVB00172 Starts
				JsonObject argJson = new JsonObject();
				argJson.add("isonMsg", isonMsg);
				argJson.add("isonMsgRes", isonMsgRes);
				isonMsgRes = routeRequest(postFlightclsName, "processRes", argJson);
				// isonMsg = routeRequest(postFlightclsName, "processRes", isonMsg);
			}
			// #BVB00088 Ends
			logReqAsDone(isonMsgRes);
			if(I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "PR")) {
				updateCbsDetails(isonMsgRes);
			}
			if(I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "CASA_MSDVWMSG") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "LOAN_CLDGNADV")) { //PKY00072 changes
				generateMiniStatement(isonMsgRes);
			}
			//PKY00076 starts
			String i$statMsg = i$ResM.getStatMsg(isonMsgRes);
			if(I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_SUCC)) {
				if(I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "CW") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "CD") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "IFT") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "LINCU") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "ACH")) {//#SRP00077 Changes
					i$FuncSrvContr.amlValidations(isonMsg);
				}
			}
			if (I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "ACH") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "IFT") || I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "LINCU")) {
				fundTransferNotification(isonMsgRes, isonMsg);//#MVT00107 changes
			}
			//PKY00076 ends
			return isonMsgRes;
//			logReqAsDone(isonMsg);
//			return isonMsg;
			// #BVB00172 Ends
		} catch (Exception e) {
			// Failed Block
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN NET#CB89002# COMMUNICATION ");
			return isonMsg;
		}
	};
	//#MVT00107 begins
	public void fundTransferNotification(JsonObject isonMsgRes, JsonObject isonMsg) {
		try {
			String cif = "";
			String toCif = "";
			String sKeyE = new String();
			String isKeyE = new String();
			JsonObject filter = new JsonObject();
			JsonObject fltr = new JsonObject();
			JsonObject prjctn = new JsonObject();
			JsonObject argJson = new JsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject imap$Data = new JsonObject();
			JsonObject ibody = isonMsg.getAsJsonObject("i-body");			
			JsonObject trnData = ibody.getAsJsonObject("trnData");
			
			prjctn.addProperty("CustomerEmailId", 1);
			prjctn.addProperty("CustomerMobileId", 1);
			prjctn.addProperty("CustomerFullName", 1);
			if(I$utils.$iStrFuzzyMatch(ibody.get("trnCd").getAsString(), "LINCU")) {
				cif = trnData.get("acc").getAsString().substring(3, 9);
				double number = trnData.get("txnAmt").getAsDouble();//MSA00019 starts
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##");
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##"); //#MVT00113 changes
					amountCom = formatter.format(d1);
				}//MSA00019 ends
				filter.addProperty("CustomerId", cif);
				JsonObject toCifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, prjctn);
				map$Data.addProperty("fromAcc", trnData.get("acc").getAsString());
				map$Data.addProperty("toAcc", trnData.get("lincuCardNo").getAsString());
				map$Data.addProperty("Branch", trnData.get("branch").getAsString());
				map$Data.addProperty("amount", amountCom);
				map$Data.addProperty("tranType", ibody.get("transferType").getAsString());
				map$Data.addProperty("memName", toCifData.get("CustomerFullName").getAsString());
				sKeyE = sKeyE.concat(toCifData.get("CustomerEmailId").getAsString()+",");
				
				if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-SUCC")) {
					map$Data.addProperty("tmp$name","TMPL#LINCU#TRANSFER#SUCC#NOTIFICATION");
					//#PAV00035 Changes
					argJson.add("map$Data", map$Data);
					argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
					JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				}else if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-ERROR")) {
					map$Data.addProperty("tmp$name","TMPL#TRN#AUTH#FAIL#NOTIFICATION");
				}
			}
			if(I$utils.$iStrFuzzyMatch(ibody.get("trnCd").getAsString(), "ACH")) {
				double number = trnData.get("txnAmt").getAsDouble();//MSA00019 starts
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##");
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##"); //#MVT00113 changes
					amountCom = formatter.format(d1);
				}//MSA00019 ends
				cif = trnData.get("txnAcc").getAsString().substring(3, 9);
				filter.addProperty("CustomerId", cif);
				JsonObject toCifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, prjctn);
				map$Data.addProperty("fromAcc", trnData.get("txnAcc").getAsString());
				map$Data.addProperty("toAcc", trnData.get("achBeneficiaryAcc").getAsString());
				map$Data.addProperty("Branch", trnData.get("branch").getAsString());
				map$Data.addProperty("amount", amountCom);
				map$Data.addProperty("tranType", ibody.get("transferType").getAsString());
				map$Data.addProperty("memName", toCifData.get("CustomerFullName").getAsString());
				sKeyE = sKeyE.concat(toCifData.get("CustomerEmailId").getAsString()+",");
				
				if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-SUCC")) {
					map$Data.addProperty("tmp$name","TMPL#ACH#TRANSFER#SUCC#NOTIFICATION");
					//#PAV00035 Changes
					argJson.add("map$Data", map$Data);
					argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
					JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				}else if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-ERROR")) {
					map$Data.addProperty("tmp$name","TMPL#TRN#AUTH#FAIL#NOTIFICATION");
				}
			}
			if(I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "Internal Fund Transfer")) {
				double number = trnData.get("lcyAmount").getAsDouble();//MSA00019 starts
				String amountCom = null;//MSA00021 starts
				cif = trnData.get("debitAccNo").getAsString().substring(3, 9);
				fltr.addProperty("CustomerId",cif);
				JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr, prjctn);
				sKeyE = sKeyE.concat(cifData.get("CustomerEmailId").getAsString()+",");
				
				toCif = trnData.get("creditAccNo").getAsString().substring(3, 9);
				filter.addProperty("CustomerId", toCif);
				JsonObject toCifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, prjctn);
				isKeyE = isKeyE.concat(toCifData.get("CustomerEmailId").getAsString()+",");
				//MSA00021 ends
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##");
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##"); //#MVT00113 changes
					amountCom = formatter.format(d1);
				}//MSA00019 ends
				map$Data.addProperty("fromAcc", trnData.get("debitAccNo").getAsString());
				map$Data.addProperty("toAcc", trnData.get("creditAccNo").getAsString());
				map$Data.addProperty("Branch", trnData.get("branchCode").getAsString());
				map$Data.addProperty("amount", amountCom);
				map$Data.addProperty("tranType", ibody.get("transferType").getAsString());
				map$Data.addProperty("memName", cifData.get("CustomerFullName").getAsString());

				if (I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(),"i-SUCC")) {
					map$Data.addProperty("tmp$name", "TMPL#IF#TRANSFER#SUCC#NOTIFICATION");
				} else if (I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-ERROR")) {
					map$Data.addProperty("tmp$name", "TMPL#TRN#AUTH#FAIL#NOTIFICATION");
				}//MSA00021 starts
//				if(!I$utils.$iStrFuzzyMatch(isKeyE, sKeyE)) {
//					imap$Data.addProperty("fromAcc", trnData.get("debitAccNo").getAsString());
//					imap$Data.addProperty("toAcc", trnData.get("creditAccNo").getAsString());
//					imap$Data.addProperty("Branch", trnData.get("branchCode").getAsString());
//					imap$Data.addProperty("amount", amountCom);
//					imap$Data.addProperty("tranType", ibody.get("transferType").getAsString());
//					imap$Data.addProperty("memName", toCifData.get("CustomerFullName").getAsString());
//					
//					if (I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(),"i-SUCC")) {
//						imap$Data.addProperty("tmp$name", "TMPL#IF#TRANSFER#SUCC#NOTIFICATION");
//					} 
////					else if (I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-ERROR")) {
////						imap$Data.addProperty("tmp$name", "TMPL#TRN#AUTH#FAIL#NOTIFICATION");
////					}
//					argJson.add("map$Data", imap$Data);
//					argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + isKeyE + "\"}"));
//					JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
//				}//MSA00021 ends
				if(!I$utils.$iStrFuzzyMatch(isKeyE, sKeyE)) {
//					imap$Data.addProperty("fromAcc", trnData.get("debitAccNo").getAsString());
//					imap$Data.addProperty("toAcc", trnData.get("creditAccNo").getAsString());
					imap$Data.addProperty("Branch", trnData.get("branchCode").getAsString());
					imap$Data.addProperty("amount", amountCom);
					imap$Data.addProperty("tranType", ibody.get("transferType").getAsString());
//					imap$Data.addProperty("memName", toCifData.get("CustomerFullName").getAsString());
					if (I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(),"i-SUCC")) {
						imap$Data.addProperty("tmp$name", "TMPL#IF#TRANSFER#SUCC#NOTIFICATION");
					}
					try{//#PAV00031 Changes Starts 
						String lastFourDigits = trnData.get("creditAccNo").getAsString().substring(trnData.get("creditAccNo").getAsString().length() - 4);
						int maskCharCount = trnData.get("creditAccNo").getAsString().length() - 4;
						String maskedAccNo = "x".repeat(maskCharCount) + lastFourDigits;
						imap$Data.addProperty("fromAcc", trnData.get("debitAccNo").getAsString());
						imap$Data.addProperty("toAcc", maskedAccNo);
						imap$Data.addProperty("memName", cifData.get("CustomerFullName").getAsString());////#PAV00035 Changes
						argJson.add("map$Data", imap$Data);
						argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
					}catch (Exception e) {
						e.printStackTrace();
					}
					try{
						String lastFourDigits = trnData.get("debitAccNo").getAsString().substring(trnData.get("debitAccNo").getAsString().length() - 4);
						int maskCharCount = trnData.get("debitAccNo").getAsString().length() - 4;
						String maskedAccNo = "x".repeat(maskCharCount) + lastFourDigits;
						imap$Data.addProperty("fromAcc",maskedAccNo);
						imap$Data.addProperty("toAcc", trnData.get("creditAccNo").getAsString());
						imap$Data.addProperty("memName", toCifData.get("CustomerFullName").getAsString());////#PAV00035 Changes
						argJson.add("map$Data", imap$Data);
						argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + isKeyE + "\"}"));
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
					}catch (Exception e) {
			             e.printStackTrace();
			        }//#PAV00031 Changes Ends
			   }//MSA00021 ends
			}//MSA00016 starts
			if(I$utils.$iStrFuzzyMatch(ibody.get("transferType").getAsString(), "Self Transfer")) {
				double number = trnData.get("lcyAmount").getAsDouble();//MSA00019 starts
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##");
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.##"); //#MVT00113 changes
					amountCom = formatter.format(d1);
				}//MSA00019 ends
				map$Data.addProperty("fromAcc", trnData.get("debitAccNo").getAsString());
				map$Data.addProperty("toAcc", trnData.get("creditAccNo").getAsString());
				map$Data.addProperty("Branch", trnData.get("branchCode").getAsString());
				map$Data.addProperty("amount", amountCom);
				map$Data.addProperty("tranType", ibody.get("transferType").getAsString());
				map$Data.addProperty("memName", trnData.get("memberName").getAsString());
				cif = trnData.get("creditAccNo").getAsString().substring(3, 9);
				filter.addProperty("CustomerId", cif);
				JsonObject toCifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, prjctn);
				sKeyE = sKeyE.concat(toCifData.get("CustomerEmailId").getAsString()+",");
				
				if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-SUCC")) {
					map$Data.addProperty("tmp$name","TMPL#SELF#TRANSFER#SUCC#NOTIFICATION");
					////#PAV00035 Changes
					argJson.add("map$Data", map$Data);
					argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
					JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
				}else if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-ERROR")) {
					map$Data.addProperty("tmp$name","TMPL#TRN#AUTH#FAIL#NOTIFICATION");
				}
			}//MSA00016 ends
//			filter.addProperty("CustomerId", cif);
//			JsonObject request = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, prjctn);
//			if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-ERROR")) {
//				map$Data.addProperty("tmp$name","TMPL#TRN#AUTH#FAIL#NOTIFICATION");
//			} else if(I$utils.$iStrFuzzyMatch(isonMsgRes.getAsJsonObject("i-stat").get("i-statMsg").getAsString(), "i-SUCC")) {
//				map$Data.addProperty("tmp$name","TMPL#TRN#AUTH#SUCC#NOTIFICATION");
//			}
//			sKeyE = sKeyE.concat(request.get("CustomerEmailId").getAsString());
			//#PAV00035 Changes
//			argJson.add("map$Data", map$Data);
//			argJson.add("toemailIds",i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
//			JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
			
			
		} catch(Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, " Failed To Sending Email");
			logger.debug("Failed To Send Email");
		}
	}
	//#MVT00107 ends
	public JsonObject processResponse(JsonObject JResp, JsonObject isonMsgReq) {
		String sResValMsg = "";
		JsonObject isonMsg = new JsonObject();
		try {
			isonMsg = isonMsgReq.deepCopy();
			JsonObject i$Result = new JsonObject();
			JsonObject i$ResultTmp = new JsonObject();
			// Nye Fix Begin
			if (I$utils.$iStrFuzzyMatch(JResp.get("resCode").getAsString(), "400")) {
				i$ResultTmp.addProperty("cbsMsg1", "");
				i$ResultTmp.addProperty("cbsMsg2",
						("FAILED IN NET#CB89001# COMMUNICATION " + JResp.get("resExp").getAsString()).toUpperCase());
				i$ResultTmp.addProperty("cbsMsg3", "");

				try {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg", i$ResultTmp);
				} catch (Exception ex) {
					// eat
				}
				i$Result.addProperty("unqCommID", JResp.get("unqCommID").getAsString()); // #BVB00205
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$Result); // CBS Adapter Resp Msg builder
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "iResMsg", isonMsg); // #BVB00078
				return isonMsg;
			}
			;
			// Nye Fix End

			if (I$utils.$iStrFuzzyMatch(JResp.get("resStat").getAsString(), i$ResM.I_SUCC)) {
				// Success Block
				if (I$utils.$iStrFuzzyMatch(JTransmitter.get("resType").getAsString(), "JSON")) // BVB need to add
																								// resType to argJson
				{
					// JSON Logic
					JsonParser parser = new JsonParser();
					JsonObject JobjRes = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
					i$Result = getResultJsonJ(JobjRes);
					if (JobjRes.has(JTransmitter.get("responseStatFieldJ").getAsString())) {
						sResValMsg = JobjRes.get(JTransmitter.get("responseStatFieldJ").getAsString()).getAsString();
						if (I$utils.$iStrFuzzyMatch(JTransmitter.get("resSuccVal").getAsString(), sResValMsg)) {
							try {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg", JobjRes);
							} catch (Exception ex) {
								// eat
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$Result);
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
									"TRANSACTION COMPLETED SUCCESSFULLY ");
							// return isonMsg;
						} else {
							try {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg", JobjRes);
							} catch (Exception ex) {
								// eat
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$Result);
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED ");
							// return isonMsg;

						}
					}
					;

				} else if (I$utils.$iStrFuzzyMatch(JTransmitter.get("resType").getAsString(), "XML")) {
					String originalResp = "N";
					if (JTransmitter.has("originalResp")) {
						originalResp = JTransmitter.get("originalResp").getAsString();
					}
					
						// XML Logic
						String sResponseXPathQuery = JTransmitter.get("responseXPathQuery").getAsString();
						String sXmlBody = JResp.get("resBody").getAsString();
						sXmlBody = I$Imputils.xmlEscapeText(sXmlBody);
						// Getting content of S:Body Element:
						// #BVB00060 Starts
						if (I$utils.$iStrFuzzyMatch(JTransmitter.get("OPR_TYPE").getAsString(), "CALLWS")) {
							// #BVB00040 Starts
							sXmlBody = I$XmlParser.getTagValue(JTransmitter.get("resParentNode").getAsString(),
									sXmlBody);
							// #BVB00040 Ends

						} else {
							sResValMsg = sXmlBody;
						}
						// #BVB00060 Ends

						sResValMsg = I$XmlParser.getXpathValDom(sResponseXPathQuery, sXmlBody);
						JsonObject cbsMsg = new JsonObject(); // #BVB00084
						i$Result = getResultJsonXml(sXmlBody);
						if (I$utils.$iStrFuzzyMatch(JTransmitter.get("resSuccVal").getAsString(), sResValMsg)) {
							try {
								// #BVB00084 Starts
								cbsMsg = getCbsMsgJsonX(sXmlBody);
								cbsMsg.addProperty("cbsMsg2", ""); // #BVB00201
								// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg",
								// getCbsMsgJsonX(sXmlBody));
								
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg", cbsMsg);
								// #BVB00084 Ends
							} catch (Exception ex) {
								// eat
							}
							;
							if (I$utils.$iStrFuzzyMatch(originalResp, "Y")) {
								i$Result.addProperty("sXmlBody", sXmlBody);
							}
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$Result);
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
									"TRANSACTION COMPLETED SUCCESSFULLY ");
							// return isonMsg; // #BVB00040
						} else {

							try {
								// #BVB00084 Starts
								cbsMsg = getCbsMsgJsonX(sXmlBody);
								cbsMsg.addProperty("cbsMsg1", ""); // #BVB00201
								// i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg",
								// getCbsMsgJsonX(sXmlBody));
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Result, "cbsMsg", cbsMsg);
								// #BVB00084 Ends
							} catch (Exception ex) {
								// eat
							}
							;
							if (I$utils.$iStrFuzzyMatch(originalResp, "Y")) {
								i$Result.addProperty("sXmlBody", sXmlBody);
							}
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$Result);
							if (I$utils.$iStrBlank(i$Result.getAsJsonObject("cbsMsg").get("cbsMsg2").getAsString())) {//#MVT00108 changes begins
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "TRANSACTION FAILED");
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										i$Result.getAsJsonObject("cbsMsg").get("cbsMsg2").getAsString());
							}	//#MVT00108 changes ends						
							// return isonMsg; // #BVB00040
						}

						// Else needs to be added BVB 
				} else {
					// God Knows What you are trying to Do :)
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKOWN TRANSACTION FORMAT ");
					// return isonMsg; // #BVB00040
				}
				;
			} else {
				// Failed Block
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN NET#CB89001# COMMUNICATION "); // BVB
																													// Error
																													// Code
																													// coming
																													// from
				// Prev layer
				// return isonMsg;// #BVB00040
			}
			;

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN NET#CB89001# COMMUNICATION ");
		}
		i$ResM.getBody(isonMsg).addProperty("unqCommID", JResp.get("unqCommID").getAsString()); // #BVB00148
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, JLogger, "iResMsg", isonMsg); // #BVB00078
		return isonMsg;

	}

	// # BVB00060 Starts
	public JsonObject callWSAdapter(JsonObject JTransmitter) {
		JsonObject JResp = new JsonObject();
		JsonObject i$Res = new JsonObject();
		try {
			JsonParser parser = new JsonParser();
			JsonObject i$Req = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();
			JsonObject i$ReqB = new JsonObject();
			i$ReqB.addProperty("p_is_req_clob", JTransmitter.get("p_is_req_clob").getAsString());
			i$ReqB.addProperty("p_is_res_clob", JTransmitter.get("p_is_res_clob").getAsString());
			i$ReqB.addProperty("p_req_xml_clob", JTransmitter.get("reqBody").getAsString().replace("\\\"", "\""));
			i$ReqB.addProperty("p_instr_xml", JTransmitter.get("p_instr_xml").getAsString());
			i$ReqB.addProperty("p_spl_parsing", JTransmitter.get("p_spl_parsing").getAsString()); // #BVB00158
			i$ReqB.addProperty("p_blk_parsing", JTransmitter.get("p_blk_parsing").getAsString()); // #BVB00158
			i$Res.addProperty("unqCommID", JTransmitter.get("unqCommID").getAsString()); // #BVB00148
			logger.debug("i$Req: " + i$ReqB);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Req, i$ResM.I_BDYTAG, i$ReqB);
			JResp = flexWsAdap.I$FireflxReqBody(i$Req);
			if (!I$utils.$isNull(JResp)) {
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(JResp), i$ResM.I_SUCC)) {
					i$Res.addProperty("resStat", i$ResM.I_SUCC);
					i$Res.addProperty("resCode", "200"); // Need to Check This
					i$Res.addProperty("resBody", i$ResM.getBodyElementS(JResp, "p_res_xml_clob"));
				}
				// #BVB00088 Starts
				else {
					i$Res.addProperty("resStat", i$ResM.I_ERR);
					i$Res.addProperty("resCode", "400"); // Need to Check This
					i$Res.addProperty("resBody", "");
					i$Res.addProperty("resExp", i$ResM.getMsgtext(JResp));

				}
				// #BVB00088 Ends
			} else {
				i$Res.addProperty("resStat", i$ResM.I_ERR);
				i$Res.addProperty("resCode", "400"); // Need to Check This
				i$Res.addProperty("resBody", "");
				i$Res.addProperty("resExp", i$ResM.getMsgtext(JResp)); // #BVB00088
			}

		} catch (Exception e) {
			e.printStackTrace();
			i$Res.addProperty("resStat", i$ResM.I_ERR);
			i$Res.addProperty("resCode", "400"); // Need to Check This
			i$Res.addProperty("resBody", "");
			i$Res.addProperty("resExp", "FAILED WITH :" + e.getMessage()); // #BVB00088
			// JResp = i$ResM.iHandleResStat(JResp, i$ResM.I_ERR, "FAILED IN NET#CB89002#
			// COMMUNICATION ");
		}

		return i$Res;
	}
	// #BVB00060 Ends

	// #BVB00088 Starts
	public JsonArray getTransmitter(JsonObject isonMsg) {
		JsonArray JCoreDets = new JsonArray();
		try {
			String sMatchStr = getMatchString();
			String sSortStr = "{\"chunkId\": -1}";
			JCoreDets = db$Ctrl.db$GetRows$Sort("ICOR_C_WS_TRANSMITTER", sMatchStr, sSortStr);
		} catch (Exception e) {
			logger.debug("Failed in getTransmitter while fetching details with: " + e.getMessage());
			JCoreDets = null;
		}
		return JCoreDets;
	}

	public JsonObject routeRequest(String clsName, String funcName, JsonObject argJson) {
		JsonObject result$ = new JsonObject();
		try {
			Class<?> ctrlClass;
			ctrlClass = Class.forName(clsName);
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod(funcName, JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, argJson, null, null);
		} catch (Exception e) {
			logger.debug("Failed in Routing the request with: " + e.getMessage());
			result$ = i$ResM.iHandleResStat(result$, i$ResM.I_ERR, "FAILED IN POST PROCESSING with: " + e.getMessage());
		}

		return result$; // Need to check this // #BVB00172
	}

	// #BVB00088 Ends
// #BVB00148 Starts 
	public JsonObject coreReqFwdRetry(JsonObject isonMsg) {
		try {
			String unqCommId = i$ResM.getBodyElementS(isonMsg, "unqCommID");
			JsonObject i$res = coreReqFwdRetry(unqCommId);

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$ResM.getBody(i$res));
			i$ResM.iHandleResStat(isonMsg, i$ResM.getStatMsg(i$res), i$ResM.getMsgtext(i$res));

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN RETRY ", e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject coreReqFwdRetry(String unqCommId) {
		JsonObject JResp = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject isonMsg = new JsonObject();
		try {
			isonMsg = parser.parse(i$ResM.I_REQTPL_NBDY).getAsJsonObject();

			filter.addProperty("unqCommID", unqCommId);
			JsonObject request = db$Ctrl.db$GetRow("ICOR_C_TRNFWD_MONITOR", filter);
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(request.getAsJsonObject("iResMsg")), i$ResM.I_SUCC)) {
				request.remove("_id");
				String finalReq = request.get("extReqMsg").getAsString();
				request.remove("extReqMsg");
				request.addProperty("reqBody", finalReq);

				// Get JTrasmitter
				filter = new JsonObject();
				filter.addProperty("trnCd", request.get("trnCd").getAsString());
				filter.addProperty("ctrnCd", request.get("ctrnCd").getAsString());
				filter.addProperty("ctrnOpr", request.get("ctrnOpr").getAsString());
				filter.addProperty("ctrnOpr1", request.get("ctrnOpr1").getAsString());
				filter.addProperty("ctrnOpr2", request.get("ctrnOpr2").getAsString());
				filter.addProperty("ctrnOpr3", request.get("ctrnOpr3").getAsString());
				filter.addProperty("trnOpr", request.get("trnOpr").getAsString());
				filter.addProperty("trnOpr1", request.get("trnOpr1").getAsString());
				filter.addProperty("trnOpr2", request.get("trnOpr2").getAsString());
				filter.addProperty("trnOpr3", request.get("trnOpr3").getAsString());

				JsonObject JCoreDets = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
				JTransmitter = JCoreDets;

				if (logReqAsWIPRetry(request)) {
					// #BVB00060 Starts
					if (I$utils.$iStrFuzzyMatch(request.get("oprType").getAsString(), i$ResM.I_CALLWS)) {

						JResp = I$EWSLnchr.ILaunchReq(request);
						// #BVB00060 Starts
					} else if (I$utils.$iStrFuzzyMatch(request.get("oprType").getAsString(), "CALLJAVA")) {
						JResp = callWSAdapter(request);

					}
					// #BVB00060 Ends
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, request, "procStatus", "DONE");
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, request, "impactoDoneDtTime",
							i$ResM.addDateTime(new Date()));
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, request, "trnStat", "2");
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, request, "trnReplyCode",
							JResp.get("resCode").getAsString());
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, request, "extResMsg", JResp.get("resBody").getAsString());
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, request, "trnMsg", JResp.get("resStat").getAsString());
				} else {
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN RETRY ");
				}
				;

				isonMsg = processResponse(JResp, isonMsg);
				// #BVB00088 Starts
				// Adding POSTFLIGHT_OPRS
//			if (i$JCoreDet.has("postflightOprs")) {
//				isonMsg = routeRequest(postFlightclsName, "processRes", isonMsg);
//			}
				// #BVB00088 Ends
				request.add("iResMsg", isonMsg); // #BVB00201
				logReqAsDoneRetry(request);
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NOT APPLICABLE FOR RETRY");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED IN RETRY ", e.getMessage());
		}
		return isonMsg;
	}
// #BVB00148 Ends
	
	public void updateCbsDetails(JsonObject isonMsg) {
		try {
			JsonObject ibody = i$ResM.getBody(isonMsg);
			JsonObject filter = new JsonObject();
			JsonObject cbsMsg = new JsonObject();
			JsonObject updateObj = new JsonObject();
			cbsMsg = ibody.get("cbsMsg").getAsJsonObject();
			updateObj.add("cbsDetails" , cbsMsg);
			updateObj.addProperty("batchNo", ibody.get("batchNo").getAsString());
			updateObj.addProperty("ReferenceNo", ibody.get("REFERENCE_NO").getAsString());
			filter.addProperty("trnData.batchNo", ibody.get("batchNo").getAsString());
			db$Ctrl.db$UpdateRow("ICOR_C_PAYROLL_CIF_FT_COLL", updateObj, filter);
		}catch(Exception e) {
			
		}
	}
	
	//PKY00072 starts
	public void generateMiniStatement(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		String blkMsg = null;
		if (i$body.has("BLK_MESSAGE")) {
			blkMsg = i$body.get("BLK_MESSAGE").getAsString();
		} else {
			blkMsg = i$body.get("CLVWS_DLY_MSG_OUT").getAsString();
		}
		try {
//			String pdf$Content = "";
			String refNo = "";
			String statementType = "";
			if (I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "CASA_MSDVWMSG")) {
//				pdf$Content = i$body.get("BLK_MESSAGE").getAsString();
				refNo = JLogger.get("trnData").getAsJsonObject().get("refno").getAsString();
				statementType = "CASA MINI STATEMENT";
			} else if (I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "LOAN_CLDGNADV")) {
//				pdf$Content = i$body.get("CLVWS_DLY_MSG_OUT").getAsString();
				refNo = JLogger.get("trnData").getAsJsonObject().get("refrenceNo").getAsString();
				statementType = "LOAN MINI STATEMENT";
			}
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);//MSA00020 starts
			document.setMargins(10, 10, 20, 20);
			PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
//			IFuncSrvcController.HeaderFooterPageEvent3 event = i$FuncSrvContr.new HeaderFooterPageEvent3();
//			writer.setPageEvent(event);
//			event.onStartPage(writer, document);
//			event.onEndPage(writer, document);
			//MSA00020 ends
			document.open();
			Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
			Chunk content = new Chunk(blkMsg);
			Paragraph para = new Paragraph();
			para.add(content);
			para.setLeading(0, 1);
//			 Chunk glue = new Chunk(new VerticalPositionMark());
			PdfPTable table = new PdfPTable(1);
			table.setWidthPercentage(95);
			PdfPCell cell = new PdfPCell();
			// cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell.setBorderColor(BaseColor.DARK_GRAY);
			// PdfPCell cell2 = new PdfPCell();
			Font font2 = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
			Paragraph para2 = new Paragraph(statementType, font2);
			Paragraph para3 = new Paragraph();
			para3.setFont(font);
			para3.add("Reference No : ");
			para3.add(refNo+"\n");
			para3.add("Transaction Date : ");
			para3.add(new Phrase(DateTime.now().toString("MMM dd, YYYY hh:mm:ss")));
			Paragraph para4 = new Paragraph(" ", font);
			para3.setAlignment(Element.ALIGN_RIGHT);
			para2.setAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(50);
			cell.setPadding(5);
			cell.setPaddingTop(10);
			cell.setVerticalAlignment(Element.ALIGN_LEFT);
			cell.addElement(para2);
			cell.addElement(para3);
			cell.addElement(para4);
			cell.addElement(para);
//			cell.setTextAlignment(TextAlignment.CENTER);
			//cell.setHorizontalAlignment(0);
			// cell.addElement(para2);
			table.addCell(cell);
			document.add(table);
			document.close();
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
			//MSA00020 starts
			JsonObject isonMsgCopy = isonMsg.deepCopy();
			JsonObject i$Body = new JsonObject();
			if (I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "CASA_MSDVWMSG")) {
				i$body.addProperty("BLK_MESSAGE", base64Str);
			}
			else if (I$utils.$iStrFuzzyMatch(JLogger.get("trnCd").getAsString(), "LOAN_CLDGNADV")) {
				i$body.addProperty("CLVWS_DLY_MSG_OUT", base64Str);
			}//MSA00020 ends
			JsonObject i$Header = isonMsgCopy.getAsJsonObject("i-header");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation1", "FILEUPLD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "screenid", "FDMFLUPD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation", "CREATE");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileName", refNo + ".pdf");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileExtn", ".pdf");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileSize", 2307138);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocType", statementType);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "I#FileData", base64Str);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Compressed", "N");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "OriginalFileName", "N");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "tranId", "y9m6jis5r3cGZTEqxGzS");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID1", "MINI STATEMENT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "LinkedCustNo", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocNo", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubVersion", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueDt", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocExpiryDt", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueAuthority", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldIP", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldSrc", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key5", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key6", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key7", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key8", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key9", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key10", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "TmpStorageRec", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldDateTime", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocPlaceIssue", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld5", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld6", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld7", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld8", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld9", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld10", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocVersion", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_HEADER, i$Header);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_BDYTAG, i$Body);
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsgCopy, i$ResM.I_STATTAG);

			JsonObject isonReqhead = new JsonObject();
			JsonObject isonMapJson = new JsonObject();
			String ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController";
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsgCopy, isonReqhead, isonMapJson); // #BVB00068
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-SUCC")) {
				String FileUrlToken = result$.get("i-body").getAsJsonObject().get("FileUrlToken").getAsString();
				String Query = "FileUrlToken="+FileUrlToken;
				//String url = "http://localhost:63002/ImpactoPuppy_Core/miniStatement.pdf?"+Query; //local
				String url = "https://impactosuitedeveloper.com/ImpactoWebPuppy/miniStatement.pdf?"+Query; //remote
				//i$body.addProperty("FileUrlToken", FileUrlToken);
				i$body.addProperty("url", url);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//PKY00072 ends
	
	// SRI00041 Changes Starts
	 public JsonObject transactionMonitorSummary(JsonObject isonMsg) {
	        try {
	            JsonObject i$body = isonMsg.getAsJsonObject("i-body");
	            JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
	            JsonObject filter = new JsonObject();
	            JsonObject sort = new JsonObject();
	            JsonArray transactionData = new JsonArray();
	            JsonObject i$Projection = new JsonObject();
	            String Coll_Name ="ICOR_C_TRNFWD_MONITOR";
	            sort.addProperty("_id", -1);
	            int iRowCnt = 0;

	            if (i$ProjectionArray != null) {
	                for (int i = 0; i < i$ProjectionArray.size(); i++) {
	                    i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
	                }
	            }
	            String extSys = i$body.get("extSys").getAsString();
	            filter.addProperty("extSys", extSys);
	            JsonArray trnCdValues = new JsonArray();
	            trnCdValues.add("ACH");
	            trnCdValues.add("CASA150");
	            trnCdValues.add("LoanRepayment");
	            trnCdValues.add("CD");
	            trnCdValues.add("CIF");
	            trnCdValues.add("CW");
	            trnCdValues.add("FT");
	            trnCdValues.add("IFT");
	            trnCdValues.add("LETTERIFT");
	            trnCdValues.add("LINCU");
	            trnCdValues.add("LOAN");
	            trnCdValues.add("PR");
	            trnCdValues.add("TD");

	            JsonObject trnCdFilter = new JsonObject();
	            JsonArray updatedTransactionData = new JsonArray();
	            trnCdFilter.add("$in", trnCdValues);
	            filter.add("trnCd", trnCdFilter);
	            JsonObject i$Match = i$ResM.getMatch(isonMsg);
	            Integer i$MaxRow = -1;
	            try {
	                i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
	            } catch (Exception e) {
	                try {
	                    i$MaxRow = isonMsg.get("MaxRows").getAsInt();
	                } catch (Exception ex) {
	                    i$MaxRow = -1;
	                };
	            };
	            int intPgNo, intRecs;
	            try {
	                intPgNo = i$body.get("intPgNo").getAsInt();
	            } catch (Exception e) {
	                intPgNo = 0;
	            }
	            try {
	                intRecs = i$body.get("intRecs").getAsInt();
	            } catch (Exception e) {
	                intRecs = 0;
	            }

	            iRowCnt = db$Ctrl.db$GetCountI("ICOR_C_TRNFWD_MONITOR", filter);
	            transactionData = db$Ctrl.db$GetRows$Sort(Coll_Name, filter, i$Projection, intPgNo, intRecs, sort);
	            int batchSize = 2000;
	            int totalRecords = transactionData.size();

	            // Define a map to store transaction codes and their descriptions
	            Map<String, String> TRANSACTION_DESCRIPTIONS = new HashMap<>();
	            TRANSACTION_DESCRIPTIONS.put("ACH", "ACH transfers");
	            TRANSACTION_DESCRIPTIONS.put("CASA150", "Shares Deposit");
	            TRANSACTION_DESCRIPTIONS.put("LoanRepayment", "LoanRepayment");
	            TRANSACTION_DESCRIPTIONS.put("CD", "Cash Deposit");
	            TRANSACTION_DESCRIPTIONS.put("CIF", "CIF Creation");
	            TRANSACTION_DESCRIPTIONS.put("CW", "Cash Withdrawal");
	            TRANSACTION_DESCRIPTIONS.put("FT", "Fund Transfer");
	            TRANSACTION_DESCRIPTIONS.put("IFT", "Internal Fund Transfer");
	            TRANSACTION_DESCRIPTIONS.put("LETTERIFT", "Letter Payment Digi App");
	            TRANSACTION_DESCRIPTIONS.put("LINCU", "LINCU");
	            TRANSACTION_DESCRIPTIONS.put("LOAN", "Loan Creation");
	            TRANSACTION_DESCRIPTIONS.put("PR", "Pay Roll");
	            TRANSACTION_DESCRIPTIONS.put("TD", "Term Deposit");

	            for (int batchStart = 0; batchStart < totalRecords; batchStart += batchSize) {
	                int batchEnd = Math.min(batchStart + batchSize, totalRecords);
	                JsonArray batch = new JsonArray();
	                for (int j = batchStart; j < batchEnd; j++) {
	                    try {
	                        JsonObject jsonObject = transactionData.get(j).getAsJsonObject();
	                        if (jsonObject.has("trnCd")) {
	                            String trnCd = jsonObject.get("trnCd").getAsString();
	                            // Get transaction description using the map
	                            String transactionDescription = TRANSACTION_DESCRIPTIONS.getOrDefault(trnCd, "");
	                            jsonObject.addProperty("transactionDescription", transactionDescription);
	                            String accNo = getMemberAcc(jsonObject, trnCd);
	                            jsonObject.addProperty("accountNumber", accNo);
	                            String memberId = getMemberId(jsonObject, trnCd);
	                            jsonObject.add("memberInfo", getCifData(memberId));
	                            if (jsonObject.has("iResMsg")) {
	                                JsonObject iResMsg = jsonObject.getAsJsonObject("iResMsg");
	                                if (iResMsg.has("i-body")) {
	                                    JsonObject iBody = iResMsg.getAsJsonObject("i-body");
	                                    if (iBody.has("REFERENCE_NO")) {
	                                        String referenceNo = iBody.get("REFERENCE_NO").getAsString();
	                                        jsonObject.addProperty("REFERENCE_NO", referenceNo);
	                                    } else {
	                                        // If "REFERENCE_NO" doesn't exist, take the unique ID
	                                        String unqCommID = iBody.get("unqCommID").getAsString();
	                                        String[] parts = unqCommID.split("-");
	                                        String uniqueId = parts[parts.length - 1];
//	                                        jsonObject.addProperty("REFERENCE_NO", uniqueId);
	                                        iBody.addProperty("REFERENCE_NO", uniqueId);
	                                    }
	                                }
	                            }
	                            updatedTransactionData.add(jsonObject);
	                        }
	                    } catch (Exception e) {
	                        e.printStackTrace();
	                    }
	                }
	            }
//				if (i$body.has("dataSetFltr")) {
//					
//				}
	            i$body.addProperty("iRowCnt", iRowCnt);
	            i$body.add("iRowData", updatedTransactionData);
	            isonMsg= i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
	            isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return isonMsg;
	    }

	    public String getMemberId(JsonObject jsonObject, String trnCd) {
	        switch (trnCd) {
	            case "ACH":
	                return jsonObject.get("trnData").getAsJsonObject().get("txnAcc").getAsString().substring(3, 9);
	            case "CASA150":
	                return jsonObject.get("trnData").getAsJsonObject().get("custNo").getAsString();
	            case "LoanRepayment":
	                return jsonObject.get("trnData").getAsJsonObject().get("accountNumber").getAsString().substring(3, 9);
	            case "CD":
	                return jsonObject.get("trnData").getAsJsonObject().get("creditAccNo").getAsString().substring(3, 9);
	            case "CIF":
	                return jsonObject.get("trnData").getAsJsonObject().get("custNo").getAsString();
	            case "CW":
	                return jsonObject.get("trnData").getAsJsonObject().get("debitAccNo").getAsString().substring(3, 9);
	            case "FT":
	            case "IFT":
	                return jsonObject.get("trnData").getAsJsonObject().get("creditAccNo").getAsString().substring(3, 9);
	            case "LETTERIFT":
	                return jsonObject.get("trnData").getAsJsonObject().get("debitAccNo").getAsString().substring(3, 9);
	            case "LINCU":
	                return jsonObject.get("trnData").getAsJsonObject().get("acc").getAsString().substring(3, 9);
	            case "LOAN":
	                return jsonObject.get("trnData").getAsJsonObject().get("custNo").getAsString();
	            case "PR":
	                return jsonObject.get("trnData").getAsJsonObject().get("debitAccNo").getAsString().substring(3, 9);
	            case "TD":
	                return jsonObject.get("trnData").getAsJsonObject().get("custNo").getAsString();
	            default:
	                return "";
	        }
	    }
	    
	    public String getMemberAcc(JsonObject jsonObject, String trnCd) {
	        switch (trnCd) {
	            case "ACH":
	                return jsonObject.get("trnData").getAsJsonObject().get("txnAcc").getAsString();
	            case "CASA150":
	                return jsonObject.get("trnData").getAsJsonObject().get("150Account").getAsString();
	            case "LoanRepayment":
	                return jsonObject.get("trnData").getAsJsonObject().get("accountNumber").getAsString();
	            case "CD":
	                return jsonObject.get("trnData").getAsJsonObject().get("creditAccNo").getAsString();
	            case "CIF":
	                return jsonObject.get("trnData").getAsJsonObject().get("custNo").getAsString();
	            case "CW":
	                return jsonObject.get("trnData").getAsJsonObject().get("debitAccNo").getAsString();
	            case "FT":
	            case "IFT":
	                return jsonObject.get("trnData").getAsJsonObject().get("creditAccNo").getAsString();
	            case "LETTERIFT":
	                return jsonObject.get("trnData").getAsJsonObject().get("debitAccNo").getAsString();
	            case "LINCU":
	                return jsonObject.get("trnData").getAsJsonObject().get("acc").getAsString();
	            case "LOAN":
	                return jsonObject.get("trnData").getAsJsonObject().get("accNo").getAsString();
	            case "PR":
	                return jsonObject.get("trnData").getAsJsonObject().get("debitAccNo").getAsString();
	            case "TD":
	                return jsonObject.get("trnData").getAsJsonObject().get("termAcNo").getAsString();
	            default:
	                return "";
	        }
	    }

	    public JsonObject getCifData(String memberId) {
	        JsonObject filter = new JsonObject();
	        filter.addProperty("CustomerId", memberId);
	        JsonObject proj = new JsonObject();
	        proj.addProperty("_id", 0);
	        proj.addProperty("CustomerId", 1);
	        proj.addProperty("CustomerFullName", 1);
	        proj.addProperty("CustomerEmailId", 1);
	        proj.addProperty("CustomerMobileId", 1);
	        proj.addProperty("CustomerBranch", 1);
	        return db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, proj);
	    }
	 // SRI00041 Changes Ends
}

// #00000001 Ends