/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Oct 5, 2018  | #BVB00005   | 1) 2) Making i-Match available in DB
      |0.1 Beta    | Vijay 		| Nov 29, 2018 | #BVB00016   | Feature I-Projection added 
      |0.1 Beta    | Vijay 		| Dec 1, 2018  | #BVB00019   | Rights should not be checked for LOV Screen Id's  
      |0.1 Beta    | Vijay 		| Dec 9, 2018  | #BVB00021   | 1) Added SOpr1, SOpr2 to in parameters to validate Request 2) Macro Economical Changes to calc pdMacroValue
      |0.1 Beta    | Vijay 		| Dec 11, 2018 | #BVB00027   | Moving QUERYMASTER to operation2 rather than in operation 
      |0.1.6       | Vijay 		| Dec 14, 2018 | #BVB00029   | Adding isonMsg to call DB Controller 
      |0.2.1       | Vijay 		| Jan 07, 2018 | #BVB00033   | 1) Adding Process Message Handler 
      														   2) Moved individual screen validation to iReqManipulator 
      														   3) Added ResPreFlightHandler for handling post actions of reponse  
      														   4) IProjectionMap Null check added. 
      |0.2.1       | Vijay 		| Jan 09, 2019 | #BVB00035   | Encryption Decryption based on Maintenance , Removed Duplicate ScrID 
      |0.2.1       | Syed 		| Jan 07, 2018 | #MAQ00001   | Adding I match condition for Summary  
      |0.1.6       | Valla 		| Dec 26, 2018 | #V0000030   | Import functionalities code   		
      |0.2.1       | Syed 		| Jan 31, 2018 | #MAQ00002   | Adding Pagination code
      |0.2.1       | Syed 		| Feb 07, 2018 | #MAQ00003   | Commented one Condition for I-Match of Summary calls
      |MVP 2.0     | Syed 		| Mar 18, 2019 | #MAQ00004   | Added Get$Count function
      |0.3.3	   | Syed 		| Apr 06, 2019 | #MAQ00005   | Added Sorting function for all Summary pages
      |0.3.6       | Vijay 		| Apr 17, 2019 | #BVB00119   | Release And Acquire Feature Release 
      |0.3.2.202   | Syed 		| Apr 08, 2019 | #MAQ00009   | Changed GET$COUNT function for Summary calls 
      |0.3.6       | Vijay 		| Apr 24, 2019 | #BVB00127   | Adding IProjection to Query
      |0.3.9.240   | Syed 		| May 18, 2019 | #MAQ00013   | Sort function made dynamic based of field
      |0.3.9.240   | Syed 		| May 18, 2019 | #MAQ00014   | GetCount and GetData response merged for operation2='GET$PAG'
      |0.3.9.241   | Niegil 	| May 22, 2019 | #NYE00014   | LOV Dataset Filter Changes       
      |0.3.9.241   | Niegil 	| May 27, 2019 | #NYE00015   | Changes for $Where handling Dataset       
      |0.3.9.241   | Niegil 	| May 28, 2019 | #NYE00016   | Changes for Ends With DataSet Filter     
      |0.3.14      | Vijay 	    | Jun 10, 2019 | #BVB00164   | NoSqlInjection Correction Changes
      |0.3.14      | Vijay 	    | Jun 10, 2019 | #BVB00165   | No records found is giving exception during Query
      |0.3.15      | Vijay  	| Jun 15, 2019 | #BVB00167   | Acquire And Release Fixes
      |0.3.15.293  | Syed 		| Jun 21, 2019 | #MAQ00020   | Changed Gson to Gson Builder
      |0.3.16      | Vijay  	| Jul 10, 2019 | #BVB00183   | IMatch will accept an Array for Summary
      |0.3.17      | Vijay  	| Jul 22, 2019 | #BVB00188   | IMatch should match with Body Request
      |0.3.18      | Pappu      | Mar 18, 2021 | #PKY00004   | Sort function made dynamic based on object
      
----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder; // #MAQ00020 
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.ISeqConsistencyController;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
//import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.iEmailService;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class ICustomerServiceStatusController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(ICustomerServiceStatusController.class);
	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private IgenericWorker igenericWorker = new IgenericWorker();
	private JsonObject i$Annotate = null;
	private ISeqConsistencyController i$seqConsCtrl = new ISeqConsistencyController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		// JsonObject i$Annotate = null;
		String Coll_Name, L_Coll_Name;
//		Gson gson = new Gson();
	    Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonObject projection = new JsonObject();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();
		 
		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
		try {
			// #BVB00019 Starts
			boolean hasRights = true;
//			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
//				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
//			else
//				hasRights = true;

			// #NYE00014 Rebuild IMatch if "dataSetFltr" Key is Present and Operation is Summary
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY"))
			{
				
				JsonObject j$DataFilter = get$FrmDataSetFilter(isonMsg);
				if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr")))
				{

					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,j$DataFilter.get("Invalid$Expr").getAsString() );
					return isonMsg;
				}
				// #NYE00015 Begin
				else if (j$DataFilter != null)
				{
					// Get Formated I-MATCH Dataset Filter
					i$Match = j$DataFilter;
				}
				// #NYE00015 End
			}
			//	#NYE00014
			
			// if (db$Ctrl.db$hasRights(i$ResM.iloggedUser, ScrId, SOpr)) {
			if (hasRights) {

				// #BVB00019 Ends

				if (i$Match == null) {
					JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
					i$Match = new JsonObject();
					try {
						// if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
								&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") // #MAQ00001
						)) {

							for (int i = 0; i < i$MatchMap.size(); i++) {
								// #BVB00183 Starts 
								 JsonElement matchElm = i$ResM.getBodyElement(isonMsg,i$MatchMap.get(i).getAsString());
								 if(!I$utils.$isNull(matchElm) ) { // #BVB00188 
								 if(matchElm.isJsonPrimitive()) {
									 i$Match.addProperty(i$MatchMap.get(i).getAsString(),
										i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
								 }else if(matchElm.isJsonArray()) { 
									 JsonArray matchArr = matchElm.getAsJsonArray();
									 String iMatchStr = "{'$in': ['"; 
									 for(int j =0; j< matchArr.size(); j++) {
										 if(j<matchArr.size()-1)
										 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"','"; 
										 else {
											 iMatchStr = iMatchStr + matchArr.get(j).getAsString()+"']}";
										 }
									 }
									 
									 i$Match.add(i$MatchMap.get(i).getAsString(), parser.parse(iMatchStr).getAsJsonObject()); 
									 
								 }
								 // #BVB00183 Ends
								 // #BVB00188 Starts 
								 }else {
									 isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
										return isonMsg;
								 }
								 // #BVB00188 Ends
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
						} else {
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
						}
					} catch (Exception e) {
						logger.error("Error description : ", e);
						i$Match = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}"); // #MAQ00001
					}
					;

				}
				;

				// #BVB00005 Ends
				// #BVB00016 Starts
				if (i$ProjectionArray != null) {
					for (int i = 0; i < i$ProjectionArray.size(); i++) {
						i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
					}
				} else {

					JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
					if (i$ProjectionMap != null) {// #BVB00033
						try {
							if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
								for (int i = 0; i < i$ProjectionMap.size(); i++) {
									i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
								}
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
							} else {
								i$Projection = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
							}
						} catch (Exception e) {
							e.printStackTrace();
							i$Projection = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
						}
						;
						// #BVB00033 Starts
					} else {
						i$Projection = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
					}
					// #BVB00033 Ends
					// i$Projection = new JsonObject();
				}
				// #BVB00016 Ends

				// #BVB00035 Starts
				projection = new JsonObject();
				projection.addProperty("privateKey", 1);
				JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
				String privateKey = cParam.get("privateKey").getAsString();
				JsonObject filter = new JsonObject();
				filter.addProperty("sessoinId", i$ResM.getClientSessionID(isonMsg));
				JsonObject sessionValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", gson.toJson(filter),
						gson.toJson(projection));

				// #BVB00035 Ends

				Integer i$MaxRow = -1;
				// #BVB00005 Starts
				JsonObject i$recordDetails = new JsonObject();
				JsonObject i$validateRes = new JsonObject();
				JsonObject i$ledgerCurVer = new JsonObject();
				// #BVB00005 Ends
				try {
					i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
				} catch (Exception e) {
					try {
						i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
					} catch (Exception ex) {
						i$MaxRow = -1;
					}
					;
				}
				;

				try {
					Coll_Name = isonMapJson.get("COLLNAME").getAsString();
				} catch (Exception e) {
					Coll_Name = null;
				}
				;

				if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
						|| (I$utils.$iStrBlank(gson.toJson(i$Match)))
				/* || I$utils.$iStrFuzzyMatch(gson.toJson(i$Match), "{}") */ ) { // #MAQ00003
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
					return isonMsg;
				}
				;

				try {
					L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
				} catch (Exception e) {
					L_Coll_Name = null;
				}
				;

				if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
					return isonMsg;
				}
				;

				try {
					// String ScrID = i$ResM.getScreenID(isonMsg); // #BVB00035
					String SOpr1 = i$ResM.getOpr1(isonMsg);
					String SOpr2 = i$ResM.getOpr2(isonMsg);
					String SOpr3 = i$ResM.getOpr3(isonMsg);
					/*
					 * if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY") &&
					 * !I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ") && !I$utils.$iStrFuzzyMatch(SOpr,
					 * "QUERY")) {
					 */
					// #MAQ00002 start
					try {
						i$body = isonMsg.getAsJsonObject("i-body");
					} catch (Exception e) {
						i$body = null;
					}
					// #MAQ00002 end

					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}"); // #BVB00035 changes ScrID to ScrId
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;

					} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						// Forwarding Request to DB Handler for SUMMARY
						logger.debug("Forwarding Request to DB Controller for Summary");
						// #MAQ00002 start
						isonMsg.add("i-body", i$body);
						int intPgNo, intRecs;
						try {
							intPgNo = i$body.get("intPgNo").getAsInt();
						} catch (Exception e) {
							intPgNo = 0;
						}
						try {
							intRecs = i$body.get("intRecs").getAsInt();
						} catch (Exception e) {
							intRecs = 0;
						}
						// #MAQ00013 starts
						// #PKY00004 starts
						Gson gsonp = new GsonBuilder().serializeNulls().create();
						String sort = "";
						try {
//							String sortField = i$body.get("sort").getAsString();
//							sort = "{'"+sortField+"':1}";
							
							sort = gsonp.toJson(isonMsg.get("i-sort").getAsJsonObject());
							
						} catch (Exception e) {
							sort = "{'_id':-1}";
						}
						// #PKY00004 ends
						// #MAQ00013 starts

						// #MAQ00004 starts
						if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {

							// #MAQ00009 starts
							int iRowCnt = 0;
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
									}
									// Added
									// Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, "{\"isCurrVer\"=\"Y\"}"); // #BVB00016

								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null)
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
									// Added Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends
						// #MAQ00014 starts
						} else if(I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
							// #MAQ00009 starts
							int iRowCnt = 0;
							JsonObject db$res = null;
							
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										 db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);								
									}
									// Added
									// Projection
									else {
										i$Match = new JsonObject();
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);// #BVB00016 Added
																						// Projection
										
									}
								}  else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master") || I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null) {
										if(!I$utils.$iStrFuzzyMatch(i$body.get("status").getAsString(), "ALL"))
											i$Match.addProperty("status", i$body.get("status").getAsString());
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
												intPgNo, intRecs, sort);
									// Added Projection
										
									}
									else {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
												i$Projection, intPgNo, intRecs, sort);
										
									}
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}
							
							i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
							i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());	
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends
							
						}
						// #MAQ00014 ends
						// #MAQ00004 ends
						else {
							// #MAQ00005 code starts
							if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
								if (i$Match != null) {
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort)); // #BVB00016
								}

								else {
									i$Match = new JsonObject();
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort));// #BVB00016 Added
																					// Projection
								}
							} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
									|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
								if (i$Match != null)
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
											intPgNo, intRecs, sort));// #BVB00016
																		// Added
																		// Projection
								else
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
											i$Projection, intPgNo, intRecs, sort));// #BVB00016

								// #MAQ00005 code ends
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
								return isonMsg;
							}
						}
					} /*
						 * else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYACQ")) {
						 * 
						 * logger.debug("Forwarding Request to DB Controller for Query Accquire"); try {
						 * JsonObject u$pdate = null; i$ledgerCurVer.addProperty("errorMsg",
						 * "Record Sucessfully Retrieved"); db$Ctrl.db$AcqRow(L_Coll_Name, i$Match,
						 * isonMsg); isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg,
						 * i$ResM.I_BDYTAG, i$ledgerCurVer); isonMsg = i$ResM.iHandleResStat(isonMsg,
						 * i$ResM.I_SUCC,"Record Sucessfully Retrieved"); return isonMsg; } catch
						 * (Exception e) { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						 * "OPERATION FAILED"); return isonMsg; }
						 * 
						 * }
						 */ else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
						return isonMsg;
					}
					;
					I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrId, SOpr); // #BVB00035
					if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
						// #BVB00005 Starts
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$body", i$body);
						// Getting the validation data from DB
						// Getting data from Master
						JsonObject i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						JsonObject i$master = db$Ctrl.db$GetRow(Coll_Name, i$runningQuery.toString());
						if (i$master != null) {
							logger.debug("Master Records: " + i$master);
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									i$master);
						} else {
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									"{}");
						}
						// Getting all records of Ledger Except for Deleted Records
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						String ndD = "{\"$ne\":\"D\"}";
						
						i$runningQuery.add("recordStat", parser.parse(ndD).getAsJsonObject());
						JsonArray i$Ledger = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("Ledger Records: " + i$Ledger);
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$Ledger",
								i$Ledger);

						// Getting records with isCurrVer:
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("isCurrVer", "Y");
						JsonArray i$ledgerCurrVer = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerCurrVer: " + i$ledgerCurrVer + " Count: " + i$ledgerCurrVer.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerCurrVer",
								i$ledgerCurrVer);

						// Getting records of Un-Auth
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("authStat", "U");
						JsonArray i$ledgerUnAuth = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerUnAuth: " + i$ledgerUnAuth + " Count: " + i$ledgerUnAuth.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerUnAuth",
								i$ledgerUnAuth);

						i$validateRes = igenericWorker.validateRequest(SOpr, SOpr1, SOpr2, i$recordDetails); // #BVB00021
						if (i$validateRes.get("i-stat").getAsInt() > 0) {
							if (i$ledgerCurrVer.size() > 0)
								i$ledgerCurVer = i$ledgerCurrVer.get(0).getAsJsonObject();
							// #BVB00005 Ends
							// Forwarding Request to DB Handler for Insert
							if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, in$ = null;

										// u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										// i$Match);
										// if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {

										/*
										 * if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) { String userPwd =
										 * i$body.get("userPwd").getAsString(); userPwd =
										 * passwordEncoder.encode(userPwd.toString());
										 * logger.debug("Excrypted Password:", userPwd); i$body.addProperty("userPwd",
										 * userPwd);
										 * 
										 * }
										 */
										// #BVB00021 Starts
										/*
										 * if(I$utils.$iStrFuzzyMatch(ScrId, "OIFHSMES")) { double i$pdMacroValue = 1;
										 * // BVB try { JsonArray i$mVal = i$body.get("mVal").getAsJsonArray(); for(int
										 * i=0; i<i$mVal.size(); i++) { try { JsonObject i$runningValue =
										 * i$mVal.get(i).getAsJsonObject(); double featureValue =
										 * i$runningValue.get("featureValue").getAsDouble(); i$pdMacroValue =
										 * i$pdMacroValue - (featureValue/100); }catch(Exception e) { // Eat Up } }
										 * 
										 * i$pdMacroValue = I$utils.$roundTwoDouble(i$pdMacroValue);
										 * i$body.addProperty("pdMacroValue", i$pdMacroValue); }catch(Exception e) {
										 * e.printStackTrace(); i$pdMacroValue = 0; }
										 * 
										 * };
										 */
										// #BVB00021 Ends

										i$body.addProperty("isCurrVer", "Y");
										i$body.addProperty("authStat", "U");
										i$body.addProperty("recordStat", "O");
										i$body.addProperty("operation", SOpr.toUpperCase());
										i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
										i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
										// i$body.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$body.addProperty("authorizer", "");
										i$body.addProperty("errorMsg", "Record Successfully Saved");
										i$body.addProperty("authorizedOnSrvDate", "");
										m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
										Integer MaxVer = 0;
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
											MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
										}
										;
										i$body.addProperty("verNo", MaxVer + 1);
										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
										i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);

										in$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029

										return in$;
										// } else {
										// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										// "OPERATION FAILED #LUP0001");
										// return isonMsg;
										// }
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
									/*
									 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									 * "OPERATION FAILED"); return isonMsg; }
									 */
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// Forwarding Request to DB Handler for UPDATE
							if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										double i$pdMacroValue = 1; // BVB
										if (i$ledgerUnAuth.size() == 0) {
											u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
													i$Match);
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {

												/*
												 * if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) { String userPwd =
												 * i$body.get("userPwd").getAsString(); userPwd =
												 * passwordEncoder.encode(userPwd.toString());
												 * logger.debug("Excrypted Password:", userPwd);
												 * i$body.addProperty("userPwd", userPwd);
												 * 
												 * }
												 */

												/*
												 * // #BVB00021 Starts if (I$utils.$iStrFuzzyMatch(ScrId, "OIFHSMES")) {
												 * try { JsonArray i$mVal = i$body.get("mVal").getAsJsonArray(); for
												 * (int i = 0; i < i$mVal.size(); i++) { try { JsonObject i$runningValue
												 * = i$mVal.get(i) .getAsJsonObject(); double featureValue =
												 * i$runningValue.get("featureValue") .getAsDouble(); i$pdMacroValue =
												 * i$pdMacroValue - (featureValue / 100); } catch (Exception e) { // Eat
												 * Up } }
												 * 
												 * i$pdMacroValue = I$utils.$roundTwoDouble(i$pdMacroValue);
												 * i$body.addProperty("pdMacroValue", i$pdMacroValue); } catch
												 * (Exception e) { e.printStackTrace(); i$pdMacroValue = 0; }
												 * 
												 * } ; // #BVB00021 Ends
												 */
												i$body.addProperty("isCurrVer", "Y");
												i$body.addProperty("authStat", "U");
												i$body.addProperty("recordStat", "O");
												i$body.addProperty("operation", SOpr.toUpperCase());
												i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
												i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
												i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
												// i$body.addProperty("acquiredBy", i$ResM.iloggedUser);
												i$body.addProperty("acquiredBy", "");
												i$body.addProperty("authorizer", "");
												i$body.addProperty("errorMsg", "Record Successfully Updated");
												i$body.addProperty("authorizedOnSrvDate", "");
												m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
												Integer MaxVer = 0;
												if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
													MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
												}
												;
												i$body.addProperty("verNo", MaxVer + 1);
												// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
												// BVB Starts
												// up$ = db$Ctrl.db$InsertRow(L_Coll_Name, i$body);
												up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
												// BVB Ends
												try {
													JsonObject recIdObject = new JsonObject();
													// #BVB00167 Starts 
													// if (i$master != null) {
													if (I$utils.$isNull(i$ledgerCurVer)) {
														recIdObject = i$master.getAsJsonObject("_id");
													} else {
														recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
													}
													;
													db$Ctrl.db$ReleaseRow(recIdObject);
													//JsonObject re$ = i$releaseLock(recIdObject);
													// db$Ctrl.db$ReleaseRow(Coll_Name, i$Match, IResManipulator.iloggedUser.get());
													
													// #BVB00167 Ends
													// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
													// //
													// Release Lock
												} catch (Exception ex) {
													// Eat Up
												}
												;

												// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
												return up$;

											} else {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
														"OPERATION FAILED #LUP0001");
												return isonMsg;
											}

										} else {

											i$ledgerCurVer = i$body.deepCopy();
											/*
											 * if (I$utils.$iStrFuzzyMatch(ScrId, "OASUSPPF")) { String userPwd =
											 * i$ledgerCurVer.get("userPwd").getAsString(); userPwd =
											 * passwordEncoder.encode(userPwd.toString());
											 * logger.debug("Excrypted Password:", userPwd);
											 * i$ledgerCurVer.addProperty("userPwd", userPwd);
											 * 
											 * }
											 */
											i$ledgerCurVer.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																													// Date
											i$ledgerCurVer.addProperty("acquiredBy", "");
											i$ledgerCurVer.addProperty("errorMsg", "Record Successfully Updated");

											i$ledgerCurVer.remove("_id");
											i$runningQuery = new JsonObject();

											i$runningQuery = i$Match.deepCopy();
											i$runningQuery.addProperty("isCurrVer", "Y");

											// up$ = db$Ctrl.db$UpdateRow(L_Coll_Name,isonMsg, i$ledgerCurVer,
											// i$runningQuery);
											up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer,
													i$runningQuery); // #BVB00029
											try {
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												// JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;

											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;

										}
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00005 Starts
							// Forwarding Request to DB Handler for AUTH
							if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$recordDetails",
											i$recordDetails);
									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$ledgerCurVer = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										// u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										// i$Match);
										// if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
										// i$ledgerCurVer.addProperty("isCurrVer", "Y");
										i$ledgerCurVer.addProperty("authStat", "A");
										// i$ledgerCurVer.addProperty("recordStat", "O");
										i$ledgerCurVer.addProperty("remarks",
												i$ResM.getBodyElementS(isonMsg, "remarks"));
										i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
										i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
										i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
										// i$ledgerCurVer.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("errorMsg", "Record Successfully Authorized");
										// i$body.addProperty("authBy", i$ResM.iloggedUser);
										// i$body.add("authDate", i$ResM.adddate(new Date()));

										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;

										// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											// JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;

										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();

										i$runningQuery = i$Match.deepCopy();
										i$runningQuery.addProperty("isCurrVer", "Y");

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
										i$ledgerCurVer.remove("isCurrVer");
										// Updating/ Inserting data to Master
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();

										up$ = db$Ctrl.db$UpdateRow(Coll_Name, isonMsg, i$ledgerCurVer, i$runningQuery,
												"true"); // #BVB00029

										return up$;
										/*
										 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										 * "OPERATION FAILED #LUP0001"); return isonMsg; }
										 */
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for CLOSE
							if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}", i$Match);
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
											i$body.addProperty("isCurrVer", "Y");
											i$body.addProperty("authStat", "U");
											i$body.addProperty("recordStat", "C");
											i$body.addProperty("operation", SOpr.toUpperCase());
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
											i$body.addProperty("authorizer", "");
											i$body.addProperty("errorMsg", "Record Successfully Closed");
											i$body.addProperty("authorizedOnSrvDate", "");
											m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
											Integer MaxVer = 0;
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
												MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
											}
											;
											i$body.addProperty("verNo", MaxVer + 1);
											// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
											up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
											try {
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												//JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;
											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;
										} else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"OPERATION FAILED #LUP0001");
											return isonMsg;
										}
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for DELETE
							if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										/*
										 * u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										 * i$Match); if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate),
										 * i$ResM.I_SUCC)) {
										 */
										i$ledgerCurVer.addProperty("isCurrVer", "N");
										i$ledgerCurVer.addProperty("authStat", "A");
										i$ledgerCurVer.addProperty("recordStat", "D");
										i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
										i$ledgerCurVer.addProperty("initiator", IResManipulator.iloggedUser.get());
										// i$ledgerCurVer.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
										i$ledgerCurVer.addProperty("errorMsg", "Record Successfully Deleted");
										i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date()));
										i$ledgerCurVer.addProperty("remarks",
												i$ResM.getBodyElementS(isonMsg, "remarks"));

										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;

										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											//JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;
										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();

										i$runningQuery = i$Match.deepCopy();
										i$runningQuery.addProperty("isCurrVer", "Y");

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer,
												i$runningQuery); // #BVB00029
										i$ledgerCurVer.remove("isCurrVer");
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();
										if (i$master != null) {
											i$runningQuery.add("verNo", i$master.get("verNo"));
											u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"Y\"}",
													i$runningQuery);
										}

										return up$;
										/*
										 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										 * "OPERATION FAILED #LUP0001"); return isonMsg; }
										 */
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends

								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00027 Starts
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SOpr2, "")) {
								// #BVB00027 Ends
								try {
									JsonObject u$pdate, m$x, up$ = null;
									i$ledgerCurVer.addProperty("errorMsg", "Record Successfully Retrieved");
									// #BVB00127 Starts 
									if (!I$utils.$isNull(i$Projection)) {
										i$ledgerCurVer = I$impactoUtil.refineJsonObject(i$ledgerCurVer, i$Projection);
									}
									// #BVB00127 Ends
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$ledgerCurVer);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Record Sucessfully Retrieved");
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00027 Starts
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYMASTER")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYMASTER")) {
									// #BVB00027 Ends
									try {
										JsonObject u$pdate, m$x, up$ = null;
										
										if(!I$utils.$isNull(i$master)) { // #BVB00165 
										i$master.addProperty("errorMsg", "Record Successfully Retrieved");
										// #BVB00127 Starts 
										if (!I$utils.$isNull(i$Projection)) {
											i$master = I$impactoUtil.refineJsonObject(i$master, i$Projection);
										}
										// #BVB00127 Ends
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$master);
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
												"Record Successfully Retrieved");
										}
										// #BVB00165 Starts 
										else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
										} 
										// #BVB00165 Ends
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}  
								// #BVB00119 Starts
								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYACQ")) {
									logger.debug("Forwarding Request to DB Controller for Query Accquire");
									try {
										JsonObject u$pdate, ac$ = null;
										// i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Retrieved");
										// #BVB00167 Starts
//										if (i$master != null) {
//											ac$ = db$Ctrl.db$AcqRow(Coll_Name, i$Match);
//										} else {
											ac$ = db$Ctrl.db$AcqRow(L_Coll_Name, i$Match);

										//}
										;
										// #BVB00167 Ends
										// if(i$ResM.getStatMsg(ac$))
										// i$ResM.getMsgtext(ac$)
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
												i$ResM.getiStat(ac$));

										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$ledgerCurVer);

										// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Record Sucessfully
										// Acquired");
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "RELEASELOCK")) {
									logger.debug("Forwarding Request to DB Controller for Query Accquire");
									try {
										JsonObject rl$ = new JsonObject();
//										JsonObject recIdObject = new JsonObject();
//										if (i$master != null) {
//											recIdObject = i$master.getAsJsonObject("_id");
//										} else {
//											recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
//										}
//										;
//										JsonObject re$ = i$releaseLock(recIdObject);
//										/*
//										 * String recID = i$ResM.convertId(recIdObject); JsonObject re$ =
//										 * db$Ctrl.db$ReleaseRow(recID);
//										 */
//										if (i$master != null) {
//											rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
//										} else {
//											rl$ = db$Ctrl.db$ReleaseRowS(L_Coll_Name, i$Match, IResManipulator.iloggedUser.get());
//
//										}
//										;
										rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
												i$ResM.getiStat(rl$));
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								;
// #BVB00119 Ends
							}

							// #BVB00005 Ends
						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									i$validateRes.get("i-Msg").getAsString());
							return isonMsg;
						}
						;

					} else {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
						return isonMsg;
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
							e.getMessage().toString());
					e.printStackTrace();
					return isonMsg;
				}
			} else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
				return isonMsg;
			}

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
//
//	public JsonObject i$releaseLock(JsonObject recIdObject) {
//		try {
//			String recID = i$ResM.convertId(recIdObject);
//			return db$Ctrl.db$ReleaseRow(recID);
//		} catch (Exception e) {
//			return null;
//		}
//	}

	// #BVB00033 Starts
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		// JsonObject argJson = new JsonObject();

		try {
			ICustomerServiceStatusController i$genAppCon = new ICustomerServiceStatusController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			isonMsg = i$genAppCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			// Adding Pre Response Message Handler

			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}
    
	// #NYE00014 Begins
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg)
	{   
       try
        {
    	   return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));
    	   
		}
		catch (Exception e)
		{   
			logger.debug(" Error in get$FrmDataSetFilter -"+e.getMessage());
			return  null;
		}
	}
	
	// #NYE00014 Ends
	
	
    
	// #BVB00033 Ends
	public ICustomerServiceStatusController() {
		// Cons
	}
}
// #00000001 Ends