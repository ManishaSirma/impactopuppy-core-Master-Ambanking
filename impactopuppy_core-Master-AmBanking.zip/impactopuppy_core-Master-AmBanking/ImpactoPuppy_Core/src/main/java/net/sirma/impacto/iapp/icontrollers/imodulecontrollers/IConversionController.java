/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------    
     |0.5 Beta     | karthik    | 9, Oct 2023  | #NK00019    | added the code for pdf to doc, pdf to docx and txt to pdf and re-arranged the functions
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
// #NK00018 Begains
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.spire.pdf.FileFormat;
import com.spire.pdf.PdfDocument;
import com.spire.pdf.PdfPageBase;
import com.spire.pdf.graphics.PdfBrushes;
import com.spire.pdf.graphics.PdfFont;
import com.spire.pdf.graphics.PdfFontFamily;
import com.spire.pdf.graphics.PdfLayoutBreakType;
import com.spire.pdf.graphics.PdfLayoutType;
import com.spire.pdf.graphics.PdfStringFormat;
import com.spire.pdf.graphics.PdfTextLayout;
import com.spire.pdf.graphics.PdfTextWidget;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.ILedZ.ILeadAppController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.Ioutils;


public class IConversionController {

	private IResManipulator i$ResM = new IResManipulator();
	private static final Ioutils I$utils = new Ioutils();
	private DBController db$Ctrl = new DBController();
	private JsonObject i$Annotate = null;
	private static final Logger logger = LoggerFactory.getLogger(ILeadAppController.class);


	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
//			IConversionController i$genAppCon = new IConversionController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			String PDF$MAP = i$ResM.getSrvcopr3(isonMsg);

			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "SplitPdf")) {
				return splitPdf(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "AddPassword")) {
				return addPassword(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "RemovePassword")) {
				return removePassword(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PDFtoTXT")) {
				return pDFtoTXT(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "JPGtoPDF")) {
				return jPGtoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "BMPtoPDF")) {
				return bMPtoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PNGtoPDF")) {
				return pNGtoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "RotatePDF")) {
				return rotatePDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PDFtoDOC")) {
				return pDFtoDOC(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PDFtoDOCX")) {
				return pDFtoDOCX(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "TXTtoPDF")) {
				return tXTtoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PDFtoGrayScalePDF")) {
				return pDFtoGrayScalePDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "TIFFtoPDF")) {
				return tIFFtoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PDFtoTIFF")) {
				return pDFtoTIFF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "RemovePDFPage")) {
				return removePDFPage(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PDFtoXLSX")) {
				return pDFtoXLSX(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "CompressPDF")) {
				return compressPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "XLStoPDF")) {
				return xLStoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "PPTXtoPDF")) {
				return pPTXtoPDF(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "xlsxToPdf")) {
				return xlsxToPdf(isonMsg);
			}
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "OPDFCDOC") && I$utils.$iStrFuzzyMatch(PDF$MAP, "XLSXtoPDF")) {
				return xLSXtoPDF(isonMsg);
			}
			
			// Adding Pre Response Message Handler
			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}

	public JsonObject splitPdf(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PdfReader reader = new PdfReader(decodedPdf);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			Document document = new Document();
			PdfCopy copy = new PdfCopy(document, outputStream);
			document.open();
			String pageRange = i$body.get("pageRange").getAsString();
			PdfStamper stamper = new PdfStamper(reader, outputStream);
			if (pageRange.isBlank()) {
//			System.out.println("Field pageRange should not be blank or empty.");
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Field pageRange should not be blank or empty.");
				return isonMsg;
			} else {
				try {
					if (pageRange.contains("-")) {
						String[] pageArr = pageRange.split("-");
						int lowerLimit = Integer.parseInt(pageArr[0]);
						int upperLimit = Integer.parseInt(pageArr[1]);
						for (int i = lowerLimit; i <= reader.getNumberOfPages() && i <= upperLimit; i++) {
							PdfImportedPage importedPage = stamper.getImportedPage(reader, i);
							copy.addPage(importedPage);
						}
					} else if (pageRange.contains(",")) {
						JsonArray pageArr = new JsonArray();
						String[] pageArrStr = pageRange.split(",");
						for (int i = 0; i < pageArrStr.length; i++) {
							pageArr.add(Integer.parseInt(pageArrStr[i]));
						}
						for (int i = 1; i <= reader.getNumberOfPages(); i++) {
							for (int j = 0; j < pageArr.size(); j++) {
								if (pageArr.get(j).getAsInt() == i) {
									PdfImportedPage importedPage = stamper.getImportedPage(reader, i);
									copy.addPage(importedPage);
								}
							}
						}
					} else {
						int pageNo = Integer.parseInt(pageRange);
						for (int i = 1; i <= reader.getNumberOfPages(); i++) {
							if (i == pageNo) {
								PdfImportedPage importedPage = stamper.getImportedPage(reader, i);
								copy.addPage(importedPage);
							}
						}
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed  to split the pdf");
					return isonMsg;
				}
				copy.freeReader(reader);
				outputStream.flush();
				document.close();
				byte[] pdfBytes = outputStream.toByteArray();
				String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
				i$body.addProperty("base64Str", base64Str);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF Successfully Splited");
			}
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to split the PDF");
		}
		return isonMsg;
	}

	/**  **/
	public JsonObject addPassword(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			// Input PDF file
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			String password = i$body.get("password").getAsString();
			File fos = new File("outputFile.pdf");
			PDDocument document = PDDocument.load(decodedPdf);
			StandardProtectionPolicy protectionPolicy = new StandardProtectionPolicy(password, password,
					new AccessPermission());
			protectionPolicy.setEncryptionKeyLength(128); // Adjust encryption key length as needed
			document.protect(protectionPolicy);
			document.save(fos);
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			File file = new File("outputFile.pdf");
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF Password added Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to add Password to the PDF");
		}
		return isonMsg;
	}

	public JsonObject removePassword(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");

			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			// Input PDF file
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			String password = i$body.get("password").getAsString();
			File fos = new File("outputFile.pdf");
			PDDocument document = PDDocument.load(decodedPdf, password);
			if (document.isEncrypted()) {
				// Remove encryption and password protection
				document.setAllSecurityToBeRemoved(true);
				document.save(fos);
			} else {
				// If the PDF is not encrypted, simply copy it to the output file
				document.save(fos);
			}
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			File file = new File("outputFile.pdf");
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF Password Removed Successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to remove password!");
		}
		return isonMsg;
	}

	public JsonObject pDFtoTXT(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");

			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File fos = new File("outputFile.txt");
			PDDocument document = PDDocument.load(decodedPdf);
			PDFTextStripper textStripper = new PDFTextStripper();
			String text = textStripper.getText(document);
			org.apache.commons.io.FileUtils.writeStringToFile(fos, text, "UTF-8");
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			File file = new File("outputFile.txt");
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF converted to txt Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PDF to TXT!");
		}
		return isonMsg;
	}

	public JsonObject jPGtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");

			JsonObject filter = new JsonObject();
			JsonArray fileurls = i$body.get("FileUrlToken").getAsJsonArray();
			List<File> imageFiles = new ArrayList<File>();
			for (int i = 0; i < fileurls.size(); i++) {
				try {
					filter.addProperty("FileUrlToken", fileurls.get(i).getAsString());
					JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
					isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
					isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
					String base64Image = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
					byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
					BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
					File imgfile = new File("MyFile.jpg");
					ImageIO.write(img, "JPG", imgfile);
					imageFiles.add(imgfile);
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to get filecontent!");
					return isonMsg;
				}
			}
			File fos = new File("outputFile.pdf");
			PDDocument document = new PDDocument();
			for (File imageFile : imageFiles) {
				
				BufferedImage image = ImageIO.read(imageFile);
				PDPage page = new PDPage();
				document.addPage(page);

				try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
					PDImageXObject imageXObject = PDImageXObject.createFromFileByExtension(imageFile, document);
					float scale = 1f;
					contentStream.drawImage(imageXObject, 0, 0, imageXObject.getWidth() * scale,
							imageXObject.getHeight() * scale);
				}
			}

			document.save(fos);
			document.close();
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.delete();
			File file = new File("MyFile.jpg");
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JPG converted to PDF Successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert JPG to PDF");
		}
		return isonMsg;
	}

	public JsonObject bMPtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonArray fileurls = i$body.get("FileUrlToken").getAsJsonArray();
			List<File> imageFiles = new ArrayList<File>();
			for (int i = 0; i < fileurls.size(); i++) {
				try {
					filter.addProperty("FileUrlToken", fileurls.get(i).getAsString());
					JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
					isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
					isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
					String base64Image = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
					byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
					BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
					File imgfile = new File("MyFile.bmp");
					ImageIO.write(img, "bmp", imgfile);
					imageFiles.add(imgfile);
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to get filecontent!");
					return isonMsg;
				}
			}
			File file = new File("outputFile.pdf");
			PDDocument document = new PDDocument();
			for (File imageFile : imageFiles) {
				BufferedImage image = ImageIO.read(imageFile);
				PDPage page = new PDPage();
				document.addPage(page);

				try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
					PDImageXObject imageXObject = PDImageXObject.createFromFileByExtension(imageFile, document);
//		                float scale = 1f;
					// Specify the X and Y coordinates where you want to place the image (in points)
					float x = 100; // X-coordinate
					float y = 200; // Y-coordinate

					// Specify the width and height of the image (optional, can be different from
					// the original image size)
					float scaledWidth = 300;
					float scaledHeight = 150;
					contentStream.drawImage(imageXObject, x, y, scaledWidth, scaledHeight);
				}
			}
			document.save(file);
			document.close();
			byte[] byteArray = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			file.delete();
			File imgfile = new File("MyFile.bmp");
			imgfile.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "BMP converted to PDF Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert BMP to PDF");
		}
		return isonMsg;
	}

	public JsonObject pNGtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			JsonArray fileurls = i$body.get("FileUrlToken").getAsJsonArray();
			List<File> imageFiles = new ArrayList<File>();
			for (int i = 0; i < fileurls.size(); i++) {
				try {
					filter.addProperty("FileUrlToken", fileurls.get(i).getAsString());
					JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
					isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
					isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
					String base64Image = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
					byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
					BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
					File file = new File("MyFile.png");
					ImageIO.write(img, "png", file);
					imageFiles.add(file);
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to get filecontent!");
					return isonMsg;
				}
			}
			File fos = new File("outputFile.pdf");
			PDDocument document = new PDDocument();
			for (File imageFile : imageFiles) {
				BufferedImage image = ImageIO.read(imageFile);
				PDPage page = new PDPage();
				document.addPage(page);

				try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
					PDImageXObject imageXObject = PDImageXObject.createFromFileByExtension(imageFile, document);
//		                float scale = 1f;
					// Specify the X and Y coordinates where you want to place the image (in points)
					float x = 100; // X-coordinate
					float y = 200; // Y-coordinate

					// Specify the width and height of the image (optional, can be different from
					// the original image size)
					float scaledWidth = 300;
					float scaledHeight = 150;
					contentStream.drawImage(imageXObject, x, y, scaledWidth, scaledHeight);
				}
			}

			document.save(fos);
			document.close();
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.delete();
			File file = new File("MyFile.png");
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PNG converted to PDF Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PNG to PDF");
		}
		return isonMsg;
	}

	public JsonObject rotatePDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");

			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File fos = new File("outputFile.pdf");
			PDDocument document = PDDocument.load(decodedPdf);
			// Iterate through pages and rotate them
			for (int pageIndex = 0; pageIndex < document.getNumberOfPages(); pageIndex++) {
				PDPage page = document.getPage(pageIndex);
				int rotation = page.getRotation();

				// Set the rotation angle (90 degrees clockwise in this example)
				page.setRotation((rotation + 90) % 360);
				// Adjust the page dimensions if needed
				if (rotation == 90 || rotation == 270) {
					// Swap width and height
					PDRectangle mediaBox = page.getMediaBox();
					// Create a new PDRectangle with the desired dimensions
					PDRectangle newMediaBox = new PDRectangle(mediaBox.getLowerLeftX(), mediaBox.getLowerLeftY(),
							mediaBox.getLowerLeftX() + mediaBox.getWidth(),
							mediaBox.getLowerLeftY() + mediaBox.getHeight());
					// Set the new media box for the page
					page.setMediaBox(newMediaBox);

				}
			}

			// Save the rotated PDF to a new file
			document.save(fos);
			document.close();
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.delete();
			File file = new File("outputFile.pdf");
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF Rotated  Successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to rotate PNG");
		}
		return isonMsg;
	}

	JsonObject pDFtoDOC(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PdfDocument doc = new PdfDocument();
			doc.loadFromBytes(decodedPdf);
			doc.saveToFile("output.doc", FileFormat.DOC);
			doc.close();
			File fos = new File("output.doc");
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF converted to DOC Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PDF to DOC");
		}
		return isonMsg;
	}

	public JsonObject pDFtoDOCX(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PdfDocument doc = new PdfDocument();
			doc.loadFromBytes(decodedPdf);
			doc.saveToFile("output.docx", FileFormat.DOCX);
			doc.close();
			File fos = new File("output.docx");
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF converted to DOCX Successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PDF to DOCX");
		}
		return isonMsg;
	}

	public JsonObject tXTtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File input = new File("input.txt");
			OutputStream os = new FileOutputStream(input);

			// Starting writing the bytes in it
			os.write(decodedPdf);

			StringBuffer sb = new StringBuffer();
			BufferedReader br = new BufferedReader(new FileReader(input));
			String content = null;
			while ((content = br.readLine()) != null) {
				sb.append(content);
				sb.append("\n");
			}
			String path = sb.toString();

			// Create a PdfDocument instance
			PdfDocument pdf = new PdfDocument();
			// Add a page
			PdfPageBase page = pdf.getPages().add();

			// Create a PdfFont instance
			PdfFont font = new PdfFont(PdfFontFamily.Helvetica, 11);

			// Create a PdfTextLayout instance
			PdfTextLayout textLayout = new PdfTextLayout();
			textLayout.setBreak(PdfLayoutBreakType.Fit_Page);
			textLayout.setLayout(PdfLayoutType.Paginate);

			// Create a PdfStringFormat instance
			PdfStringFormat format = new PdfStringFormat();
			format.setLineSpacing(20f);

			// Create a PdfTextWidget instance from the text
			PdfTextWidget textWidget = new PdfTextWidget(path, font, PdfBrushes.getBlack());
			// Set string format
			textWidget.setStringFormat(format);

			// Draw the text at the specified location of the page
			Rectangle2D.Float bounds = new Rectangle2D.Float();
			bounds.setRect(0, 25, page.getCanvas().getClientSize().getWidth(),
					page.getCanvas().getClientSize().getHeight());
			textWidget.draw(page, bounds, textLayout);

			// Save the result file
			pdf.saveToFile("TextToPdf.pdf", FileFormat.PDF);
			File fos = new File("TextToPdf.pdf");
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.delete();
			input.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "TXT file converted to PDF file Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PDF to DOC");
		}
		return isonMsg;
	}
	
	public JsonObject pDFtoGrayScalePDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PDDocument document = PDDocument.load(decodedPdf);
			PDFRenderer pdfRenderer = new PDFRenderer(document);
			for (int pageIndex = 0; pageIndex < document.getNumberOfPages(); pageIndex++) {
				try {

					PDPage page = document.getPage(pageIndex);

					// Render the page to an RGB image
					BufferedImage bufferedImage = pdfRenderer.renderImageWithDPI(pageIndex, 300, ImageType.RGB);

					int width = bufferedImage.getWidth();
					int height = bufferedImage.getHeight();
					BufferedImage grayscaleImage = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
					Graphics2D g2d = grayscaleImage.createGraphics();
					g2d.drawImage(bufferedImage, 0, 0, null);
					g2d.dispose();
					// Convert the RGB image to grayscale
					File img = new File("input.jpg");
					ImageIO.write(bufferedImage, "JPEG", img);

					// Save the grayscale image as a new PDF page
					PDPageContentStream contentStream = new PDPageContentStream(document, page);
					PDImageXObject pdImage = PDImageXObject.createFromFileByContent(img, document);
					contentStream.drawImage(pdImage, 0, 0, page.getMediaBox().getWidth(), page.getMediaBox().getHeight());
					contentStream.close();
				} catch (Exception e) {
					e.printStackTrace();
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error occured while converting the image to gray scale");
				}
			}
			File file = new File("grayscale.pdf");
			document.save(file);
			document.close();
			byte[] byteArray = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			file.delete();
			File img = new File("input.jpg");
			img.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF successfully converted to gray scale PDF!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "failed to convert the PDF to GrayScale PDF!");
		}
		return isonMsg;
	}
	
	public JsonObject tIFFtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER",filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File tiffFile = new File("tiff.tiff");
			FileOutputStream bytetiff = new FileOutputStream(tiffFile);
			bytetiff.write(decodedPdf);
			String tiffFilePath = "tiff.tiff";
            String pdfFilePath = "output.pdf";
            BufferedImage tiffImage = ImageIO.read(new File(tiffFilePath));
            int width = 0;
            int height = 0;
            if (tiffImage != null) {
			   width = tiffImage.getWidth();
			   height = tiffImage.getHeight();
			} else {
//			    System.err.println("Failed to read the image.");
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to read the image.");
				return isonMsg;
			}
            Document document = new Document(new Rectangle(width, height));
			// Initialize PDF writer
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pdfFilePath));
            document.open();
            Image tiffPdfImage = Image.getInstance(tiffImage, null);
            // Add TIFF image to the PDF
            document.add(tiffPdfImage);
            document.close();
			File fos = new File("output.pdf");
			byte[] byteArray = FileUtils.readFileToByteArray(fos);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			fos.deleteOnExit();
			tiffFile.deleteOnExit();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "TIFF converted to PDF Successfully!");
		}catch(Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert TIFF to PDF");
		}
		return isonMsg;
	}
	
	public JsonObject pDFtoTIFF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File PDFfile = new File("PDFfile.pdf");
			FileOutputStream fos = new FileOutputStream(PDFfile);
			fos.write(decodedPdf);
			JsonArray imageFiles = new JsonArray();
			 PDDocument document = PDDocument.load(PDFfile);
	         PDFRenderer pdfRenderer = new PDFRenderer(document);
	         for (int pageIndex = 0; pageIndex < document.getNumberOfPages(); pageIndex++) {
	                BufferedImage image = pdfRenderer.renderImageWithDPI(pageIndex, 300, ImageType.RGB);

	                File tiffFile = new File("tiff" + (pageIndex + 1) + ".tiff");
	                ImageIO.write(image, "TIFF", tiffFile);
	                imageFiles.add("tiff" + (pageIndex + 1) + ".tiff");
	            }
	         String zipFileName = "images.zip";
	         try {
	             // Create a FileOutputStream to write to the ZIP file
	             FileOutputStream files = new FileOutputStream(zipFileName);
	             ZipOutputStream zos = new ZipOutputStream(files);
	             for (int i=0; i<imageFiles.size(); i++) {
	                 // Create a new entry in the ZIP file for the image
	                 ZipEntry entry = new ZipEntry(imageFiles.get(i).getAsString());
	                 zos.putNextEntry(entry);
	                 // Read the image file and write it to the ZIP file
	                 FileInputStream fis = new FileInputStream(imageFiles.get(i).getAsString());
	                 byte[] buffer = new byte[1024];
	                 int length;
	                 while ((length = fis.read(buffer)) > 0) {
	                     zos.write(buffer, 0, length);
	                 }
	                 fis.close();
	                 zos.closeEntry();
	             }
	             // Close the ZIP output stream
	             zos.close();
//	             System.out.println("Images have been added to " + zipFileName);
	         } catch (IOException e) {
	             e.printStackTrace();
	             isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to Add the tiff Files in Zip");
	         }
	        document.close();
	        File zipedfile = new File("images.zip");
	        byte[] byteArray = FileUtils.readFileToByteArray(zipedfile);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			PDFfile.deleteOnExit();
			zipedfile.deleteOnExit();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF converted to TIFF Successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PDF to TIFF");
		}
		return isonMsg;
	}
	
	public JsonObject removePDFPage(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PDDocument document = PDDocument.load(decodedPdf);
			int noOfPages = document.getNumberOfPages();
			String pageRange = i$body.get("removepages").getAsString();
			if (pageRange.isBlank()) {
//				System.out.println("Field pageRange should not be blank or empty.");
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Field pageRange should not be blank or empty.");
				return isonMsg;
			} else {
				try {
					if (pageRange.contains("-")) {
						String[] pageArr = pageRange.split("-");
						int lowerLimit = Integer.parseInt(pageArr[0]);
						int upperLimit = Integer.parseInt(pageArr[1]);
						for (int i = lowerLimit; i <= document.getNumberOfPages() && i <= upperLimit; i++) {
							document.removePage(i-1);
						}
					} else if (pageRange.contains(",")) {
						JsonArray pageArr = new JsonArray();
						String[] pageArrStr = pageRange.split(",");
						for (int i = 0; i < pageArrStr.length; i++) {
							pageArr.add(Integer.parseInt(pageArrStr[i]));
						}
						for (int i = 1; i <= document.getNumberOfPages(); i++) {
							for (int j = 0; j < pageArr.size(); j++) {
								if (pageArr.get(j).getAsInt() == i) {
									document.removePage(i-1);
								}
							}
						}
					} else {
						int pageNo = Integer.parseInt(pageRange);
						for (int i = 0; i <= document.getNumberOfPages(); i++) {
							if (i == pageNo) {
								document.removePage(i-1);
							}
						}
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed  to Delete the pdf");
					return isonMsg;
				}
			}
//			document.removePage(1-i$body.get("removepage").getAsInt()); 
			document.save("test.pdf");
			document.close();
			File file = new File("test.pdf");
			byte[] byteArray = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			file.delete();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF page deleted Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to delete PDF page");
		}
		return isonMsg;
	}
	
	JsonObject pDFtoXLSX(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PDDocument pdfDocument = PDDocument.load(decodedPdf);
			PDFTextStripper pdfTextStripper = new PDFTextStripper();
	        // Create Excel workbook
	        HSSFWorkbook workbook = new HSSFWorkbook();
	        // Iterate through each page in the PDF
	        for (int pageIndex = 0; pageIndex < pdfDocument.getNumberOfPages(); pageIndex++) {
	            // Extract text from the current page
	            pdfTextStripper.setStartPage(pageIndex + 1);
	            pdfTextStripper.setEndPage(pageIndex + 1);
	            String pdfText = pdfTextStripper.getText(pdfDocument);
	            // Create a new sheet for each page
	            Sheet sheet = workbook.createSheet("Page_" + (pageIndex + 1));
	            // Split the extracted text into rows
	            String[] rows = pdfText.split("\n");
	            // Populate Excel sheet with extracted text
	            for (int i = 0; i < rows.length; i++) {
	                Row row = sheet.createRow(i);
	                String[] cells = rows[i].split("\t"); // Adjust delimiter as needed

	                for (int j = 0; j < cells.length; j++) {
	                    Cell cell = row.createCell(j);
	                    cell.setCellValue(cells[j]);
	                }
	            }
	        }

	        // Write the workbook to a file
	        try (FileOutputStream fileOut = new FileOutputStream("test.xls")) {
	            workbook.write(fileOut);
	        }

	        // Close the PDF document
	        pdfDocument.close();
			
//			pdfDocument.saveToFile("test.xlsx", FileFormat.XLSX);
			File file = new File("test.xlsx");
			byte[] byteArray = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArray);
			i$body.addProperty("base64Str", base64String);
			file.deleteOnExit();
	        workbook.close();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF converted to XLSX Successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed convert PDF to XLSX");
		}
		return isonMsg;
	}
	
	JsonObject compressPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			PdfReader reader = new PdfReader(decodedPdf);
			PdfStamper stamper = new PdfStamper(reader, new FileOutputStream("output.pdf"));
			int total = reader.getNumberOfPages() + 1;
			for ( int i=1; i<total; i++) {
			   reader.setPageContent(i + 1, reader.getPageContent(i + 1));
			}
			stamper.setFullCompression();
			stamper.close();
			File file = new File("output.pdf");
			byte[] byteArr = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArr);
			i$body.addProperty("base64Str", base64String);
			file.deleteOnExit();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF compressed successfully!");
		}catch(Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to compress PDF!");
		}
		return isonMsg;
	}
	
	public JsonObject xLStoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File XlsFile = new File("Test.xls");
			FileOutputStream fileOuputStream = new FileOutputStream(XlsFile);
			fileOuputStream.write(decodedPdf);
			FileInputStream input_document = new FileInputStream(XlsFile);
			HSSFWorkbook my_xls_workbook = new HSSFWorkbook(input_document);
			HSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
			short availableColumns = my_worksheet.getRow(0).getLastCellNum();
			Iterator<Row> rowIterator = my_worksheet.iterator();
			Document iText_xls_2_pdf = new Document();
			PdfWriter.getInstance(iText_xls_2_pdf, new FileOutputStream("Excel2PDF_Output.pdf"));
			iText_xls_2_pdf.open();
			PdfPTable my_table = new PdfPTable(availableColumns);
			PdfPCell table_cell = null;
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					switch (cell.getCellType()) {
						default:
							try {
								table_cell = new PdfPCell(new Phrase(cell.getStringCellValue()));
							} catch (IllegalStateException illegalStateException) {
								// TODO: Need to handle exceptions for different type too
								if (illegalStateException.getMessage()
										.equals("Cannot get a STRING value from a NUMERIC cell")) {
									table_cell = new PdfPCell(new Phrase(String.valueOf(cell.getNumericCellValue())));
								}
							}
							my_table.addCell(table_cell);
							break;
					}
				}
			}
			iText_xls_2_pdf.add(my_table);
			iText_xls_2_pdf.close();
			// we created our pdf file..
			input_document.close();
			File file = new File("Excel2PDF_Output.pdf");
			byte[] byteArr = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArr);
			i$body.addProperty("base64Str", base64String);
			file.deleteOnExit();
			XlsFile.deleteOnExit();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "XLS converted to PDF successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert XLS to PDF!");
		}
		return isonMsg;
	}
	
	public JsonObject pPTXtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File pptxFile = new File("sample.pptx");
			FileOutputStream fos = new FileOutputStream(pptxFile);
			fos.write(decodedPdf);
			String file = "sample.pptx";
			XMLSlideShow ppt = new XMLSlideShow(OPCPackage.open(file));
			Dimension pgsize = ppt.getPageSize();
			float scale = 1;
			int width = (int) (pgsize.width * scale);
			int height = (int) (pgsize.height * scale);

			int i = 1;
			int totalSlides = ppt.getSlides().size();
			for (XSLFSlide slide : ppt.getSlides()) {

				BufferedImage img = new BufferedImage(pgsize.width, pgsize.height, BufferedImage.TYPE_INT_RGB);
				Graphics2D graphics = img.createGraphics();
				graphics.setPaint(Color.white);
				graphics.fill(new Rectangle2D.Float(0, 0, pgsize.width, pgsize.height));
				graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
				graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
				graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
				graphics.setColor(Color.white);
				graphics.clearRect(0, 0, width, height);
				graphics.scale(scale, scale);

				slide.draw(graphics);
				FileOutputStream out = new FileOutputStream("images" + i + ".png");
				javax.imageio.ImageIO.write(img, "png", out);
				out.close();
				i++;
			}

			com.lowagie.text.Document document = new com.lowagie.text.Document();
			com.lowagie.text.pdf.PdfWriter.getInstance(document, new FileOutputStream("filenew.pdf"));
			com.lowagie.text.pdf.PdfPTable table = new com.lowagie.text.pdf.PdfPTable(1);

			for (int j = 1; j <= totalSlides; j++) {
				com.lowagie.text.Image slideImage = com.lowagie.text.Image.getInstance("images" + j + ".png");

				document.setPageSize(new com.lowagie.text.Rectangle(slideImage.getWidth(), slideImage.getHeight()));
				document.open();
				slideImage.setAbsolutePosition(0, 0);

				table.addCell(new com.lowagie.text.pdf.PdfPCell(slideImage, true));

			}
			document.add(table);
			document.close();
			
			File pdfFile = new File("filenew.pdf");
			byte[] byteArr = FileUtils.readFileToByteArray(pdfFile);
			String base64String = Base64.getEncoder().encodeToString(byteArr);
			i$body.addProperty("base64Str", base64String);
			pdfFile.deleteOnExit();
			pptxFile.deleteOnExit();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PPTX converted to PDF successfully!");
		}catch(Exception e){
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert PPTX to PDF!");
		}
		return isonMsg;
	}
	
	public JsonObject xLSXtoPDF(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			File XlsXFile = new File("Test.xlsx");
			FileOutputStream fileOuputStream = new FileOutputStream(XlsXFile);
			fileOuputStream.write(decodedPdf);
			FileInputStream excelFile = new FileInputStream("Test.xlsx");
			Workbook workbook = new XSSFWorkbook(OPCPackage.open(excelFile));
            Sheet sheet = workbook.getSheetAt(0);
            
            // Create PDF document
            PDDocument document = new PDDocument();
            PDPage page = new PDPage();
            document.addPage(page);
            
            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            // Use DataFormatter to format cell values
            DataFormatter dataFormatter = new DataFormatter();
            
            for (Row row : sheet) {
                for (Cell cell : row) {
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                    contentStream.newLineAtOffset((float) cell.getColumnIndex() * 100, 700 - (float) row.getRowNum() * 20);

                    // Use DataFormatter to get formatted string value and replace newline characters
                    String cellValue = dataFormatter.formatCellValue(cell).replace("\n", " ");
                    contentStream.showText(cellValue);

                    contentStream.endText();
                }
            }
            
            contentStream.close();

            // Save PDF file
            document.save("file.pdf");
            document.close();
            workbook.close();
            
            File file = new File("file.pdf");
			byte[] byteArr = FileUtils.readFileToByteArray(file);
			String base64String = Base64.getEncoder().encodeToString(byteArr);
			i$body.addProperty("base64Str", base64String);
			file.deleteOnExit();
			XlsXFile.deleteOnExit();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "XLSX converted to PDF successfully!");
		}catch(Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert XLSX to PDF!");
		}
		return isonMsg;
	}
	
	public JsonObject xlsxToPdf(JsonObject isonMsg) throws IOException {
		try {
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			JsonObject filter = new JsonObject();
			filter.addProperty("FileUrlToken", i$ResM.getBodyElementS(isonMsg, "FileUrlToken"));
			JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filter);
			isonMsg = i$ResM.addStrToBody(isonMsg, "FileUrlId", icorMDmsLogger.get("FileUrlId").getAsString());
			isonMsg = db$Ctrl.db$GrdFSDwld(isonMsg);
			String base64Pdf = isonMsg.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			byte[] decodedPdf = null;
			try {
				decodedPdf = Base64.getDecoder().decode(base64Pdf);
			} catch (Exception e) {
				decodedPdf = org.apache.commons.codec.binary.Base64.decodeBase64(base64Pdf);
			}
			com.spire.xls.Workbook workbook = new com.spire.xls.Workbook();
			File xlsxfile = new File("test.xlsx");
			FileOutputStream bytetiff = new FileOutputStream(xlsxfile);
			bytetiff.write(decodedPdf);
			workbook.loadFromFile("test.xlsx");
			workbook.getConverterSetting().setSheetFitToPage(true);
			workbook.saveToFile("KYM.pdf", com.spire.xls.FileFormat.PDF);
			File pdffile = new File("KYM.pdf");
			byte[] byteArr = FileUtils.readFileToByteArray(pdffile);
			String base64String = Base64.getEncoder().encodeToString(byteArr);
			i$body.addProperty("base64Str", base64String);
			pdffile.deleteOnExit();
			xlsxfile.deleteOnExit();
			bytetiff.close();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "XLSX converted to PDF successfully!");
		} catch (Exception e) {
			e.printStackTrace();
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to convert XLSX to PDF!");
		}
		return isonMsg;
	}
	
} // #NK00018 ends
