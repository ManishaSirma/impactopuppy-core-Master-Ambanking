/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.

      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1         | Devraj 	| Feb 03, 2021 | #DVJ00018   | Initial writing
      |0.2         | Pappu      | Mar 25, 2021 | #PKY00006   | written code for set profile picture in Lincu PDF
      |0.2         | Pappu      | Mar 26, 2021 | #PKY00007   | Added  code for Member_Onboarding and health_Insurance 
      |0.2         | Pappu      | Mar 30, 2021 | #PKY00008   | Added code for clico_one pdf   
      |0.2         | Tarun      | May 22, 2021 | #TKS00001   | Added code for Member_Onboarding and InternetMobileFacility   
      |0.2         | samadhan   | may 31, 2021 | #SRP00001   | Addes code for Employement_status
      |0.2         | samadhan   | Jun 15, 2021 | #SRP00002   | Added Code for WorkPhoneNumber Format
      |0.4         | Pruthvi    | Jun 19, 2021 | #YPR00092   | Added Code for Fixed Deposit Format
      |0.2         | Samadhan   | Jun 18, 2021 | #SRP00003   | Added Code for Loan Format,FD Beneficiary Form and Terms and Condition for FD Formats.
      |0.4         | Samadhan   | Jun 30, 2021 | #SRP00004   | Added code for FD Beneficiary form and Terms and Condition Formats.
      |0.2         | Sushmita   | Jun 01, 2021 | #SKP00001   | Added code for Loan Application Format
      |0.2         | Samadhan   | Jul 22, 2021 | #SRP00005   | Added Code for Loan Pdf's
      |0.2         | Samadhan   | Jul 27, 2021 | #SRP00006   | Added code for loan module
      |0.2         | Samadhan   | jul 28, 2021 | #SRP00007   | Added code in FD for tenor
      |0.3         | Sushmita   | Jul 31, 2021 | #SKP00002   | Written Deduction and Enrolment PDF's code
      |0.4         | Samadhan   | Aug 02, 2021 | #SRP00008   | Written code for Payment of Interest in FD Format
      |0.4         | pappu      | Aug 04, 2021 | #PKY00036   | Added code for Lincu And FIP workflow PDFs
      |0.4         | Samadhan   | Aug 05, 2021 | #SRP00010   | Added Code for FD module
      |0.4         | Samadhan   | Aug 11, 2021 | #SRP00011   | Added Code For Tatil CoronaVirus form
      |0.4         | Samadhan   | Aug 12, 2021 | #SRP00012   | Added Code for Tatil Application Form
      |0.4         | Pappu      | Aug 11, 2021 | #PKY00038   | Added code for Tatil_Evidence_of_Insurability_Form
      |0.5         | Sushmita   | Aug 11, 2021 | #SKP00003   | Added Code for Dental and Vision PDF
      |0.5         | Sushmita   | Aug 11, 2021 | #SKP00004   | Added code for Proof of address form and Premier card application data pdf
      |0.5         | Sushmita   | Aug 11, 2021 | #SKP00005   | Added code for Tatil Deduction Form  
      |0.5         | Pappu      | Aug 16, 2021 | #PKY00040   |  coveragePremium options for Tatil_Deduction_Form 
      |0.5         | Samadhan   | Aug 18, 2021 | #SRP00013   | Added Code for FD and Loan Format
      |0.5         | Samadhan   | Aug 26, 2021 | #SRP00016   | Added Code for FCIP, FIP, Lincu, Tatil formats.
      |0.5         | Samadhan   | Aug 26, 2021 | #SRP00017   | Added Code for FD confirmation Letter
      |0.5         | Samadhan   | Aug 31, 2021 | #SRP00018   | Added Code for FD Format.
      |0.5 Beta    | Pappu      | Sep 01, 2021 | #PKY00045   | handled code for sendgrid API attachment filling
      |0.5         | Samadhan   | Sep 15, 2021 | #SRP00022   | Added Code For Loan Format
      |0.5 Beta    | Tarun      | Sep 15, 2021 | #TKS00002   | added code for Loan application and Terms & condition pdf.
      |0.5         | Sushmita   | Sep 16, 2021 | #SKP00006   | Added changes for Fip enrollemnt pdf
      |0.5         | Sushmita   | Sep 16, 2021 | #SKP00007   | Added changes for Fip enrollemnt pdf
      |0.5         | Sushmita   | Sep 16, 2021 | #SKP00008   | Added code for Fip enrollemnt pdf for docname
      |0.5         | Samadhan   | Sep 22, 2021 | #SRP00024   | Added Code in Load Formar for Loan and Share Balance.
      |0.5 Beta    | Tarun      | Sep 23, 2021 | #TKS00006   | added code for Loan application pdf.
      ||0.5        | Samadhan   | Sep 23, 2021 | #SRP00025   | Added Code for FCIP format
      |0.5         | Samadhan   | Sep 24, 2021 | #SRP00026   | Added Code for Lincu Format
      |0.5         | Pappu      | Sep 27, 2021 | #PKY00048   | handle cuna enrollment and designation pdf issue and handle Tatil_Premier_Card_Application_form income range issue
      |0.5         | Samadhan   | Sep 30, 2021 | #SRP00027   | Added Code for Tatil Common Law RelationShip form and Tatil module related Pdf's
      |0.5         | Samadhan   | Oct 06, 2021 | #SRP00028   | Added Code for FCIP Enrollment pdf
      |0.5         | Manikanta	| Oct 11, 2021 | #MVT00001	 | Added code for home Ownership field for LINCU
      |0.5		   | Manikanta  | Oct 11, 2021 | #MVT00002   | Added code for Tatil Premier Card Application PDF DOB is not mapping
      |0.5		   | Manikanta	| Oct 20, 2021 | #MVT00003	 | Written code for FD Beneficiary Form  for percentage not mapping
      |0.5		   | Manikanta	| Oct 20, 2021 | #MVT00004	 | Added code for Loan Application forn for Security offered not mapping
      |0.5         | Samadhan   | Oct 27, 2021 | #SRP00029   | Added Code for FIP format 
      ||0.5		   | Manikanta	| oct 27, 2021 | #MVT00005	 | Added code for Tatil pdf for marital issue and benifiecry pdf date issue and lincu date formate issue and marital status and hieght issue in tatil
      |0.5         | Samadhan   | Oct 28, 2021 | #SRP00030   | Added code for Tatil deduction pdf
      |0.5		   | Manikanta	| Oct 28, 2021 | #MVT00006	 | Written code for Date formate issue in corona virus pdf
      |0.5		   | Manikanta	| oct 29, 2021 | #MVT00007	 | Added code for marital status in Loan pdf
      |0.5		   | Manikanta	| oct 29, 2021 | #MVT00008	 | Added code for Dental_And_vision_Care_Benefits
      |0.5		   | Manikanta	| oct 29, 2021 | #MVT00009   | Written code for premier card date mapping
      |0.5		   | Manikanta  | oct 29, 2021 | #MVT000010  | Added code for member health pdf for covarage mapping
      |0.5         | Samadhan   | Oct 29, 2021 | #SRP00031   | Added Code for Tatil Primier card pdf for Adrees fields.
      |0.5         | Samadhan   | Nov 03, 2021 | #SRP00032   | Added Code for Dental and Vision pdf
      |0.5         | Pappu      | Nov 08, 2021 | #PKY00059   | added changes for pdf bugs
      |0.5         | Samadhan   | Nov 10, 2021 | #SRP00033   | Added Code for Home Address field in Dental and vision pdf
      |0.5		   | Manikanta  | Nov 04, 2021 | #MVT000011  | Added code for CUNA FIP Enrollment pdf
      |0.5         | Samadhan   | Nov 10, 2021 | #SRP00034   | Added Code for Corona Virus pdf
      |0.5         | Samadhan   | Nov 11, 2021 | #SRP00035   | Added Code for Lincu Format 
      |0.5		   | Manikanta  | Nov 15, 2021 | #MVT000012  | Added code for Loan application Home adress mapping
      |0.5 		   | manikanta  | Nov 15, 2021 | #MVT000013  | Added code for member health application form
      |0.5         | Pappu      | Nov,12, 2021 | #PKY00061   | handled employee coverage for Evidence Of Insurability form and customer fullName for loan form
      |0.5		   | Manikanta  | Nov,15, 2021 | #MVT00014   | Added code for FIP Beneficiary date formate
      |0.5         | Samadhan   | Nov 16, 2021 | #SRP00037   | Added Code in Tatil Application for Address field
      |0.5		   | Manikanta  | Nov,16, 2021 | #MVT00015	 | Added code for Corona virus pdf
      |0.5         | Samadhan   | Nov 18, 2021 | #SRP00038   | Added Code for Lincu format for country fields.
      |0.5         | Samadhan   | Nov 23, 2021 | #SRP00040   | Added Code for FCIP pdf Date Format
      |0.5		   | Manikanta  | Nov 24, 2021 | #MVT00016   | Added code for FIP Beneficiary date format
      |0.5		   | Manikanta  | Nov 24, 2021 | #MVT00017	 | Added code for New Pdf
      |0.5		   | Manikanta  | Nov 25, 2021 | #MVT00018   | Added code for FCIP pdf Date Format
      |0.5		   | Manikanta  | Nov 29, 2021 | #MVT00019   | Changed code For Enrollment for Date mapping
      |0.5 		   | Manikanta  | Dec 02, 2021 | #MVT00020   | Added code for FIP Deduction for Plane type mapping
      |0.5         | Samadhan   | Nov 03, 2021 | #SRP00041   | Added Code for Evidence Of Insurability for Dependent Employee, Spouse.
      |0.5         | Samadhan   | Nov 03, 2021 | #SRP00042   | Added Code for Proof Of Address Form
      |0.5		   | Manikanta  | Dec 09, 2021 | #MVT00022   | Added code for FCIP deduction checkbox issue
      |0.5         | Sushmita   | Dec 08, 2021 | #SKP00009   | Added code for address feild in cuna pdf
      |0.5         | Sushmita   | Dec 09, 2021 | #SKP00010   | Added changes for FD pdf
      |0.5		   | Manikanta  | Dec 10, 2021 | #MVT00023 	 | Adde code For Lincu DOB date formate
      |0.5		   | Manikant   | Feb 16, 2022 | #MVT00033   | Added code for deduction pdf
      |0.5         | Samadhan   | Feb 22, 2022 | #SRP00050   | Chnages in Dental and Vision form
      |0.5         | Samadhan   | Feb 22, 2022 | #SRP00051   | Changes in Tatil Deduction form
      |0.5         | Samadhan   | Mar 15, 2022 | #SRP00052   | Added code for Tatil Deduction form for Coverge Option
      |0.5         | Manikanta  | mar 23, 2022 | #MVT00051   | Added code for FD amount
      |0.5         | Samadhan   | Apr 18, 2022 | #SRP0055    | Added code for Policy in EOI form
      |0.5         | Sushmita   | Apr 19, 2022 | #SKP00011   | Handled code for policy in EOI form
      |0.5         | Samadhan   | Apr 20, 2022 | #SRP00060   | Added Code for Phase1 pdf integrations    
      |0.3         | Sushmita   | Jul 14, 2021 | #SKP00001   | Commented employee code
      |0.3         | Samadhan   | Oct 28, 2021 | #SRP00031   | Code chnages in Lincu pdf
      |0.3	       | Manikanta  | Nov 02, 2021 | #MVT00001	 | Added code for lincu dob formate issue
      |0.3         | Samadhan   | Nov 04, 2021 | #SRP00032   | Added Code and change the code for Lincu Format
      |0.3         | Samadhan   | Nov 08, 2021 | #SRP00033   | Added Code for SSNNo Field in Lincu format
      |0.3         | Manikanta  | Nov 09, 2021 | #MVT00002   | Added code for Linku Education field
      |0.3         | Samadhan   | Nov 12, 2021 | #SRP00035   | Added Code for Lincu pdf for Power of Atternoy
      |0.3         | Samadhan   | Nov 15, Nov  | #SRP00036   | Added Code for Clico format
      |0.3         | Samadhan   | Nov 19, Nov  | #SRP00039   | Code changes for clico pdf
      |0.3         | Samadhan   | Nov 24, Nov  | #SRP00040   | Added code in Joint Partner pdf for Mobile Numbers fields.
      |0.3         | Samadhan   | Nov 26, Nov  | #SRP00041   | Code changes in Due Diligience form for PEP field 
      |0.3         | Sushmita   | Apr 22, 2022 | #SKP00012   | Added acct no feild
      |0.3         | Samadhan   | May 10, 2022 | #SRP00062   | Code changes for KYM Cuna and Clico pdf's
      |0.0.9.3	   | Madhura	| Jun 21, 2022 | #MDA0001	 | Added Source of Funds PDF
      |0.3		   | Manikanta  | Nov 02, 2022 | #MVT00080   | Added code for mapping issue
      |0.3		   | Manikanta  | Nov 02, 2022 | #MVT00081   | Added Code To Handle employee mapping issue in On member Boarding pdfs
      |0.3 		   | Manikanta  | Nov 04, 2022 | #MVT00082   | Added code to map Birth Country in Clico pdf's
      |0.3		   | Manikanta  | Nov 07, 2022 | #MVT00083   | Added code for Lincu Contact Number issue
      |0.3 		   | Manikanta  | Nov 09, 2022 | #MVT00084   | Added Code For Cuna pdf Country Residency mapping
      |0.3		   | Mnaikanta  | Nov 10, 2022 | #MVT00085   | Added code to employer adress in member on boarding pdfs
      |0.3 		   | Manikanta  | Nov 11, 2022 | #MVT00086   | Added code To map address In Tecu member on Boarding pdf
      |0.3         | Manikanta  | Nov 14, 2022 | #MVT00087   | Added code to map mailing address and permenent adress in Tecu PDF
      |0.3		   | Manikanta  | Nov 15, 2022 | #MVT00088   | Added code for tecu pdf mapping issues
      |0.3 		   | Manikanta  | Nov 16, 2022 | #MVT00089   | Added code for tecu pdf issues
      |0.4         | Sindhu     | Nov 16, 2022 | #SRM00008   | Code changes for FCIP deduction pdf mapping
      |0.4		   | Manikanta  | Nov 17, 2022 | #MVT00090   | Added code to handle extra symbols in internet pdfs
      |0.4		   | Manikanta  | Nov 18, 2022 | #MVT00091 	 | Added code for employer adress issue in tecu pdf's
      |0.4 		   | Manikanta  | Nov 24, 2022 | #MVT00093   | Added code to map primuim values in CUNA pdf
      |0.4		   | Manikanta  | Nov 25, 2022 | #MVT00095   | Added code for lincu pdf for share holdings
      |0.4		   | Madhura    | Dec 15, 2022 | #MSA00001   | Added code for re-kyc lite
      |0.4		   | Madhura    | Jan 16, 2023 | #MSA00002   | Added code for address for Member Onboarding
      |0.4		   | Manikanta  | Jan 20, 2023 | #MVT00098	 | Added code to handle member disclosure loan summary
      |0.4		   | Manikanta  | Jan 25, 2023 | #MVT00099   | Added code pdf mapping issues
      |0.4		   | Madhura    | Feb 20, 2023 | #MSA00003   | Added code for First date in Promissory Note
      |0.4		   | Manikanta  | May 03, 2023 | #MVT00112   | Added code to map address line2
      |0.4		   | Manikanta  | May 05, 2023 | #MVT00113   | Added code for loan and lincu pdf issues
      |0.4		   | Madhura    | May 12, 2023 | #MSA00004   | Added code for Handling PDF issues for LOAN PDF
      |0.4		   | Madhura    | May 16, 2023 | #MSA00013   | Added code for Handling Re-KYM pdf issue
      |0.4		   | Sindhu     |June 14, 2023 | #SRM00042   | Handled code to map borrower and borrower signature
      |0.4		   | Madhura    |July 30, 2023 | #MSA00027   | Handled code for Receipt PDFs
      |0.4		   | Pavithra   |Aug  17, 2023 | #PAV00015   | Added try catch block
      |0.4		   | Madhura    |Aug  23, 2023 | #MSA00033   | Handled for LIC PDFs
      |0.4		   | Srikanth   |Oct  18, 2023 | #SRI00011   | Added code for Handling all the Ambassador banking Save Receipt
      |0.4		   | Srikanth   |Feb  16, 2024 | #SRI00033   | Added code for Handling the Loan Disclosure Data Format
      |0.4		   | Srikanth   |Feb  21, 2024 | #SRI00036   | Added code for Handling the Purpose of Loan
      |0.4		   | Srikanth   |Feb  29, 2024 | #SRI00037   | Added Code for Group Health and life application format
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

 */

// #DVJ00018 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.twilio.sdk.verbs.Uri;

import net.sirma.fuzzy.fuzzywuzzy.FuzzySearch;
import net.sirma.impacto.iapp.iconfig.MongoConfig;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController;
import net.sirma.impacto.iapp.iutils.Ioutils;

//import com.mongodb.client.MongoDatabase;
//import com.mongodb.client.gridfs.GridFSBucket;
//import com.mongodb.client.gridfs.GridFSBuckets;
//import com.mongodb.client.gridfs.GridFSDownloadStream;
import org.bson.types.ObjectId;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

import javax.imageio.ImageIO;
import org.apache.pdfbox.jbig2.Bitmap;

public class IPDFPopulatorKeyMapping {
	private Logger logger = LoggerFactory.getLogger(IPDFPopulatorKeyMapping.class);
	private DBController db$Ctrl = new DBController();
	private IResManipulator i$ResM = new IResManipulator();
	private IFuncSrvcController i$Func = new IFuncSrvcController();
	private Ioutils i$outis = new Ioutils();
	private Ioutils I$Ioutils = new Ioutils();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			// Creating a PdfDocument object
			//#PKY00045 starts
			JsonObject jBody = new JsonObject();
			if(isonMsg.has("i-body"))
				 jBody = isonMsg.getAsJsonObject("i-body");
			else
				jBody = isonMsg;
			//#PKY00045 ends
			String base64 = "";
			JsonObject jFilter = new JsonObject();
			jFilter.addProperty("pdfId", jBody.get("pdfId").getAsString());
			jFilter.addProperty("active", "A");

			JsonObject pdfHelper = new JsonObject();
			pdfHelper = db$Ctrl.db$GetRow("ICOR_M_PDF_TEMPLATE", jFilter);
			String pdfName = pdfHelper.get("pdfName").getAsString();
			base64 = pdfHelper.get("template").getAsString();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			PdfReader reader = new PdfReader(Base64.decode(base64));
			PdfStamper stamp = new PdfStamper(reader, baos);
			AcroFields form = stamp.getAcroFields();
//			JsonObject funcData = new JsonObject();

			// fillPDFField(jBody,form);
			JsonObject data = uploadToDms(pdfName , base64 , "");
			String FileUrlToken = data.get("i-body").getAsJsonObject().get("FileUrlToken").getAsString();
			String url = generateLink(FileUrlToken,pdfName );
			String QRCodeString = generateQRCode(url);
			pdfValueSetter(jBody, pdfHelper.get("pdfName").getAsString(), form, stamp , QRCodeString);
			pdfValueSetter2(jBody, pdfHelper.get("pdfName").getAsString(), form, stamp , QRCodeString);
			rcptPdfValueSetter(jBody, pdfHelper.get("pdfName").getAsString(), form, stamp);
//			LICPdfValueSetter(jBody, pdfHelper.get("pdfName").getAsString(), form, stamp); //MSA00033 changes
			pdfValueSetter3(jBody, pdfHelper.get("pdfName").getAsString(), form, stamp , QRCodeString);
			
			stamp.setFormFlattening(true);
			stamp.close();
			String Strbase64 = Base64.encodeBytes(baos.toByteArray());
			
			//Strbase64 = Strbase64.replace("\n", "");
			uploadToDms(pdfName , Strbase64 , FileUrlToken);
			if(i$outis.$iStrFuzzyMatch(jBody.get("pdfId").getAsString(), "LOAN001")) {
				JsonObject result = i$Func.flexcubeDataMapping(Strbase64 , isonMsg);
				if(result.getAsJsonObject("i-body").has("I#FileData")) {
					return result;
				}
			}

			jBody = new JsonObject();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", jBody);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg.getAsJsonObject("i-body"), "I#FileData", Strbase64);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PDF GENERATED SUCCESSFULLY");

			return isonMsg;

		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO GENERATE");
			return isonMsg;
		}
	}

	// SBC0087 START
	private void setformfield(AcroFields form, String fldnam, String val, String OrginalKey) {

		try {
			if (JchangedVals == null || (JchangedVals != null && JchangedVals.size() < 1)
					|| (JchangedVals != null && JchangedVals.size() > 0 && JchangedVals.has(OrginalKey)))
				form.setField(fldnam, val);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}	
	
	public String generateLink(String FileUrlToken,String pdfName) {
		String Query = "FileUrlToken="+FileUrlToken;  
		String url = "";
		JsonObject projection = new JsonObject();
		projection.addProperty("_id", 0);
		projection.addProperty("pdfStatementURL", 1);
		url = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection).getAsJsonObject().get("pdfStatementURL").getAsString()+Query;
//		url = "http://localhost:63002/ImpactoPuppy_Core/miniStatement.pdf?"+Query;
		url = url.replace("##type##", pdfName);
		return url;
	}
	
	public String getDayOfMonthSuffix( int dateInt,String dateString) { 
		if(dateInt ==1 || dateInt ==11 || dateInt ==31) {
    	   dateString = (dateInt+" st").toString();
		}else if(dateInt ==2 || dateInt == 22) {
    	   dateString = (dateInt+" nd").toString();
       }else if(dateInt ==3 || dateInt == 23) {
    	   dateString = (dateInt+" rd").toString();
       }else {
    	  dateString = (dateInt+" th").toString();
       }   
       return dateString;
}
	
	public String getDayOfMonthSuffix2( int amountDate,String dateString2) { 
		if(amountDate ==1 || amountDate ==11 || amountDate ==31) {
    	   dateString2 = (amountDate+" st").toString();
		}else if(amountDate ==2 || amountDate == 22) {
    	   dateString2 = (amountDate+" nd").toString();
       }else if(amountDate ==3 || amountDate == 23) {
    	   dateString2 = (amountDate+" rd").toString();
       }else {
    	  dateString2 = (amountDate+" th").toString();
       }   
       return dateString2;
}
	
	public String generateQRCode(String url) {
		String charset = "UTF-8";
		Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
		hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
		BitMatrix matrix = null;
		try {
			matrix = new MultiFormatWriter().encode(new String(url.getBytes(charset), charset),
					BarcodeFormat.QR_CODE, 50, 50);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedImage bufferedImage = MatrixToImageWriter.toBufferedImage(matrix);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			ImageIO.write(bufferedImage, "png", baos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] pdfBytes = baos.toByteArray();
		String result = java.util.Base64.getEncoder().encodeToString(pdfBytes);
		return result;
		
	}
	
	public JsonObject uploadToDms(String pdfName , String base64Str , String FileUrlToken) {
		JsonObject i$Header = new JsonObject();
		JsonObject isonMsgCopy = new JsonObject();
		JsonObject i$Body = new JsonObject();
		JsonObject result$ = null;
		try {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation1", "FILEUPLD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "screenid", "FDMFLUPD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation", "CREATE");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileName", pdfName + ".pdf");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileExtn", ".pdf");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileSize", 2307138);
			if(!i$outis.$iStrFuzzyMatch(FileUrlToken, ""))
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileUrlToken", FileUrlToken);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocType", "LETTER MINI STATEMENT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "I#FileData", base64Str);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Compressed", "N");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "OriginalFileName", "N");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "tranId", "y9m6jis5r3cGZTEqxGzS");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID1", "MINI STATEMENT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "LinkedCustNo", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocNo", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubVersion", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueDt", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocExpiryDt", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueAuthority", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldIP", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldSrc", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key5", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key6", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key7", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key8", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key9", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key10", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "TmpStorageRec", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldDateTime", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocPlaceIssue", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld5", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld6", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld7", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld8", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld9", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld10", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocVersion", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_HEADER, i$Header);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_BDYTAG, i$Body);
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsgCopy, i$ResM.I_STATTAG);

			JsonObject isonReqhead = new JsonObject();
			JsonObject isonMapJson = new JsonObject();
			String ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController";
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsgCopy, isonReqhead, isonMapJson);
		}catch(Exception e) {
			
		}
		return result$;
	}
	
	private void fillPDFField(JsonObject dataObject, String fieldKey, AcroFields form) {
        try {

            if (fieldKey.contains("_")) {
                int index = fieldKey.indexOf("_");
                String orKey = fieldKey.substring(0, index);
                try {
                    String nomVal = dataObject.get(orKey).getAsString();
                    if (i$outis.$iStrFuzzyMatch(fieldKey, orKey + "_" + nomVal)) {
                        setformfield(form, fieldKey, "X", orKey);
                    }
                } catch (Exception e) {
                    if (dataObject.has(fieldKey)) {
                        String nomVal = dataObject.get(fieldKey).getAsString();
                        setformfield(form, fieldKey, nomVal);
                    }
                }
            } else {
                if (dataObject.has(fieldKey)) {
                    String nomVal = dataObject.get(fieldKey).getAsString();
                    setformfield(form, fieldKey, nomVal);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	//#PKY00038 starts
		private void fillPDFFieldWithExportValue(JsonObject dataObject, String fieldKey, AcroFields form, int indx) {
		    try {
		        Integer wrprIndx = new Integer(indx);
		        String lastStr = wrprIndx.toString();

		        if (fieldKey.contains("_")) {
		            int index = fieldKey.indexOf("_");
		            String orKey = fieldKey.substring(0, index);
		            String
		            export = fieldKey.substring(index + 1);
		            String exportvalue = "Yes";
		            if (
		                export.equalsIgnoreCase("No")) {
		                exportvalue = "No";
		            }
		            try {
		                String nomVal = dataObject.get(orKey).getAsString();
		                if (i$outis.$iStrFuzzyMatch(fieldKey, orKey + "_" + nomVal)) {
		                    setformfield(form, fieldKey, exportvalue, orKey);
		                }
		            } catch (Exception e) {
		                if (dataObject.has(fieldKey)) {
		                    String nomVal = dataObject.get(fieldKey).getAsString();
		                    setformfield(form, fieldKey, nomVal);
		                }
		            }
		            try {
		                String nomVal = dataObject.get(orKey.substring(0, orKey.length() - 1)).getAsString();
		                char lstChar = orKey.charAt(orKey.length() - 1);
		                String lstCharStr = Character.toString(lstChar);
		                if (i$outis.$iStrFuzzyMatch(lstCharStr, lastStr)) {
		                    if (i$outis.$iStrFuzzyMatch(fieldKey, orKey + "_" + nomVal)) {
		                        setformfield(form, fieldKey, exportvalue, orKey);
		                    }
		                }

		            } catch (Exception e) {

		            }
		        } else {
		            if (dataObject.has(fieldKey)) {
		                String nomVal = dataObject.get(fieldKey).getAsString();
		                setformfield(form, fieldKey, nomVal);
		            } else {
		                int len = fieldKey.length();
		                char lastIndex = fieldKey.charAt(len - 1);
		                String charStr = Character.toString(lastIndex);
		                if (i$outis.$iStrFuzzyMatch(charStr, lastStr)) {
		                    if (lastIndex > 48 && lastIndex < 57) {
		                        String fieldKey2 = fieldKey.substring(0, len - 1);
		                        if (dataObject.has(fieldKey2)) {
		                            String nomVal = dataObject.get(fieldKey2).getAsString();
		                            setformfield(form, fieldKey, nomVal);
		                        }
		                    }
		                }

		            }
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}
		//#PKY00038 ends

	public static String createTECUMobNo(String isdCode, String mobNo) {
		try {
			return new StringBuilder()// removed "+"
					.append(isdCode.length() > 3 ? isdCode.substring(0, 1) : "").append(isdCode.length() > 3 ? "-" : "")// removed
																														// (
					.append(isdCode.length() > 3 ? isdCode.substring(1) : isdCode).append("-")// removed )
					.append(mobNo.substring(0, 3)).append("-").append(mobNo.length() > 7 ? mobNo.substring(3, 6) : "")
					.append(mobNo.length() > 7 ? "-" : "")
					.append(mobNo.length() > 7 ? mobNo.substring(6) : mobNo.substring(3)).toString();
		} catch (Exception e) {
			
			return isdCode + "-" + mobNo;

			// return null;
		}
	}
	 //#SRP00002 Starts
	public static String createTECUWorkPhoneNo(String isdCode, String mobNo) {
		try {
			String workPhone= new StringBuilder()// removed "+"
					.append(isdCode.length() > 3 ? isdCode.substring(0, 1) : "").append(isdCode.length() > 3 ? "-" : "")// removed
																														// (
					.append(isdCode.length() > 3 ? isdCode.substring(1) : isdCode).append("-")// removed )
					.append(mobNo.substring(0, 3)).append("-") //.append(mobNo.length() > 7 ? mobNo.substring(3, 6) : "")
				//	.append(mobNo.length() > 7 ? "-" : "")
					.append(mobNo.length() > 7 ? mobNo.substring(3) : mobNo.substring(3)).toString();
	          return workPhone;
		} catch (Exception e) {		
			return isdCode + "-" + mobNo;

			// return null;
		}
	}
	//#SRP00002 Ends

	public static String createClicoMobNo(String mobNo) {
		try {
			return new StringBuilder()// removed "+"
					.append(mobNo.substring(0, 3)).append("-").append(mobNo.length() > 7 ? mobNo.substring(3, 6) : "")
					.append(mobNo.length() > 7 ? "-" : "")
					.append(mobNo.length() > 7 ? mobNo.substring(6) : mobNo.substring(3)).toString();
		} catch (Exception e) {
			
			return mobNo;
		}
	}

	private JsonObject separateDateComps(JsonObject jsonModuleDetails, String dateIdentifier) {
		try {
			if (jsonModuleDetails.has(dateIdentifier)) {
				try {
					String[] dateComps = jsonModuleDetails.get(dateIdentifier).getAsString().split("/");
					if (Integer.parseInt(dateComps[0]) < 10) {
						String day = "0" + dateComps[0];
						jsonModuleDetails.addProperty(new String(dateIdentifier + "DD"), day);
					} else {
						jsonModuleDetails.addProperty(new String(dateIdentifier + "DD"), dateComps[0]);
					}
					jsonModuleDetails.addProperty(new String(dateIdentifier + "MM"), dateComps[1]);
					jsonModuleDetails.addProperty(new String(dateIdentifier + "YYYY"), dateComps[2]);
				} catch (Exception e) {
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonModuleDetails;
	}

	public static String getClicoDateFormat(String date) {
		try {
			StringBuilder strDate = new StringBuilder();
			String[] dateComps = date.split("-");
			if (dateComps[2].length() == 1 && Integer.parseInt(dateComps[2]) < 10)
				dateComps[2] = "0" + dateComps[2];
			if (dateComps[1].length() == 1 && Integer.parseInt(dateComps[1]) < 10)
				dateComps[1] = "0" + dateComps[1];
			return strDate.append(dateComps[1]).append("/").append(dateComps[2]).append("/").append(dateComps[0])
					.toString();
		} catch (Exception e) {
			
			return date;
		}
	}

	public static String getStringInPascalCase(String defString) {
		try {
			int intCharValueAtPos0 = (int) defString.charAt(0);
			if (intCharValueAtPos0 >= 97 && intCharValueAtPos0 <= 122) {
				intCharValueAtPos0 -= 32;
				return (char) intCharValueAtPos0 + defString.substring(1);
			} else {
				return defString;
			}
		} catch (Exception e) {
			return defString;
		}
	}

	private void concatContactNos(AcroFields form, String number, String extension, JsonObject dataObject) {
		try {
			if (dataObject.has(number) && !dataObject.get(number).getAsString().isEmpty()) {
				if (dataObject.has(extension) && !dataObject.get(extension).getAsString().isEmpty()) {
					setformfield(form, number, createTECUMobNo(dataObject.get(extension).getAsString(),
							dataObject.get(number).getAsString()));
				} else {
					setformfield(form, number, dataObject.get(number).getAsString());
				}
			} else {
				setformfield(form, number, "");
			}
			// setformfield(form,"nomMobNo",
			// dataObject.get("nomMobNoExtension").getAsString() +
			// dataObject.get("nomMobNo").getAsString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//#SRP00027 Starts
	private void pdfValueSetter2(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp , String base64)
			throws IOException, DocumentException {
		Map<String, AcroFields.Item> fieldsLinkedHashMap = form.getFields();
		List<String> filedName = new ArrayList<String>(fieldsLinkedHashMap.keySet());
		if (pdfName.equalsIgnoreCase("Beneficiary_Agreement_Fixed_Deposit")) {
			JsonObject tranDetails = jsonObject.get("trnData").getAsJsonObject();
			try {
				if (tranDetails.has("addCity") && !i$outis.$iStrBlank(tranDetails.get("addCity").getAsString())) {
					setformfield(form, "city", tranDetails.get("addCity").getAsString());
				}
			} catch (Exception e) {

			}
			try {
				if (tranDetails.has("addCountry") && !i$outis.$iStrBlank(tranDetails.get("addCountry").getAsString())) {
					setformfield(form, "country", tranDetails.get("addCountry").getAsString());
				}
			} catch (Exception e) {

			}
			try {
				if (tranDetails.has("addLine1") || tranDetails.has("addLine2") || tranDetails.has("addLine3")
						|| tranDetails.has("addLine4")) { //#SRP00037 Changes
					StringBuilder strfullname = new StringBuilder();
					try {
						if (tranDetails.has("addLine1")
								&& !i$outis.$iStrBlank(tranDetails.get("addLine1").getAsString())) {
							strfullname.append(tranDetails.get("addLine1").getAsString());
						}
					} catch (Exception e) {

					}
					try {
						if (tranDetails.has("addLine2")
								&& !i$outis.$iStrBlank(tranDetails.get("addLine2").getAsString())) {
							strfullname.append(" ");
							strfullname.append(tranDetails.get("addLine2").getAsString());
						}
					} catch (Exception e) {

					}
					try {
						if (tranDetails.has("addLine3")
								&& !i$outis.$iStrBlank(tranDetails.get("addLine3").getAsString())) {
							strfullname.append(" ");
							strfullname.append(tranDetails.get("addLine3").getAsString());
						}
					} catch (Exception e) {

					}
					try {
						if (tranDetails.has("addLine4")
								&& !i$outis.$iStrBlank(tranDetails.get("addLine4").getAsString())) {
							strfullname.append(" ");
							strfullname.append(tranDetails.get("addLine4").getAsString());
						}
					} catch (Exception e) {

					}
					setformfield(form, "no", strfullname.toString());
				}
			} catch (Exception e) {

			}
			try {
				for (int i = 0; i <= filedName.size(); i++) {

					fillPDFField(tranDetails, filedName.get(i), form);
				}
			} catch (Exception e) {

			}
			
			try {
				addImage(stamp, form, "Qr_code_1", base64);
			}catch(Exception e) {
				
			}
			
			try {
				if (tranDetails.has("custNo") && !i$outis.$iStrBlank(tranDetails.get("custNo").getAsString())) {
					setformfield(form, "memberNo", tranDetails.get("custNo").getAsString());
				}
			} catch (Exception e) {

			}

			try { // #SRP00003 changes Starts //#PKY00061 starts
			    if (tranDetails.has("CustomerFullName")) {
			        String[] name = tranDetails.get("CustomerFullName").getAsString().split(" ");
			      
			        if (name.length == 3) {
			            setformfield(form, "firstName", name[0]);
			            setformfield(form, "other", name[1]);
			            setformfield(form, "surname", name[2]);
			        }else if(name.length == 4) {
			        	StringBuilder names = new StringBuilder();
			        	names.append(name[1]);
			        	names.append(" ");
			        	names.append(name[2]);
			        	setformfield(form, "firstName", name[0]);
			            setformfield(form, "other", names.toString());
			            setformfield(form, "surname", name[3]);
			        }else if(name.length == 5) {
			        	StringBuilder names = new StringBuilder();
			        	names.append(name[1]);
			        	names.append(" ");
			        	names.append(name[2]);
			        	names.append(" ");
			        	names.append(name[3]);
			        	setformfield(form, "firstName", name[0]);
			            setformfield(form, "other", names.toString());
			            setformfield(form, "surname", name[4]);
			        }else if(name.length == 6) {
			        	StringBuilder names = new StringBuilder();
			        	names.append(name[1]);
			        	names.append(" ");
			        	names.append(name[2]);
			        	names.append(" ");
			        	names.append(name[3]);
			        	names.append(" ");
			        	names.append(name[4]);
			        	setformfield(form, "firstName", name[0]);
			            setformfield(form, "other", names.toString());
			            setformfield(form, "surname", name[5]);
			        }else {
			            setformfield(form, "firstName", name[0]);
			            setformfield(form, "surname", name[1]);
			        }
			    }
			} catch (Exception e) {} // #SRP00003 changes Ends //#PKY00061 ends
			try {
				if (tranDetails.has("dateOfIssue")
						&& !i$outis.$iStrBlank(tranDetails.get("dateOfIssue").getAsString())) {
					setformfield(form, "date", tranDetails.get("dateOfIssue").getAsString());
				}
			} catch (Exception e) {

			}
			try {
				if (tranDetails.has("payInAccNo") && !i$outis.$iStrBlank(tranDetails.get("payInAccNo").getAsString())) {
					setformfield(form, "accountNo", tranDetails.get("payInAccNo").getAsString());
				}
			} catch (Exception e) {

			}
			// #SRP00004 Starts
			JsonArray beneficiary = jsonObject.get("trnData").getAsJsonObject().get("beneficiary").getAsJsonArray();
			for (int i = 1; i <= beneficiary.size(); i++) {
				JsonObject benDetails = beneficiary.get(i - 1).getAsJsonObject();

				try {  //MVT00003    starts
					if(benDetails.has("percentBenefits")&& !i$outis.$iStrBlank(benDetails.get("percentBenefits").getAsString())) {
						setformfield(form, "percentage_"+i,benDetails.get("percentBenefits").getAsString());
					}
				} catch(Exception e) {
					
				}  //MVT00003 ends
				try {
					if (benDetails.has("lastName") && !i$outis.$iStrBlank(benDetails.get("lastName").getAsString())) {
						setformfield(form, "surname" + i, benDetails.get("lastName").getAsString());
					}
				} catch (Exception e) {
				}
				try {
					if (benDetails.has("firstName") && !i$outis.$iStrBlank(benDetails.get("firstName").getAsString())) {
						setformfield(form, "first" + i, benDetails.get("firstName").getAsString());
					}
				} catch (Exception e) {
				}
				try {
					if (benDetails.has("middleName")
							&& !i$outis.$iStrBlank(benDetails.get("middleName").getAsString())) {
						setformfield(form, "other" + i, benDetails.get("middleName").getAsString());
					}
				} catch (Exception e) {
				}
				try {
					if (benDetails.has("addCity") && !i$outis.$iStrBlank(benDetails.get("addCity").getAsString())) {
						setformfield(form, "city" + i, benDetails.get("addCity").getAsString());
					}
				} catch (Exception e) {
				}
				try {
					if (benDetails.has("addCountry")
							&& !i$outis.$iStrBlank(benDetails.get("addCountry").getAsString())) {
						setformfield(form, "country" + i, benDetails.get("addCountry").getAsString());
					}
				} catch (Exception e) {
				}
				try {

					if (i$outis.$iStrBlank(benDetails.get("mobileNo").getAsString()))
						setformfield(form, "phone1No" + i, "");
					else
						setformfield(form, "phone1No" + i,
								createTECUMobNo(benDetails.get("mobileNoExtension").getAsString(),
										benDetails.get("mobileNo").getAsString()));

				} catch (Exception e) {

				}
				// #SRP00025 Starts
				try {

					if (i$outis.$iStrBlank(benDetails.get("mobileNo2").getAsString()))
						setformfield(form, "phone2No" + i, "");
					else
						setformfield(form, "phone2No" + i,
								createTECUMobNo(benDetails.get("mobileNoExtension2").getAsString(),
										benDetails.get("mobileNo2").getAsString()));

				} catch (Exception e) {

				} // #SRP00025 Ends

				try {
					if (benDetails.has("addLine1") || benDetails.has("addline2") || benDetails.has("addLine3")
							|| benDetails.has("addLine4")) {
						StringBuilder benFullAddress = new StringBuilder();
						try {
							if (benDetails.has("addLine1")
									&& !i$outis.$iStrBlank(benDetails.get("addLine1").getAsString())) {
								benFullAddress.append(benDetails.get("addLine1").getAsString());
							}
						} catch (Exception e) {

						}
						try {
							if (benDetails.has("addLine2")
									&& !i$outis.$iStrBlank(benDetails.get("addLine2").getAsString())) { //#MVT00112 code changes
								benFullAddress.append(", ");
								benFullAddress.append(benDetails.get("addLine2").getAsString());

							}
						} catch (Exception e) {

						}
						try {
							if (benDetails.has("addLine3")
									&& !i$outis.$iStrBlank(benDetails.get("addLine3").getAsString())) {
								benFullAddress.append(", ");
								benFullAddress.append(benDetails.get("addLine3").getAsString());
							}
						} catch (Exception e) {

						}
						try {
							if (benDetails.has("addLine4")
									&& !i$outis.$iStrBlank(benDetails.get("addLine4").getAsString())) {
								benFullAddress.append(", ");
								benFullAddress.append(benDetails.get("addLine4").getAsString());
							}
						} catch (Exception e) {

						}
						setformfield(form, "no" + i, benFullAddress.toString());
					}
				} catch (Exception e) {
				}
				// #SRP00018 Starts
				try {
					if (benDetails.has("driversPermitId") || benDetails.has("nationalId")
							|| benDetails.has("passportId")) {
						if (benDetails.has("driversPermitId")
								&& !i$outis.$iStrBlank(benDetails.get("driversPermitId").getAsString()))
							setformfieldS(form, "identificationNoCountryCodeifApplicable" + i,
									benDetails.get("driversPermitId").getAsString());
						else if (benDetails.has("nationalId")
								&& !i$outis.$iStrBlank(benDetails.get("nationalId").getAsString()))
							setformfieldS(form, "identificationNoCountryCodeifApplicable" + i,
									benDetails.get("nationalId").getAsString());
						else if (benDetails.has("passportId")
								&& !i$outis.$iStrBlank(benDetails.get("passportId").getAsString()))
							setformfieldS(form, "identificationNoCountryCodeifApplicable" + i,
									benDetails.get("passportId").getAsString());
					}
				} catch (Exception e) {

				} // #SRP00018 Ends
			}
		}else if (pdfName.equalsIgnoreCase("Tatil_Coronavirus_Questionnaire_Form")) {   //#PKY00059 starts
			  JsonObject tatilCoronaQuestionnaire = jsonObject.get("tatilCoronaQuestionnaire").getAsJsonObject();
			  try {
					for (int i = 0; i <= filedName.size(); i++) {
						fillPDFField(tatilCoronaQuestionnaire, filedName.get(i), form);
					}
				}catch(Exception e) {
						
				}
				try {// #SRP00034 changes start	//#MVT00015 Changes starts
					if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("isAdditionOfPrimary").getAsString(),
							"true")) {
						setformfieldS(form, "additionOfPrimaryInsured", "Yes");
					}
				} catch (Exception e) {
				}
				try {
					if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("isAdditionOfDependent").getAsString(),
							"true"))
						setformfieldS(form, "additionOfDependent", "Yes");
				} catch (Exception e) {
				}
				try {
					if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("isPolicyReinstatement").getAsString(),
							"true"))
						setformfieldS(form, "policyReinstatement", "Yes");
				} catch (Exception e) {	//#MVT00015 Changes ends
				} // #SRP00034 changes Ends
			  
			  JsonArray eligibleDependent = tatilCoronaQuestionnaire.get("eligibleDependent").getAsJsonArray();
				 try {
					 for(int j=0;j<eligibleDependent.size();j++) {
						 int index =j+1;
						 JsonObject dependentDet = eligibleDependent.get(j).getAsJsonObject();
						 try {
							 for (int i = 0; i <= filedName.size(); i++) {
									fillPDFFieldWithExportValue(dependentDet, filedName.get(i), form, index);
								}
						 }catch(Exception e) {
						 }	//#MVT00006 Starts
						 try {
							 if(dependentDet.has("depemdentDoB") && !i$outis.$iStrBlank(dependentDet.get("depemdentDoB").getAsString())){
								  String[] dob = dependentDet.get("depemdentDoB").getAsString().split("-");
								  String year = dob[0];
								  String month = dob[1];
								  String day = dob[2];
								  String DOB = new StringBuilder(day+"-").append(month).append("-"+year).toString();
								 setformfield(form, "depemdentDoB"+index, DOB);;
							 } 
						 }catch(Exception e) {
							 
						 }	//#MVT00006 ends
					 }
				 }catch(Exception e) {
				 }
			  try {
				  if (tatilCoronaQuestionnaire.has("diagnosedWithCovid19WithinPast30Days") && !i$outis.$iStrBlank(tatilCoronaQuestionnaire.get("diagnosedWithCovid19WithinPast30Days").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("diagnosedWithCovid19WithinPast30Days").getAsString(), "Y")) {
						  setformfieldS(form, "diagnosedWithCovid19WithinPast30DaysYes", "Yes");
						  try {//#PKY00059 starts
							  String diagnoseDetails = tatilCoronaQuestionnaire.get("diagnoseDetails").getAsString();
							  if(diagnoseDetails.length()>94) { //#SRP00037 changes
								  setformfieldS(form, "diagnoseDetails1", tatilCoronaQuestionnaire.get("diagnoseDetails").getAsString().substring(0, 94));
								  setformfieldS(form, "diagnoseDetails2", tatilCoronaQuestionnaire.get("diagnoseDetails").getAsString().substring(94, diagnoseDetails.length()));
								  
							  }else {
								  setformfieldS(form, "diagnoseDetails1", tatilCoronaQuestionnaire.get("diagnoseDetails").getAsString());
							  }
						  }catch(Exception e) {
							  
						  }//#PKY00059 ends
					  }else if(i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("diagnosedWithCovid19WithinPast30Days").getAsString(), "N")) {
						  setformfieldS(form, "diagnosedWithCovid19WithinPast30DaysNo", "Yes");
					  }
				  }                   
			  }catch(Exception e) {
			  }
			  try {
				  if (tatilCoronaQuestionnaire.has("travelOutSideYourTrinidadAndTobagoSince1Decenber2019") && !i$outis.$iStrBlank(tatilCoronaQuestionnaire.get("travelOutSideYourTrinidadAndTobagoSince1Decenber2019").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("travelOutSideYourTrinidadAndTobagoSince1Decenber2019").getAsString(), "Y")) {
						  setformfieldS(form, "travelOutSideYourTrinidadAndTobagoSince1Decenber2019Yes", "Yes");
						  try {//#PKY00059 starts
							  String nameOfCountryAndDateOfTravel = tatilCoronaQuestionnaire.get("nameOfCountryAndDateOfTravel").getAsString();
							  if(nameOfCountryAndDateOfTravel.length()>94) { //#SRP00037 changes
								  setformfieldS(form, "nameOfCountryAndDateOfTravel1", tatilCoronaQuestionnaire.get("nameOfCountryAndDateOfTravel").getAsString().substring(0, 94));
								  setformfieldS(form, "nameOfCountryAndDateOfTravell2", tatilCoronaQuestionnaire.get("nameOfCountryAndDateOfTravel").getAsString().substring(94, nameOfCountryAndDateOfTravel.length()));
								  
							  }else {
								  setformfieldS(form, "nameOfCountryAndDateOfTravel1", tatilCoronaQuestionnaire.get("nameOfCountryAndDateOfTravel").getAsString());
							  }
						  }catch(Exception e) {
							  
						  }//#PKY00059 ends
					  }else if(i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("travelOutSideYourTrinidadAndTobagoSince1Decenber2019").getAsString(), "N")) {
						  setformfieldS(form, "travelOutSideYourTrinidadAndTobagoSince1Decenber2019No", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
			  try {
				  if (tatilCoronaQuestionnaire.has("coronaReportStatus") && !i$outis.$iStrBlank(tatilCoronaQuestionnaire.get("coronaReportStatus").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("coronaReportStatus").getAsString(), "Y")) {
						  setformfieldS(form, "coronaReportStatusYes", "Yes");
						  try {//#PKY00059 starts
							  String DetailOfReport = tatilCoronaQuestionnaire.get("DetailOfReport").getAsString();
							  if(DetailOfReport.length()>94) {  //#SRP00037 changes
								  setformfieldS(form, "DetailOfReport1", tatilCoronaQuestionnaire.get("DetailOfReport").getAsString().substring(0, 94));
								  setformfieldS(form, "DetailOfReports2", tatilCoronaQuestionnaire.get("DetailOfReport").getAsString().substring(94, DetailOfReport.length()));
								  
							  }else {
								  setformfieldS(form, "DetailOfReport1", tatilCoronaQuestionnaire.get("DetailOfReport").getAsString());
							  }
						  }catch(Exception e) {
							  
						  }//#PKY00059 ends
					  }else if(i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("coronaReportStatus").getAsString(), "N")) {
						  setformfieldS(form, "coronaReportStatusNo", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
			
			  try {
				  if (tatilCoronaQuestionnaire.has("healthStatus") && !i$outis.$iStrBlank(tatilCoronaQuestionnaire.get("healthStatus").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("healthStatus").getAsString(), "Y")) {
						  setformfieldS(form, "healthStatusYes", "Yes");
					  }else if(i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("healthStatus").getAsString(), "N")) {
						  setformfieldS(form, "healthStatusNo", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
			  try {
				  if (tatilCoronaQuestionnaire.has("adviceForTest") && !i$outis.$iStrBlank(tatilCoronaQuestionnaire.get("adviceForTest").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("adviceForTest").getAsString(), "Y")) {
						  setformfieldS(form, "adviceForTestYes", "Yes");
					  }else if(i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("adviceForTest").getAsString(), "N")) {
						  setformfieldS(form, "adviceForTestNo", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
			  try {
				  if (tatilCoronaQuestionnaire.has("coronaSymptons") && !i$outis.$iStrBlank(tatilCoronaQuestionnaire.get("coronaSymptons").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("coronaSymptons").getAsString(), "Y")) {
						  setformfieldS(form, "coronaSymptonsYes", "Yes");
						  try {//#PKY00059 starts
							  String detailOfSymptons = tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString();
							  if(detailOfSymptons.length()>188) { //#SRP00037 changes
								  setformfieldS(form, "detailOfSymptons1", tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString().substring(0, 94));
								  setformfieldS(form, "detailOfSympton2", tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString().substring(94, 188));
								  setformfieldS(form, "detailOfSymptonsa3", tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString().substring(188, detailOfSymptons.length()));
								  
							  }else {
								  if(detailOfSymptons.length()>94) {
									  setformfieldS(form, "detailOfSymptons1", tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString().substring(0, 94));
									  setformfieldS(form, "detailOfSympton2", tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString().substring(94, detailOfSymptons.length()));
									  
								  }else {
									  setformfieldS(form, "detailOfSymptons1", tatilCoronaQuestionnaire.get("detailOfSymptons").getAsString());
								  }
							  }
						  }catch(Exception e) {
							  
						  }//#PKY00059 ends
					  }else if(i$outis.$iStrFuzzyMatch(tatilCoronaQuestionnaire.get("coronaSymptons").getAsString(), "N")) {
						  setformfieldS(form, "coronaSymptonsNo", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
		  }  //#SRP00011 Ends
		//#PKY00059 ends
		else if (pdfName.equalsIgnoreCase("Common_Law_Relationship_Form")) { // #SRP00027 Starts
			JsonObject TatilCommonLaw = jsonObject.get("TatilCommonLaw").getAsJsonObject();
			try {
				for (int i = 0; i <= filedName.size(); i++) {

					fillPDFField(TatilCommonLaw, filedName.get(i), form);
				}
			} catch (Exception e) {

			}
			try {
				if (TatilCommonLaw.has("dateOfDeclared")) {
					String[] DOB = getClicoDateFormat(TatilCommonLaw.get("dateOfDeclared").getAsString()).split("/");
					String month = DOB[0];
					String day = DOB[1];
					String year = DOB[2];
					setformfield(form, "year1", year);
					setformfield(form, "day", day);
					setformfield(form, "month1", month);
				}
				;
			} catch (Exception e) {

			}// #SRP00027 Ends
		}else if(pdfName.equalsIgnoreCase("LinCU_Prepaid_MasterCard")){         //#PKY00036 starts
			  JsonObject lincuDetails = jsonObject.get("fcbl").getAsJsonObject();
			  try {
					for (int i = 0; i <= filedName.size(); i++) {
						fillPDFField(lincuDetails, filedName.get(i), form);
						fillPDFField(jsonObject, filedName.get(i), form);
					}
				}catch(Exception e) {
						
				}
			  try {		//#MVT00005 starts	//#MVT00023 Changes starts
				  if (lincuDetails.has("dob") && !i$outis.$iStrBlank(lincuDetails.get("dob").getAsString())) {
					  String[] DOB = getClicoDateFormat(lincuDetails.get("dob").getAsString()).split("/");
					  String year = DOB[2];
					  String month = DOB[0];
					  String day = DOB[1];
					  String date = new StringBuilder(day+"-").append(month).append("-"+year).toString();
					  setformfieldS(form, "dob", date);
				  }
			  }catch(Exception e) {	//#MVT00023 Changes ends
				  
			  }		//#MVT00005 end
			  //#SRP00026 Starts
			  try {
				  if (lincuDetails.has("ssnNo") && !i$outis.$iStrBlank(lincuDetails.get("ssnNo").getAsString())) {
					  String ssnNo=lincuDetails.get("ssnNo").getAsString();
					  String ssnNo1=ssnNo.substring(0, 3);
					  setformfieldS(form, "ssnNo1", ssnNo1);
					  String ssnNo2=ssnNo.substring(3, 5);
					  setformfieldS(form, "ssnNo2", ssnNo2);
					  String ssnNo3=ssnNo.substring(5, 9);
					  setformfieldS(form, "ssnNo3", ssnNo3);
				  }
			  }catch(Exception e) {
			  } //#SRP00026 Ends
			  try {
				  if (lincuDetails.has("doYouHaveFcbAccount") && !i$outis.$iStrBlank(lincuDetails.get("doYouHaveFcbAccount").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(lincuDetails.get("doYouHaveFcbAccount").getAsString(), "Y")) {
						  setformfieldS(form, "PYes", "Yes");
					      setformfield(form, "lincuMemberCif", lincuDetails.get("cif").getAsString());
					  }else if(i$outis.$iStrFuzzyMatch(lincuDetails.get("doYouHaveFcbAccount").getAsString(), "N")) {
						  setformfieldS(form, "PNo", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
			  //#SRP00016 Starts
			  try {        
				  {//#MVT00095 Changes starts
					if (i$outis.$iStrFuzzyMatch(lincuDetails.get("fcbShareHolding").getAsString(), "majorityShareholder"))
						setformfieldS(form, "majorShareholder", "Yes");
					else if (i$outis.$iStrFuzzyMatch(lincuDetails.get("fcbShareHolding").getAsString(), "minorityShareholder"))
						setformfieldS(form, "minorShareholder", "Yes");
					else if (i$outis.$iStrFuzzyMatch(lincuDetails.get("fcbShareHolding").getAsString(), "notAShareholder"))//#MVT00095 Changes ends
						setformfieldS(form, "NotaShareHolder", "Yes");
				}
			}catch (Exception e) {
				
			} //#SRP00016 Ends
			  try {
				  if (lincuDetails.has("gender") && !i$outis.$iStrBlank(lincuDetails.get("gender").getAsString())) {
						  setformfieldS(form, "Credit_UnionBranch-Sex", lincuDetails.get("gender").getAsString());
				  }
			  }catch(Exception e) {
			  }
			  try {
				  if (lincuDetails.has("maritalStatusDesc") && !i$outis.$iStrBlank(lincuDetails.get("maritalStatusDesc").getAsString())) {//#SRP00035 changes
						  setformfieldS(form, "Credit_UnionBranch-MarialStts", lincuDetails.get("maritalStatusDesc").getAsString());
				  }
			  }catch(Exception e) {
			  }
			  //MSA   starts
			  
			  try {
				  if (lincuDetails.has("motherMaidenName") && !i$outis.$iStrBlank(lincuDetails.get("motherMaidenName").getAsString())) {
						  setformfieldS(form, "mothersMaidenName", lincuDetails.get("motherMaidenName").getAsString());
				  }
			  }catch(Exception e) {
			  }
			  try {
				  if (lincuDetails.has("annualIncome") && !i$outis.$iStrBlank(lincuDetails.get("annualIncome").getAsString())) {
						  setformfieldS(form, "annualIncome", lincuDetails.get("annualIncome").getAsString());
				  }
			  }catch(Exception e) {
			  }
			  
			  //MSA   ends
			  
			  try {	//#MVT00113 changes starts
				  if(lincuDetails.has("employersName")&& i$outis.$iStrFuzzyMatch(lincuDetails.get("employersName").getAsString(), "OTHER")) {
					  setformfieldS(form, "employersName", lincuDetails.get("employerOther").getAsString());
				  }
				  else if(lincuDetails.has("employersNameDesc")&& !i$outis.$iStrBlank(lincuDetails.get("employersNameDesc").getAsString())) {
					  setformfieldS(form, "employersName", lincuDetails.get("employersNameDesc").getAsString());
				  }
				}catch(Exception e) {
			  }//#MVT00113 changes ends
			  try {
				  if(lincuDetails.has("countryBusinessDesc")&& !i$outis.$iStrBlank(lincuDetails.get("countryBusinessDesc").getAsString())) {
					  setformfieldS(form, "countryBusiness", lincuDetails.get("countryBusinessDesc").getAsString());
				  }
				}catch(Exception e) {
			  }
			  try {
				  if(lincuDetails.has("phone")&& !i$outis.$iStrBlank(lincuDetails.get("phone").getAsString())) {
					  setformfieldS(form, "phone", lincuDetails.get("phone").getAsString());
				  }
				}catch(Exception e) {
			  }
			  
			  try {
				  if (lincuDetails.has("countryOfBirthDesc") && !i$outis.$iStrBlank(lincuDetails.get("countryOfBirthDesc").getAsString())) {
						  setformfieldS(form, "countryOfBirth", lincuDetails.get("countryOfBirthDesc").getAsString());
				  }
			  }catch(Exception e) {
			  }//#SRP00035 Ends
			  try {
				  if (lincuDetails.has("permanentAddressHomeOwnership") && !i$outis.$iStrBlank(lincuDetails.get("permanentAddressHomeOwnership").getAsString())) {
					  if (i$outis.$iStrFuzzyMatch(lincuDetails.get("permanentAddressHomeOwnership").getAsString(), "Own")) {
						  setformfieldS(form, "PHomeOwnership", "Yes");
					  }else if(i$outis.$iStrFuzzyMatch(lincuDetails.get("permanentAddressHomeOwnership").getAsString(), "Rent")) {
						  setformfieldS(form, "PHomeOwnershipRent", "Yes");
					  }else if(i$outis.$iStrFuzzyMatch(lincuDetails.get("permanentAddressHomeOwnership").getAsString(), "liveWithRelative")) {  //MVT00001 Changes
						  setformfieldS(form, "PHomeOwnership_livewith", "Yes");
					  }else if(i$outis.$iStrFuzzyMatch(lincuDetails.get("permanentAddressHomeOwnership").getAsString(), "Sublet")) {    //MVT00001 Changes
						  setformfieldS(form, "PHomeOwnershipSublet", "Yes");
					  }
				  }
			  }catch(Exception e) {
			  }
			  //#SRP00038 starts
			  try {
				  if (lincuDetails.has("citizenshipCountry1Desc") && !i$outis.$iStrBlank(lincuDetails.get("citizenshipCountry1Desc").getAsString())) {
					  setformfield(form, "CitizenshipCountry1", lincuDetails.get("citizenshipCountry1Desc").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("citizenshipCountry2Desc") && !i$outis.$iStrBlank(lincuDetails.get("citizenshipCountry2Desc").getAsString())) {
					  setformfield(form, "CitizenshipCountry2", lincuDetails.get("citizenshipCountry2Desc").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("citizenshipCountry3Desc") && !i$outis.$iStrBlank(lincuDetails.get("citizenshipCountry3Desc").getAsString())) {
					  setformfield(form, "CitizenshipCountry3", lincuDetails.get("citizenshipCountry3Desc").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("citizenshipCountry4Desc") && !i$outis.$iStrBlank(lincuDetails.get("citizenshipCountry4Desc").getAsString())) {
					  setformfield(form, "CitizenshipCountry4", lincuDetails.get("citizenshipCountry4Desc").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  //#SRP00038 Ends
			  try {
				  if (lincuDetails.has("homePhone") && !i$outis.$iStrBlank(lincuDetails.get("homePhone").getAsString())) {
					  setformfield(form, "Home Phone", lincuDetails.get("homePhone").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("mobilePhone") && !i$outis.$iStrBlank(lincuDetails.get("mobilePhone").getAsString())) {
					  setformfield(form, "Mobile Phone", lincuDetails.get("mobilePhone").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("faxNumber") && !i$outis.$iStrBlank(lincuDetails.get("faxNumber").getAsString())) {
					  setformfield(form, "Fax Number", lincuDetails.get("faxNumber").getAsString());
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("eligibleForForeignTax") && i$outis.$iStrFuzzyMatch(lincuDetails.get("eligibleForForeignTax").getAsString(), "Y")) {
					  setformfieldS(form, "Yes", "Yes");
				  }
				  else if(lincuDetails.has("eligibleForForeignTax") && i$outis.$iStrFuzzyMatch(lincuDetails.get("eligibleForForeignTax").getAsString(), "N")) {
					  setformfieldS(form, "No", "Yes");
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("citizenshipInAnotherCountry") && i$outis.$iStrFuzzyMatch(lincuDetails.get("citizenshipInAnotherCountry").getAsString(), "Y")) {
					  setformfieldS(form, "ctzYes", "Yes");
				  }
				  else if(lincuDetails.has("citizenshipInAnotherCountry") && i$outis.$iStrFuzzyMatch(lincuDetails.get("citizenshipInAnotherCountry").getAsString(), "N")) {
					  setformfieldS(form, "ctzNo", "Yes");
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("documentsForForeignTax") && i$outis.$iStrFuzzyMatch(lincuDetails.get("documentsForForeignTax").getAsString(), "Y")) {
					  setformfieldS(form, "FYes", "Yes");
				  }
				  else if(lincuDetails.has("documentsForForeignTax") && i$outis.$iStrFuzzyMatch(lincuDetails.get("documentsForForeignTax").getAsString(), "N")) {
					  setformfieldS(form, "FNo", "Yes");
				  }
			  }catch(Exception e) {
				  
			  }
			  try {
				  if (lincuDetails.has("powerOfAttorny") && i$outis.$iStrFuzzyMatch(lincuDetails.get("powerOfAttorny").getAsString(), "Y")) {
					  setformfieldS(form, "PwrYes", "Yes");
				  }
				  else if(lincuDetails.has("powerOfAttorny") && i$outis.$iStrFuzzyMatch(lincuDetails.get("powerOfAttorny").getAsString(), "N")) {
					  setformfieldS(form, "PwrFNo", "Yes");
				  }
			  }catch(Exception e) {
				  
			  }//#PKY00036 ends
			  StringBuilder address = new StringBuilder();//MSA00072 starts
				try {
					if (lincuDetails.has("permanentAddressLine3") && !i$outis.$iStrBlank(lincuDetails.get("permanentAddressLine3").getAsString())) {
						try {
							if (lincuDetails.has("permanentAddressLine3") && !i$outis.$iStrBlank(lincuDetails.get("permanentAddressLine3").getAsString())) {
								address.append(lincuDetails.get("permanentAddressLine3").getAsString());
							}
						} catch (Exception e) {}
						try {
							if (lincuDetails.has("permanentAddressLine4") && !i$outis.$iStrBlank(lincuDetails.get("permanentAddressLine4").getAsString())) {
								address.append(" ");
								address.append(lincuDetails.get("permanentAddressLine4").getAsString());
							}
						} catch (Exception e) {}
					} else {
						try {
							if (lincuDetails.has("permanentAddressLine4") && !i$outis.$iStrBlank(lincuDetails.get("permanentAddressLine4").getAsString())) {
								address.append(lincuDetails.get("permanentAddressLine4").getAsString());
							}
						} catch (Exception e) {}
					}
					setformfield(form, "permanentAddressCity", address.toString());
				}catch(Exception e) {
				  setformfield(form, "permanentAddressCity", " ");
			  }//MSA00072 ends
		  }
		  //#SRP00011 Start
	      //#PKY00038 starts
       else if(pdfName.equalsIgnoreCase("Tatil_Evidence_of_Insurability_Form")) {
		  
		  JsonObject tatilInsurabilityData = jsonObject.get("tatilEvidenceOfInsurability").getAsJsonObject();
		  //#SRP00034 Starts
		  try {        
				if (i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("isSelf").getAsString(), "true"))
					setformfieldS(form, "employeeApplyingForCoverageFor_self", "Yes");
				else if (i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("isDependents").getAsString(), "true"))
					setformfieldS(form, "employeeApplyingForCoverageFor_dependents", "Yes");
		}catch (Exception e) {
			
		} //#SRP00034 Ends
		  try {
				for (int i = 0; i <= filedName.size(); i++) {
					fillPDFFieldWithExportValue(tatilInsurabilityData, filedName.get(i), form, 0);
				}
			}catch(Exception e) {
					
			}
		//#SRP00016 starts
		  try {        
				if (i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("medical").getAsString(), "true"))
					setformfieldS(form, "coverageApplied_medical", "Yes");
				else if (i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("Life").getAsString(), "true"))
					setformfieldS(form, "coverageApplied_life", "Yes");
				else if (i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("AD").getAsString(), "true"))
					setformfieldS(form, "coverageApplied_AD", "Yes");
				else if (i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("criticalIllness").getAsString(), "true"))
					setformfieldS(form, "coverageApplied_criticalIllness", "Yes");						
		}catch (Exception e) {
			
		} 
		  if(tatilInsurabilityData.has("dateForlastConsultation")|| tatilInsurabilityData.has("reasonForlastConsultation")) {
				StringBuilder strfullname = new StringBuilder();
				try {
					if (tatilInsurabilityData.has("dateForlastConsultation") && !i$outis.$iStrBlank(tatilInsurabilityData.get("dateForlastConsultation").getAsString())) {
						strfullname.append(tatilInsurabilityData.get("dateForlastConsultation").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (tatilInsurabilityData.has("reasonForlastConsultation") && !i$outis.$iStrBlank(tatilInsurabilityData.get("reasonForlastConsultation").getAsString())) {
						strfullname.append(" ");
						strfullname.append(tatilInsurabilityData.get("reasonForlastConsultation").getAsString());
					}
				} catch (Exception e) {
					
				}
				setformfield(form, "dateAndReasonForlastConsultation", strfullname.toString());
			}//#SRP00016 ends 
		  
		 JsonArray dependent = tatilInsurabilityData.get("dependent").getAsJsonArray();
		 try {
			 int childIndex = 2;
			 for(int j=0;j<dependent.size();j++) {
				 int index =j+1;
				 JsonObject dependentDet = dependent.get(j).getAsJsonObject();
				 if(i$outis.$iStrFuzzyMatch(dependentDet.get("dependentRelationship").getAsString(), "Employee")) //#SRP00041 Starts
				 {
					 try {
						 for (int i = 0; i <= filedName.size(); i++) {
								fillPDFFieldWithExportValue(dependentDet, filedName.get(i), form, index);
							}
					 }catch(Exception e) {
					 }
					 try {        //#MVT00005 changes starts
							if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Single"))
								setformfieldS(form, "dependentMaritalStatus1_S", "Yes");
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Married"))
								setformfieldS(form, "dependentMaritalStatus1_M", "Yes");
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Divorced"))
								setformfieldS(form, "dependentMaritalStatus1_D", "Yes");
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Other"))
								setformfieldS(form, "dependentMaritalStatus1_O", "Yes");	
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Employed"))
								setformfieldS(form, "dependentMaritalStatus1_E", "Yes");		//#MVT00005 changes ends
					}catch (Exception e) {
						
					} 
				 }
				 
				 else if(i$outis.$iStrFuzzyMatch(dependentDet.get("dependentRelationship").getAsString(), "Spouse")) 
				 {
					 try {
						 for (int i = 0; i <= filedName.size(); i++) {
								fillPDFFieldWithExportValue(dependentDet, filedName.get(i), form, index);
							}
					 }catch(Exception e) {
					 }
					 try {        //#MVT00005 changes starts
							if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Single"))
								setformfieldS(form, "dependentMaritalStatus2_S", "Yes");
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Married"))
								setformfieldS(form, "dependentMaritalStatus2_M", "Yes");
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Divorced"))
								setformfieldS(form, "dependentMaritalStatus2_D", "Yes");
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Other"))
								setformfieldS(form, "dependentMaritalStatus2_O", "Yes");	
							else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Employed"))
								setformfieldS(form, "dependentMaritalStatus2_E", "Yes");		//#MVT00005 changes ends
					}catch (Exception e) {
						
					} 
				 }
				 else if(i$outis.$iStrFuzzyMatch(dependentDet.get("dependentRelationship").getAsString(), "Child")) //#SRP00041 Ends
				 {
				 try {
					 childIndex = childIndex + 1;
					 for (int i = 0; i <= filedName.size(); i++) {
							fillPDFFieldWithExportValue(dependentDet, filedName.get(i), form, childIndex);
						}
				 }catch(Exception e) {
				 }
				 try {        //#MVT00005 changes starts
						if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Single"))
							setformfieldS(form, "dependentMaritalStatus"+childIndex+"_S", "Yes");
						else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Married"))
							setformfieldS(form, "dependentMaritalStatus"+childIndex+"_M", "Yes");
						else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Divorced"))
							setformfieldS(form, "dependentMaritalStatus"+childIndex+"_D", "Yes");
						else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Other"))
							setformfieldS(form, "dependentMaritalStatus"+childIndex+"_O", "Yes");	
						else if (i$outis.$iStrFuzzyMatch(dependentDet.get("dependentMaritalStatus").getAsString(), "Employed"))
							setformfieldS(form, "dependentMaritalStatus"+childIndex+"_E", "Yes");		//#MVT00005 changes ends
				}catch (Exception e) {
					
				} 
				 }
			 }
		 }catch(Exception e) {
		 }
		//#PKY00061 starts
//		 try {
//			 if(tatilInsurabilityData.has("isSelf")){
//				 setformfieldS(form, "employeeApplyingForCoverageFor_self", "Yes");
//			 }else if(tatilInsurabilityData.has("isDependents")) {
//				 setformfieldS(form, "employeeApplyingForCoverageFor_dependents", "Yes");
//			 }
//		 }catch(Exception e) {
//			 
//		 }
		//#PKY00061 ends
		 //#PKY00059 starts
		 try {
			 if(i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("hadComplicationOfPregnancyEmployee").getAsString(),"Y")||i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("hadComplicationOfPregnancySpouse").getAsString(),"Y")||i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("hadComplicationOfPregnancyChild").getAsString(),"Y")){
				 String [] DOB = getClicoDateFormat(tatilInsurabilityData.get("hadComplicationOfPregnancyDetailsDate").getAsString()).split("/");
					String month = DOB[0];
					String day = DOB[1];
					String year = DOB[2];
					setformfield(form, "hadComplicationOfPregnancyDetailsDate_DD",day);
					setformfield(form, "hadComplicationOfPregnancyDetailsDate_MM",month);
					setformfield(form, "hadComplicationOfPregnancyDetailsDate_YY",year);
			 }
			 if(i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("anyOfDependentsPregnantEmployee").getAsString(),"Y")||i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("anyOfDependentsPregnantChild").getAsString(),"Y")||i$outis.$iStrFuzzyMatch(tatilInsurabilityData.get("anyOfDependentsPregnantSpouse").getAsString(),"Y")){
				 String [] DOB = getClicoDateFormat(tatilInsurabilityData.get("anyOfDependentsPregnantDetailsDate").getAsString()).split("/");
					String month = DOB[0];
					String day = DOB[1];
					String year = DOB[2];
					setformfield(form, "anyOfDependentsPregnantDetailsDate_DD",day);
					setformfield(form, "anyOfDependentsPregnantDetailsDate_MM",month);
					setformfield(form, "anyOfDependentsPregnantDetailsDate_YY",year);
			 }
		 }catch(Exception e) {
			 
		 }//#PKY00059 ends
		 //#SKP00011 Starts
		 JsonArray insuranceTypes = tatilInsurabilityData.get("insuranceTypes").getAsJsonArray();
//		 JsonArray policy=tatilInsurabilityData.get("policy").getAsJsonArray();//#SRP0055 changes
		 try {
			 
			 for(int j=0;j<insuranceTypes.size();j++) {
				 StringBuilder yearOfIssuedbuldr = new StringBuilder();
				 StringBuilder insuredPersonbuldr = new StringBuilder();
				 StringBuilder nameOfInsuranceCompanybuldr = new StringBuilder();
				 StringBuilder typeOfCoveragebuldr = new StringBuilder();
				 int index =j+1;
				 JsonObject insuranceDet = insuranceTypes.get(j).getAsJsonObject();//#SRP0055 changes
				 String noOfPolicyStr = insuranceDet.get("noOfpolicy").getAsString();
				 JsonArray insuranceDetArr = insuranceDet.get("policy").getAsJsonArray();
				 int noOfPolicy = Integer.parseInt(noOfPolicyStr);
				 
				 for(int i = 0; i< noOfPolicy; i++) {
					 JsonObject policy = insuranceDetArr.get(i).getAsJsonObject();
					 if (policy.has("yearOfIssued")) {
						 if(yearOfIssuedbuldr.length() > 0) {
							 yearOfIssuedbuldr.append(",");
						 }
						 yearOfIssuedbuldr.append(policy.get("yearOfIssued").getAsString());
						 
						 
					 }
					 if (policy.has("insuredPerson")) {
						 if(insuredPersonbuldr.length() > 0) {
							 insuredPersonbuldr.append(",");
						 }
						 insuredPersonbuldr.append(policy.get("insuredPerson").getAsString());
						 
					 }
					 if (policy.has("nameOfInsuranceCompany")) {
						 if(nameOfInsuranceCompanybuldr.length() > 0) {
							 nameOfInsuranceCompanybuldr.append(",");
						 }
						 nameOfInsuranceCompanybuldr.append(policy.get("nameOfInsuranceCompany").getAsString());
						 
						 
					 }
					 if (policy.has("typeOfCoverage")) {
						 if(typeOfCoveragebuldr.length() > 0) {
							 typeOfCoveragebuldr.append(",");
						 }
						 typeOfCoveragebuldr.append(policy.get("typeOfCoverage").getAsString());
						 
						 
					 }
				 }
				 form.setField("yearOfIssued"+index, yearOfIssuedbuldr.toString());
				 form.setField("insuredPerson"+index, insuredPersonbuldr.toString());
				 form.setField("nameOfInsuranceCompany"+index, nameOfInsuranceCompanybuldr.toString());
				 form.setField("typeOfCoverage"+index, typeOfCoveragebuldr.toString());
				 
			 }
		 }catch(Exception e) {
		 }
		 //#SKP00011 Ends
		 JsonArray disease = tatilInsurabilityData.get("disease").getAsJsonArray();
		 try {
			 for(int j=0;j<disease.size();j++) {
				 int index =j+1;
				 JsonObject diseaseDet = disease.get(j).getAsJsonObject();
				 try {
					 for (int i = 0; i <= filedName.size(); i++) {
						 fillPDFFieldWithExportValue(diseaseDet, filedName.get(i), form, index);
						}
				 }catch(Exception e) {
				 }
			 }
		 }catch(Exception e) {
		 }
		 
		 JsonArray questionDetails = tatilInsurabilityData.get("questionDetails").getAsJsonArray();
		 try {
			 for(int j=0;j<questionDetails.size();j++) {
				 int index =j+1;
				 JsonObject questionDet = questionDetails.get(j).getAsJsonObject();
				 try {
					 for (int i = 0; i <= filedName.size(); i++) {
						  fillPDFFieldWithExportValue(questionDet, filedName.get(i), form, index);
						}
				 }catch(Exception e) {
				 }
			 }
		 }catch(Exception e) {
		 }
	  }//#PKY00038 ends
       else if (pdfName.equalsIgnoreCase("Cuna_Designation_Of_Beneficiary")|| pdfName.equalsIgnoreCase("Cuna_Enrolment_Form")) {    //#SRP00060 Starts  
			// #SBC0087 starts
			JsonObject cunaMemDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
			JsonArray cunaBenDetails =cunaMemDetails.getAsJsonArray("beneficiaryDetails");
			
			JsonObject nameInfo = jsonObject.get("personalInfo").getAsJsonObject();
			JsonObject addInfo = jsonObject.getAsJsonObject("additionalDetails").getAsJsonObject();
			
			//Cuna_Designation_Of_Beneficiary
			try {
				if (nameInfo.has("firstName")|| nameInfo.has("middleName")|| nameInfo.has("lastName")) {
					StringBuilder strfullname = new StringBuilder();
					try {
						if (nameInfo.has("firstName") && !i$outis.$iStrBlank(nameInfo.get("firstName").getAsString())) {
							strfullname.append(nameInfo.get("firstName").getAsString());
						}
					} catch (Exception e) {
						
					}
					try {
						if (nameInfo.has("middleName") && !i$outis.$iStrBlank(nameInfo.get("middleName").getAsString())) {
							strfullname.append(" ");
							strfullname.append(nameInfo.get("middleName").getAsString());
						}
					} catch (Exception e) {
						
					}
					try {
						if (nameInfo.has("lastName") && !i$outis.$iStrBlank(nameInfo.get("lastName").getAsString())) {
							strfullname.append(" ");
							strfullname.append(nameInfo.get("lastName").getAsString());
						}
					} catch (Exception e) {
						
					}
					
					setformfield(form, "cunaMemFullName", strfullname.toString());
				}
			} catch (Exception e) {
				
			}
//Cuna_Designation_Of_Beneficiary
			
			try {
				if(cunaMemDetails.has("cunaPlanType") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaPlanType").getAsString()) ) { 
					setformfield(form, "cunaPlanType", cunaMemDetails.get("cunaPlanType").getAsString());
					setformfield(form, "FIPBEN", cunaMemDetails.get("individualBenefit").getAsString());
					setformfield(form, "FIPPREM", cunaMemDetails.get("monthlyPremium").getAsString());
//					setformfield(form, "CIPREM", cunaMemDetails.get("cirMonthlyPremium").getAsString()); //#MVT00093 Changes starts        
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			//#MVT00093 Changes ends
		
//cuna_CIR_details
			try {
				String BenCondCheck = cunaMemDetails.get("isCIR").getAsString();
				if(BenCondCheck.equalsIgnoreCase("Y")) {
					
					try {
						setformfieldS(form, "CIR", "On");
						
						if(cunaMemDetails.has("cunaCIRCovAmt") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaCIRCovAmt").getAsString()) ) {
							setformfield(form, "CICOVAMT", cunaMemDetails.get("cunaCIRCovAmt").getAsString());
						}
					}catch(Exception e) {
						
					} 
					try {
						if(cunaMemDetails.has("cirMonthlyPremium") && !i$outis.$iStrBlank(cunaMemDetails.get("cirMonthlyPremium").getAsString())) {
						setformfield(form, "CIPREM", cunaMemDetails.get("cirMonthlyPremium").getAsString());
						}
					}catch(Exception e) {
						
					}
					try {
						if(cunaMemDetails.has("cunaIllness") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllness").getAsString()) ) {
							if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllness").getAsString(), "Y")) {
								setformfieldS(form, "CIQ1", "Yes");
								
                                 if(cunaMemDetails.has("cunaIllnessDetails") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllnessDetails").getAsString()) ) {
                               	  setformfield(form, "CIQ1INFO", cunaMemDetails.get("cunaIllnessDetails").getAsString());
								}
								
							}
							else if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllness").getAsString(), "N")) {
								setformfieldS(form, "CIQ1", "No");
							}
						}
					}catch(Exception e) {
						
					}
					try {
						if(jsonObject.has("cunaInsurance")) {
							String age = jsonObject.get("cunaInsurance").getAsJsonObject().get("age").getAsString();
							setformfield(form, "age_band", age);                       

						}
					}catch(Exception e) {
						
					}
					try {
						if(cunaMemDetails.has("cunaIllnessTreatment") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllnessTreatment").getAsString()) ) {
							if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllnessTreatment").getAsString(), "Y")) {
								setformfieldS(form, "CIQ2", "Yes");
								
                                 if(cunaMemDetails.has("cunaIllnessTreatmentDetails") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllnessTreatmentDetails").getAsString()) ) {
                               	  setformfield(form, "CIRQ2INFO", cunaMemDetails.get("cunaIllnessTreatmentDetails").getAsString());
								}
								
							}
							else if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllnessTreatment").getAsString(), "N")) {
								setformfieldS(form, "CIQ2", "No");
							}
						}
						
					}catch(Exception e) {
						
					}
				}
			}catch(Exception e) {
				
			}
				
					
//cune_beneficiary_details
	try {		
		for (int i = 1; i <=cunaBenDetails.size() ; i++) {
			
				JsonObject cunaBen =cunaBenDetails.get(i-1).getAsJsonObject();
			
					try {
						if(cunaBen.has("firstName")&& !i$outis.$iStrBlank(cunaBen.get("firstName").getAsString())) {
							try {
							if (cunaBen.has("firstName")|| cunaBen.has("middleName")|| cunaBen.has("lastName")) {
								StringBuilder strCunaBen = new StringBuilder();
								try {
									if (cunaBen.has("firstName") && !i$outis.$iStrBlank(cunaBen.get("firstName").getAsString())) {
										strCunaBen.append(cunaBen.get("firstName").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (cunaBen.has("middleName") && !i$outis.$iStrBlank(cunaBen.get("middleName").getAsString())) {
										strCunaBen.append(" ");
										strCunaBen.append(cunaBen.get("middleName").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (cunaBen.has("lastName") && !i$outis.$iStrBlank(cunaBen.get("lastName").getAsString())) {
										strCunaBen.append(" ");
										strCunaBen.append(cunaBen.get("lastName").getAsString());
									}
								} catch (Exception e) {
									
								}
								
								setformfield(form, "cunaBen"+i+"FullName", strCunaBen.toString());
							}
							}catch(Exception e) {
								
							}
							
							try {
								if (cunaBen.has("dob")) {
									String cunaDob = cunaBen.get("dob").getAsString();
									setformfield(form, "cunaBen"+i+"Dob", cunaDob);
								}
							} catch (Exception e) {
								
							}
							
							try {

								if (i$outis.$iStrBlank(cunaBen.get("mobileNo").getAsString()))//#SRP00039 changes
									setformfield(form, "cunaBen"+i+"PhoneNumbers", "");
								else
									setformfield(form, "cunaBen"+i+"PhoneNumbers",
											createTECUMobNo(
													cunaBen.get("mobileNoExtension").getAsString(),
													cunaBen.get("mobileNo").getAsString()));

							} catch (Exception e) {
								
							}
							//#SRP00039 starts
							try {
								if(cunaBen.has("address")) {
									setformfield(form, "cunaBen"+i+"Addresse",cunaBen.get("address").getAsString());
								}
								
							}catch(Exception e) {
								
							}
						   //#SRP00039 ends
							try {
								if(cunaBen.has("email")) {//#SRP00039 Changes
									setformfield(form, "cunaBen"+i+"Email",cunaBen.get("email").getAsString());
								}
								
							}catch(Exception e) {
								
							}
							try {
								if(cunaBen.has("dob")) {//#SRP00039 changes
									setformfield(form, "cunaBen"+i+"Dobs",cunaBen.get("dob").getAsString());
								}
								
							}catch(Exception e) {
								
							}
							try {
								if(cunaBen.has("id")) {
									setformfield(form, "cunaBen"+i+"DocID",cunaBen.get("id").getAsString());

								}
							}catch(Exception e) {
								
							}
							try {
								if(cunaBen.has("relation")) {//#SRP00039 Changes
									setformfield(form, "cunaBen"+i+"RelDesc",cunaBen.get("relation").getAsString());

								}
							}catch(Exception e) {
								
							}
							
							try {
								if (cunaBen.has("addLine1")|| cunaBen.has("addline2")|| cunaBen.has("addLine3")||cunaBen.has("addLine4")||cunaBen.has("addCity")||cunaBen.has("addState")||cunaBen.has("addCountry")||cunaBen.has("addZipCode")) {
									StringBuilder ben1FullAddress = new StringBuilder();
									try {
										if (cunaBen.has("addLine1") && !i$outis.$iStrBlank(cunaBen.get("addLine1").getAsString())) {
											ben1FullAddress.append(cunaBen.get("addLine1").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addline2") && !i$outis.$iStrBlank(cunaBen.get("addline2").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addline2").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addLine3") && !i$outis.$iStrBlank(cunaBen.get("addLine3").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addLine3").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addLine4") && !i$outis.$iStrBlank(cunaBen.get("addLine4").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addLine4").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addCity") && !i$outis.$iStrBlank(cunaBen.get("addCity").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addCity").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addState") && !i$outis.$iStrBlank(cunaBen.get("addState").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addState").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addCountry") && !i$outis.$iStrBlank(cunaBen.get("addCountry").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addCountry").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (cunaBen.has("addZipCode") && !i$outis.$iStrBlank(cunaBen.get("addZipCode").getAsString())) {
											ben1FullAddress.append(", ");
											ben1FullAddress.append(cunaBen.get("addZipCode").getAsString());
										}
									} catch (Exception e) {
										
									}
									
									setformfield(form, "cunaBen"+i+"Address", ben1FullAddress.toString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (cunaBen.has("gender")) { //#SRP00039 changes
									if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "M"))
										setformfield(form, "cunaBen"+i+"GenderDescs", "Male");

									else if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "F"))
										setformfield(form, "cunaBen"+i+"GenderDescs", "Female");
									
									else if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "O"))
										setformfield(form, "cunaBen"+i+"GenderDescs", "Other");
									
									else if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "P"))
										setformfield(form, "cunaBen"+i+"GenderDescs", "Prefer Not to Disclose");
								}

							} catch (Exception e) {
								
							}

						}
						
					}catch(Exception e) {
						
					}
				}
			} catch (Exception e) {
				
			}
//cuna_binificiary_details


// CUNA Enrollment form
			JsonObject CunaEnrollDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
			try {
			for (int i = 0; i <= filedName.size(); i++) {
		
			fillPDFField(CunaEnrollDetails, filedName.get(i), form);
			}
			}catch(Exception e) {
				
			}

			try {
				JsonObject cunaPersonalDetail = jsonObject.get("personalInfo").getAsJsonObject();// #SRP00062 starts
				if (cunaPersonalDetail.has("firstName") || cunaPersonalDetail.has("middleName")
						|| cunaPersonalDetail.has("lastName")) {
					try {
						if (cunaPersonalDetail.has("firstName")
								&& !i$outis.$iStrBlank(cunaPersonalDetail.get("firstName").getAsString())) {
							setformfield(form, "FirstName", cunaPersonalDetail.get("firstName").getAsString());
						}
						if (cunaPersonalDetail.has("middleName")
								&& !i$outis.$iStrBlank(cunaPersonalDetail.get("middleName").getAsString())) {
							setformfield(form, "MiddleName", cunaPersonalDetail.get("middleName").getAsString());
						}
						if (cunaPersonalDetail.has("lastName")
								&& !i$outis.$iStrBlank(cunaPersonalDetail.get("lastName").getAsString())) {
							setformfield(form, "LastName", cunaPersonalDetail.get("lastName").getAsString());
						}
					} catch (Exception e) {

					}
				}
			} catch (Exception e) {
				// #SRP00062 Ends
			}

//			try {
//				if (CunaEnrollDetails.has("cunaMemberAddrCntry")) {
//					String memCntry = CunaEnrollDetails.get("cunaMemberAddrCntry").getAsString();
//					setformfield(form, "nationalityDesc", memCntry);
//				}
//
//			} catch (Exception e) {
//				
//			}
			try {//#MVT00084 Changes starts
				if (i$outis.$iStrFuzzyMatch(addInfo.get("isResident").getAsString(), "Y")
						&& addInfo.has("nationalityDesc")) {
					setformfield(form, "nationalityDesc", addInfo.get("nationalityDesc").getAsString());
				} else if (addInfo.has("countryOfResidenceDesc")) {
					setformfield(form, "nationalityDesc", addInfo.get("countryOfResidenceDesc").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			// #MVT00084 Changes ends

			try {
				if (CunaEnrollDetails.has("cunaDob")) {
					String cunaDob = CunaEnrollDetails.get("cunaDob").getAsString();
					setformfield(form, "dob", cunaDob);
				}

			} catch (Exception e) {
				
			}
			try {
				if (CunaEnrollDetails.has("cunaGender")) {
					if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "M"))
						setformfield(form, "genderDesc", "Male");

					else if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "F"))
						setformfield(form, "genderDesc", "Female");
					
					else if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "O"))
						setformfield(form, "genderDesc", "Other");
						
			    	else if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "P"))
							setformfield(form, "genderDesc", "Prefer Not to Disclose");

				}

			} catch (Exception e) {
				
			}

			try {
				JsonObject cunaContactData = jsonObject.get("contactDetails").getAsJsonObject();

				if (i$outis.$iStrBlank(cunaContactData.get("mobileNumber").getAsString()))
					setformfield(form, "cuna_mobile_number", "");
				else
					setformfield(form, "cuna_mobile_number",
							createTECUMobNo(cunaContactData.get("mobileISD").getAsString(),
									cunaContactData.get("mobileNumber").getAsString()));

			} catch (Exception e) {
				
			}
			try {
				JsonObject ContactData = jsonObject.get("contactDetails").getAsJsonObject();
				if (ContactData.has("emailId")) {
					String email = ContactData.get("emailId").getAsString();
					setformfield(form, "emailId", email);
				}
			} catch (Exception e) {
				
			}

			try {
				JsonObject homePhonDetails = jsonObject.get("additionalDetails").getAsJsonObject();
				if (i$outis.$iStrBlank(homePhonDetails.get("homePhoneNumber").getAsString()))
					setformfield(form, "cunaHomePhone", "");
				else
					setformfield(form, "cunaHomePhone",
							createTECUMobNo(homePhonDetails.get("homephoneExtension").getAsString(),
									homePhonDetails.get("homePhoneNumber").getAsString()));

			} catch (Exception e) {
				
			}
			try {
				JsonObject cntryDetaios = jsonObject.get("additionalDetails").getAsJsonObject();
				if (cntryDetaios.has("birthCountryDesc")) { //#MVT00089 changes
					String birthCntry = cntryDetaios.get("birthCountryDesc").getAsString();
					setformfield(form, "birthCountryDesc", birthCntry);
				}

			} catch (Exception e) {
				
			}

			try {
				JsonObject personalDetails = jsonObject.get("personalInfo").getAsJsonObject();
				
				
				try {
					if (nameInfo.has("mailAddLine1")|| nameInfo.has("mailAddLine2")|| nameInfo.has("mailAddLine3") || nameInfo.has("mailAddLine4")) {
						StringBuilder strfullAdd = new StringBuilder();
						try {
							if (nameInfo.has("mailAddLine1") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine1").getAsString())) {
								strfullAdd.append(nameInfo.get("mailAddLine1").getAsString());
							}
						} catch (Exception e) {
							
						}
						try {
							if (nameInfo.has("mailAddLine2") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine2").getAsString())) {
								strfullAdd.append(", ");
								strfullAdd.append(nameInfo.get("mailAddLine2").getAsString());
							}
						} catch (Exception e) {
							
						}
						try {
							if (nameInfo.has("mailAddLine3") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine3").getAsString())) {
								strfullAdd.append(", ");
								strfullAdd.append(nameInfo.get("mailAddLine3").getAsString());
							}
						} catch (Exception e) {
							
						}
						try {
							if (nameInfo.has("mailAddLine4") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine4").getAsString())) {
								strfullAdd.append(" ");
								strfullAdd.append(nameInfo.get("mailAddLine4").getAsString());
							}
						} catch (Exception e) {
							
						} 
						
						setformfield(form, "full_addressline1", strfullAdd.toString());
					}
				} catch (Exception e) {
					
				}
				
				
				try {
					if (personalDetails.has("priDocName") || personalDetails.has("priDocId")) {
						StringBuilder concatDoc = new StringBuilder();
						try {
							String docName = personalDetails.get("priDocName").getAsString();
							concatDoc.append(docName);
							concatDoc.append(" ");
						}catch(Exception e) {
							
						}try {
							String docId = personalDetails.get("priDocId").getAsString();
							concatDoc.append(docId);
						}catch(Exception e) {
							
						}
						
						setformfield(form, "priDocName", concatDoc.toString());
					}
				} catch (Exception e) {
					
				}
			} catch (Exception e) {
				
			}//#SBC0087 ends
		}//#SRP00060 Ends

	// #SKP00003 Starts

	}//MSA00027 starts
	public void rcptPdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp)throws IOException, DocumentException{
//		JsonObject ibody = jsonObject.get("i-body").getAsJsonObject();
		
		if (pdfName.equalsIgnoreCase("ACH_Transfer_Receipt") || pdfName.equalsIgnoreCase("Internal_Refund_Receipt") 
				|| pdfName.equalsIgnoreCase("Lincu_Transfer_Receipt") || pdfName.equalsIgnoreCase("Cheque_Request_Receipt") || pdfName.equalsIgnoreCase("Cuna_FCIP_Receipt")
				|| pdfName.equalsIgnoreCase("CUNA_FIP_Receipt") || pdfName.equalsIgnoreCase("Letter_Request_Receipt") || pdfName.equalsIgnoreCase("LinCU_Application_Receipt")
				|| pdfName.equalsIgnoreCase("Loan_Auto_Renewal_Receipt") || pdfName.equalsIgnoreCase("Service_Request_Receipt") || pdfName.equalsIgnoreCase("BanktoTECU_Receipt")
				|| pdfName.equalsIgnoreCase("Fixed_Deposit_Receipt") || pdfName.equalsIgnoreCase("Fully_Secured_Loan_Application_Receipt") 
				|| pdfName.equalsIgnoreCase("Loan_Repayment_Receipt")|| pdfName.equalsIgnoreCase("My_Information_Receipt")|| pdfName.equalsIgnoreCase("Un-Secured_Loan_Application_Receipt") 
				|| pdfName.equalsIgnoreCase("Line_Of_Credit_Application_Receipt")|| pdfName.equalsIgnoreCase("Self_Transfer_Receipt") ||  pdfName.equalsIgnoreCase("Member_OnBoarding_Receipt") 
				|| pdfName.equalsIgnoreCase("Re_KYM_Receipt")
				|| pdfName.equalsIgnoreCase("Cash_Deposit_Receipt")  //SRI00011 starts
				|| pdfName.equalsIgnoreCase("Cash_Withdrawal_Receipt")
				|| pdfName.equalsIgnoreCase("Fund_transfer_internal_bank_Receipt")
				|| pdfName.equalsIgnoreCase("Third_party_cash_deposit_Receipt")
				|| pdfName.equalsIgnoreCase("Cheque_request_Receipt")
				|| pdfName.equalsIgnoreCase("Letter_request_Receipt")
				|| pdfName.equalsIgnoreCase("Fixed_Deposit_Receipt")
				|| pdfName.equalsIgnoreCase("Account_opening_Receipt")) {
//			try {
//				if (jsonObject.has("pdfName") && !i$outis.$iStrBlank(jsonObject.get("pdfName").getAsString())) {
//					setformfield(form, "PdfName", jsonObject.get("pdfName").getAsString());
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}														 //SRI00011 ends
			try {
				if (jsonObject.has("transactionType")
						&& !i$outis.$iStrBlank(jsonObject.get("transactionType").getAsString())) {
					setformfield(form, "TypeOfTransaction", jsonObject.get("transactionType").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (jsonObject.has("referenceNo") && !i$outis.$iStrBlank(jsonObject.get("referenceNo").getAsString())) {
					setformfield(form, "ReferenceNumber", jsonObject.get("referenceNo").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (jsonObject.has("date") && !i$outis.$iStrBlank(jsonObject.get("date").getAsString())) {
					setformfield(form, "Date", jsonObject.get("date").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (jsonObject.has("time") && !i$outis.$iStrBlank(jsonObject.get("time").getAsString())) {
					setformfield(form, "Time", jsonObject.get("time").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (jsonObject.has("fromName") && !i$outis.$iStrBlank(jsonObject.get("fromName").getAsString())) {
					setformfield(form, "NameFrom", jsonObject.get("fromName").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (jsonObject.has("fromAccNo") && !i$outis.$iStrBlank(jsonObject.get("fromAccNo").getAsString())) {
					setformfield(form, "A/CFrom", jsonObject.get("fromAccNo").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (jsonObject.has("toName") && !i$outis.$iStrBlank(jsonObject.get("toName").getAsString())) {
					setformfield(form, "NameTo", jsonObject.get("toName").getAsString());
				}
			} catch (Exception e) {
			}
			try {
				if (jsonObject.has("toAccNo") && !i$outis.$iStrBlank(jsonObject.get("toAccNo").getAsString())) {
					setformfield(form, "A/CTo", jsonObject.get("toAccNo").getAsString());
				}
			} catch (Exception e) {
			}
			try {
				if (jsonObject.has("amount") && !i$outis.$iStrBlank(jsonObject.get("amount").getAsString())) {
					setformfield(form, "Amount", jsonObject.get("amount").getAsString());
				}
			} catch (Exception e) {
			}
			try {
				if (jsonObject.has("applicationId")
						&& !i$outis.$iStrBlank(jsonObject.get("applicationId").getAsString())) {
					setformfield(form, "ApplicationId", jsonObject.get("applicationId").getAsString());
				}
			} catch (Exception e) {
			}
			try {
				if (jsonObject.has("applicantName")
						&& !i$outis.$iStrBlank(jsonObject.get("applicantName").getAsString())) {
					setformfield(form, "ApplicantsName", jsonObject.get("applicantName").getAsString());
				}
			} catch (Exception e) {
			}
			try {
				if (jsonObject.has("totalPremium")
						&& !i$outis.$iStrBlank(jsonObject.get("totalPremium").getAsString())) {
					setformfield(form, "TotalPremium", jsonObject.get("totalPremium").getAsString());
				}
			} catch (Exception e) {
			}
		}
	}// MSA00027 ends
	
	//MSA00001 starts
	public void clicoMapping(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp)throws IOException, DocumentException{

		
		// #PKY00008 starts
//		JsonObject i$Body = isonMsg.getAsJsonObject("i-body");
		JsonObject jsonClicoDetails = jsonObject.get("clicoDeclaration").getAsJsonObject();
		JsonObject additionalDetl = jsonObject.get("additionalDetails").getAsJsonObject(); 
		JsonObject empDetails = jsonObject.get("employment").getAsJsonObject();
		JsonArray benDetails = jsonClicoDetails.get("beneficiaryDetails").getAsJsonArray();
		JsonObject ben1details = benDetails.get(0).getAsJsonObject();
		JsonObject ben2Details = benDetails.get(1).getAsJsonObject();
		JsonObject adrDetails = jsonObject.get("addressResult").getAsJsonObject();
		JsonObject clicoPersonalDetail=jsonObject.get("personalInfo").getAsJsonObject();//#SRP00062 starts
		try {
			if(clicoPersonalDetail.has("firstName") && !i$outis.$iStrBlank(clicoPersonalDetail.get("firstName").getAsString())) {
				setformfield(form, "firstName", clicoPersonalDetail.get("firstName").getAsString());
			}
			if(clicoPersonalDetail.has("middleName") && !i$outis.$iStrBlank(clicoPersonalDetail.get("middleName").getAsString())) {
				setformfield(form, "middleName", clicoPersonalDetail.get("middleName").getAsString());
			}
			if(clicoPersonalDetail.has("lastName") && !i$outis.$iStrBlank(clicoPersonalDetail.get("lastName").getAsString())) {
				setformfield(form, "lastName", clicoPersonalDetail.get("lastName").getAsString());
			}
		}catch(Exception e) {
			
		}//#SRP00062 Ends
		
		try { 
			StringBuilder addrs = new StringBuilder();
			if (empDetails.has("employerAddressLine1") && !i$outis.$iStrBlank(empDetails.get("employerAddressLine1").getAsString())) {
				addrs.append(empDetails.get("employerAddressLine1").getAsString());
			} if(empDetails.has("employerAddressLine2") && !i$outis.$iStrBlank(empDetails.get("employerAddressLine2").getAsString())) {
				addrs.append(", ");
				addrs.append(empDetails.get("employerAddressLine2").getAsString());
			}
			setformfield(form, "employerStreet", addrs.toString());
		} catch (Exception e) {
		}
		try {
			if (empDetails.has("employerCity") && !i$outis.$iStrBlank(empDetails.get("employerCity").getAsString())) {
				setformfield(form, "employerCity", empDetails.get("employerCity").getAsString());
			}
			if (empDetails.has("employerCountryDesc")
					&& !i$outis.$iStrBlank(empDetails.get("employerCountryDesc").getAsString())) {
				setformfield(form, "employerCountry", empDetails.get("employerCountryDesc").getAsString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		try {
			if(jsonClicoDetails.has("clicoEmpName") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoEmpName").getAsString())) {
				setformfield(form, "clicoEmployerName", jsonClicoDetails.get("clicoEmpName").getAsString());   
			}
		}catch(Exception e) {
			
		}
		try {
			if(jsonClicoDetails.has("clicoPermAddCountryDesc") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoPermAddCountryDesc").getAsString())) {
				setformfield(form, "clicoPermAddCountryDesc", jsonClicoDetails.get("clicoPermAddCountryDesc").getAsString());   
			}
		}catch(Exception e) {
			
		}
		
		try {
			if(jsonClicoDetails.has("clicoMailAddCountryDesc") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoMailAddCountryDesc").getAsString())) {
				setformfield(form, "clicoMailAddCountryDesc", jsonClicoDetails.get("clicoMailAddCountryDesc").getAsString());   
			}
		}catch(Exception e) {
			
		}
		
		try { 
			if(empDetails.has("employerDesc") && !i$outis.$iStrBlank(empDetails.get("employerDesc").getAsString())) {
				if(i$outis.$iStrFuzzyMatch(empDetails.get("employer").getAsString(), "OTHER")) {
					setformfield(form, "clicoEmplDescName", empDetails.get("employerOther").getAsString());
				}else {
					setformfield(form, "clicoEmplDescName", empDetails.get("employerDesc").getAsString());
				}
			} //#MVT00081 Changes ends
		}catch(Exception e) {
			
		}
		
		try {
		String  secondBenCondn = jsonClicoDetails.get("addBeneficiary").getAsString();
		if(secondBenCondn.equalsIgnoreCase("Y")) {
			try {
				if (ben2Details.has("dob"))
					setformfield(form, "clicoBen2Dob", getClicoDateFormat(ben2Details.get("dob").getAsString()));
			} catch (Exception e) {
				
			}
			try {
				if (ben2Details.has("trusteeDOB"))
					setformfield(form, "clicoBen2TrusteeDOB",
							getClicoDateFormat(ben2Details.get("trusteeDOB").getAsString()));
			} catch (Exception e) {
				
			}
			try {
				if (ben2Details.has("percentBenefits")) {
					if (!ben2Details.get("percentBenefits").getAsString().equals(""))
						setformfield(form, "clicoBen2PercentBenefits",
								ben2Details.get("percentBenefits").getAsString() + "%");
				}
			} catch (Exception e) {
				
			}
			
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("mobileNo").getAsString())) {
					setformfield(form, "clicoBen2MobileNo",
							createClicoMobNo(ben2Details.get("mobileNo").getAsString()));
					setformfield(form, "clicoBen2MobileNoExtension",
							ben2Details.get("mobileNoExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("homePhone").getAsString())) {
					setformfield(form, "clicoBen2HomePhone",
							createClicoMobNo(ben2Details.get("homePhone").getAsString()));
					setformfield(form, "clicoBen2HomePhoneExtension",
							ben2Details.get("homePhoneExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("workPhone").getAsString())) {
					setformfield(form, "clicoBen2WorkPhone",
							createClicoMobNo(ben2Details.get("workPhone").getAsString()));
					setformfield(form, "clicoBen2WorkPhoneExtension",
							ben2Details.get("workPhoneExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeMobNo").getAsString())) {
					setformfield(form, "clicoBen2TrusteeMobNo",
							createClicoMobNo(ben2Details.get("trusteeMobNo").getAsString()));
					setformfield(form, "clicoBen2TrusteeMobNoExtension",
							ben2Details.get("trusteeMobNoExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeHomePhone").getAsString())) {
					setformfield(form, "clicoBen2TrusteeHomePhone",
							createClicoMobNo(ben2Details.get("trusteeHomePhone").getAsString()));
					setformfield(form, "clicoBen2TrusteeHomePhoneExtension",
							ben2Details.get("trusteeHomePhoneExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("empFaxNo").getAsString())) {
					setformfield(form, "clicoBen2EmpFaxNo",
							createClicoMobNo(ben2Details.get("empFaxNo").getAsString()));
					setformfield(form, "clicoBen2EmpFaxNoExtension",
							ben2Details.get("empFaxNoExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("firstName").getAsString()))
					setformfield(form, "clicoBen2FirstName", ben2Details.get("firstName").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("middleName").getAsString()))
					setformfield(form, "clicoBen2MiddleName", ben2Details.get("middleName").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("lastName").getAsString()))
					setformfield(form, "clicoBen2LastName", ben2Details.get("lastName").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("addCity").getAsString()))
					setformfield(form, "clicoBen2AddCity", ben2Details.get("addCity").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("empAddCity").getAsString()))
					setformfield(form, "clicoBen2EmpAddCity", ben2Details.get("empAddCity").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeAddCity").getAsString()))
					setformfield(form, "clicoBen2TrusteeAddCity",
							ben2Details.get("trusteeAddCity").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("addCountry").getAsString()))
					setformfield(form, "clicoBen2AddCountry", ben2Details.get("addCountry").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("empAddCountry").getAsString()))
					setformfield(form, "clicoBen2EmpAddCountryDesc",
							ben2Details.get("empAddCountry").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeAddCountry").getAsString()))
					setformfield(form, "clicoBen2TrusteeAddCountryDesc",
							ben2Details.get("trusteeAddCountry").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("id").getAsString()))
					setformfield(form, "clicoBen2Id", ben2Details.get("id").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("nationality").getAsString()))
					setformfield(form, "clicoBen2NationalityDesc",
							ben2Details.get("nationality").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("relationInsured").getAsString()))
					setformfield(form, "clicoBen2RelationInsuredDesc",
							ben2Details.get("relationInsured").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("occupation").getAsString()))
					setformfield(form, "clicoBen2Occupation", ben2Details.get("occupation").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("placeBirth").getAsString())) //#MVT00082 Changes
					setformfield(form, "clicoBen2CountryBirthDesc",
							ben2Details.get("placeBirth").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeCountryBirth").getAsString()))
					setformfield(form, "clicoBen2TrusteeCountryBirthDesc",
							ben2Details.get("trusteeCountryBirth").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeName").getAsString()))
					setformfield(form, "clicoBen2TrusteeName",
							ben2Details.get("trusteeName").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeId").getAsString()))
					setformfield(form, "clicoBen2TrusteeId", ben2Details.get("trusteeId").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeNationality").getAsString()))
					setformfield(form, "clicoBen2TrusteeNationalityDesc",
							ben2Details.get("trusteeNationality").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("trusteeAdd").getAsString()))
					setformfield(form, "clicoBen2TrusteeAdd", ben2Details.get("trusteeAdd").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("empAdd").getAsString()))
					setformfield(form, "clicoBen2EmpAdd", ben2Details.get("empAdd").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("clicoBen2EmailID").getAsString()))
					setformfield(form, "clicoBen2Email", ben2Details.get("clicoBen2EmailID").getAsString());
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(ben2Details.get("gender").getAsString())) {
					if (i$outis.$iStrFuzzyMatch(ben2Details.get("gender").getAsString(), "M"))
						setformfield(form, "clicoBen2Gender_M", "X");

					else if (i$outis.$iStrFuzzyMatch(ben2Details.get("gender").getAsString(), "F"))
						setformfield(form, "clicoBen2Gender_F", "X");
				}
			} catch (Exception e) {
				

			}

			try {
				if (!i$outis.$iStrBlank(ben2Details.get("maritalStatus").getAsString())) {
					if (i$outis.$iStrFuzzyMatch(ben2Details.get("maritalStatus").getAsString(), "S"))
						setformfield(form, "clicoBen2MaritalStatus_S", "X");

					else if (i$outis.$iStrFuzzyMatch(ben2Details.get("maritalStatus").getAsString(), "M"))
						setformfield(form, "clicoBen2MaritalStatus_M", "X");

					else if (i$outis.$iStrFuzzyMatch(ben2Details.get("maritalStatus").getAsString(), "D"))
						setformfield(form, "clicoBen2MaritalStatus_D", "X");

					else if (i$outis.$iStrFuzzyMatch(ben2Details.get("maritalStatus").getAsString(), "P"))
						setformfield(form, "clicoBen2MaritalStatus_P", "X");

					else if (i$outis.$iStrFuzzyMatch(ben2Details.get("maritalStatus").getAsString(), "W"))
						setformfield(form, "clicoBen2MaritalStatus_W", "X");

					else if (i$outis.$iStrFuzzyMatch(ben2Details.get("maritalStatus").getAsString(), "C"))
						setformfield(form, "clicoBen2MaritalStatus_C", "X");

				}

			} catch (Exception e) {
				
			}
		}
        }catch(Exception e) {
		}
		
		try {
			if (ben1details.has("dob"))
				setformfield(form, "clicoBen1Dob", getClicoDateFormat(ben1details.get("dob").getAsString()));
		} catch (Exception e) {
			
		}
		
		try {
			if (jsonClicoDetails.has("clicoDob"))
				setformfield(form, "clicoDobs",
						getClicoDateFormat(jsonClicoDetails.get("clicoDob").getAsString()));//#SRP00036 changes
		} catch (Exception e) {
			
		}
		try {
			if (ben1details.has("trusteeDOB"))
				setformfield(form, "clicoBen1TrusteeDOB",
						getClicoDateFormat(ben1details.get("trusteeDOB").getAsString()));
		} catch (Exception e) {
			
		}
		
		try {
			if (ben1details.has("percentBenefits")) {
				if (!ben1details.get("percentBenefits").getAsString().equals(""))
					setformfield(form, "clicoBen1PercentBenefits",
							ben1details.get("percentBenefits").getAsString() + "%");
			}
		} catch (Exception e) {
			
		}

		try {
			try {
				if (!i$outis.$iStrBlank(jsonClicoDetails.get("clicoMobNo").getAsString()))
					setformfield(form, "clicoMobNo",
							createClicoMobNo(jsonClicoDetails.get("clicoMobNo").getAsString()));
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(jsonClicoDetails.get("clicoHomeNo").getAsString()))
					setformfield(form, "clicoHomeNo",
							createClicoMobNo(jsonClicoDetails.get("clicoHomeNo").getAsString()));
			} catch (Exception e) {
				
			}
			try {
				if (!i$outis.$iStrBlank(jsonClicoDetails.get("clicoEmpPhoneNo").getAsString()))
					setformfield(form, "clicoEmpPhoneNo",
							createClicoMobNo(jsonClicoDetails.get("clicoEmpPhoneNo").getAsString()));
			} catch (Exception e) {
				
			}

			
			try {
				if (!i$outis.$iStrBlank(ben1details.get("mobileNo").getAsString())) {
					// if
					// (!i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen2HomePhone").getAsString()))
					setformfield(form, "clicoBen1MobileNo",
							createClicoMobNo(ben1details.get("mobileNo").getAsString()));
					setformfield(form, "clicoBen1MobileNoExtension",
							ben1details.get("mobileNoExtension").getAsString());
					setformfield(form, "clicoBen1HomePhone",
							createClicoMobNo(ben1details.get("homePhone").getAsString()));

				}
			} catch (Exception e) {
				
			}
			try {

				if (!i$outis.$iStrBlank(ben1details.get("homePhone").getAsString())) {
					setformfield(form, "clicoBen1HomePhone",
							createClicoMobNo(ben1details.get("homePhone").getAsString()));
					setformfield(form, "clicoBen1HomePhoneExtension",
							ben1details.get("homePhoneExtension").getAsString());
				}
			} catch (Exception e) {
				
			}

			
			try {
				if (!i$outis.$iStrBlank(ben1details.get("workPhone").getAsString())) {
					setformfield(form, "clicoBen1WorkPhone",
							createClicoMobNo(ben1details.get("workPhone").getAsString()));
					setformfield(form, "clicoBen1WorkPhoneExtension",
							ben1details.get("workPhoneExtension").getAsString());

				}
			} catch (Exception e) {
				
			}

			

			try {
				if (!i$outis.$iStrBlank(ben1details.get("trusteeMobNo").getAsString())) {
					setformfield(form, "clicoBen1TrusteeMobNo",
							createClicoMobNo(ben1details.get("trusteeMobNo").getAsString()));
					setformfield(form, "clicoBen1TrusteeMobNoExtension",
							ben1details.get("trusteeMobNoExtension").getAsString());
				}
			} catch (Exception e) {
				
			}

			try {
				if (!i$outis.$iStrBlank(ben1details.get("trusteeHomePhone").getAsString())) {
					setformfield(form, "clicoBen1TrusteeHomePhone",
							createClicoMobNo(ben1details.get("trusteeHomePhone").getAsString()));
					setformfield(form, "clicoBen1TrusteeHomePhoneExtension",
							ben1details.get("trusteeHomePhoneExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
			
			try {
				if (!i$outis.$iStrBlank(ben1details.get("empFaxNo").getAsString())) {
					setformfield(form, "clicoBen1EmpFaxNo",
							createClicoMobNo(ben1details.get("empFaxNo").getAsString()));
					setformfield(form, "clicoBen1EmpFaxNoExtension",
							ben1details.get("empFaxNoExtension").getAsString());
				}
			} catch (Exception e) {
				
			}
		
			// ben details
			try {
				try {
					if (!i$outis.$iStrBlank(ben1details.get("firstName").getAsString()))
						setformfield(form, "clicoBen1FirstName", ben1details.get("firstName").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("middleName").getAsString()))
						setformfield(form, "clicoBen1MiddleName", ben1details.get("middleName").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("lastName").getAsString()))
						setformfield(form, "clicoBen1LastName", ben1details.get("lastName").getAsString());
				} catch (Exception e) {
					
				}
				
				try {
					if (!i$outis.$iStrBlank(ben1details.get("addCity").getAsString()))
						setformfield(form, "clicoBen1AddCity", ben1details.get("addCity").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("empAddCity").getAsString()))
						setformfield(form, "clicoBen1EmpAddCity", ben1details.get("empAddCity").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeAddCity").getAsString()))
						setformfield(form, "clicoBen1TrusteeAddCity",
								ben1details.get("trusteeAddCity").getAsString());
				} catch (Exception e) {
					
				}
				
				try {
					if (!i$outis.$iStrBlank(ben1details.get("addCountry").getAsString()))
						setformfield(form, "clicoBen1AddCountry", ben1details.get("addCountry").getAsString());
				} catch (Exception e) {
					

				}
				
				try {
					if (!i$outis.$iStrBlank(additionalDetl.get("countryOfBirth").getAsString()))
						setformfield(form, "clicoCountryBirth", additionalDetl.get("countryOfBirth").getAsString());
				} catch (Exception e) {
					

				}
				
				try {
					if (!i$outis.$iStrBlank(additionalDetl.get("nationality").getAsString()))
						setformfield(form, "clicoNationality", additionalDetl.get("nationality").getAsString());
				} catch (Exception e) {
					

				}
				
				try {
					if (!i$outis.$iStrBlank(ben1details.get("empAddCountry").getAsString()))
						setformfield(form, "clicoBen1EmpAddCountryDesc",
								ben1details.get("empAddCountry").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeAddCountry").getAsString()))
						setformfield(form, "clicoBen1TrusteeAddCountryDesc",
								ben1details.get("trusteeAddCountry").getAsString());
				} catch (Exception e) {
					
				}

			
				try {
					if (!i$outis.$iStrBlank(ben1details.get("id").getAsString()))
						setformfield(form, "clicoBen1Id", ben1details.get("id").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("nationality").getAsString()))
						setformfield(form, "clicoBen1NationalityDesc",
								ben1details.get("nationality").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("relationInsured").getAsString()))
						setformfield(form, "clicoBen1RelationInsuredDesc",
								ben1details.get("relationInsured").getAsString());
				} catch (Exception e) {
					
				}
				

				try {
					if (!i$outis.$iStrBlank(ben1details.get("occupation").getAsString()))
						setformfield(form, "clicoBen1Occupation", ben1details.get("occupation").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("placeBirth").getAsString())) //#MVT00082 Changes
						setformfield(form, "clicoBen1CountryBirthDesc",
								ben1details.get("placeBirth").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeCountryBirth").getAsString()))
						setformfield(form, "clicoBen1TrusteeCountryBirthDesc",
								ben1details.get("trusteeCountryBirth").getAsString());
				} catch (Exception e) {
					
				}

				
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeName").getAsString()))
						setformfield(form, "clicoBen1TrusteeName",
								ben1details.get("trusteeName").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeId").getAsString()))
						setformfield(form, "clicoBen1TrusteeId", ben1details.get("trusteeId").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeNationality").getAsString()))
						setformfield(form, "clicoBen1TrusteeNationalityDesc",
								ben1details.get("trusteeNationality").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("trusteeAdd").getAsString()))
						setformfield(form, "clicoBen1TrusteeAdd", ben1details.get("trusteeAdd").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (!i$outis.$iStrBlank(ben1details.get("empAdd").getAsString()))
						setformfield(form, "clicoBen1EmpAdd", ben1details.get("empAdd").getAsString());
				} catch (Exception e) {
					
				}
				
				try {
					if (!i$outis.$iStrBlank(ben1details.get("clicoBen1EmailID").getAsString()))
						setformfield(form, "clicoBen1Email", ben1details.get("clicoBen1EmailID").getAsString());

				} catch (Exception e) {
					
				}

			} catch (Exception e) {
				
			}

			try {
				if (!i$outis.$iStrBlank(ben1details.get("maritalStatus").getAsString())) {
					if (i$outis.$iStrFuzzyMatch(ben1details.get("maritalStatus").getAsString(), "S"))
						setformfield(form, "clicoBen1MaritalStatus_S", "X");

					else if (i$outis.$iStrFuzzyMatch(ben1details.get("maritalStatus").getAsString(), "M"))
						setformfield(form, "clicoBen1MaritalStatus_M", "X");

					else if (i$outis.$iStrFuzzyMatch(ben1details.get("maritalStatus").getAsString(), "D"))
						setformfield(form, "clicoBen1MaritalStatus_D", "X");

					else if (i$outis.$iStrFuzzyMatch(ben1details.get("maritalStatus").getAsString(), "P"))
						setformfield(form, "clicoBen1MaritalStatus_P", "X");

					else if (i$outis.$iStrFuzzyMatch(ben1details.get("maritalStatus").getAsString(), "W"))
						setformfield(form, "clicoBen1MaritalStatus_W", "X");

					else if (i$outis.$iStrFuzzyMatch(ben1details.get("maritalStatus").getAsString(), "C"))
						setformfield(form, "clicoBen1MaritalStatus_C", "X");

				}

			} catch (Exception e) {
				
			}

			try {
				if (!i$outis.$iStrBlank(ben1details.get("gender").getAsString())) {
					if (i$outis.$iStrFuzzyMatch(ben1details.get("gender").getAsString(), "M"))
						setformfield(form, "clicoBen1Gender_M", "X");

					if (i$outis.$iStrFuzzyMatch(ben1details.get("gender").getAsString(), "F"))
						setformfield(form, "clicoBen1Gender_F", "X");
				}
			} catch (Exception e) {
				

			}

		} catch (Exception e) {

		}
		// #PKY00008 ends
	
	}//madhura
	public void newPdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp)throws IOException, DocumentException {
		
		if (pdfName.equalsIgnoreCase("member_onboarding_re_kyc_lite")) {
			
			JsonObject changeValue = jsonObject.get("changedVals").getAsJsonObject();
			JsonObject personalInfo = jsonObject.get("personalInfo").getAsJsonObject();
			try {
				form.setField("applicationId", changeValue.get("applicationId").getAsString());
			}catch(Exception e) {}
			try {
				if (jsonObject.has("changedVals")) {
					if (jsonObject.getAsJsonObject("changedVals").has("CIF")) {
						form.setField("CIF", jsonObject.getAsJsonObject("changedVals").get("CIF").getAsString());
					}
				}
			} catch (Exception e) {
				
			}
			try {
				if(personalInfo.has("firstName") && !i$outis.$iStrBlank(personalInfo.get("firstName").getAsString())) {
					setformfield(form, "firstNameO", personalInfo.get("firstName").getAsString());
				}
				if(personalInfo.has("middleName") && !i$outis.$iStrBlank(personalInfo.get("middleName").getAsString())) {
					setformfield(form, "middleNameO", personalInfo.get("middleName").getAsString());
				}
				if(personalInfo.has("lastName") && !i$outis.$iStrBlank(personalInfo.get("lastName").getAsString())) {
					setformfield(form, "lastNameO", personalInfo.get("lastName").getAsString());
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				if(changeValue.has("firstName") && !i$outis.$iStrBlank(changeValue.get("firstName").getAsString())) {
					setformfield(form, "firstName_1", changeValue.get("firstName").getAsString());
				}
				if(changeValue.has("middleName") && !i$outis.$iStrBlank(changeValue.get("middleName").getAsString())) {
					setformfield(form, "middleName_1", changeValue.get("middleName").getAsString());
				}
				if(changeValue.has("lastName") && !i$outis.$iStrBlank(changeValue.get("lastName").getAsString())) {
					setformfield(form, "lastName_1", changeValue.get("lastName").getAsString());
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				if(changeValue.has("dob") && !i$outis.$iStrBlank(changeValue.get("dob").getAsString())) {
					setformfield(form, "dob", changeValue.get("dob").getAsString());
				}
			}catch(Exception e) {}
			
			try {
				if(changeValue.has("emailId") && !i$outis.$iStrBlank(changeValue.get("emailId").getAsString())) {
					setformfield(form, "emailId", changeValue.get("emailId").getAsString());
				}
			}catch(Exception e) {
			}
			try {
				if(changeValue.has("officialEmailId") && !i$outis.$iStrBlank(changeValue.get("officialEmailId").getAsString())) {
					setformfield(form, "officialEmailId", changeValue.get("officialEmailId").getAsString());
				}
			}catch(Exception e) {
				
			}
			try {
				StringBuilder homeNo = new StringBuilder();
				try {
					if (changeValue.has("homephoneExtension") && !changeValue.get("homephoneExtension").getAsString().isEmpty()) {
						homeNo.append("(");
						homeNo.append(changeValue.get("homephoneExtension").getAsString());
						homeNo.append(")");
						}
				}catch(Exception e) {}
				try {
					if (changeValue.has("homePhoneNumber") && !changeValue.get("homePhoneNumber").getAsString().isEmpty()) {
						homeNo.append(changeValue.get("homePhoneNumber").getAsString());
					}
				}catch(Exception e) {}
					setformfield(form, "homePhoneNumber", homeNo.toString());
			}catch(Exception e) {}
			
			try {
				StringBuilder mobileNo = new StringBuilder();
				try {
					if (changeValue.has("mobileISD") && !changeValue.get("mobileISD").getAsString().isEmpty()) {
						mobileNo.append("(");
						mobileNo.append(changeValue.get("mobileISD").getAsString());
						mobileNo.append(")");
						}
				}catch(Exception e) {}
				try {
					if (changeValue.has("mobileNumber") && !changeValue.get("mobileNumber").getAsString().isEmpty()) {
						mobileNo.append(changeValue.get("mobileNumber").getAsString());
					}
				}catch(Exception e) {}
					setformfield(form, "mobileNumber", mobileNo.toString());
			}catch(Exception e) {}
			try {
				StringBuilder workNo = new StringBuilder();
				try {
					if (changeValue.has("employerExtension") && !changeValue.get("employerExtension").getAsString().isEmpty()) {
						workNo.append("(");
						workNo.append(changeValue.get("employerExtension").getAsString());
						workNo.append(")");
						}
				}catch(Exception e) {}
				try {
					if (changeValue.has("employerWorkPhoneNumber") && !changeValue.get("employerWorkPhoneNumber").getAsString().isEmpty()) {
						workNo.append(changeValue.get("employerWorkPhoneNumber").getAsString());
					}
				}catch(Exception e) {}
					setformfield(form, "employerWorkPhoneNumber", workNo.toString());
			}catch(Exception e) {}
//			try {
//			if (changeValue.has("employmentMode")) {
//				try {
//				if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "N") || i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "R") )
//					setformfield(form, "employmentMode_R", "X");
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "F"))
//					setformfield(form, "employmentMode_F", "X");								
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "T"))
//					setformfield(form, "employmentMode_T", "X");
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "O"))
//					setformfield(form, "employmentMode_O", "X");
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "P"))
//					setformfield(form, "employmentMode_P", "X");
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "S"))
//					setformfield(form, "employmentMode_S", "X");
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("employmentMode").getAsString(), "U"))
//					setformfield(form, "employmentMode_U", "X");
//				}catch(Exception e) {}
//			}
//			}catch(Exception e) {}
			try {
				if (changeValue.has("joiningDate")) 
					setformfield(form, "joiningDate", changeValue.get("joiningDate").getAsString());
			}catch(Exception e) {}
//			try {
//			if (changeValue != null && changeValue.has("sectorEmployed")) {
//				if (i$outis.$iStrFuzzyMatch(changeValue.get("sectorEmployed").getAsString(), "PRISEC")) {
//					setformfield(form, "employmentType_PRISEC",changeValue.get("employmentTypeDesc").getAsString());
//				} 
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("sectorEmployed").getAsString(),"PUBSEC")) {
//					setformfield(form, "employmentType_PUBSEC",changeValue.get("employmentTypeDesc").getAsString());
//				} 
//				else if (i$outis.$iStrFuzzyMatch(changeValue.get("sectorEmployed").getAsString(),"SLFEMP")) {
//					setformfield(form, "employmentType_SLFEMP",changeValue.get("employmentTypeDesc").getAsString());
//				} 
//				else {
//					setformfield(form, "employmentType_OTHERS",changeValue.get("employmentTypeDesc").getAsString());
//				}
//			}
//			}catch(Exception e) {}
			try {
			if (changeValue.get("salary").getAsInt()< 5000) {
				setformfield(form, "avgMonthlyIncome_0-5", "X");
			} 
			else if (changeValue.get("salary").getAsInt()>= 5000 && changeValue.get("salary").getAsInt()<= 12000) {
				setformfield(form, "avgMonthlyIncome_5-12_1", "X");
			} 
			else if (changeValue.get("salary").getAsInt()> 12000 && changeValue.get("salary").getAsInt()<= 17000) {
				setformfield(form, "avgMonthlyIncome_12-17_1", "X");
			} 
			else if (changeValue.get("salary").getAsInt()> 17000 && changeValue.get("salary").getAsInt()<= 22000) {
				setformfield(form, "avgMonthlyIncome_17-22_1", "X");
			} 
			else if (changeValue.get("salary").getAsInt()> 22000 && changeValue.get("salary").getAsInt()<= 27000) {
				setformfield(form, "avgMonthlyIncome_22-27_1", "X");
			} 
			else if (changeValue.get("salary").getAsInt()> 27000) {
				setformfield(form, "avgMonthlyIncome_>27_1", "X");
			}
			}catch(Exception e) {}
			try {
				if(changeValue.has("occupation")) 
					setformfield(form, "occupation", changeValue.get("occupation").getAsString());
			}catch(Exception e) {}
			try {
				if(changeValue.has("employeeNo")) 
					setformfield(form, "employeeNo", changeValue.get("employeeNo").getAsString());
			}catch(Exception e) {}
			try {
				if (i$outis.$iStrFuzzyMatch(changeValue.get("employer").getAsString(), "OTHER")) {
					setformfield(form, "employerDesc", changeValue.get("employerOther").getAsString());
				} else {
					setformfield(form, "employerDesc", changeValue.get("employerDesc").getAsString());
				}
			}catch(Exception e) {}
			try {
				StringBuilder adress = new StringBuilder();
				try {
				if (changeValue.has("employerCity") && !changeValue.get("employerCity").getAsString().isEmpty()) {
						adress.append(changeValue.get("employerCity").getAsString());
					}
				}catch(Exception e) {}
				try {
				if (changeValue.has("employerCountryDesc") && !changeValue.get("employerCountryDesc").getAsString().isEmpty()) {
					adress.append(", ");
					adress.append(changeValue.get("employerCountryDesc").getAsString());
				}
				}catch(Exception e) {}
				setformfield(form, "empAdd1", adress.toString());
			}catch(Exception e) {}
			try {
				StringBuilder permAdress = new StringBuilder();
				try {
				if (changeValue.has("permAddLine1") && !changeValue.get("permAddLine1").getAsString().isEmpty()) {
					permAdress.append(changeValue.get("permAddLine1").getAsString());
				}
				}catch(Exception e) {}
				try {
				if (changeValue.has("permAddLine2") && !changeValue.get("permAddLine2").getAsString().isEmpty()) {
					permAdress.append(", ");
					permAdress.append(changeValue.get("permAddLine2").getAsString());
				}
				}catch(Exception e) {}
				setformfield(form, "permAddLine_1", permAdress.toString());
			}catch(Exception e) {}
			try {
				StringBuilder permAdressCity = new StringBuilder();
				try {
				if (changeValue.has("permAddCity") && !changeValue.get("permAddCity").getAsString().isEmpty()) {
					permAdressCity.append(changeValue.get("permAddCity").getAsString());
				}
				}catch(Exception e) {}
				try {
				if (changeValue.has("permAddCountryDesc") && !changeValue.get("permAddCountryDesc").getAsString().isEmpty()) {
					permAdressCity.append(", ");
					permAdressCity.append(changeValue.get("permAddCountryDesc").getAsString());
				}
				}catch(Exception e) {}
				setformfield(form, "permAddLine_2", permAdressCity.toString());
			}catch(Exception e) {}
			try {
				StringBuilder mailAdress = new StringBuilder();
				try {
				if (changeValue.has("mailAddLine1") && !changeValue.get("mailAddLine1").getAsString().isEmpty()) {
					mailAdress.append(changeValue.get("mailAddLine1").getAsString());
				}
				}catch(Exception e) {}
				try {
				if (changeValue.has("mailAddLine2") && !changeValue.get("mailAddLine2").getAsString().isEmpty()) {
					mailAdress.append(", ");
					mailAdress.append(changeValue.get("mailAddLine2").getAsString());
				}
				}catch(Exception e) {}
				setformfield(form, "mailAddLine_3", mailAdress.toString());
			}catch(Exception e) {}
			try {
				StringBuilder mailAdressCity = new StringBuilder();
				try {
				if (changeValue.has("mailAddCity") && !changeValue.get("mailAddCity").getAsString().isEmpty()) {
					mailAdressCity.append(changeValue.get("mailAddCity").getAsString());
				}
				}catch(Exception e) {}
				try {
				if (changeValue.has("mailAddCountryDesc") && !changeValue.get("mailAddCountryDesc").getAsString().isEmpty()) {
					mailAdressCity.append(", ");
					mailAdressCity.append(changeValue.get("mailAddCountryDesc").getAsString());
				}
				}catch(Exception e) {}
				setformfield(form, "mailAddLine_4", mailAdressCity.toString());
			}catch(Exception e) {}
			try {
				if (changeValue.has("birthCountryDesc") && !changeValue.get("birthCountryDesc").getAsString().isEmpty()) 
					setformfield(form, "birthCountryDesc", changeValue.get("birthCountryDesc").getAsString());
			}catch(Exception e) {}
			try {
				if (changeValue.has("nationality") && !changeValue.get("nationality").getAsString().isEmpty()) 
					setformfield(form, "nationalityDesc", changeValue.get("nationality").getAsString());
			}catch(Exception e) {}
			try {
			if (i$outis.$iStrFuzzyMatch(changeValue.get("maritalStatus").getAsString(), "S"))
				setformfield(form, "maritalStatus_S", "X");

			else if (i$outis.$iStrFuzzyMatch(changeValue.get("maritalStatus").getAsString(), "M"))
				setformfield(form, "maritalStatus_M", "X");

			else if (i$outis.$iStrFuzzyMatch(changeValue.get("maritalStatus").getAsString(), "D"))
				setformfield(form, "maritalStatus_D", "X");

			else if (i$outis.$iStrFuzzyMatch(changeValue.get("maritalStatus").getAsString(), "P"))
				setformfield(form, "maritalStatus_P", "X");

			else if (i$outis.$iStrFuzzyMatch(changeValue.get("maritalStatus").getAsString(), "W"))
				setformfield(form, "maritalStatus_E", "X");

			else if (i$outis.$iStrFuzzyMatch(changeValue.get("maritalStatus").getAsString(), "C"))
				setformfield(form, "maritalStatus_C", "X");
			}catch(Exception e) {}
			
			try {
				if (changeValue.has("nationalId")) {
					setformfield(form, "nationalId",changeValue.get("nationalId").getAsString());
				}
				if(changeValue.has("pinIssDate")){
					setformfield(form, "issueDateNationalId",changeValue.get("pinIssDate").getAsString());
				}
				if(changeValue.has("pinExpDate")){
					setformfield(form, "expiryDateNationalId",changeValue.get("pinExpDate").getAsString());
				}
				if(changeValue.has("pinIssCntry")){
					setformfield(form, "cntryOfIssNationalId",changeValue.get("pinIssCntry").getAsString());
				}
			}catch(Exception e) {}
			try {
				if (changeValue.has("driversPermitId")) {
					setformfield(form, "driversPermit",changeValue.get("driversPermitId").getAsString());
				}
				if(changeValue.has("dpIssDate")){
					setformfield(form, "issueDateDriversPer",changeValue.get("dpIssDate").getAsString());
				}
				if(changeValue.has("dpExpDate")){
					setformfield(form, "expiryDateDriversPer",changeValue.get("dpExpDate").getAsString());
				}
				if(changeValue.has("dpIssuCntry")){
					setformfield(form, "cntryOfIssDriversPer",changeValue.get("dpIssuCntry").getAsString());
				}
			}catch(Exception e) {}
			try {
				if (changeValue.has("passportId")) {
					setformfield(form, "Passport",changeValue.get("passportId").getAsString());
				}
				if(changeValue.has("passportIssDate")){
					setformfield(form, "issueDatePassport",changeValue.get("passportIssDate").getAsString());
				}
				if(changeValue.has("passportExpDate")){
					setformfield(form, "expiryDatePassport",changeValue.get("passportExpDate").getAsString());
				}
				if(changeValue.has("passportIssCntry")){
					setformfield(form, "cntryOfIssPassport",changeValue.get("passportIssCntry").getAsString());
				}
			}catch(Exception e) {}
			try {
				if (changeValue.has("placeOfBirth")) {
					setformfield(form, "placeOfBirth",changeValue.get("placeOfBirth").getAsString());
				}
			}catch(Exception e) {}
		
		}		
	}
	//MSA00001 ends
	private void pdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp , String base64)throws IOException, DocumentException {

		try {

			if (pdfName.equalsIgnoreCase("member_onboarding_re_kyc_lite")) {
				newPdfValueSetter(jsonObject, pdfName, form, stamp);
				
			}  if (pdfName.equalsIgnoreCase("clico_one")) {
				clicoMapping(jsonObject, pdfName, form, stamp);
			}if (pdfName.equalsIgnoreCase("lincu_pdf_file")) {

				JsonObject ocrObject = jsonObject.get("personalInfo").getAsJsonObject();
				JsonObject contactObject = jsonObject.get("contactDetails").getAsJsonObject();
				JsonObject additionalObject = jsonObject.get("additionalDetails").getAsJsonObject();
				JsonObject employmentObject = jsonObject.get("employment").getAsJsonObject();
				JsonObject factaDetails = jsonObject.get("fatcaDeclaration").getAsJsonObject();
				// #PKY00006 starts
				JsonObject document = jsonObject.get("documents").getAsJsonObject();
				JsonArray docArray = document.get("documentDetails").getAsJsonArray();
				JsonObject docDetails = docArray.get(0).getAsJsonObject();
				JsonArray sideArray = docDetails.get("sides").getAsJsonArray();
				JsonObject sideDetails = sideArray.get(0).getAsJsonObject();
				String pp = sideDetails.get("FileUrlToken").getAsString();

				try {
//				JsonObject filterSide = new JsonObject();
//				GridFSDownloadStream downloadStream = null;
//				ByteArrayOutputStream outputStream = null;
//				MongoDatabase db = MongoConfig.getMongoDB();
//				GridFSBucket grid$FS = GridFSBuckets.create(db);
//
//				filterSide.addProperty("FileUrlToken", pp);
//				JsonObject icorMDmsLogger = db$Ctrl.db$GetRow("ICOR_M_DMS_LOGGER", filterSide);
//				if (!i$outis.$isNull(icorMDmsLogger)) {
//
//					ObjectId fileId = new ObjectId(icorMDmsLogger.get("FileUrlId").getAsString());
//
//					downloadStream = grid$FS.openDownloadStream(fileId);
//					outputStream = new ByteArrayOutputStream();
//					int data = downloadStream.read();
//					while (data >= 0) {
//						outputStream.write((char) data);
//						data = downloadStream.read();
//					}
//					String baseString = new String(outputStream.toByteArray());
//					//Applying image to pdf
//	                addImage(stamp, form, "Add Photo",baseString);
//					
//
//				}
					addImage(stamp, form, "Add Photo",base64);
					try {
						  if (additionalObject.has("doYouHaveFcbAccount") && !i$outis.$iStrBlank(additionalObject.get("doYouHaveFcbAccount").getAsString())) {
							  if (i$outis.$iStrFuzzyMatch(additionalObject.get("doYouHaveFcbAccount").getAsString(), "Y")) {
								  setformfieldS(form, "Do you have an FCB Account Yes", "Yes");
							      setformfield(form, "IfYes", additionalObject.get("cif").getAsString());
							  }else if(i$outis.$iStrFuzzyMatch(additionalObject.get("doYouHaveFcbAccount").getAsString(), "N")) {
								  setformfieldS(form, "Do you have an FCB Account No", "Yes");
							  }
						  }
					  }catch(Exception e) {
					  }
					try {        
						  {
							if (i$outis.$iStrFuzzyMatch(additionalObject.get("majorityShareholding").getAsString(), "true"))
								setformfieldS(form, "FcbNo", "Yes");
							else if (i$outis.$iStrFuzzyMatch(additionalObject.get("minorityShareholding").getAsString(), "true"))
								setformfieldS(form, "FcbMinority", "Yes");
							else if (i$outis.$iStrFuzzyMatch(additionalObject.get("notShareholder").getAsString(), "true"))
								setformfieldS(form, "NotaShareHolder", "Yes");
						}
					}catch (Exception e) {
						
					} 
					 try {
						  if (contactObject.has("permanentAddressHomeOwnership") && !i$outis.$iStrBlank(contactObject.get("permanentAddressHomeOwnership").getAsString())) {
							  if (i$outis.$iStrFuzzyMatch(contactObject.get("permanentAddressHomeOwnership").getAsString(), "Own")) {
								  setformfieldS(form, "PHomeOwnership", "Yes");
							  }else if(i$outis.$iStrFuzzyMatch(contactObject.get("permanentAddressHomeOwnership").getAsString(), "Rent")) {
								  setformfieldS(form, "PHomeOwnershipRent", "Yes");
							  }else if(i$outis.$iStrFuzzyMatch(contactObject.get("permanentAddressHomeOwnership").getAsString(), "Relative")) {
								  setformfieldS(form, "PHomeOwnership_livewith", "Yes");
							  }else if(i$outis.$iStrFuzzyMatch(contactObject.get("permanentAddressHomeOwnership").getAsString(), "Sumbet")) {
								  setformfieldS(form, "PHomeOwnershipSublet", "Yes");
							  }
						  }
					  }catch(Exception e) {
					  }
//					if (jsonObject.has("memberPrfPic")) {
//						addImage(stamp, form, "Add Photo", jsonObject.get("memberPrfPic").getAsString());
//					}
				} catch (Exception e) {
					
				}

				// #PKY00006 ends

//				try {
//					if (factaDetails.has("fatcaCountry")) {
//						setformfield(form, "Citizenship Country 1", factaDetails.get("fatcaCountry").getAsString());
//					}
//				} catch (Exception e) {
//					
//				}
				try {//#SRP00032 Changes starts
					if (factaDetails.has("fatcaCountryOther1")) {
						setformfield(form, "Citizenship Country 1",
								factaDetails.get("fatcaCountryOther1").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (factaDetails.has("fatcaCountryOther2")) {
						setformfield(form, "Citizenship Country 2",
								factaDetails.get("fatcaCountryOther2").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (factaDetails.has("fatcaCountryOther3")) {
						setformfield(form, "Citizenship Country 3",
								factaDetails.get("fatcaCountryOther3").getAsString());
					}
				} catch (Exception e) {
					
				}//#SRP00032 Changes Ends
				//#SRP00033 Starts
				try {
					  if (factaDetails.has("ssnNo1") && !i$outis.$iStrBlank(factaDetails.get("ssnNo1").getAsString())) {
						  String ssnNo=factaDetails.get("ssnNo1").getAsString();
						  String ssnNo1=ssnNo.substring(0, 3);
						  setformfieldS(form, "SSN No", ssnNo1);
						  String ssnNo2=ssnNo.substring(3, 5);
						  setformfieldS(form, "SSN No 2", ssnNo2);
						  String ssnNo3=ssnNo.substring(5, 9);
						  setformfieldS(form, "SSN No 3", ssnNo3);
					  }
				  }catch(Exception e) {
				  }
				//#SRP00033 Ends
				//#SRP00035 Starts
				try {
					if (i$outis.$iStrFuzzyMatch(factaDetails.get("isGranteePOA").getAsString(), "Y")) {
						setformfieldS(form, "powerAttorney_Yes", "Yes");
					} else if (i$outis.$iStrFuzzyMatch(factaDetails.get("isGranteePOA").getAsString(),
							"N")) {
						setformfieldS(form, "powerAttorney_No", "Yes");
					}
				} catch (Exception e) {
					
				}
				try {
					if (i$outis.$iStrFuzzyMatch(factaDetails.get("isCitizenOfOtherCountry").getAsString(), "Y")) {
						setformfieldS(form, "CitizenShipCountry_Yes", "Yes");
					} else if (i$outis.$iStrFuzzyMatch(factaDetails.get("isCitizenOfOtherCountry").getAsString(),
							"N")) {
						setformfieldS(form, "CitizenShipCountry_No", "Yes");
					}
				} catch (Exception e) {
					
				}
				//#SRP00035 Ends
				try {
					if (jsonObject.has("applicationId")) {
						setformfield(form, "Application no", jsonObject.get("applicationId").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					setformfield(form, "Date", i$outis.customerDate(new Date()));

				} catch (Exception e) {
					
				}
				try {
					setformfield(form, "Credit Union", "TECU CREDIT UNION");

				} catch (Exception e) {
					
				}
				try {
					if (contactObject.has("branch")) {
						setformfield(form, "Branch", contactObject.get("branch").getAsString());
					}
				} catch (Exception e) {
					
				}
//				try {
//					setformfield(form, "Credit Union Member No", "");//#SRP00031 changes start
//				} catch (Exception e) {
//					
//				}
//				try {
//					if (false) {
//						setformfield(form, "Do you have an FCB Account", "Y");
//
//					} else {
//						setformfield(form, "Do you have an FCB Account", "N");
//
//					}
//				} catch (Exception e) {
//					
//				}//#SRP00031 changes start

				try {
					try {
						if (i$outis.$iStrFuzzyMatch(ocrObject.get("priDocName").getAsString(),
								IConstants.I_NATIONALID.toString())) {
							setformfield(form, "Electorial ID", ocrObject.get("priDocId").getAsString());
						} else if (i$outis.$iStrFuzzyMatch(ocrObject.get("priDocName").getAsString(),
								IConstants.I_PASSPORT.toString())) {
							setformfield(form, "Passport", ocrObject.get("priDocId").getAsString());
						} else if (i$outis.$iStrFuzzyMatch(ocrObject.get("priDocName").getAsString(),
								IConstants.I_DRIVERSPERMIT.toString())) {
							setformfield(form, "Drivers Permit", ocrObject.get("priDocId").getAsString());
						}
					} catch (Exception e) {
						
					}

					try {
						if (i$outis.$iStrFuzzyMatch(ocrObject.get("secDocName").getAsString(),
								IConstants.I_DRIVERSPERMIT.toString())) {
							setformfield(form, "Drivers Permit", ocrObject.get("secDocId").getAsString());
						} else if (i$outis.$iStrFuzzyMatch(ocrObject.get("secDocName").getAsString(),
								IConstants.I_PASSPORT.toString())) {
							setformfield(form, "Passport", ocrObject.get("secDocId").getAsString());
						} else if (i$outis.$iStrFuzzyMatch(ocrObject.get("secDocName").getAsString(),
								IConstants.I_NATIONALID.toString())) {
							setformfield(form, "Electorial ID", ocrObject.get("secDocId").getAsString());
						}
					} catch (Exception e) {
						
					}
				} catch (Exception e) {
					
				}

				try {
					setformfield(form, "Prefix", ocrObject.get("prefix").getAsString());

				} catch (Exception e) {
					
				}
				try { // #MVT00088 Changes starts
					if (ocrObject.has("firstName")) {
						setformfield(form, "First Name", ocrObject.get("firstName").getAsString().replaceFirst("^ *", ""));
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("middleName")) {
						setformfield(form, "Middle Name", ocrObject.get("middleName").getAsString().replaceFirst("^ *", ""));
					}

				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("lastName")) {
						setformfield(form, "Last Name", ocrObject.get("lastName").getAsString().replaceFirst("^ *", ""));
					}// #MVT00088 Changes ends

				} catch (Exception e) {
					
				}
				try {
					if (additionalObject.has("motherMaidenName")) {
						setformfield(form, "Mothers Maiden Name",
								additionalObject.get("motherMaidenName").getAsString());
					}
				} catch (Exception e) {
					
				}
				// #PKY00006 starts

				try {
					if (additionalObject.has("numberOfDependents"))
						setformfield(form, "Number of Dependent",
								additionalObject.get("numberOfDependents").getAsString());

				} catch (Exception e) {
					
				}
				// #PKY00006 ends

				try {
					// if (ocrObject.get("gender").getAsString().equalsIgnoreCase("Male")) {
					setformfield(form, "Sex", ocrObject.get("gender").getAsString());
					/*
					 * } else { setformfield(form, "Sex", "F"); }
					 */
				} catch (Exception e) {
					
				}
				try {
					if (additionalObject.has("maritalStatusDesc")) { //#SRP00032 changes
						setformfield(form, "Marital Status", additionalObject.get("maritalStatusDesc").getAsString());
					}

				} catch (Exception e) {
					
				}
				try {
					if (contactObject.has("emailId")) {
						setformfield(form, "Email", contactObject.get("emailId").getAsString());
					}

				} catch (Exception e) {
					
				}
				try { // #MVT00001 changes starts
					if (ocrObject.has("dob") && !i$outis.$iStrBlank(ocrObject.get("dob").getAsString())) {
						String[] DOB = getClicoDateFormat(ocrObject.get("dob").getAsString()).split("/");
						String year = DOB[2];
						String month = DOB[0];
						String day = DOB[1];
						String date = new StringBuilder(day + "-").append(month).append("-" + year).toString();
						setformfieldS(form, "Date of Birth", date);		
					}
				} catch (Exception e) {

				}	//// #MVT00001 changes ends
				try {
					if (contactObject.has("mobileISD") && contactObject.has("mobileNumber")) {
						setformfield(form, "Mobile Phone", contactObject.get("mobileISD").getAsString()
								+ contactObject.get("mobileNumber").getAsString());
					}

				} catch (Exception e) {
					
				}
				try {
					if (additionalObject.has("homePhoneNumber")) {
						setformfield(form, "Home Phone", additionalObject.get("homePhoneNumber").getAsString());
					}
					//
				} catch (Exception e) {
					
				}				
				try {
					if (additionalObject.has("nationality")) {
						setformfield(form, "Nationality", additionalObject.get("nationality").getAsString());
					}
					//
				} catch (Exception e) {
					
				}
				
				try {
					if (additionalObject.has("countryOfBirth")) {
						setformfield(form, "Country of birth", additionalObject.get("countryOfBirth").getAsString());
					}
					//
				} catch (Exception e) {
					
				}
				
				try {
					if (additionalObject.has("faxNumber")) {
						setformfield(form, "Fax Number", additionalObject.get("faxNumber").getAsString());

					}
				} catch (Exception e) {
					
				}
				try {
					if (additionalObject.has("educationCode")) {	//#MVT00002 Changes starts
						setformfield(form, "Education Code", additionalObject.get("educationCodeDesc").getAsString());	//#MVT00002 Changes ends
					}

				} catch (Exception e) {
					
				}
				try {
					if (additionalObject.has("shareHolderCode")) {
						setformfield(form, "Share Holder Code", additionalObject.get("shareHolderCode").getAsString());
					}
					setformfield(form, "BIR", "");

				} catch (Exception e) {
					
				}
				try {
					try {
						if (ocrObject.has("priDocName")) {
							if (ocrObject.get("priDocName").getAsString()
									.equalsIgnoreCase(IConstants.I_NATIONALID.toString())) {
								if (jsonObject.has("priDocId")) {
									setformfield(form, "National ID", jsonObject.get("priDocId").getAsString());
								}
							} else if (ocrObject.get("priDocName").getAsString()
									.equalsIgnoreCase(IConstants.I_DRIVERSPERMIT.toString())) {
								if (jsonObject.has("priDocId")) {
									setformfield(form, "Drivers Permit", jsonObject.get("priDocId").getAsString());
								}
							} else if (ocrObject.get("priDocName").getAsString()
									.equalsIgnoreCase(IConstants.I_PASSPORT.toString())) {
								if (jsonObject.has("priDocId")) {
									setformfield(form, "Passport", jsonObject.get("priDocId").getAsString());
								}
							}
						}
					} catch (Exception e) {
						
					}
					try {
						if (ocrObject.has("secDocName")) {
							if (ocrObject.get("secDocName").getAsString()
									.equalsIgnoreCase(IConstants.I_NATIONALID.toString())) {
								if (jsonObject.has("secDocId")) {
									setformfield(form, "National ID", jsonObject.get("secDocId").getAsString());
								}
							} else if (ocrObject.get("secDocName").getAsString()
									.equalsIgnoreCase(IConstants.I_DRIVERSPERMIT.toString())) {
								if (jsonObject.has("secDocId")) {
									setformfield(form, "Drivers Permit", jsonObject.get("secDocId").getAsString());
								}
							} else if (ocrObject.get("secDocName").getAsString()
									.equalsIgnoreCase(IConstants.I_PASSPORT.toString())) {
								if (jsonObject.has("secDocId")) {
									setformfield(form, "Passport", jsonObject.get("secDocId").getAsString());
								}
							}
						}
					} catch (Exception e) {
						
					}
				} catch (Exception e) {
					
				}
				try {
					if (additionalObject.has("homeOwnerShip")) {
						if (additionalObject.get("homeOwnerShip").getAsString().equalsIgnoreCase("Own")) {
							setformfield(form, "Home Ownership", "Own");
						} else if (additionalObject.get("homeOwnerShip").getAsString().equalsIgnoreCase("Rent")) {
							setformfield(form, "Home Ownership", "Rent");

						} else if (additionalObject.get("homeOwnerShip").getAsString().equalsIgnoreCase("Sublet")) {
							setformfield(form, "Home Ownership", "Sublet");
						} else {
							setformfield(form, "Home Ownership", "Live with Relatives");
						}
					}
				} catch (Exception e) {
					
				}
//				try {
//					if (ocrObject.has("permAddLine1")) {
//						StringBuilder strBldrPermAdd = new StringBuilder(ocrObject.get("permAddLine1").getAsString());
//						try {
//							if (ocrObject.has("permAddLine2")
//									&& !i$outis.$iStrBlank(ocrObject.get("permAddLine2").getAsString())) {
//								strBldrPermAdd.append(",");
//								strBldrPermAdd.append(ocrObject.get("permAddLine2").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
//						setformfield(form, "Permanent Add1", strBldrPermAdd.toString());
//					}
//				} catch (Exception e) {
//					
//				}
//				try {
//					if (ocrObject.has("permAddLine3")) {
//						StringBuilder strBldrPermAdd = new StringBuilder(ocrObject.get("permAddLine3").getAsString());
//						try {
//							if (ocrObject.has("permAddLine4")
//									&& !i$outis.$iStrBlank(ocrObject.get("permAddLine4").getAsString())) {
//								strBldrPermAdd.append(",");
//								strBldrPermAdd.append(ocrObject.get("permAddLine4").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
//						setformfield(form, "Permanent Add2", strBldrPermAdd.toString());
//					}
//				} catch (Exception e) {
//					
//				}
				
				try {
					if (ocrObject.has("permAddLine1")) {
						
						setformfield(form, "Permanent Add1", ocrObject.get("permAddLine1").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("permAddLine2")) {
						
						setformfield(form, "Permanent Add2", ocrObject.get("permAddLine2").getAsString());
					}
				} catch (Exception e) {
					
				}
				
				
				
				try {
					if (ocrObject.has("permAddCity")) {
						setformfield(form, "Permanent City", ocrObject.get("permAddCity").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("permAddState")) {
						setformfield(form, "Permanent State", ocrObject.get("permAddState").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("permAddStreetType")) {
						setformfield(form, "Permanent Street Type", ocrObject.get("permAddStreetType").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("permAddZipCode")) {
						setformfield(form, "Permanent Zip Code", ocrObject.get("permAddZipCode").getAsString());
					}

				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("permAddCountry")) {
						setformfield(form, "Permanent Country", ocrObject.get("permAddCountry").getAsString());
					}

				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("cbttResidence")) {
						setformfield(form, "CBTT Residence", ocrObject.get("cbttResidence").getAsString());
					}
				} catch (Exception e) {
					
				}
//				try {
//					if (ocrObject.has("mailAddLine1")) {
//						StringBuilder strBldrPermAdd = new StringBuilder(ocrObject.get("mailAddLine1").getAsString());
//						try {
//							if (ocrObject.has("mailAddLine2")
//									&& !i$outis.$iStrBlank(ocrObject.get("mailAddLine2").getAsString())) {
//								strBldrPermAdd.append(",");
//								strBldrPermAdd.append(ocrObject.get("mailAddLine2").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
//						setformfield(form, "Mailing Add1", strBldrPermAdd.toString());
//					}
//				} catch (Exception e) {
//					
//				}
//				try {
//					if (ocrObject.has("mailAddLine3")) {
//						StringBuilder strBldrPermAdd = new StringBuilder(ocrObject.get("mailAddLine3").getAsString());
//						try {
//							if (ocrObject.has("mailAddLine4")
//									&& !i$outis.$iStrBlank(ocrObject.get("mailAddLine4").getAsString())) {
//								strBldrPermAdd.append(",");
//								strBldrPermAdd.append(ocrObject.get("mailAddLine4").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
//						setformfield(form, "Mailing Add2", strBldrPermAdd.toString());
//					}
//
//				} catch (Exception e) {
//					
//				}
				
				try {
					if (ocrObject.has("mailAddLine1")) {
						
						setformfield(form, "Mailing Add1", ocrObject.get("mailAddLine1").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("mailAddLine2")) {
						
						setformfield(form, "Mailing Add2", ocrObject.get("mailAddLine2").getAsString());
					}
				} catch (Exception e) {
					
				}
				
				
				try {
					if (ocrObject.has("mailAddCity")) {
						setformfield(form, "Mailing City", ocrObject.get("mailAddCity").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("mailAddState")) {
						setformfield(form, "Mailing State", ocrObject.get("mailAddState").getAsString());
					}

				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("mailAddZipCode")) {
						setformfield(form, "Mailing Zip Code", ocrObject.get("mailAddZipCode").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("mailAddCountry")) {
						setformfield(form, "Mailing Country", ocrObject.get("mailAddCountry").getAsString());
					}

				} catch (Exception e) {
					
				}
				try {
					if (employmentObject.has("employerDesc")) {
						if(i$outis.$iStrFuzzyMatch(employmentObject.get("employer").getAsString(), "OTHER")) { //#MVT00081 Changes starts
							setformfield(form, "Employers  Name", employmentObject.get("employerOther").getAsString());
						}else {
							setformfield(form, "Employers  Name", employmentObject.get("employerDesc").getAsString());
						} //#MVT00081 Changes ends
					}
				} catch (Exception e) {
					
				}
				try {
					if (employmentObject.has("occupation")) {
						setformfield(form, "Occupation", employmentObject.get("occupation").getAsString());//#SRP00032 changes
					}
				} catch (Exception e) {
					
				}
				try {// #MVT00085 Changes starts
					StringBuilder adress = new StringBuilder();
					JsonObject opr = i$ResM.getGobalValJObj("request").getAsJsonObject();

					if (i$outis.$iStrFuzzyMatch(opr.get("i-header").getAsJsonObject().get("operation").getAsString(),"ACQ")) {
						try {
							if (employmentObject.has("empAdd1") && !employmentObject.get("empAdd1").getAsString().isEmpty()) {
								adress.append(employmentObject.get("empAdd1").getAsString());
							}
							if (employmentObject.has("employerCity") && !employmentObject.get("employerCity").getAsString().isEmpty()) {
								adress.append(" ");
								adress.append(employmentObject.get("employerCity").getAsString());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						if (employmentObject.has("employerAddressLine1") || employmentObject.has("employerAddressLine2")
								|| employmentObject.has("employerCity") || employmentObject.has("employerCountryDesc")) {
							try {
								adress.append(employmentObject.get("employerAddressLine1").getAsString());
							} catch (Exception e) {
							}
							try {
								adress.append(" ");
								adress.append(employmentObject.get("employerAddressLine2").getAsString());
							} catch (Exception e) {
							}
							try {
								adress.append(" ");
								adress.append(employmentObject.get("employerCity").getAsString());
							} catch (Exception e) {
							}
//							try {
//								adress.append(" ");
//								adress.append(employmentObject.get("employerCountryDesc").getAsString());
//							} catch (Exception e) {
//							}
						}
					}
					setformfield(form, "Emp Add1", adress.toString());// #SRP00032 Changes
					
				} catch (Exception e) {
					
				}//#MVT00085 Changes ends
				try {
					if (employmentObject.has("employerCountryDesc")) {
						setformfield(form, "Emp Add2", employmentObject.get("employerCountryDesc").getAsString());
					}
				} catch (Exception e) {
					
				}
				//#SRP00032 Starts
				try {
					if (employmentObject.has("employerCity")) {
						setformfield(form, "Employer City", employmentObject.get("employerCity").getAsString());
					}
				} catch (Exception e) {
					
				}
				//#SRP00032 Ends
				
				try {
					if (employmentObject.has("employerCountryDesc")) {
						setformfield(form, "EmpBsnCountry", employmentObject.get("employerCountryDesc").getAsString());
					}
				} catch (Exception e) {
					
				}
				
				try {
					setformfield(form, "Emp City", "");
					setformfield(form, "ZIP code_3", employmentObject.get("empZipCode").getAsString());
				} catch (Exception e) {
					
				}
				try {
					if (ocrObject.has("avgMonthlyIncome")) {
						setformfield(form, "Annual Income Code", ocrObject.get("avgMonthlyIncome").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {	//#MVT00083 Changes Starts
					StringBuilder phoneNo = new StringBuilder(employmentObject.get("employerExtension").getAsString());
					phoneNo.append(employmentObject.get("employerWorkPhoneNumber").getAsString());
					if (employmentObject.has("employerWorkPhoneNumber")) {
						setformfield(form, "Business Phone", phoneNo.toString());
					}
				} catch (Exception e) {
					
				}
//				try {
//					if (employmentObject.has("employerExtension")) {
//						setformfield(form, "Business Phone Extension",
//								employmentObject.get("employerExtension").getAsString());
//					}
//
//				} catch (Exception e) {
//					
//				}
				try {
//					if (employmentObject.has("employerExtension")) {
//						setformfield(form, "Business Phone Extension",
//								employmentObject.get("employerExtension").getAsString());
//					}//#MVT00083 Changes ends

					if (additionalObject.has("birthCountryDesc")) {
						setformfield(form, "Country of birth", additionalObject.get("birthCountryDesc").getAsString());
					}
//					if (ocrObject.has("permAddCountry")) {
//						setformfield(form, "Nationality", ocrObject.get("permAddCountry").getAsString());
//					}
				} catch (Exception e) {
					
				}
				try {
					setformfield(form, "Local Tax Exempt", "No");
					setformfieldS(form, "EFTF", "No");
					setformfieldS(form, "DFTE", "No");
					setformfieldS(form, "CAC", "No");
					setformfieldS(form, "PA", "No");

					// SBC0087 ENDS
//                  
//                    
				} catch (Exception e) {
					
				}
				setformfield(form, "Credit Union Name", "NA");
			} if  (pdfName.equalsIgnoreCase("T_FD_Application_PDF")) { //#YPR00092 Starts


				JsonObject trnData = jsonObject.get("trnData").getAsJsonObject();
				JsonArray benfArr = trnData.get("beneficiary").getAsJsonArray();
                // #SRP00007 Starts
				try {        
					if (trnData.has("tenor") && !i$outis.$iStrBlank(trnData.get("tenor").getAsString())) {
						if (i$outis.$iStrFuzzyMatch(trnData.get("tenor").getAsString(), "1YRTERM"))
							setformfieldS(form, "1yearTerm", "On");
						else if (i$outis.$iStrFuzzyMatch(trnData.get("tenor").getAsString(), "3YRTERM"))
							setformfieldS(form, "3yearTerm", "On");
						else if (i$outis.$iStrFuzzyMatch(trnData.get("tenor").getAsString(), "5YRTERM"))
							setformfieldS(form, "5yearTerm", "On");
						else if (i$outis.$iStrFuzzyMatch(trnData.get("tenor").getAsString(), "10YRTERM"))
							setformfieldS(form, "10yearTerm", "On");						
					}
				}catch (Exception e) {  
					
				} //#SRP00007 Ends
				
				//#SRP00008 Starts changes
		        try {        
		          if (trnData.has("paymentOfInterest") && !i$outis.$iStrBlank(trnData.get("paymentOfInterest").getAsString())) {
		            if (i$outis.$iStrFuzzyMatch(trnData.get("paymentOfInterest").getAsString(), "Creditinterestto151sharesaccount")) {
		              setformfieldS(form, "creditShareAccountNo", "On");
		              try {                                                                       
							if (trnData.has("payOutAccNo")) {
								setformfield(form, "creditShareAccountNo1",trnData.get("payOutAccNo").getAsString());
							}
						} catch (Exception e) {
							
						}
//		              try {
//							if (trnData.has("initialTDAmt")) {
//								setformfield(form, "dollar1",trnData.get("initialTDAmt").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
			        }
		            else if (i$outis.$iStrFuzzyMatch(trnData.get("paymentOfInterest").getAsString(), "Creditinterestto150sharedepositaccount")) { 
		              setformfieldS(form, "creditShareDepositAccountNo", "On");
		              try {
							if (trnData.has("payOutAccNo")) {
								setformfield(form, "creditShareDepositAccountNo1",trnData.get("payOutAccNo").getAsString());
							}
						} catch (Exception e) {
							
						}
//		              try {
//							if (trnData.has("initialTDAmt")) {
//								setformfield(form, "dollar2",trnData.get("initialTDAmt").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
		              }
		            else if (i$outis.$iStrFuzzyMatch(trnData.get("paymentOfInterest").getAsString(), "Credittobankaccountandprovidebankinformation")) {
		              setformfieldS(form, "creditBankAccountNo", "On");
		              //#SRP00018 Starts 
		              try {                                                                       
							if (trnData.has("bankAccountNumber")&& !i$outis.$iStrBlank(trnData.get("bankAccountNumber").getAsString())) {
								setformfield(form, "CreditBankAccountNo",trnData.get("bankAccountNumber").getAsString());
							}
						} catch (Exception e) {
							
						}
		              JsonObject runningBenf = trnData.getAsJsonObject();
						try {
							if (runningBenf.has("bankName")|| runningBenf.has("bankAddress")) {
								StringBuilder strfullname = new StringBuilder();
								try {
									if (runningBenf.has("bankName") && !i$outis.$iStrBlank(runningBenf.get("bankName").getAsString())) {
										strfullname.append(runningBenf.get("bankName").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (runningBenf.has("bankAddress") && !i$outis.$iStrBlank(runningBenf.get("bankAddress").getAsString())) {
										strfullname.append(" ");
										strfullname.append(runningBenf.get("bankAddress").getAsString());
									}
								} catch (Exception e) {
									
								}
								setformfield(form, "bankNameAndAddress", strfullname.toString());
							}
						}catch (Exception e) {
							
						}
		            } //#SRP00018 ends
		            else if (i$outis.$iStrFuzzyMatch(trnData.get("paymentOfInterest").getAsString(), "TransfertolinCUaccount")) {
		              setformfieldS(form, "transferToLinCUAccountNo", "On");  
		              try {                                                                       
							if (trnData.has("payOutAccNo")) {
								setformfield(form, "transferToLinCUAccountNo1",trnData.get("payOutAccNo").getAsString());
							}
						} catch (Exception e) {
							
						}
//		              try {
//							if (trnData.has("initialTDAmt")) {
//								setformfield(form, "dollar3",trnData.get("initialTDAmt").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
		            }
		            else if (i$outis.$iStrFuzzyMatch(trnData.get("paymentOfInterest").getAsString(), "Renewwithinterest")) {
		              setformfieldS(form, "renewWithInterest", "On");  
		              try {                                                                       
							if (trnData.has("payOutAccNo")) {
								setformfield(form, "other1",trnData.get("payOutAccNo").getAsString());
							}
						} catch (Exception e) {
							
						}
		            }
		          }
		        }catch (Exception e) {  
		          
		        }//#SRP00008 Ends changes
		        //#SKP00012 Starts
		        try {
					if (trnData.has("payInAccNo")) {
						setformfield(form, "AccountCertificateNo",trnData.get("payInAccNo").getAsString());
					}
				} catch (Exception e) {
				//#SKP00012 Ends
				}
		        
		        try {
					addImage(stamp, form, "Qr_code_1", base64);
				}catch(Exception e) {
					
				}
		        
				try {
					if (trnData.has("custNo")) {
						setformfield(form, "MemberNo",trnData.get("custNo").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (trnData.has("CustomerFullName")) {
						setformfield(form, "membersName",trnData.get("CustomerFullName").getAsString());
					}
				} catch (Exception e) {
					
				}
				//#SRP00013 Start
				try {
					if (benfArr.size()>0) {
						for (int i=1;i<=benfArr.size();i++) {
				               JsonObject runningBenf = benfArr.get(i-1).getAsJsonObject();
							try {
								if (runningBenf.has("firstName")|| runningBenf.has("middleName")|| runningBenf.has("lastName")) {
									StringBuilder strfullname = new StringBuilder();
									try {
										if (runningBenf.has("firstName") && !i$outis.$iStrBlank(runningBenf.get("firstName").getAsString())) {
											strfullname.append(runningBenf.get("firstName").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (runningBenf.has("middleName") && !i$outis.$iStrBlank(runningBenf.get("middleName").getAsString())) {
											strfullname.append(" ");
											strfullname.append(runningBenf.get("middleName").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (runningBenf.has("lastName") && !i$outis.$iStrBlank(runningBenf.get("lastName").getAsString())) {
											strfullname.append(" ");
											strfullname.append(runningBenf.get("lastName").getAsString());
										}
									} catch (Exception e) {
										
									}
									
									setformfield(form, "beneficaries"+i, strfullname.toString());
									setformfield(form, "percentage"+i,runningBenf.get("percentBenefits").getAsString());
								}
							} catch (Exception e) {
								
							}
						}
					}
				} catch (Exception e) {
					
				}//#SRP00013 Ends
				
				try {
					if (trnData.has("initialTDAmt")) {
						setformfield(form, "amountOfDeposit",trnData.get("initialTDAmt").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (trnData.has("interestRate")) {
						setformfield(form, "interestRate",trnData.get("interestRate").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (trnData.has("dateOfIssue")) {
						setformfield(form, "dateOfIssue",trnData.get("dateOfIssue").getAsString());
					}
				} catch (Exception e) {
					
				}

				try {
					if (trnData.has("maturityDate")) {
						setformfield(form, "maturityDate",trnData.get("maturityDate").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {
					if (trnData.has("payInAccNo")) {
						setformfield(form, "shareDepositAccountNumber",trnData.get("payInAccNo").getAsString()); // #SRP00007 changed
					}
				} catch (Exception e) {
					
				}
				//#SRP00010 Start
				try {
					if (trnData.has("identificationNo")&& !i$outis.$iStrBlank(trnData.get("identificationNo").getAsString())) {
						setformfield(form, "identificationNo",trnData.get("identificationNo").getAsString());
					}
				} catch (Exception e) {
					
				}
				try {

					if (i$outis.$iStrBlank(trnData.get("memberContactNo").getAsString()))
						setformfield(form, "memberContactNo", "");
					else
						setformfield(form, "memberContactNo",createTECUMobNo(trnData.get("mobileNoExtension").getAsString(),trnData.get("memberContactNo").getAsString()));

				} catch (Exception e) {
					
				}
				try {
					if (trnData.has("dateOfIssue")&& !i$outis.$iStrBlank(trnData.get("dateOfIssue").getAsString())) {
						setformfield(form, "date_2",trnData.get("dateOfIssue").getAsString());
					}
				} catch (Exception e) {
					
				} //#SRP00010 Ends
			
				// #YPR00092 Ends
			} else {
				Map<String, AcroFields.Item> fieldsLinkedHashMap = form.getFields();
				List<String> filedName = new ArrayList<String>(fieldsLinkedHashMap.keySet());
				

				if (i$outis.$iStrFuzzyMatch(pdfName, "member_onboarding")|| i$outis.$iStrFuzzyMatch(pdfName, "member_onboarding_re_kyc")) {
					JsonObject jsonEmpDetails = null;

					try {
						jsonEmpDetails = jsonObject.get("employment").getAsJsonObject();
						if (jsonEmpDetails.has("employer")) {
							if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employer").getAsString(), "OTHER")) {
								setformfield(form, "employerConcat", jsonEmpDetails.get("employerOther").getAsString());
								}
							else {
								setformfield(form, "employerConcat", jsonEmpDetails.get("employerDesc").getAsString());
								}
						}
						

//						if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employerDesc").getAsString(), "OTHER EMPLOYERS")
//								&& jsonEmpDetails.has("employerOther")
//								&& !i$outis.$iStrBlank(jsonEmpDetails.get("employerOther").getAsString()))
//							form.setField("employerDesc",
//									"OTHER EMPLOYERS(" + jsonEmpDetails.get("employerOther").getAsString() + ")");
//
//						if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employer").getAsString(), "OTHER")) {
//							 jsonEmpDetails.addProperty("employer", new
//							 StringBuilder(jsonEmpDetails.get("employer").getAsString()).append("(").append(jsonEmpDetails.get("employerOther").getAsString()).append(")").toString());
//						}
					} catch (Exception e) {
						
					}

					try {
						JsonObject nationDetails = jsonObject.get("additionalDetails").getAsJsonObject();
						if (nationDetails.has("nationality")) {
							String natioNality = nationDetails.get("nationality").getAsString();
							setformfield(form, "nationalityDesc", natioNality);
						}

					} catch (Exception e) {
						
					}
					
					try {
						addImage(stamp, form, "QRCode", base64);
					}catch(Exception e) {
						
					}
					
					
					// #PKY00007 STARTS

					try {
						JsonObject jsonEmpDetails1 = jsonObject.get("employment").getAsJsonObject();
						if (i$outis.$iStrFuzzyMatch(jsonEmpDetails1.get("avgMonthlyIncome").getAsString(), "0-5")) {
							setformfield(form, "avgMonthlyIncome_0-5", "X");
						} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails1.get("avgMonthlyIncome").getAsString(),
								"5-12")) {
							setformfield(form, "avgMonthlyIncome_5-12", "X");
						} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails1.get("avgMonthlyIncome").getAsString(),
								"12-17")) {
							setformfield(form, "avgMonthlyIncome_12-17", "X");
						} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails1.get("avgMonthlyIncome").getAsString(),
								"17-22")) {
							setformfield(form, "avgMonthlyIncome_17-22", "X");
						} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails1.get("avgMonthlyIncome").getAsString(),
								"22-27")) {
							setformfield(form, "avgMonthlyIncome_22-27", "X");
						} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails1.get("avgMonthlyIncome").getAsString(),
								">27")) {
							setformfield(form, "avgMonthlyIncome_>27", "X");
						}
					} catch (Exception e) {
						
					}
					/// #PKY00007 ENDS

					try {
						if (jsonEmpDetails != null && jsonEmpDetails.has("sectorEmployed")) {
							String key = "hjjkljlkj";
							if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("sectorEmployed").getAsString(), "PRISEC")) {
								setformfield(form, "employmentType_PRISEC",
										jsonEmpDetails.get("employmentTypeDesc").getAsString());
							} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("sectorEmployed").getAsString(),
									"PUBSEC")) {
								setformfield(form, "employmentType_PUBSEC",
										jsonEmpDetails.get("employmentTypeDesc").getAsString());
							} else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("sectorEmployed").getAsString(),
									"SLFEMP")) {
								setformfield(form, "employmentType_SLFEMP",
										jsonEmpDetails.get("employmentTypeDesc").getAsString());
							} else {
								setformfield(form, "employmentType_OTHERS",
										jsonEmpDetails.get("employmentTypeDesc").getAsString());
							}
						}

					} catch (Exception e) {
						
					}
					// set Employment Type
					
										
             //#SRP00001 Begins		       			
					try {
						if (!i$outis.$iStrBlank(jsonEmpDetails.get("employmentMode").getAsString())) {
							if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "N") || i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "R") )
								setformfield(form, "employmentModes_R", "X");

							else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "F"))
								setformfield(form, "employmentModes_F", "X");								
							else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "T"))
								setformfield(form, "employmentModes_T", "X");
							else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "O"))
								setformfield(form, "employmentModes_O", "X");
							else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "P"))
								setformfield(form, "employmentModes_P", "X");
							else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "S"))
								setformfield(form, "employmentModes_S", "X");
							else if (i$outis.$iStrFuzzyMatch(jsonEmpDetails.get("employmentMode").getAsString(), "U"))
								setformfield(form, "employmentModes_U", "X");
							
								
						}
					} catch (Exception e) {
						
					}
				
				//#SRP00001 End..
				
					for (int i = 0; i < filedName.size(); i++) {
						String isNomination = "";
						String recommender = "";
						String pep = "";
						String fatca = "";
						try {
							isNomination = jsonObject.get("moreInfo").getAsJsonObject().get("isnominateBenificiary")
									.getAsString();
							recommender = jsonObject.get("moreInfo").getAsJsonObject().get("isRecommmendation")
									.getAsString();
						} catch (Exception e) {
							
						}
						// #PKY00007 starts

//                        try {
//                            fatca = jsonObject.get("moreInfo").getAsJsonObject().get("isCitizenShipofOtherCountry").getAsString();
//                            pep = jsonObject.get("moreInfo").getAsJsonObject().get("isPoliticallyExposed").getAsString();
//                        } catch (Exception e) {
//                            
//                        }
						// #PKY00007 ends

						try {
							JsonObject dataObject = jsonObject.get("contactDetails").getAsJsonObject();
							fillPDFField(dataObject, filedName.get(i), form);
						} catch (Exception e) {
							
						}
						try {
							JsonObject dataObject = jsonObject.get("employment").getAsJsonObject();
							fillPDFField(dataObject, filedName.get(i), form);
							if (i$outis.$iStrFuzzyMatch(filedName.get(i), "empAdd1")) {
								StringBuilder strEmpAdd = new StringBuilder();
								JsonObject opr = i$ResM.getGobalValJObj("request").getAsJsonObject(); // #MVT00085 Changes starts

								
								if (i$outis.$iStrFuzzyMatch(opr.get("i-header").getAsJsonObject().get("operation").getAsString(), "ACQ")) {
									try {
										if (dataObject.has("empAdd1")&&!dataObject.get("empAdd1").getAsString().isEmpty()) {
											strEmpAdd.append(dataObject.get("empAdd1").getAsString());
										}
										if (dataObject.has("employerCity")&&!dataObject.get("employerCity").getAsString().isEmpty()) {
											strEmpAdd.append(" ");
											strEmpAdd.append(dataObject.get("employerCity").getAsString());
										}
									} catch (Exception e) {
										e.printStackTrace();
									}
								} else {
									try {
										if (dataObject.has("employerAddressLine1")
												&& !dataObject.get("employerAddressLine1").getAsString().isEmpty()) {
											strEmpAdd.append(dataObject.get("employerAddressLine1").getAsString());
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("employerAddressLine2")
												&& !dataObject.get("employerAddressLine2").getAsString().isEmpty()) {
											strEmpAdd.append(", ");
											strEmpAdd.append(dataObject.get("employerAddressLine2").getAsString());
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("employerCity")
												&& !dataObject.get("employerCity").getAsString().isEmpty()) {
											strEmpAdd.append(", ");
											strEmpAdd.append(dataObject.get("employerCity").getAsString());
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("employerCountryDesc")
												&& !dataObject.get("employerCountryDesc").getAsString().isEmpty()) {
											strEmpAdd.append(", ");
											strEmpAdd.append(dataObject.get("employerCountryDesc").getAsString());
										}
									} catch (Exception e) {

									}
//									try {
//										if (dataObject.has("empZipCode")
//												&& !dataObject.get("empZipCode").getAsString().isEmpty()) {
//											strEmpAdd.append(" - ");
//											strEmpAdd.append(dataObject.get("empZipCode").getAsString());
//										}
//									} catch (Exception e) {
//
//									} // #MVT00085 Changes ends
								}
								setformfield(form, filedName.get(i), strEmpAdd.toString());
							}
							if (filedName.get(i).equals("employerDesc") && i$outis.$iStrFuzzyMatch(
									jsonEmpDetails.get("employerDesc").getAsString(), "OTHER EMPLOYERS"))
								form.setField("employerDesc",
										"OTHER EMPLOYERS(" + jsonEmpDetails.get("employerOther").getAsString() + ")");

							setformfield(form, "joiningDate",
									jsonObject.get("employment").getAsJsonObject().get("joiningDate").getAsString());
						} catch (Exception e) {
							e.printStackTrace();
						}
						try {
							JsonObject dataObject = jsonObject.get("additionalDetails").getAsJsonObject();
							fillPDFField(dataObject, filedName.get(i), form);
						} catch (Exception e) {
							
						}
						// #PKY00007 Ends
//                        try {
//                        	JsonObject dataObjects = jsonObject.get("additionalDetails").getAsJsonObject();
//                        	if(dataObjects.has("numberOfDependents")) {
//                        		setformfield(form,"numberOfDependent",dataObjects.get("numberOfDependents").getAsString());
//                        	}
//                        }catch(Exception e) {
//                        	
//                        }
//                        try {
//                        	JsonObject dataObjects = jsonObject.get("additionalDetails").getAsJsonObject();
//                        	if(dataObjects.has("numberofChildren")) {
//                        		setformfield(form,"numberOfChildren",dataObjects.get("numberofChildren").getAsString());
//                        	}
//                        }catch(Exception e) {
//                        	
//                        }
                        try {
                        	JsonObject dataObjects = jsonObject.get("additionalDetails").getAsJsonObject();
                        	if(dataObjects.has("birthCertificatePinNo")) {
                        		setformfield(form,"birthCertificatePinNo",dataObjects.get("birthCertificatePinNo").getAsString());
                        	}
                        }catch(Exception e) {
                        	
                        }
						// #PKY00007 Ends
						try {
							JsonObject dataObject = jsonObject.get("personalInfo").getAsJsonObject();
							fillPDFField(dataObject, filedName.get(i), form);

						} catch (Exception e) {
							
						}

						try {
							if (isNomination.equalsIgnoreCase("Y")) {
								try {
									JsonObject dataObject = jsonObject.get("nomnationOfBenificiary").getAsJsonObject();
									fillPDFField(dataObject, filedName.get(i), form);
									try {
										if (i$outis.$iStrFuzzyMatch(filedName.get(i), "nomMobNo"))
											concatContactNos(form, "nomMobNo", "nomMobNoExtension", dataObject);
										// setformfield(form,"nomMobNo",
										// dataObject.get("nomMobNoExtension").getAsString() +
										// dataObject.get("nomMobNo").getAsString());
									} catch (Exception e) {
										
									}
									try {
										if (i$outis.$iStrFuzzyMatch(filedName.get(i), "nomMobNo2"))
											concatContactNos(form, "nomMobNo2", "nomMobNoExtension2", dataObject);
										// setformfield(form,"nomMobNo2",
										// dataObject.get("nomMobNoExtension2").getAsString() +
										// dataObject.get("nomMobNo2").getAsString());
									} catch (Exception e) {
										
									}
									try {
										if (i$outis.$iStrFuzzyMatch(filedName.get(i), "nomHomePhone"))
											concatContactNos(form, "nomHomePhone", "nomHomePhoneExtension", dataObject);
										// setformfield(form,"nomHomePhone",
										// dataObject.get("nomHomePhoneExtension").getAsString() +
										// dataObject.get("nomHomePhone").getAsString());
									} catch (Exception e) {
										
									}
									try {
										if (i$outis.$iStrFuzzyMatch(filedName.get(i), "nomOfficePhone"))
											concatContactNos(form, "nomOfficePhone", "nomOfficePhoneExtension",
													dataObject);
										// setformfield(form,"nomOfficePhone",
										// dataObject.get("nomOfficePhoneExtension").getAsString() +
										// dataObject.get("nomOfficePhone").getAsString());
									} catch (Exception e) {
										
									}

									if (i$outis.$iStrFuzzyMatch(filedName.get(i), "nomFaxNo"))
										concatContactNos(form, "nomFaxNo", "nomFaxNoExtension", dataObject);
									// setformfield(form,"nomFaxNo",
									// dataObject.get("nomFaxNoExtension").getAsString() +
									// dataObject.get("nomFaxNo").getAsString());
									setformfield(form, "dobNomination", jsonObject.get("nomnationOfBenificiary")
											.getAsJsonObject().get("dobNomination").getAsString());
									StringBuilder strNomAdd = new StringBuilder();
									try {
										if (!i$outis.$iStrBlank(jsonObject.get("nomnationOfBenificiary")
												.getAsJsonObject().get("nomPermAddLine").getAsString())) {
											strNomAdd.append(jsonObject.get("nomnationOfBenificiary").getAsJsonObject()
													.get("nomPermAddLine").getAsString()+", ");//#MVT00099 changes begins
										}
									} catch (Exception e) {
										
									}
									try {
										if (!i$outis.$iStrBlank(jsonObject.get("nomnationOfBenificiary")
												.getAsJsonObject().get("nomPermAddLine2").getAsString())) {
											strNomAdd.append(jsonObject.get("nomnationOfBenificiary")
													.getAsJsonObject().get("nomPermAddLine2").getAsString()+", ");
										}
									} catch (Exception e) {
										
									}
//									//TKS00001 starts
//									try {										
//										if(dataObject.has("nomDocId") && !i$outis.$iStrBlank(dataObject.get("nomDocId").getAsString())) {
//											setformfield(form , "nomDoc" , dataObject.get("nomDocId").getAsString());
//										}else if(dataObject.has("nomDocNaId") && !i$outis.$iStrBlank(dataObject.get("nomDocNaId").getAsString())) {
//											setformfield(form , "nomDoc" ,dataObject.get("nomDocNaId").getAsString());
//										}else if(dataObject.has("nomDocDLId") && !i$outis.$iStrBlank(dataObject.get("nomDocDLId").getAsString())) {
//											setformfield(form , "nomDoc" , dataObject.get("nomDocDLId").getAsString());
//										}										
//									}catch(Exception e) {}
//									//TKS00001 ends
									try {//MSA00018 starts
										if(i$outis.$iStrFuzzyMatch(dataObject.get("nomineeMemberOfTecu").getAsString(),"Y")) {
											if(i$outis.$iStrFuzzyMatch(dataObject.get("docType").getAsString(),"Driver's Permit")) {
												setformfield(form , "nomDoc" , dataObject.get("nomDocDLId").getAsString());
											}
											else if(i$outis.$iStrFuzzyMatch(dataObject.get("docType").getAsString(),"NATIONAL IDENTIFICATION CARD")) {
												setformfield(form , "nomDoc" , dataObject.get("nomDocNaId").getAsString());
											}
											else if(i$outis.$iStrFuzzyMatch(dataObject.get("docType").getAsString(),"Passport")) {
												setformfield(form , "nomDoc" , dataObject.get("nomDocId").getAsString());
											}
										}
										else {
											if(dataObject.has("nomDocNaId") && !i$outis.$iStrBlank(dataObject.get("nomDocNaId").getAsString())) {
												setformfield(form , "nomDoc" , dataObject.get("nomDocNaId").getAsString());
											}else if(dataObject.has("nomDocId") && !i$outis.$iStrBlank(dataObject.get("nomDocId").getAsString())) {
												setformfield(form , "nomDoc" , dataObject.get("nomDocId").getAsString());
											}else if(dataObject.has("nomDocDLId") && !i$outis.$iStrBlank(dataObject.get("nomDocDLId").getAsString())) {// MSA00017 changes
												setformfield(form , "nomDoc" , dataObject.get("nomDocDLId").getAsString());
											}
										}
									}catch(Exception e) {}//MSA00018 ends
									try {
										if (!i$outis.$iStrBlank(jsonObject.get("nomnationOfBenificiary")
												.getAsJsonObject().get("nomPermAddLine3").getAsString())) {
											strNomAdd.append( jsonObject.get("nomnationOfBenificiary")
													.getAsJsonObject().get("nomPermAddLine3").getAsString()+", ");
										}
									} catch (Exception e) {
										
									}
									try { //#MVT00086 Changes Starts
										if (!i$outis.$iStrBlank(jsonObject.get("nomnationOfBenificiary")
												.getAsJsonObject().get("nomCity").getAsString())) {
											strNomAdd.append(jsonObject.get("nomnationOfBenificiary")
													.getAsJsonObject().get("nomCity").getAsString()+", ");
										}
									} catch (Exception e) {
										
									} //#MVT00086 Changes ends
									try { //MSA00002 starts
										if (!i$outis.$iStrBlank(jsonObject.get("nomnationOfBenificiary")
												.getAsJsonObject().get("nomNationalityDesc").getAsString())) {
											strNomAdd.append(jsonObject.get("nomnationOfBenificiary")
													.getAsJsonObject().get("nomNationalityDesc").getAsString());
										}//#MVT00099 changes ends
									} catch (Exception e) {
										
									} //MSA00002 ends
									setformfield(form, "nomPermAddLine", strNomAdd.toString());
								} catch (Exception e) {
									
								}
							}
						} catch (Exception e) {
							
						}
						
						try {
							if (jsonObject.has("nomnationOfBenificiary")) {
								JsonObject beneficiary = jsonObject.get("nomnationOfBenificiary").getAsJsonObject();
								setformfield(form, "nomBirthCertPinNo", beneficiary.get("nomBirthCertPinNo").getAsString());
							}
							
						}catch(Exception e) {
							
						}

						try {
							if (recommender.equalsIgnoreCase("Y")) {
								try {
									JsonObject dataObject = jsonObject.get("recommenderDetails").getAsJsonObject();
									/*
									 * if(i$outis.$iStrFuzzyMatch(filedName.get(i), "recHomePhone"))
									 * concatContactNos(form, "recHomePhone", "recHomePhoneExtension", dataObject);
									 * if(i$outis.$iStrFuzzyMatch(filedName.get(i), "recMobNo"))
									 * concatContactNos(form, "recMobNo", "recMobNoExtension", dataObject);
									 * if(i$outis.$iStrFuzzyMatch(filedName.get(i), "recWorkPhone"))
									 * concatContactNos(form, "recWorkPhone", "recWorkPhoneExtension", dataObject);
									 */
									JsonObject jsonRecommender = jsonObject.get("recommenderDetails").getAsJsonObject();
									try {
										if (i$outis.$iStrBlank(jsonRecommender.get("recHomePhone").getAsString()))
											setformfield(form, "recHomePhone", "");
										else
											setformfield(form, "recHomePhone",
													createTECUMobNo(
															jsonRecommender.get("recHomePhoneExtension").getAsString(),
															jsonRecommender.get("recHomePhone").getAsString()));

									} catch (Exception e) {
										
									}
									try {
										if (i$outis.$iStrBlank(jsonRecommender.get("recMobNo").getAsString()))
											setformfield(form, "recMobNo", "");
										else
											setformfield(form, "recMobNo",
													createTECUMobNo(
															jsonRecommender.get("recMobNoExtension").getAsString(),
															jsonRecommender.get("recMobNo").getAsString()));

									} catch (Exception e) {
										
									}
									try {
										if (i$outis.$iStrBlank(jsonRecommender.get("recWorkPhone").getAsString()))
											setformfield(form, "recWorkPhone", "");
										else
											setformfield(form, "recWorkPhone",
													createTECUMobNo(
															jsonRecommender.get("recWorkPhoneExtension").getAsString(),
															jsonRecommender.get("recWorkPhone").getAsString()));

									} catch (Exception e) {
										
									}
									try {
										if (jsonRecommender.has("recEmployerDesc")) {
											setformfield(form, "recEmployer", jsonRecommender.get("recEmployerDesc").getAsString());
										}
										else
											setformfield(form, "recEmployer","");

									} catch (Exception e) {
										
									}
									
									try {
										if (i$outis.$iStrFuzzyMatch(dataObject.get("recRelation").getAsString(), "Other")) {
											String recOther = dataObject.get("recRelation").getAsString()+" ("+dataObject.get("recRelationname").getAsString()+")";
											setformfield(form, "recRelation",recOther);
										}
										else {
											setformfield(form, "recRelation",dataObject.get("recRelation").getAsString());
										}
									} catch (Exception e) {
										
									}

									fillPDFField(dataObject, filedName.get(i), form);
								} catch (Exception e) {
									
								}

							}
						} catch (Exception e) {
							
						}

//                        if (pep.equalsIgnoreCase("Y")) {         //#PKY00007
						try {
							JsonObject dataObject = jsonObject.get("politicatalExposedDetailsDetails")
									.getAsJsonObject();
							fillPDFField(dataObject, filedName.get(i), form);
						} catch (Exception e) {
							
						}
//                        } else {
//                            jsonObject.add("politicatalExposedDetailsDetails", i$ResM.str2Json(IConstants.I_NO_PEP_SELECTION.toString()));
//                            JsonObject dataObject = jsonObject.get("politicatalExposedDetailsDetails").getAsJsonObject();
//                            ;
//                            fillPDFField(dataObject, filedName.get(i),form);
//                        }
//                        if (fatca.equalsIgnoreCase("Y")) {      //#PKY00007
						try {
							JsonObject dataObject = jsonObject.get("fatcaDeclaration").getAsJsonObject();
							fillPDFField(dataObject, filedName.get(i), form);

							String fatcaCountry = jsonObject.get("moreInfo").getAsJsonObject()
									.get("isCitizenShipofOtherCountry").getAsString();
							if (i$outis.$iStrFuzzyMatch(fatcaCountry, i$ResM.I_YCHAR)) {
								setformfield(form, "fatcaCountry", "Y");
							} else {
								setformfield(form, "fatcaCountry", "N");
							}

						} catch (Exception e) {
							
						}
//                        }

					}

					try {
						setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
					} catch (Exception e) {
						
					}
					try {
						if (jsonObject.has("Nominee Document_ocr_result")) {
							JsonObject nomiOb = jsonObject.get("Nominee Document_ocr_result").getAsJsonObject();
							try {
								if (nomiOb.has("ISSUING STATE NAME")) {
									setformfield(form, "cntryOfIssDocType",
											nomiOb.get("ISSUING STATE CODE").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (nomiOb.has("DATE OF ISSUE")) {
									setformfield(form, "issueDateDocType", nomiOb.get("DATE OF ISSUE").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (nomiOb.has("DATE OF EXPIRY")) {
									setformfield(form, "expiryDateDocType", nomiOb.get("DATE OF EXPIRY").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (nomiOb.has("DOCUMENT NUMBER")) {
									setformfield(form, "docType", nomiOb.get("DOCUMENT NUMBER").getAsString());
								}
							} catch (Exception e) {
								
							}
						}
					} catch (Exception e) {
						
					}
					// #PKY00007 starts
					try {
						String loanDetails = jsonObject.get("additionalDetails").getAsJsonObject().get("interestedInLoan").getAsString();
						if (loanDetails.equalsIgnoreCase("Y")) {
							if (i$outis.$iStrFuzzyMatch(
									jsonObject.get("additionalDetails").getAsJsonObject().get("interestedloanType").getAsString(),"Vehicle Loan")) {
								setformfield(form, "interestedloanType_Vehicle Loan", "X");
							} else if (i$outis.$iStrFuzzyMatch(
									jsonObject.get("additionalDetails").getAsJsonObject().get("interestedloanType").getAsString(),"Mortgage Loan")) {
								setformfield(form, "interestedloanType_MORTGAGE", "X");
							} else if (i$outis.$iStrFuzzyMatch(
									jsonObject.get("additionalDetails").getAsJsonObject().get("interestedloanType").getAsString(),"Secured Character Loan")) {
								setformfield(form, "interestedloanType_Secured Character Loan", "X");
							} else if (i$outis.$iStrFuzzyMatch(
									jsonObject.get("additionalDetails").getAsJsonObject().get("interestedloanType").getAsString(),"Unsecured Character Loan")) {
								setformfield(form, "interestedloanType_Unsecured Character Loan", "X");
							}
						}

					} catch (Exception e) {
						
					}
					try { //#MVT00086 starts
						if(jsonObject.get("additionalDetails").getAsJsonObject().has("countryOfIssuanceDesc")) {
							setformfield(form, "countryOfIssuance", jsonObject.get("additionalDetails")
									.getAsJsonObject().get("countryOfIssuanceDesc").getAsString());
						}
					}catch(Exception e) {
						
					}//#MVT00086 ends

					try {
						String spouceDetails = jsonObject.get("additionalDetails").getAsJsonObject()
								.get("spouseMemberOfTecu").getAsString();
						if (spouceDetails.equalsIgnoreCase("Y")) {
							setformfield(form, "spouseMemberNumbers", jsonObject.get("additionalDetails")
									.getAsJsonObject().get("spouseMemberNumber").getAsString());
						}

					} catch (Exception e) {
						
					}

					try {
						if (i$outis.$iStrFuzzyMatch(
								jsonObject.get("employment").getAsJsonObject().get("accountFunded").getAsString(),
								"Via Salary")) {
							setformfield(form, "accountFunded_Via Salary", "X");
						} else if (i$outis.$iStrFuzzyMatch(
								jsonObject.get("employment").getAsJsonObject().get("accountFunded").getAsString(),
								"Others")) {
							setformfield(form, "accountFunded_Others", "X");
							setformfield(form, "enterSourceAcountFunded", jsonObject.get("employment").getAsJsonObject()
									.get("enterSourceAccountFunded").getAsString());
						}

					} catch (Exception e) {
						
					}
					// #PKY00007 Ends

					JsonObject personalInfo = null;
					try {
						personalInfo = jsonObject.get("personalInfo").getAsJsonObject();
						setformfield(form, "dob", personalInfo.get("dob").getAsString());
//						if (i$outis.$iStrFuzzyMatch(pdfName, "member_onboarding_re_kyc_lite")) {
//							try {
//							JsonObject identificationInfo = jsonObject.get("identificationInfo").getAsJsonObject();
////                            if (personalInfo.has("priDocName")) {
////                                setformfield(form, "firstName", personalInfo.has("firstName") ? JchangedVals.get("firstName").getAsString() : "", "firstName");
////                                setformfield(form, "middleName", personalInfo.has("middleName") ? JchangedVals.get("middleName").getAsString() : "", "middleName");
////                                setformfield(form, "lastName", personalInfo.has("lastName") ? JchangedVals.get("lastName").getAsString() : "", "lastName");
////
////                                if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(), IConstants.I_NATIONALID.toString().toUpperCase()) >= 90 && FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(), IConstants.I_NATIONALID.toString()) <= 100) {
////                                    setformfield(form, "nationalId", personalInfo.has("priDocId") ? JchangedVals.get("priDocId").getAsString() : "", "priDocId");
////                                    setformfield(form, "expiryDateNationalId", personalInfo.has("priDocDOE") ? JchangedVals.get("priDocDOE").getAsString() : "", "priDocDOE");
////                                    setformfield(form, "issueDateNationalId", personalInfo.has("priDocDOI") ? JchangedVals.get("priDocDOI").getAsString() : "", "priDocDOI");
////                                    setformfield(form, "cntryOfIssNationalId", personalInfo.has("priDocCntryIssuance") ? JchangedVals.get("priDocCntryIssuance").getAsString() : "", "priDocCntryIssuance");
////                                } else if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(), IConstants.I_PASSPORT.toString()) >= 90 && FuzzySearch.weightedRatio(JchangedVals.get("priDocName").getAsString(), IConstants.I_PASSPORT.toString()) <= 100) {
////                                    setformfield(form, "Passport", personalInfo.has("priDocId") ? JchangedVals.get("priDocId").getAsString() : "", "priDocId");
////                                    setformfield(form, "expiryDatePassport", personalInfo.has("priDocDOE") ? JchangedVals.get("priDocDOE").getAsString() : "", "priDocDOE");
////                                    setformfield(form, "issueDatePassport", personalInfo.has("priDocDOI") ? JchangedVals.get("priDocDOI").getAsString() : "", "priDocDOI");
////                                    setformfield(form, "cntryOfIssPassport", personalInfo.has("priDocCntryIssuance") ? JchangedVals.get("priDocCntryIssuance").getAsString() : "", "priDocCntryIssuance");
////                                } else if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(), IConstants.I_DRIVERSPERMIT.toString()) >= 90 && FuzzySearch.weightedRatio(JchangedVals.get("priDocName").getAsString(), IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
////                                    setformfield(form, "driversPermit", personalInfo.has("priDocId") ? JchangedVals.get("priDocId").getAsString() : "", "priDocId");
////                                    setformfield(form, "expiryDateDriversPer", personalInfo.has("priDocDOE") ? JchangedVals.get("priDocDOE").getAsString() : "", "priDocDOE");
////                                    setformfield(form, "issueDateDriversPer", personalInfo.has("priDocDOI") ? JchangedVals.get("priDocDOI").getAsString() : "", "priDocDOI");
////                                    setformfield(form, "cntryOfIssDriversPer", personalInfo.has("priDocCntryIssuance") ? JchangedVals.get("priDocCntryIssuance").getAsString() : "", "priDocCntryIssuance");
////                                }
////                            }
////                            if (personalInfo.has("secDocName")) {
////                                if (FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(), IConstants.I_DRIVERSPERMIT.toString()) >= 90 && FuzzySearch.weightedRatio(JchangedVals.get("secDocName").getAsString(), IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
////
////                                    setformfield(form, "driversPermit", personalInfo.has("secDocId") ? JchangedVals.get("secDocId").getAsString() : "", "secDocId");
////                                    setformfield(form, "expiryDateDriversPer", personalInfo.has("secDocDOE") ? JchangedVals.get("secDocDOE").getAsString() : "", "secDocDOE");
////                                    setformfield(form, "issueDateDriversPer", personalInfo.has("secDocDOI") ? JchangedVals.get("secDocDOI").getAsString() : "", "secDocDOI");
////                                    setformfield(form, "cntryOfIssDriversPer", personalInfo.has("secDocCntryIssuance") ? JchangedVals.get("secDocCntryIssuance").getAsString() : "", "secDocCntryIssuance");
////                                } else if (FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(), IConstants.I_PASSPORT.toString()) >= 90 && FuzzySearch.weightedRatio(JchangedVals.get("secDocName").getAsString(), IConstants.I_PASSPORT.toString()) <= 100) {
////
////
////                                    setformfield(form, "Passport", personalInfo.has("secDocId") ? JchangedVals.get("secDocId").getAsString() : "", "secDocId");
////                                    setformfield(form, "expiryDatePassport", personalInfo.has("secDocDOE") ? JchangedVals.get("secDocDOE").getAsString() : "", "secDocDOE");
////                                    setformfield(form, "issueDatePassport", personalInfo.has("secDocDOI") ? JchangedVals.get("secDocDOI").getAsString() : "", "secDocDOI");
////                                    setformfield(form, "cntryOfIssPassport", personalInfo.has("secDocCntryIssuance") ? JchangedVals.get("secDocCntryIssuance").getAsString() : "", "secDocCntryIssuance");
////                                } else if (FuzzySearch.weightedRatio(JchangedVals.get("secDocName").getAsString(), IConstants.I_NATIONALID.toString()) >= 90 && FuzzySearch.weightedRatio(JchangedVals.get("secDocName").getAsString(), IConstants.I_NATIONALID.toString()) <= 100) {
////
////
////                                    setformfield(form, "nationalId", personalInfo.has("secDocId") ? JchangedVals.get("secDocId").getAsString() : "", "secDocId");
////                                    setformfield(form, "expiryDateNationalId", personalInfo.has("secDocDOE") ? JchangedVals.get("secDocDOE").getAsString() : "", "secDocDOE");
////                                    setformfield(form, "issueDateNationalId", personalInfo.has("secDocDOI") ? JchangedVals.get("secDocDOI").getAsString() : "", "secDocDOI");
////                                    setformfield(form, "cntryOfIssNationalId", personalInfo.has("secDocCntryIssuance") ? JchangedVals.get("secDocCntryIssuance").getAsString() : "", "secDocCntryIssuance");
////                                }
////                            }
//
//							if (FuzzySearch.weightedRatio(identificationInfo.get("priDocName").getAsString(),
//									IConstants.I_NATIONALID.toString()) >= 90
//									&& FuzzySearch.weightedRatio(identificationInfo.get("priDocName").getAsString(),
//											IConstants.I_NATIONALID.toString()) <= 100) {
//								setformfield(form, "nationalId", identificationInfo.get("priDocId").getAsString());
//								setformfield(form, "expiryDateNationalId", identificationInfo.get("priDocDOE").getAsString());
//								setformfield(form, "issueDateNationalId", identificationInfo.get("priDocDOI").getAsString());
////                                setformfield(form, "cntryOfIssNationalId", (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).substring(0, (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1));
//								try {	//#MVT00093 Changes starts
//									setformfield(form, "cntryOfIssNationalId",
//											identificationInfo.get("priDocIssuanceCountry").getAsString()); // #PKY00007
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//							} else if (FuzzySearch.weightedRatio(identificationInfo.get("priDocName").getAsString(),
//									IConstants.I_PASSPORT.toString()) >= 90
//									&& FuzzySearch.weightedRatio(identificationInfo.get("priDocName").getAsString(),
//											IConstants.I_PASSPORT.toString()) <= 100) {
//								setformfield(form, "Passport", identificationInfo.get("priDocId").getAsString());
//								setformfield(form, "expiryDatePassport", identificationInfo.get("priDocDOE").getAsString());
//								setformfield(form, "issueDatePassport", identificationInfo.get("priDocDOI").getAsString());
////                                  setformfield(form, "cntryOfIssPassport", (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).substring(0, (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1));
//								try {
//									setformfield(form, "cntryOfIssPassport",
//											identificationInfo.get("priDocIssuanceCountry").getAsString()); // #PKY00007
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//							} else if (FuzzySearch.weightedRatio(identificationInfo.get("priDocName").getAsString(),
//									IConstants.I_DRIVERSPERMIT.toString()) >= 90
//									&& FuzzySearch.weightedRatio(identificationInfo.get("priDocName").getAsString(),
//											IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
//								setformfield(form, "driversPermit", identificationInfo.get("priDocId").getAsString());
//								setformfield(form, "expiryDateDriversPer", identificationInfo.get("priDocDOE").getAsString());
//								setformfield(form, "issueDateDriversPer", identificationInfo.get("priDocDOI").getAsString());
////                                  setformfield(form, "cntryOfIssDriversPer", (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).substring(0, (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1));
//								try {
//									setformfield(form, "cntryOfIssDriversPer",
//											identificationInfo.get("priDocIssuanceCountry").getAsString()); // #PKY00007
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//							}
//							if (FuzzySearch.weightedRatio(identificationInfo.get("secDocName").getAsString(),
//									IConstants.I_DRIVERSPERMIT.toString()) >= 90
//									&& FuzzySearch.weightedRatio(identificationInfo.get("secDocName").getAsString(),
//											IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
//								setformfield(form, "driversPermit", identificationInfo.get("secDocId").getAsString());
//								setformfield(form, "expiryDateDriversPer", identificationInfo.get("secDocDOE").getAsString());
//								setformfield(form, "issueDateDriversPer", identificationInfo.get("secDocDOI").getAsString());
////                                  setformfield(form, "cntryOfIssDriversPer", (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString().substring(0, (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1)));
//								try {
//									setformfield(form, "cntryOfIssDriversPer",
//											identificationInfo.get("secDocIssuanceCountry").getAsString()); // #PKY00007
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//							} else if (FuzzySearch.weightedRatio(identificationInfo.get("secDocName").getAsString(),
//									IConstants.I_PASSPORT.toString()) >= 90
//									&& FuzzySearch.weightedRatio(identificationInfo.get("secDocName").getAsString(),
//											IConstants.I_PASSPORT.toString()) <= 100) {
//								setformfield(form, "Passport", identificationInfo.get("secDocId").getAsString());
//								setformfield(form, "expiryDatePassport", identificationInfo.get("secDocDOE").getAsString());
//								setformfield(form, "issueDatePassport", identificationInfo.get("secDocDOI").getAsString());
////                                  setformfield(form, "cntryOfIssPassport", (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString().substring(0, (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1)));
//								try {
//									setformfield(form, "cntryOfIssPassport",
//											identificationInfo.get("secDocIssuanceCountry").getAsString()); // #PKY00007
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//
//							} else if (FuzzySearch.weightedRatio(identificationInfo.get("secDocName").getAsString(),
//									IConstants.I_NATIONALID.toString()) >= 90
//									&& FuzzySearch.weightedRatio(identificationInfo.get("secDocName").getAsString(),
//											IConstants.I_NATIONALID.toString()) <= 100) {
//								setformfield(form, "nationalId", identificationInfo.get("secDocId").getAsString());
//								setformfield(form, "expiryDateNationalId", identificationInfo.get("secDocDOE").getAsString());
//								setformfield(form, "issueDateNationalId", identificationInfo.get("secDocDOI").getAsString());
////                                  setformfield(form, "cntryOfIssNationalId", (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString().substring(0, (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1)));
//								try {
//									setformfield(form, "cntryOfIssNationalId",
//											identificationInfo.get("secDocIssuanceCountry").getAsString()); // #PKY00007
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//							}
//							//#MVT00093 Changes ends
//							}catch(Exception e) {}
//							//MSA00013 starts
//							JsonObject contactDetl = jsonObject.get("contactDetails").getAsJsonObject();
//							try {
//								if (contactDetl != null) {
//									StringBuilder addLine1 = new StringBuilder();
//									try {
//										if (contactDetl.has("permAddLine1")
//												&& !i$outis.$iStrBlank(contactDetl.get("permAddLine1").getAsString())) {
//											addLine1.append(contactDetl.get("permAddLine1").getAsString());
//										}
//									} catch (Exception e) {
//
//									}
//									try {
//										if (contactDetl.has("permAddLine2")
//												&& !i$outis.$iStrBlank(contactDetl.get("permAddLine2").getAsString())) {
//											addLine1.append(", ");
//											addLine1.append(contactDetl.get("permAddLine2").getAsString());
//										}
//									} catch (Exception e) {
//
//									}
//									setformfield(form, "permAddLine1", addLine1.toString());
//								}
//							} catch (Exception e) {
//							}
//							try {
//								if (contactDetl != null) {
//									StringBuilder addLine2 = new StringBuilder();
//									try {
//										if (contactDetl.has("permAddCity")
//												&& !i$outis.$iStrBlank(contactDetl.get("permAddCity").getAsString())) {
//											addLine2.append(contactDetl.get("permAddCity").getAsString());
//										}
//									} catch (Exception e) {
//
//									}
//									try {
//										if (contactDetl.has("permAddCountry")
//												&& !i$outis.$iStrBlank(contactDetl.get("permAddCountry").getAsString())) {
//											addLine2.append(", ");
//											addLine2.append(contactDetl.get("permAddCountry").getAsString());
//										}
//									} catch (Exception e) {
//
//									}
//									setformfield(form, "permAddLine2", addLine2.toString());
//								}
//							} catch (Exception e) {
//							}
//							try {
//								if (contactDetl != null) {
//									StringBuilder addMailLine1 = new StringBuilder();
//									try {
//										if (contactDetl.has("mailAddLine1")
//												&& !i$outis.$iStrBlank(contactDetl.get("mailAddLine1").getAsString())) {
//											addMailLine1.append(contactDetl.get("mailAddLine1").getAsString());
//										}
//									} catch (Exception e) {
//										
//									}
//									try {
//										if (contactDetl.has("mailAddLine2")
//												&& !i$outis.$iStrBlank(contactDetl.get("mailAddLine2").getAsString())) {
//											addMailLine1.append(", ");
//											addMailLine1.append(contactDetl.get("mailAddLine2").getAsString());
//										}
//									} catch (Exception e) {
//										
//									}
//									setformfield(form, "mailAddLine1", addMailLine1.toString());
//								}
//								}catch(Exception e) {}
//							try {
//								if (contactDetl != null) {
//									StringBuilder addMailLine2 = new StringBuilder();
//									try {
//										if (contactDetl.has("mailAddCity")
//												&& !i$outis.$iStrBlank(contactDetl.get("mailAddCity").getAsString())) {
//											addMailLine2.append(contactDetl.get("mailAddCity").getAsString());
//										}
//									} catch (Exception e) {
//										
//									}
//									try {
//										if (contactDetl.has("mailAddCountry")
//												&& !i$outis.$iStrBlank(contactDetl.get("mailAddCountry").getAsString())) {
//											addMailLine2.append(", ");
//											addMailLine2.append(contactDetl.get("mailAddCountry").getAsString());
//										}
//									} catch (Exception e) {
//										
//									}
//									setformfield(form, "mailAddLine2", addMailLine2.toString());
//								}
//								}catch(Exception e) {}
//							//MSA00013 ends
//
//						} 
//						else {
							try{//#PAV00015 Changes
								if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
									IConstants.I_NATIONALID.toString()) >= 90
									&& FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
											IConstants.I_NATIONALID.toString()) <= 100) {
								setformfield(form, "nationalId", personalInfo.get("priDocId").getAsString());
								setformfield(form, "expiryDateNationalId", personalInfo.get("priDocDOE").getAsString());
								setformfield(form, "issueDateNationalId", personalInfo.get("priDocDOI").getAsString());
//                                setformfield(form, "cntryOfIssNationalId", (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).substring(0, (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1));
//								setformfield(form, "cntryOfIssNationalId",
//										personalInfo.get("priDocIssuanceCountry").getAsString()); // #PKY00007
								setformfield(form, "cntryOfIssNationalId", // #MVT00088 Changes starts
										jsonObject.get("primaryOCrResult").getAsJsonObject().get("issuingStateCode").getAsString());

							} else if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
									IConstants.I_PASSPORT.toString()) >= 90
									&& FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
											IConstants.I_PASSPORT.toString()) <= 100) {
								setformfield(form, "Passport", personalInfo.get("priDocId").getAsString());
								setformfield(form, "expiryDatePassport", personalInfo.get("priDocDOE").getAsString());
								setformfield(form, "issueDatePassport", personalInfo.get("priDocDOI").getAsString());
//                                setformfield(form, "cntryOfIssPassport", (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).substring(0, (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1));
//								setformfield(form, "cntryOfIssPassport",
//										personalInfo.get("priDocIssuanceCountry").getAsString()); // #PKY00007
								setformfield(form, "cntryOfIssPassport",
										jsonObject.get("primaryOCrResult").getAsJsonObject().get("issuingStateCode").getAsString());

							} else if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
									IConstants.I_DRIVERSPERMIT.toString()) >= 90
									&& FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
											IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
								setformfield(form, "driversPermit", personalInfo.get("priDocId").getAsString());
								setformfield(form, "expiryDateDriversPer", personalInfo.get("priDocDOE").getAsString());
								setformfield(form, "issueDateDriversPer", personalInfo.get("priDocDOI").getAsString());
//                                setformfield(form, "cntryOfIssDriversPer", (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).substring(0, (jsonObject.get("primaryOCrResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1));
//								setformfield(form, "cntryOfIssDriversPer",
//										personalInfo.get("priDocIssuanceCountry").getAsString()); // #PKY00007
								setformfield(form, "cntryOfIssDriversPer",
										jsonObject.get("primaryOCrResult").getAsJsonObject().get("issuingStateCode").getAsString());

							}}catch (Exception e) {//#PAV00015 Changes
								e.printStackTrace();
							}
							try {//#PAV00015 Changes
							if (FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
									IConstants.I_DRIVERSPERMIT.toString()) >= 90
									&& FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
											IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
								setformfield(form, "driversPermit", personalInfo.get("secDocId").getAsString());
								setformfield(form, "expiryDateDriversPer", personalInfo.get("secDocDOE").getAsString());
								setformfield(form, "issueDateDriversPer", personalInfo.get("secDocDOI").getAsString());
//                                setformfield(form, "cntryOfIssDriversPer", (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString().substring(0, (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1)));
//								setformfield(form, "cntryOfIssDriversPer",
//										personalInfo.get("secDocIssuanceCountry").getAsString()); // #PKY00007
								setformfield(form, "cntryOfIssDriversPer",
										jsonObject.get("secondaryOCRResult").getAsJsonObject().get("issuingStateCode").getAsString());

							} else if (FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
									IConstants.I_PASSPORT.toString()) >= 90
									&& FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
											IConstants.I_PASSPORT.toString()) <= 100) {
								setformfield(form, "Passport", personalInfo.get("secDocId").getAsString());
								setformfield(form, "expiryDatePassport", personalInfo.get("secDocDOE").getAsString());
								setformfield(form, "issueDatePassport", personalInfo.get("secDocDOI").getAsString());
//                                setformfield(form, "cntryOfIssPassport", (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString().substring(0, (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1)));
//								setformfield(form, "cntryOfIssPassport",
//										personalInfo.get("secDocIssuanceCountry").getAsString()); // #PKY00007
								setformfield(form, "cntryOfIssPassport",
										jsonObject.get("secondaryOCRResult").getAsJsonObject().get("issuingStateCode").getAsString());

							} else if (FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
									IConstants.I_NATIONALID.toString()) >= 90
									&& FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
											IConstants.I_NATIONALID.toString()) <= 100) {
								setformfield(form, "nationalId", personalInfo.get("secDocId").getAsString());
								setformfield(form, "expiryDateNationalId", personalInfo.get("secDocDOE").getAsString());
								setformfield(form, "issueDateNationalId", personalInfo.get("secDocDOI").getAsString());
//                                setformfield(form, "cntryOfIssNationalId", (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString().substring(0, (jsonObject.get("secondaryOCRResult").getAsJsonObject().get("ISSUING STATE CODE").getAsString()).length() - 1)));
//								setformfield(form, "cntryOfIssNationalId",
//										personalInfo.get("secDocIssuanceCountry").getAsString()); // #PKY00007
								setformfield(form, "cntryOfIssNationalId",
										jsonObject.get("secondaryOCRResult").getAsJsonObject().get("issuingStateCode").getAsString());

							} // #MVT00088 Changes starts
							}catch (Exception e) {//#PAV00015 Changes
								e.printStackTrace();
							}
//						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					try {
						if (personalInfo != null) {
							StringBuilder addLine1 = new StringBuilder(personalInfo.get("permAddLine1").getAsString());
							try {
								if (personalInfo.has("permAddLine2")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddLine2").getAsString())) {
									addLine1.append(", ");
									addLine1.append(personalInfo.get("permAddLine2").getAsString());
								}
							} catch (Exception e) {
								
							}
							setformfield(form, "permAddLine1", addLine1.toString());
							StringBuilder addline2 = new StringBuilder();
							try {
								if (personalInfo.has("permAddLine3")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddLine3").getAsString())) {
									addline2.append(personalInfo.get("permAddLine3").getAsString());
									addline2.append(", ");
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("permAddLine4")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddLine4").getAsString())) {
									addline2.append(personalInfo.get("permAddLine4").getAsString());
									addline2.append(", ");
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("permAddCity")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddCity").getAsString())) {
									addline2.append(personalInfo.get("permAddCity").getAsString());
									addline2.append(", ");
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("permAddState")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddState").getAsString())) {
									addline2.append(personalInfo.get("permAddState").getAsString());
									addline2.append(", ");
								}
							} catch (Exception e) {
								
							}
							try { //#MVT00087 Changes starts 
								if (personalInfo.has("permAddCountryDesc")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddCountryDesc").getAsString())) {
									addline2.append(personalInfo.get("permAddCountryDesc").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("permAddZipCode")
										&& !i$outis.$iStrBlank(personalInfo.get("permAddZipCode").getAsString())) {
									addline2.append(" - ");
									addline2.append(personalInfo.get("permAddZipCode").getAsString());
								}
							} catch (Exception e) {
								
							}
							setformfield(form, "permAddLine2", addline2.toString());

							// mail address
							StringBuilder mailLine1 = new StringBuilder(personalInfo.get("mailAddLine1").getAsString()); //MVT00080 Changes starts
							try {
								if (personalInfo.has("mailAddLine2")
										&& !i$outis.$iStrBlank(personalInfo.get("mailAddLine2").getAsString())) {
									mailLine1.append(", ");
									mailLine1.append(personalInfo.get("mailAddLine2").getAsString());
								}
//								if (personalInfo.has("mailAddCity")
//										&& !i$outis.$iStrBlank(personalInfo.get("mailAddCity").getAsString())) {
//									mailLine1.append(", ");
//									mailLine1.append(personalInfo.get("mailAddCity").getAsString());
//								}
							} catch (Exception e) {

							} //#MVT00087 Changes ends
							setformfield(form, "mailAddLine1", mailLine1.toString()); //MVT00080 Changes ends
							StringBuilder mailLine2 = new StringBuilder();
//							try {
//								if (personalInfo.has("mailAddLine3")
//										&& !i$outis.$iStrBlank(personalInfo.get("mailAddLine3").getAsString())) {
//									mailLine2.append(personalInfo.get("mailAddLine3").getAsString());
//									mailLine2.append(", ");
//								}
//							} catch (Exception e) {
//								
//							}
//							try {
//								if (personalInfo.has("mailAddLine4")
//										&& !i$outis.$iStrBlank(personalInfo.get("mailAddLine4").getAsString())) {
//									mailLine2.append(personalInfo.get("mailAddLine4").getAsString());
//									mailLine2.append(", ");
//								}
//							} catch (Exception e) {
//								
//							}
							try {
								if (personalInfo.has("mailAddCity")
										&& !i$outis.$iStrBlank(personalInfo.get("mailAddCity").getAsString())) {
									mailLine2.append(personalInfo.get("mailAddCity").getAsString());
									mailLine2.append(", ");
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("mailAddState")
										&& !i$outis.$iStrBlank(personalInfo.get("mailAddState").getAsString())) {
									mailLine2.append(personalInfo.get("mailAddState").getAsString());
									mailLine2.append(", ");
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("mailAddCountryDesc")
										&& !i$outis.$iStrBlank(personalInfo.get("mailAddCountryDesc").getAsString())) {
									mailLine2.append(personalInfo.get("mailAddCountryDesc").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (personalInfo.has("mailAddZipCode")
										&& !i$outis.$iStrBlank(personalInfo.get("mailAddZipCode").getAsString())) {
									mailLine2.append(" - ");
									mailLine2.append(personalInfo.get("mailAddZipCode").getAsString());
								}
							} catch (Exception e) {
								
							}
							setformfield(form, "mailAddLine2", mailLine2.toString());
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					try {	//MVT00080 Changes starts
						setformfield(form, "birthCountryDesc", personalInfo.get("country").getAsString());
					} catch (Exception e) {
						e.printStackTrace();
					}	//MVT00080 Changes ends
					
					try { // #MVT00088 Changes starts
						if(personalInfo.has("firstName") && !i$outis.$iStrBlank(personalInfo.get("firstName").getAsString())) {
							setformfield(form, "firstName", personalInfo.get("firstName").getAsString());
						}
						if(personalInfo.has("middleName") && !i$outis.$iStrBlank(personalInfo.get("middleName").getAsString())) {
							setformfield(form, "middleName", personalInfo.get("middleName").getAsString());
						}
						if(personalInfo.has("lastName") && !i$outis.$iStrBlank(personalInfo.get("lastName").getAsString())) {
							setformfield(form, "lastName", personalInfo.get("lastName").getAsString());
						}
					}catch(Exception e) {
						e.printStackTrace();
					} // #MVT00088 Changes ends
					// to print mobileNos with ISD codes
					try {
						try {
							if (i$outis.$iStrBlank(jsonObject.get("contactDetails").getAsJsonObject()
									.get("mobileNumber").getAsString()))
								setformfield(form, "mobileNumber", "");
							else
								setformfield(form, "mobileNumber",
										createTECUMobNo(
												jsonObject.get("contactDetails").getAsJsonObject().get("mobileISD")
														.getAsString(),
												jsonObject.get("contactDetails").getAsJsonObject().get("mobileNumber")
														.getAsString()));
						} catch (Exception e) {
							
						}
						try {

							if (i$outis.$iStrBlank(jsonObject.get("additionalDetails").getAsJsonObject()
									.get("homePhoneNumber").getAsString()))
								setformfield(form, "homePhoneNumber", "");
							else
								setformfield(form, "homePhoneNumber",
										createTECUMobNo(
												jsonObject.get("additionalDetails").getAsJsonObject()
														.get("homephoneExtension").getAsString(),
												jsonObject.get("additionalDetails").getAsJsonObject()
														.get("homePhoneNumber").getAsString()));
						} catch (Exception e) {
							
						}
						try {
							if (i$outis.$iStrBlank(jsonObject.get("additionalDetails").getAsJsonObject().get("spouseMobileNumber").getAsString()))
								setformfield(form, "spouseMobileNumber", "");
							else
								setformfield(form, "spouseMobileNumber",createTECUMobNo(jsonObject.get("additionalDetails").getAsJsonObject().get("spouseMobileNumberExtension").getAsString(),jsonObject.get("additionalDetails").getAsJsonObject().get("spouseMobileNumber").getAsString()));
						} catch (Exception e) {
							
						}
						// employment contacts 
						try {
							if (i$outis.$iStrBlank(jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber").getAsString()))
								setformfield(form, "employerWorkPhoneNumber", "");   
							else
//								 setformfield(form, "employerWorkPhoneNumber",
//								 createTECUMobNo(jsonObject.get("employment").getAsJsonObject().get("employerExtension").getAsString(),
//								 jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber").getAsString()));
								setformfield(form, "employerWorkPhoneNumber",createTECUWorkPhoneNo(jsonObject.get("employment").getAsJsonObject().get("employerExtension").getAsString(),jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber").getAsString())); //#SRP00002 changes 
						} catch (Exception e) {
							
						}
						try {

							if (i$outis.$iStrBlank(
									jsonObject.get("employment").getAsJsonObject().get("empfaxNo").getAsString()))
								setformfield(form, "empfaxNo", "");
							else
								setformfield(form, "empfaxNo", createTECUMobNo(
										jsonObject.get("employment").getAsJsonObject().get("empfaxNoExtension")
												.getAsString(),
										jsonObject.get("employment").getAsJsonObject().get("empfaxNo").getAsString()));
						} catch (Exception e) {
							
						}
						try {
							if (i$outis.$iStrBlank(jsonObject.get("additionalDetails").getAsJsonObject()
									.get("faxNumber").getAsString()))
								setformfield(form, "faxNumber", "");
							else
								// setformfield(form, "faxNumber",
								// createTECUMobNo(jsonObject.get("additionalDetails").getAsJsonObject().get("faxNumberExtension").getAsString(),
								// jsonObject.get("additionalDetails").getAsJsonObject().get("faxNumber").getAsString()));
								setformfield(form, "faxNumber", createClicoMobNo(jsonObject.get("additionalDetails")
										.getAsJsonObject().get("faxNumber").getAsString()));
						} catch (Exception e) {
							
						}
						try {

							if (i$outis.$iStrBlank(jsonObject.get("employment").getAsJsonObject()
									.get("employerWorkPhoneNumber2").getAsString()))   
								setformfield(form, "employerExtension2", "");
						} catch (Exception e) {
							
						}
						try {
							if (i$outis.$iStrBlank(
									jsonObject.get("employment").getAsJsonObject().get("empfaxNo").getAsString()))
								setformfield(form, "empfaxNoExtension", "");
						} catch (Exception e) {
							
						}
						try {
							if (i$outis.$iStrBlank(jsonObject.get("additionalDetails").getAsJsonObject()
									.get("faxNumber").getAsString()))
								setformfield(form, "faxNumberExtension", "");
						} catch (Exception e) {
							
						}

						try {
							if (i$outis.$iStrBlank(jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber").getAsString()))
								setformfield(form, "employerExtension", "");
						} catch (Exception e) {
							
						}
						try {

							if (i$outis.$iStrBlank(
									jsonObject.get("additionalDetails").getAsJsonObject().get("mobNo2").getAsString()))
								setformfield(form, "mobNo2", "");
							else
								setformfield(form, "mobNo2",
										createTECUMobNo(
												jsonObject.get("additionalDetails").getAsJsonObject()
														.get("mobNo2Extension").getAsString(),
												jsonObject.get("additionalDetails").getAsJsonObject().get("mobNo2")
														.getAsString()));
						} catch (Exception e) {
							
						}
						try {

							if (i$outis.$iStrBlank(jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber2").getAsString()))    
								setformfield(form, "employerWorkPhoneNumber2", "");
							else
								// setformfield(form, "employerWorkPhoneNumber2",
								// createTECUMobNo(jsonObject.get("employment").getAsJsonObject().get("employerExtension2").getAsString(),
								// jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber2").getAsString()));
								setformfield(form, "employerWorkPhoneNumber2",createTECUWorkPhoneNo(jsonObject.get("employment").getAsJsonObject().get("employerExtension2").getAsString(),jsonObject.get("employment").getAsJsonObject().get("employerWorkPhoneNumber2").getAsString()));//#SRP00002 changes
						} catch (Exception e) {
							
						}
					} catch (Exception e) {
						
					}
					// #PKY00007 starts
					try {
						String creditMemDetails = jsonObject.get("additionalDetails").getAsJsonObject()
								.get("anyOtherCreditUnionMember").getAsString();
						if (creditMemDetails.equalsIgnoreCase("Y")) {
							setformfield(form, "otherCreditUnionNameIs", jsonObject.get("additionalDetails")
									.getAsJsonObject().get("otherCreditUnionName").getAsString());
						}

					} catch (Exception e) {
						
					}
					// #PKY00007 ends
				}
				//#SRP00003 Start...
				
				  else if (pdfName.equalsIgnoreCase("LOAN_APPLICATION")) {
					JsonObject loanSummary = new JsonObject();//#MVT00099 changes begins
					JsonObject extraDetails = jsonObject.get("extraDetails").getAsJsonObject();
					JsonObject loanDetails = jsonObject.get("loanDetails").getAsJsonObject();
					JsonObject memberInfo = jsonObject.get("memberInfo").getAsJsonObject();
					String cif = jsonObject.get("cif").getAsString();
					JsonObject filter = new JsonObject();
					filter.addProperty("CustomerId",cif);
					JsonObject data =  db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",filter);
					
					//JsonArray coBorrowerDetails = jsonObject.get("coBorrowerDetails").getAsJsonArray();
					//#SRP00024 Starts
					if (jsonObject.has("summary")) {
						loanSummary = jsonObject.get("summary").getAsJsonObject();
					}
					if (jsonObject.has("loanSummary")) {
						loanSummary = jsonObject.get("loanSummary").getAsJsonObject();
					}//#MVT00099 changes ends
					try {
					      JsonObject coMakersDetails = jsonObject.get("coMakersDetails").getAsJsonObject();
					      try {
								if (coMakersDetails.has("loanBalance")&& !i$outis.$iStrBlank(coMakersDetails.get("loanBalance").getAsString())) {
									setformfield(form, "loan", coMakersDetails.get("loanBalance").getAsString());
								}
							} catch (Exception e) {
								
							}
					      try {
								if (coMakersDetails.has("shareBalance")&& !i$outis.$iStrBlank(coMakersDetails.get("shareBalance").getAsString())) {
									setformfield(form, "shares2", coMakersDetails.get("shareBalance").getAsString());
								}
							} catch (Exception e) {
								
							}
					}catch(Exception e) {
						
					}//#SRP00024 Ends
					try {
						for (int i = 0; i <= filedName.size(); i++) {
					
						fillPDFField(memberInfo, filedName.get(i), form);
						fillPDFField(extraDetails, filedName.get(i), form);
						fillPDFField(loanDetails, filedName.get(i), form);
						fillPDFField(jsonObject, filedName.get(i), form);
						
						}
						}catch(Exception e) {
							
						}
					//MSA starts
					try {
						if (data.has("DateJoinedCu")) {
							String dateJoined = data.get("DateJoinedCu").getAsString();
							setformfield(form, "dateJoinedCu", dateJoined);
						}
						
					}catch(Exception e) {
						
					}
					//MSA ends
//					for(int i=0;i<coBorrowerDetails.size();i++) {
//						JsonObject borrowerDetails = coBorrowerDetails.get(i).getAsJsonObject();
//
//						try {
//							if (jsonObject.has("CustomerFullName")) {
//								setformfield(form, "customer"+i+"FullName", borrowerDetails.get("CustomerFullName").getAsString());
//							}
//						} catch (Exception e) {
//					}	
//						try {
//							if (jsonObject.has("CustomerId")) {
//								setformfield(form, "Customer"+i+"Id", borrowerDetails.get("CustomerId").getAsString());
//							}
//						} catch (Exception e) {
//					}
//						try {
//							if (jsonObject.has("CustomerEmailId")) {
//								setformfield(form, "Customer"+i+"EmailId", borrowerDetails.get("CustomerEmailId").getAsString());
//							}
//						} catch (Exception e) {
//					}
//						try {
//							if (jsonObject.has("CustomerMobileId")) {
//								setformfield(form, "Customer"+i+"MobileId", borrowerDetails.get("CustomerMobileId").getAsString());
//							}
//						} catch (Exception e) {
//					}
//						
//					}
					
					//#MVT000012 Starts
					try {
						String diagnoseDetails = memberInfo.get("homeAddress").getAsString();
						if (diagnoseDetails.length() > 66) {
							setformfieldS(form, "homeAddress",
									memberInfo.get("homeAddress").getAsString().substring(0, 66));
							setformfieldS(form, "homeAddress2", memberInfo.get("homeAddress").getAsString()
									.substring(66, diagnoseDetails.length()));

						} else {
							setformfieldS(form, "homeAddress", memberInfo.get("homeAddress").getAsString());
						}
					} catch (Exception e) {

					}//#MVT000012 ends
					// #SKP00001 Starts 
					//MSA00004 starts
					    try {
					    	if(loanDetails.has("branchDate")&& !i$outis.$iStrBlank(loanDetails.get("branchDate").getAsString())) {
					    		setformfield(form, "date", loanDetails.get("branchDate").getAsString());
					    	}
			           } catch (Exception e) {
						
					    }//MSA00004 ends
					    
					    try {
					    	if(jsonObject.has("cif")&& !i$outis.$iStrBlank(jsonObject.get("cif").getAsString()))
						    setformfield(form, "memberNo", jsonObject.get("cif").getAsString());
					    } catch (Exception e) {
						
					    }
						try {
							if (!i$outis.$iStrBlank(memberInfo.get("martialStatus").getAsString())) {
								if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "M"))
									setformfieldS(form, "Married", "On");

								else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "S"))
									setformfieldS(form, "Single", "On");
								
								else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "D"))
									setformfieldS(form, "divorced", "On");
								
								else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "P"))
									setformfieldS(form, "separated", "On");
								
								else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "C"))//#MVT00007 changes starts 
									setformfieldS(form, "claw", "On");//#MVT00007 Changes ends
							}
						} catch (Exception e) {
							
						}
				     	try {
				     		if (!i$outis.$iStrBlank(memberInfo.get("employmentStatus").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "F")) 
				     				setformfieldS(form, "permanent", "On");
				     			 
				     			 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "T"))
										setformfieldS(form, "temporary", "On");
									
								 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "U"))
										setformfieldS(form, "casual", "On");
									
								 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "S"))
										setformfieldS(form, "selfEmployed", "On");
									
								 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "P"))
										setformfieldS(form, "contract", "On");
				     		 }
						   } catch (Exception e) {
						
					    }
					    try {
					    	if (memberInfo.has("otherIncome")&& !i$outis.$iStrBlank(memberInfo.get("otherIncome").getAsString())) {
							setformfield(form, "otherIncomePerAnnum", memberInfo.get("otherIncome").getAsString());
					    	}
				    	} catch (Exception e) {
						
				    	}
					    //#SRP00022 Starts
					    
					    try {
							if (extraDetails.has("reference1FirstName")|| extraDetails.has("reference1LastName")) {
								StringBuilder referenceFullName = new StringBuilder();
								try {
									if (extraDetails.has("reference1FirstName") && !i$outis.$iStrBlank(extraDetails.get("reference1FirstName").getAsString())) {
										referenceFullName.append(extraDetails.get("reference1FirstName").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (extraDetails.has("reference1LastName") && !i$outis.$iStrBlank(extraDetails.get("reference1LastName").getAsString())) {
										referenceFullName.append(" ");
										referenceFullName.append(extraDetails.get("reference1LastName").getAsString());
									}
								} catch (Exception e) {
									
								}
								setformfield(form, "referencesName1", referenceFullName.toString());		
							}
						}catch(Exception e) {
						}
					    try {
					    	if (i$outis.$iStrBlank(extraDetails.get("reference1ContactNumber").getAsString())) {
							setformfield(form, "contactNo1", "");
					    	}
					    	else{
							setformfield(form, "contactNo1",createTECUMobNo(extraDetails.get("reference1ContactNumberCode").getAsString(),extraDetails.get("reference1ContactNumber").getAsString()));
					            } 
					    }catch (Exception e) {
							
					    }
					    try {
							if (extraDetails.has("reference2FirstName")|| extraDetails.has("reference2LastName")) {
								StringBuilder referenceFullName = new StringBuilder();
								try {
									if (extraDetails.has("reference2FirstName") && !i$outis.$iStrBlank(extraDetails.get("reference2FirstName").getAsString())) {
										referenceFullName.append(extraDetails.get("reference2FirstName").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (extraDetails.has("reference2LastName") && !i$outis.$iStrBlank(extraDetails.get("reference2LastName").getAsString())) {
										referenceFullName.append(" ");
										referenceFullName.append(extraDetails.get("reference2LastName").getAsString());
									}
								} catch (Exception e) {
									
								}
								setformfield(form, "referencesName2", referenceFullName.toString());		
							}
						}catch(Exception e) {
						}
					    try {
					    	if (i$outis.$iStrBlank(extraDetails.get("reference2ContactNumber").getAsString())) {
							setformfield(form, "contactNo2", "");
					    	}
					    	else{
							setformfield(form, "contactNo2",createTECUMobNo(extraDetails.get("reference2ContactNumberCode").getAsString(),extraDetails.get("reference2ContactNumber").getAsString()));
					            } 
					    }catch (Exception e) {
							
					    }
					    try {
					    	if (i$outis.$iStrBlank(memberInfo.get("workPhone").getAsString())) {
							setformfield(form, "telNosWork", "");
					    	}
					    	else{
							setformfield(form, "telNosWork",createTECUMobNo(memberInfo.get("workCode").getAsString(),memberInfo.get("workPhone").getAsString()));
					            } 
					    }catch (Exception e) {
							
					    }
					    //#TKS00006 starts
					    try {
					    	if (memberInfo.has("employer")&& !i$outis.$iStrBlank(memberInfo.get("employer").getAsString())) {
					    		if(i$outis.$iStrFuzzyMatch(memberInfo.get("employer").getAsString(), "OTHER")) {
					    			setformfield(form, "employer", memberInfo.get("employerOther").getAsString());
					    		}else {
					    			setformfield(form, "employer", memberInfo.get("employerDesc").getAsString());
					    		}
					    	}
						} catch (Exception e) {
							
						}
					  //#TKS00006 ends
					    //#SRP00022 Ends
				    	try {
					    	if (i$outis.$iStrBlank(memberInfo.get("homePhone").getAsString())) {
							setformfield(form, "telNosHome", "");
					    	}
					    	else{
							setformfield(form, "telNosHome",createTECUMobNo(memberInfo.get("homeCode").getAsString(),memberInfo.get("homePhone").getAsString()));
					            } 
					    }catch (Exception e) {
							
					    }
				    	//#SRP00025 Starts changes
				    	try {
							if (extraDetails.has("loanOfficerDesc")&& !i$outis.$iStrBlank(extraDetails.get("loanOfficerDesc").getAsString())) {
								setformfield(form, "PrintName", extraDetails.get("loanOfficerDesc").getAsString());
							}
						} catch (Exception e) {
							
						}
//				    	try {
//							if (jsonObject.has("cif")&& !i$outis.$iStrBlank(jsonObject.get("cif").getAsString())) {
//								setformfield(form, "Member No 1", jsonObject.get("cif").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
//				    	try {
//							if (loanDetails.has("totalShareBalance")&& !i$outis.$iStrBlank(loanDetails.get("totalShareBalance").getAsString())) {
//								setformfield(form, "Shares 1", loanDetails.get("totalShareBalance").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
				    	try {
							if (loanSummary.has("firstPaymentDate")&& !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
								String frstPaymentDate = loanSummary.get("firstPaymentDate").getAsString();
								setformfield(form, "firstInstalmentDate", loanSummary.get("firstPaymentDate").getAsString());
							}
						} catch (Exception e) {
							
						}
				    	try {
							if (loanDetails.has("maturityDate")&& !i$outis.$iStrBlank(loanDetails.get("maturityDate").getAsString())) {
								String maturityDate = loanDetails.get("maturityDate").getAsString();
								setformfield(form, "MaturityDate", loanDetails.get("maturityDate").getAsString());
								
							}
						} catch (Exception e) {
							
						}
				    	//MSA starts	//#MVT00113 changes starts
						/*try {
							if (loanDetails.has("maxLoanAmount")&& !i$outis.$iStrBlank(loanDetails.get("maxLoanAmount").getAsString())) {
								double number = loanDetails.get("maxLoanAmount").getAsDouble();
								if (number > 1000) {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("#0,000.00");
									String amountCom = formatter.format(d1);
									setformfield(form, "loanAmount", amountCom);
								}
								else {
									String amtCom = Double.toString(number);
									setformfield(form, "loanAmount", amtCom);
								}
							}
						} catch (Exception e) {
							
						}*/
				    	try {
				    		if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
				    			double number = loanDetails.get("amount").getAsDouble();
								if (number > 1000) {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("#0,000.00");
									String amountCom = formatter.format(d1);
									setformfield(form, "loanAmount", amountCom);
								}
								else {
									String amtCom = Double.toString(number);
									setformfield(form, "loanAmount", amtCom);
								}
							}
				    	} catch(Exception e) {
				    		
				    	}//#MVT00113 changes ends
				    	//MSA00014 starts
						try {
							if (loanDetails.has("emi")&& !i$outis.$iStrBlank(loanDetails.get("emi").getAsString())) {
								double number = loanDetails.get("emi").getAsDouble();
								String amountCom = null;
								if (number > 1000) {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00");
									amountCom = formatter.format(d1);
									
								}
								else {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00"); //#MVT00113 changes
									amountCom = formatter.format(d1);
								}
								setformfield(form, "installment", amountCom);
							}//MSA00014 ends
						} catch (Exception e) {
							
						}// MSA ends
				    	try {
							if (loanDetails.has("emi")&& !i$outis.$iStrBlank(loanDetails.get("emi").getAsString())) {
								setformfield(form, "installment1", "month");
							}
						} catch (Exception e) {
							
						}
				    	try {
							if (loanDetails.has("tenor")&& !i$outis.$iStrBlank(loanDetails.get("tenor").getAsString())) {
								setformfield(form, "term", loanDetails.get("tenor").getAsString());
							}
						} catch (Exception e) {
							
						}
				    	try {
							if (loanDetails.has("intrestRate")&& !i$outis.$iStrBlank(loanDetails.get("intrestRate").getAsString())) {
								String interestRate = loanDetails.get("intrestRate").getAsString() + " % APR";
								setformfield(form, "rateOfIntrest", interestRate);
							}
						} catch (Exception e) {
							
						}
				    	//SRI00036 Starts
				    	try {
							if (loanDetails.has("purposeDescription")&& !i$outis.$iStrBlank(loanDetails.get("purposeDescription").getAsString())) {
								String  loanPuposeDesc =  loanDetails.get("purposeDescription").getAsString();
								setformfield(form, "loanPurpose", loanPuposeDesc);		
							}
						}catch(Exception e) {
						}  //SRI00036 ends
//				    	try {
//							if (loanDetails.has("linkages")&& !i$outis.$iStrBlank(loanDetails.get("linkages").getAsString())) {
//								setformfield(form, "rateOfIntrest", loanDetails.get("linkages").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
				    	try {
							if (loanDetails.has("linkages")&& !i$outis.$iStrBlank(loanDetails.get("linkages").getAsString())) {
								double number = loanDetails.get("linkages").getAsDouble();
								String amountCom = null;
								if (number > 1000) {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00");
									amountCom = formatter.format(d1);
									
								}
								else {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00"); //#MVT00113 changes
									amountCom = formatter.format(d1);
								}
								setformfield(form, "detailsOfCollateral 1", amountCom);
							}
						} catch (Exception e) {
							
						}
				    	try {
							if (loanDetails.has("branchDate")&& !i$outis.$iStrBlank(loanDetails.get("branchDate").getAsString())) {
								setformfield(form, "meetingDate", loanDetails.get("branchDate").getAsString());
							}
						} catch (Exception e) {
							
						}
				    	try {
							if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
								double number = loanDetails.get("amount").getAsDouble();
								String amountCom = null;
								if (number > 1000) {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00");
									amountCom = formatter.format(d1);
									
								}
								else {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00"); //#MVT00113 changes
									amountCom = formatter.format(d1);
								}
								setformfield(form, "dollar", amountCom);
							}
						} catch (Exception e) {
							
						}
				    	try {
							if (loanSummary.has("firstPaymentDate")&& !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
								String dueDay = loanSummary.get("firstPaymentDate").getAsString().split("-")[2];
								setformfield(form, "dateDue", dueDay);
							}
						} catch (Exception e) {
							
						}
						try {
							if (extraDetails.has("isShares")
									&& i$outis.$iStrFuzzyMatch(extraDetails.get("isShares").getAsString(), "true")) {
								setformfield(form, "sharesCharacter", "X");
							} else if (loanDetails.has("securityType")
									&& i$outis.$iStrFuzzyMatch(loanDetails.get("securityType").getAsString(), "true")) {
								setformfield(form, "sharesCharacter", "X");
							}
						} catch (Exception e) {

						}
				    	try {
								setformfield(form, "undefined9", "SYSTEM-AUTH");
						} catch (Exception e) {
							
						}
//				    	String date = i$ResM.getOnlydate(new Date());
//				    	try {
//								setformfield(form, "Date_2", date);
//						} catch (Exception e) {
//							
//						}
				    	//MSA00016 starts
				    	try {
							if (loanDetails.has("branchDate")&& !i$outis.$iStrBlank(loanDetails.get("branchDate").getAsString())) {
								setformfield(form, "Date_2", loanDetails.get("branchDate").getAsString());
							}
						} catch (Exception e) {
							
						}//MSA00016 ends
				    	//#SRP00025 Ends changes
				    	try {
					    	if (i$outis.$iStrBlank(memberInfo.get("primaryMobile").getAsString())) {
							setformfield(form, "telNosCell1", "");
						    }
					    	else{
							setformfield(form, "telNosCell1",createTECUMobNo(memberInfo.get("primaryCode").getAsString(),memberInfo.get("primaryMobile").getAsString()));
					            }
					    }catch (Exception e) {
							
					        }
				    	try {
					    	if (i$outis.$iStrBlank(memberInfo.get("secondaryMobile").getAsString())) {
							setformfield(form, "telNosCell2", "");
					    	}
					    	else{
							setformfield(form, "telNosCell2",createTECUMobNo(memberInfo.get("secondaryCode").getAsString(),memberInfo.get("secondaryMobile").getAsString()));
					            }
					    } catch (Exception e) {
					    	
					    }
						setformfield(form, "signature1_es_:signer:signature", "Digital App Confirmation");
                        
				    	try {
							if (extraDetails.has("purposeLoanDesc")|| extraDetails.has("purposeDesc")) {
								StringBuilder loanPuposeDesc = new StringBuilder();
								/*try {
									if (extraDetails.has("purposeLoanDesc") && !i$outis.$iStrBlank(extraDetails.get("purposeLoanDesc").getAsString())) {
										loanPuposeDesc.append(extraDetails.get("purposeLoanDesc").getAsString());
									}
								} catch (Exception e) {
									
								}*/
								try {
									if (extraDetails.has("purposeDesc") && !i$outis.$iStrBlank(extraDetails.get("purposeDesc").getAsString())) {
//										loanPuposeDesc.append(" - "); //#MVT00088 Changes
										loanPuposeDesc.append(extraDetails.get("purposeDesc").getAsString());
									}
								} catch (Exception e) {
									
								}
								setformfield(form, "PURPOSE OF LOAN", loanPuposeDesc.toString());		
							}
						}catch(Exception e) {
						}
				    	try {
							if (extraDetails.has("Otherformsecurity")&& !i$outis.$iStrBlank(extraDetails.get("Otherformsecurity").getAsString())) {
								setformfield(form, "other", extraDetails.get("Otherformsecurity").getAsString());
							}
						} catch (Exception e) {
							
						}
				    	//MSA00014 starts
						try {
							if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
								double number = loanDetails.get("amount").getAsDouble();
								String amountCom = null;
								if (number > 1000) {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00");
									amountCom = formatter.format(d1);
								}
								else {
									Double d1 = Double.valueOf(number);
									NumberFormat formatter = new DecimalFormat("####,###,###.00");
									amountCom = formatter.format(d1);
								}
								setformfield(form, "dollars", amountCom);

							}
						} catch (Exception e) {
							
						}// MSA00014 ends
//				    	try {
//							if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
//								setformfield(form, "dollars", loanDetails.get("amount").getAsString());
//							}
//						} catch (Exception e) {
//							
//						}
						//MSA starts
				    	try {
							if (loanDetails.has("amountInWords")&& !i$outis.$iStrBlank(loanDetails.get("amountInWords").getAsString())) {
								String amtWrd = loanDetails.get("amountInWords").getAsString();
								String[] amtWord = amtWrd.split("_");
								String amtWord1 = amtWord[0];
								String amtWord2 = amtWord[1];
								int length = amtWrd.length();
								if (length <= 85) {
									setformfield(form, "applyForLoan", amtWord1 + " And " + amtWord2);
								} else {
									setformfield(form, "applyForLoan", amtWord1);
									setformfield(form, "applyForLoan_2", " And "+amtWord2);
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}//MSA ends
				    	try {
					    	if (memberInfo.has("DOB")) {
							String [] DOB = getClicoDateFormat(memberInfo.get("DOB").getAsString()).split("/");
							String month = DOB[0];
							String day = DOB[1];
							String year = DOB[2];
							setformfield(form, "DOB_day",day);
							setformfield(form, "DOB_Month",month);
							setformfield(form, "DOB_Year",year);
							};
				        } catch (Exception e) {
				        	
				        }
				    	
					// #SKP00001 Ends
				    // #SRP00006 Starts
					try {        
						if (extraDetails.has("promotionMedium") && !i$outis.$iStrBlank(extraDetails.get("promotionMedium").getAsString()) ) {
							if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "NEWS"))
								setformfieldS(form, "isNewspaper", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "RADIO"))
								setformfieldS(form, "isRadio", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "TV"))
								setformfieldS(form, "isTelevision", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "DIGAD"))
								setformfieldS(form, "isDigitalScreens", "On");						
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "REL"))
								setformfieldS(form, "isRelative", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "WEB"))
								setformfieldS(form, "isWebsite", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "SM"))
								setformfieldS(form, "isSocialMedia", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "FRND"))
								setformfieldS(form, "isFriend", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "COWRK"))
								setformfieldS(form, "isCoWorker", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "TM"))
								setformfieldS(form, "isTecuMembers", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "TS"))
								setformfieldS(form, "isTecuStaff", "On");
							else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "EXPO"))
								setformfieldS(form, "isExpoTradeshow", "On");
						}
					}catch (Exception e) {
						
					}
					//#SRP00013 Start
					try {        
						  {	//MVT00004 changes starts
							if (i$outis.$iStrFuzzyMatch(extraDetails.get("isVehicle").getAsString(), "true"))
								setformfieldS(form, "billOfSale", "On");
							if (i$outis.$iStrFuzzyMatch(extraDetails.get("isInsurance").getAsString(), "true"))
								setformfieldS(form, "comakerInsurance", "On");
							if (i$outis.$iStrFuzzyMatch(extraDetails.get("isPropertyLand").getAsString(), "true"))
								setformfieldS(form, "mortgage", "On");
							if (i$outis.$iStrFuzzyMatch(extraDetails.get("isShares").getAsString(), "true"))
								setformfieldS(form, "sharesCharacter", "On");						
							if (i$outis.$iStrFuzzyMatch(extraDetails.get("isUnits").getAsString(), "true"))
								setformfieldS(form, "units", "On");
						}	//MVT00004 changes ends
					}catch (Exception e) {
						
					} //#SRP00013 Ends
				} else if(pdfName.equalsIgnoreCase("PROMISSORY NOTE")) {
					promissoryPdfValueSetter(jsonObject, pdfName, form, stamp , base64);
				} else if(pdfName.equalsIgnoreCase("MEMBER DISCLOSURE STATEMENT")) {
					disclosurePdfValueSetter(jsonObject, pdfName, form, stamp , base64);
				}else if (pdfName.equalsIgnoreCase("Application_For_Line_Of_Credit")) {
					LOCPdfValueSetter(jsonObject, pdfName, form, stamp , base64,filedName);
				}
				// #SRP00006 Ends
				  else if (pdfName.equalsIgnoreCase("Terms_And_Conditions_Fixed_Deposits ")) {
					
					JsonObject tranDetail = jsonObject.get("trnData").getAsJsonObject();
					try {
						if (tranDetail.has("dateOfIssue")&& !i$outis.$iStrBlank(tranDetail.get("dateOfIssue").getAsString())) {
//							setformfield(form, "date",tranDetail.get("dateOfIssue").getAsString());Date
							setformfield(form, "Date",tranDetail.get("dateOfIssue").getAsString());
						}
					} catch (Exception e) {
						
					}  //#SRP00004 Ends
					try {
						if (tranDetail.has("CustomerFullName")&& !i$outis.$iStrBlank(tranDetail.get("CustomerFullName").getAsString())) {
//							setformfield(form, "membersName",tranDetail.get("CustomerFullName").getAsString());
							setformfield(form, "Members Name",tranDetail.get("CustomerFullName").getAsString());

						}
					} catch (Exception e) {
						
					} 
					//#TKS00002 starts
					
					try {
						addImage(stamp, form, "Qr_code_1", base64);
					}catch(Exception e) {
						
					}
					
					try {
						if (tranDetail.has("payInAccNo")&& !i$outis.$iStrBlank(tranDetail.get("payInAccNo").getAsString())) {
//							setformfield(form, "accountNumber",tranDetail.get("payInAccNo").getAsString());  //SKP00010 Changes
							setformfield(form, "Account Number",tranDetail.get("payInAccNo").getAsString());
						}
					} catch (Exception e) {
						
					}
					//#TKS00002 ends
				}   // #SRP00003 Ends...
				//#SRP00017 Start
				  else if (pdfName.equalsIgnoreCase("FD_Confirmation_Letter")) {
					  JsonObject trnData = jsonObject.get("trnData").getAsJsonObject();
					  try {
							for (int i = 0; i <= filedName.size(); i++) {
							fillPDFField(trnData, filedName.get(i), form);
							}
							}catch(Exception e) {
								
							}
					  try {
							if (jsonObject.has("applicationId")&& !i$outis.$iStrBlank(jsonObject.get("applicationId").getAsString())) {
								setformfield(form, "applicationId",jsonObject.get("applicationId").getAsString());
							}
						} catch (Exception e) {
							
						}
					  try {
							if (trnData.has("CustomerFullName")&& !i$outis.$iStrBlank(trnData.get("CustomerFullName").getAsString())) {
								setformfield(form, "lastName",trnData.get("CustomerFullName").getAsString());
							}
						} catch (Exception e) {}
					  
					  try {	//#MVT00051 changes starts
						  if(trnData.has("initialTDAmt")&& !i$outis.$iStrBlank(trnData.get("initialTDAmt").getAsString())) {
							  	String convertedString = new DecimalFormat("#,###.00").format(Double.parseDouble(trnData.get("initialTDAmt").getAsString()));
								setformfield(form, "initialTDAmt","$"+convertedString);
						  }
					  }catch(Exception e) {
						  e.printStackTrace();
					  }//#MVT00051 changes ends
					  try {
							if (trnData.has("acCls")|| trnData.has("tenor")) {
								StringBuilder benFullAddress = new StringBuilder();
								try {
									if (trnData.has("acCls") && !i$outis.$iStrBlank(trnData.get("acCls").getAsString())) {
										benFullAddress.append(trnData.get("acCls").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (trnData.has("tenor") && !i$outis.$iStrBlank(trnData.get("tenor").getAsString())) {
										benFullAddress.append(" - ");
										benFullAddress.append(trnData.get("tenor").getAsString());
									}
								} catch (Exception e) {
									
								}
								setformfield(form, "tenor", benFullAddress.toString());		
							}
						}catch(Exception e) {
						}
					  try {
					    	 String currentDate = i$outis.getDate();
							 setformfield(form, "date", trnData.get("dateOfIssue").getAsString());   //#PKY00045 changes
							    
			           } catch (Exception e) {
						
					    }
				  }//#SRP00017 Ends
				  else if (pdfName.equalsIgnoreCase("Advance_Protector_Deduction_Form")) {        // #SRP00005 Start
					  JsonObject cherrypicks = jsonObject.get("cherrypicks").getAsJsonObject();
					  try {
					    	 String currentDate = i$outis.getDate();
							 setformfield(form, "date", currentDate);
							    
			           } catch (Exception e) {
						
					    }
						 try {
					     		if (!i$outis.$iStrBlank(cherrypicks.get("deductPremium").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(cherrypicks.get("deductPremium").getAsString(), "SingleCoverage")) 
					     				setformfieldS(form, "singleCoverage", "Yes"); 
					     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("deductPremium").getAsString(), "JointCoverage"))
										setformfieldS(form, "jointCoverage", "Yes");
					     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("deductPremium").getAsString(), "SingleCreditDisablility"))
										setformfieldS(form, "singleCreditDisability", "Yes");
					     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("deductPremium").getAsString(), "JointCreditDisablility"))
										setformfieldS(form, "jointCreditDisability", "Yes");
					     		 }
							   } catch (Exception e) {
						    }
					    try {
							if (jsonObject.has("CustomerFullName")&& !i$outis.$iStrBlank(jsonObject.get("CustomerFullName").getAsString())) {
								setformfield(form, "memberName", jsonObject.get("CustomerFullName").getAsString());
							}
						} catch (Exception e) {
					}	
					  try {
							if (jsonObject.has("cif")&& !i$outis.$iStrBlank(jsonObject.get("cif").getAsString())) {
								setformfield(form, "memberNumber", jsonObject.get("cif").getAsString());
							}
						} catch (Exception e) {
					}	
					  
				  }else if (pdfName.equalsIgnoreCase("Advanced_Protector_Insurance_Enrollment_Form")) {
					  JsonObject cherrypicks = jsonObject.get("cherrypicks").getAsJsonObject();
					  try {
							for (int i = 0; i <= filedName.size(); i++) {
							fillPDFField(cherrypicks, filedName.get(i), form);
							}
							}catch(Exception e) {	
							}
					  try {
					    	 String currentDate = i$outis.getDate();
							 setformfield(form, "date", currentDate);
							    
			           } catch (Exception e) {
					    }
					  try {
				     		if (!i$outis.$iStrBlank(cherrypicks.get("insuredsGender").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(cherrypicks.get("insuredsGender").getAsString(), "M")) 
				     				setformfieldS(form, "gender_M", "On");
				     			 
				     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("insuredsGender").getAsString(), "F"))
									setformfieldS(form, "gender_F", "On");
				     		 }
						   } catch (Exception e) {
						
					    }
					  try {
				     		if (!i$outis.$iStrBlank(cherrypicks.get("jointInsuredsGender").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(cherrypicks.get("jointInsuredsGender").getAsString(), "M")) 
				     				setformfieldS(form, "gender_M1", "On");
				     			 
				     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("jointInsuredsGender").getAsString(), "F"))
									setformfieldS(form, "gender_F1", "On");
				     		 }
						   } catch (Exception e) {		
					    }
					  try {
				     		if (!i$outis.$iStrBlank(cherrypicks.get("insuredsIdentification").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(cherrypicks.get("insuredsIdentification").getAsString(), "ID")) 
				     				setformfieldS(form, "ID", "On");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("insuredsIdentification").getAsString(), "DP"))
									setformfieldS(form, "DP", "On");
				     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("insuredsIdentification").getAsString(), "PP"))
									setformfieldS(form, "PP", "On");
				     		 }
						   } catch (Exception e) {
						
					    }
						try {
							if (!i$outis.$iStrBlank(cherrypicks.get("jointInsuredsIdentification").getAsString())) {
								if (i$outis.$iStrFuzzyMatch(cherrypicks.get("jointInsuredsIdentification").getAsString(), "ID"))
									setformfieldS(form, "ID_1", "On");
								else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("jointInsuredsIdentification").getAsString(), "DP"))
									setformfieldS(form, "DP_1", "On");
								else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("jointInsuredsIdentification").getAsString(), "PP"))
									setformfieldS(form, "PP_1", "On");
							}
						} catch (Exception e) {

						}
					  try {
				     		if (!i$outis.$iStrBlank(cherrypicks.get("disabilityCoverageWages").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(cherrypicks.get("disabilityCoverageWages").getAsString(), "Y")) 
				     				setformfieldS(form, "disabilityCoverageWages_Yes", "Yes");				     			 
				     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("disabilityCoverageWages").getAsString(), "N"))
									setformfieldS(form, "disabilityCoverageWages_No", "Yes");
				     		 }
						   } catch (Exception e) {
						
					    }
					  try {
				     		if (!i$outis.$iStrBlank(cherrypicks.get("disabilityCoverageBenefits").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(cherrypicks.get("disabilityCoverageBenefits").getAsString(), "Y")) 
				     				setformfieldS(form, "disabilityCoverageBenefits_Yes", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(cherrypicks.get("disabilityCoverageBenefits").getAsString(), "N"))
									setformfieldS(form, "disabilityCoverageBenefits_No", "Yes");
				     		 }
						   } catch (Exception e) {						
					    }
				  }
				  else if (pdfName.equalsIgnoreCase("Statement_OF_Affairs")) {
					  JsonObject soaInfo = jsonObject.get("soaInfo").getAsJsonObject();
					  try {
							for (int i = 0; i <= filedName.size(); i++) {
							fillPDFField(soaInfo, filedName.get(i), form);
							}
							}catch(Exception e) {
								
							}
				  }// #SRP00005 ends
				   // #SKP00002 Starts
				  else if (pdfName.equalsIgnoreCase("Family_Idemnity_Plane_Deduction_Form")) {
					//#PKY00036 starts
					  ////#PKY00059 starts
					  try {
						  if(jsonObject.has("fipEnrolment")) {	//#MVT00020 Changes starts
							  JsonObject fipEnrolment =jsonObject.get("fipEnrolment").getAsJsonObject();
							  if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "A")) {
								  setformfieldS(form, "Paln_A", "x");
							  }else  if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "B")) {
								  setformfieldS(form, "Paln_B", "x");
							  }else  if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "C")) {
								  setformfieldS(form, "Paln_C", "x");
							  }else if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "D")) {
								  setformfieldS(form, "Paln_D", "x");
							  }else  if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "E")) {
								  setformfieldS(form, "Paln_E", "x");
							  }else  if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "F")) {
								  setformfieldS(form, "Paln_F", "x");
							  }else  if(i$outis.$iStrFuzzyMatch(fipEnrolment.get("cunaPlanType").getAsString(), "G")) {
								  setformfieldS(form, "Paln_G", "x");
							  }
						  }
					  }catch(Exception e) {
						  
					  }	//#MVT00020 Changes ends
					  //#PKY00059 ends
					  JsonObject deductionData = new JsonObject();
					   try {       //#SRM00008 changes
						   JsonObject fipDeduction = jsonObject.get("fipDeduction").getAsJsonObject();;  
					  } catch(Exception e) {
						  
					  }
					  if(jsonObject.has("fcipData"))
						  deductionData = jsonObject.get("fcipData").getAsJsonObject();
					  else
						  deductionData = jsonObject.get("fipDeduction").getAsJsonObject();
					  
					  try {
							for (int i = 0; i <= filedName.size(); i++) {
						
							fillPDFField(deductionData, filedName.get(i), form);
							}
						}catch(Exception e) {
								
						}//#PKY00036 ends
					  //#SRP00025 Starts Changes	//#MVT00022 Chnages starts
					  try {        
							if (i$outis.$iStrFuzzyMatch(deductionData.get("isShareAccount").getAsString(), "true"))
								setformfieldS(form, "DeductFIP_Share Account", "X");
						} catch (Exception e) {
						}
					  
						try {
							if (jsonObject.has("fipDeduction")) { // #PKY00059 changes
								if (i$outis.$iStrFuzzyMatch(deductionData.get("isCriticalIllnessRider").getAsString(),
										"true"))
									setformfieldS(form, "DeductFIP_Critical Illness Rider", "X");
							}
						} catch (Exception e) {
						}
						try {
							if (i$outis.$iStrFuzzyMatch(deductionData.get("isFCIP").getAsString(), "true"))
								setformfieldS(form, "DeductFIP_FCIP", "X");
					  }catch (Exception e) {
						
					  }//#SRP00025 Ends changes		//#MVT00022 Chnages ends
//						try {        
//							  JsonObject fipDeduction = jsonObject.get("fipDeduction").getAsJsonObject(); //#SRM00008 changes
//							if (fipDeduction.has("date") && !i$outis.$iStrBlank(fipDeduction.get("date").getAsString()))
//								setformfieldS(form, "effectiveDateOfInsurance", fipDeduction.get("date").getAsString());
//						} catch (Exception e) {
//						}
						
						try {
							addImage(stamp, form, "Qr_code_1", base64);
						}catch(Exception e) {
							
						}
						
					  try {//#PKY00036 starts
						  JsonObject nameDetails = new JsonObject();
							if (deductionData.has("firstName")|| deductionData.has("middleName")|| deductionData.has("lastName")) 
								nameDetails =deductionData;
							else
								nameDetails = jsonObject.get("personalInfo").getAsJsonObject();    
								
								if(nameDetails.has("firstName")|| nameDetails.has("middleName")|| nameDetails.has("lastName")) {
									StringBuilder strfullname = new StringBuilder();
									try {
										if (nameDetails.has("firstName") && !i$outis.$iStrBlank(nameDetails.get("firstName").getAsString())) {
											strfullname.append(nameDetails.get("firstName").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (nameDetails.has("middleName") && !i$outis.$iStrBlank(nameDetails.get("middleName").getAsString())) {
											strfullname.append(" ");
											strfullname.append(nameDetails.get("middleName").getAsString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (nameDetails.has("lastName") && !i$outis.$iStrBlank(nameDetails.get("lastName").getAsString())) {
											strfullname.append(" ");
											strfullname.append(nameDetails.get("lastName").getAsString());
										}
									} catch (Exception e) {
										
									} //#PKY00036 ends
									setformfield(form, "memberName", strfullname.toString());
								}
							
						} catch (Exception e) {
							
						}
					  } else if (pdfName.equalsIgnoreCase("Family_Critical_Illness_Plane_Enrolment_Form")) {
					  JsonObject fcipData = jsonObject.get("fcipData").getAsJsonObject();
					  JsonObject fcipDesignation = jsonObject.get("fcipDesignationOfBeneficiaries").getAsJsonObject();//#SRP00028 starts
					  try {

							if (i$outis.$iStrBlank(fcipDesignation.get("telephoneContact").getAsString()))
								setformfield(form, "TelephoneNumber", "");
							else
								setformfield(form, "TelephoneNumber",
										createTECUMobNo(fcipDesignation.get("telephoneContactExtension").getAsString(),
												fcipDesignation.get("telephoneContact").getAsString()));

						} catch (Exception e) {

						}
					  try {
						  if(fcipDesignation.has("name")&& !i$outis.$iStrBlank(fcipDesignation.get("name").getAsString()))
							  setformfield(form, "name", fcipDesignation.get("name").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipDesignation.has("age")&& !i$outis.$iStrBlank(fcipDesignation.get("age").getAsString()))
							  setformfield(form, "age", fcipDesignation.get("age").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipDesignation.has("address")&& !i$outis.$iStrBlank(fcipDesignation.get("address").getAsString()))
							  setformfield(form, "address", fcipDesignation.get("address").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipDesignation.has("relationPrimaryInsured")&& !i$outis.$iStrBlank(fcipDesignation.get("relationPrimaryInsured").getAsString()))
							  setformfield(form, "relationPrimaryInsured", fcipDesignation.get("relationPrimaryInsured").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipDesignation.has("trusteeName")&& !i$outis.$iStrBlank(fcipDesignation.get("trusteeName").getAsString()))
							  setformfield(form, "trusteeName", fcipDesignation.get("trusteeName").getAsString());
						  } catch (Exception e) {
							  
						  }//#SRP00028 Ends
					  try {
						  if (!i$outis.$iStrBlank(fcipData.get("familyCriticalIllnessPlanCertificate").getAsString())) {
							  if (i$outis.$iStrFuzzyMatch(fcipData.get("familyCriticalIllnessPlanCertificate").getAsString(), "Y")) 
								  setformfieldS(form, "familyCriticalIllnessPlanCertificate_Yes", "Yes");			     			 
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("familyCriticalIllnessPlanCertificate").getAsString(), "N"))
								  setformfieldS(form, "familyCriticalIllnessPlanCertificate_No", "No");
							  }
						  } catch (Exception e) {						
							  
						  }
					  try {
						  if (!i$outis.$iStrBlank(fcipData.get("enrolledOnAnotherFamilyCritcalIllnessPlan").getAsString())) {
							  if (i$outis.$iStrFuzzyMatch(fcipData.get("enrolledOnAnotherFamilyCritcalIllnessPlan").getAsString(), "Y")) 
								  setformfieldS(form, "enrolledOnAnotherFamilyCritcalIllnessPlan_Yes", "Yes");			     			 
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("enrolledOnAnotherFamilyCritcalIllnessPlan").getAsString(), "N"))
								  setformfieldS(form, "enrolledOnAnotherFamilyCritcalIllnessPlan_No", "No");
							  }
						  } catch (Exception e) {						
							  
						  }
					  try {
						  if (fcipData.has("gender")) {
							  if (i$outis.$iStrFuzzyMatch(fcipData.get("gender").getAsString(), "M"))
								  setformfieldS(form, "gender_M", "Male");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("gender").getAsString(), "F"))
								  setformfieldS(form, "gender_F", "No");
							  }
						  } catch (Exception e) {
							  
						  }
					  try { //#SRP00040 Starts
						  if (fcipData.has("dob") && !i$outis.$iStrBlank(fcipData.get("dob").getAsString())) { //#MVT00018 Changes starts
							  String[] DOB = getClicoDateFormat(fcipData.get("dob").getAsString()).split("/");
							  String year = DOB[2];
							  String month = DOB[0];
							  String day = DOB[1];
							  String cunaBen1Dob = new StringBuilder(day+"/").append(month).append("/"+year).toString();
							  setformfieldS(form, "dob", cunaBen1Dob);
						  }
					  }catch(Exception e) {//#MVT00018 Changes ends
						  
					  }//#SRP00040 Ends
					  try {
						  if (!i$outis.$iStrBlank(fcipData.get("identification").getAsString())) {  //#SRP00016 start Changes
							  if (i$outis.$iStrFuzzyMatch(fcipData.get("identification").getAsString(), "NationalId"))
								  setformfieldS(form, "Identification_ID Card", "ID Card");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("identification").getAsString(), "National Id"))
								  setformfieldS(form, "Identification_ID Card", "ID Card");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("identification").getAsString(), "DriversPermit"))
								  setformfieldS(form, "Identification", "DP");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("identification").getAsString(), "Driver's Permit"))
								  setformfieldS(form, "Identification", "DP");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("identification").getAsString(), "Passport"))
								  setformfieldS(form, "Identification_Passport", "Passport");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("identification").getAsString(), "BirthCertificate"))
								  setformfieldS(form, "Identification_BirthCertificate", "Birth Certificate"); //#SRP00016 ends changes
							  }
						  } catch (Exception e) {
							  
						  }
					  try {
						  if (!i$outis.$iStrBlank(fcipData.get("proofOfAdress").getAsString())) {  //#SRP00016 start Changes
							  if (i$outis.$iStrFuzzyMatch(fcipData.get("proofOfAdress").getAsString(), "UtilityBill"))
								  setformfieldS(form, "ProofOfAddress_UtilityBil", "Utility Bill");//MSA starts
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("proofOfAdress").getAsString(), "Landline Bill"))
								  setformfieldS(form, "ProofOfAddress_UtilityBil", "Utility Bill");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("proofOfAdress").getAsString(), "Electricity Bill"))
								  setformfieldS(form, "ProofOfAddress_UtilityBil", "Utility Bill");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("proofOfAdress").getAsString(), "Wasa Bill"))
								  setformfieldS(form, "ProofOfAddress_UtilityBil", "Utility Bill");
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("proofOfAdress").getAsString(), "Tecu Statement"))
								  setformfieldS(form, "ProofOfAddress_Others", "Other");//MSA ends
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("proofOfAdress").getAsString(), "Other"))
								  setformfieldS(form, "ProofOfAddress_Others", "Other"); //#SRP00016 ends changes
							  }
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("organizationCreditUnion")&& !i$outis.$iStrBlank(fcipData.get("organizationCreditUnion").getAsString()))
							  setformfield(form, "organizationCreditUnion", fcipData.get("organizationCreditUnion").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("membershipNo")&& !i$outis.$iStrBlank(fcipData.get("membershipNo").getAsString()))
							  setformfield(form, "membershipNo", fcipData.get("membershipNo").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("residentialAdress")&& !i$outis.$iStrBlank(fcipData.get("residentialAdress").getAsString()))
							  setformfield(form, "residentialAdress", fcipData.get("residentialAdress").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("mailingAdress")&& !i$outis.$iStrBlank(fcipData.get("mailingAdress").getAsString()))
							  setformfield(form, "mailingAdress", fcipData.get("mailingAdress").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("telephoneHome")&& !i$outis.$iStrBlank(fcipData.get("telephoneHome").getAsString()))
							  setformfield(form, "telephoneHome", fcipData.get("telephoneHome").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("telephoneWork")&& !i$outis.$iStrBlank(fcipData.get("telephoneWork").getAsString()))
							  setformfield(form, "telephoneWork", fcipData.get("telephoneWork").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("telephoneMobile")&& !i$outis.$iStrBlank(fcipData.get("telephoneMobile").getAsString()))
							  setformfield(form, "telephoneMobile", fcipData.get("telephoneMobile").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("emailId")&& !i$outis.$iStrBlank(fcipData.get("emailId").getAsString()))
							  setformfield(form, "emailId", fcipData.get("emailId").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("primaryInsuredBenefitOfAmount")&& !i$outis.$iStrBlank(fcipData.get("primaryInsuredBenefitOfAmount").getAsString()))
							  setformfield(form, "bnefitOfAmount", fcipData.get("primaryInsuredBenefitOfAmount").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("primaryInsuredPremiumDue")&& !i$outis.$iStrBlank(fcipData.get("primaryInsuredPremiumDue").getAsString()))
							  setformfield(form, "premiumDue", fcipData.get("primaryInsuredPremiumDue").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(fcipData.has("totalPremium")&& !i$outis.$iStrBlank(fcipData.get("totalPremium").getAsString()))
							  setformfield(form, "totalPremiumWithApplication", fcipData.get("totalPremium").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if (fcipData.has("firstName")&& !i$outis.$iStrBlank(fcipData.get("firstName").getAsString())) {
							  setformfield(form, "firstName", fcipData.get("firstName").getAsString());
							  }
						  } catch (Exception e) {
							  
						  }	
					  try {
						  if (fcipData.has("middleName")&& !i$outis.$iStrBlank(fcipData.get("middleName").getAsString())) {
							  setformfield(form, "middleName", fcipData.get("middleName").getAsString());
							  }
						  } catch (Exception e) {
							  
						  }
					  try {
						  if (fcipData.has("lastName")&& !i$outis.$iStrBlank(fcipData.get("lastName").getAsString())) {
							  setformfield(form, "lastName", fcipData.get("lastName").getAsString());
							  }
						  } catch (Exception e) {
							  
						  }
					  try {
						  if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithCancer").getAsString())) {
							  if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithCancer").getAsString(), "Y")) 
								  setformfieldS(form, "diagnosedWithCancer_Y0", "Yes");	
							  else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithCancer").getAsString(), "N"))
								  setformfieldS(form, "diagnosedWithCancer_N0", "No");
							  }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithParalysis").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithParalysis").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithParalysis_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithParalysis").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithParalysis_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithHiv").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithHiv").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithHiv_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithHiv").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithHiv_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithHeart").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithHeart").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithHeart_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithHeart").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithHeart_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithMajor").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithMajor").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithMajor_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithMajor").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithMajor_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithHeartCondition").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithHeartCondition").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithHeartCondition_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithHeartCondition").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithHeartCondition_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithStroke").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithStroke").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithStroke_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithStroke").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithStroke_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithComa").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithComa").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithComa_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithComa").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithComa_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("diagnosedWithDiabities").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithDiabities").getAsString(), "Y")) 
				     				setformfieldS(form, "diagnosedWithDiabities_Y0", "Yes");			     			 
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("diagnosedWithDiabities").getAsString(), "N"))
									setformfieldS(form, "diagnosedWithDiabities_N0", "No"); //#SRP00026 Change
				     		 }
						   } catch (Exception e) {						
							   
						   }
					 try {
				     		if (!i$outis.$iStrBlank(fcipData.get("lastFiveYearMedicalCondition").getAsString())) {
				     			 if (i$outis.$iStrFuzzyMatch(fcipData.get("lastFiveYearMedicalCondition").getAsString(), "Y")) {
				     				setformfieldS(form, "lastFiveYearMedicalCondition_Y0", "Yes"); 
				     			setformfield(form, "lastFiveYearMedicalConditionDetails0",fcipData.get("lastFiveYearMedicalConditionDetails").getAsString());	
				     			 }
				     			 else if (i$outis.$iStrFuzzyMatch(fcipData.get("lastFiveYearMedicalCondition").getAsString(), "N"))
									setformfieldS(form, "lastFiveYearMedicalCondition_N0", "No");
				     		 }
						   } catch (Exception e) {						
							   
						   }
					  JsonArray insuredInfo = jsonObject.get("insuredInfo").getAsJsonArray();
					  for(int i=1;i<=insuredInfo.size();i++) {
						  JsonObject insuredDetails = insuredInfo.get(i-1).getAsJsonObject();
						  try {
							  if (insuredDetails.has("firstName")&& !i$outis.$iStrBlank(insuredDetails.get("firstName").getAsString())) {
								  setformfield(form, "firstName_"+i, insuredDetails.get("firstName").getAsString());
								  }
							  } catch (Exception e) {
								  
							  }	
						  try {
							  if (insuredDetails.has("middleName")&& !i$outis.$iStrBlank(insuredDetails.get("middleName").getAsString())) {
								  setformfield(form, "middleName_"+i, insuredDetails.get("middleName").getAsString());
								  }
							  } catch (Exception e) {
								  
							  }	
						  try {
							  if (insuredDetails.has("lastName")&& !i$outis.$iStrBlank(insuredDetails.get("lastName").getAsString())) {
								  setformfield(form, "lastName_"+i, insuredDetails.get("lastName").getAsString());
								  }
							  } catch (Exception e) {
								  
							  }	
						  try {
							  if (insuredDetails.has("address")&& !i$outis.$iStrBlank(insuredDetails.get("address").getAsString())) {
								  setformfield(form, "address_"+i, insuredDetails.get("address").getAsString());
								  }
							  } catch (Exception e) {
								  
							  }
						  try {
							  if (!i$outis.$iStrBlank(insuredDetails.get("proofOfAddress").getAsString())) {  //#SRP00016 Starts changes
								  if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAddress").getAsString(), "UtilityBill"))
									  setformfieldS(form, "proofOfAddress_Utility"+i, "I - UB"+i);
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAddress").getAsString(), "RegisteredMail"))
									  setformfieldS(form, "proofOfAddress_RegisterMail"+i, "I - RM"+i);   //#SRP00016 ends changes
								  }
							  } catch (Exception e) {
								  
							  }
						  try {
							  if (!i$outis.$iStrBlank(insuredDetails.get("proofOfAge").getAsString())) {  //#SRP00016 starts changes
								  if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAge").getAsString(), "Passport"))
									  setformfieldS(form, "proofOfAge_Passport"+i, "I - PP"+i);
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAge").getAsString(), "NationalId"))
									  setformfieldS(form, "proofOfAge_IdentifcationCard"+i, "I - ID"+i);
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAge").getAsString(), "DriversPermit"))
									  setformfieldS(form, "proofOfAge_Driver'sPermit"+i, "I - DP"+i);
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAge").getAsString(), "Driver's Permit"))
									  setformfieldS(form, "proofOfAge_Driver'sPermit"+i, "I - DP"+i);
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAge").getAsString(), "BirthCertificate"))
									  setformfieldS(form, "proofOfAge_BirthCertificate"+i, "I - BC"+i);  //#SRP00016 ends changes
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("proofOfAge").getAsString(), "Birth Certificate"))
									  setformfieldS(form, "proofOfAge_BirthCertificate"+i, "I - BC"+i);
								  }
							  } catch (Exception e) {
								  
							  }
						  try {
							  if(insuredDetails.has("telephone")&& !i$outis.$iStrBlank(insuredDetails.get("telephone").getAsString()))
								  setformfield(form, "telephone"+i, insuredDetails.get("telephone").getAsString());
							  } catch (Exception e) {
								  
							  }
						  try {
							  if(insuredDetails.has("emailId")&& !i$outis.$iStrBlank(insuredDetails.get("emailId").getAsString())) //#SRP00016 changes
								  setformfield(form, "emailId"+i, insuredDetails.get("emailId").getAsString());
							  } catch (Exception e) {
								  
							  }
						  try {
							  if(insuredDetails.has("relationshipPrimaryInsured")&& !i$outis.$iStrBlank(insuredDetails.get("relationshipPrimaryInsured").getAsString()))
								  setformfield(form, "relationshipPrimaryInsured"+i, insuredDetails.get("relationshipPrimaryInsured").getAsString());
							  } catch (Exception e) {
								  
							  }
						  try {
							  if(insuredDetails.has("proofOfRelationship")&& !i$outis.$iStrBlank(insuredDetails.get("proofOfRelationship").getAsString()))
								  setformfield(form, "proofOfRetationship"+i, insuredDetails.get("proofOfRelationship").getAsString());
							  } catch (Exception e) {
								  
							  }
						  try {
							  if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithCancer").getAsString())) {
								  if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithCancer").getAsString(), "Y")) 
									  setformfieldS(form, "diagnosedWithCancer_Y"+i, "Yes");
								  else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithCancer").getAsString(), "N"))
									  setformfieldS(form, "diagnosedWithCancer_N"+i, "No");
								  }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithParalysis").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithParalysis").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithParalysis_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithParalysis").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithParalysis_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithHiv").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithHiv").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithHiv_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithHiv").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithHiv_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithHeart").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithHeart").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithHeart_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithHeart").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithHeart_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithMajor").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithMajor").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithMajor_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithMajor").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithMajor_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithHeartCondition").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithHeartCondition").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithHeartCondition_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithHeartCondition").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithHeartCondition_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithStroke").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithStroke").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithStroke_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithStroke").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithStroke_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithComa").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithComa").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithComa_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithComa").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithComa_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("diagnosedWithDiabities").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithDiabities").getAsString(), "Y")) 
					     				setformfieldS(form, "diagnosedWithDiabities_Y"+i, "Yes");			     			 
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("diagnosedWithDiabities").getAsString(), "N"))
										setformfieldS(form, "diagnosedWithDiabities_N"+i, "No");  //#SRP00025 changes
					     		 }
							   } catch (Exception e) {						
								   
							   }
						 try {
								if(insuredDetails.has("benefitOfAmount")&& !i$outis.$iStrBlank(insuredDetails.get("benefitOfAmount").getAsString()))
									setformfield(form, "bnefitOfAmount"+i, insuredDetails.get("benefitOfAmount").getAsString());
								} catch (Exception e) {
									
								}
						 try {
								if(insuredDetails.has("premiumDue")&& !i$outis.$iStrBlank(insuredDetails.get("premiumDue").getAsString())) //#SRP00016 changes
									setformfield(form, "premiumDue"+i, insuredDetails.get("premiumDue").getAsString());
								} catch (Exception e) {
									
								}
						 try {
								if (insuredDetails.has("dob"))
									setformfield(form, "dob_"+i, getClicoDateFormat(insuredDetails.get("dob").getAsString()));
							} catch (Exception e) {
								
							}
						 try {
								if (insuredDetails.has("gender")) {  //#SRP00027 changes
									if (i$outis.$iStrFuzzyMatch(insuredDetails.get("gender").getAsString(), "M"))
										setformfieldS(form, "gender_M"+i, "I - Male"+i);
									else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("gender").getAsString(), "F"))
										setformfieldS(form, "gender_F"+i, "I - Female"+i);
								}
							} catch (Exception e) {
								
							}
						 try {
					     		if (!i$outis.$iStrBlank(insuredDetails.get("lastFiveYearMedicalCondition").getAsString())) {
					     			 if (i$outis.$iStrFuzzyMatch(insuredDetails.get("lastFiveYearMedicalCondition").getAsString(), "Y")) {
					     				setformfieldS(form, "lastFiveYearMedicalCondition_Y"+i, "Yes"); 
					     			setformfield(form, "lastFiveYearMedicalConditionDetails"+i,insuredDetails.get("lastFiveYearMedicalConditionDetails").getAsString());	
					     			 }
					     			 else if (i$outis.$iStrFuzzyMatch(insuredDetails.get("lastFiveYearMedicalCondition").getAsString(), "N"))
										setformfieldS(form, "lastFiveYearMedicalCondition_N"+i, "No");
					     		 }
							   } catch (Exception e) {						
								   
							   }
					}
					}
				     // #SKP00002 Ends
				
				    //#SRP00011 Start
				  
				// #SKP00003 Starts
   				  else if (pdfName.equalsIgnoreCase("Dental_And_vision_Care_Benefits")) {
   						  JsonObject dentalAndVisionCareBenefits = new JsonObject();       
   						  if(jsonObject.has("dentalAndVisionCareBenefits"))
   							  dentalAndVisionCareBenefits = jsonObject.get("dentalAndVisionCareBenefits").getAsJsonObject();
   						  try {
   								for (int i = 0; i <= filedName.size(); i++) {
   							
   								fillPDFField(dentalAndVisionCareBenefits, filedName.get(i), form);
   								}
   							}catch(Exception e) {
   									
   							}
   						  try {
   							  if(dentalAndVisionCareBenefits.has("employer")&& !i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("employer").getAsString()))
   								  setformfield(form, "employer", dentalAndVisionCareBenefits.get("employer").getAsString());
   							  } catch (Exception e) {
   								  
   							  }
   						  try {
   							  if(dentalAndVisionCareBenefits.has("policyNo")&& !i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("policyNo").getAsString()))
   								  setformfield(form, "policyNo", dentalAndVisionCareBenefits.get("policyNo").getAsString());
   							  } catch (Exception e) {
   								  
   							  }
   						  try {
   							  if(dentalAndVisionCareBenefits.has("fullName")&& !i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("fullName").getAsString()))
   								  setformfield(form, "fullName", dentalAndVisionCareBenefits.get("fullName").getAsString());
   							  } catch (Exception e) {
   								  
   							  }
   						  try {
   							  if(dentalAndVisionCareBenefits.has("dob")&& !i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("dob").getAsString()))
   								  setformfield(form, "dob", dentalAndVisionCareBenefits.get("dob").getAsString());
   							  } catch (Exception e) {
   								  
   							  }
   						try {//#SRP00033 starts
                            String diagnoseDetails = dentalAndVisionCareBenefits.get("homeAddress").getAsString();
                            if(diagnoseDetails.length()>72) {
                              setformfieldS(form, "homeAddress", dentalAndVisionCareBenefits.get("homeAddress").getAsString().substring(0, 72));
                              setformfieldS(form, "PLEASE PRINT", dentalAndVisionCareBenefits.get("homeAddress").getAsString().substring(72, diagnoseDetails.length()));
                              
                            }else {
                              setformfieldS(form, "homeAddress", dentalAndVisionCareBenefits.get("homeAddress").getAsString());
                            }
                          }catch(Exception e) {
                            
                          }//#SRP00033 ends
   						  try {
   							  if(dentalAndVisionCareBenefits.has("occupation")&& !i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("occupation").getAsString()))
   								  setformfield(form, "occupation", dentalAndVisionCareBenefits.get("occupation").getAsString());
   							  } catch (Exception e) {
   								  
   							  }
//   						//#SRP00032 Starts
								JsonArray completeDentalCareBenefits = dentalAndVisionCareBenefits
										.get("completeDentalCareBenefits").getAsJsonArray();
								for (int j = 1; j <= completeDentalCareBenefits.size(); j++) {
									JsonObject dependentInfo = completeDentalCareBenefits.get(j - 1).getAsJsonObject();
									try {
										if (dependentInfo.has("nameOfInsured") && !i$outis
												.$iStrBlank(dependentInfo.get("nameOfInsured").getAsString()))
											setformfield(form, "nameOfInsured" + j,
													dependentInfo.get("nameOfInsured").getAsString());
									} catch (Exception e) {

									}
									try {
										if (dependentInfo.has("nameOfDentistLastConsulted")
												|| dependentInfo.has("addressOfDentistLastConsulted")) {
											StringBuilder dentistDesc = new StringBuilder();
											try {
												if (dependentInfo.has("nameOfDentistLastConsulted")
														&& !i$outis.$iStrBlank(dependentInfo
																.get("nameOfDentistLastConsulted").getAsString())) {
													dentistDesc.append(dependentInfo.get("nameOfDentistLastConsulted")
															.getAsString());
												}
											} catch (Exception e) {

											}
											try {
												if (dependentInfo.has("addressOfDentistLastConsulted")
														&& !i$outis.$iStrBlank(dependentInfo
																.get("addressOfDentistLastConsulted").getAsString())) {
													dentistDesc.append(" ");
													dentistDesc.append(dependentInfo
															.get("addressOfDentistLastConsulted").getAsString());
												}
											} catch (Exception e) {

											}
											setformfield(form, "nameOfDentistLastConsulted" + j,
													dentistDesc.toString());
										}
									} catch (Exception e) {
									}
									try {
										if (dependentInfo.has("dateOfLastVisitDate") && !i$outis
												.$iStrBlank(dependentInfo.get("dateOfLastVisitDate").getAsString()))
											setformfield(form, "dateOfLastVisitDate" + j,
													dependentInfo.get("dateOfLastVisitDate").getAsString());
									} catch (Exception e) {

									}
									try {
										if (dependentInfo.has("dateOfLastVisitYear") && !i$outis
												.$iStrBlank(dependentInfo.get("dateOfLastVisitYear").getAsString()))
											setformfield(form, "dateOfLastVisitYear" + j,
													dependentInfo.get("dateOfLastVisitYear").getAsString());
									} catch (Exception e) {

									}
								} // #SRP00032 Ends
   						  try {
   					     		if (!i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("hasAnyDentalTreatmentRecommended").getAsString())) {
   					     			 if (i$outis.$iStrFuzzyMatch(dentalAndVisionCareBenefits.get("hasAnyDentalTreatmentRecommended").getAsString(), "Y")) {
   					     				setformfieldS(form, "hasAnyDentalTreatmentRecommended_Yes", "Yes"); 
   					     			setformfield(form, "hasAnyDentalTreatmentRecommendedDetails",dentalAndVisionCareBenefits.get("hasAnyDentalTreatmentRecommendedDetails").getAsString());	
   					     			 }
   					     			 else if (i$outis.$iStrFuzzyMatch(dentalAndVisionCareBenefits.get("hasAnyDentalTreatmentRecommended").getAsString(), "N"))
   										setformfieldS(form, "hasAnyDentalTreatmentRecommended_No", "Yes");
   					     		 }
   							   } catch (Exception e) {						
   								   
   							   }

   						  try {
   					     		if (!i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("anyOfAboveDependentsWearDentures").getAsString())) {
   					     			 if (i$outis.$iStrFuzzyMatch(dentalAndVisionCareBenefits.get("anyOfAboveDependentsWearDentures").getAsString(), "Y")) {
   					     				setformfieldS(form, "anyOfAboveDependentsWearDentures_Yes", "Yes"); 
   					     				 JsonArray anyOfAboveDependentsWearDenturesDetails = dentalAndVisionCareBenefits.get("anyOfAboveDependentsWearDenturesDetails").getAsJsonArray();
   										  for(int i=1;i<=anyOfAboveDependentsWearDenturesDetails.size();i++) {
   											  JsonObject anyOfAboveDependentsWearDenturesDetailsInfo = anyOfAboveDependentsWearDenturesDetails.get(i-1).getAsJsonObject();
   											  try {
   												  if(anyOfAboveDependentsWearDenturesDetailsInfo.has("anyOfAboveDependentsWearDenturesName")&& !i$outis.$iStrBlank(anyOfAboveDependentsWearDenturesDetailsInfo.get("anyOfAboveDependentsWearDenturesName").getAsString()))
   													  setformfield(form, "anyOfAboveDependentsWearDenturesName"+i, anyOfAboveDependentsWearDenturesDetailsInfo.get("anyOfAboveDependentsWearDenturesName").getAsString());
   												  } catch (Exception e) {
   													  
   												  }
   											  try {
   												  if (!i$outis.$iStrBlank(anyOfAboveDependentsWearDenturesDetailsInfo.get("anyOfAboveDependentsWearDenturesDetailsPartialOrComplete").getAsString())) {
   													  if (i$outis.$iStrFuzzyMatch(anyOfAboveDependentsWearDenturesDetailsInfo.get("anyOfAboveDependentsWearDenturesDetailsPartialOrComplete").getAsString(), "P")) 
   														  setformfieldS(form, "anyOfAboveDependentsWearDenturesDetailsPartial"+i+"_P", "Yes");			     			 
   													  else if (i$outis.$iStrFuzzyMatch(anyOfAboveDependentsWearDenturesDetailsInfo.get("anyOfAboveDependentsWearDenturesDetailsPartialOrComplete").getAsString(), "C"))
   														  setformfieldS(form, "anyOfAboveDependentsWearDenturesDetailsComplete"+i+"_C", "Yes");
   													  }
   												  } catch (Exception e) {						
   													  
   												  }
   										  }
   					     			 }
   					     			 else if (i$outis.$iStrFuzzyMatch(dentalAndVisionCareBenefits.get("hasAnyDentalTreatmentRecommended").getAsString(), "N"))	//#MVT00008 changes starts
   										setformfieldS(form, "anyOfAboveDependentsWearDentures_No", "Yes");//#MVT00008 changes ends
   					     		 }
   							   } catch (Exception e) {						
   								   
   							   }
   						//#SRP00032 Starts
						JsonArray completeVisionCareBenefits = dentalAndVisionCareBenefits
								.get("completeVisionCareBenefits").getAsJsonArray();
						for (int j = 1; j <= completeVisionCareBenefits.size(); j++) {
							JsonObject visionInfo = completeVisionCareBenefits.get(j - 1).getAsJsonObject();
							try {
								if (visionInfo.has("nameOfInsured")
										&& !i$outis.$iStrBlank(visionInfo.get("nameOfInsured").getAsString()))
									setformfield(form, "nameOfInsureds" + j,
											visionInfo.get("nameOfInsured").getAsString());
							} catch (Exception e) {

							}
							try {
								if (visionInfo.has("nameOfOpticianLastConsulted")
										|| visionInfo.has("addressOfOpticianLastConsulted")) {
									StringBuilder dentistDesc = new StringBuilder();
									try {
										if (visionInfo.has("nameOfOpticianLastConsulted") && !i$outis.$iStrBlank(
												visionInfo.get("nameOfOpticianLastConsulted").getAsString())) {
											dentistDesc.append(
													visionInfo.get("nameOfOpticianLastConsulted").getAsString());
										}
									} catch (Exception e) {

									}
									try {
										if (visionInfo.has("addressOfOpticianLastConsulted") && !i$outis.$iStrBlank(
												visionInfo.get("addressOfOpticianLastConsulted").getAsString())) {
											dentistDesc.append(" ");
											dentistDesc.append(
													visionInfo.get("addressOfOpticianLastConsulted").getAsString());
										}
									} catch (Exception e) {

									}
									setformfield(form, "nameOfOpticianLastConsulted" + j, dentistDesc.toString());
								}
							} catch (Exception e) {
							}
							try {
								if (visionInfo.has("dateOfLastPrescriptionExam") && !i$outis
										.$iStrBlank(visionInfo.get("dateOfLastPrescriptionExam").getAsString()))//#SRP00050 changes
									setformfield(form, "dateOfLastPrescriptionExame" + j,
											visionInfo.get("dateOfLastPrescriptionExam").getAsString());
							} catch (Exception e) {

							}
							try {
								if (visionInfo.has("dateOfLastPrescriptionLenses") && !i$outis
										.$iStrBlank(visionInfo.get("dateOfLastPrescriptionLenses").getAsString()))//#SRP00050 changes
									setformfield(form, "dateOfLastPrescriptionLensese" + j,
											visionInfo.get("dateOfLastPrescriptionLenses").getAsString());
							} catch (Exception e) {

							}
							try {
								if (visionInfo.has("dateOfLastPrescriptionFrames") && !i$outis
										.$iStrBlank(visionInfo.get("dateOfLastPrescriptionFrames").getAsString()))//#SRP00050 changes
									setformfield(form, "dateOfLastPrescriptionFramese" + j,
											visionInfo.get("dateOfLastPrescriptionFrames").getAsString());
							} catch (Exception e) {

							}
						} // #SRP00032 Ends

   						  try {
   							  if (!i$outis.$iStrBlank(dentalAndVisionCareBenefits.get("anyOfDependentsReceiveDentalAndVisionTreatment").getAsString())) {
   								  if (i$outis.$iStrFuzzyMatch(dentalAndVisionCareBenefits.get("anyOfDependentsReceiveDentalAndVisionTreatment").getAsString(), "Y")) {
   									  setformfieldS(form, "anyOfDependentsReceiveDentalAndVisionTreatment_Yes", "Yes");	
   								  setformfield(form, "hasAnyDentalTreatmentRecommendedDetails",dentalAndVisionCareBenefits.get("hasAnyDentalTreatmentRecommendedDetails").getAsString());	
   								  }
   								  else if (i$outis.$iStrFuzzyMatch(dentalAndVisionCareBenefits.get("anyOfDependentsReceiveDentalAndVisionTreatment").getAsString(), "N"))
   									  setformfieldS(form, "anyOfDependentsReceiveDentalAndVisionTreatment_No", "Yes");
   								  }
   							  } catch (Exception e) {						
   								  
   							  }
   						  }
   				    // #SKP00003 Ends
				 // #SKP00004 Starts  
				  else if (pdfName.equalsIgnoreCase("Tatil_Proof_Of_Address")) {
					  JsonObject tatilProofOfAddress =jsonObject.get("tatilProofOfAddress").getAsJsonObject();
						/*
						 * try { //#MVT00005 changes Date date = new Date(); SimpleDateFormat dateFormat
						 * = new SimpleDateFormat("dd/MM/yyyy"); String strDate =
						 * dateFormat.format(date); setformfield(form, "date", strDate); //#MVT00005
						 * changes ends } catch (Exception e) {
						 * 
						 * }
						 */
						  try {
							  if(tatilProofOfAddress.has("typeOfBill")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("typeOfBill").getAsString()))
								  setformfield(form, "typeOfBill", tatilProofOfAddress.get("typeOfBill").getAsString());
							  } catch (Exception e) {
								  
							  }
						  try {
							  if(tatilProofOfAddress.has("memberName2")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("memberName2").getAsString()))
								  setformfield(form, "Members Name_2", tatilProofOfAddress.get("memberName2").getAsString());
							  } catch (Exception e) {
								  
							  }
						  String s1=tatilProofOfAddress.get("nameOfPerson").getAsString(); //#SRP00042 Starts
						  String s2=tatilProofOfAddress.get("memberName1").getAsString();
						if(s1.equals(s2)) //#SRP00042 Ends
						  {
							try {
								  if(tatilProofOfAddress.has("nameOfPerson")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("nameOfPerson").getAsString()))
									  setformfield(form, "nameOfPerson", tatilProofOfAddress.get("nameOfPerson").getAsString());
								  } catch (Exception e) {
									  
								  }
							  try {
								  if(tatilProofOfAddress.has("memberName1")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("memberName1").getAsString()))
									  setformfield(form, "memberName1", tatilProofOfAddress.get("memberName1").getAsString());
								  } catch (Exception e) {
									  
								  }
						  }
						else {
							try {
								  if(tatilProofOfAddress.has("nameOfPerson")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("nameOfPerson").getAsString()))
									  setformfield(form, "nameOfPerson", tatilProofOfAddress.get("nameOfPerson").getAsString());
								  } catch (Exception e) {
									  
								  }
							  try {
								  if(tatilProofOfAddress.has("memberName1")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("memberName1").getAsString()))
									  setformfield(form, "memberName1", tatilProofOfAddress.get("memberName1").getAsString());
								  } catch (Exception e) {
									  
								  }
						  try {
							  if(tatilProofOfAddress.has("periodOftimeAtResidence")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("periodOftimeAtResidence").getAsString()))
								  setformfield(form, "periodOftimeAtResidence", tatilProofOfAddress.get("periodOftimeAtResidence").getAsString());
							  } catch (Exception e) {
								  
							  }
						 
						  try {
							  if(tatilProofOfAddress.has("relationToMember")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("relationToMember").getAsString()))
								  setformfield(form, "Relationship to member", tatilProofOfAddress.get("relationToMember").getAsString());
							  } catch (Exception e) {
								  
							  }
						  try { //#SRP00031 Starts
							  if(tatilProofOfAddress.has("relationToMemberOther")&& !i$outis.$iStrBlank(tatilProofOfAddress.get("relationToMemberOther").getAsString()))
								  setformfield(form, "Relationship to member", tatilProofOfAddress.get("relationToMemberOther").getAsString());
							  } catch (Exception e) {
								  
							  }//#SRP00031 Ends
						  try {
							  String landmark=tatilProofOfAddress.get("directionAndLandmark").getAsString();//#SRP00037 Starts
							  String address1=landmark.substring(0, 40);
							  setformfield(form, "Directions andor Landmark if applicable", address1);
							  String address2=landmark.substring(40, landmark.length());
							  setformfield(form, "Directions andor Landmark if applicable 2", address2);//#SRP00037 Ends
						  }catch(Exception e) {
							  
						  }
						}
						  }
				  else if (pdfName.equalsIgnoreCase("Tatil_Premier_Card_Application_Data")) {
					  JsonObject tatilPremiercardInfo = new JsonObject();       
					  if(jsonObject.has("tatilPremiercardInfo"))
						  tatilPremiercardInfo = jsonObject.get("tatilPremiercardInfo").getAsJsonObject();
					  try {
							for (int i = 0; i <= filedName.size(); i++) {
						
							fillPDFField(tatilPremiercardInfo, filedName.get(i), form);
							}
						}catch(Exception e) {
								
						}
					  /*try {	//#MVT00009 starts
						  	String cdate =i$outis.customerDate(new Date());
						  	String[] date = cdate.split("/");
							String month = date[1];
							String day = date[0];
							String year = date[2];
							setformfield(form, "date_year", year);
							setformfield(form, "date_day", day);
							setformfield(form, "date_month", month);
						  
					  }catch(Exception e) {
						  
					  }	//#MVT00009 ends*/
					  try {
						  if (tatilPremiercardInfo.has("firstName") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("firstName").getAsString())) {
							  setformfield(form, "FIRST NAME", tatilPremiercardInfo.get("firstName").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  if (tatilPremiercardInfo.has("lastName") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("lastName").getAsString())) {
							  setformfield(form, "SURNAME", tatilPremiercardInfo.get("lastName").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  String homeAddress=tatilPremiercardInfo.get("homeAddress").getAsString();//#SRP00031 Changes Starts
						  String address1=homeAddress.substring(0,28);
						  setformfield(form, "HOME ADDRESS", address1);
						  String address2=homeAddress.substring(28, homeAddress.length());
						  setformfield(form, "HOME ADDRESS1", address2);//#SRP00031 Changes Ends
					  }catch(Exception e) {
						  
					  }
					//MVT00002 Changes starts
					  try {
						  if (tatilPremiercardInfo.has("dob") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("dob").getAsString())) {
								String [] DOB = getClicoDateFormat(tatilPremiercardInfo.get("dob").getAsString()).split("/");
								
								String month = DOB[0];
								String day = DOB[1];
								String year = DOB[2].substring(2);
								String dob = day+month+year;
								setformfield(form, "DATE OF BIRTH", dob);
						  }
					  }catch(Exception e) {
						  
					  } //MVT00002 Changes ends
					  try {
						  if (tatilPremiercardInfo.has("telHome") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("telHome").getAsString())) {
							  setformfield(form, "TELH", tatilPremiercardInfo.get("telHome").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  if (tatilPremiercardInfo.has("telWork") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("telWork").getAsString())) {
							  setformfield(form, "TELW", tatilPremiercardInfo.get("telWork").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  if (tatilPremiercardInfo.has("telCell") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("telCell").getAsString())) {
							  setformfield(form, "TELC", tatilPremiercardInfo.get("telCell").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  if (tatilPremiercardInfo.has("Email") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("Email").getAsString())) {
							  setformfield(form, "EMAIL", tatilPremiercardInfo.get("Email").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  if (tatilPremiercardInfo.has("employerDesc") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("employerDesc").getAsString())) {//#SRP00031 Changes 
							  setformfield(form, "EMPLOYER", tatilPremiercardInfo.get("employerDesc").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  if (tatilPremiercardInfo.has("position") && !i$outis.$iStrBlank(tatilPremiercardInfo.get("position").getAsString())) {
							  setformfield(form, "POSITION", tatilPremiercardInfo.get("position").getAsString());
						  }
					  }catch(Exception e) {
						  
					  }
					  try {
						  String workAddress=tatilPremiercardInfo.get("workAddress").getAsString(); //#SRP00031 Changes Starts
						  String address1=workAddress.substring(0,28);
						  setformfield(form, "WORK ADDRESS", address1);
						  String address2=workAddress.substring(28, workAddress.length());
						  setformfield(form, "WORK ADDRESS1", address2);//#SRP00031 Changes Ends
					  }catch(Exception e) {
						  
					  }
					  try {
							if (tatilPremiercardInfo.has("cardType")) {
								if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("cardType").getAsString(), "customer"))
									setformfieldS(form, "Customer", "X");

								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("cardType").getAsString(), "renewingCustomer"))
									setformfieldS(form, "Renewing Customer", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("cardType").getAsString(), "staff"))
									setformfieldS(form, "Staff", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("cardType").getAsString(), "renewingStaff"))
									setformfieldS(form, "Renewing Staff", "X");
							}

						} catch (Exception e) {
							
						}
					  try {
							if (tatilPremiercardInfo.has("gender")) {
								if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("gender").getAsString(), "M"))
									setformfieldS(form, "GENDER Male", "X");

								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("gender").getAsString(), "F"))
									setformfieldS(form, "Female", "X");
							}

						} catch (Exception e) {
							
						}
					  try {
							if (tatilPremiercardInfo.has("gender")) {
								if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("maritalStatus").getAsString(), "Single"))
									setformfieldS(form, "MARITAL STATUS Single", "X");

								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("maritalStatus").getAsString(), "Married"))
									setformfieldS(form, "Married", "X");
							}

						} catch (Exception e) {
							
						}
					  try {
							if (tatilPremiercardInfo.has("contactYouVia")) {
								if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("contactYouVia").getAsString(), "Tel(H)"))
									setformfieldS(form, "TelH", "X");

								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("contactYouVia").getAsString(), "Tel(C)"))
									setformfieldS(form, "TelC", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("contactYouVia").getAsString(), "Tel(W)"))
									setformfieldS(form, "TelW", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("contactYouVia").getAsString(), "Email"))
									setformfieldS(form, "email", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("contactYouVia").getAsString(), "Mail"))
									setformfieldS(form, "Mail", "X");
							}

						} catch (Exception e) {
							
						}
					  try {
							if (tatilPremiercardInfo.has("monthlyIncomeRange")) {  //#PKY00048 starts
								if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("monthlyIncomeRange").getAsString(), "Less than $4K"))
									setformfieldS(form, "Less than 4K", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("monthlyIncomeRange").getAsString(), "$4K – $8K"))
									setformfieldS(form, "4K  8K", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("monthlyIncomeRange").getAsString(), "$8k – $12K"))
									setformfieldS(form, "8k  12K", "X");
								else if (i$outis.$iStrFuzzyMatch(tatilPremiercardInfo.get("monthlyIncomeRange").getAsString(), "Over $12K"))
									setformfieldS(form, "Over 12K", "X");
							}

						} catch (Exception e) {
							
						}  //#PKY00048 ends
					  }
				    // #SKP00004 Ends
				 //SKP00005 Starts
				  else if (pdfName.equalsIgnoreCase("Tatil_Deduction_Form")) {
					  JsonObject tatilApplication = jsonObject.get("tatilApplication").getAsJsonObject();   //#PKY00040 changes
					  JsonObject tatildeduction = new JsonObject();       
					  if(jsonObject.has("tatildeduction"))
						  tatildeduction = jsonObject.get("tatildeduction").getAsJsonObject();
					  try {
							for (int i = 0; i <= filedName.size(); i++) {
						
							fillPDFField(tatildeduction, filedName.get(i), form);
							}
						}catch(Exception e) {
								
						}
					  try {
						  if(tatildeduction.has("date")&& !i$outis.$iStrBlank(tatildeduction.get("date").getAsString()))
							  setformfield(form, "date", tatildeduction.get("date").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(tatildeduction.has("memberNumber")&& !i$outis.$iStrBlank(tatildeduction.get("memberNumber").getAsString()))
							  setformfield(form, "memberNumber", tatildeduction.get("memberNumber").getAsString());
						  } catch (Exception e) {
							  
						  }
					  try {
						  if(tatildeduction.has("memberName")&& !i$outis.$iStrBlank(tatildeduction.get("memberName").getAsString()))
							  setformfield(form, "memberName", tatildeduction.get("memberName").getAsString());
						  } catch (Exception e) {
							  
						  }//#PKY00040 starts
							try { // #SRP00052 changes starts #MVT00033 Changes starts
								if (tatilApplication.has("tatilmemAgeUnder64")) {
									if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "25"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "M"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$200")))
										setformfieldS(form, "division1MemberOnly", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "25"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "O"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$360")))
										setformfieldS(form, "division1Member+OneDependent", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "25"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "F"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$559")))
										setformfieldS(form, "division1Member+Family", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "40"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "M"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$270")))
										setformfieldS(form, "division2MemberOnly", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "40"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "O"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$486")))
										setformfieldS(form, "division2Member+OneDependent", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "40"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "F"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$756")))
										setformfieldS(form, "division2Member+Family", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "75"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "M"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$420")))
										setformfieldS(form, "division3MemberOnly", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "75"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "O"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$756")))
										setformfieldS(form, "division3Member+OneDependent", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeUnder64").getAsString(), "75"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "F"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$1176")))
										setformfieldS(form, "division3Member+Family", "Yes");
								} // #MVT00033 Changes ends

							} catch (Exception e) {

							}
						/*	try {
								if (tatilApplication.has("tatilmemAgeAbove65")) { // #SRP00051 Changes Start
									if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "25"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "M"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$315")))
										setformfieldS(form, "division4MemberOnly", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "25"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "O"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$567")))
										setformfieldS(form, "division4Member+OneDependent", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "25"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "F"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$882")))
										setformfieldS(form, "division4Member+Family", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "40"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "M"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$357")))
										setformfieldS(form, "division5MemberOnly", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "40"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "O"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$643")))
										setformfieldS(form, "division5Member+OneDependent", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "40"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "F"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$1000")))
										setformfieldS(form, "division5Member+Family", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "75"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "M"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$450")))
										setformfieldS(form, "division6MemberOnly", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "75"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "O"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$810")))
										setformfieldS(form, "division6Member+OneDependent", "Yes");
									else if ((i$outis.$iStrFuzzyMatch(
											tatilApplication.get("tatilmemAgeAbove65").getAsString(), "75"))
											&& (i$outis.$iStrFuzzyMatch(
													tatilApplication.get("tatilMemCoverage").getAsString(), "F"))
											&& (i$outis.$iStrFuzzyMatch(
													tatildeduction.get("coveragePremium").getAsString(), "$1260")))
										setformfieldS(form, "division6Member+Family", "Yes"); // #SRP00030 changes Ends
																								// //#SRP00051 Changes
																								// Start
								}

							} catch (Exception e) {// #SRP00052 changes

							}//#PKY00040 ends*/
					  try {
						  if(tatildeduction.has("memberSignature")&& !i$outis.$iStrBlank(tatildeduction.get("memberSignature").getAsString()))
							  setformfield(form, "memberSignature", tatildeduction.get("memberSignature").getAsString());
						  } catch (Exception e) {
							  
						  }
					  }
				    //SKP00005 Ends	//#MVT00017 Changes starts
				//#MDA0001 starts

				else if (pdfName.equalsIgnoreCase("DECLARATION_OF_SOURCE_OF_FUNDS_Form")) {
					JsonObject fundsinfo = new JsonObject();
					if (jsonObject.has("fundsInfo"))
						fundsinfo = jsonObject.get("fundsInfo").getAsJsonObject();
					try {
						for (int i = 0; i <= filedName.size(); i++) {

							fillPDFField(fundsinfo, filedName.get(i), form);
						}
					} catch (Exception e) {

					}

					try {
						if (fundsinfo.has("customerName")
								&& !i$outis.$iStrBlank(fundsinfo.get("customerName").getAsString()))
							setformfield(form, "customerName", fundsinfo.get("customerName").getAsString());
					} catch (Exception e) {

					}

					try {
						if (fundsinfo.has("creditSource")
								&& !i$outis.$iStrBlank(fundsinfo.get("creditSource").getAsString()))
							setformfield(form, "creditSource", fundsinfo.get("creditSource").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("fundingSource")
								&& !i$outis.$iStrBlank(fundsinfo.get("fundingSource").getAsString()))
							setformfield(form, "fundingSource", fundsinfo.get("fundingSource").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("natureOfBusinessOrIncomeStream")
								&& !i$outis.$iStrBlank(fundsinfo.get("natureOfBusinessOrIncomeStream").getAsString()))
							setformfield(form, "natureOfBusinessOrIncomeStream",
									fundsinfo.get("natureOfBusinessOrIncomeStream").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("accountHolderName1")
								&& !i$outis.$iStrBlank(fundsinfo.get("accountHolderName1").getAsString()))
							setformfield(form, "accountHolderName1", fundsinfo.get("accountHolderName1").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("date") && !i$outis.$iStrBlank(fundsinfo.get("date").getAsString()))
							setformfield(form, "date", fundsinfo.get("date").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("salary") && !i$outis.$iStrBlank(fundsinfo.get("salary").getAsString()))
							setformfield(form, "salary", fundsinfo.get("salary").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("business") && !i$outis.$iStrBlank(fundsinfo.get("business").getAsString()))
							setformfield(form, "business", fundsinfo.get("business").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("income") && !i$outis.$iStrBlank(fundsinfo.get("income").getAsString()))
							setformfield(form, "income", fundsinfo.get("income").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("dividend") && !i$outis.$iStrBlank(fundsinfo.get("dividend").getAsString()))
							setformfield(form, "dividend", fundsinfo.get("dividend").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("intrest") && !i$outis.$iStrBlank(fundsinfo.get("intrest").getAsString()))
							setformfield(form, "intrest", fundsinfo.get("intrest").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("gift") && !i$outis.$iStrBlank(fundsinfo.get("gift").getAsString()))
							setformfield(form, "gift", fundsinfo.get("gift").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("pocketMoney") && !i$outis.$iStrBlank(fundsinfo.get("pocketMoney").getAsString()))
							setformfield(form, "pocketMoney", fundsinfo.get("pocketMoney").getAsString());
					} catch (Exception e) {

					}
					try {
						if (fundsinfo.has("Others") && !i$outis.$iStrBlank(fundsinfo.get("Others").getAsString()))
							setformfield(form, "Others", fundsinfo.get("Others").getAsString());
					} catch (Exception e) {

					}
				}
				// #MDA0001 ends
				else if (pdfName.equalsIgnoreCase("Cuna_Designation_Of_Beneficiary_Phase2")|| pdfName.equalsIgnoreCase("Family_Indemnity_Plan_Enrolment_Form")) {  //#SRP00062 Chnages //#MVT00017 Changes ends
					// #SBC0087 starts
					JsonObject cunaMemDetails = new JsonObject();      //#PKY00036 starts
					if(jsonObject.has("cunaInsurance"))
						cunaMemDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
					else
						cunaMemDetails = jsonObject.get("fipEnrolment").getAsJsonObject();  //#PKY00036 ends
					 
					JsonArray cunaBenDetails =cunaMemDetails.getAsJsonArray("beneficiaryDetails");
					JsonObject nameInfo = jsonObject.get("personalInfo").getAsJsonObject();
					
					//Cuna_Designation_Of_Beneficiary
					try {
						if (nameInfo.has("firstName")|| nameInfo.has("middleName")|| nameInfo.has("lastName")) {
							StringBuilder strfullname = new StringBuilder();
							try {
								if (nameInfo.has("firstName") && !i$outis.$iStrBlank(nameInfo.get("firstName").getAsString())) {
									strfullname.append(nameInfo.get("firstName").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (nameInfo.has("middleName") && !i$outis.$iStrBlank(nameInfo.get("middleName").getAsString())) {
									strfullname.append(" ");
									strfullname.append(nameInfo.get("middleName").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (nameInfo.has("lastName") && !i$outis.$iStrBlank(nameInfo.get("lastName").getAsString())) {
									strfullname.append(" ");
									strfullname.append(nameInfo.get("lastName").getAsString());
								}
							} catch (Exception e) {
								
							}  //#MVT00005 starts //#MVT00019 Changes staers
							//setformfield(form, "Date", i$outis.customerDate(new Date()));	//#MVT00005 ends 
							setformfield(form, "cunaMemFullName", strfullname.toString());
						}
					} catch (Exception e) {	//#MVT00019 changes ends
						
					} //#PKY00036 starts
					if (jsonObject.has("fipDesignation")) {
						JsonObject designationDet = jsonObject.get("fipDesignation").getAsJsonObject();
						try {
							for (int i = 0; i <= filedName.size(); i++) {

								fillPDFField(designationDet, filedName.get(i), form);
							}
						} catch (Exception e) {

						}
						try {
							JsonObject personalInfo = jsonObject.get("personalInfo").getAsJsonObject();
							if (personalInfo.has("firstName") || personalInfo.has("lastName")) {
								StringBuilder strCunaBen = new StringBuilder();
								try {
									if (personalInfo.has("firstName")
											&& !i$outis.$iStrBlank(personalInfo.get("firstName").getAsString())) {
										strCunaBen.append(personalInfo.get("firstName").getAsString());
									}
								} catch (Exception e) {

								}
								try {
									if (personalInfo.has("lastName")
											&& !i$outis.$iStrBlank(personalInfo.get("lastName").getAsString())) {
										strCunaBen.append(" ");
										strCunaBen.append(personalInfo.get("lastName").getAsString());
									}
								} catch (Exception e) {

								}
								// #MVT000011 changes starts
								setformfield(form, "cunaMemFullName", strCunaBen.toString()); // #MVT000011 changes ends
							} else {
								setformfield(form, "cunaMemFullName", ""); // #SKP00006 changes
							}
						} catch (Exception e) {

						}
						// #SRP00016 Starts
						try {
							if (designationDet.has("cunaBen1FullName")
									&& !i$outis.$iStrBlank(designationDet.get("cunaBen1FullName").getAsString())) {
								setformfield(form, "cunaBenFullName",
										designationDet.get("cunaBen1FullName").getAsString());
							}
						} catch (Exception e) {

						}
//						try {
//							if(designationDet.has("cunaBen1Dob") && !i$outis.$iStrBlank(designationDet.get("cunaBen1Dob").getAsString()) ) {
//								setformfield(form, "cunaBen1Dob", designationDet.get("cunaBen1Dob").getAsString());
//							}
//						}catch(Exception e) {
//							
//						}//#MVT00014 changes starts
						try {
							  if (designationDet.has("cunaBen1Dob") && !i$outis.$iStrBlank(designationDet.get("cunaBen1Dob").getAsString())) {
								  String[] DOB = getClicoDateFormat(designationDet.get("cunaBen1Dob").getAsString()).split("/");
								  String year = DOB[2];
								  String day = DOB[1];
								  String month = DOB[0];
								  String cunaBen1Dob = new StringBuilder(month+"/").append(day).append("/"+year).toString();//#SRP00040 Changes
								  setformfieldS(form, "cunaBendob", cunaBen1Dob);
							  }
						  }catch(Exception e) {
							  
						  }		//#MVT00014 chnages end
						try {
							if(designationDet.has("cunaBen1Rel") && !i$outis.$iStrBlank(designationDet.get("cunaBen1Rel").getAsString()) ) {
								setformfield(form, "cunaBenRel", designationDet.get("cunaBen1Rel").getAsString());
							}
						}catch(Exception e) {
							
						}
						try {
							if(designationDet.has("membershipNo") && !i$outis.$iStrBlank(designationDet.get("membershipNo").getAsString()) ) {
								setformfield(form, "Membership No", designationDet.get("membershipNo").getAsString());
							}
						}catch(Exception e) {
							
						}
						//#SRP00016 Ends
						try {
							if(designationDet.has("nameOfLegalGuardian") && !i$outis.$iStrBlank(designationDet.get("nameOfLegalGuardian").getAsString()) ) {
								setformfield(form, "Name of Legal Guardian", designationDet.get("nameOfLegalGuardian").getAsString());
							}
						}catch(Exception e) {
							
						}
//						try {
//							if(designationDet.has("witness") && !i$outis.$iStrBlank(designationDet.get("witness").getAsString()) ) {
//								setformfield(form, "Witness", designationDet.get("witness").getAsString());
//							}
//						}catch(Exception e) {
//							
//						}
						try {	//#MVT00016 changes starts
							if (designationDet.has("date1")
									&& !i$outis.$iStrBlank(designationDet.get("date1").getAsString())) {
								String[] date1 = getClicoDateFormat(designationDet.get("date1").getAsString())
										.split("/");
								String year1 = date1[2];
								String day1 = date1[1];
								String month1 = date1[0];
								String date = new StringBuilder(month1 + "-").append(day1).append("-" + year1)
										.toString();
								setformfieldS(form, "Date 1", date);
							}
						}catch(Exception e) {
							
						}
						try {
							if (designationDet.has("date2")
									&& !i$outis.$iStrBlank(designationDet.get("date2").getAsString())) {
								String[] date2 = getClicoDateFormat(designationDet.get("date2").getAsString())
										.split("/");
								String year2 = date2[2];
								String day2 = date2[1];
								String month2 = date2[0];
								String cdate = new StringBuilder(month2 + "-").append(day2).append("-" + year2)
										.toString();
								setformfieldS(form, "Date 2", cdate);
							}
						}catch(Exception e) {	//#MVT00016 changes ends

						}
					} //#PKY00036 ends
					
					
		//Cuna_Designation_Of_Beneficiary
					
					try {
						if(cunaMemDetails.has("cunaPlanType") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaPlanType").getAsString()) ) { 
							setformfield(form, "cunaPlanType", cunaMemDetails.get("cunaPlanType").getAsString());
							setformfield(form, "FIPBEN", cunaMemDetails.get("individualBenefit").getAsString());
							setformfield(form, "FIPPREM", cunaMemDetails.get("monthlyPremium").getAsString());
							setformfield(form, "CIPREM", cunaMemDetails.get("cirMonthlyPremium").getAsString());                  //#SKP00007 Changes
						}
						
					}catch(Exception e) {
						e.printStackTrace();
					}
					
					try {
						addImage(stamp, form, "Qr_code_1", base64);
					}catch(Exception e) {
						
					}
				
		//cuna_CIR_details
					try {
						String BenCondCheck = cunaMemDetails.get("isCIR").getAsString();
						if(BenCondCheck.equalsIgnoreCase("Y")) {
							
							try {
								setformfieldS(form, "CIR", "On");
								
								if(cunaMemDetails.has("cunaCIRCovAmt") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaCIRCovAmt").getAsString()) ) {
									setformfield(form, "CICOVAMT", cunaMemDetails.get("cunaCIRCovAmt").getAsString());
								}
							}catch(Exception e) {
								
							}
							//#PKY00059 starts
							try {
                                if(jsonObject.has("fipEnrolment")) {
                                    setformfield(form, "age_band", cunaMemDetails.get("ageBand").getAsString());                      
                                }
                            }catch(Exception e) {}//#PKY00059 ends
							try {
								if(cunaMemDetails.has("cunaIllness") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllness").getAsString()) ) {
									if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllness").getAsString(), "Y")) {
										setformfieldS(form, "CIQ1", "Yes");
										
                                          if(cunaMemDetails.has("cunaIllnessDetails") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllnessDetails").getAsString()) ) {
                                        	  setformfield(form, "CIQ1INFO", cunaMemDetails.get("cunaIllnessDetails").getAsString());
										}
										
									}
									else if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllness").getAsString(), "N")) {
										setformfieldS(form, "CIQ1", "No");
									}
								}
							}catch(Exception e) {
								
							}
							try {
								if(cunaMemDetails.has("cunaIllnessTreatment") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllnessTreatment").getAsString()) ) {
									if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllnessTreatment").getAsString(), "Y")) {
										setformfieldS(form, "CIQ2", "Yes");
										
                                          if(cunaMemDetails.has("cunaIllnessTreatmentDetails") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaIllnessTreatmentDetails").getAsString()) ) {
                                        	  setformfield(form, "CIRQ2INFO", cunaMemDetails.get("cunaIllnessTreatmentDetails").getAsString());
										}
										
									}
									else if (i$outis.$iStrFuzzyMatch(cunaMemDetails.get("cunaIllnessTreatment").getAsString(), "N")) {
										setformfieldS(form, "CIQ2", "No");
									}
								}
								
							}catch(Exception e) {
								
							}
						}
					}catch(Exception e) {
						
					}
						
							
		//cune_beneficiary_details	//#MVT00017 Changes starts
					if(pdfName.equalsIgnoreCase("Cuna_Enrolment_Form")|| pdfName.equalsIgnoreCase("Family_Indemnity_Plan_Enrolment_Form")) {   //#PKY00048 changes	//#MVT00017 Changes ends
						String monthlyPremiumStr = cunaMemDetails.get("monthlyPremium").getAsString();//#SRP00029 start
						String cirmonthlyPremiumStr;
						try {
							cirmonthlyPremiumStr=cunaMemDetails.get("cirMonthlyPremium").getAsString();
						}catch(Exception e) {
							cirmonthlyPremiumStr = "$0";
						}
						double monthlyPremium=Double.parseDouble(monthlyPremiumStr.substring(1));
						double cirmonthlyPremium=Double.parseDouble(cirmonthlyPremiumStr.substring(1));
						double total=monthlyPremium+cirmonthlyPremium;
						setformfield(form, "totalPremium", "$"+total);
						try {	
						if(i$outis.$iStrFuzzyMatch(cunaMemDetails.get("addBeneficiary").getAsString(), "Y"))//#SRP00029 Ends
						{
							for (int i = 1; i <=cunaBenDetails.size() ; i++) {
								
									JsonObject cunaBen =cunaBenDetails.get(i-1).getAsJsonObject();
								
										try {
											if(cunaBen.has("firstName")&& !i$outis.$iStrBlank(cunaBen.get("firstName").getAsString())) {
												try {
												if (cunaBen.has("firstName")|| cunaBen.has("middleName")|| cunaBen.has("lastName")) {
													StringBuilder strCunaBen = new StringBuilder();
													try {
														if (cunaBen.has("firstName") && !i$outis.$iStrBlank(cunaBen.get("firstName").getAsString())) {
															strCunaBen.append(cunaBen.get("firstName").getAsString());
														}
													} catch (Exception e) {
														
													}
													try {
														if (cunaBen.has("middleName") && !i$outis.$iStrBlank(cunaBen.get("middleName").getAsString())) {
															strCunaBen.append(" ");
															strCunaBen.append(cunaBen.get("middleName").getAsString());
														}
													} catch (Exception e) {
														
													}
													try {
														if (cunaBen.has("lastName") && !i$outis.$iStrBlank(cunaBen.get("lastName").getAsString())) {
															strCunaBen.append(" ");
															strCunaBen.append(cunaBen.get("lastName").getAsString());
														}
													} catch (Exception e) {
														
													}
													//#MVT000011 changes starts
													setformfield(form, "cunains"+i+"FullName", strCunaBen.toString());	//#MVT000011 changes ends
												}
												}catch(Exception e) {
													
												}
												
												try {
													if (cunaBen.has("dob")) {
														String cunaDob = cunaBen.get("dob").getAsString();
														setformfield(form, "cunaBen"+i+"Dob", cunaDob);
													}
												} catch (Exception e) {
													
												}
												
												try {
													if (cunaBen.has("address")) {
														String cunaAddr = cunaBen.get("address").getAsString();
														setformfield(form, "cunaBen"+i+"Address", cunaAddr);
													}
												} catch (Exception e) {
													
												}
												
												try {

													if (i$outis.$iStrBlank(cunaBen.get("mobileNo").getAsString()))
														setformfield(form, "cunaBen"+i+"PhoneNumber", "");
													else
														setformfield(form, "cunaBen"+i+"PhoneNumber",
																createTECUMobNo(
																		cunaBen.get("mobileNoExtension").getAsString(),
																		cunaBen.get("mobileNo").getAsString()));

												} catch (Exception e) {
													
												}
												
												try {
													if(cunaBen.has("emailId")) {
														setformfield(form, "cunaBen"+i+"Email",cunaBen.get("emailId").getAsString());
													}
													
												}catch(Exception e) {
													
												}
												try {
													if(cunaBen.has("dob")) {	//#MVT000011 changes starts
														setformfield(form, "cunains"+i+"Dob",cunaBen.get("dob").getAsString());	//#MVT000011 changes ends
													}
													
												}catch(Exception e) {
													
												}
												try {
													if(cunaBen.has("identificationNo")) { //#SRP00027 Changes
														setformfield(form, "cunaBen"+i+"DocID",cunaBen.get("identificationNo").getAsString());
				
													}
												}catch(Exception e) {
													
												}
												try {
													if(cunaBen.has("relationInsured")) {	//#MVT000011 changes starts
														setformfield(form, "cunains"+i+"RelDesc",cunaBen.get("relationInsured").getAsString());	//#MVT000011 changes ends

													}
												}catch(Exception e) {
													
												}
												
												try {
													if (cunaBen.has("address")|| cunaBen.has("addLine3")||cunaBen.has("addLine4")||cunaBen.has("addCity")||cunaBen.has("addState")||cunaBen.has("addCountry")||cunaBen.has("addZipCode")) {
														StringBuilder ben1FullAddress = new StringBuilder();
														try {
															if (cunaBen.has("address") && !i$outis.$iStrBlank(cunaBen.get("address").getAsString())) {
																ben1FullAddress.append(cunaBen.get("address").getAsString());
															}
														} catch (Exception e) {
															
														}
														try {
															if (cunaBen.has("addLine3") && !i$outis.$iStrBlank(cunaBen.get("addLine3").getAsString())) {
																ben1FullAddress.append(", ");
																ben1FullAddress.append(cunaBen.get("addLine3").getAsString());
															}
														} catch (Exception e) {
															
														}
														try {
															if (cunaBen.has("addLine4") && !i$outis.$iStrBlank(cunaBen.get("addLine4").getAsString())) {
																ben1FullAddress.append(", ");
																ben1FullAddress.append(cunaBen.get("addLine4").getAsString());
															}
														} catch (Exception e) {
															
														}
														try {
															if (cunaBen.has("addCity") && !i$outis.$iStrBlank(cunaBen.get("addCity").getAsString())) {
																ben1FullAddress.append(", ");
																ben1FullAddress.append(cunaBen.get("addCity").getAsString());
															}
														} catch (Exception e) {
															
														}
														try {
															if (cunaBen.has("addState") && !i$outis.$iStrBlank(cunaBen.get("addState").getAsString())) {
																ben1FullAddress.append(", ");
																ben1FullAddress.append(cunaBen.get("addState").getAsString());
															}
														} catch (Exception e) {
															
														}
														try {
															if (cunaBen.has("addCountry") && !i$outis.$iStrBlank(cunaBen.get("addCountry").getAsString())) {
																ben1FullAddress.append(", ");
																ben1FullAddress.append(cunaBen.get("addCountry").getAsString());
															}
														} catch (Exception e) {
															
														}
														try {
															if (cunaBen.has("addZipCode") && !i$outis.$iStrBlank(cunaBen.get("addZipCode").getAsString())) {
																ben1FullAddress.append(", ");
																ben1FullAddress.append(cunaBen.get("addZipCode").getAsString());
															}
														} catch (Exception e) {
															
														}
														
														setformfield(form, "cunaBen"+i+"Address", ben1FullAddress.toString());
													}
												} catch (Exception e) {
													
												}
												try {
													if (cunaBen.has("gender")) {
														if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "M"))
															setformfield(form, "cunaBen"+i+"GenderDesc", "Male");

														else if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "F"))
															setformfield(form, "cunaBen"+i+"GenderDesc", "Female");
														
														else if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "O"))
															setformfield(form, "cunaBen"+i+"GenderDesc", "Other");
														
														else if (i$outis.$iStrFuzzyMatch(cunaBen.get("gender").getAsString(), "P"))
															setformfield(form, "cunaBen"+i+"GenderDesc", "Prefer Not to Disclose");
													}

												} catch (Exception e) {
													
												}

											}
											
										}catch(Exception e) {
											
										}
									}
							}
								} catch (Exception e) {
									
								}
					}
			
  //cuna_binificiary_details


  // CUNA Enrollment form
			JsonObject CunaEnrollDetails = new JsonObject();
			//#SKP00008 Starts
			try {
				JsonObject document = jsonObject.get("documents").getAsJsonObject();
				JsonArray docArray = document.get("documentDetails").getAsJsonArray();
				JsonObject docDetails = docArray.get(0).getAsJsonObject();
				JsonArray sideArray = docDetails.get("sides").getAsJsonArray();
				JsonObject sideDetails = sideArray.get(0).getAsJsonObject();
				String documentName = sideDetails.get("docName").getAsString();
			}catch(Exception e) {}

			JsonObject personalDetail = jsonObject.get("personalInfo").getAsJsonObject();
			//#SKP00008 Ends
			if(jsonObject.has("cunaInsurance"))
				 CunaEnrollDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
			else
				 CunaEnrollDetails = jsonObject.get("fipEnrolment").getAsJsonObject();      //#PKY00036 changes
					
					try {
					for (int i = 0; i <= filedName.size(); i++) {
				
					fillPDFField(CunaEnrollDetails, filedName.get(i), form);
					}
					}catch(Exception e) {
						
					}
					//SKP00008 Starts
					try {
						if (personalDetail.has("priDocName") && !i$outis.$iStrBlank(personalDetail.get("priDocName").getAsString())) {
							setformfield(form, "priDocName", personalDetail.get("priDocName").getAsString());
						}
					} catch (Exception e) {
						
					}
					//SKP00008 Ends
					try {
						if (cunaMemDetails.has("cunaFirstName")|| cunaMemDetails.has("cunaMiddleName")|| cunaMemDetails.has("cunaLastName")) {
						
							try {
								if (cunaMemDetails.has("cunaFirstName") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaFirstName").getAsString())) {
									setformfield(form, "firstName", CunaEnrollDetails.get("cunaFirstName").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (cunaMemDetails.has("cunaMiddleName") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaMiddleName").getAsString())) {
									setformfield(form, "middleName", CunaEnrollDetails.get("cunaMiddleName").getAsString());
								}
							} catch (Exception e) {
								
							}
							try {
								if (cunaMemDetails.has("cunaLastName") && !i$outis.$iStrBlank(cunaMemDetails.get("cunaLastName").getAsString())) {
									setformfield(form, "lastName", CunaEnrollDetails.get("cunaLastName").getAsString());
								}
							} catch (Exception e) {
								
							}
							
							
						}
					} catch (Exception e) {
						
					}
					

					try {
						if (CunaEnrollDetails.has("cunaMemberAddrCntry")) {
							String memCntry = CunaEnrollDetails.get("cunaMemberAddrCntry").getAsString();
							setformfield(form, "nationalityDesc", memCntry);
						}

					} catch (Exception e) {
						
					}
					try {
						if (CunaEnrollDetails.has("membershipNo")) {  //#PKY00048 changes
							String memCntry = CunaEnrollDetails.get("membershipNo").getAsString();
							setformfield(form, "MEMBERSHIP No", memCntry);
						}

					} catch (Exception e) {
						
					}

					try {
						if (CunaEnrollDetails.has("cunaDob")) {
							String cunaDob = CunaEnrollDetails.get("cunaDob").getAsString();
							setformfield(form, "dob", cunaDob);
						}

					} catch (Exception e) {
						
					}
					try {
						if (CunaEnrollDetails.has("cunaGender")) {
							if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "M"))
								setformfield(form, "genderDesc", "Male");

							else if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "F"))
								setformfield(form, "genderDesc", "Female");
							
							else if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "O"))
								setformfield(form, "genderDesc", "Other");
								
					    	else if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(), "P"))
									setformfield(form, "genderDesc", "Prefer Not to Disclose");

						}

					} catch (Exception e) {
						
					}

					try {
						JsonObject cunaContactData = new JsonObject();
						if(jsonObject.has("contactDetails"))
							cunaContactData = jsonObject.get("contactDetails").getAsJsonObject();
						else
							cunaContactData = jsonObject.get("fipEnrolment").getAsJsonObject();      //#PKY00036 changes
						 

						if (i$outis.$iStrBlank(cunaContactData.get("mobileNumber").getAsString()))
							setformfield(form, "cuna_mobile_number", "");
						else
							setformfield(form, "cuna_mobile_number",
									createTECUMobNo(cunaContactData.get("mobileISD").getAsString(),
											cunaContactData.get("mobileNumber").getAsString()));

					} catch (Exception e) {
						
					}
					try {
						JsonObject ContactData = new JsonObject();
						if(jsonObject.has("contactDetails"))
							ContactData = jsonObject.get("contactDetails").getAsJsonObject();
						else
							ContactData = jsonObject.get("fipEnrolment").getAsJsonObject();     //#PKY00036 changes
						 
						if (ContactData.has("emailId")) {
							String email = ContactData.get("emailId").getAsString();
							setformfield(form, "emailId", email);
						}
					} catch (Exception e) {
						
					}

					try {
						JsonObject homePhonDetails = new JsonObject();
						if(jsonObject.has("additionalDetails"))
							 homePhonDetails = jsonObject.get("additionalDetails").getAsJsonObject();
						else
							homePhonDetails = jsonObject.get("fipEnrolment").getAsJsonObject();   //#PKY00036 changes
						
						if (i$outis.$iStrBlank(homePhonDetails.get("homePhoneNumber").getAsString()))     
							setformfield(form, "cunaHomePhone", "");
						else
							setformfield(form, "cunaHomePhone",
									createTECUMobNo(homePhonDetails.get("homephoneExtension").getAsString(),
											homePhonDetails.get("homePhoneNumber").getAsString()));

					} catch (Exception e) {
						
					}
					try {
						JsonObject cntryDetaios = new JsonObject();
						if(jsonObject.has("additionalDetails"))
							 cntryDetaios = jsonObject.get("additionalDetails").getAsJsonObject();
						else
							cntryDetaios = jsonObject.get("fipEnrolment").getAsJsonObject();          //#PKY00036 changes
						
						if (cntryDetaios.has("birthCountryDesc")) {
							String birthCntry = cntryDetaios.get("birthCountryDesc").getAsString();
							setformfield(form, "birthCountryDesc", birthCntry);
						}

					} catch (Exception e) {
						
					}

					try {
						JsonObject personalDetails = jsonObject.get("personalInfo").getAsJsonObject();
						//#SRP00027 starts
						try {
							if (personalDetails.has("priDocId") && !i$outis.$iStrBlank(personalDetails.get("priDocId").getAsString())) {
								setformfield(form, "priDocName", personalDetails.get("priDocId").getAsString());
							}
						} catch (Exception e) {
							
						}//#SRP00027 Ends
						//SKP00009 Starts
						try {
							if (CunaEnrollDetails.has("cunaAddress") && !i$outis.$iStrBlank(CunaEnrollDetails.get("cunaAddress").getAsString())) {
								setformfield(form, "full_addressline1", CunaEnrollDetails.get("cunaAddress").getAsString());
							}
						} catch (Exception e) {
							
						}
//						try {
//							if (nameInfo.has("mailAddLine1")|| nameInfo.has("mailAddLine2")|| nameInfo.has("mailAddLine3") || nameInfo.has("mailAddLine4")) {
//								StringBuilder strfullAdd = new StringBuilder();
//								try {
//									if (nameInfo.has("mailAddLine1") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine1").getAsString())) {
//										strfullAdd.append(nameInfo.get("mailAddLine1").getAsString());
//									}
//								} catch (Exception e) {
//									
//								}
//								try {
//									if (nameInfo.has("mailAddLine2") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine2").getAsString())) {
//										strfullAdd.append(", ");
//										strfullAdd.append(nameInfo.get("mailAddLine2").getAsString());
//									}
//								} catch (Exception e) {
//									
//								}
//								try {
//									if (nameInfo.has("mailAddLine3") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine3").getAsString())) {
//										strfullAdd.append(", ");
//										strfullAdd.append(nameInfo.get("mailAddLine3").getAsString());
//									}
//								} catch (Exception e) {
//									
//								}
//								try {
//									if (nameInfo.has("mailAddLine4") && !i$outis.$iStrBlank(nameInfo.get("mailAddLine4").getAsString())) {
//										strfullAdd.append(" ");
//										strfullAdd.append(nameInfo.get("mailAddLine4").getAsString());
//									}
//								} catch (Exception e) {
//									
//								}
//								
//								setformfield(form, "full_addressline1", strfullAdd.toString());
//							}
//						} catch (Exception e) {
//							
//						}
						//SKP00009 Ends
						
						
//						try {
//							if (personalDetails.has("priDocName") || personalDetails.has("priDocId")) {
//								StringBuilder concatDoc = new StringBuilder();
//								try {
//									String docName = personalDetails.get("priDocName").getAsString();
//									concatDoc.append(docName);
//									concatDoc.append(" ");
//								}catch(Exception e) {
//									
//								}try {
//									String docId = personalDetails.get("priDocId").getAsString();
//									concatDoc.append(docId);
//								}catch(Exception e) {
//									
//								}
//								
//								setformfield(form, "priDocName", concatDoc.toString());
//							}
//						} catch (Exception e) {
//							
//						}
					} catch (Exception e) {
						
					}
					
			//#SBC0087 ends
					
					
					
					
				}
				
				else {
					for (int i = 0; i <= filedName.size(); i++) {
						try {
							if (pdfName.equalsIgnoreCase("clico_one")) {

								try {
									JsonObject ClicoDetails = jsonObject.get("clicoDeclaration").getAsJsonObject();
									JsonObject additionalDetl = jsonObject.get("additionalDetails").getAsJsonObject();

									// #PKY00008 starts
									JsonArray benneficiaryDetails = ClicoDetails.get("beneficiaryDetails")
											.getAsJsonArray();
									JsonObject benFirstdetails = benneficiaryDetails.get(0).getAsJsonObject();
									JsonObject benSecondDetails = benneficiaryDetails.get(1).getAsJsonObject();
									
									// #PKY00008 ends

									String nomVal = null;
									try {
										nomVal = ClicoDetails.get(filedName.get(i)).getAsString();
									} catch (Exception e) {
										
									}
									try {
										if (!i$outis.$iStrBlank(additionalDetl.get("nationality").getAsString()))
											setformfield(form, "clicoNationality", additionalDetl.get("nationality").getAsString());
									} catch (Exception e) {
										

									}
									if (nomVal != null) {
										setformfield(form, filedName.get(i), nomVal);
									}
									fillPDFField(ClicoDetails, filedName.get(i), form);

									try {
										if (filedName.get(i).equals("clicoPermAddLine1")) {
											StringBuilder strClicoPermAdd = new StringBuilder();
											try {
												if (ClicoDetails.has("clicoPermAddLine1") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoPermAddLine1").getAsString())) {
													strClicoPermAdd.append(
															ClicoDetails.get("clicoPermAddLine1").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (ClicoDetails.has("clicoPermAddLine2") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoPermAddLine2").getAsString())) {
													strClicoPermAdd.append(", ");
													strClicoPermAdd.append(
															ClicoDetails.get("clicoPermAddLine2").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (ClicoDetails.has("clicoPermAddLine3") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoPermAddLine3").getAsString())) {
													strClicoPermAdd.append(", ");
													strClicoPermAdd.append(
															ClicoDetails.get("clicoPermAddLine3").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (ClicoDetails.has("clicoPermAddLine4") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoPermAddLine4").getAsString())) {
													strClicoPermAdd.append(", ");
													strClicoPermAdd.append(
															ClicoDetails.get("clicoPermAddLine4").getAsString());
												}
											} catch (Exception e) {
												
											}
											setformfield(form, filedName.get(i), strClicoPermAdd.toString());
										}
									} catch (Exception e) {
										
									}
									try {
										if (filedName.get(i).equals("clicoMailAddLine1")) {
											StringBuilder strClicoMailAdd = new StringBuilder();
											try {
												if (ClicoDetails.has("clicoMailAddLine1") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoMailAddLine1").getAsString())) {
													strClicoMailAdd.append(
															ClicoDetails.get("clicoMailAddLine1").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (ClicoDetails.has("clicoMailAddLine2") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoMailAddLine2").getAsString())) {
													strClicoMailAdd.append(", ");
													strClicoMailAdd.append(
															ClicoDetails.get("clicoMailAddLine2").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (ClicoDetails.has("clicoMailAddLine3") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoMailAddLine3").getAsString())) {
													strClicoMailAdd.append(", ");
													strClicoMailAdd.append(
															ClicoDetails.get("clicoMailAddLine3").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (ClicoDetails.has("clicoMailAddLine4") && !i$outis.$iStrBlank(
														ClicoDetails.get("clicoMailAddLine4").getAsString())) {
													strClicoMailAdd.append(", ");
													strClicoMailAdd.append(
															ClicoDetails.get("clicoMailAddLine4").getAsString());
												}
											} catch (Exception e) {
												
											}
											setformfield(form, filedName.get(i), strClicoMailAdd.toString());
											// fillPDFField(jsonClicoDetails, filedName.get(i));
										}
									} catch (Exception e) {
										
									}
//                                   //#PKY00008 starts  
									// if (filedName.get(i).equals("clicoBen1AddLine1")) {
//                                            StringBuilder strClicoBen1Buldr = new StringBuilder();
//                                            if (jsonClicoDetails.has("clicoBen1AddLine1") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen1AddLine1").getAsString())) {
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen1AddLine1").getAsString());
//                                            }
//                                            if (jsonClicoDetails.has("clicoBen1Addline2") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen1Addline2").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen1Addline2").getAsString());
//                                            }
//                                            if (jsonClicoDetails.has("clicoBen1AddLine3") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen1AddLine3").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen1AddLine3").getAsString());
//                                            }
//                                            if (jsonClicoDetails.has("clicoBen1AddLine4") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen1AddLine4").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen1AddLine4").getAsString());
//                                            }
//                                            setformfield(form, filedName.get(i), strClicoBen1Buldr.toString());
//                                            //fillPDFField(jsonClicoDetails, filedName.get(i));
//                                       }
									try {
										if (filedName.get(i).equals("clicoBen1AddLine1")) {
											StringBuilder strClicoBen1Buldr = new StringBuilder();
											try {
												if (benFirstdetails.has("addLine1") && !i$outis
														.$iStrBlank(benFirstdetails.get("addLine1").getAsString())) {
													strClicoBen1Buldr
															.append(benFirstdetails.get("addLine1").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (benFirstdetails.has("addline2") && !i$outis
														.$iStrBlank(benFirstdetails.get("addline2").getAsString())) {
													strClicoBen1Buldr.append(", ");
													strClicoBen1Buldr
															.append(benFirstdetails.get("addline2").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (benFirstdetails.has("addLine3") && !i$outis
														.$iStrBlank(benFirstdetails.get("addLine3").getAsString())) {
													strClicoBen1Buldr.append(", ");
													strClicoBen1Buldr
															.append(benFirstdetails.get("addLine3").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (benFirstdetails.has("addLine4") && !i$outis
														.$iStrBlank(benFirstdetails.get("addLine4").getAsString())) {
													strClicoBen1Buldr.append(", ");
													strClicoBen1Buldr
															.append(benFirstdetails.get("addLine4").getAsString());
												}
											} catch (Exception e) {
												
											}
											setformfield(form, filedName.get(i), strClicoBen1Buldr.toString());
											// fillPDFField(jsonClicoDetails, filedName.get(i));
										}
									} catch (Exception e) {
										
									}

//                                        if (filedName.get(i).equals("clicoBen1EmpAdd")) {
//                                            StringBuilder strClicoBen1Buldr = new StringBuilder();
//                                            if (ben1details.has("addLine1") && !i$outis.$iStrBlank(ben1details.get("addLine1").getAsString())) {
//                                                strClicoBen1Buldr.append(ben1details.get("addLine1").getAsString());
//                                            }
//                                            if (ben1details.has("addline2") && !i$outis.$iStrBlank(ben1details.get("addline2").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(ben1details.get("addline2").getAsString());
//                                            }
//                                            if (ben1details.has("addLine3") && !i$outis.$iStrBlank(ben1details.get("addLine3").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(ben1details.get("addLine3").getAsString());
//                                            }
//                                            if (ben1details.has("addLine4") && !i$outis.$iStrBlank(ben1details.get("addLine4").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(ben1details.get("addLine4").getAsString());
//                                            }
//                                            setformfield(form, filedName.get(i), strClicoBen1Buldr.toString());
//                                            //fillPDFField(jsonClicoDetails, filedName.get(i));
//                                        }

//                                        if (filedName.get(i).equals("clicoBen2Add")) {
//                                            StringBuilder strClicoBen1Buldr = new StringBuilder();
//                                            if (jsonClicoDetails.has("clicoBen2AddLine1") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen2AddLine1").getAsString())) {
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen2AddLine1").getAsString());
//                                            }
//                                            if (jsonClicoDetails.has("clicoBen2Addline2") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen2Addline2").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen2Addline2").getAsString());
//                                            }
//                                            if (jsonClicoDetails.has("clicoBen2AddLine3") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen2AddLine3").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen2AddLine3").getAsString());
//                                            }
//                                            if (jsonClicoDetails.has("clicoBen2AddLine4") && !i$outis.$iStrBlank(jsonClicoDetails.get("clicoBen2AddLine4").getAsString())) {
//                                                strClicoBen1Buldr.append(", ");
//                                                strClicoBen1Buldr.append(jsonClicoDetails.get("clicoBen2AddLine4").getAsString());
//                                            }
//                                            setformfield(form, filedName.get(i), strClicoBen1Buldr.toString());
//
//                                        }
									try {
										if (filedName.get(i).equals("clicoBen2AddLine1")) {
											StringBuilder strClicoBen1Buldr = new StringBuilder();
											String benSecondsel = ClicoDetails.get("addBeneficiary").getAsString();
											if(benSecondsel.equalsIgnoreCase("Y")) {
											try {
												if (benSecondDetails.has("addLine1") && !i$outis
														.$iStrBlank(benSecondDetails.get("addLine1").getAsString())) {
													strClicoBen1Buldr
															.append(benSecondDetails.get("addLine1").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (benSecondDetails.has("addline2") && !i$outis
														.$iStrBlank(benSecondDetails.get("addline2").getAsString())) {
													strClicoBen1Buldr.append(", ");
													strClicoBen1Buldr
															.append(benSecondDetails.get("addline2").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (benSecondDetails.has("addLine3") && !i$outis
														.$iStrBlank(benSecondDetails.get("addLine3").getAsString())) {
													strClicoBen1Buldr.append(", ");
													strClicoBen1Buldr
															.append(benSecondDetails.get("addLine3").getAsString());
												}
											} catch (Exception e) {
												
											}
											try {
												if (benSecondDetails.has("addLine4") && !i$outis
														.$iStrBlank(benSecondDetails.get("addLine4").getAsString())) {
													strClicoBen1Buldr.append(", ");
													strClicoBen1Buldr
															.append(benSecondDetails.get("addLine4").getAsString());
												}
											} catch (Exception e) {
												
											}
											setformfield(form, filedName.get(i), strClicoBen1Buldr.toString());
											}
										}
									} catch (Exception e) {
										
									}
									
                                                                  

								} catch (Exception e) {
									
								}								
								try { //#MVT00089 changes starts
									JsonObject clicoPersonalDetail = jsonObject.get("personalInfo").getAsJsonObject();
									if(clicoPersonalDetail.has("firstName") && !i$outis.$iStrBlank(clicoPersonalDetail.get("firstName").getAsString())) {
										setformfield(form, "clicoInsuredFirstName", clicoPersonalDetail.get("firstName").getAsString());
									}
									if(clicoPersonalDetail.has("middleName") && !i$outis.$iStrBlank(clicoPersonalDetail.get("middleName").getAsString())) {
										setformfield(form, "middleNameInsuredClico", clicoPersonalDetail.get("middleName").getAsString());
									}
									if(clicoPersonalDetail.has("lastName") && !i$outis.$iStrBlank(clicoPersonalDetail.get("lastName").getAsString())) {
										setformfield(form, "lastNameInsuredClico", clicoPersonalDetail.get("lastName").getAsString());
									}
								}catch(Exception e) {
									
								}//#MVT00089 changes ends
								// }
								try {
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
								} catch (Exception e) {
									
								}
								try {
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}

							} else if (pdfName.equalsIgnoreCase("clico_two")) {
								String clico2 = jsonObject.get("moreInfo").getAsJsonObject().get("isapplyForClico")
										.getAsString();
								if (clico2.equalsIgnoreCase("Y")) {
									try {
										String nomVal = jsonObject.get("clicoDeclaration").getAsJsonObject()
												.get(filedName.get(i)).getAsString();
										setformfield(form, filedName.get(i), nomVal);
									} catch (Exception e) {
										
									}
								}
								try {
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}
								try {
									if (jsonObject.get("clicoDeclaration").getAsJsonObject().get("Group1").getAsString()
											.equalsIgnoreCase("Y")) {
										setformfield(form, "Group1", "GROUP LIFE PREMIUM");
									}
								} catch (Exception e) {
									
								}
								try {
									if (jsonObject.get("clicoDeclaration").getAsJsonObject().get("Group2").getAsString()
											.equalsIgnoreCase("Y")) {
										setformfield(form, "Group2", "GROUP HEALTH PREMIUM");
									}
								} catch (Exception e) {
									
								}
							} else if (pdfName.equalsIgnoreCase("health_isurance")) {

								String health = jsonObject.get("moreInfo").getAsJsonObject()
										.get("isApplyForHealthIssurance").getAsString();

								if (health.equalsIgnoreCase("Y")) {
									JsonObject jsonHealthDetails = jsonObject.get("healthIsurance").getAsJsonObject();
									jsonHealthDetails = separateDateComps(jsonHealthDetails, "healthDob");
									jsonHealthDetails = separateDateComps(jsonHealthDetails, "healthDepBen1Date");
									jsonHealthDetails = separateDateComps(jsonHealthDetails, "healthDepBen2Date");
									jsonHealthDetails = separateDateComps(jsonHealthDetails, "healthDepBen3Date");
									jsonHealthDetails = separateDateComps(jsonHealthDetails, "healthDepBen4Date");
									try {
										String nomVal = jsonObject.get("healthIsurance").getAsJsonObject()
												.get(filedName.get(i)).getAsString();
										setformfield(form, filedName.get(i), nomVal);

									} catch (Exception e) {
										
									}
									fillPDFField(jsonObject.get("healthIsurance").getAsJsonObject(), filedName.get(i),
											form);

//                                    String healthGender=jsonHealthDetails.getAsString();
//                                    setformfield(form, filedName.get(i),healthGender );
									// radios for dependent beneficiary trustee status
									try {
										String[] benDepValues = { "healthDepBen1Dependent", "healthDepBen1Beneficiary",
												"healthDepBen1Trustee", "healthDepBen2Dependent",
												"healthDepBen2Beneficiary", "healthDepBen2Trustee",
												"healthDepBen3Dependent", "healthDepBen3Beneficiary",
												"healthDepBen3Trustee", "healthDepBen4Dependent",
												"healthDepBen4Beneficiary", "healthDepBen4Trustee" };
										try {

											for (String benField : benDepValues) {
												if (i$outis.$iStrFuzzyMatch(
														jsonHealthDetails.get(benField).getAsString(),
														i$ResM.I_YCHAR)) {
													setformfield(form, benField, "X");
												}
											}
										} catch (Exception e) {
											
										}
									} catch (Exception e) {
										
									}
								}
								try {
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
								} catch (Exception e) {
									
								}
								try {
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}
								// #PKY00007 starts
								try {
									//if(filedName.get(i)
									//
									String healthdetails1 = jsonObject.get("healthIsurance").getAsJsonObject()
											.get("healthQuery1").getAsString();
									if (healthdetails1.equalsIgnoreCase("Y")) {
										setformfield(form, "healthQueryDetails01", jsonObject.get("healthIsurance")
												.getAsJsonObject().get("healthQueryDetails1").getAsString());
									}

								} catch (Exception e) {
									
								}
								try {
									String healthdetails2 = jsonObject.get("healthIsurance").getAsJsonObject()
											.get("healthQuery3").getAsString();

									if (healthdetails2.equalsIgnoreCase("Y")) {
										setformfield(form, "healthQueryDetails03", jsonObject.get("healthIsurance")
												.getAsJsonObject().get("healthQueryDetails3").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									String healthdetails3 = jsonObject.get("healthIsurance").getAsJsonObject()
											.get("healthQuery6").getAsString();

									if (healthdetails3.equalsIgnoreCase("Y")) {
										setformfield(form, "healthQueryDetailsCountriess",
												jsonObject.get("healthIsurance").getAsJsonObject()
														.get("healthQueryDetailsCountries").getAsString());
										setformfield(form, "healthQueryDetailsDurations",
												jsonObject.get("healthIsurance").getAsJsonObject()
														.get("healthQueryDetailsDuration").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									String healthdetails4 = jsonObject.get("healthIsurance").getAsJsonObject()
											.get("healthQuery15").getAsString();

									if (healthdetails4.equalsIgnoreCase("Y")) {
										setformfield(form, "healthQueryDetails015", jsonObject.get("healthIsurance")
												.getAsJsonObject().get("healthQueryDetails15").getAsString());
									}
								} catch (Exception e) {
									
								}

								// #PKY00007 ends
							} else if (pdfName.equalsIgnoreCase("joint_patner")) {

								String isJoint = jsonObject.get("moreInfo").getAsJsonObject().get("isJointPatner").getAsString();
								JsonObject jointData = new JsonObject();
								try {
									jointData = jsonObject.get("jointPatnerAuthorization").getAsJsonObject();
								}catch(Exception e) {
									
								}
								if (isJoint.equalsIgnoreCase("Y")) {
									try {

										if (jsonObject.has("jointPatnerAuthorization")) {
											JsonObject jsonJPDetails = jsonObject.get("jointPatnerAuthorization").getAsJsonObject();
											try {
												if (jsonJPDetails.has(filedName.get(i))) {
													String nomVal = jsonJPDetails.get(filedName.get(i)).getAsString();
													setformfield(form, filedName.get(i), nomVal);
												}
											} catch (Exception e) {
												
											}
											try {//#SRP00040 Starts
												if (i$outis.$iStrBlank(jsonJPDetails.get("JointPartnerMobileId").getAsString()))
													setformfield(form, "mobilePhone", "");
												else
													setformfield(form, "mobilePhone",
															createTECUMobNo(
																	jsonJPDetails.get("JointPartnerMobileIsdNo").getAsString(),
																	jsonJPDetails.get("JointPartnerMobileId").getAsString()));

											} catch (Exception e) {
												
											}
											try {
												if (i$outis.$iStrBlank(jsonJPDetails.get("JointPartnerHomeTelNo").getAsString()))
													setformfield(form, "homePhone", "");
												else
													setformfield(form, "homePhone",
															createTECUMobNo(
																	jsonJPDetails.get("JointPartnerHomeTelIsd").getAsString(),
																	jsonJPDetails.get("JointPartnerHomeTelNo").getAsString()));

											} catch (Exception e) {
												
											}
											try {
												if (!i$outis.$iStrBlank(jsonJPDetails.get("JointPartnerOtherNo").getAsString()))
													setformfield(form, "other", jsonJPDetails.get("JointPartnerOtherNo").getAsString());
											} catch (Exception e) {
												
											}//#SRP00040 Ends
											if (jsonJPDetails.has("mailAddLine1JP")|| jsonJPDetails.has("mailAddLine2JP")) {
												StringBuilder strJPAdd = new StringBuilder();
												try {
													if (!jsonJPDetails.get("mailAddLine1JP").getAsString().isEmpty()) {
														strJPAdd.append(jsonJPDetails.get("mailAddLine1JP").getAsString());
													}
												} catch (Exception e) {
													
												}
												try {
													if (!jsonJPDetails.get("mailAddLine2JP").getAsString().isEmpty()) {
														strJPAdd.append(", ");
														strJPAdd.append(jsonJPDetails.get("mailAddLine2JP").getAsString());
													}
												} catch (Exception e) {
													
												}
												try {
													if (!jsonJPDetails.get("mailAddStateJP").getAsString().isEmpty()) {
														strJPAdd.append(", ");
														strJPAdd.append(jsonJPDetails.get("mailAddStateJP").getAsString());
													}
												} catch (Exception e) {
													
												}
												try {
													if (!jsonJPDetails.get("mailAddZipCodeJP").getAsString().isEmpty()) {
														strJPAdd.append(", ");
														strJPAdd.append(jsonJPDetails.get("mailAddZipCodeJP").getAsString());
													}
												} catch (Exception e) {
													
												}
												setformfield(form, "mailAddLineJP", strJPAdd.toString());
												setformfield(form, "mailAddCityJP",jsonJPDetails.get("mailAddCityJP").getAsString());
											}
										}
									} catch (Exception e) {
										
									}
								}
								try {
									if (jointData.has("PassportIssueDate")) {
										setformfield(form, "passportIssueDateJP", jointData.get("PassportIssueDate").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									if (jointData.has("CustomerDpIssueDate")) {
										setformfield(form, "customerDpIssueDateJP", jointData.get("CustomerDpIssueDate").getAsString());
									}
								} catch (Exception e) {
									
								}
								try {
									addImage(stamp, form, "Qr_code_1", base64);
								}catch(Exception e) {
									
								}
								
								try {
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}

							} else if (pdfName.equalsIgnoreCase("cuna")) {

								String isCuna = jsonObject.get("moreInfo").getAsJsonObject().get("isapplyForCunaInsurance").getAsString();

								if (isCuna.equalsIgnoreCase("Y")) {
									try {
										String nomVal = jsonObject.get("cunaInsurance").getAsJsonObject().get(filedName.get(i)).getAsString();
										setformfield(form, filedName.get(i), nomVal);
									} catch (Exception e) {
										
									}
								}
								try {
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}
								if (isCuna.equalsIgnoreCase("Y")) {
									try {
										JsonObject jsonCunaDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
										if (jsonCunaDetails.has("beneficiaryDetails")) {
											JsonObject jsonBen1Details = jsonCunaDetails.get("beneficiaryDetails").getAsJsonArray().get(0).getAsJsonObject();
											JsonObject jsonBen2Details = jsonCunaDetails.get("beneficiaryDetails").getAsJsonArray().get(1).getAsJsonObject();
											try {
												for (int k = 0; k < jsonBen1Details.keySet().size(); k++) {
													String key = jsonBen1Details.keySet().toArray()[k].toString();
													String value = jsonBen1Details.get(key).getAsString();
													key = "cunaBen1" + getStringInPascalCase(key);
													jsonCunaDetails.addProperty(key, value);
												}
											} catch (Exception e) {
												
											}
											try {
												for (int j = 0; j < jsonBen2Details.keySet().size(); j++) {
													String key = jsonBen2Details.keySet().toArray()[j].toString();
													String value = jsonBen2Details.get(key).getAsString();
													key = "cunaBen2" + getStringInPascalCase(key);
													jsonCunaDetails.addProperty(key, value);
												}
											} catch (Exception e) {
												
											}
											jsonCunaDetails.remove("beneficiaryDetails");
										}
										if (jsonCunaDetails.has("cunaBen1Dob")) {
											try {
												String[] dateComps = jsonCunaDetails.get("cunaBen1Dob").getAsString()
														.split("-");
												try {
													if (dateComps[2].length() == 1
															&& Integer.parseInt(dateComps[2]) < 10) {
														String day = "0" + dateComps[2];
														jsonCunaDetails.addProperty("cunaBen1DobDD", day);
													} else {
														jsonCunaDetails.addProperty("cunaBen1DobDD", dateComps[2]);
													}
												} catch (Exception e) {
													
												}
												try {
													if (dateComps[1].length() == 1
															&& Integer.parseInt(dateComps[1]) < 10) {
														String month = "0" + dateComps[1];
														jsonCunaDetails.addProperty("cunaBen1DobMM", month);
													} else {
														jsonCunaDetails.addProperty("cunaBen1DobMM", dateComps[1]);
													}
												} catch (Exception e) {
													
												}
												jsonCunaDetails.addProperty("cunaBen1DobYYYY", dateComps[0]);
											} catch (Exception e) {
												
											}
										}
										if (jsonCunaDetails.has("cunaBen2Dob")) {
											try {
												String[] dateComps = jsonCunaDetails.get("cunaBen2Dob").getAsString()
														.split("-");
												try {
													if (dateComps[2].length() == 1
															&& Integer.parseInt(dateComps[2]) < 10) {
														String day = "0" + dateComps[2];
														jsonCunaDetails.addProperty("cunaBen2DobDD", day);
													} else {
														jsonCunaDetails.addProperty("cunaBen2DobDD", dateComps[2]);
													}
												} catch (Exception e) {
													
												}
												try {
													if (dateComps[1].length() == 1
															&& Integer.parseInt(dateComps[1]) < 10) {
														String month = "0" + dateComps[1];
														jsonCunaDetails.addProperty("cunaBen2DobMM", month);
													} else {
														jsonCunaDetails.addProperty("cunaBen2DobMM", dateComps[1]);
													}
												} catch (Exception e) {
													
												}
												jsonCunaDetails.addProperty("cunaBen2DobYYYY", dateComps[0]);
											} catch (Exception e) {
												
											}
										}
										if (jsonCunaDetails.has("cunaDob")) {
											try {
												String[] dateComps = jsonCunaDetails.get("cunaDob").getAsString()
														.split("-");
												try {
													if (dateComps[2].length() == 1
															&& Integer.parseInt(dateComps[2]) < 10) {
														String day = "0" + dateComps[2];
														jsonCunaDetails.addProperty("cunadobDD", day);
													} else {
														jsonCunaDetails.addProperty("cunadobDD", dateComps[2]);
													}
												} catch (Exception e) {
													
												}
												try {
													if (dateComps[1].length() == 1
															&& Integer.parseInt(dateComps[1]) < 10) {
														String month = "0" + dateComps[1];
														jsonCunaDetails.addProperty("cunadobMM", month);
													} else {
														jsonCunaDetails.addProperty("cunadobMM", dateComps[1]);
													}
												} catch (Exception e) {
													
												}
												jsonCunaDetails.addProperty("cunadobYYYY", dateComps[0]);
											} catch (Exception e) {
												
											}
										}
										String nomVal = null;
										try {
											nomVal = jsonCunaDetails.get(filedName.get(i)).getAsString();
										} catch (Exception e) {
											
										}

										if (nomVal != null) {
											setformfield(form, filedName.get(i), nomVal);
										}
										fillPDFField(jsonCunaDetails, filedName.get(i), form);
									} catch (Exception e) {
										
									}
								}
								try {
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}

								// SBC0087 STARTS
								// FOR CUNA NEW PDF 
//								try {
//									JsonObject nameInfo = jsonObject.get("personalInfo").getAsJsonObject();
//									
//									if (nameInfo.has("firstName") || nameInfo.has("middleName")
//											|| nameInfo.has("lastName")) {
//										String firstname = nameInfo.get("firstName").getAsString();
//										String secondname = nameInfo.get("middleName").getAsString();
//										String thirdname = nameInfo.get("lastName").getAsString();
//
//										String finalname = firstname.concat(" " + secondname + " " + thirdname);
//										setformfield(form, "cunaMemFullName", finalname);
//									}
//
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									JsonObject cunaMemDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
//									try {
//										if (cunaMemDetails.has("cunaBen1FirstName")
//												|| cunaMemDetails.has("cunaBen1MiddleName")
//												|| cunaMemDetails.has("cunaBen1LastName")) {
//											String cunaBenFname = cunaMemDetails.get("cunaBen1FirstName").getAsString();
//											String cunaBenMname = cunaMemDetails.get("cunaBen1MiddleName")
//													.getAsString();
//											String cunaBenLname = cunaMemDetails.get("cunaBen1LastName").getAsString();
//
//											String finalBenName = cunaBenFname
//													.concat(" " + cunaBenMname + " " + cunaBenLname);
//											setformfield(form, "cunaBen1FullName", finalBenName);
//
//										}
//									} catch (Exception e) {
//										
//									}
//									try {
//										if (cunaMemDetails.has("cunaBen1Dob")) {
//											String cunaDob = cunaMemDetails.get("cunaBen1Dob").getAsString();
//											setformfield(form, "cunaBen1Dob", cunaDob);
//										}
//									} catch (Exception e) {
//										
//									}
//									try {
//										if (cunaMemDetails.has("cunaBen2FirstName")
//												|| cunaMemDetails.has("cunaBen2MiddleName")
//												|| cunaMemDetails.has("cunaBen2LastName")) {
//											String cunaBen2Fname = cunaMemDetails.get("cunaBen2FirstName")
//													.getAsString();
//											String cunaBenM2name = cunaMemDetails.get("cunaBen2MiddleName")
//													.getAsString();
//											String cunaBen2Lname = cunaMemDetails.get("cunaBen2LastName").getAsString();
//
//											String finalBenName = cunaBen2Fname
//													.concat(" " + cunaBenM2name + " " + cunaBen2Lname);
//											setformfield(form, "cunaBen2FullName", finalBenName);
//										}
//									} catch (Exception e) {
//										
//									}
//
//								} catch (Exception e) {
//									
//								}
//
//								// CUNA Enrollment form
//								JsonObject CunaEnrollDetails = jsonObject.get("cunaInsurance").getAsJsonObject();
//								fillPDFField(CunaEnrollDetails, filedName.get(i), form);
//								try {
//									if (CunaEnrollDetails.has("cunaFirstName")
//											|| CunaEnrollDetails.has("cunaMiddleName")
//											|| CunaEnrollDetails.has("cunaLastName")) {
//
//										String fName = CunaEnrollDetails.get("cunaFirstName").getAsString();
//										setformfield(form, "firstName", fName);
//
//										String mName = CunaEnrollDetails.get("cunaMiddleName").getAsString();
//										setformfield(form, "middleName", mName);
//
//										String lName = CunaEnrollDetails.get("cunaLastName").getAsString();
//										setformfield(form, "lastName", lName);
//									}
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									if (CunaEnrollDetails.has("cunaMemberAddrCntry")) {
//										String memCntry = CunaEnrollDetails.get("cunaMemberAddrCntry").getAsString();
//										setformfield(form, "nationalityDesc", memCntry);
//									}
//
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									if (CunaEnrollDetails.has("cunaDob")) {
//										String cunaDob = CunaEnrollDetails.get("cunaDob").getAsString();
//										setformfield(form, "dob", cunaDob);
//									}
//
//								} catch (Exception e) {
//									
//								}
//								try {
//									if (CunaEnrollDetails.has("cunaGender")) {
//										if (i$outis.$iStrFuzzyMatch(CunaEnrollDetails.get("cunaGender").getAsString(),
//												"Male"))
//											setformfield(form, "genderDesc", "Male");
//
//										else if (i$outis.$iStrFuzzyMatch(
//												CunaEnrollDetails.get("cunaGender").getAsString(), "Female"))
//											setformfield(form, "genderDesc", "Female");
//
//									}
//
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									JsonObject cunaContactData = jsonObject.get("contactDetails").getAsJsonObject();
//
//									if (i$outis.$iStrBlank(cunaContactData.get("mobileNumber").getAsString()))
//										setformfield(form, "cuna_mobile_number", "");
//									else
//										setformfield(form, "cuna_mobile_number",
//												createTECUMobNo(cunaContactData.get("mobileISD").getAsString(),
//														cunaContactData.get("mobileNumber").getAsString()));
//
//								} catch (Exception e) {
//									
//								}
//								try {
//									JsonObject ContactData = jsonObject.get("contactDetails").getAsJsonObject();
//									if (ContactData.has("emailId")) {
//										String email = ContactData.get("emailId").getAsString();
//										setformfield(form, "emailId", email);
//									}
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									JsonObject homePhonDetails = jsonObject.get("additionalDetails").getAsJsonObject();
//									if (i$outis.$iStrBlank(homePhonDetails.get("homePhoneNumber").getAsString()))
//										setformfield(form, "cunaHomePhone", "");
//									else
//										setformfield(form, "cunaHomePhone",
//												createTECUMobNo(homePhonDetails.get("homephoneExtension").getAsString(),
//														homePhonDetails.get("homePhoneNumber").getAsString()));
//
//								} catch (Exception e) {
//									
//								}
//								try {
//									JsonObject cntryDetaios = jsonObject.get("additionalDetails").getAsJsonObject();
//									if (cntryDetaios.has("birthCountryDesc")) {
//										String birthCntry = cntryDetaios.get("birthCountryDesc").getAsString();
//										setformfield(form, "birthCountryDesc", birthCntry);
//									}
//
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									JsonObject personalDetails = jsonObject.get("personalInfo").getAsJsonObject();
//									try {
//
//										if (personalDetails.has("mailAddLine1") || personalDetails.has("mailAddLine2")
//												|| personalDetails.has("mailAddLine3")
//												|| personalDetails.has("mailAddLine4")) {
//											String add1 = personalDetails.get("mailAddLine1").getAsString();
//											String add2 = personalDetails.get("mailAddLine2").getAsString();
//											String add3 = personalDetails.get("mailAddLine3").getAsString();
//											String add4 = personalDetails.get("mailAddLine4").getAsString();
//
//											String fullAddrress = add1.concat(" " + add2 + " " + add3 + " " + add4);
//											setformfield(form, "full_addressline1", fullAddrress);
//										}
//									} catch (Exception e) {
//										
//									}
//
//									try {
//										if (personalDetails.has("priDocName")) {
//											String docName = personalDetails.get("priDocName").getAsString();
//											setformfield(form, "priDocName", docName);
//										}
//									} catch (Exception e) {
//										
//									}
//								} catch (Exception e) {
//									
//								}
//								try {
//
//									if (i$outis.$iStrBlank(CunaEnrollDetails.get("cunaBen1PhoneNo").getAsString()))
//										setformfield(form, "cunaBen1PhoneNumber", "");
//									else
//										setformfield(form, "cunaBen1PhoneNumber",
//												createTECUMobNo(
//														CunaEnrollDetails.get("cunaBen1PhoneExtension").getAsString(),
//														CunaEnrollDetails.get("cunaBen1PhoneNo").getAsString()));
//
//								} catch (Exception e) {
//									
//								}
//
//								try {
//									if (i$outis.$iStrBlank(CunaEnrollDetails.get("cunaBen2PhoneNo").getAsString()))
//										setformfield(form, "cunaBen2PhoneNumber", "");
//									else
//										setformfield(form, "cunaBen2PhoneNumber",
//												createTECUMobNo(
//														CunaEnrollDetails.get("cunaBen2PhoneExtension").getAsString(),
//														CunaEnrollDetails.get("cunaBen2PhoneNo").getAsString()));
//
//								} catch (Exception e) {
//									
//								}

								// SBC0087 ENDS

							} else if (pdfName.equalsIgnoreCase("grec_insurance")) {

								String isJoint = jsonObject.get("moreInfo").getAsJsonObject()
										.get("isapplyForGregIssurance").getAsString();

								if (isJoint.equalsIgnoreCase("Y")) {
									try {
										String nomVal = jsonObject.get("grecInsuarance").getAsJsonObject()
												.get(filedName.get(i)).getAsString();
										setformfield(form, filedName.get(i), nomVal);
									} catch (Exception e) {
										
									}
								}
								try {
									setformfield(form, "applicationId", jsonObject.get("referenceNo").getAsString());
								} catch (Exception e) {
									
								}

							} else if (pdfName.equalsIgnoreCase("enhanced_due_diligence_form")) {
								try {
									JsonObject dataObject = jsonObject.get("enhanced_due").getAsJsonObject();
									fillPDFField(dataObject, filedName.get(i), form);
									setformfield(form, "applicationId", jsonObject.get("applicationId").getAsString());
									setformfield(form, "referenceNo", jsonObject.get("referenceNo").getAsString());
									JsonObject personalInfo = jsonObject.get("personalInfo").getAsJsonObject();
									try {
										if (FuzzySearch.weightedRatio(personalInfo.get("priDocName").getAsString(),
												IConstants.I_NATIONALID.toString()) >= 90
												&& FuzzySearch.weightedRatio(
														personalInfo.get("priDocName").getAsString(),
														IConstants.I_NATIONALID.toString()) <= 100) {
											setformfield(form, "docNoID", personalInfo.get("priDocId").getAsString());
											setformfield(form, "ID", "X");
										} else if (FuzzySearch.weightedRatio(
												personalInfo.get("priDocName").getAsString(),
												IConstants.I_PASSPORT.toString()) >= 90
												&& FuzzySearch.weightedRatio(
														personalInfo.get("priDocName").getAsString(),
														IConstants.I_PASSPORT.toString()) <= 100) {
											setformfield(form, "docNoPP", personalInfo.get("priDocId").getAsString());
											setformfield(form, "PP", "X");
										} else if (FuzzySearch.weightedRatio(
												personalInfo.get("priDocName").getAsString(),
												IConstants.I_DRIVERSPERMIT.toString()) >= 90
												&& FuzzySearch.weightedRatio(
														personalInfo.get("priDocName").getAsString(),
														IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
											setformfield(form, "docNoDP", personalInfo.get("priDocId").getAsString());
											setformfield(form, "DP", "X");
										}
										if (FuzzySearch.weightedRatio(personalInfo.get("secDocName").getAsString(),
												IConstants.I_DRIVERSPERMIT.toString()) >= 90
												&& FuzzySearch.weightedRatio(
														personalInfo.get("secDocName").getAsString(),
														IConstants.I_DRIVERSPERMIT.toString()) <= 100) {
											setformfield(form, "docNoDP", personalInfo.get("secDocId").getAsString());
											setformfield(form, "DP", "X");
										} else if (FuzzySearch.weightedRatio(
												personalInfo.get("secDocName").getAsString(),
												IConstants.I_PASSPORT.toString()) >= 90
												&& FuzzySearch.weightedRatio(
														personalInfo.get("secDocName").getAsString(),
														IConstants.I_PASSPORT.toString()) <= 100) {
											setformfield(form, "docNoPP", personalInfo.get("secDocId").getAsString());
											setformfield(form, "PP", "X");
										} else if (FuzzySearch.weightedRatio(
												personalInfo.get("secDocName").getAsString(),
												IConstants.I_NATIONALID.toString()) >= 90
												&& FuzzySearch.weightedRatio(
														personalInfo.get("secDocName").getAsString(),
														IConstants.I_NATIONALID.toString()) <= 100) {
											setformfield(form, "docNoID", personalInfo.get("secDocId").getAsString());
											setformfield(form, "ID", "X");
										}
									} catch (Exception e) {
										
									}
									
									try {
										addImage(stamp, form, "Qr_code_1", base64);
									}catch(Exception e) {
										
									}
									//MSA00004 starts
									try {
										if (dataObject.has("anticipatedCheckShares")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckShares").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckShares").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckShares_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckFixedDeposits")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckFixedDeposits").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckFixedDeposits").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckFixedDeposits_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckCharacterLoan")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckCharacterLoan").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckCharacterLoan").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckCharacterLoan_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckMortgage")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckMortgage").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckMortgage").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckMortgage_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckShareDeposit")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckShareDeposit").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckShareDeposit").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckShareDeposit_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckInvestment")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckInvestment").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckInvestment").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckInvestment_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckMotorVehicleLoan")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckMotorVehicleLoan").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckMotorVehicleLoan").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckMotorVehicleLoan_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									try {
										if (dataObject.has("anticipatedCheckLINCU")) {
											String anticipated = String.valueOf(dataObject.get("anticipatedCheckLINCU").getAsBoolean());
											if (i$outis.$iStrFuzzyMatch(dataObject.get("anticipatedCheckLINCU").getAsString(), anticipated)) {
												setformfieldS(form, "anticipatedCheckLINCU_Y", "true");
											}
										}
									} catch (Exception e) {

									}
									//MSA00004 ends 
									
									//SBC0087 Starts	//#SRP00041 Changes starts
									try {										
										if(dataObject.has("pepRelationship") && !i$outis.$iStrBlank(dataObject.get("pepRelationship").getAsString()) ) {
											if (i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "S")) {
												setformfieldS(form, "pepMemberCheckSelf_Y", "On");
											} else if (i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "F")
													|| i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "C")
													|| i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "P")
													|| i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "R")
													|| i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "Q")) {
												setformfieldS(form, "pepMemberCheckFamilyMember_Y", "On");
											} else if (i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "O")) {
												setformfieldS(form, "pepMemberCheckOther_Y", "On");
											} else if (i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "U")) {
												setformfieldS(form, "pepMemberCheckUltimateBen_Y", "On");
											} else if (i$outis.$iStrFuzzyMatch(dataObject.get("pepRelationship").getAsString(), "A")) {
												setformfieldS(form, "pepMemberCheckCloseAssociate_Y", "On");
											}
										}
									}catch(Exception e) {
										
									}
								    //SBC0087 Ends   //#SRP00041 Changes Ends
								} catch (Exception e) {
									
								}
							}
							// SBC0087 STARTS	//#MVT000013 changes starts
							else if (pdfName.equalsIgnoreCase("TECU_Member_Health")||pdfName.equalsIgnoreCase("TECU_Member_Health_Application")) {	//#MVT000013 changes ends
								
								try {
									JsonObject insuranceDetails = new JsonObject();  //#SRP00012 Start
									if(jsonObject.has("tatilInsurance"))
										insuranceDetails = jsonObject.get("tatilInsurance").getAsJsonObject();
									else
										insuranceDetails = jsonObject.get("tatilApplication").getAsJsonObject();  //#SRP00012 Ends

										
									fillPDFField(insuranceDetails, filedName.get(i), form);

									try { //#SRP00031 Starts
										if(insuranceDetails.has("tatilspouseRelationshipOther") && !i$outis.$iStrBlank(insuranceDetails.get("tatilspouseRelationshipOther").getAsString()) ) {   //#PKY00048 changes
											setformfield(form, "tatilspouseRelationship", insuranceDetails.get("tatilspouseRelationshipOther").getAsString());                        //#SKP00006 changes
										}
									}catch(Exception e) {//#SRP00031 Ends
										
									}
									try {
										  String homeAddress=insuranceDetails.get("tatilMemAddress1").getAsString();//#SRP00037 Starts
										  String address1=homeAddress.substring(0,42);
										  String address2=homeAddress.substring(42, homeAddress.length());
										  setformfield(form, "tatilMemAddress1", address1);
										  setformfield(form, "tatilMemAddress2", address2);//#SRP00037 Ends
									  }catch(Exception e) {
										  
									  }
									
									try {
										if (insuranceDetails != null && insuranceDetails.has("tatilMemGender")) {
											// String key = "hjjkljlkj";
											if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemGender").getAsString(), "M")) {
												setformfield(form, "M", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemGender").getAsString(), "F")) {
												setformfield(form, "F", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemGender").getAsString(), "O")) {
												setformfield(form, "O", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemGender").getAsString(), "P ")) {
												setformfield(form, "P", "X");
											}
										}
									} catch (Exception e) {
										
									}
									try {
										if (insuranceDetails != null && insuranceDetails.has("tatilMemMartialStatus")) {
											if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "S")) {
												setformfield(form, "S", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
													"MA")) {
												setformfield(form, "MA", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "R")) {
												setformfield(form, "R", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "D")) {
												setformfield(form, "D", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
													"SE")) {
												setformfield(form, "SE", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
													"Spouse E")) {
												setformfield(form, "E", "X");
											}
										}
									} catch (Exception e) {
										
									}
									try { //#MVT00005 starts
										if (insuranceDetails != null && insuranceDetails.has("tatilMemMartialStatus")) {
											if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "S")) {
												setformfield(form, "S", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
													"M")) {
												setformfield(form, "MA", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "R")) {
												setformfield(form, "R", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "D")) {
												setformfield(form, "D", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
													"P")) {
												setformfieldS(form, "SE", "On");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
													"E")) {
												setformfieldS(form, "E", "On");
											}
										}
									} catch (Exception e) {
										
									} 	//#MVT00005 ends
									try {

										if (insuranceDetails != null && insuranceDetails.has("tatilMemCoverage")) {
											if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemCoverage").getAsString(), "MO")) {
												setformfield(form, "MO", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemCoverage").getAsString(), "MD")) {
												setformfield(form, "MD", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemCoverage").getAsString(), "MF")) {
												setformfield(form, "MF", "X");
											}
										}

									} catch (Exception e) {
										
									}
									//#SRP00028 starts
									try {	//#MVT000010	changes starts

										if (insuranceDetails != null && insuranceDetails.has("tatilMemCoverage")) {
											if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemCoverage").getAsString(), "F")) {
												setformfield(form, "M&F", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemCoverage").getAsString(), "M")) {
												setformfield(form, "Member", "X");
											} else if (i$outis.$iStrFuzzyMatch(
													insuranceDetails.get("tatilMemCoverage").getAsString(), "O")) {
												setformfield(form, "M&O", "X");
											}
										}	//#MVT000010 changes ends

									} catch (Exception e) {
										
									}//#SRP00028 Ends

//                            		 try {
//                            			 JsonObject addressdetails = jsonObject.get("tatilInsurance").getAsJsonObject();
//                            			 
//                            			 if(addressdetails.has("tatilMemAddress1") && addressdetails.has("tatilMemAddress2")) {
//                            				 String address1=  addressdetails.get("tatilMemAddress1").getAsString();
//                            				 String address2= addressdetails.get("tatilMemAddress2").getAsString();
//                            				 String finalAddress = address1.concat(", "+address2);
//                            				 
//                            				 setformfield(form, "tatilMemAddress1",finalAddress );
//                            			 }
//                            		 }catch(Exception e) {
//                            			 
//                            		 }

									try {
										JsonObject addressdetails = jsonObject.get("tatilInsurance").getAsJsonObject();

										try {
											if (i$outis
													.$iStrBlank(addressdetails.get("tatilMemHomePhone").getAsString()))
												setformfield(form, "mobileNumber", "");
											else
												setformfield(form, "tatilMemHomePhone",
														createTECUMobNo(
																addressdetails.get("tatilMemHomePhoneExtension")
																		.getAsString(),
																addressdetails.get("tatilMemHomePhone").getAsString()));
										} catch (Exception e) {
											
										}

										try {

											if (i$outis.$iStrBlank(addressdetails.get("tatilMemMobNo").getAsString()))
												setformfield(form, "mobileNumber", "");
											else
												setformfield(form, "tatilMemMobNo",
														createTECUMobNo(
																addressdetails.get("tatilMemMobNoExtension")
																		.getAsString(),
																addressdetails.get("tatilMemMobNo").getAsString()));
										} catch (Exception e) {
											
										}
									} catch (Exception e) {
										
									}

									try {
										String mPlan = jsonObject.get("tatilInsurance").getAsJsonObject()
												.get("tatilIsSposePlan").getAsString();
										try {
											if (mPlan.equalsIgnoreCase("Y")) {
												setformfield(form, "Y", "Y");
												setformfield(form, "tatilSpouseMemberPlan",
														jsonObject.get("tatilInsurance").getAsJsonObject()
																.get("tatilSpouseMemberPlan").getAsString());
												setformfield(form, "tatilSpouseMemberInsuranceCompany",
														jsonObject.get("tatilInsurance").getAsJsonObject()
																.get("tatilSpouseMemberInsuranceCompany")
																.getAsString());
												setformfield(form, "tatilSpousePlanGrp",
														jsonObject.get("tatilInsurance").getAsJsonObject()
																.get("tatilSpousePlanGrp").getAsString());
												setformfield(form, "tatilSpouseInsuranceCompany",
														jsonObject.get("tatilInsurance").getAsJsonObject()
																.get("tatilSpouseInsuranceCompany").getAsString());
											}
										} catch (Exception e) {
											
										}
										if (mPlan.equalsIgnoreCase("N")) {
											setformfield(form, "N", "N");
										}

									} catch (Exception e) {
										
									}
									//#SRP00012 Start
									try {
										String mPlan = jsonObject.get("tatilApplication").getAsJsonObject()
												.get("tatilIsSposePlan").getAsString();
										try {
											if (mPlan.equalsIgnoreCase("Y")) {
												setformfield(form, "Y", "Y");
												setformfield(form, "tatilSpouseMemberPlan",
														jsonObject.get("tatilApplication").getAsJsonObject()
																.get("tatilSpouseMemberPlan").getAsString());
												setformfield(form, "tatilSpouseMemberInsuranceCompany",
														jsonObject.get("tatilApplication").getAsJsonObject()
																.get("tatilSpouseMemberInsuranceCompany")
																.getAsString());
												setformfield(form, "tatilSpousePlanGrp",
														jsonObject.get("tatilApplication").getAsJsonObject()
																.get("tatilSpousePlanGrp").getAsString());
												setformfield(form, "tatilSpouseInsuranceCompany",
														jsonObject.get("tatilApplication").getAsJsonObject()
																.get("tatilSpouseInsuranceCompany").getAsString());
											}
										} catch (Exception e) {
											
										}
										if (mPlan.equalsIgnoreCase("N")) {
											setformfield(form, "N", "N");
										}

									} catch (Exception e) {
										
									} //#SRP00012 Ends

									try {
										setformfieldS(form, "Firsttime_Y",
												jsonObject.get("tatilInsurance").getAsJsonObject()
														.get("tatilMemCheckedFirstTimeApplicant").getAsString());
										setformfieldS(form, "Returning_Y",
												jsonObject.get("tatilInsurance").getAsJsonObject()
														.get("tatilMemCheckedReturningApplicant").getAsString());

//                            			 setformfieldS(form, "tatilspouseBeneficiary", jsonObject.get("tatilInsurance").getAsJsonObject().get("tatilspouseBeneficiary").getAsString());
//                            			 setformfieldS(form, "tatilSpouseDob", jsonObject.get("tatilInsurance").getAsJsonObject().get("tatilSpouseDob").getAsString());
//                            			 setformfieldS(form, "tatilspouseRelationship", jsonObject.get("tatilInsurance").getAsJsonObject().get("tatilspouseRelationship").getAsString());

									} catch (Exception e) {
										
									}
									//#SRP00012 Starts changes
									JsonObject tatilApplication=jsonObject.get("tatilApplication").getAsJsonObject();
									try {
							     		if (!i$outis.$iStrBlank(tatilApplication.get("tatilMemCheckedFirstTimeApplicant").getAsString())) {
							     			 if (i$outis.$iStrFuzzyMatch(tatilApplication.get("tatilMemCheckedFirstTimeApplicant").getAsString(), "Y")) 
							     				setformfieldS(form, "Firsttime_Y", "Yes");			     			 
							     			 else if (i$outis.$iStrFuzzyMatch(tatilApplication.get("tatilMemCheckedFirstTimeApplicant").getAsString(), "N"))
												setformfieldS(form, "Firsttime_Y", "");
							     		 }
									   } catch (Exception e) {						
										   
									   }
									try {
							     		if (!i$outis.$iStrBlank(tatilApplication.get("tatilMemCheckedReturningApplicant").getAsString())) {
							     			 if (i$outis.$iStrFuzzyMatch(tatilApplication.get("tatilMemCheckedReturningApplicant").getAsString(), "Y")) 
							     				setformfieldS(form, "Returning_Y", "Yes");			     			 
							     			 else if (i$outis.$iStrFuzzyMatch(tatilApplication.get("tatilMemCheckedReturningApplicant").getAsString(), "N"))
												setformfieldS(form, "Returning_Y", "");
							     		 }
									   } catch (Exception e) {						
										   
									   }
									//#SRP00012 Ends changes
									
									try {
										JsonObject age$UnderDetails = new JsonObject();  //#SRP00012 Start
											if(jsonObject.has("tatilInsurance"))
												age$UnderDetails = jsonObject.get("tatilInsurance").getAsJsonObject();
											else
												age$UnderDetails = jsonObject.get("tatilApplication").getAsJsonObject(); //#SRP00012 Ends
										if (i$outis.$iStrFuzzyMatch(
												age$UnderDetails.get("tatilmemAgeUnder64").getAsString(), "25"))
											setformfieldS(form, "$250,000.00_U", "Yes");

										else if (i$outis.$iStrFuzzyMatch(
												age$UnderDetails.get("tatilmemAgeUnder64").getAsString(), "40"))
											setformfieldS(form, "$400,000.00_U", "Yes");

										else if (i$outis.$iStrFuzzyMatch(
												age$UnderDetails.get("tatilmemAgeUnder64").getAsString(), "75"))
											setformfieldS(form, "$750,000.00_U", "Yes");

									} catch (Exception e) {
										
									}

									try {
										JsonObject age$OverDetails = new JsonObject();        //#SRP00012 Start
										if(jsonObject.has("tatilInsurance"))
											age$OverDetails = jsonObject.get("tatilInsurance").getAsJsonObject();
										else
											age$OverDetails = jsonObject.get("tatilApplication").getAsJsonObject();  //#SRP00012 Ends
										if (i$outis.$iStrFuzzyMatch(
												age$OverDetails.get("tatilmemAgeAbove65").getAsString(), "25"))
											setformfieldS(form, "$250,000.00_A", "Yes");

										else if (i$outis.$iStrFuzzyMatch(
												age$OverDetails.get("tatilmemAgeAbove65").getAsString(), "40"))
											setformfieldS(form, "$400,000.00_A", "Yes");

										else if (i$outis.$iStrFuzzyMatch(
												age$OverDetails.get("tatilmemAgeAbove65").getAsString(), "75"))
											setformfieldS(form, "$750,000.00_A", "Yes");

									} catch (Exception e) {
										
									}

								} catch (Exception e) {
									
								}
								
								JsonObject age$UnderDetails = new JsonObject();  //#SRP00012 Start
								if(jsonObject.has("tatilInsurance"))
										age$UnderDetails = jsonObject.get("tatilInsurance").getAsJsonObject();
								else
									age$UnderDetails = jsonObject.get("tatilApplication").getAsJsonObject();
								
                         //#SRP00012 Start
                                     
                                    if(jsonObject.has("tatilApplication")) {
                                    	 JsonObject tatilApplication = jsonObject.get("tatilApplication").getAsJsonObject();
                                         JsonArray eligibleDependent = tatilApplication.get("dependents").getAsJsonArray();
                                       for(int j=1;j<=eligibleDependent.size();j++) {
                                         JsonObject dependentInfo = eligibleDependent.get(j-1).getAsJsonObject();
                                         try {
                                           if(dependentInfo.has("tatilmemDependentName")&& !i$outis.$iStrBlank(dependentInfo.get("tatilmemDependentName").getAsString()))
                                             setformfield(form, "tatilmemDependent"+j+"Name", dependentInfo.get("tatilmemDependentName").getAsString());
                                           } catch (Exception e) {
                                             
                                           }
                                         try {
                                           if(dependentInfo.has("tatilmemDependentRelationship")&& !i$outis.$iStrBlank(dependentInfo.get("tatilmemDependentRelationship").getAsString()))
                                             setformfield(form, "tatilmemDependent"+j+"Relationship", dependentInfo.get("tatilmemDependentRelationship").getAsString());
                                           } catch (Exception e) {
                                             
                                           }
                                         try {
                                           if(dependentInfo.has("tatilmemDependentGender")&& !i$outis.$iStrBlank(dependentInfo.get("tatilmemDependentGender").getAsString()))
                                             setformfield(form, "tatilmemDependent"+j+"Gender", dependentInfo.get("tatilmemDependentGender").getAsString());
                                           } catch (Exception e) {
                                             
                                           }
                                         try {
                                            if(dependentInfo.has("tatilmemDependentDob")&& !i$outis.$iStrBlank(dependentInfo.get("tatilmemDependentDob").getAsString()))
                                             setformfield(form, "tatilmemDependent"+j+"Dob", dependentInfo.get("tatilmemDependentDob").getAsString());
                                               } catch (Exception e) {
                                                 
                                               }
                                       }

                                    }  //#SRP00012 Ends
                                    else if (pdfName.equalsIgnoreCase("TECU_Member_Health")) {//#SRP00060 Starts
        								try {
        									JsonObject insuranceDetails = jsonObject.get("tatilInsurance").getAsJsonObject();
        									fillPDFField(insuranceDetails, filedName.get(i), form);

        									try {
        										if (insuranceDetails != null && insuranceDetails.has("tatilMemGender")) {
        											// String key = "hjjkljlkj";
        											if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemGender").getAsString(), "M")) {
        												setformfield(form, "M", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemGender").getAsString(), "F")) {
        												setformfield(form, "F", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemGender").getAsString(), "O")) {
        												setformfield(form, "O", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemGender").getAsString(), "P ")) {
        												setformfield(form, "P", "X");
        											}
        										}
        									} catch (Exception e) {
        										
        									}
        									try {
        										if (insuranceDetails != null && insuranceDetails.has("tatilMemMartialStatus")) {
        											if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "S")) {
        												setformfield(form, "S", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
        													"MA")) {
        												setformfield(form, "MA", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "R")) {
        												setformfield(form, "R", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemMartialStatus").getAsString(), "D")) {
        												setformfield(form, "D", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
        													"SE")) {
        												setformfield(form, "SE", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemMartialStatus").getAsString(),
        													"Spouse E")) {
        												setformfield(form, "E", "X");
        											}
        										}
        									} catch (Exception e) {
        										
        									}
        									try {

        										if (insuranceDetails != null && insuranceDetails.has("tatilMemCoverage")) {
        											if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemCoverage").getAsString(), "MO")) {
        												setformfield(form, "MO", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemCoverage").getAsString(), "MD")) {
        												setformfield(form, "MD", "X");
        											} else if (i$outis.$iStrFuzzyMatch(
        													insuranceDetails.get("tatilMemCoverage").getAsString(), "MF")) {
        												setformfield(form, "MF", "X");
        											}
        										}

        									} catch (Exception e) {
        										
        									}

//                                    		 try {
//                                    			 JsonObject addressdetails = jsonObject.get("tatilInsurance").getAsJsonObject();
//                                    			 
//                                    			 if(addressdetails.has("tatilMemAddress1") && addressdetails.has("tatilMemAddress2")) {
//                                    				 String address1=  addressdetails.get("tatilMemAddress1").getAsString();
//                                    				 String address2= addressdetails.get("tatilMemAddress2").getAsString();
//                                    				 String finalAddress = address1.concat(", "+address2);
//                                    				 
//                                    				 setformfield(form, "tatilMemAddress1",finalAddress );
//                                    			 }
//                                    		 }catch(Exception e) {
//                                    			 
//                                    		 }

        									try {
        										JsonObject addressdetails = jsonObject.get("tatilInsurance").getAsJsonObject();

        										try {
        											if (i$outis
        													.$iStrBlank(addressdetails.get("tatilMemHomePhone").getAsString()))
        												setformfield(form, "mobileNumber", "");
        											else
        												setformfield(form, "tatilMemHomePhone",
        														createTECUMobNo(
        																addressdetails.get("tatilMemHomePhoneExtension")
        																		.getAsString(),
        																addressdetails.get("tatilMemHomePhone").getAsString()));
        										} catch (Exception e) {
        											
        										}

        										try {

        											if (i$outis.$iStrBlank(addressdetails.get("tatilMemMobNo").getAsString()))
        												setformfield(form, "mobileNumber", "");
        											else
        												setformfield(form, "tatilMemMobNo",
        														createTECUMobNo(
        																addressdetails.get("tatilMemMobNoExtension")
        																		.getAsString(),
        																addressdetails.get("tatilMemMobNo").getAsString()));
        										} catch (Exception e) {
        											
        										}
        									} catch (Exception e) {
        										
        									}

        									try {
        										String mPlan = jsonObject.get("tatilInsurance").getAsJsonObject()
        												.get("tatilIsSposePlan").getAsString();
        										try {
        											if (mPlan.equalsIgnoreCase("Y")) {
        												setformfield(form, "Y", "Y");
        												setformfield(form, "tatilSpouseMemberPlan",
        														jsonObject.get("tatilInsurance").getAsJsonObject()
        																.get("tatilSpouseMemberPlan").getAsString());
        												setformfield(form, "tatilSpouseMemberInsuranceCompany",
        														jsonObject.get("tatilInsurance").getAsJsonObject()
        																.get("tatilSpouseMemberInsuranceCompany")
        																.getAsString());
        												setformfield(form, "tatilSpousePlanGrp",
        														jsonObject.get("tatilInsurance").getAsJsonObject()
        																.get("tatilSpousePlanGrp").getAsString());
        												setformfield(form, "tatilSpouseInsuranceCompany",
        														jsonObject.get("tatilInsurance").getAsJsonObject()
        																.get("tatilSpouseInsuranceCompany").getAsString());
        											}
        										} catch (Exception e) {
        											
        										}
        										if (mPlan.equalsIgnoreCase("N")) {
        											setformfield(form, "N", "N");
        										}

        									} catch (Exception e) {
        										
        									}

        									try {
        										setformfieldS(form, "Firsttime_Y",
        												jsonObject.get("tatilInsurance").getAsJsonObject()
        														.get("tatilMemCheckedFirstTimeApplicant").getAsString());
        										setformfieldS(form, "Returning_Y",
        												jsonObject.get("tatilInsurance").getAsJsonObject()
        														.get("tatilMemCheckedReturningApplicant").getAsString());

//                                    			 setformfieldS(form, "tatilspouseBeneficiary", jsonObject.get("tatilInsurance").getAsJsonObject().get("tatilspouseBeneficiary").getAsString());
//                                    			 setformfieldS(form, "tatilSpouseDob", jsonObject.get("tatilInsurance").getAsJsonObject().get("tatilSpouseDob").getAsString());
//                                    			 setformfieldS(form, "tatilspouseRelationship", jsonObject.get("tatilInsurance").getAsJsonObject().get("tatilspouseRelationship").getAsString());

        									} catch (Exception e) {
        										
        									}

        									try {
        										JsonObject age$UnderDetail = jsonObject.get("tatilInsurance")
        												.getAsJsonObject();
        										if (i$outis.$iStrFuzzyMatch(
        												age$UnderDetail.get("tatilmemAgeUnder64").getAsString(), "25"))
        											setformfieldS(form, "$250,000.00_U", "Yes");

        										else if (i$outis.$iStrFuzzyMatch(
        												age$UnderDetail.get("tatilmemAgeUnder64").getAsString(), "40"))
        											setformfieldS(form, "$400,000.00_U", "Yes");

        										else if (i$outis.$iStrFuzzyMatch(
        												age$UnderDetail.get("tatilmemAgeUnder64").getAsString(), "75"))
        											setformfieldS(form, "$750,000.00_U", "Yes");

        									} catch (Exception e) {
        										
        									}

        									try {
        										JsonObject age$OverDetails = jsonObject.get("tatilInsurance").getAsJsonObject();
        										if (i$outis.$iStrFuzzyMatch(
        												age$OverDetails.get("tatilmemAgeAbove65").getAsString(), "25"))
        											setformfieldS(form, "$250,000.00_A", "Yes");

        										else if (i$outis.$iStrFuzzyMatch(
        												age$OverDetails.get("tatilmemAgeAbove65").getAsString(), "40"))
        											setformfieldS(form, "$400,000.00_A", "Yes");

        										else if (i$outis.$iStrFuzzyMatch(
        												age$OverDetails.get("tatilmemAgeAbove65").getAsString(), "75"))
        											setformfieldS(form, "$750,000.00_A", "Yes");

        									} catch (Exception e) {
        										
        									}

        								} catch (Exception e) {
        									
        								}

        							}//#SRP00060 Ends

							} else if (pdfName.equalsIgnoreCase("Internet_Mobile_Facility")) {

								try {
									JsonObject internetFaciDetails = jsonObject.get("internetMobilefacility")
											.getAsJsonObject();
									JsonObject personalInfo = jsonObject.get("personalInfo").getAsJsonObject(); //#MVT00081 Changes
									JsonObject empObject = jsonObject.get("employment").getAsJsonObject(); //#MVT00081 Changes
									
									try {
/*										if (internetFaciDetails.has("firstName")
												|| internetFaciDetails.has("middleName")
												|| internetFaciDetails.has("lastName")) {
											String nameF = internetFaciDetails.get("firstName").getAsString();
											String nameM = internetFaciDetails.get("middleName").getAsString();
											String nameL = internetFaciDetails.get("lastName").getAsString();

											String finalName = nameF.concat(" " + nameM + " " + nameL);*/
										StringBuilder finalName = new StringBuilder(personalInfo.get("firstName").getAsString()); //#MVT00089 changes starts
										if(personalInfo.has("middleName")) {
											finalName.append(" ");
											finalName.append(personalInfo.get("middleName").getAsString());
										}
										if(personalInfo.has("lastName")) {
											finalName.append(" ");
											finalName.append(personalInfo.get("lastName").getAsString());//#MVT00089 changes ends
										}
										setformfield(form, "internetMobilefacility_fullName", finalName.toString());

									} catch (Exception e) {
										e.printStackTrace();
									}

									try {
//										String desc = internetFaciDetails.get("employerDesc").getAsString(); //#MVT00081 Changes starts
										if (empObject.has("employerDesc") && !i$outis.$iStrBlank(empObject.get("employerDesc").getAsString())) {
											if (i$outis.$iStrFuzzyMatch(empObject.get("employer").getAsString(), "OTHER")) {
												setformfield(form, "employerDesc", empObject.get("employerOther").getAsString());
											} else {
												setformfield(form, "employerDesc", empObject.get("employerDesc").getAsString());
											}
//											setformfield(form, "employerDesc", desc);
										} //#MVT00081 Changes ends
									} catch (Exception e) {

									}
								} catch (Exception e) {
									
								}
								
								try {
									addImage(stamp, form, "Qr_code_1", base64);
								}catch(Exception e) {
									
								}

								try {
									JsonObject internetFaciDetails = jsonObject.get("personalInfo").getAsJsonObject();
									StringBuilder homeAdress = new StringBuilder();
									StringBuilder homeAdress1 = new StringBuilder();

									try { //#MVT00090 changes starts
										if (internetFaciDetails.has("permAddLine1") && !i$outis.$iStrBlank(internetFaciDetails.get("permAddLine1").getAsString())) {
											String address1 = internetFaciDetails.get("permAddLine1").getAsString();
											homeAdress.append(address1);
										}
										if (internetFaciDetails.has("permAddLine2") && !i$outis.$iStrBlank(internetFaciDetails.get("permAddLine2").getAsString())) {
											String address1 = internetFaciDetails.get("permAddLine2").getAsString();
											homeAdress.append(", ");
											homeAdress.append(address1);
										}
//										if (internetFaciDetails.has("mailAddLine3") && !i$outis.$iStrBlank(internetFaciDetails.get("mailAddLine3").getAsString())) {
//											String address1 = internetFaciDetails.get("mailAddLine3").getAsString();
//											homeAdress.append(", ");
//											homeAdress.append(address1);
//										}
//										if (internetFaciDetails.has("mailAddLine4") && !i$outis.$iStrBlank(internetFaciDetails.get("mailAddLine4").getAsString())) {
//											String address1 = internetFaciDetails.get("mailAddLine4").getAsString();
//											homeAdress.append(", ");
//											homeAdress.append(address1);
//										}
										if (internetFaciDetails.has("permAddCity") && !i$outis.$iStrBlank(internetFaciDetails.get("permAddCity").getAsString())) {
											String address1 = internetFaciDetails.get("permAddCity").getAsString();
//											homeAdress.append(", ");//#MVT00099 changes begins
											homeAdress1.append(address1);
										}
										if (internetFaciDetails.has("permAddState") && !i$outis.$iStrBlank(internetFaciDetails.get("permAddState").getAsString())) {
											String address1 = internetFaciDetails.get("permAddState").getAsString();
											homeAdress.append(", ");
											homeAdress.append(address1);
										}
										if (internetFaciDetails.has("permAddCountryDesc") && !i$outis.$iStrBlank(internetFaciDetails.get("permAddCountryDesc").getAsString())) {
											String address1 = internetFaciDetails.get("permAddCountryDesc").getAsString();
											homeAdress1.append(", ");
											homeAdress1.append(address1);
										}
										if (internetFaciDetails.has("permAddZipCode") && !i$outis.$iStrBlank(internetFaciDetails.get("permAddZipCode").getAsString())) {
											String address1 = internetFaciDetails.get("permAddZipCode").getAsString();
											homeAdress.append(", ");
											homeAdress.append(address1);
										}
										setformfield(form, "internetMobilefacility_fullAddress", homeAdress.toString());
										setformfield(form, "Home Address 2", homeAdress1.toString());//#MVT00099 changes ends

										// String finalAddres = address1.concat(" " + address2 + " " + address3
										// + " " + address4 + " " + mailAddCity + " " + mailAddState + " " +
										// mailAddCountry + " " + mailAddZipCode);
									} catch (Exception e) {
										e.printStackTrace();
									}
									try {
										//TKS00001 starts
										JsonObject empDetails = jsonObject.get("employment").getAsJsonObject();
										StringBuilder fulladdr = new StringBuilder();
										JsonObject opr = i$ResM.getGobalValJObj("request").getAsJsonObject();// #MVT00091 Changes starts
										
										if (i$outis.$iStrFuzzyMatch(opr.get("i-header").getAsJsonObject().get("operation").getAsString(), "ACQ")) {
											try {
												if (empDetails.has("empAdd1") && !empDetails.get("empAdd1").getAsString().isEmpty()) {
													fulladdr.append(empDetails.get("empAdd1").getAsString());
												}
												if (empDetails.has("employerCity") && !empDetails.get("employerCity").getAsString().isEmpty()) {
													fulladdr.append(" ");
													fulladdr.append(empDetails.get("employerCity").getAsString());
												}
											} catch (Exception e) {
												e.printStackTrace();
											}
										} else {
											if (empDetails.has("employerAddressLine1") || empDetails.has("employerAddressLine2")
													|| empDetails.has("employerCity") || empDetails.has("employerCountryDesc")) { // #MVT00085 Changes starts
												try {
													String addr1 = empDetails.get("employerAddressLine1").getAsString();
													fulladdr.append(addr1);
												} catch (Exception e) {
												}

												try {
													String addr2 = empDetails.get("employerAddressLine2").getAsString();
													fulladdr.append(",");
													fulladdr.append(addr2);
												} catch (Exception e) {
												}
												try {
													String addCity = empDetails.get("employerCity").getAsString();
													fulladdr.append(",");
													fulladdr.append(addCity);
												} catch (Exception e) {
												}

												try {
													String employerCountry = empDetails.get("employerCountryDesc").getAsString();
													fulladdr.append(",");
													fulladdr.append(employerCountry);// #MVT00090 Changes ends

												} catch (Exception e) {

												}

//											try {
//												String empZipCode = empDetails.get("empZipCode").getAsString();
//												fulladdr.append(empZipCode);
//												fulladdr.append(",");
//											}catch(Exception e) {
//												
//											} //#MVT00085 Changes starts
											}
										}
										setformfield(form, "empAdd1", fulladdr.toString());// #MVT00091 Changes ends
									} catch (Exception e) {
										
									}
									//TKS00001 ends
									try {
										JsonObject contactInfo = jsonObject.get("contactDetails").getAsJsonObject();
										if (contactInfo.has("emailId")) {
											String emailAddress = contactInfo.get("emailId").getAsString();
											setformfield(form, "officialEmailId", emailAddress);
										}
									} catch (Exception e) {
										
									}

								} catch (Exception e) {
									
								}

								try {
									JsonObject internetFaciDetails = jsonObject.get("additionalDetails")
											.getAsJsonObject();

									try {
										if (i$outis
												.$iStrBlank(internetFaciDetails.get("homePhoneNumber").getAsString()))
											setformfield(form, "homePhoneNumber", "");
										else
											setformfield(form, "internetMobilefacility_HomePhoneNo",
													createTECUMobNo(
															internetFaciDetails.get("homephoneExtension").getAsString(),
															internetFaciDetails.get("homePhoneNumber").getAsString()));

									} catch (Exception e) {
										
									}
									try {
										JsonObject contactInfo = jsonObject.get("contactDetails").getAsJsonObject();
										if (i$outis.$iStrBlank(contactInfo.get("mobileNumber").getAsString()))
											setformfield(form, "mobNo2", "");
										else
											setformfield(form, "internetMobilefacility_MobileNo",
													createTECUMobNo(
															contactInfo.get("mobileISD").getAsString(),
															contactInfo.get("mobileNumber").getAsString()));
									} catch (Exception e) {
										
									}

								} catch (Exception e) {
									
								}
								try {
									JsonObject internetFaciDetails = jsonObject.get("internetMobilefacility")
											.getAsJsonObject();
									try {
										if (internetFaciDetails.has("dob")) {
											String DOB = internetFaciDetails.get("dob").getAsString();
											setformfield(form, "dob", DOB);
										}
									} catch (Exception e) {
										
									}
//                              Bugzilla bug #975 Starts #SKP00001 Starts
//									try {
//										if (internetFaciDetails.has("employeeNo")) {
//											String employeeno = internetFaciDetails.get("employeeNo").getAsString();
//											setformfield(form, "employeeNo", employeeno);
//										}
//									} catch (Exception e) {
//										
//									}
//                              Bugzilla bug #975 Ends #SKP00001 Ends
									try {
										if (internetFaciDetails.has("priDocId")) {
											String priDoc = internetFaciDetails.get("priDocId").getAsString();
											setformfield(form, "priDocId", priDoc);
										}
									} catch (Exception e) {
										
									}
									try {
										if (internetFaciDetails.has("secDocId")) {
//											String secDocId = jsonObject.get("secondaryOCRResult").getAsJsonObject().get("registrationNo").getAsString();
											String secDoc = internetFaciDetails.get("secDocId").getAsString();
											setformfield(form, "secDocId", secDoc);
										}
									} catch (Exception e) {
										
									}

								} catch (Exception e) {
									
								}

							} else if (pdfName.equalsIgnoreCase("Line of Credit Form")) {
								JsonObject creditDetails = jsonObject.get("lineOfCredit").getAsJsonObject();

								try {

									fillPDFField(creditDetails, filedName.get(i), form);

								} catch (Exception e) {
									
								}

								try {
									if (creditDetails.has("lineOfCreditPreviousAddress")) {
										String addressPrev = creditDetails.get("lineOfCreditPreviousAddress")
												.getAsString();
										setformfield(form, "lineOfCreditPreviousAddress1", addressPrev);
									}
								} catch (Exception e) {
									
								}

								try {
									if (creditDetails.has("lineOfCreditStatus")) {
										if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditStatus").getAsString(), "P"))
											setformfieldS(form, "P", "x");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditStatus").getAsString(), "T"))
											setformfieldS(form, "T", "x");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditStatus").getAsString(), "C"))
											setformfieldS(form, "C", "x");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditStatus").getAsString(), "S"))
											setformfieldS(form, "S", "x");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditStatus").getAsString(), "CO"))
											setformfieldS(form, "CO", "x");
									}

								} catch (Exception e) {
									
								}

								try {
									if (creditDetails.has("lineOfCreditMaritalStatus")) {

										if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditMaritalStatus").getAsString(), "Single"))
											setformfieldS(form, "Single", "On");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditMaritalStatus").getAsString(),
												"Married"))
											setformfieldS(form, "Married", "On");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditMaritalStatus").getAsString(), "CLaw"))
											setformfieldS(form, "CLaw", "On");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditMaritalStatus").getAsString(),
												"Divorced"))
											setformfieldS(form, "Divorced", "On");

										else if (i$outis.$iStrFuzzyMatch(
												creditDetails.get("lineOfCreditMaritalStatus").getAsString(),
												"Separated"))
											setformfieldS(form, "Separated", "On");

									}
								} catch (Exception e) {
									
								}

								// try {
//                            		if (creditDetails.has("lineOfCreditDob")) {
//                                       
//                                            String[] dateComps = creditDetails.get("lineOfCreditDob").getAsString().split("-");
//                                            if (dateComps[2].length() == 1 && Integer.parseInt(dateComps[2]) < 10) {
//                                                String day = "0" + dateComps[2];
//                                                creditDetails.addProperty("lineOfCreditDob", day);
//                                            } else {
//                                            	creditDetails.addProperty("lineOfCreditDob", dateComps[2]);
//                                            }
//                                            if (dateComps[1].length() == 1 && Integer.parseInt(dateComps[1]) < 10) {
//                                                String month = "0" + dateComps[1];
//                                                creditDetails.addProperty("lineOfCreditDob", month);
//                                            } else {
//                                            	creditDetails.addProperty("lineOfCreditDob", dateComps[1]);
//                                            }
//                                            creditDetails.addProperty("lineOfCreditDob", dateComps[0]);
//                                    }

								// }catch(Exception e) {
								// 
								// }

							} else if (pdfName.equalsIgnoreCase("Banque_Atlantique")) {
								JsonObject personalInfo = jsonObject.get("personalInfo").getAsJsonObject();
								JsonObject additionalInfo = jsonObject.get("additionalDetails").getAsJsonObject();
								JsonObject contactInfo = jsonObject.get("contactDetails").getAsJsonObject();
								JsonObject empDetails = jsonObject.get("employment").getAsJsonObject();

								try {
									fillPDFField(personalInfo, filedName.get(i), form);
									fillPDFField(additionalInfo, filedName.get(i), form);
									fillPDFField(contactInfo, filedName.get(i), form);
									fillPDFField(empDetails, filedName.get(i), form);
								} catch (Exception e) {
									
								}

								try {
									String title = personalInfo.get("prefix").getAsString();
									if (i$outis.$iStrFuzzyMatch(personalInfo.get("prefix").getAsString(), "Mr"))
										setformfield(form, "Mr", "x");

									else if (i$outis.$iStrFuzzyMatch(personalInfo.get("prefix").getAsString(), "Mrs"))
										setformfield(form, "Mrs", "x");

									else if (i$outis.$iStrFuzzyMatch(personalInfo.get("prefix").getAsString(), "Ms"))
										setformfield(form, "Ms", "x");

									else if (i$outis.$iStrFuzzyMatch(personalInfo.get("prefix").getAsString(), "Dr"))
										setformfield(form, "Dr", "x");

									else if (i$outis.$iStrFuzzyMatch(personalInfo.get("prefix").getAsString(), "Prof"))
										setformfield(form, "Prof", "x");

									else if (i$outis.$iStrFuzzyMatch(personalInfo.get("prefix").getAsString(), "Other"))
										setformfield(form, "Other", "x");

								} catch (Exception e) {
									
								}

								try {
									if (i$outis.$iStrFuzzyMatch(additionalInfo.get("maritalStatus").getAsString(),
											"M")) {
										setformfield(form, "M", "x");
										setformfieldS(form, "M1", "On");
									}

									else if (i$outis.$iStrFuzzyMatch(additionalInfo.get("maritalStatus").getAsString(),
											"S")) {
										setformfield(form, "S", "x");
										setformfieldS(form, "S1", "On");
									}

									else if (i$outis.$iStrFuzzyMatch(additionalInfo.get("maritalStatus").getAsString(),
											"E")) {
										setformfield(form, "E", "x");
										setformfieldS(form, "W1", "On");
									}

									else if (i$outis.$iStrFuzzyMatch(additionalInfo.get("maritalStatus").getAsString(),
											"D")) {
										setformfield(form, "D", "x");
										setformfieldS(form, "D1", "On");
									} else if (i$outis
											.$iStrFuzzyMatch(additionalInfo.get("maritalStatus").getAsString(), "O1")) {
										setformfieldS(form, "O1", "On");

									}

								} catch (Exception e) {
									
								}
								try {

									if (i$outis.$iStrBlank(empDetails.get("employerWorkPhoneNumber").getAsString()))
										setformfield(form, "WorkPhoneNumber", "");
									else
										setformfield(form, "WorkPhoneNumber",createTECUMobNo(empDetails.get("employerExtension").getAsString(),empDetails.get("employerWorkPhoneNumber").getAsString()));

								} catch (Exception e) {
									
								}
								try {
									if (i$outis.$iStrBlank(empDetails.get("empfaxNo").getAsString())) {
										setformfield(form, "WorkFaxNumber", "");
									} else {

										setformfield(form, "WorkFaxNumber",
												createTECUMobNo(empDetails.get("empfaxNoExtension").getAsString(),
														empDetails.get("empfaxNo").getAsString()));
										setformfield(form, "empPhoneNumber",
												createTECUMobNo(empDetails.get("empfaxNoExtension").getAsString(),
														empDetails.get("empfaxNo").getAsString()));
									}
								} catch (Exception e) {
									
								}
								try {
									String addCty = personalInfo.get("mailAddCity").getAsString();
									String addCntry = personalInfo.get("mailAddCountryDesc").getAsString();

									String finalAddress = addCty.concat("," + addCntry);
									setformfield(form, "physicalAddress", finalAddress);

								} catch (Exception e) {
									
								}

								try {
									String add1 = personalInfo.get("mailAddLine1").getAsString();
									String add2 = personalInfo.get("mailAddLine2").getAsString();
									String add3 = personalInfo.get("mailAddLine3").getAsString();
									String add4 = personalInfo.get("mailAddLine4").getAsString();

									String finalMailAddress = add1.concat(" " + add2 + " " + add3 + " " + add4);
									setformfield(form, "fullMailingAddress", finalMailAddress);
									setformfield(form, "fullpersoneladress", finalMailAddress);

								} catch (Exception e) {
									
								}
								try {
									if (i$outis.$iStrBlank(contactInfo.get("mobileNumber").getAsString())) {
										setformfield(form, "tellFixed", "");
									} else {
										setformfield(form, "tellFixed",
												createTECUMobNo(contactInfo.get("mobileISD").getAsString(),
														contactInfo.get("mobileNumber").getAsString()));
										setformfield(form, "PhoneMobileandHome",
												createTECUMobNo(contactInfo.get("mobileISD").getAsString(),
														contactInfo.get("mobileNumber").getAsString()));
									}

								} catch (Exception e) {
									
								}

								try {
									if (i$outis.$iStrBlank(additionalInfo.get("mobNo2").getAsString())) {
										setformfield(form, "tellMobile", "");
									} else {
										setformfield(form, "tellMobile",
												createTECUMobNo(additionalInfo.get("mobNo2Extension").getAsString(),
														additionalInfo.get("mobNo2").getAsString()));
									}

								} catch (Exception e) {
									
								}

								try {
									if (i$outis.$iStrBlank(additionalInfo.get("faxNumber").getAsString()))
										setformfield(form, "personalFax", "");
									else
										setformfield(form, "personalFax",
												createTECUMobNo(additionalInfo.get("faxNumberExtension").getAsString(),
														additionalInfo.get("faxNumber").getAsString()));

								} catch (Exception e) {
									
								}

								try {
									String dob = personalInfo.get("dob").getAsString();
									String place = additionalInfo.get("birthCountryDesc").getAsString();

									String dob$PlaceOfbirth = dob.concat(" " + place);
									setformfield(form, "dateplaceofbirth", dob$PlaceOfbirth);
								} catch (Exception e) {
									
								}
							}

							// SBC0087 ENDS
						} catch (Exception e) {
							
						}
					}
				}

			}

		} catch (Exception e) {
			logger.debug(e.getLocalizedMessage());

		}

	}
	//MSA starts
		private void LOCPdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp , String base64, List<String> filedName)throws IOException, DocumentException{

			JsonObject loanSummary = new JsonObject();//#MVT00099 changes begins
			JsonObject extraDetails = jsonObject.get("extraDetails").getAsJsonObject();
			JsonObject loanDetails = jsonObject.get("loanDetails").getAsJsonObject();
			JsonObject memberInfo = jsonObject.get("memberInfo").getAsJsonObject();
			String cif = jsonObject.get("cif").getAsString();
			JsonObject filter = new JsonObject();
			filter.addProperty("CustomerId",cif);
			JsonObject data =  db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA",filter);
			
			//JsonArray coBorrowerDetails = jsonObject.get("coBorrowerDetails").getAsJsonArray();
			//#SRP00024 Starts
			if (jsonObject.has("summary")) {
				loanSummary = jsonObject.get("summary").getAsJsonObject();
			}
			if (jsonObject.has("loanSummary")) {
				loanSummary = jsonObject.get("loanSummary").getAsJsonObject();
			}//#MVT00099 changes ends
			try {
			      JsonObject coMakersDetails = jsonObject.get("coMakersDetails").getAsJsonObject();
			      try {
						if (coMakersDetails.has("loanBalance")&& !i$outis.$iStrBlank(coMakersDetails.get("loanBalance").getAsString())) {
							setformfield(form, "loan", coMakersDetails.get("loanBalance").getAsString());
						}
					} catch (Exception e) {
						
					}
			      try {
						if (coMakersDetails.has("shareBalance")&& !i$outis.$iStrBlank(coMakersDetails.get("shareBalance").getAsString())) {
							setformfield(form, "shares2", coMakersDetails.get("shareBalance").getAsString());
						}
					} catch (Exception e) {
						
					}
			}catch(Exception e) {
				
			}//#SRP00024 Ends
			try {
				for (int i = 0; i <= filedName.size(); i++) {
			
				fillPDFField(memberInfo, filedName.get(i), form);
				fillPDFField(extraDetails, filedName.get(i), form);
				fillPDFField(loanDetails, filedName.get(i), form);
				fillPDFField(jsonObject, filedName.get(i), form);
				
				}
				}catch(Exception e) {
					
				}
			//MSA starts
			try {
				if (data.has("DateJoinedCu")) {
					String dateJoined = data.get("DateJoinedCu").getAsString();
					setformfield(form, "dateJoinedCu", dateJoined);
				}
				
			}catch(Exception e) {
				
			}
			try {
				if(data.has("DateJoinedComp")) {
					String dateJoined = data.get("DateJoinedComp").getAsString();
					Date date = Calendar.getInstance().getTime();  
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");  
					String strDate = dateFormat.format(date); 
					
					int years = I$Ioutils.getDateDifferencesInYears(dateJoined, strDate);
					
					setformfield(form, "serviceWithCompany", years+" years");
					setformfield(form, "serviceWithCompany2", years+" years");
				}
				
			}catch(Exception e) {
				
			}
			//MSA ends
//			for(int i=0;i<coBorrowerDetails.size();i++) {
//				JsonObject borrowerDetails = coBorrowerDetails.get(i).getAsJsonObject();
	//
//				try {
//					if (jsonObject.has("CustomerFullName")) {
//						setformfield(form, "customer"+i+"FullName", borrowerDetails.get("CustomerFullName").getAsString());
//					}
//				} catch (Exception e) {
//			}	
//				try {
//					if (jsonObject.has("CustomerId")) {
//						setformfield(form, "Customer"+i+"Id", borrowerDetails.get("CustomerId").getAsString());
//					}
//				} catch (Exception e) {
//			}
//				try {
//					if (jsonObject.has("CustomerEmailId")) {
//						setformfield(form, "Customer"+i+"EmailId", borrowerDetails.get("CustomerEmailId").getAsString());
//					}
//				} catch (Exception e) {
//			}
//				try {
//					if (jsonObject.has("CustomerMobileId")) {
//						setformfield(form, "Customer"+i+"MobileId", borrowerDetails.get("CustomerMobileId").getAsString());
//					}
//				} catch (Exception e) {
//			}
//				
//			}
			
			//#MVT000012 Starts
			try {
				String diagnoseDetails = memberInfo.get("homeAddress").getAsString();
				if (diagnoseDetails.length() > 64) {
					setformfieldS(form, "homeAddress",
							memberInfo.get("homeAddress").getAsString().substring(0, 64));
					setformfieldS(form, "homeAddress2", memberInfo.get("homeAddress").getAsString()
							.substring(64, diagnoseDetails.length()));

				} else {
					setformfieldS(form, "homeAddress", memberInfo.get("homeAddress").getAsString());
				}
			} catch (Exception e) {

			}//#MVT000012 ends
			// #SKP00001 Starts 
			    try {
			    	 String currentDate = i$outis.getDate();
					 setformfield(form, "date", currentDate);
					    
	           } catch (Exception e) {
				
			    }
			    
			    try {
			    	if(jsonObject.has("cif")&& !i$outis.$iStrBlank(jsonObject.get("cif").getAsString()))
				    setformfield(form, "memberNo", jsonObject.get("cif").getAsString());
			    } catch (Exception e) {
				
			    }
				try {
					if (!i$outis.$iStrBlank(memberInfo.get("martialStatus").getAsString())) {
						if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "M"))
							setformfieldS(form, "Married", "On");

						else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "S"))
							setformfieldS(form, "Single", "On");
						
						else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "D"))
							setformfieldS(form, "divorced", "On");
						
						else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "P"))
							setformfieldS(form, "separated", "On");
						
						else if (i$outis.$iStrFuzzyMatch(memberInfo.get("martialStatus").getAsString(), "C"))//#MVT00007 changes starts 
							setformfieldS(form, "claw", "On");//#MVT00007 Changes ends
					}
				} catch (Exception e) {
					
				}
		     	try {
		     		if (!i$outis.$iStrBlank(memberInfo.get("employmentStatus").getAsString())) {
		     			 if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "F")) 
		     				setformfieldS(form, "permanent", "On");
		     			 
		     			 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "T"))
								setformfieldS(form, "temporary", "On");
							
						 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "U"))
								setformfieldS(form, "casual", "On");
							
						 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "S"))
								setformfieldS(form, "selfEmployed", "On");
							
						 else if (i$outis.$iStrFuzzyMatch(memberInfo.get("employmentStatus").getAsString(), "P"))
								setformfieldS(form, "contract", "On");
		     		 }
				   } catch (Exception e) {
				
			    }
			    try {
			    	if (memberInfo.has("otherIncome")&& !i$outis.$iStrBlank(memberInfo.get("otherIncome").getAsString())) {
					setformfield(form, "otherIncomePerAnnum", memberInfo.get("otherIncome").getAsString());
			    	}
		    	} catch (Exception e) {
				
		    	}
			    //#SRP00022 Starts
			    
			    try {
					if (extraDetails.has("reference1FirstName")|| extraDetails.has("reference1LastName")) {
						StringBuilder referenceFullName = new StringBuilder();
						try {
							if (extraDetails.has("reference1FirstName") && !i$outis.$iStrBlank(extraDetails.get("reference1FirstName").getAsString())) {
								referenceFullName.append(extraDetails.get("reference1FirstName").getAsString());
							}
						} catch (Exception e) {
							
						}
						try {
							if (extraDetails.has("reference1LastName") && !i$outis.$iStrBlank(extraDetails.get("reference1LastName").getAsString())) {
								referenceFullName.append(" ");
								referenceFullName.append(extraDetails.get("reference1LastName").getAsString());
							}
						} catch (Exception e) {
							
						}
						setformfield(form, "referencesName1", referenceFullName.toString());		
					}
				}catch(Exception e) {
				}
			    try {
			    	if (i$outis.$iStrBlank(extraDetails.get("reference1ContactNumber").getAsString())) {
					setformfield(form, "contactNo1", "");
			    	}
			    	else{
					setformfield(form, "contactNo1",createTECUMobNo(extraDetails.get("reference1ContactNumberCode").getAsString(),extraDetails.get("reference1ContactNumber").getAsString()));
			            } 
			    }catch (Exception e) {
					
			    }
			    try {
					if (extraDetails.has("reference2FirstName")|| extraDetails.has("reference2LastName")) {
						StringBuilder referenceFullName = new StringBuilder();
						try {
							if (extraDetails.has("reference2FirstName") && !i$outis.$iStrBlank(extraDetails.get("reference2FirstName").getAsString())) {
								referenceFullName.append(extraDetails.get("reference2FirstName").getAsString());
							}
						} catch (Exception e) {
							
						}
						try {
							if (extraDetails.has("reference2LastName") && !i$outis.$iStrBlank(extraDetails.get("reference2LastName").getAsString())) {
								referenceFullName.append(" ");
								referenceFullName.append(extraDetails.get("reference2LastName").getAsString());
							}
						} catch (Exception e) {
							
						}
						setformfield(form, "referencesName2", referenceFullName.toString());		
					}
				}catch(Exception e) {
				}
			    try {
			    	if (i$outis.$iStrBlank(extraDetails.get("reference2ContactNumber").getAsString())) {
					setformfield(form, "contactNo2", "");
			    	}
			    	else{
					setformfield(form, "contactNo2",createTECUMobNo(extraDetails.get("reference2ContactNumberCode").getAsString(),extraDetails.get("reference2ContactNumber").getAsString()));
			            } 
			    }catch (Exception e) {
					
			    }
			    try {
			    	if (i$outis.$iStrBlank(memberInfo.get("workPhone").getAsString())) {
					setformfield(form, "telNosWork", "");
			    	}
			    	else{
					setformfield(form, "telNosWork",createTECUMobNo(memberInfo.get("workCode").getAsString(),memberInfo.get("workPhone").getAsString()));
			            } 
			    }catch (Exception e) {
					
			    }
			    //#TKS00006 starts
			    try {
			    	if (memberInfo.has("employer")&& !i$outis.$iStrBlank(memberInfo.get("employer").getAsString())) {
			    		if(i$outis.$iStrFuzzyMatch(memberInfo.get("employer").getAsString(), "OTHER")) {
			    			setformfield(form, "employer", memberInfo.get("employerOther").getAsString());
			    		}else {
			    			setformfield(form, "employer", memberInfo.get("employerDesc").getAsString());
			    		}
			    	}
				} catch (Exception e) {
					
				}
			  //#TKS00006 ends
			    //#SRP00022 Ends
		    	try {
			    	if (i$outis.$iStrBlank(memberInfo.get("homePhone").getAsString())) {
					setformfield(form, "telNosHome", "");
			    	}
			    	else{
					setformfield(form, "telNosHome",createTECUMobNo(memberInfo.get("homeCode").getAsString(),memberInfo.get("homePhone").getAsString()));
			            } 
			    }catch (Exception e) {
					
			    }
		    	//#SRP00025 Starts changes
//		    	try {
//					if (extraDetails.has("loanOfficerDesc")&& !i$outis.$iStrBlank(extraDetails.get("loanOfficerDesc").getAsString())) {
//						setformfield(form, "PrintName", extraDetails.get("loanOfficerDesc").getAsString());
//					}
//				} catch (Exception e) {
//					
//				}
//		    	try {
//					if (jsonObject.has("cif")&& !i$outis.$iStrBlank(jsonObject.get("cif").getAsString())) {
//						setformfield(form, "Member No 1", jsonObject.get("cif").getAsString());
//					}
//				} catch (Exception e) {
//					
//				}
//		    	try {
//					if (loanDetails.has("totalShareBalance")&& !i$outis.$iStrBlank(loanDetails.get("totalShareBalance").getAsString())) {
//						setformfield(form, "Shares 1", loanDetails.get("totalShareBalance").getAsString());
//					}
//				} catch (Exception e) {
//					
//				}
		    	try {
					if (loanSummary.has("firstPaymentDate")&& !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
						setformfield(form, "firstInstalmentDate", loanSummary.get("firstPaymentDate").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("maturityDate")&& !i$outis.$iStrBlank(loanDetails.get("maturityDate").getAsString())) {
						setformfield(form, "MaturityDate", loanDetails.get("maturityDate").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("maxLoanAmount")&& !i$outis.$iStrBlank(loanDetails.get("maxLoanAmount").getAsString())) {
						setformfield(form, "loanAmount", loanDetails.get("maxLoanAmount").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("emi")&& !i$outis.$iStrBlank(loanDetails.get("emi").getAsString())) {
						setformfield(form, "installment", loanDetails.get("emi").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("emi")&& !i$outis.$iStrBlank(loanDetails.get("emi").getAsString())) {
						setformfield(form, "installment1", "month");
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("tenor")&& !i$outis.$iStrBlank(loanDetails.get("tenor").getAsString())) {
						setformfield(form, "term", loanDetails.get("tenor").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("intrestRate")&& !i$outis.$iStrBlank(loanDetails.get("intrestRate").getAsString())) {
						String interestRate = loanDetails.get("intrestRate").getAsString() + " % APR";
						setformfield(form, "rateOfIntrest", interestRate);
					}
				} catch (Exception e) {
					
				}
//		    	try {
//					if (loanDetails.has("linkages")&& !i$outis.$iStrBlank(loanDetails.get("linkages").getAsString())) {
//						setformfield(form, "rateOfIntrest", loanDetails.get("linkages").getAsString());
//					}
//				} catch (Exception e) {
//					
//				}
		    	try {
					if (loanDetails.has("linkages")&& !i$outis.$iStrBlank(loanDetails.get("linkages").getAsString())) {
						setformfield(form, "detailsOfCollateral 1", loanDetails.get("linkages").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("udfDate")&& !i$outis.$iStrBlank(loanDetails.get("udfDate").getAsString())) {
						setformfield(form, "meetingDate", loanDetails.get("udfDate").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
						setformfield(form, "dollar", loanDetails.get("amount").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanSummary.has("firstPaymentDate")&& !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
						String dueDay = loanSummary.get("firstPaymentDate").getAsString().split("-")[2];
						setformfield(form, "dateDue", dueDay);
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanSummary.has("isShares")&& i$outis.$iStrFuzzyMatch(loanSummary.get("isShares").getAsString(), "Y")) {
						setformfield(form, "sharesCharacter", "X");
					}
				} catch (Exception e) {
					
				}
		    	try {
						setformfield(form, "undefined9", "SYSTEM-AUTH");
				} catch (Exception e) {
					
				}
		    	String date = i$ResM.getOnlydate(new Date());
		    	try {
						setformfield(form, "Date_2", date);
				} catch (Exception e) {
					
				}
		    	//#SRP00025 Ends changes
		    	try {
			    	if (i$outis.$iStrBlank(memberInfo.get("primaryMobile").getAsString())) {
					setformfield(form, "telNosCell1", "");
				    }
			    	else{
					setformfield(form, "telNosCell1",createTECUMobNo(memberInfo.get("primaryCode").getAsString(),memberInfo.get("primaryMobile").getAsString()));
			            }
			    }catch (Exception e) {
					
			        }
		    	try {
			    	if (i$outis.$iStrBlank(memberInfo.get("secondaryMobile").getAsString())) {
					setformfield(form, "telNosCell2", "");
			    	}
			    	else{
					setformfield(form, "telNosCell2",createTECUMobNo(memberInfo.get("secondaryCode").getAsString(),memberInfo.get("secondaryMobile").getAsString()));
			            }
			    } catch (Exception e) {
			    	
			    }
	            
		    	try {
					if (extraDetails.has("purposeLoanDesc")|| extraDetails.has("purposeDesc")) {
						StringBuilder loanPuposeDesc = new StringBuilder();
						/*try {
							if (extraDetails.has("purposeLoanDesc") && !i$outis.$iStrBlank(extraDetails.get("purposeLoanDesc").getAsString())) {
								loanPuposeDesc.append(extraDetails.get("purposeLoanDesc").getAsString());
							}
						} catch (Exception e) {
							
						}*/
						try {
							if (extraDetails.has("purposeDesc") && !i$outis.$iStrBlank(extraDetails.get("purposeDesc").getAsString())) {
//								loanPuposeDesc.append(" - "); //#MVT00088 Changes
								loanPuposeDesc.append(extraDetails.get("purposeDesc").getAsString());
							}
						} catch (Exception e) {
							
						}
						setformfield(form, "PURPOSE OF LOAN", loanPuposeDesc.toString());		
					}
				}catch(Exception e) {
				}
		    	try {
					if (extraDetails.has("Otherformsecurity")&& !i$outis.$iStrBlank(extraDetails.get("Otherformsecurity").getAsString())) {
						setformfield(form, "other", extraDetails.get("Otherformsecurity").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	try {
					if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
						setformfield(form, "dollars", loanDetails.get("amount").getAsString());
					}
				} catch (Exception e) {
					
				}
		    	//MSA starts
		    	try {
					if (loanDetails.has("amountInWords")&& !i$outis.$iStrBlank(loanDetails.get("amountInWords").getAsString())) {
						String amtWrd = loanDetails.get("amountInWords").getAsString();
						String[] amtWord = amtWrd.split("_");
						String amtWord1 = amtWord[0];
						String amtWord2 = amtWord[1];
						int length = amtWrd.length();
						if (length <= 60) {
							setformfield(form, "applyForLoan", amtWord1 + " And " + amtWord2);
						} else {
							setformfield(form, "applyForLoan", amtWord1);
							setformfield(form, "applyForLoan_2", " And "+amtWord2);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}//MSA ends
		    	try {
			    	if (memberInfo.has("DOB")) {
					String [] DOB = getClicoDateFormat(memberInfo.get("DOB").getAsString()).split("/");
					String month = DOB[0];
					String day = DOB[1];
					String year = DOB[2];
					setformfield(form, "DOB_day",day);
					setformfield(form, "DOB_Month",month);
					setformfield(form, "DOB_Year",year);
					};
		        } catch (Exception e) {
		        	
		        }
			// #SKP00001 Ends
		    // #SRP00006 Starts
			try {        
				if (extraDetails.has("promotionMedium") && !i$outis.$iStrBlank(extraDetails.get("promotionMedium").getAsString()) ) {
					if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "NEWS"))
						setformfieldS(form, "isNewspaper", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "RADIO"))
						setformfieldS(form, "isRadio", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "TV"))
						setformfieldS(form, "isTelevision", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "DIGAD"))
						setformfieldS(form, "isDigitalScreens", "On");						
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "REL"))
						setformfieldS(form, "isRelative", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "WEB"))
						setformfieldS(form, "isWebsite", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "SM"))
						setformfieldS(form, "isSocialMedia", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "FRND"))
						setformfieldS(form, "isFriend", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "COWRK"))
						setformfieldS(form, "isCoWorker", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "TM"))
						setformfieldS(form, "isTecuMembers", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "TS"))
						setformfieldS(form, "isTecuStaff", "On");
					else if (i$outis.$iStrFuzzyMatch(extraDetails.get("promotionMedium").getAsString(), "EXPO"))
						setformfieldS(form, "isExpoTradeshow", "On");
				}
			}catch (Exception e) {
				
			}
			//#SRP00013 Start
			try {        
				  {	//MVT00004 changes starts
					if (i$outis.$iStrFuzzyMatch(extraDetails.get("isVehicle").getAsString(), "true"))
						setformfieldS(form, "billOfSale", "On");
					if (i$outis.$iStrFuzzyMatch(extraDetails.get("isInsurance").getAsString(), "true"))
						setformfieldS(form, "comakerInsurance", "On");
					if (i$outis.$iStrFuzzyMatch(extraDetails.get("isPropertyLand").getAsString(), "true"))
						setformfieldS(form, "mortgage", "On");
					if (i$outis.$iStrFuzzyMatch(extraDetails.get("isShares").getAsString(), "true"))
						setformfieldS(form, "sharesCharacter", "On");						
					if (i$outis.$iStrFuzzyMatch(extraDetails.get("isUnits").getAsString(), "true"))
						setformfieldS(form, "units", "On");
				}	//MVT00004 changes ends
			}catch (Exception e) {
				
			} //#SRP00013 Ends
		
		}
		//MSA ends
	
	private void disclosurePdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp , String base64)throws IOException, DocumentException{
		JsonObject loanDetails = jsonObject.get("loanDetails").getAsJsonObject();
		JsonObject memberInfo = jsonObject.get("memberInfo").getAsJsonObject();
		JsonObject extraDetails = jsonObject.get("extraDetails").getAsJsonObject();
		JsonObject loanSummary = new JsonObject();//#MVT00098 Changes begins
		String customerId = "";
		String customerName = "";
		String homeAddress = "";
		try {
			if (jsonObject.has("summary")) {
				loanSummary = jsonObject.get("summary").getAsJsonObject();
			} else if (jsonObject.has("loanSummary")) {
				loanSummary = jsonObject.get("loanSummary").getAsJsonObject();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}//#MVT00098 Changes ends
		double totalPrincipal = loanDetails.get("tenor").getAsInt() * loanDetails.get("emi").getAsDouble();
		try {
			customerId = jsonObject.get("cif").getAsString();
			customerName = jsonObject.get("CustomerFullName").getAsString();
			homeAddress = memberInfo.get("homeAddress").getAsString();
		}catch(Exception e) {}
		try {
			if (!i$outis.$iStrBlank(customerId)) {
				setformfield(form, "Member No",customerId);
			}
		} catch (Exception e) {}
		try {
			if (!i$outis.$iStrBlank(customerName)) {
				setformfield(form, "Member Name 0",customerName);
			}
		} catch (Exception e) {}
		try {
			if (loanDetails.has("loanProduct")&& !i$outis.$iStrBlank(loanDetails.get("loanProduct").getAsString())) {
				setformfield(form, "Loan TypeRow1", loanDetails.get("loanProduct").getAsString());
			}
		} catch (Exception e) {
			
		}
		//MSA starts
				try {
					if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
						double number = loanDetails.get("amount").getAsDouble();
						String amountCom = null;
						if (number > 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00"); //#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00"); //#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						setformfield(form, "Amount FinancedRow1", "$"+amountCom);

					}
				} catch (Exception e) {
					
				}
				try {
					if (loanSummary.has("totalInterest")&& !i$outis.$iStrBlank(loanSummary.get("totalInterest").getAsString())) {
						double number = loanSummary.get("totalInterest").getAsDouble();
						String amountCom = null;
						if (number > 1000 ) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						setformfield(form, "Total Interest Charge Amt Row1", "$"+amountCom);
					}
				} catch (Exception e) {
					
				}
				try {//MSA00004 changes
					if (loanSummary.has("totalRepayAmount")&& !i$outis.$iStrBlank(loanSummary.get("totalRepayAmount").getAsString())) {
						double number = loanSummary.get("totalRepayAmount").getAsDouble();
						String amountCom = null;
						if (number > 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						setformfield(form, "Total Principal  Interest EMI x TenorRow1", "$"+amountCom);
					}
				} catch (Exception e) {
					
				}
				try {
					if (loanDetails.has("emi")&& !i$outis.$iStrBlank(loanDetails.get("emi").getAsString())) {
						double number = loanDetails.get("emi").getAsDouble();
						String amountCom = null;
						if (number > 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
							amountCom = formatter.format(d1);
						}
						setformfield(form, "INSTALLMENT", amountCom);
					}
				} catch (Exception e) {
					
				}
				// MSA ends
		try {
			if (loanDetails.has("intrestRate")&& !i$outis.$iStrBlank(loanDetails.get("intrestRate").getAsString())) {
				setformfield(form, "Annual Percentage Rate  APRRow1",loanDetails.get("intrestRate").getAsString()+"%");
			}
		} catch (Exception e) {
			
		}
		
		try {//MSA00004 changes
			if (loanSummary.has("totalInterest")&& !i$outis.$iStrBlank(loanSummary.get("totalInterest").getAsString())) {
				double number = loanSummary.get("totalInterest").getAsDouble();//MSA00014 starts
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
					amountCom = formatter.format(d1);
				}
				setformfield(form, "intrest charge", amountCom);//MSA00014 ends
			}
		} catch (Exception e) {
			
		}
		
		try {//MSA00004 changes
			if (loanSummary.has("totalInterest")&& !i$outis.$iStrBlank(loanSummary.get("totalInterest").getAsString())) {
				double number = loanSummary.get("totalInterest").getAsDouble();//MSA00014 starts
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
					amountCom = formatter.format(d1);
				}
				setformfield(form, "total intrest charge", amountCom);//MSA00014 ends
			}
		} catch (Exception e) {
			
		}
		
		try {
			if (loanDetails.has("maturityDate")&& !i$outis.$iStrBlank(loanDetails.get("maturityDate").getAsString())) {
				setformfield(form, "MATURITY DATE FINAL PAYMENT", loanDetails.get("maturityDate").getAsString());
			}
		} catch (Exception e) {
			
		}
		try {
			if (loanDetails.has("tenor")) {
				setformfield(form, "TENOR  Term", loanDetails.get("tenor").getAsInt() + "");
			}
		} catch (Exception e) {
			
		}
		
		try {
			if (loanDetails.has("branchDate") && !i$outis.$iStrBlank(loanDetails.get("branchDate").getAsString())) {  			//#SRI00033  changes  Starts
		        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
		        SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yy");
		        
		        String inputDateStr = loanDetails.get("branchDate").getAsString();
		        Date inputDate = inputFormat.parse(inputDateStr);
		        String formattedDateStr = outputFormat.format(inputDate);
		        
		        setformfield(form, "Date of Loan", formattedDateStr);
		        setformfield(form, "Date1", formattedDateStr);
		    }
		} catch (Exception e) {
			
		}																											//#SRI00033  changes  Ends
		try {
			if (loanSummary.has("firstPaymentDate")&& !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
				setformfield(form, "FIRST INSTALLMENT DUE ON", loanSummary.get("firstPaymentDate").getAsString());
			}
		} catch (Exception e) {
			
		}
		try {
			setformfield(form, "Text1", "0.00");
			setformfield(form, "Text2", "0.00");
			setformfield(form, "Text3", "0.00");
			setformfield(form, "PreparedBy", "SYSTEM-AUTH");
			setformfield(form, "CheckedBy", "SYSTEM-AUTH");
			setformfield(form, "Borrower", "Digital App confirmation");//#SRM00042 changes
		} catch (Exception e) {
			
		}
//		//MSA00014 starts
		try {
			if (loanSummary.has("totalInterest")&& !i$outis.$iStrBlank(loanSummary.get("totalInterest").getAsString())) {
				double number = loanSummary.get("totalInterest").getAsDouble();
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					Double dd = d1 + 0.00;
					NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
					amountCom = formatter.format(dd);
				}
				else {
					Double d1 = Double.valueOf(number);
					Double dd = d1 + 0.00;
					NumberFormat formatter = new DecimalFormat("####,###,###.00");//#MVT00113 changes
					amountCom = formatter.format(dd);
				}
				setformfield(form, "Text4",amountCom);
			}
		} catch (Exception e) {
			
		}//MSA00014 ends
		try {
			addImage(stamp, form, "Qr_Code2", base64);
		}catch(Exception e) {
			
		}
	}
	
	
	private void promissoryPdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp , String base64)throws IOException, DocumentException{
		JsonObject loanDetails = new JsonObject();
		JsonObject memberInfo = new JsonObject();
		JsonObject extraDetails = new JsonObject();
		JsonObject loanSummary = new JsonObject();
		
		try {
			loanDetails = jsonObject.get("loanDetails").getAsJsonObject();
		}catch(Exception e) {
			
		}
		try {
			memberInfo = jsonObject.get("memberInfo").getAsJsonObject();
		}catch(Exception e) {
			
		}
		try {
			extraDetails = jsonObject.get("extraDetails").getAsJsonObject();
		}catch(Exception e) {
			
		}//#MVT00099 changes begins
		if(jsonObject.has("loanSummary")) {
			loanSummary = jsonObject.get("loanSummary").getAsJsonObject();
		}
		if(jsonObject.has("summary")) {
			loanSummary = jsonObject.get("summary").getAsJsonObject();
		}
		//#MVT00099 changes ends
		String customerId = "";
		String customerName = "";
		String homeAddress = "";
		try {
			customerId = jsonObject.get("cif").getAsString();
			customerName = jsonObject.get("CustomerFullName").getAsString();
			homeAddress = memberInfo.get("homeAddress").getAsString();
		}catch(Exception e) {}
		
		try {
			if (!i$outis.$iStrBlank(customerId)) {
				setformfield(form, "MEMBER NO",customerId);
			}
		} catch (Exception e) {}
		try {
			if (!i$outis.$iStrBlank(customerName)) {
				setformfield(form, "BORROWER",customerName);
				setformfield(form, "Borrower signature", "Digital App confirmation");//#SRM00042 changes
			}
		} catch (Exception e) {}
		try {
			if (!i$outis.$iStrBlank(homeAddress)) {
				setformfield(form, "ADDRESS",homeAddress);
			}
		} catch (Exception e) {}
		try {
			if (loanDetails.has("branchDate")&& !i$outis.$iStrBlank(loanDetails.get("branchDate").getAsString())) {
				setformfield(form, "DATE", loanDetails.get("branchDate").getAsString());
				setformfield(form, "DATE_4", loanDetails.get("branchDate").getAsString());
			}
		} catch (Exception e) {
			
		}
		try {
			if (extraDetails.has("udfDate")&& !i$outis.$iStrBlank(extraDetails.get("udfDate").getAsString())) {
				setformfield(form, "DATE3", extraDetails.get("udfDate").getAsString());
			}
		} catch (Exception e) {
			
		}
		//MSA00003 starts
		try {
			if (loanSummary.has("firstPaymentDate") && !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
				String frstPayDate = loanSummary.get("firstPaymentDate").getAsString();
				String[] dateParts = frstPayDate.split("-");
				String dateString = null;
				String year = dateParts[0];
				String month = dateParts[1];
				String date = dateParts[2];
				int dateInt =Integer.valueOf(date);
				
				int monthNumber = Integer.parseInt(month);
				String monthLetter = Month.of(monthNumber).name().toString();
				Integer date1 = Integer.valueOf(date) - 1;
				int amountDate = date1;
				String dateWithSuffix = getDayOfMonthSuffix(dateInt,dateString);
				String dateWithSuffix2 = getDayOfMonthSuffix2(amountDate,dateString);
				setformfield(form, "chosen day", dateWithSuffix);
				setformfield(form, "day of", monthLetter+" "+year);
				setformfield(form, "and like amount on the", dateWithSuffix2);
			}
		} catch (Exception e) {
			
		}
		//MSA00003 ends
//		if (extraDetails.has("reference1FirstName")|| extraDetails.has("reference1LastName")) {
//			StringBuilder referenceFullName = new StringBuilder();
//			try {
//				if (extraDetails.has("reference1FirstName") && !i$outis.$iStrBlank(extraDetails.get("reference1FirstName").getAsString())) {
//					referenceFullName.append(extraDetails.get("reference1FirstName").getAsString());
//				}
//			} catch (Exception e) {
//				
//			}
////			try {
////				if (extraDetails.has("reference1LastName") && !i$outis.$iStrBlank(extraDetails.get("reference1LastName").getAsString())) {
////					referenceFullName.append(" ");
////					referenceFullName.append(extraDetails.get("reference1LastName").getAsString());
////				}
////			} catch (Exception e) {
////				
////			}
////			setformfield(form, "GUARANTOR", referenceFullName.toString());		
//		}
		//MSA starts
		try {
			if (loanDetails.has("amount")&& !i$outis.$iStrBlank(loanDetails.get("amount").getAsString())) {
				double number = loanDetails.get("amount").getAsDouble();
				String amountCom = null;
				if (number > 1000) {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.00");
					amountCom = formatter.format(d1);
				}
				else {
					Double d1 = Double.valueOf(number);
					NumberFormat formatter = new DecimalFormat("####,###,###.00");
					amountCom = formatter.format(d1);
				}
				setformfield(form, "Lender or order the sum of 1", amountCom);
			}
		} catch (Exception e) {
			
		}// MSA ends
		try {
			if (loanDetails.has("intrestRate")&& !i$outis.$iStrBlank(loanDetails.get("intrestRate").getAsString())) {
				Float intRate =  loanDetails.get("intrestRate").getAsFloat();
				Float monthIntrRate = intRate/12;
				setformfield(form, "Lender or order the sum of 2", monthIntrRate.toString());
			}
		} catch (Exception e) {
			
		}
		//MSA starts
				try {
					if (loanDetails.has("emi")&& !i$outis.$iStrBlank(loanDetails.get("emi").getAsString())) {
						double number = loanDetails.get("emi").getAsDouble();
						String amountCom = null;
						if (number > 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");
							amountCom = formatter.format(d1);
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("####,###,###.00");
							amountCom = formatter.format(d1);
						}
						setformfield(form, "per cent per month until the full paid value of this Note is received The first instalment of", amountCom);
					}
				} catch (Exception e) {
					
				}// MSA ends
		try {
			if (loanDetails.has("loanBranchName")&& !i$outis.$iStrBlank(loanDetails.get("loanBranchName").getAsString())) {
				setformfield(form, "BRANCH", loanDetails.get("loanBranchName").getAsString());
			}
		} catch (Exception e) {
			
		}
		try {
			if (loanSummary.has("firstPaymentDate")&& !i$outis.$iStrBlank(loanSummary.get("firstPaymentDate").getAsString())) {
				setformfield(form, "Date4", loanSummary.get("firstPaymentDate").getAsString());
			}
		} catch (Exception e) {
			
		}
		try {
			setformfield(form, "LENDER REPRESENTATIVE", "SYSTEM-AUTH");
			setformfield(form, "SIGN LENDER REPRESENTATIVE", "SYSTEM-AUTH");
		} catch (Exception e) {
			
		}
		try {
			addImage(stamp, form, "QRcode1", base64);
		}catch(Exception e) {
			
		}
	
	}
	
	// SBC0087 ENDS
	JsonObject JchangedVals = new JsonObject();

	private void setformfield(AcroFields form, String fldnam, String val) {

		try {
			// if rekym lite and changedvals json is there
			if (JchangedVals == null || (JchangedVals != null && JchangedVals.size() < 1)
					|| (JchangedVals != null && JchangedVals.size() > 0 && JchangedVals.has(fldnam))) {

				if (val != null && !val.contains("@") && !val.contains("."))
					val = val.toUpperCase();
				form.setField(fldnam, val);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	// SBC0087 STARTS

	JsonObject JchangedVals1 = new JsonObject();

	private void setformfieldS(AcroFields form, String fldnam, String val) {

		try {
			// if rekym lite and changedvals json is there
			if (JchangedVals1 == null || (JchangedVals1 != null && JchangedVals1.size() < 1)
					|| (JchangedVals1 != null && JchangedVals1.size() > 0 && JchangedVals1.has(fldnam))) {

				if (val != null && !val.contains("@") && !val.contains("."))
					// val = val.toUpperCase();
					form.setField(fldnam, val);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// SBC0087 ENDS

	// Fill the field data
	/*
	 * private void fillPDFField(JsonObject dataObject, AcroFields form) { try {
	 * Map<String,String> value = i$outis.findKeys(dataObject); for(String key:
	 * value.keySet()) { form.setField(key, value.get(key)); } } catch(Exception e)
	 * {  }
	 * 
	 * try { //SND ArrayList<String> mainObjectKeySet=getKeySet(dataObject); for(int
	 * i=0;i<=mainObjectKeySet.size();i++) { try { JsonElement obj =
	 * dataObject.get(mainObjectKeySet.get(i)); System.out.println(obj);
	 * if(dataObject.get(mainObjectKeySet.get(i)).isJsonObject()) { JsonObject
	 * subJsonObj = dataObject.get(mainObjectKeySet.get(i)).getAsJsonObject();
	 * ArrayList<String> subOBjectKetSet=getKeySet(subJsonObj); for(int
	 * j=0;j<=subOBjectKetSet.size();j++) { try { JsonElement obj1 =
	 * subJsonObj.get(subOBjectKetSet.get(j)); System.out.println(obj1);
	 * if(subJsonObj.get(subOBjectKetSet.get(j)).isJsonPrimitive()) { try { String
	 * key = subOBjectKetSet.get(j); String value =
	 * subJsonObj.get(key).getAsString(); form.setField(key,value); } catch
	 * (Exception e) { // TODO: handle exception logger.debug(e.getMessage()); } } }
	 * catch (Exception e) { // TODO: handle exception } } }else
	 * if(dataObject.get(mainObjectKeySet.get(i)).isJsonPrimitive()) { JsonElement
	 * obj2 = dataObject.get(mainObjectKeySet.get(i)); System.out.println(obj2); try
	 * { String str1 = mainObjectKeySet.get(i); System.out.println(str1); String
	 * str2 = dataObject.get(mainObjectKeySet.get(i)).getAsString();
	 * System.out.println(str2); form.setField(mainObjectKeySet.get(i),
	 * dataObject.get(mainObjectKeySet.get(i)).getAsString()); } catch (Exception e)
	 * { // TODO: handle exception logger.debug(e.getMessage()); } } } catch
	 * (Exception e) { // TODO: handle exception } }
	 * 
	 * } catch (Exception e) {  } }
	 */

	// for getting the Keys of Json Object
	public ArrayList<String> getKeySet(JsonObject i$sonObject) {
		ArrayList<String> iQueus = new ArrayList<String>();
		try {
			Set<Entry<String, JsonElement>> entrySet = i$sonObject.entrySet();
			for (Map.Entry<String, JsonElement> entry : entrySet) {
				iQueus.add(entry.getKey());
			}
			return iQueus;
		} catch (Exception e) {
			// nothing here
		}
		return iQueus;
	}
//#PKY00006 starts 

	public static void addImage(PdfStamper stamper, AcroFields form, String field, String baseString) {
		try {
			java.util.List<AcroFields.FieldPosition> photograph = form.getFieldPositions(field);
			if (photograph != null && photograph.size() > 0) {
				com.itextpdf.text.Rectangle rect = photograph.get(0).position;

				byte[] imageByteArray = java.util.Base64.getDecoder().decode(baseString);

				Image img = Image.getInstance(imageByteArray);
				img.scaleToFit(rect.getWidth(), rect.getHeight());
				img.setBorder(2);
				img.setAbsolutePosition(photograph.get(0).position.getLeft() + (rect.getWidth() - img.getScaledWidth()),
						photograph.get(0).position.getTop() - (rect.getHeight()));
				PdfContentByte cb = stamper.getOverContent((int) photograph.get(0).page);
				cb.addImage(img);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//MSA00033 starts
//	public void LICPdfValueSetter(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp)throws IOException, DocumentException{
//		try {
//			JsonObject personalInfo = jsonObject.get("personalInfo").getAsJsonObject();
//			JsonObject additionalDetl = jsonObject.get("additionalDetails").getAsJsonObject();
//			JsonObject productInfo = jsonObject.get("product").getAsJsonObject();
//			JsonObject primOCR = jsonObject.get("primaryOCrResult").getAsJsonObject();
////			JsonObject summaryContDetl = jsonObject.get("summary").getAsJsonObject().get("contactDetails").getAsJsonObject();
//			
//			Map<String, AcroFields.Item> fieldsLinkedHashMap = form.getFields();
//			List<String> filedName = new ArrayList<String>(fieldsLinkedHashMap.keySet());
//
//			try {
//				for (int i = 0; i <= filedName.size(); i++) {
//					try {
//					fillPDFField(additionalDetl, filedName.get(i), form);
//					fillPDFField(personalInfo, filedName.get(i), form);
//					}catch(Exception e) {
//						
//					}
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//			try {
//				StringBuilder permaddress = new StringBuilder();
//				try {
//					if (personalInfo.has("permAddLine1") && !i$outis.$iStrBlank(personalInfo.get("permAddLine1").getAsString())) {
//						permaddress.append(personalInfo.get("permAddLine1").getAsString());
//					}
//				} catch (Exception e) {}
//				try {
//					if (personalInfo.has("permAddLine2") && !i$outis.$iStrBlank(personalInfo.get("permAddLine2").getAsString())) {
//						permaddress.append(", ");
//						permaddress.append(personalInfo.get("permAddLine2").getAsString());
//					}
//				} catch (Exception e) {}
//				setformfield(form, "premAddress", permaddress.toString());
//				
//			}catch(Exception e) {}
//			try {
//				StringBuilder spouseName = new StringBuilder();
//				try {
//					if (additionalDetl.has("spouseFirstName") && !i$outis.$iStrBlank(additionalDetl.get("spouseFirstName").getAsString())) {
//						spouseName.append(additionalDetl.get("spouseFirstName").getAsString());
//					}
//				} catch (Exception e) {}
//				try {
//					if (additionalDetl.has("spouseSurName") && !i$outis.$iStrBlank(additionalDetl.get("spouseSurName").getAsString())) {
//						spouseName.append(".");
//						spouseName.append(additionalDetl.get("spouseSurName").getAsString());
//					}
//				} catch (Exception e) {}
//				setformfield(form, "spousesFullName", spouseName.toString());
//				
//			}catch(Exception e) {}
//		
//			
//			if (pdfName.equalsIgnoreCase("ProposalForm_LIC’s_Jeevan_Akshay")) {
//				JsonObject jeevanAkshy = productInfo.get("jeevanAkshy").getAsJsonObject();
//				for (int i = 0; i <= filedName.size(); i++) {
//					try {
//						fillPDFField(jeevanAkshy, filedName.get(i), form);
//					}catch(Exception e) {
//						
//					}
//				}
//				try {
//					if(primOCR.has("country") && !i$outis.$iStrBlank(primOCR.get("country").getAsString())) {
//						setformfield(form, "permAddCountryDesc", primOCR.get("country").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(primOCR.has("pinCode") && !i$outis.$iStrBlank(primOCR.get("pinCode").getAsString())) {
//						setformfield(form, "permAddZipCode", primOCR.get("pinCode").getAsString());
//					}
//				}catch(Exception e) {}
//
//			}
//			
//			else if(pdfName.equalsIgnoreCase("ProposalForm_INSURANCE_ON_OWN_LIFE_Jeevan_Labh")) {
//				JsonObject labhObj = productInfo.get("labh").getAsJsonObject();
//				try {
//					if(labhObj.has("sumAssured") && !i$outis.$iStrBlank(labhObj.get("sumAssured").getAsString())) {
//						setformfield(form, "sumProposed", labhObj.get("sumAssured").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(labhObj.has("planTerm") && !i$outis.$iStrBlank(labhObj.get("planTerm").getAsString())) {
//						setformfield(form, "policyterm", labhObj.get("planTerm").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(labhObj.has("paymentMode") && !i$outis.$iStrBlank(labhObj.get("paymentMode").getAsString())) {
//						setformfield(form, "modeOfPremium", labhObj.get("paymentMode").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(labhObj.has("paymentMode") && !i$outis.$iStrBlank(labhObj.get("paymentMode").getAsString())) {
//						setformfield(form, "modeOfPremium", labhObj.get("paymentMode").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(primOCR.has("pinCode") && !i$outis.$iStrBlank(primOCR.get("pinCode").getAsString())) {
//						setformfield(form, "permAddZipCode", primOCR.get("pinCode").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(primOCR.has("country") && !i$outis.$iStrBlank(primOCR.get("country").getAsString())) {
//						setformfield(form, "permAddState", personalInfo.get("permAddState").getAsString()+" ("+primOCR.get("country").getAsString()+")");
//					}
//				}catch(Exception e) {}
//				
//			}
//			else if(pdfName.equalsIgnoreCase("ProposalForm_LIC’s_CancerCover")) {
//				
//			}
//			else if(pdfName.equalsIgnoreCase("ProposalForm_INSURANCE_ON_OWN_LIFE_TermPlan")) {
//				JsonObject labhObj = productInfo.get("labh").getAsJsonObject();
//				try {
//					if(labhObj.has("sumAssured") && !i$outis.$iStrBlank(labhObj.get("sumAssured").getAsString())) {
//						setformfield(form, "sumProposed", labhObj.get("sumAssured").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(labhObj.has("planTerm") && !i$outis.$iStrBlank(labhObj.get("planTerm").getAsString())) {
//						setformfield(form, "planTerm", labhObj.get("planTerm").getAsString());
//					}
//				}catch(Exception e) {}
//				try {
//					if(labhObj.has("paymentMode") && !i$outis.$iStrBlank(labhObj.get("paymentMode").getAsString())) {
//						setformfield(form, "modePremium", labhObj.get("paymentMode").getAsString());
//					}
//				}catch(Exception e) {}
//				
////				try {
////					if(summaryInsu.has("policyNo") && !i$outis.$iStrBlank(summaryInsu.get("policyNo").getAsString())) {
////						setformfield(form, "1PolicyNumber", summaryInsu.get("policyNo").getAsString());
////					}
////				}catch(Exception e) {}
////				try {
////					if(summaryInsu.has("sumAssured") && !i$outis.$iStrBlank(summaryInsu.get("sumAssured").getAsString())) {
////						setformfield(form, "4SumAssured", summaryInsu.get("sumAssured").getAsString());
////					}
////				}catch(Exception e) {}
////				try {
////					if(summaryInsu.has("policyCommencementDate") && !i$outis.$iStrBlank(summaryInsu.get("policyCommencementDate").getAsString())) {
////						setformfield(form, "8DateOfCommencement", summaryInsu.get("policyCommencementDate").getAsString());
////					}
////				}catch(Exception e) {}
//			}
//			else if(pdfName.equalsIgnoreCase("Self_Declaration_Jeevan-Akshay_Form") || pdfName.equalsIgnoreCase("Self_Declaration_Jeevan_Labh_Form") || pdfName.equalsIgnoreCase("Self_Declaration_Cancer_Cover_Form")) {
//				if (pdfName.equalsIgnoreCase("Self_Declaration_Jeevan-Akshay_Form")) {
//					String policyName = jsonObject.get("summaryP").getAsJsonObject().get("insurance").getAsJsonObject().get("policyName").getAsString();
//					setformfield(form, "policyName", policyName);
//				}
//				if (pdfName.equalsIgnoreCase("Self_Declaration_Jeevan_Labh_Form")) {
//					String policyName = jsonObject.get("summaryI").getAsJsonObject().get("insurance").getAsJsonObject().get("policyName").getAsString();
//					setformfield(form, "policyName", policyName);
//				}
//				if (pdfName.equalsIgnoreCase("Self_Declaration_Cancer_Cover_Form")) {
//					String policyName = jsonObject.get("summaryH").getAsJsonObject().get("insurance").getAsJsonObject().get("policyName").getAsString();
//					setformfield(form, "policyName", policyName);
//				}
//				
//				StringBuilder fullname = new StringBuilder();
//				try {
//					
//					if(personalInfo.has("firstName") && !i$outis.$iStrBlank(personalInfo.get("firstName").getAsString())) {
//						fullname.append(personalInfo.get("firstName").getAsString());
//					}
//				}catch(Exception e) {}
////				try {
////					if(personalInfo.has("middleName") && !i$outis.$iStrBlank(personalInfo.get("middleName").getAsString())) {
////						fullname.append(" ");
////						fullname.append(personalInfo.get("middleName").getAsString());
////					}
////				}catch(Exception e) {}
////				try {
////					if(personalInfo.has("lastName") && !i$outis.$iStrBlank(personalInfo.get("lastName").getAsString())) {
////						fullname.append(" ");
////						fullname.append(personalInfo.get("lastName").getAsString());
////					}
////				}catch(Exception e) {}
//				setformfield(form, "fullName", personalInfo.get("firstName").getAsString());
////				try {
////					if(summaryInsu.has("policyName") && !i$outis.$iStrBlank(summaryInsu.get("policyName").getAsString())) {
////						setformfield(form, "policyName", summaryInsu.get("policyName").getAsString());
////					}
////				}catch(Exception e) {}
//				try {
//					String date = i$ResM.getOnlydate(new Date());
//					setformfield(form, "date", date);
//				}catch(Exception e) {}
//				try {
//					if(personalInfo.has("permAddCity") && !i$outis.$iStrBlank(personalInfo.get("permAddCity").getAsString())) {
//						setformfield(form, "permAddCity", personalInfo.get("permAddCity").getAsString());
//					}
//				}catch(Exception e) {}
//			}
//			else if(pdfName.equalsIgnoreCase("Illustration_of_Endowment_Plan")) {
//				String date = I$Ioutils.$getISONowAm();
//				try {
//					if(personalInfo.has("firstName") && !i$outis.$iStrBlank(personalInfo.get("firstName").getAsString())) {
//						setformfield(form, "policyHolderName", personalInfo.get("firstName").getAsString());
//					}
//				}catch(Exception e) {
//					
//				}
//				try {
//					if(personalInfo.has("age") && !i$outis.$iStrBlank(personalInfo.get("age").getAsString())) {
//						setformfield(form, "age", personalInfo.get("age").getAsString());
//					}
//				}catch(Exception e) {
//					
//				}
//				try {
//					if(additionalDetl.has("gender") && !i$outis.$iStrBlank(additionalDetl.get("gender").getAsString())) {
//						setformfield(form, "gender", additionalDetl.get("gender").getAsString());
//					}
//				}catch(Exception e) {
//					
//				}
//				setformfield(form, "DateOfIllustration", date);
//			}
//			
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//	}//MSA00033 ends
	
	//SRI00037  Changes Starts
	private void pdfValueSetter3(JsonObject jsonObject, String pdfName, AcroFields form, PdfStamper stamp , String base64)
			throws IOException, DocumentException {
		
		Map<String, AcroFields.Item> fieldsLinkedHashMap = form.getFields();
		List<String> filedName = new ArrayList<String>(fieldsLinkedHashMap.keySet());
		if (pdfName.equalsIgnoreCase("Group_Health_and_Life_Application_Form")) {
			JsonObject tranDetails = jsonObject.getAsJsonObject();
			JsonObject sectionB = jsonObject.getAsJsonObject("sectionB");
			JsonArray sectionC = jsonObject.getAsJsonArray("sectionC");
			JsonArray sectionD = jsonObject.getAsJsonArray("sectionD");
			JsonObject sectionE = jsonObject.getAsJsonObject("sectionE");
			
			try {
				for (int i = 0; i <= filedName.size(); i++) {
					fillPDFField(tranDetails, filedName.get(i), form);
					fillPDFField(sectionB, filedName.get(i), form);
					fillPDFField(sectionE, filedName.get(i), form);
				}
				}catch(Exception e) {
					e.printStackTrace();
				}
			
			try {
				if (!i$outis.$iStrBlank(tranDetails.get("maritalStatus").getAsString())) {
					if (i$outis.$iStrFuzzyMatch(tranDetails.get("maritalStatus").getAsString(), "S"))
						setformfield(form, "maritalStatus_S", "X");

					else if (i$outis.$iStrFuzzyMatch(tranDetails.get("maritalStatus").getAsString(), "M"))
						setformfield(form, "maritalStatus_M", "X");

					else if (i$outis.$iStrFuzzyMatch(tranDetails.get("maritalStatus").getAsString(), "D"))
						setformfield(form, "maritalStatus_D", "X");

					else if (i$outis.$iStrFuzzyMatch(tranDetails.get("maritalStatus").getAsString(), "W"))
						setformfield(form, "maritalStatus_W", "X");

					else if (i$outis.$iStrFuzzyMatch(tranDetails.get("maritalStatus").getAsString(), "C"))
						setformfield(form, "maritalStatus_C", "X");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			
			try {
				if (!i$outis.$iStrBlank(tranDetails.get("gender").getAsString())) {
					if (i$outis.$iStrFuzzyMatch(tranDetails.get("gender").getAsString(), "M")) {
						setformfield(form, "applicantGender_M", "X");
					} else if (i$outis.$iStrFuzzyMatch(tranDetails.get("gender").getAsString(), "F")) {
						setformfield(form, "applicantGender_F", "X");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			try {
				if(!i$outis.$iStrBlank(tranDetails.get("identification").getAsString())) {
					if(i$outis.$iStrFuzzyMatch(tranDetails.get("identification").getAsString(), "DP")) {
						setformfield(form, "identification_DP", "X");
					}
					else if(i$outis.$iStrFuzzyMatch(tranDetails.get("identification").getAsString(), "PP")) {
						setformfield(form, "identification_PP", "X");
					}
					else if(i$outis.$iStrFuzzyMatch(tranDetails.get("identification").getAsString(), "ID")) {
						setformfield(form, "identification_ID", "X");
					}
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				if(!i$outis.$iStrBlank(tranDetails.get("coverageType").getAsString())) {
					if(i$outis.$iStrFuzzyMatch(tranDetails.get("coverageType").getAsString(), "GH")) {
						setformfield(form, "coverageType_GH", "X");
					}
					else if(i$outis.$iStrFuzzyMatch(tranDetails.get("coverageType").getAsString(), "GL")) {
						setformfield(form, "coverageType_GL", "X");
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				if(!i$outis.$iStrBlank(tranDetails.get("extraCoverage").getAsString())) {
					if(i$outis.$iStrFuzzyMatch(tranDetails.get("extraCoverage").getAsString(), "VL")) {
						setformfield(form, "extraCoverage_VL", "X");
					}
					else if(i$outis.$iStrFuzzyMatch(tranDetails.get("extraCoverage").getAsString(), "DL")) {
						setformfield(form, "extraCoverage_DL", "X");
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			try {
				JsonObject spouseObject = sectionC.get(0).getAsJsonObject();
				if (spouseObject.has("spouseName") && !i$outis.$iStrBlank(spouseObject.get("spouseName").getAsString())) {
			        setformfield(form, "spouseName", spouseObject.get("spouseName").getAsString());
			    }
				
			    if (spouseObject.has("spouseGender") && spouseObject.get("spouseGender").getAsString().equals("M")||spouseObject.get("spouseGender").getAsString().equals("F")) {
			        setformfield(form, "spouseGender", spouseObject.get("spouseGender").getAsString());
			    }
			    
			    if (spouseObject.has("spouseDOB") && !i$outis.$iStrBlank(spouseObject.get("spouseDOB").getAsString())) {
			        setformfield(form, "spouseDOB", spouseObject.get("spouseDOB").getAsString());
			    }
			    
			    if (spouseObject.has("spouseEffectiveDate") && !i$outis.$iStrBlank(spouseObject.get("spouseEffectiveDate").getAsString())) {
			        setformfield(form, "spouseEffectiveDate", spouseObject.get("spouseEffectiveDate").getAsString());
			    }
			    
			    if (spouseObject.has("spouseCountryResidence") && !i$outis.$iStrBlank(spouseObject.get("spouseCountryResidence").getAsString())) {
			        setformfield(form, "spouseCountryResidence", spouseObject.get("spouseCountryResidence").getAsString());
			    }
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			try {
				
				for (int i = 1; i < sectionC.size(); i++) {
				    JsonObject member = sectionC.get(i).getAsJsonObject();
				    
				    if (member.has("child" + i + "Name") && !i$outis.$iStrBlank(member.get("child" + i + "Name").getAsString())) {
				        setformfield(form, "child" + i + "Name", member.get("child" + i + "Name").getAsString());
				    }
				    
				    if (member.has("child"+ i +"Gender") && !i$outis.$iStrBlank(member.get("child"+ i +"Gender").getAsString())) {
				        setformfield(form, "child"+ i +"Gender", member.get("child"+ i +"Gender").getAsString());
				    }
				    if (member.has("child" + i + "DOB") && !i$outis.$iStrBlank(member.get("child" + i + "DOB").getAsString())) {
				        setformfield(form, "child" + i + "DOB", member.get("child" + i + "DOB").getAsString());
				    }
				    if (member.has("child"+i+"EffectiveDate") && !i$outis.$iStrBlank(member.get("child"+i+"EffectiveDate").getAsString())) {
				        setformfield(form, "child"+i+"EffectiveDate", member.get("child"+i+"EffectiveDate").getAsString());
				    }
				    if (member.has("child"+i+"CountryResidence") && !i$outis.$iStrBlank(member.get("child"+i+"CountryResidence").getAsString())) {
				        setformfield(form, "child"+i+"CountryResidence", member.get("child"+i+"CountryResidence").getAsString());
				    }
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			try {
			    
			    for (int i = 0; i < sectionD.size(); i++) {
			        JsonObject member = sectionD.get(i).getAsJsonObject();
			        
			        if (member.has("relation" + (i + 1)) && !i$outis.$iStrBlank(member.get("relation" + (i + 1)).getAsString())) {
			            String relation = member.get("relation" + (i + 1)).getAsString();
			            setformfield(form, "relation" + (i + 1), relation);
			        }
			        
			        if (member.has("beneficiaryName" + (i + 1)) && !i$outis.$iStrBlank(member.get("beneficiaryName" + (i + 1)).getAsString())) {
			            String beneficiaryName = member.get("beneficiaryName" + (i + 1)).getAsString();
			            setformfield(form, "beneficiaryName" + (i + 1), beneficiaryName);
			        }
			        
			        if (member.has("gender" + (i + 1)) && !i$outis.$iStrBlank(member.get("gender" + (i + 1)).getAsString())) {
			            String gender = member.get("gender" + (i + 1)).getAsString();
			            setformfield(form, "gender" + (i + 1), gender);
			        }
			        
			        if (member.has("dob" + (i + 1)) && !i$outis.$iStrBlank(member.get("dob" + (i + 1)).getAsString())) {
			            String dob = member.get("dob" + (i + 1)).getAsString();
			            setformfield(form, "dob" + (i + 1), dob);
			        }
			        
			        if (member.has("percentage" + (i + 1)) && !i$outis.$iStrBlank(member.get("percentage" + (i + 1)).getAsString())) {
			            String percentage = member.get("percentage" + (i + 1)).getAsString();
			            setformfield(form, "percentage" + (i + 1), percentage);
			        }
			    }
			} catch (Exception e) {
			    e.printStackTrace();
			}
			
			try {
				if (sectionE.has("accountType") && !i$outis.$iStrBlank(sectionE.get("accountType").getAsString())) {
					
					if(i$outis.$iStrFuzzyMatch(sectionE.get("accountType").getAsString(), "savings")) {
						setformfield(form, "accountType_S", "X");
					}
					else if (i$outis.$iStrFuzzyMatch(sectionE.get("accountType").getAsString(), "savings")) {
						setformfield(form, "accountType_C", "X");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}
	//SRI00037  Changes Ends

private Ioutils $iStrFuzzymatch() {
		// TODO Auto-generated method stub
		return null;
	}

//#PKY00006 ends

	public IPDFPopulatorKeyMapping() {
		// super();
		// TODO Auto-generated constructor stub
	}

}
// #DVJ00018 Ends