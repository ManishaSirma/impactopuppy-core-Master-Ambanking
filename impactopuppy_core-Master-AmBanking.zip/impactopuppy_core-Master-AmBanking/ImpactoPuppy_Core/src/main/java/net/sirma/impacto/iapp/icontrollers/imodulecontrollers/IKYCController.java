/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 02, 2019 | #BVB00050   | Initial writing
      |0.2.2       | Baz 		| Feb 03, 2019 | #Va000026   | Workflow Related changes and cleaning of unused imports
      |0.2.2       | Baz 		| Mar 23, 2019 | #Va000027   | ReferDc Application Functionalities
      |0.2.2       | Baz 		| Apr 25, 2019 | #Va000028   | Date Format Change 
      |0.2.2       | Baz 		| May 15, 2019 | #Va000029   | Date Format Change
      |0.2.3       | Devraj 	| Feb 19, 2021 | #DVJ00032   | Fixed application display issue from TECU
      |0.2.3	   | Manikanta  | May 25, 2022 | #MVT00057   | Added code for risk profiling of existing customer 
      |0.2.3	   | Manikanta  | Sep 13, 2022 | #MVT00075	 | Added code For Risk scanning Of single existing customer
      |0.2.3       | Sindhu R   | Nov 12, 2022 | #SRM00008   | Added code for storing signature in the db
      |0.2.3	   | Manikanta  | Jul 17, 2023 | #MVT00128   | added code for for aml kyc checks reports
      |0.2.3       | Sindhu R   | Jul 19, 2023 | #SRM00050   | Added code for fetching reports in risk job
      |0.2.3       | Nagendra   | Aug 18, 2023 | #NAG00001   | added code to change the collection name for single risk profile 
      |0.2.3       | Pavithra   | Aug 23, 2023 | #PAV00016   | handled risk profiling job issues
      |0.2.3       | Madhura    | Aug 28, 2023 | #MSA00033   | handled for generating empty Template for NULL record reports
      |0.2.3       | Sindhu R   | Aug 31, 2023 | #SRM00057   | Added code for CIF workflow stage reversal
      |0.2.3       | Pavithra   | Sep 27, 2023 | #PAV00017   | Handled Changes of 12 parameters of KYC_AML Check
      |0.2.3       | Pavithra   | Oct 04, 2023 | #PAV00018   | Handled status and completed fields for risk profiling jobs and reports
      |0.2.3       | Pavithra   | Oct 06, 2023 | #PAV00019   | Risk Profiling job optimization changes
      |0.2.3       | Sindhu R   | Oct 27, 2023 | #SRM00067   | Handled code to trigger email for KYM and riskprofiling jobs
 	  |0.2.3       | Srikanth   | Nov 06, 2023 | #SRI00015   | Handled code to Period Code and Financial Year.
 	  |0.2.3       | Srikanth   | Nov 06, 2023 | #SRI00016   | Handled code Monthly Report Thread part.
 	  |0.2.3       | Pavithra   | Nov 15, 2023 | #PAV00022    | Handled code for AddtoWhitelist and AddtoBlackList 
 	  |0.2.3       | Pavithra   | Nov 27, 2023 | #PAV00028    | Handled lincu card validation parameter in riskprofiling job
 	  |0.2.3       | Sindhu R   | Nov 30, 2023 | #SRM00077    | Handled code for fetching individual KYM reports
 	  |0.2.3       | Sumit      | Dec 04 2023  | #SKG00038    | Added code for  risk profile modifications	  
 	  |0.2.3       | Srikanth   | Dec 22 2023  | #SRI00027    | Added code for  FATCA report handeling 
      ----------------------------------------------------------------------------------------------------------------
*/   
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController;
import net.sirma.impacto.iapp.ihelpers.IPDFTextExtractor;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IKYCController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ImpactoUtil Im$utils = new ImpactoUtil();
	private IExtWSLauncher i$EWslancher = new IExtWSLauncher();
	private IWebSearchController i$webSrvc = new IWebSearchController();
	private IModelEvaluationController risc= new IModelEvaluationController();
	private static final Logger logger = LoggerFactory.getLogger(IKYCController.class);
	private IAppMessageHandler iAppMsgHandler = new IAppMessageHandler();
	private IFuncSrvcController srvcFunction = new IFuncSrvcController();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IEmailService i$Email = new IEmailService();
	private ISmsService I$ISmsService = new ISmsService();
	private IMbpmContorller I$MbpmContorller = new IMbpmContorller();
	JsonObject thread$isonMsg = new JsonObject();
	JsonObject thread$isonheader = new JsonObject();
	JsonObject thread$isonMapJson = new JsonObject();
	JsonObject ibody = new JsonObject();
	JsonObject icbsbody = new JsonObject();
	String rCollName = null;
	String userid = null;

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String srvName = i$ResM.getSrvcName(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE") && !I$utils.$iStrFuzzyMatch(Scr, "OB2RSKSN") ) {	//#MVT00075 changes starts
				userid = IResManipulator.iloggedUser.get();
				thread$isonMsg = isonMsg;
				thread$isonheader = isonheader;
				thread$isonMapJson = isonMapJson;
				return createKYCApln(isonMsg, isonheader, isonMapJson);
			} else if(I$utils.$iStrFuzzyMatch(Scr, "OB2RSKSN") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")){
				isonMsg = existRiskScan(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "CREATE") && I$utils.$iStrFuzzyMatch(srvName, "CUST_SIGNATURE")) {  
				isonMsg = appSignature(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(SrvOpr, "ResetDoc") && I$utils.$iStrFuzzyMatch(srvName, "ResetDocument")) {
				isonMsg = resetDocument(isonMsg);
			}else if(I$utils.$iStrFuzzyMatch(Scr, "XWFBACKW") && I$utils.$iStrFuzzyMatch(SOpr, "PROCESS_TASK")) {
				backwardOperation(isonMsg); // #SRM00057 changes
			}else if(I$utils.$iStrFuzzyMatch(Scr, "OB2KYMRP") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				reportQuery(isonMsg); // #SRM00077 changes
			}else if(I$utils.$iStrFuzzyMatch(SrvOpr, "VALIDATE") && I$utils.$iStrFuzzyMatch(srvName, "OABINCOM")) {
				isonMsg = noOfStagesNotify(isonMsg);  //MSA00080 changes
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN OR INVALID OPERATION");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;	//#MVT00075 changes ends
	}

	public JsonObject createKYCApln(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject jBody = new JsonObject();
		String sRef = null;
		String Coll_Name = "";
		String DcStatus = null;
		String ScrCtrlClass = null;
		String sAppNumber = null;
		jBody = i$ResM.getBody(isonMsg);
		// remove the _id from the body if it exist
		try {
			jBody.remove("_id");
		} catch (Exception e) {
			// pass
		}

		try {
			JsonObject jFilter = new JsonObject();

			try {
				Coll_Name = isonMapJson.get("COLLNAME").getAsString();
			} catch (Exception e) {
				Coll_Name = null;
			}
			;
			// #Va000026 Begins
			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			ZonedDateTime now = ZonedDateTime.now();
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "WRK_FLW_STAGE", "PENDING");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdAt",
					i$ResM.adddate(Date.from(now.toInstant())).getAsJsonObject());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "RecordStat", "W_WIP");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getBody(isonMsg), "createdBy",
					IResManipulator.iloggedUser.get());

			String qry$up = "{$and:[{\"applicationId\":\"" + sAppNumber + "\", \"referenceNo\" : {$ne:\"" + sRef
					+ "\"}, \"isCurrVer\":\"Y\"}]}";

			String srefqry = "{$ne: \"" + sRef + "\"}";
			JsonObject subqry = new JsonObject();
			subqry.addProperty("$ne", sRef);
			jFilter.add("referenceNo", subqry.getAsJsonObject());
			jFilter.addProperty("applicationId", sAppNumber);
			// String ftr$qry = "{\"applicationId\":\""+sAppNumber+"\",\"referenceNo\":{$ne:
			// \""+sRef+"\"}}";

			JsonObject $update = new JsonObject();
			$update.addProperty("isCurrVer", "N");
			db$Ctrl.db$UpdateRow(Coll_Name, $update, jFilter);
			db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", $update, jFilter);

			// WOrkflow Status
			jFilter = new JsonObject();
			jFilter.addProperty("applicationId", sAppNumber);
			jFilter.addProperty("referenceNo", sRef);
			JsonObject Appl$Json = new JsonObject();
			Appl$Json = db$Ctrl.db$GetRow(Coll_Name, jFilter);

			if (!(Appl$Json != null)) {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if (I$utils.$iStrFuzzyMatch(Appl$Json.get("WRK_FLW_STAGE").getAsString(), "PENDING")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "H_HOLD"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_OH001");
			} else if ((I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "T_TERMINATED"))
					|| (I$utils.$iStrFuzzyMatch(Appl$Json.get("RecordStat").getAsString(), "C_CLOSED"))) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");
			} else {
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");
			}

			jBody.addProperty("referenceNo", sRef);
			JsonObject Jbdy = new JsonObject();
			// trigger Workflow
			if (I$utils.$iStrFuzzyMatch(DcStatus, "COMPLETED")) {
				// #BZ00002 change begins

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", IResManipulator.iloggedUser.get());	// #DVJ00032
				JsonObject date$convert = new JsonObject();
				if (jBody.has("personalInfo")) {
					date$convert = jBody.get("personalInfo").getAsJsonObject();
				}

				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("priDocDOI").getAsString());
					date$convert.add("priDocDOI_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;

				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("priDocDOE").getAsString());
					date$convert.add("priDocDOE_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("secDocDOI").getAsString());
					date$convert.add("secDocDOI_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}
				;
				try {
					JsonObject iso$date = dateFromatter(
							jBody.get("personalInfo").getAsJsonObject().get("secDocDOE").getAsString());
					date$convert.add("secDocDOE_ISO", iso$date);
					jBody.add("personalInfo", date$convert);
				} catch (Exception e) {
					// Pass
				}

				jFilter.addProperty("applicationId", sAppNumber);
				jFilter.addProperty("referenceNo", sRef);
				db$Ctrl.db$UpdateRow(Coll_Name, jBody, jFilter, "true");

				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
				int noOfDocs = 2; 
				
				try {
					noOfDocs = jBody.getAsJsonObject("documents").get("numberOfDocUploaded").getAsInt(); 
				}catch (Exception e) {
					noOfDocs = 2; 
				}
				
				
				if (noOfDocs > 1
						|| !iAppMsgHandler.checkAdd$Msg("12121218")) {
					ExecutorService executor = Executors.newFixedThreadPool(1);// creating a pool of threads
					for (int i = 0; i < 1; i++) {
						Runnable worker = new imbpmFwdThread(isonMsg, isonheader, isonMapJson);
						executor.execute(worker);// calling execute method of ExecutorService
					}
//				executor.shutdown();
//				while (!executor.isTerminated()) {
//				}

					logger.debug("Finished all threads");

					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				} else {
					iAppMsgHandler.add$Msg("12121218", new JsonArray());
					
				}
				// #BZ00002 Ends

			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
		} catch (Exception es) {
			es.printStackTrace();
			logger.debug(es.getMessage());
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "UNKNOWN EXCEPTION_TC001");

		}

	}
	//#MVT00057 Starts
	public JsonObject riskScan(JsonObject isonMsg) {
		try {
			JsonObject ftr = new JsonObject();
			JsonObject status = new JsonObject();
			int threads = isonMsg.get("threads").getAsInt();
			String scanId = isonMsg.get("scanId").getAsString();
			status.addProperty("initiatedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			status.addProperty("ScanId", scanId);
			status.addProperty("ScanType", isonMsg.get("ScanType").getAsString());//SKP00001 changes
			status.addProperty("Status", "WIP");//#PAV00018 Changes
			ftr.addProperty("ScanId", scanId);
			db$Ctrl.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN_LOG", status, ftr, "true");
			try { // #SRM00067 Changes start
            	String dateforEmail = status.get("initiatedTime").getAsString();
                srvcFunction.jobEmailNotification(isonMsg.get("ScanType").getAsString(), "Initiated", dateforEmail);
            } catch (Exception e) {
            	e.printStackTrace();
            } // #SRM00067 Changes end
			// #SRI00016 Changes Starts
			
			Thread achThread = new Thread();
			try {
					JsonObject jWrkArgs = new JsonObject();
					isonMsg.addProperty("scanId", scanId);
					jWrkArgs.add("isonMsg", isonMsg);
					jWrkArgs.addProperty("clsName",
							"net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController");
					jWrkArgs.addProperty("funcName", "getACHTrnReport");
					IThreadController IThread$worker = new IThreadController(jWrkArgs);
					achThread = new Thread(IThread$worker);
					achThread.start();
			} catch (Exception e) {
				
			}
			Thread locThread = new Thread();
			try {
					JsonObject jWrkArgs = new JsonObject();
					isonMsg.addProperty("scanId", scanId);
					jWrkArgs.add("isonMsg", isonMsg);
//					jWrkArgs.addProperty("scanId", scanId);
					jWrkArgs.addProperty("clsName",
							"net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController");
					jWrkArgs.addProperty("funcName", "getLocReport");
					IThreadController IThread$worker = new IThreadController(jWrkArgs);
					locThread = new Thread(IThread$worker);
					locThread.start();
			} catch (Exception e) {
				
			}
			Thread white$BlackThread = new Thread();
			try {
					JsonObject jWrkArgs = new JsonObject();
					isonMsg.addProperty("scanId", scanId);
					jWrkArgs.add("isonMsg", isonMsg);
//					jWrkArgs.addProperty("scanId", scanId);
					jWrkArgs.addProperty("clsName",
							"net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IFuncSrvcController");
					jWrkArgs.addProperty("funcName", "getWhite$BlackMemTypeReport");
					IThreadController IThread$worker = new IThreadController(jWrkArgs);
					white$BlackThread = new Thread(IThread$worker);
					white$BlackThread.start();
			} catch (Exception e) {
				
			}
			
			// #SRI00016 Changes ends
			Thread t = null;
			// SKG00038 starts
			//MSA00033 starts
//			JsonArray objStr = new JsonArray();
//			objStr.add("List of Members who have given Power of Attorney or Delegation of Authority to transact on their behalf");
//			objStr.add("List of Members not complying with TECU Due Diligence process");
//			objStr.add("List of Members whose source of funds or origin of wealth is not from Salary");
//			objStr.add("List of Members whose names figure in Negative News relating to criminal activities");
//			objStr.add("List of Members employed or doing business in Listed Business");
//			objStr.add("List of Members whose occupation involves higher risk for money laundering");
//			JsonArray finalResultArray = new JsonArray();
//			for(int j=0; j<objStr.size(); j++) {
//				JsonObject bussObj = new JsonObject();
//				JsonArray resultArr = new JsonArray();
//				bussObj.addProperty("ReportType", objStr.get(j).getAsString());
//				bussObj.addProperty("ScanId", scanId);
//				bussObj.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
////				bussObj.addProperty("fileName", "Delegation_of_Authority_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
////						.format(Calendar.getInstance().getTime())+ ".pdf");
//				bussObj.addProperty("fileName", objStr.get(j).getAsString()+" _"+ I$utils.$getISONowAm() +".pdf");
//				bussObj.add("reportResults", resultArr);
//				bussObj.addProperty("Status", "WIP");//#PAV00018 Changes
//				bussObj.addProperty("financialYear", I$MbpmContorller.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));      //SRI00015 Changes
//				bussObj.addProperty("periodCode", I$MbpmContorller.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));				//SRI00015 Changes
//				finalResultArray.add(bussObj);
//			}
//			db$Ctrl.db$InsertMany("ICOR_M_RISK_REPORT", finalResultArray);//MSA00033 ends
			// SKG00038 end
			for (int i = 0; i < threads; i++) {
				JsonObject jWrkArgs = new JsonObject();
				
	            jWrkArgs.add("isonMsg", isonMsg);
	    		jWrkArgs.addProperty("scanId", scanId);
	            jWrkArgs.addProperty("threadCount", i);
	            jWrkArgs.addProperty("totalNumberOfThreads", threads);
	            jWrkArgs.add("isonMsg", jWrkArgs.deepCopy());
				jWrkArgs.addProperty("clsName",
						"net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IKYCController");
				jWrkArgs.addProperty("funcName", "riskThreadProcess");
				IThreadController IThread$worker = new IThreadController(jWrkArgs);
				t = new Thread(IThread$worker);
				t.start();
			}
//			t.join();
//			reportsHandler(isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Operation is not completed");
		}
		return isonMsg;
	}
	public JsonObject riskThreadProcess(JsonObject argJson) {
		try {
			int noOfThread = 0;  //PAV00019 Changes
			double i$noOfIter = 0;
			int i$noOfIterInt = 0;
			int noOfIterThread = 0;
			int cifCount = 0;
			try {//#PAV00022 Changes Starts
				JsonObject wproj = new JsonObject();
				wproj.addProperty("_id", 0);	//#MVT00051 changes starts
				wproj.addProperty("customerId", 1);
				wproj.addProperty("financialCycle", 1);
				JsonArray i$whiteListedMem = db$Ctrl.db$GetSummRowsArray("ICOR_M_WHITELISTED_MEMBER", "{'active':'A','authStat':'A'}", wproj, 0, 0);	//#MVT00051 changes ends
				i$ResM.setGobalVals("i$whiteListedMem", i$whiteListedMem);
			} catch (Exception e) {
			}
			//PKY00075 starts
			try {
				JsonObject bProj = new JsonObject();
				bProj.addProperty("_id", 0);
				bProj.addProperty("customerId", 1);
				bProj.addProperty("financialCycle", 1);
				JsonArray i$blackListedMem = db$Ctrl.db$GetSummRowsArray("ICOR_M_BLACK_LIST", "{'active':'A','authStat':'A'}", bProj, 0, 0);
				i$ResM.setGobalVals("i$blackListedMem", i$blackListedMem);
			} catch (Exception e) {
			}
			//#PAV00022 Changes Ends
	        int threadCount = argJson.get("threadCount").getAsInt();
	        noOfThread = argJson.get("totalNumberOfThreads").getAsInt();
			cifCount = db$Ctrl.db$GetCountI("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}");
	        double i$noOfIterThreadDbl = Double.valueOf(cifCount) / noOfThread;
	        noOfIterThread = (int) Math.ceil(i$noOfIterThreadDbl);
			if (noOfIterThread < 100) {
				i$noOfIter = Double.valueOf(noOfIterThread) / noOfIterThread;
				i$noOfIter = Math.ceil(i$noOfIter);
			} else {
				i$noOfIter = Double.valueOf(noOfIterThread) / 100;
				i$noOfIterInt = (int) Math.ceil(i$noOfIter) * 100;
				i$noOfIter = Double.valueOf(i$noOfIterInt) / 100;
			}
			argJson.addProperty("noOfIter", i$noOfIter);
            argJson.addProperty("noOfIterThreadmem", noOfIterThread);
            argJson.addProperty("threadCount", threadCount);
            argJson.addProperty("noOfIterInt", i$noOfIterInt);
            riskProfileScan(argJson);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return argJson;		
	}
	//#MVT00075 starts
public JsonObject existRiskScan(JsonObject argJson) {
		JsonObject ibody = argJson.get("i-body").getAsJsonObject();
		JsonObject i$datasheet = new JsonObject();
		JsonObject isonMsg = new JsonObject();
		JsonObject cifData = new JsonObject();
		JsonObject proj = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject ftr = new JsonObject();
		JsonObject branchData= new JsonObject();
		Gson gson = new Gson();
		try {
			proj.addProperty("_id", 0);
			proj.addProperty("CustomerId", 1);
			proj.addProperty("Occupation", 1);	
			proj.addProperty("dueDiligence", 1);
			proj.addProperty("CustomerBranch", 1);
			proj.addProperty("Employmenttype", 1);
			proj.addProperty("isapplyForClico", 1);
			proj.addProperty("GeoLocationdesc", 1);
			proj.addProperty("CifCreationDate", 1);
			proj.addProperty("BirthCountryDesc", 1);
			proj.addProperty("CustomerFullName", 1);
			proj.addProperty("interestedInLoan", 1);
			proj.addProperty("Islincuapplication", 1);//#PAV00028 Changes 
			proj.addProperty("delegatedAutourity", 1);
			proj.addProperty("fixedDepositInterested", 1);
			proj.addProperty("isapplyForCunaInsurance", 1);
			proj.addProperty("CustomerBranch", 1);
			proj.addProperty("BranchName", 1);
			proj.addProperty("AddressForCorrespondence1", 1); //SRI000009 Changes starts
            proj.addProperty("AddressForCorrespondence2", 1);
            proj.addProperty("AddressForCorrespondence3", 1);
            proj.addProperty("AddressForCorrespondence4", 1);
            proj.addProperty("PAddress1", 1);
            proj.addProperty("PAddress2", 1);
            proj.addProperty("PAddress3", 1);
            proj.addProperty("PAddress4", 1);
            proj.addProperty("CustomerNationalityDesc", 1); //SRI000009 Changes ends
			ftr.addProperty("CustomerId", ibody.get("CustomerId").getAsString());
			cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", ftr, proj);
			
			String add1 =cifData.get("AddressForCorrespondence1").getAsString() ;
            String add2 = cifData.get("AddressForCorrespondence2").getAsString();
            String add3 = cifData.get("AddressForCorrespondence3").getAsString();
            String add4 = cifData.get("AddressForCorrespondence4").getAsString();
            String add5 = cifData.get("PAddress1").getAsString();
            String add6 = cifData.get("PAddress2").getAsString();
            String add7 = cifData.get("PAddress3").getAsString();
            String add8 = cifData.get("PAddress4").getAsString();
            String Locnd = cifData.get("CustomerNationalityDesc").getAsString();
            JsonArray geoLocArr1 = new JsonArray();
            geoLocArr1.add(add1);
            geoLocArr1.add(add2);
            geoLocArr1.add(add3);
            geoLocArr1.add(add4);
            geoLocArr1.add(add5);
            geoLocArr1.add(add6);
            geoLocArr1.add(add7);
            geoLocArr1.add(add8);
            geoLocArr1.add(Locnd);   
	
			projection.addProperty("DefaultTrn", 1);
			projection.addProperty("DefaultHTrn", 1);
			projection.addProperty("MinTransaction", 1);
			projection.addProperty("MaxTransaction", 1);
			JsonObject cParam =db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection);
			
			int transaction = 0;
			int highRiskTransaction = 0;
			JsonObject filter = new JsonObject();
			JsonObject filter1 = new JsonObject();
			JsonObject timings = new JsonObject();
			JsonArray hrtObject = new JsonArray();
			JsonObject funName = new JsonObject();
			JsonObject getDataFn = new JsonObject();
			JsonObject riskObjet = new JsonObject();
			JsonObject getHRTDataFn = new JsonObject();
			JsonObject linkedEntitiesData = new JsonObject();
			
			String scanId = Im$utils.generateRandomKey();
			isonMsg.addProperty("scanId", scanId);
			//isonMsg = argJson.get("isonMsg").getAsJsonObject();
			filter.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
			filter.addProperty("ScanId", scanId);
			timings.addProperty("initiatedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			db$Ctrl.db$UpdateRow("ICOR_M_EXIST_RISK_SCAN", timings, filter, "true");//#NAG00001
			
			riskObjet.addProperty("modelType", "TECU_RP");
			riskObjet.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
			riskObjet.addProperty("CustomerFullName", cifData.get("CustomerFullName").getAsString());
			try {
				getDataFn.addProperty("p_cust_no", cifData.get("CustomerId").getAsString());
//				getDataFn.addProperty("p_branch", "100");
				getDataFn.addProperty("p_branch", cifData.get("CustomerBranch").getAsString());
				getDataFn.addProperty("funcName", "GET_CUSTOMER_TRANSACTION");
				hrtObject.add(getDataFn);
			} catch (Exception e) {
				transaction = 0;
			}
			try {
				getHRTDataFn.addProperty("p_cust_no", cifData.get("CustomerId").getAsString());
//				getHRTDataFn.addProperty("p_branch", "100");
				getHRTDataFn.addProperty("p_branch", cifData.get("CustomerBranch").getAsString());
				getHRTDataFn.addProperty("funcName", "GET_CUSTOMER_HIGHRISK_TRANSACTION");
				hrtObject.add(getHRTDataFn);
			} catch (Exception e) {
				highRiskTransaction = 0;
			}
			try {
                linkedEntitiesData.addProperty("p_cust_no", cifData.get("CustomerId").getAsString());
                linkedEntitiesData.addProperty("funcName", "GET_LINKED_ENTITIES");
                hrtObject.add(linkedEntitiesData);
            }catch(Exception e) {
                
            }
			JsonArray funcRes = new JsonArray();
			try {
				funName.add("funcDetails", hrtObject);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, funName);
				JsonObject transactionDetails = srvcFunction.exeCallOrcl(isonMsg);
				funcRes = transactionDetails.get("i-body").getAsJsonObject().get("funcRes").getAsJsonArray();
				transaction = funcRes.get(0).getAsJsonObject().get("GET_CUSTOMER_TRANSACTION").getAsJsonObject()
						.get("l_count").getAsInt();
				highRiskTransaction = funcRes.get(1).getAsJsonObject().get("GET_CUSTOMER_HIGHRISK_TRANSACTION")
						.getAsJsonObject().get("l_count").getAsInt();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {    														 //SRI000009 Changes starts
                //transaction = cifData.getAsJsonObject("questionary").get("transaction").getAsInt();
                    if (transaction < 0) {
                    transaction = 0;
                    } else if (transaction > 10000) {
                    	transaction = 10000;
                    }
                    i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Transaction", transaction);
                 }catch (Exception e) {
           			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Transaction", 11);
          		  }
			try {
            //highRiskTransaction = cifData.getAsJsonObject("questionary").get("highRiskTransaction").getAsInt();
                if (highRiskTransaction < 0) {
                    highRiskTransaction = 0;
                } else if (highRiskTransaction > 10000) {
                	highRiskTransaction = 10000;
                }
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "High_Risk_Transaction",highRiskTransaction);
                } catch (Exception e) {
                i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "High_Risk_Transaction", 3);
            }																	//SRI000009 Changes ends
			 try {
                 String cifCreationDate = cifData.get("CifCreationDate").getAsString();
                 filter1.addProperty("KeyId", cifData.get("CustomerBranch").getAsString());
                 filter1.addProperty("Type", "CBS_BRANCH");
                 branchData = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter1);
                 String branchDate = "";
                 if(!I$utils.$isNull(branchData)) {
                     branchDate= branchData.get("BRANCH_DATE").getAsString();
                 }
                 //Date date = new Date();
                 //String currDate = I$utils.changeDateFormat(date, "yyyy-MM-dd");
                 int difference = I$utils.getDateDifference(cifCreationDate, branchDate, "yyyy-MM-dd");
                 double diff = (double) difference / 365;
                 if(diff <= 0) {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "New Member");
                 }
                 else if (diff < 2) {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "Member for less than two years");
                 } else {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "Member for more than two years");
                 }
             } catch (Exception e) {
                 i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "New Member");
                 e.printStackTrace();
             }
			try { 												//SRI000009 Changes 
				for(int x=0;x<geoLocArr1.size();x++)
                {
                    //JsonObject res=new JsonObject();
                    String var=  geoLocArr1.get(x).getAsString();
                    if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Origin','formulaRating.value':{'$regex' : '^" + geoLocArr1.get(x).getAsString() + "$','$options' : 'i'}}") > 0) {
                        i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", geoLocArr1.get(x).getAsString());
                    } else {
                        i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
                    }
                }
			} catch (Exception e) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
			}
//				String geoOrigin = cifData.get("BirthCountryDesc").getAsString();
//				if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA",
//						"{'dataFormulaId':'Geographic_Origin','formulaRating.value':{'$regex' : '^" + geoOrigin
//								+ "$','$options' : 'i'}}") > 0) {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", geoOrigin);
//				} else {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
//				}
			try {
				geoLocArr1.remove(geoLocArr1.size()-1);
                for(int x=0;x<geoLocArr1.size();x++)
                {
                    //JsonObject res=new JsonObject();
                    if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Location','formulaRating.value':{'$regex' : '^" + geoLocArr1.get(x).getAsString() + "$','$options' : 'i'}}") > 0) {
                        i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", geoLocArr1.get(x).getAsString());
                    } else {
                        i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");
                    }
                }
			} catch (Exception e) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");
			}
//			try {
//				String businessNature = cifData.get("Occupation").getAsString();
//				if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Nature_of_Business','formulaRating.value':{'$regex' : '^" + businessNature + "$','$options' : 'i'}}") > 0) {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", businessNature);
//				} else {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", "Other");
//				}
//			} catch (Exception e) {
//				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", "Other");
//			}
			// try {
			// 	String occupation = cifData.get("Occupation").getAsString();
			// 	if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Occupation','formulaRating.value':{'$regex' : '^" + occupation + "$','$options' : 'i'}}") > 0) {
			// 		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", occupation);
			// 	} else {
			// 		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
			// 	}
			// } catch (Exception e) {
			// 	i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
			// }
			try {
                String occupation = cifData.get("Occupation").getAsString();
                if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Occupation','formulaRating.value':{'$regex' : '^" + occupation + "$','$options' : 'i'}}") > 0) {
              	   i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", occupation);
                   try {
                        JsonObject occUpationRating = db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA",
                            "{'dataFormulaId':'Occupation','formulaRating.value':{'$regex' : '^"
                                        + occupation + "$','$options' : 'i'}}");

                           JsonArray amlDbData = occUpationRating.get("formulaRating").getAsJsonArray();
                           JsonObject data = i$impactoUtil.objFromArrWithSearch(amlDbData, "value", occupation);
                           if (I$utils.$iStrFuzzyMatch("H", data.get("rating").getAsString())) {
                           }
                       } catch (Exception e) {

                        }
					} else {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
					}
				} catch (Exception e) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
				}
				try {
					Boolean fixedDepositInterested = true;
					try {
						if (I$utils.$iStrFuzzyMatch(cifData.get("fixedDepositInterested").getAsString(), "N"))
							fixedDepositInterested = false;
					} catch (Exception e) {
					}
					if (fixedDepositInterested
							|| I$utils.$iStrFuzzyMatch(cifData.get("isapplyForClico").getAsString(), "Y")
							|| I$utils.$iStrFuzzyMatch(cifData.get("isapplyForCunaInsurance").getAsString(), "Y")) {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service",
								"Insurance");
					} else if (I$utils.$iStrFuzzyMatch(cifData.get("interestedInLoan").getAsString(), "Y")) {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Loan");
					} else if (I$utils.$iStrFuzzyMatch(cifData.get("Islincuapplication").getAsString(), "Y")) {//#PAV00028 Changes
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service",
								"LINCU card");
					} else {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service",
								"Insurance");
					}
				} catch (Exception e) {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Insurance");
			}
//			try {
//				if (cifData.get("dueDiligence").getAsBoolean() != true) {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence",
//							"Member unwilling or reluctant to co-operate with the Society’s due diligence process");
//				} else {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence",
//							"Member co-operative with due diligence process");
//				}
//			} catch (Exception e) {
//				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member co-operative with due diligence process");
//			}
//			try {
//				if (cifData.get("delegatedAutourity").getAsBoolean() == true) {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
//						"Transaction involves power of attorney or other form of delegated authority");
//				} else {
//					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
//						"Transaction does NOT involve power of attorney or other form of delegated authority");
//				}
//			} catch (Exception e) {
//				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
//					"Transaction does NOT involve power of attorney or other form of delegated authority");
//			}
			 try {
                 if (I$utils.$iStrFuzzyMatch(funcRes.get(2).getAsJsonObject().get("GET_LINKED_ENTITIES").getAsJsonObject().get("l_data").getAsString(),"POA")) {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
                             "Transaction involves power of attorney or other form of delegated authority");
                 } 
                 else {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
                         "Transaction does NOT involve power of attorney or other form of delegated authority");
                 }
             }catch(Exception e) {
                 i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
                         "Transaction does NOT involve power of attorney or other form of delegated authority");
             }
			try {
				if (cifData.get("dueDiligence").getAsBoolean() == true) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Diligence_Type",
							"Transaction involves power of attorney or other form of delegated authority");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Diligence_Type",
							"Transaction does NOT involve power of attorney or other form of delegated authority");
				}
			} catch (Exception e) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
						"Transaction does NOT involve power of attorney or other form of delegated authority");
			}
			 try {
                 if (!I$utils.$iStrFuzzyMatch(cifData.get("Employmenttype").getAsString(),"Via Salary")) {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds",
                         "Member’s source of funds or origin of wealth is NOT easily verifiable and/or a significant portion (more than 50%) is proceeds of a cash intensive business");
                 } else {
                     i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds",
                         "Member’s source of funds or origin of wealth is easily verifiable and is not proceeds of a cash intensive business");
                 }
             } catch (Exception e) {
                 i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds",
                     "Member’s source of funds or origin of wealth is easily verifiable and is not proceeds of a cash intensive business");
             }
			try {
				JsonObject arg$Json = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", "{'trnCd':'duckDuckGoSearch'}");
				arg$Json.addProperty("unqCommID", Im$utils.generateRandomKey());
				arg$Json.add("reqBody", new JsonObject());
				String extUrl = arg$Json.get("extUrl").getAsString();
				extUrl = extUrl.replaceAll("###IMP1###key###IMP2###",
					cifData.get("CustomerFullName").getAsString());
				arg$Json.addProperty("extUrl", extUrl);
				JsonObject JResp = i$EWslancher.ILaunchReq(arg$Json);
				JsonArray blackListWords = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", "{'PARAM':'BlackListWords'}")
					.getAsJsonArray("value");
				JsonObject Res = i$webSrvc.doDuckDuckGoSearch(JResp.get("resBody").getAsString(), blackListWords);
				if (Res.get("hits").getAsJsonArray().size() > 0) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search","Member is the subject of Negative News relating to criminal activities");
				} else
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search","Member is NOT the subject of Negative News relating to criminal activities");
			} catch (Exception e) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search","Member is NOT the subject of Negative News relating to criminal activities");
			}
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, riskObjet, "dataSheet", i$datasheet);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, riskObjet);

			JsonObject result = risc.evaluateExistingCustomer(argJson);
			result.addProperty("CompletedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			try {
				if (cifData.has("BranchName")) {
					result.addProperty("BranchName", cifData.get("BranchName").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (cifData.has("CustomerBranch")) {
					result.addProperty("CustomerBranch", cifData.get("CustomerBranch").getAsString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			db$Ctrl.db$UpdateRow("ICOR_M_EXIST_RISK_SCAN", result, filter, "true");//#NAG00001
			
			JsonArray indWeight = result.get("INDIVIDUAL_WEIGHT").getAsJsonArray();
			JsonObject trn = i$impactoUtil.objFromArrWithSearch(indWeight, "dataFormulaId", "Transaction");
			JsonObject hTrn = i$impactoUtil.objFromArrWithSearch(indWeight, "dataFormulaId", "High_Risk_Transaction");
			if (trn.get("value").getAsInt() < 3) {
				trn.addProperty("Description",
						"Number of member-generated transactions does NOT exceed 10 per month");
			} else {
				trn.addProperty("Description", "Number of member-generated transactions exceed 10 per month");
			}
			if (hTrn.get("value").getAsInt() < 3) {
				hTrn.addProperty("Description",
						"Member does NOT receive or remit more than 2 ACH transactions per month");
			} else {
				hTrn.addProperty("Description",
						"Member receives or remits more than 2 ACH transactions per month");
			}
				
			argJson.get("i-body").getAsJsonObject().remove("dataSheet");
			argJson.get("i-body").getAsJsonObject().addProperty("scanId", scanId);
			argJson.get("i-body").getAsJsonObject().add("results", result.get("INDIVIDUAL_WEIGHT").getAsJsonArray());						
		}catch(Exception e) {
			argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			return argJson;
		}
		return argJson;
	}
	//#MVT00075 ends
	public void riskProfileScan(JsonObject argJson) throws IOException{
		JsonObject projection = new JsonObject();
		int header$Count =0;// SKG00038 changes
		JsonObject ftr = new JsonObject();
		Gson gson = new Gson();	
		int threadCount = argJson.get("threadCount").getAsInt();
		String scanId = argJson.get("scanId").getAsString();
		double i$noOfIter = 0.0;
		i$noOfIter = argJson.get("noOfIter").getAsDouble();
		projection.addProperty("_id", 0);
		for (int i = 0; i < i$noOfIter; i++) {
			try {
				JsonObject proj = new JsonObject(); //PAV00019 Changes
				JsonObject i$datasheet = new JsonObject();
				int i$noOfIterInt = 0;
				i$noOfIterInt = argJson.get("noOfIterInt").getAsInt();
				int noOfIterThread = argJson.get("noOfIterThreadmem").getAsInt();
				JsonObject jbody = new JsonObject();
				JsonObject branchData= new JsonObject();//#PAV00017 Changes
				JsonObject cifData = new JsonObject();
				JsonArray reportObj = new JsonArray();
				JsonArray crimObj = new JsonArray(); 
				JsonArray noSal = new JsonArray();
				JsonArray delAuth = new JsonArray();
				JsonArray delDilig = new JsonArray();
				JsonArray aml = new JsonArray();

				JsonObject totalRecords = new JsonObject();
				JsonArray arrayFiltr = new JsonArray();
				JsonObject finres = new JsonObject();
				JsonArray risc$res = new JsonArray();
				JsonArray cif = new JsonArray();
				int skip = 0;
				int low = 0, high = 0, medium = 0, totalScannedRecordsCount = 0;
				proj.addProperty("_id", 0);
				proj.addProperty("CustomerId", 1);
				proj.addProperty("CustomerFullName", 1);
				proj.addProperty("CustomerBranch", 1);
				proj.addProperty("CifCreationDate", 1);
				proj.addProperty("BirthCountryDesc", 1);
				proj.addProperty("GeoLocationdesc", 1);
				proj.addProperty("Occupation", 1);
				proj.addProperty("fixedDepositInterested", 1);
				proj.addProperty("isapplyForClico", 1);
				proj.addProperty("isapplyForCunaInsurance", 1);
				proj.addProperty("interestedInLoan", 1);
				proj.addProperty("Islincuapplication", 1);//#PAV00028 Changes
				proj.addProperty("dueDiligence", 1);
				proj.addProperty("delegatedAutourity", 1);
				proj.addProperty("Employmenttype", 1);
				proj.addProperty("CustomerBranch", 1);
				proj.addProperty("BranchName", 1);
				proj.addProperty("AddressForCorrespondence1", 1);//#PAV00017 Changes
				proj.addProperty("AddressForCorrespondence2", 1);
				proj.addProperty("AddressForCorrespondence3", 1);
				proj.addProperty("AddressForCorrespondence4", 1);
				proj.addProperty("PAddress1", 1);
				proj.addProperty("PAddress2", 1);
				proj.addProperty("PAddress3", 1);
				proj.addProperty("PAddress4", 1);
				proj.addProperty("CustomerNationalityDesc", 1);//#PAV00017 Changes
				if (noOfIterThread < 100) {
					skip = noOfIterThread * i;
					skip = skip + (noOfIterThread * threadCount);
					cif = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}", proj, skip, noOfIterThread,"Y");
				} else {
					skip = 100 * i;
					skip = skip + (i$noOfIterInt * threadCount);
					cif = db$Ctrl.db$GetSummRowsArray("ICOR_M_CBS_CIF_DATA", "{'Active':'A'}", proj, skip, 100, "Y");
				}
				for (int j = 0; j < cif.size(); j++) {
					try {
						JsonObject riskObjet = new JsonObject();
						JsonObject filter = new JsonObject();
						JsonObject filter1 = new JsonObject();
						JsonObject timings = new JsonObject();
						JsonArray hrtObject = new JsonArray();
						JsonObject linkedEntitiesData = new JsonObject();
						JsonObject getDataFn = new JsonObject();
						JsonObject getHRTDataFn = new JsonObject();
						JsonObject funName = new JsonObject();
						int transaction = 0;
						int highRiskTransaction = 0;
						
						ftr.addProperty("ScanId", scanId);
						cifData = cif.get(j).getAsJsonObject();
						JsonArray regexArray = new JsonArray();//#PAV00017 Changes
						regexArray.add(cifData.get("AddressForCorrespondence1").getAsString());
						regexArray.add(cifData.get("AddressForCorrespondence2").getAsString());
						regexArray.add(cifData.get("AddressForCorrespondence3").getAsString());
						regexArray.add(cifData.get("AddressForCorrespondence4").getAsString());
						regexArray.add(cifData.get("PAddress1").getAsString());
						regexArray.add(cifData.get("PAddress2").getAsString());
					    regexArray.add(cifData.get("PAddress3").getAsString());
						regexArray.add(cifData.get("PAddress4").getAsString());
						regexArray.add(cifData.get("CustomerNationalityDesc").getAsString());
						jbody=cifData.deepCopy();
						jbody.remove("AddressForCorrespondence1");
						jbody.remove("AddressForCorrespondence2");
						jbody.remove("AddressForCorrespondence3");
						jbody.remove("AddressForCorrespondence4");
						jbody.remove("PAddress1");
						jbody.remove("PAddress2");
						jbody.remove("PAddress3");
						jbody.remove("PAddress4");
						jbody.remove("CustomerNationalityDesc");
//						jbody.remove("fixedDepositInterested");
//						jbody.remove("Islincuapplication");//#PAV00017 Changes
						//// SKG00038 starts
						try {
							if (threadCount == 0 && header$Count <= 0) {
								JsonArray objStr = new JsonArray();
								objStr.add("List of Members who have given Power of Attorney or Delegation of Authority to transact on their behalf");
//								objStr.add("List of Members not complying with TECU Due Diligence process");
//								objStr.add("List of Members whose source of funds or origin of wealth is not from Salary");
								objStr.add("List of Members whose names figure in Negative News relating to criminal activities");
//								objStr.add("List of Members employed or doing business in Listed Business");
								objStr.add("List of Members whose occupation involves higher risk for money laundering");
								JsonArray finalResultArray = new JsonArray();
								for (int k = 0; k < objStr.size(); k++) {
									JsonObject bussObj = new JsonObject();
									JsonArray resultArr = new JsonArray();
									JsonArray headers = new JsonArray();
									JsonObject head = new JsonObject();
									head.addProperty("Branch Code", 1);
									head.addProperty("Branch Name", 2);
									head.addProperty("Member ID", 3);
									head.addProperty("Member Name", 4);
									head.addProperty("CifCreationDate", 5);
									head.addProperty("Employmenttype", 6);
									head.addProperty("GeoLocationdesc", 7); 
									head.addProperty("Occupation", 8);
									head.addProperty("delegatedAutourity", 9); 
									head.addProperty("dueDiligence", 10);
									head.addProperty("BirthCountryDesc", 11);
									head.addProperty("Islincuapplication", 12);
									head.addProperty("fixedDepositInterested", 13);
									bussObj.addProperty("ReportType", objStr.get(k).getAsString());
									bussObj.addProperty("ScanId", scanId);
									bussObj.addProperty("CreatedAt",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
									bussObj.addProperty("fileName",objStr.get(k).getAsString() + " _" + I$utils.$getISONowAm() + ".pdf");
									resultArr.add(jbody);
									bussObj.add("reportResults", resultArr);
									bussObj.addProperty("Status", "WIP");// #PAV00018 Changes
									bussObj.addProperty("financialYear", I$MbpmContorller.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", "")); // SRI00015
									bussObj.addProperty("periodCode", I$MbpmContorller.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", "")); // SRI00015
									bussObj.add("headers", head);
									finalResultArray.add(bussObj);
								}
								db$Ctrl.db$InsertMany("ICOR_M_RISK_REPORT", finalResultArray);
								header$Count++;
							}
						} catch (Exception e) {
						}
						// SKG00038 end
						JsonObject isonMsg = argJson.get("isonMsg").getAsJsonObject();
						filter.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
						filter.addProperty("ScanId", scanId);
						timings.addProperty("initiatedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
								.format(Calendar.getInstance().getTime()));
						db$Ctrl.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN", timings, filter, "true");    //#MVT00036 Changes ends

						riskObjet.addProperty("modelType", "TECU_RP");
						riskObjet.addProperty("CustomerId", cifData.get("CustomerId").getAsString());
						riskObjet.addProperty("CustomerFullName", cifData.get("CustomerFullName").getAsString());
						try {//PAV00022 Changes Starts
							 if (I$utils.strInJsonArray(cifData.get("CustomerId").getAsString(), i$ResM.getGobalValArr("i$whiteListedMem"))) {
		                        		try {
		                        			int whiteListedMemCount = 0;
		                        		  	Calendar calendar = Calendar.getInstance();
				        	 	            int year = calendar.get(Calendar.YEAR);
				                            JsonObject CustomerIdObj = new JsonObject();
				                            JsonArray  CustomerObj= i$ResM.getGobalValArr("i$whiteListedMem");
				                            JsonObject whitelistPeriod = Im$utils.objFromArrWithSearch(CustomerObj , "customerId", cifData.get("CustomerId").getAsString()).getAsJsonObject();
				                            
				                            String financialCycle = whitelistPeriod.get("financialCycle").getAsString().substring(2);
				                            int yearPeriod = Integer.parseInt(financialCycle);
				                            if(yearPeriod==year) {
				                            	whiteListedMemCount++;

					                            CustomerIdObj = new JsonObject();
					                            CustomerIdObj.addProperty("whiteListedMem", cifData.get("CustomerId").getAsString());
					                            String whiteListedMemID = gson.toJson(CustomerIdObj);
					                            db$Ctrl.db$UpdateRowOperator("ICOR_M_EXIT_RISK_SCAN_LOG", whiteListedMemID, ftr, "true", "push");
					                            totalScannedRecordsCount++;
					                            continue;
				                            }
		                        		}catch(Exception e) {
		                        			e.printStackTrace();
		                        		}
		                        	}
		                        
		                        if (I$utils.strInJsonArray(cifData.get("CustomerId").getAsString(), i$ResM.getGobalValArr("i$blackListedMem"))) {
		                        		try {
		                        			int blackListedMemCount = 0;
		                        		  	Calendar calendar = Calendar.getInstance();
				        	 	            int year = calendar.get(Calendar.YEAR);
				                            JsonObject CustomerIdObj = new JsonObject();
				                            JsonArray  CustomerObj= i$ResM.getGobalValArr("i$blackListedMem");
				                            JsonObject blacklistPeriod = Im$utils.objFromArrWithSearch(CustomerObj , "customerId", cifData.get("CustomerId").getAsString()).getAsJsonObject();
				                            
				                            String financialCycle = blacklistPeriod.get("financialCycle").getAsString().substring(2);
				                            int yearPeriod = Integer.parseInt(financialCycle);
				                            if(yearPeriod==year) {
				                            	blackListedMemCount++;
				                            	JsonObject i$res = new JsonObject();
					                            CustomerIdObj = new JsonObject();
					                            CustomerIdObj.addProperty("blackListedMem", cifData.get("CustomerId").getAsString());
					                            String blackListedMemID = gson.toJson(CustomerIdObj);
					                            db$Ctrl.db$UpdateRowOperator("ICOR_M_EXIT_RISK_SCAN_LOG", blackListedMemID, ftr, "true", "push");
					                            high++;
					                            totalScannedRecordsCount++;
					                            i$res.addProperty("MODEL_COLOR", "Light Red");
					                            i$res.addProperty("MODEL_CLASS" , "High");
					                            db$Ctrl.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN",i$res,ftr);
					                            continue;
				                            }
		                        		}catch(Exception e) {
		                        			e.printStackTrace();
		                        		}	
		                        	}
						}catch(Exception e) {
							e.printStackTrace();
						}////PAV00022 Changes Ends
						try {
							getDataFn.addProperty("p_cust_no", cifData.get("CustomerId").getAsString());
//							getDataFn.addProperty("p_branch", "100");
							getDataFn.addProperty("p_branch", cifData.get("CustomerBranch").getAsString());
							getDataFn.addProperty("funcName", "GET_CUSTOMER_TRANSACTION");
							hrtObject.add(getDataFn);
						} catch (Exception e) {
							transaction = 0;
						}try {
							getHRTDataFn.addProperty("p_cust_no", cifData.get("CustomerId").getAsString());
//							getHRTDataFn.addProperty("p_branch", "100");
							getHRTDataFn.addProperty("p_branch", cifData.get("CustomerBranch").getAsString());
							getHRTDataFn.addProperty("funcName", "GET_CUSTOMER_HIGHRISK_TRANSACTION");
							hrtObject.add(getHRTDataFn);
						} catch (Exception e) {
							highRiskTransaction = 0;
						}
						try {//#PAV00017 Changes
							linkedEntitiesData.addProperty("p_cust_no", cifData.get("CustomerId").getAsString());
							linkedEntitiesData.addProperty("funcName", "GET_LINKED_ENTITIES");
							hrtObject.add(linkedEntitiesData);
						}catch(Exception e) {
							
						}
						JsonArray funcRes = new JsonArray();
						try {
							funName.add("funcDetails", hrtObject);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, funName);
							JsonObject transactionDetails = srvcFunction.exeCallOrcl(isonMsg);
							funcRes = transactionDetails.get("i-body").getAsJsonObject().get("funcRes")
									.getAsJsonArray();
							transaction = funcRes.get(0).getAsJsonObject().get("GET_CUSTOMER_TRANSACTION").getAsJsonObject()
									.get("l_count").getAsInt();
							highRiskTransaction = funcRes.get(1).getAsJsonObject().get("GET_CUSTOMER_HIGHRISK_TRANSACTION")
									.getAsJsonObject().get("l_count").getAsInt();
						}catch(Exception e) {
							e.printStackTrace();
						}
						try {
							 //transaction = cifData.getAsJsonObject("questionary").get("transaction").getAsInt();
							if (transaction < 0) {
								transaction = 0;
							} else if (transaction > 10000) {
								transaction = 10000;
							}
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Transaction", transaction);
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Transaction", 11);
						}
						try {
							//highRiskTransaction = cifData.getAsJsonObject("questionary").get("highRiskTransaction").getAsInt();
							if (highRiskTransaction < 0) {
								highRiskTransaction = 0;
							} else if (highRiskTransaction > 10000) {
								highRiskTransaction = 10000;
							}
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "High_Risk_Transaction",highRiskTransaction);
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "High_Risk_Transaction", 3);
						}
						try {//#PAV00017 Changes
							String cifCreationDate = cifData.get("CifCreationDate").getAsString();
							filter1.addProperty("KeyId", cifData.get("CustomerBranch").getAsString());
							filter1.addProperty("Type", "CBS_BRANCH");
							branchData = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter1);
							String branchDate = "";
							if(!I$utils.$isNull(branchData)) {
								branchDate= branchData.get("BRANCH_DATE").getAsString();
							}
							//Date date = new Date();
							//String currDate = I$utils.changeDateFormat(date, "yyyy-MM-dd");
							int difference = I$utils.getDateDifference(cifCreationDate, branchDate, "yyyy-MM-dd");
							double diff = (double) difference / 365;
							if(diff <= 0) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "New Member");
							}
							else if (diff < 2) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "Member for less than two years");
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "Member for more than two years");
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Client_Status", "New Member");
							e.printStackTrace();
						}//#PAV00017 Changes
						try {
							//String geoOrigin = cifData.get("BirthCountryDesc").getAsString();
							for(int x=0;x<regexArray.size();x++)//#PAV00017 Changes
							{
								//JsonObject res=new JsonObject();
								String var=  regexArray.get(x).getAsString();
								if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Origin','formulaRating.value':{'$regex' : '^" + regexArray.get(x).getAsString() + "$','$options' : 'i'}}") > 0) {
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", regexArray.get(x).getAsString());
								} else {
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
								}
							}//#PAV00017 Changes
//								res=db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Origin','formulaRating.value':{'$regex' : '^" + regexArray.get(i).getAsString()+ "$','$options' : 'i'}}"); 
//								if(!I$utils.$isNull(res))
//								{
//									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", regexArray.get(i).getAsString());
//									break;
//								}
//																				
//							}
//							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
//							
//							if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Origin','formulaRating.value':{'$regex' : '^" + geoOrigin + "$','$options' : 'i'}}") > 0) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", geoOrigin);
////								locObj.add(jbody);     // #SRM00050 changes 
//							} else {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
//							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Origin", "Other");
						}
						try {//#PAV00017 Changes
							regexArray.remove(regexArray.size()-1);
							for(int x=0;x<regexArray.size();x++)
							{
								//JsonObject res=new JsonObject();
								if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Location','formulaRating.value':{'$regex' : '^" + regexArray.get(x).getAsString() + "$','$options' : 'i'}}") > 0) {
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", regexArray.get(x).getAsString());
								} else {
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");
								}
							}//#PAV00017 Changes
//							String geoLoc = cifData.get("GeoLocationdesc").getAsString();
//							if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA","{'dataFormulaId':'Geographic_Location','formulaRating.value':{'$regex' : '^" + geoLoc + "$','$options' : 'i'}}") > 0) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", geoLoc);
//							} else {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");
//							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Geographic_Location", "Other");
						}
//						try {
//							String businessNature = cifData.get("Occupation").getAsString();
//							if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Nature_of_Business','formulaRating.value':{'$regex' : '^" + businessNature + "$','$options' : 'i'}}") > 0) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", businessNature);
////								jbody.addProperty("ReportType", "NATURE_OF_BUSINESS");
////								jbody.addProperty("ScanId", scanId);
////								jbody.addProperty("Created At", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
////										.format(Calendar.getInstance().getTime()));
//								reportObj.add(jbody);					
//							} else {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", "Other");
//							}
//						} catch (Exception e) {
//							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Nature_of_Business", "Other");
//						}
						try {
							String occupation = cifData.get("Occupation").getAsString();
							if (db$Ctrl.db$GetCountI("ICOR_M_DATA_FORMULA", "{'dataFormulaId':'Occupation','formulaRating.value':{'$regex' : '^" + occupation + "$','$options' : 'i'}}") > 0) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", occupation);
								try {
									JsonObject occUpationRating = db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA",
											"{'dataFormulaId':'Occupation','formulaRating.value':{'$regex' : '^"
													+ occupation + "$','$options' : 'i'}}");

									JsonArray amlDbData = occUpationRating.get("formulaRating").getAsJsonArray();
									JsonObject data = i$impactoUtil.objFromArrWithSearch(amlDbData, "value", occupation);
									if (I$utils.$iStrFuzzyMatch("H", data.get("rating").getAsString())) {
										aml.add(cifData); // #MVT0000
									}
								} catch (Exception e) {

								}
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
							}
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Occupation", "Other");
						}
						try {
							Boolean fixedDepositInterested = true;
							try {
								if (I$utils.$iStrFuzzyMatch(cifData.get("fixedDepositInterested").getAsString(), "N"))
									fixedDepositInterested = false;
							} catch (Exception e) {
							}
//							if (fixedDepositInterested || I$utils.$iStrFuzzyMatch(cifData.get("isapplyForClico").getAsString(), "Y")
//								|| I$utils.$iStrFuzzyMatch(cifData.get("isapplyForCunaInsurance").getAsString(), "Y")) {
//							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Insurance");
//							} else if (I$utils.$iStrFuzzyMatch(cifData.get("interestedInLoan").getAsString(),"Y")) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "Loan");
//							} 
							if (I$utils.$iStrFuzzyMatch(cifData.get("Islincuapplication").getAsString(), "Y")) { //isLinCUApplication //#PAV00028 Changes
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "LINCU card");
							} else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "No LINCU card");
							}
						} catch (Exception e) {
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Type_of_Product_or_Service", "No LINCU card");
						}
//						try {
//							if (cifData.get("dueDiligence").getAsBoolean() != true) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member unwilling or reluctant to co-operate with the Society’s due diligence process");
//								
//							} else {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member co-operative with due diligence process");
//							}
//						} catch (Exception e) {
//							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Due_Diligence", "Member co-operative with due diligence process");
//						}
						try {//#PAV00017
							if (I$utils.$iStrFuzzyMatch(funcRes.get(2).getAsJsonObject().get("GET_LINKED_ENTITIES").getAsJsonObject().get("l_data").getAsString(),"POA")) {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
										"Transaction involves power of attorney or other form of delegated authority");
									delAuth.add(cifData);
							} //#PAV00017
							else {
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
									"Transaction does NOT involve power of attorney or other form of delegated authority");
							}
						}catch(Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
									"Transaction does NOT involve power of attorney or other form of delegated authority");
						}
						
//						try {
//							if (cifData.get("dueDiligence").getAsBoolean() == true) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Diligence_Type",
//									"Transaction involves power of attorney or other form of delegated authority");
//								delDilig.add(jbody);
//							} else {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Diligence_Type",
//									"Transaction does NOT involve power of attorney or other form of delegated authority");
//							}
//						} catch (Exception e) {
//							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Delegated_Autourity",
//								"Transaction does NOT involve power of attorney or other form of delegated authority");
//						}
						
						
//						try {
//							if (!I$utils.$iStrFuzzyMatch(cifData.get("Employmenttype").getAsString(),"Via Salary")) {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds",
//									"Member’s source of funds or origin of wealth is NOT easily verifiable and/or a significant portion (more than 50%) is proceeds of a cash intensive business");
//								noSal.add(jbody);
//							} else {
//								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds",
//									"Member’s source of funds or origin of wealth is easily verifiable and is not proceeds of a cash intensive business");
//							}
//						} catch (Exception e) {
//							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "Source_of_Funds",
//								"Member’s source of funds or origin of wealth is easily verifiable and is not proceeds of a cash intensive business");
//						}
						try {
							JsonObject arg$Json = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", "{'trnCd':'duckDuckGoSearch'}");
							arg$Json.addProperty("unqCommID", Im$utils.generateRandomKey());
							arg$Json.add("reqBody", new JsonObject());
							String extUrl = arg$Json.get("extUrl").getAsString();
							extUrl = extUrl.replaceAll("###IMP1###key###IMP2###",
								cifData.get("CustomerFullName").getAsString());
							arg$Json.addProperty("extUrl", extUrl);
							JsonObject JResp = i$EWslancher.ILaunchReq(arg$Json);
							JsonArray blackListWords = db$Ctrl.db$GetRow("ICOR_C_SDN_PARAM", "{'PARAM':'BlackListWords'}")
								.getAsJsonArray("value");
							JsonObject Res = i$webSrvc.doDuckDuckGoSearch(JResp.get("resBody").getAsString(), blackListWords);
							if (Res.get("hits").getAsJsonArray().size() > 0) {
								crimObj.add(cifData);
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search","Member is the subject of Negative News relating to criminal activities");
							} else
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search","Member is NOT the subject of Negative News relating to criminal activities");
						} catch (Exception e) {
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$datasheet, "News_Search","Member is NOT the subject of Negative News relating to criminal activities");
						}
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, riskObjet, "dataSheet", i$datasheet);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, riskObjet);

						JsonObject result = risc.evaluateExistingCustomer(argJson);
						result.addProperty("ScanId", scanId);
						try {
							if (cifData.has("BranchName")) {
								result.addProperty("BranchName", cifData.get("BranchName").getAsString());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						try {
							if (cifData.has("CustomerBranch")) {
								result.addProperty("CustomerBranch", cifData.get("CustomerBranch").getAsString());
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						risc$res.add(result);
						arrayFiltr.add(filter);
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, i$ResM.I_BDYTAG, result);					
						String res = result.get("MODEL_CLASS").getAsString();
						if(I$utils.$iStrFuzzyMatch(res, "Low")) {
							low++;
							totalScannedRecordsCount++;
						}
						else if(I$utils.$iStrFuzzyMatch(res, "Medium")) {
							medium++;
							totalScannedRecordsCount++;
						}
						else if(I$utils.$iStrFuzzyMatch(res, "High")) {
							high++;
							totalScannedRecordsCount++;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				try {
					if (delAuth.size() > 0) {//MSA00033 starts
						ftr.addProperty("ReportType", "List of Members who have given Power of Attorney or Delegation of Authority to transact on their behalf");
						JsonObject delReportObj = new JsonObject();
						JsonObject delAuthRecords = new JsonObject();
						delAuthRecords.add("$each", delAuth);
		                delReportObj.add("reportResults", delAuthRecords);
	        			String i$reportsDoc = gson.toJson(delReportObj);
    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$reportsDoc, ftr, "true", "push");//MSA00033 ends
					}
					if (delDilig.size() > 0) {//MSA00033 starts
						ftr.addProperty("ReportType", "List of Members not complying with TECU Due Diligence process");
						JsonObject delReportObj = new JsonObject();
						JsonObject delDiligRecords = new JsonObject();
						delDiligRecords.add("$each", delDilig);
		                delReportObj.add("reportResults", delDiligRecords);
	        			String i$reportsDoc = gson.toJson(delReportObj);
    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$reportsDoc, ftr, "true", "push");//MSA00033 ends		
    	        	}
				
					if (noSal.size() > 0) {//MSA00033 starts
						ftr.addProperty("ReportType", "List of Members whose source of funds or origin of wealth is not from Salary");
						JsonObject delReportObj = new JsonObject();
						JsonObject noSalRecords = new JsonObject();
						noSalRecords.add("$each", noSal);
		                delReportObj.add("reportResults", noSalRecords);
	        			String i$reportsDoc = gson.toJson(delReportObj);
    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$reportsDoc, ftr, "true", "push");//MSA00033 ends
//						if (db$Ctrl.db$GetCountI("ICOR_M_RISK_REPORT", ftr) > 0) {
//							projection.addProperty("reportResults", 1);
//							JsonObject dbData = db$Ctrl.db$GetRow("ICOR_M_RISK_REPORT", ftr, projection);
//							JsonArray dataArray = dbData.getAsJsonArray("reportResults");
//							dataArray.addAll(noSal.getAsJsonArray());
//							bussObj.add("reportResults", dataArray);
//						} else {
//							bussObj.addProperty("ReportType", "List of Members whose source of funds or origin of wealth is not from Salary");
//							bussObj.addProperty("ScanId", scanId);
//							bussObj.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime()));
//							bussObj.addProperty("fileName", "Source_Of_Funds_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime())+ ".pdf");
//							bussObj.add("reportResults", noSal);
//						}
//						db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", bussObj, ftr, "true");
					}
					if (crimObj.size() > 0) {//MSA00033 starts
//						ftr.remove("ReportType");
						ftr.addProperty("ReportType", "List of Members whose names figure in Negative News relating to criminal activities");
						JsonObject delReportObj = new JsonObject();
						JsonObject crimObjRecords = new JsonObject();
						crimObjRecords.add("$each", crimObj);
		                delReportObj.add("reportResults", crimObjRecords);
	        			String i$reportsDoc = gson.toJson(delReportObj);
    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$reportsDoc, ftr, "true", "push");//MSA00033 ends
						
//						if (db$Ctrl.db$GetCountI("ICOR_M_RISK_REPORT", ftr) > 0) {
//							projection.addProperty("reportResults", 1);
//							JsonObject dbData = db$Ctrl.db$GetRow("ICOR_M_RISK_REPORT", ftr, projection);
//							JsonArray dataArray = dbData.getAsJsonArray("reportResults");
//							dataArray.addAll(crimObj.getAsJsonArray());
////						    occupations.add(dataArray);
//							bussObj.add("reportResults", dataArray);
//						} else {
//							bussObj.addProperty("ReportType", "List of Members whose names figure in Negative News relating to criminal activities");
//							bussObj.addProperty("ScanId", scanId);
//							bussObj.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime()));
//							bussObj.addProperty("fileName", "Criminal_Activities_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime())+ ".pdf");
//							bussObj.add("reportResults", crimObj);
//						}
//						db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", bussObj, ftr, "true");
					}
					if (reportObj.size() > 0) {//MSA00033 starts
//						ftr.remove("ReportType");
						ftr.addProperty("ReportType", "List of Members employed or doing business in Listed Business");
						JsonObject delReportObj = new JsonObject();
						JsonObject reportObjRecords = new JsonObject();
						reportObjRecords.add("$each", reportObj);
		                delReportObj.add("reportResults", reportObjRecords);
	        			String i$reportsDoc = gson.toJson(delReportObj);
    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$reportsDoc, ftr, "true", "push");//MSA00033 ends
//						if (db$Ctrl.db$GetCountI("ICOR_M_RISK_REPORT", ftr) > 0) {
//							projection.addProperty("reportResults", 1);
//							JsonObject dbData = db$Ctrl.db$GetRow("ICOR_M_RISK_REPORT", ftr, projection);
//							JsonArray dataArray = dbData.getAsJsonArray("reportResults");
//							dataArray.addAll(reportObj.getAsJsonArray());
//							bussObj.add("reportResults", dataArray);
//						} else {
//							bussObj.addProperty("ReportType", "List of Members employed or doing business in Listed Business");
//							bussObj.addProperty("ScanId", scanId);
//							bussObj.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime()));
//							bussObj.addProperty("fileName", "Listed_Business_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime())+ ".pdf");
//							bussObj.add("reportResults", reportObj);
//						}
//						db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", bussObj, ftr, "true");
					}
//					if (locObj.size() > 0) { // #SRM00050 changes start
//						ftr.addProperty("ReportType", "Geographic_location");
//						if (db$Ctrl.db$GetCountI("ICOR_M_RISK_REPORT", ftr) > 0) {
//							projection.addProperty("reportResults", 1);
//							JsonObject dbData = db$Ctrl.db$GetRow("ICOR_M_RISK_REPORT", ftr, projection);
//							JsonArray dataArray = dbData.getAsJsonArray("reportResults");
//							dataArray.addAll(locObj.getAsJsonArray());
//							bussObj.add("reportResults", dataArray);
//						} else {
//							bussObj.addProperty("ReportType", "Geographic_location");
//							bussObj.addProperty("ScanId", scanId);
//							bussObj.addProperty("Created At", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
//									.format(Calendar.getInstance().getTime()));
//							bussObj.add("reportResults", locObj);
//						}
//						db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", bussObj, ftr, "true"); // #SRM00050 changes end
//						db$Ctrl.db$UpdateRowOperator("ICOR_M_EXIT_RISK_SCAN_LOG", gson.toJson(bussObj), ftr, "true",
//								"push");
	//
//					}
					if(aml.size()>0) {//MSA00033 starts
	                    ftr.addProperty("ReportType", "List of Members whose occupation involves higher risk for money laundering");
	                    JsonObject delReportObj = new JsonObject();
						JsonObject amlRecords = new JsonObject();
//						for (int m = 0; m < aml.size(); m++) {
//							try {
//								JsonObject runningObj = aml.get(m).getAsJsonObject();
//								Set<String> keys = runningObj.keySet();
//								for (String key : keys) {
//									try {
//										String temp = runningObj.get("Occupation").getAsString();
//										aml.get(i).getAsJsonObject().remove("Occupation");
//										
//										aml.get(i).getAsJsonObject().addProperty("Member ID",
//												runningObj.get("CustomerId").getAsString());								
//										aml.get(i).getAsJsonObject().addProperty("Member Name",
//												runningObj.get("CustomerFullName").getAsString());
//										aml.get(i).getAsJsonObject().addProperty("Branch Code",
//												runningObj.get("CustomerBranch").getAsString());
//										aml.get(i).getAsJsonObject().addProperty("Branch Name",
//												runningObj.get("BranchName").getAsString());								
//										aml.get(i).getAsJsonObject().addProperty("Location",
//												runningObj.get("GeoLocationdesc").getAsString());
//										aml.get(i).getAsJsonObject().addProperty("Occupation",temp);
//										aml.get(i).getAsJsonObject().addProperty("Date of Onboarding",
//												runningObj.get("CifCreationDate").getAsString());
//										break;
//									} catch (Exception e) {
//									}
//								}
//								aml.get(i).getAsJsonObject().remove("CustomerId");
//								aml.get(i).getAsJsonObject().remove("CustomerFullName");
//								aml.get(i).getAsJsonObject().remove("CustomerBranch");
//								aml.get(i).getAsJsonObject().remove("BranchName");
//								aml.get(i).getAsJsonObject().remove("CifCreationDate");
//								aml.get(i).getAsJsonObject().remove("GeoLocationdesc");
//								aml.get(i).getAsJsonObject().remove("Employmenttype");
//								aml.get(i).getAsJsonObject().remove("BirthCountryDesc");
//							} catch (Exception e) {
//							}
//						}
		                amlRecords.add("$each", aml);
		                delReportObj.add("reportResults", amlRecords);
	        			String i$reportsDoc = gson.toJson(delReportObj);
    	        		db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$reportsDoc, ftr, "true", "push");//MSA00033 ends
	                }
				} catch (Exception e) {

				}
				
				finres.add("riscResulr", risc$res);
				db$Ctrl.db$UpdateMany("ICOR_M_EXIT_RISK_SCAN", risc$res, arrayFiltr, "true");
				try {
					srvcFunction.getRiskPrfReport(risc$res, scanId);
				}catch(Exception e) {}
				ftr.remove("ReportType");//SKP00001 changes
				totalRecords.addProperty("RiscProfiling" + "."+"High", high);
				totalRecords.addProperty("RiscProfiling" + "."+"Medium", medium);
				totalRecords.addProperty("RiscProfiling" + "."+"Low", low);
				totalRecords.addProperty("TotalScannedRecordsCount", totalScannedRecordsCount);
				db$Ctrl.db$UpdateRowOperator("ICOR_M_EXIT_RISK_SCAN_LOG", gson.toJson(totalRecords), ftr, "true", "inc");
			
			}catch(Exception e) {}
		}
		ftr.remove("ReportType");//#MVT00128 changes begins
        JsonObject completedThreads = new JsonObject();
        threadCount = threadCount + 1;
        completedThreads.addProperty("CompletedThreads", threadCount);
        db$Ctrl.db$UpdateRowOperator("ICOR_M_EXIT_RISK_SCAN_LOG", gson.toJson(completedThreads), ftr, "true", "push");	//#MVT00038 changes

        projection = new JsonObject();
		projection.addProperty("_id", 0);
		ftr.addProperty("ScanId", scanId);
		JsonObject counts = db$Ctrl.db$GetRow("ICOR_M_EXIT_RISK_SCAN_LOG", ftr, projection);
		int count = counts.get("CompletedThreads").getAsJsonArray().size();
		if (count <= 9) {
            try {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
            }
        }
		if (count >= 10) {
			JsonObject status = new JsonObject();
			status.addProperty("CompletedTime", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			status.addProperty("Status","Completed");//#PAV00018 Changes
			db$Ctrl.db$UpdateRow("ICOR_M_EXIT_RISK_SCAN_LOG", status, ftr, "true");
			try {
				JsonObject isonMsg = new JsonObject();
				isonMsg.addProperty("scanId", scanId);
				reportsHandler(isonMsg, "RiskProfiling");
			} catch (Exception e) {
			}
			try { // #SRM00067 Changes start
            	String jobStatus =  status.get("Status").getAsString();
            	String dateforEmail = status.get("CompletedTime").getAsString();
                srvcFunction.jobEmailNotification("RiskProfiling", jobStatus, dateforEmail);
            } catch (Exception e) {
            	e.printStackTrace();
            } // #SRM00067 Changes end
			try {
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}//#MVT00057 ends

	//SRM00057 starts	
	public JsonObject backwardOperation(JsonObject isonMsg) {
		JsonObject i$body = i$ResM.getBody(isonMsg);
		try {
			JsonObject filter = new JsonObject();
			Gson gson = new Gson();
			JsonObject fltr = new JsonObject();
			JsonObject upObj = new JsonObject();
			JsonObject updateObj = new JsonObject();
			JsonObject imbpmJson = new JsonObject();
			JsonObject prevStageDetail = new JsonObject();
			String currentStage;
			JsonObject argJson = new JsonObject();
			String FwdOpr = null;
			JsonArray remarkArr = new JsonArray();
			JsonObject currObj = new JsonObject();
			JsonArray latestRemark = i$body.get("LatestRemarks").getAsJsonArray();
			if(i$ResM.getBody(isonMsg).has("LatestRemarks")) {
				remarkArr = i$ResM.getBody(isonMsg).get("LatestRemarks").getAsJsonArray();
			}
			filter.addProperty("applicationId", i$body.get("applicationId").getAsString());
			filter.addProperty("referenceNo", i$body.get("referenceNo").getAsString());
			argJson = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", filter);
			
			currentStage = argJson.get("CurrentTask").getAsString();
			
			if (I$utils.$iStrFuzzyMatch(currentStage, "2") || I$utils.$iStrFuzzyMatch(currentStage, "3")|| I$utils.$iStrFuzzyMatch(currentStage, "4")) {
				fltr.addProperty("WORKFLOWID", i$body.get("WorkFlowId").getAsString());
				imbpmJson = db$Ctrl.db$GetRow("ICOR_M_IM_BPM", fltr);
				
				JsonObject stage = imbpmJson.get("CONTROL_JSON").getAsJsonObject().get("STGLIFECYCLE").getAsJsonObject();
				String previousStage = stage.get(currentStage).getAsJsonObject().get("PREV_STG_NO").getAsString();
				JsonObject newCurrentObj = stage.get(previousStage).getAsJsonObject();				
				JsonObject newPreStg = stage.getAsJsonObject(newCurrentObj.get("PREV_STG_NO").getAsString());
				if (!I$utils.$iStrFuzzyMatch(newCurrentObj.get("PREV_STG_NO").getAsString(), "0")) {
					prevStageDetail.addProperty("Queue", I$MbpmContorller.getCurrQueue(newPreStg, FwdOpr));
					prevStageDetail.addProperty("CurrentTask", newPreStg.get("CURR_STG_NO").getAsString());
					prevStageDetail.addProperty("CurrentTskStage", newPreStg.get("CURR_STG_NO").getAsString());
					prevStageDetail.addProperty("CurrentStageName", newPreStg.get("STGNAME").getAsString());
					prevStageDetail.addProperty("NxtTskStage", newPreStg.get("NEXT_STG_NO").getAsString());
					prevStageDetail.addProperty("PreTskStage", newPreStg.get("PREV_STG_NO").getAsString());
					prevStageDetail.addProperty("NewTskStage", newPreStg.get("NEXT_STG_NO").getAsString());
					prevStageDetail.addProperty("ModifiedBy", IResManipulator.iloggedUser.get());
				}
			
				if (!I$utils.$isNull(imbpmJson)) {
					updateObj.addProperty("currStgNo", previousStage);
					updateObj.addProperty("WRK_FLW_STAGE", newCurrentObj.get("STGNAME").getAsString());
					updateObj.addProperty("WorkFlowStatus", newCurrentObj.get("STGNAME").getAsString());
					updateObj.add("WorkFlowLatestRemarks", latestRemark);
					upObj.addProperty("Queue",  I$MbpmContorller.getCurrQueue(newCurrentObj, FwdOpr));
					upObj.addProperty("CurrentTask", newCurrentObj.get("CURR_STG_NO").getAsString());
					upObj.addProperty("CurrentTskStage", newCurrentObj.get("CURR_STG_NO").getAsString());
					upObj.addProperty("CurrentStageName", newCurrentObj.get("STGNAME").getAsString());
					upObj.addProperty("NxtTskStage", newCurrentObj.get("NEXT_STG_NO").getAsString());
					upObj.addProperty("PreTskStage", newCurrentObj.get("PREV_STG_NO").getAsString());
					upObj.addProperty("TerminatedBy", IResManipulator.iloggedUser.get());
					upObj.add("prevStageDetail", prevStageDetail);
					
					for (int i = 0; i < remarkArr.size(); i++) {
						currObj.add("WorkFlowRemarks", remarkArr.get(i).getAsJsonObject());
						if (I$utils.$iStrFuzzyMatch(i$body.get("WorkFlowId").getAsString(), "IMPACTO_CIF_WFLW_NEW")) {
							db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_CIF_APPLICATION", gson.toJson(currObj), filter,
									"false", "push");
							db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION", updateObj, filter);
						} else if (I$utils.$iStrFuzzyMatch(i$body.get("WorkFlowId").getAsString(),
								"IMPACTO_LINCU_WORKFLOW")) {
							db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_LINCU_APPLICATION", gson.toJson(currObj), filter,
									"false", "push");
							db$Ctrl.db$UpdateRow("ICOR_C_B2U_LINCU_APPLICATION", updateObj, filter);
						}else if (I$utils.$iStrFuzzyMatch(i$body.get("WorkFlowId").getAsString(),
								"IMPACTO_CHERRY_PICKS_WORKFLOW")) {
							db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_FCIP_APPLICATION", gson.toJson(currObj), filter,
									"false", "push");
							db$Ctrl.db$UpdateRow("ICOR_C_B2U_FCIP_APPLICATION", updateObj, filter);
						}else if (I$utils.$iStrFuzzyMatch(i$body.get("WorkFlowId").getAsString(),
								"IMPACTO_FIP_WORKFLOW")) {
							db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_FIP_APPLICATION", gson.toJson(currObj), filter,
									"false", "push");
							db$Ctrl.db$UpdateRow("ICOR_C_B2U_FIP_APPLICATION", updateObj, filter);
						}else if (I$utils.$iStrFuzzyMatch(i$body.get("WorkFlowId").getAsString(),
								"IMPACTO_FIXED_DEPOSIT_WORKFLOW")) {
							db$Ctrl.db$UpdateRowOperator("ICOR_C_B2U_FD_APPLICATION", gson.toJson(currObj), filter,
									"false", "push");
							db$Ctrl.db$UpdateRow("ICOR_C_B2U_FD_APPLICATION", updateObj, filter);
						}
					}
					
					db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", upObj, filter);
					i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION SUCCESSFULLY REVERTED TO PREVIOUS STAGE");
					return isonMsg;
				}
			} else {
				i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "APPLICATION CANNOT BE REVERTED TO PREVIOUS STAGE");
				return isonMsg;
			}
		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO REVERT TO PREVIOUS STAGE");
		}
		return isonMsg;
	}	//SRM00057 ends
	
	// #SRM00008 changes start
	public JsonObject appSignature(JsonObject isonMsg) {
		try {
			JsonObject jBody = new JsonObject();
			JsonObject filter = new JsonObject();
			if (isonMsg.has("i-body")) {
				jBody = isonMsg.getAsJsonObject("i-body");
				JsonElement sign = jBody.get("signature");
				if(sign!=null) {
					db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION",filter,"true");
				}
			} 
		} catch (Exception e) {
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED TO UPDATE SIGNATURE");

		}
		return isonMsg;
	}  //#SRM00008 changes end
	// #SRM00077 changes start 
	public JsonObject reportQuery(JsonObject isonMsg) {
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		try {
			JsonObject filter =new JsonObject();
			JsonObject projection =new JsonObject();
			filter.add("schedulerId", ibody.get("schedulerId"));
			filter.add("ReportType", ibody.get("ReportType"));
			projection.addProperty("_id", 0);
			JsonObject Apl$Json = db$Ctrl.db$GetRow("ICOR_M_KYM_REPORT", filter, projection);
//			ibody.add("rowData", Apl$Json);// Thank you Sirma
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Apl$Json);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
					"Record Successfully Retrieved");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}// #SRM00077 changes end
	public JsonObject resetDocument(JsonObject isonMsg) {
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			String applicationId = ibody.get("applicationId").getAsString();
			JsonObject filter = new JsonObject();
			filter.addProperty("applicationId", applicationId);
			JsonObject updateObj = new JsonObject();
			updateObj.add("documents.documentDetails", new JsonArray());
			db$Ctrl.db$UpdateRow("ICOR_C_B2U_CIF_APPLICATION",updateObj,filter);
		}catch(Exception e) {
			
		}
		return isonMsg;
	}
	
	// #Va000027 Begins
	public void updateReferDcStatus(String sAppNumber, String Coll_Name) {
		// Change the rejected application queue so that application may not appear in
		// rejected list
		try {
			JsonObject jFlter = new JsonObject();
			jFlter.addProperty("applicationId", sAppNumber);
			JsonObject Apl$Json = new JsonObject();
			Apl$Json = db$Ctrl.db$GetRow(Coll_Name, jFlter);
			if (Apl$Json != null) {
				if (I$utils.$iStrFuzzyMatch(Apl$Json.get("DcStatus").getAsString(), "ReferDcIncomplete")) {
					jFlter.addProperty("referenceNo", Apl$Json.get("referenceNo").getAsString());
					JsonObject task$Json = db$Ctrl.db$GetRow("ICOR_IBM_PROCESS", jFlter);
					if (task$Json != null) {
						task$Json.addProperty("Queue", "ReferDcResubmit");
						db$Ctrl.db$UpdateRow("ICOR_IBM_PROCESS", task$Json, jFlter);

					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// #Va000027 Ends
	// #BVB00033 Ends

//Date Format Change 
// #00000013 ends
	public JsonObject dateFromatter(String date) {
		SimpleDateFormat dmyFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat cntDate = new SimpleDateFormat("yyyy-MM-dd");
		Date orDate;
		JsonObject retDate = new JsonObject();
		try {
			orDate = dmyFormat.parse(date);
			retDate = i$ResM.adddate(orDate);
			return retDate;
		} catch (Exception e) {
			return null;
		}

	}

	// Threading for calling IMBPM Controller // #BZ00002 change begins
	class imbpmFwdThread implements Runnable {
		private String message;
		JsonArray flght$Opr;
		JsonObject iosnMsg;
		JsonObject isonMapJson;
		JsonObject isonheader;

		public imbpmFwdThread(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
			this.message = "RUN";
			this.iosnMsg = isonMsg;
			this.isonMapJson = isonMapJson;
			this.isonheader = isonheader;

		}

		public void run() {
			logger.debug("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Thread starting");
			logger.debug(Thread.currentThread().getName() + " (Start) message = " + message);
			JsonObject i$res = mirrorController(iosnMsg, isonMapJson, isonheader);// call processmessage method that
																					// sleeps the
			// logger.debug("Thread Result" + i$res.toString());
			logger.debug(Thread.currentThread().getName() + " (End)");// prints thread name
		}

	}

	// #Va000029 change begins
	public JsonObject mirrorController(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {

		try {
			JsonObject Jbdy = new JsonObject();
			JsonObject jBody = new JsonObject();
			jBody = i$ResM.getBody(isonMsg);
			String sRef = null;
			String Coll_Name = "";
			String DcStatus = null;
			String ScrCtrlClass = null;
			String sAppNumber = null;

			JsonObject jFilter = new JsonObject();
			
			// Redirecting to Create KYC application workflow
			sRef = i$ResM.getBodyElementS(isonMsg, "referenceNo");
			sAppNumber = i$ResM.getBodyElementS(isonMsg, "applicationId");
			// DcStatus = i$ResM.getBodyElementS(isonMsg, "DcStatus");
			// update the referDc Applicaiton
			JsonObject i$wrkFlow = db$Ctrl.db$GetRow("ICOR_C_SCR_COLL_MAP",
					"{\"SCRID\":" + i$ResM.getScreenID(isonMsg) + "}", "{\"WORKFLOW\":1}");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "FwdOpr",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "WorkFlowId",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("WorkFlowId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "TaskStage",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("TaskStage").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "ReqKeyFld", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "screenid",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdScrId").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$ResM.getHeader(isonMsg), "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "operation",
					i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdSOpr").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "referenceNo", sRef);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "applicationId", sAppNumber);
			// #DVJ00032 Starts
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, Jbdy, "userId", 
					i$ResM.getBody(isonMsg).get("userId").getAsString());
			// #DVJ00032 Ends
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, Jbdy);
			// Fwd the Control to Workflow COntroller.
			ScrCtrlClass = i$wrkFlow.get("WORKFLOW").getAsJsonObject().get("FwdController").getAsString();
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsg, isonheader, isonMapJson);
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-ERR")) {
				if (i$ResM.getBodyElementS(result$, "errorMsg") != null) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "ERROR IN CALLING THE THE JAVA METHOD");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, jFilter);
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "JAVA METHOD CALLED SUCCESSFULLY");
				}
			} else {

				i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "APPLICATION UPDATED SUCCESSFULLY");
				return isonMsg;
			}

		} catch (Exception e) {
			return null;
		}
	}

	// #Va000029 change ends
	
	public void reportsHandler(JsonObject isonMsg, String ScanType) {
        try {
            final IPDFTextExtractor I$textExtr = new IPDFTextExtractor();
            String schedulerId = Im$utils.generateRandomString(20);
            String fYear = null;
            String pCode = null;
            Boolean pdfCreated=false;//#PAV00018 Changes
            String reportType = "";
                int date_1 = 0;
                int month = 0;
                int year = 0;
                try {
                    Calendar calendar = Calendar.getInstance();
                    date_1 = calendar.get(Calendar.DATE);
                    month = calendar.get(Calendar.MONTH) + 1;
                    year = calendar.get(Calendar.YEAR);

                    if (month <= 9) {
                        pCode = "M0" + month;
                    } else {
                        pCode = "M" + month;
                    }
                    fYear = "FY" + year;
                } catch (Exception e) {
                }
                JsonObject filter = new JsonObject();
                JsonParser parser = new JsonParser();
                JsonObject projection = new JsonObject();
                projection.addProperty("_id", 0);
                projection.addProperty("reportResults", 1);
                projection.addProperty("ReportType", 1);
                projection.addProperty("fileName", 1);
                projection.addProperty("CreatedAt", 1);//#PAV00016 Changes
                projection.addProperty("ScanId", 1);//#PAV00016 Changes
                projection.addProperty("headers", 1);//// SKG00038 changes
                String scanId = isonMsg.get("scanId").getAsString();
                filter.addProperty("ScanId", scanId);
                JsonArray reportsData = new JsonArray();
				if (I$utils.$iStrFuzzyMatch(ScanType, "RiskProfiling")) {
					 reportsData = db$Ctrl.db$GetRows("ICOR_M_RISK_REPORT", filter, projection);
				}
				if (I$utils.$iStrFuzzyMatch(ScanType, "KYM")) {
					 reportsData = db$Ctrl.db$GetRows("ICOR_M_KYM_REPORT", filter, projection);
				}
                String date = I$utils.$getISONowAm();
                JsonArray attachment = new JsonArray();
                JsonObject filert1Copy = new JsonObject();
                int size = reportsData.size();
                for (int j = 0; j < reportsData.size(); j++) {
                	JsonObject update$Data=new JsonObject();
                	JsonObject filter1 = new JsonObject();
                	String currentStatus="Failed";//#PAV00018 Changes
                    try {
                        JsonObject currentResult = reportsData.get(j).getAsJsonObject();
                        //String reportType = "";
                        Set < String > keyset = currentResult.keySet();
                        String strKey = null;
                        String fileName = null;
                        String base64Str = "";
                       // JsonObject filter1 = new JsonObject();
                        
                        JsonObject ibody = new JsonObject();
                        JsonArray arrKey = new JsonArray();
                        for (String key: keyset) {
//                            try {
                                try {
                                    strKey = currentResult.get(key).getAsString();
                                  if(I$utils.$iStrFuzzyMatch(key, "fileName")){
                                	  fileName = strKey;
                                  }
                                  else if(I$utils.$iStrFuzzyMatch(key, "ReportType")) {
                                	  reportType = strKey;
                                  }
//                                    continue;
                                } catch (Exception e) {
                                	if(I$utils.$iStrFuzzyMatch(key, "reportResults")){// SKG00038 changes
                                        arrKey = currentResult.get(key).getAsJsonArray();
                                	}
                                }
                            }
                                String columns = "['Sl.No',";
                                String columnNames = "['Sl.No',";
                                JsonObject funcData = new JsonObject();
                                JsonObject attachmentData = new JsonObject();
                                JsonArray clms = new JsonArray();
                                JsonArray columnName = new JsonArray();
                                if(arrKey.size() > 0) {
                                	for (int i = 0; i < 1; i++) {
                                        try {
                                            //	                                JsonArray dataObj = new JsonArray();
                                            //	                                JsonObject runningObj = new JsonObject();
                                            JsonObject runningObject = arrKey.get(i).getAsJsonObject();
                                            Set < String > keys = runningObject.keySet();
                                            int keysCount = 0;
                                            for (String key1: keys) {
                                                try {
                                                    //	                                        runningObj.addProperty(key1, runningObject.get(key1).getAsString());
                                                    //	                                        dataObj.add(runningObj);
                                                    if (keysCount == 0) {
                                                        columns = columns + "'" + key1 + "'";
                                                        columnNames = columnNames + "'" + key1 + "'";
                                                        keysCount++;
                                                    } else {
                                                        columns = columns + "," + "'" + key1 + "'";
                                                        columnNames = columnNames + "," + "'" + key1 + "'";
                                                    }

                                                } catch (Exception e) {}
                                            }
                                            columns = columns + "]";
                                            columnNames = columnNames + "]";
                                        } catch (Exception e) {}
                                    }
                                	 clms = parser.parse(columns).getAsJsonArray();
                                     columnName = parser.parse(columnNames).getAsJsonArray();
                                }
                             // SKG00038 starts 
                                else {
                                	
                                	 if(currentResult.has("headers") && currentResult.get("headers").getAsJsonArray().size() > 0) {
                                	for (int i = 0; i < 1; i++) {
                                        try {
                                            //	                                JsonArray dataObj = new JsonArray();
                                            //	                                JsonObject runningObj = new JsonObject();
                                            JsonObject runningObject = currentResult.get("headers").getAsJsonArray().get(i).getAsJsonObject();
                                            Set < String > keys = runningObject.keySet();
                                            int keysCount = 0;
                                            for (String key1: keys) {
                                                try {
                                                    //	                                        runningObj.addProperty(key1, runningObject.get(key1).getAsString());
                                                    //	                                        dataObj.add(runningObj);
                                                    if (keysCount == 0) {
                                                        columns = columns + "'" + key1 + "'";
                                                        columnNames = columnNames + "'" + key1 + "'";
                                                        keysCount++;
                                                    } else {
                                                        columns = columns + "," + "'" + key1 + "'";
                                                        columnNames = columnNames + "," + "'" + key1 + "'";
                                                    }

                                                } catch (Exception e) {}
                                            }
                                            columns = columns + "]";
                                            columnNames = columnNames + "]";
                                        } catch (Exception e) {}
                                    }
                                	 clms = parser.parse(columns).getAsJsonArray();
                                     columnName = parser.parse(columnNames).getAsJsonArray();
                                	 }
                                }
                             // SKG00038 end
                                funcData.add("columns", clms);
                                funcData.add("rowData", arrKey);
                                funcData.add("columnNames", columnName);
                                funcData.addProperty("noOfColumns", clms.size());
                                funcData.addProperty("fileName", fileName);
                                funcData.addProperty("ReportType", reportType);
                                ibody.add("i-body", funcData);
                                ibody = I$textExtr.generatePDFReport(ibody);
                                base64Str = ibody.get("i-body").getAsJsonObject().get("report").getAsString();
                                if(!I$utils.$iStrFuzzyMatch(base64Str,"null")) {//#PAV00018 Changes
                                	pdfCreated=true;
                                	currentStatus="Completed";
                                }
                                attachmentData.addProperty("docType", "application/pdf");
                                attachmentData.addProperty("fileName", fileName);
                                attachmentData.addProperty("template", base64Str);
                                attachment.add(attachmentData);
//                            } catch (Exception e) {}
//                      }
                        filter1.addProperty("ScanId", scanId);
                        filter1.addProperty("ReportType", reportType);
                      // JsonObject update$Data = new JsonObject();
                        
                        currentResult.remove("reportResults");//#PAV00016 Changes
                        update$Data = currentResult.deepCopy();//#PAV00016 Changes
                        
                        update$Data.add("completedAt", i$ResM.adddate(new Date()));
                        update$Data.addProperty("schedulerId", schedulerId);
                        update$Data.addProperty("financialYear", fYear);
                        update$Data.addProperty("periodCode", pCode);
                        update$Data.addProperty("template", base64Str);
                        update$Data.addProperty("Status", currentStatus);
						if (I$utils.$iStrFuzzyMatch(ScanType, "RiskProfiling")) {
	                        db$Ctrl.db$Remove("ICOR_M_RISK_REPORT", filter1);//#PAV00016 Changes
							JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", update$Data, filter1, "true");
						}
						if (I$utils.$iStrFuzzyMatch(ScanType, "KYM")) {
	                        db$Ctrl.db$Remove("ICOR_M_KYM_REPORT", filter1);//#PAV00016 Changes
							JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_KYM_REPORT", update$Data, filter1, "true");
						}
                    } catch (Exception e) {//#PAV00018 Changes
                    	update$Data.addProperty("Status", currentStatus);
                    	JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_KYM_REPORT", update$Data, filter1, "true");
                    }
                }
                JsonObject dataSetFilter = new JsonObject();
                JsonObject datasetProjection = new JsonObject();
                JsonObject emailDataset$Data = new JsonObject();
                String keyE = new String();
                String keyM = new String();
                JsonObject argJson = new JsonObject();
                dataSetFilter.addProperty("datasetId", "Dataset_5693");
                datasetProjection.addProperty("userDetails", 1);
                datasetProjection.addProperty("sendEmail", 1);
                datasetProjection.addProperty("sendSms", 1);
                emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
                if (!I$utils.$isNull(emailDataset$Data)) {
                    JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
                    boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
                    boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
                    for (int i1 = 0; i1 < userDet.size(); i1++) {
                        try {
                            if (sendEmail) {
                                JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
                                String Email = jsonObject.get("userEmailId").getAsString();
                                keyE = keyE.concat(Email);
                                if (i1 < userDet.size() - 1) {
                                    keyE = keyE.concat(",");
                                }
                            }
                            if (sendSMS) {
                                JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
                                String SMS = jsonObject.get("userMobileNo").getAsString();
                                keyM = keyM.concat(SMS);
                                if (i1 < userDet.size() - 1) {
                                    keyM = keyM.concat(",");
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        JsonObject map$Data = new JsonObject();
                        map$Data.addProperty("tmp$name", "TMPL#TT#MEMBERS#ALL#REPORT#MAIL");
                        argJson.add("map$Data", map$Data);
                        argJson.addProperty("key$Type", "notification");
                        argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
                        argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
                        argJson.add("attachment", attachment);
                        if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
                            JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
                            JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
                            JsonObject statusMsg = i$resE.get("i-stat").getAsJsonObject();
                            JsonObject filter2=new JsonObject();
                            filter2.addProperty("ScanId", scanId);
                            filter2.addProperty("ReportType", reportType);
                            	                    if (statusMsg.has("i-statMsg")) {//#PAV00018 Changes
                            	                        JsonObject update$Data = new JsonObject();
                            	                        update$Data.addProperty("reportsent", "true");
                            	                        update$Data.add("reportsentAT", i$ResM.addDateTime(new Date()));
                            	                        JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", update$Data, filter2, "true");
                            
                            	                    }
                        }
                    } catch (Exception e) {
                        logger.debug("Failed to send email and sms" + e.getMessage());
                    }
                } else {
                    logger.debug("Failed to find Email/Mobile for Alert.");
                }
            } catch (Exception e) {}
        }
	//SRI00015 starts
	public static JsonObject pCode$fYear() {
		JsonObject pCode$Object = new JsonObject();
		try {
			String fYear = null;
			String pCode = null;
			int date_1 = 0;
			int month = 0;
			int year = 0;
			try {
				Calendar calendar = Calendar.getInstance();
				date_1 = calendar.get(Calendar.DATE);
				month = calendar.get(Calendar.MONTH) + 1;
				year = calendar.get(Calendar.YEAR);
				if (month <= 9) {
					pCode = "M0" + month;
				} else {
					pCode = "M" + month;
				}
				fYear = "FY" + year;
			} catch (Exception e) {
				return null;
			}
			pCode$Object.addProperty("financialYear", fYear);
			pCode$Object.addProperty("periodCode", pCode);

		} catch (Exception e) {
			return null;
		}
		return pCode$Object;
	}//SRI00015 ends
	//MSA00080 starts
	public JsonObject noOfStagesNotify(JsonObject isonMsg) {
		try {
			String applid = i$ResM.getBodyElementS(isonMsg, "applicationId");
			JsonObject filter = new JsonObject();
			JsonObject proj = new JsonObject();
			String stgName = null;
			filter.addProperty("applicationId", applid);
			proj.addProperty("currStgNo", 1);
			proj.addProperty("totalOnBoardingStages", 1);
			JsonObject cifApplData = db$Ctrl.db$GetRow("ICOR_C_B2U_CIF_APPLICATION", filter, proj);
			int stgNo = cifApplData.get("currStgNo").getAsInt() + 1;
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", proj);
			if (stgNo == 1) {
				stgName = "Contact Info";
			} else if (stgNo == 2) {
				stgName = "Documents";
			} else if (stgNo == 3) {
				stgName = "Additional Details";
			} else if (stgNo == 4) {
				stgName = "Other Products";
			} else if (stgNo == 5) {
				stgName = "PEP/FATCA";
			} else if (stgNo == 6) {
				stgName = "PDF/Other Details";
			}
			int totalstg = cParam.get("totalOnBoardingStages").getAsInt();
			i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "You have completed " + stgNo + " (" + stgName + ") "+ "of the " + totalstg
					+ " pages necessary to complete your membership application. Please review and click 'Save and Continue' to pick up where you left off.");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return isonMsg;
	}//MSA00080 ends
	public IKYCController() {
		// Cons
	}
}
// #00000001 Ends 