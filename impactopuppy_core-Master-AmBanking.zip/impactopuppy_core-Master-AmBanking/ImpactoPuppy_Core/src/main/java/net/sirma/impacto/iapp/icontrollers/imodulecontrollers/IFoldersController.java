/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------    
      |3.2.5.446   | Pruthvi  	| Apr 27, 2020 | #YPR00014   | Initial Writing
      |1.0.8       | Pruthvi  	| Jul 04, 2020 | #YPR00034   | Added Validation for ProjectNames 
      |0.4 Beta    | Pruthvi  	| Jun 11, 2020 | #YPR00087   | Adding CRUD for IDocz Folders
      |0.4 Beta    | Tarun  	| Jun 22, 2021 | #TKS00001   | Added code for folderIdPath.
      |0.4 Beta    | Tarun  	| Jun 30, 2021 | #TKS00002   | Added function addFoldrAPI .
      |0.4 Beta    | Pruthvi	| Jul 15, 2021 | #YPR00099   | Added to IDocz DMS history logger.
      |0.4 Beta    | Tarun  	| Jul 29, 2021 | #TKS00006   | Added archive field in folders
      |0.4 Beta    | Tarun  	| Aug 04, 2021 | #TKS00007   | Added code to restrict folders with same name.
      |0.5 Beta    | Pruthvi  	| Sep 22, 2021 | #YPR00110   | Added changes to dynamically build the folders for KYC applications in DMS
      |0.5 Beta    | Tarun  	| Nov 02, 2021 | #TKS00008   | Added code to create country wise folders.
      |0.5 Beta    | Sushmita   | Nov 15, 2021 | #SKP00001   | Added code to create country wise folders in Post On-Boarding workspace
      |0.5 Beta    | Sushmita   | Dec 31, 2021 | #SKP00002   | Added changes for Post-Onboarding History
      |0.5 Beta    | Sindhu     | Dec 30, 2022 | #SRM00018   | Handled code for displaying one document data in favourites
      |0.5 Beta    | Sindhu     | Mar 30, 2023 | #SRM00032   | Handled code for getting restired documents in the response
      |0.5 Beta    | Sumit      | June 30,2023 |#SKG00013    | Changes for successful message after added folder
      |0.5 Beta    | Sumit      | Aug 04, 2023 |#SKG00018    |  Handled for after archive the folder again create  to same folder name
      |0.5 Beta    | Sumit      | Aug 08, 2023 |#SKG00019    |  Handled for delete documents of manual workspace is not reflecting in trash module 
      |0.5 Beta    | Sumit      | Aug 09, 2023 |#SKG00020    |  Handled for delete folder of manual workspace is not reflecting in trash module 
      |0.5 Beta    | karthik    | Aug 16, 2023 | #NK00001    | added code for bug no #9661
      |0.5 Beta    | Sumit      | Aug 17, 2023 |#SKG00021    |  Handled for delete folder of manual workspace is not remove from favorite module 
	  |0.5 Beta    | karthik    | Aug 18, 2023 | #NK00003    | Handled for delete folder of manual workspace is not remove from favorite module for multiple documents
	  |0.5 Beta    | karthik    | Nov 29, 2023 | #NK00067    | Added code for workspace filter
	  |0.5 Beta    | karthik    | Dec 01, 2023 | #NK00068    | Added validations for adding sub folder
	  |0.5 Beta    | karthik    | Dec 15, 2023 | #NK00069    | Added code for Restore folder
      ---------------------------------------------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder; // #MAQ00020 
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
//import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.iEmailService;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.IgenericWorker;

public class IFoldersController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IFoldersController.class);
	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033
	private IResPreFlightHandler i$resPre = new IResPreFlightHandler();

	// **********************************************************************//
	private IDataValidator I$DataValidator = new IDataValidator();
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private IgenericWorker igenericWorker = new IgenericWorker();
	private JsonObject i$Annotate = null;
//	private ISeqConsistencyController i$seqConsCtrl = new ISeqConsistencyController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private static final IDocumentsController IDoc$ctrl = new IDocumentsController();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		// JsonObject i$Annotate = null;
		String Coll_Name, L_Coll_Name;
//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonObject projection = new JsonObject();

		// #BVB00005 Starts
		JsonObject i$Match = i$ResM.getMatch(isonMsg);// #bvb Change to DB
		// #BVB00016 Starts
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();

		// #BVB00016 Ends

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);
		try {
			// #BVB00019 Starts
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;

			// #NYE00014 Rebuild IMatch if "dataSetFltr" Key is Present and Operation is
			// Summary
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {

				JsonObject j$DataFilter = get$FrmDataSetFilter(isonMsg);
				if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr"))) {

					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,j$DataFilter.get("Invalid$Expr").getAsString());
					return isonMsg;
				}
				// #NYE00015 Begin
				else if (j$DataFilter != null) {
					// Get Formated I-MATCH Dataset Filter
					i$Match = j$DataFilter;
				}
				// #NYE00015 End
			}
			// #NYE00014

			// if (db$Ctrl.db$hasRights(i$ResM.iloggedUser, ScrId, SOpr)) {
			if (hasRights) {

				// #BVB00019 Ends

				if (i$Match == null) {
					JsonArray i$MatchMap = i$ResM.getIMatch(isonMapJson);
					i$Match = new JsonObject();
					try {
						// if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						if (i$MatchMap.size() > 0 && (!I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "")
								&& !I$utils.$iStrFuzzyMatch(gson.toJson(i$ResM.getBody(isonMsg)), "{}") // #MAQ00001
						)) {

							for (int i = 0; i < i$MatchMap.size(); i++) {
								// #BVB00183 Starts
								JsonElement matchElm = i$ResM.getBodyElement(isonMsg, i$MatchMap.get(i).getAsString());
								if (!I$utils.$isNull(matchElm)) { // #BVB00188
									if (matchElm.isJsonPrimitive()) {
										i$Match.addProperty(i$MatchMap.get(i).getAsString(),
												i$ResM.getBodyElementS(isonMsg, i$MatchMap.get(i).getAsString()));
									} else if (matchElm.isJsonArray()) {
										JsonArray matchArr = matchElm.getAsJsonArray();
										String iMatchStr = "{'$in': ['";
										for (int j = 0; j < matchArr.size(); j++) {
											if (j < matchArr.size() - 1)
												iMatchStr = iMatchStr + matchArr.get(j).getAsString() + "','";
											else {
												iMatchStr = iMatchStr + matchArr.get(j).getAsString() + "']}";
											}
										}

										i$Match.add(i$MatchMap.get(i).getAsString(),parser.parse(iMatchStr).getAsJsonObject());

									}
									// #BVB00183 Ends
									// #BVB00188 Starts
								} else {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH");
									return isonMsg;
								}
								// #BVB00188 Ends
							}
							;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, i$Match);
						} else {
							i$Match = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}");
						}
					} catch (Exception e) {
						logger.error("Error description : ", e);
						i$Match = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_MATCH, "{}"); // #MAQ00001
					}
					;

				}
				;

				// #BVB00005 Ends
				// #BVB00016 Starts
				if (i$ProjectionArray != null) {
					for (int i = 0; i < i$ProjectionArray.size(); i++) {
						i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
					}
				} else {

					JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
					if (i$ProjectionMap != null) {// #BVB00033
						try {
							if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
								for (int i = 0; i < i$ProjectionMap.size(); i++) {
									i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
								}
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
							} else {
								i$Projection = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
							}
						} catch (Exception e) {
							e.printStackTrace();
							i$Projection = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
						}
						;
						// #BVB00033 Starts
					} else {
						i$Projection = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
					}
					// #BVB00033 Ends
					// i$Projection = new JsonObject();
				}
				// #BVB00016 Ends

				// #BVB00035 Starts
				projection = new JsonObject();
				projection.addProperty("privateKey", 1);
				JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
				String privateKey = cParam.get("privateKey").getAsString();
				JsonObject filter = new JsonObject();
				filter.addProperty("sessoinId", i$ResM.getClientSessionID(isonMsg));
				JsonObject sessionValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", gson.toJson(filter),
						gson.toJson(projection));

				// #BVB00035 Ends

				Integer i$MaxRow = -1;
				// #BVB00005 Starts
				JsonObject i$recordDetails = new JsonObject();
				JsonObject i$validateRes = new JsonObject();
				JsonObject i$ledgerCurVer = new JsonObject();
				// #BVB00005 Ends
				try {
					i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
				} catch (Exception e) {
					try {
						i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
					} catch (Exception ex) {
						i$MaxRow = -1;
					}
					;
				}
				;

				try {
					Coll_Name = isonMapJson.get("COLLNAME").getAsString();
				} catch (Exception e) {
					Coll_Name = null;
				}
				;

				if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
						|| (I$utils.$iStrBlank(gson.toJson(i$Match)))) { // #MAQ00003
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
					return isonMsg;
				}
				;

				try {
					L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
				} catch (Exception e) {
					L_Coll_Name = null;
				}
				;

				if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
					return isonMsg;
				}
				;

				try {
					// String ScrID = i$ResM.getScreenID(isonMsg); // #BVB00035
					String SOpr1 = i$ResM.getOpr1(isonMsg);
					String SOpr2 = i$ResM.getOpr2(isonMsg);
					String SOpr3 = i$ResM.getOpr3(isonMsg);
					// #MAQ00002 start
					try {
						i$body = isonMsg.getAsJsonObject("i-body");
					} catch (Exception e) {
						i$body = null;
					}
					// #MAQ00002 end

					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}"); // #BVB00035 changes ScrID to ScrId
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;

					} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						// Forwarding Request to DB Handler for SUMMARY
						logger.debug("Forwarding Request to DB Controller for Summary");
						// #MAQ00002 start
						isonMsg.add("i-body", i$body);
						int intPgNo, intRecs;
						try {
							intPgNo = i$body.get("intPgNo").getAsInt();
						} catch (Exception e) {
							intPgNo = 0;
						}
						try {
							intRecs = i$body.get("intRecs").getAsInt();
						} catch (Exception e) {
							intRecs = 0;
						}
						// #MAQ00013 starts
						String sort = "";
						try {
							String sortField = i$body.get("sort").getAsString();
							sort = "{'" + sortField + "':1}";
						} catch (Exception e) {
							sort = "{'_id':-1}";
						}
						// #MAQ00013 starts

						// #MAQ00004 starts
						if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {

							// #MAQ00009 starts
							int iRowCnt = 0;
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
									}
									// Added
									// Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, "{\"isCurrVer\"=\"Y\"}"); // #BVB00016

								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null)
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
									// Added Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends
							// #MAQ00014 starts
						} else if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
							// #MAQ00009 starts
							int iRowCnt = 0;
							JsonObject db$res = null;

							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										JsonArray accWsArr = db$Ctrl.db$getDMSAccessWS();// #YPR00096 Changes
										//NK00067 starts
										i$Match.addProperty("isCurrVer", "Y");
										try {
											i$Match.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
										} catch (Exception e) {
											i$Match.add("workspaceId",parser.parse("{'$in':" + accWsArr + "}").getAsJsonObject());
										} //NK00067 ends
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,i$Projection, intPgNo, intRecs, sort);
									}
									// Added
									// Projection
									else {
										i$Match = new JsonObject();
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);// #BVB00016 Added
																						// Projection

									}
								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null) {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match,i$Projection, intPgNo, intRecs, sort);
										// Added Projection

									} else {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),i$Projection, intPgNo, intRecs, sort);

									}
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}

							i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
							i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends

						}
						// #MAQ00014 ends
						// #MAQ00004 ends
						else {
							// #MAQ00005 code starts
							if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
								if (i$Match != null) {
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort)); // #BVB00016
								}

								else {
									i$Match = new JsonObject();
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort));// #BVB00016 Added
																					// Projection
								}
							} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
									|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
								if (i$Match != null)
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
											intPgNo, intRecs, sort));// #BVB00016
																		// Added
																		// Projection
								else
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
											i$Projection, intPgNo, intRecs, sort));// #BVB00016

								// #MAQ00005 code ends
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
								return isonMsg;
							}
						}
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
						return isonMsg;
					}
					;
					I$DataValidator.$validate_isonAnnote(i$Annotate, i$body, ScrId, SOpr); // #BVB00035
					if (IDataValidator.i$AnnotRes.get().get("i-stat").getAsInt() > 0) {
						// #BVB00005 Starts
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$body", i$body);
						// Getting the validation data from DB
						// Getting data from Master
						JsonObject i$runningQuery = new JsonObject();
						JsonObject i$master = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						// #YPR00034 validation for names
//						if(I$utils.$iStrFuzzyMatch(ScrId, "OI5CRRPR") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")){
//						String filterQuery = "{'$and':[{'workspaceId':'"+i$body.get("workspaceId").getAsString()+"'},{'isCurrVer':'Y'},{'$or':["+i$runningQuery+",{'projectName':{'$regex' : '^"+i$body.get("projectName").getAsString()+"$','$options' : 'i'}}]}]}";
//						 i$master = db$Ctrl.db$GetRow(Coll_Name, filterQuery.toString());
//						}else {
						i$master = db$Ctrl.db$GetRow(Coll_Name, i$runningQuery.toString());
//						}
						if (i$master != null) {
							logger.debug("Master Records: " + i$master);
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									i$master);
						} else {
							i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$master",
									"{}");
						}
						// Getting all records of Ledger Except for Deleted Records
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						String ndD = "{\"$ne\":\"D\"}";
						i$runningQuery.add("recordStat", parser.parse(ndD).getAsJsonObject());
						JsonArray i$Ledger = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("Ledger Records: " + i$Ledger);
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$Ledger",
								i$Ledger);

						// Getting records with isCurrVer:
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("isCurrVer", "Y");
						JsonArray i$ledgerCurrVer = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerCurrVer: " + i$ledgerCurrVer + " Count: " + i$ledgerCurrVer.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerCurrVer",
								i$ledgerCurrVer);

						// Getting records of Un-Auth
						i$runningQuery = new JsonObject();
						i$runningQuery = i$Match.deepCopy();
						i$runningQuery.addProperty("authStat", "U");
						JsonArray i$ledgerUnAuth = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
						logger.debug("i$ledgerUnAuth: " + i$ledgerUnAuth + " Count: " + i$ledgerUnAuth.size());
						i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerUnAuth",
								i$ledgerUnAuth);

						i$validateRes = igenericWorker.validateRequest(SOpr, SOpr1, SOpr2, i$recordDetails); // #BVB00021
						if (i$validateRes.get("i-stat").getAsInt() > 0) {
							if (i$ledgerCurrVer.size() > 0)
								i$ledgerCurVer = i$ledgerCurrVer.get(0).getAsJsonObject();
							// #BVB00005 Ends
							// Forwarding Request to DB Handler for Insert
							if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
								try {
//									if(db$Ctrl.db$getIBorgRPAaccess(isonMsg,"Project")>=1) {//#YPR00016 for IBorgAccess
//										if(db$Ctrl.db$getIBorgScopeAccess(isonMsg)>=1){//#YPR00017 for ScopeAccess
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (!(I$utils.$iStrFuzzyMatch(i$body.get("workspaceId").getAsString(),
											i$body.get("parentFolderId").getAsString()))) {
										String subFold = i$body.get("folderName").getAsString();
										String parentFoldId = i$body.get("parentFolderId").getAsString();
										JsonObject filt = new JsonObject();
										filt.addProperty("folderId", parentFoldId);
										JsonObject parentFoldIdDetl = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", filt);
										// #NK00068 starts
//										if (!(I$utils.$iStrFuzzyMatch(parentFoldIdDetl.get("initiator").getAsString(),IResManipulator.iloggedUser.get())) && (I$utils.$iStrFuzzyMatch(i$body.get("workspaceId").getAsString(),"IWRKSP469371"))) {
//											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Only initiator can add sub folder");
//											return isonMsg;
//										} //NK00068 ends
										String parentFoldName = parentFoldIdDetl.get("folderName").getAsString();
										if (I$utils.$iStrFuzzyMatch(subFold, parentFoldName)) {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"Parent-FolderName and Sub-FolderName Can't be Same");
											return isonMsg;
										}
									}
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, in$ = null;
										// #TKS00001 starts
										JsonObject folderData = new JsonObject();
										JsonObject parentFilter = new JsonObject();
										int level = i$body.get("folderLevel").getAsInt();
										parentFilter.addProperty("folderId",i$body.get("parentFolderId").getAsString());
										String fldrFilter = "{'workspaceId':'" + i$body.get("workspaceId").getAsString() + "' , 'parentFolderId':'" + i$body.get("parentFolderId").getAsString() + "' , 'isCurrVer':'Y' , 'folderName':{'$regex':'" + i$body.get("folderName").getAsString() + "' , '$options':'i'} , 'folderLevel':" + level + "}";
										int fldrCount = db$Ctrl.db$GetCountI("ICOR_M_DMS_FOLDERS", fldrFilter);
										int archiveFldrCount = db$Ctrl.db$GetCountI("ICOR_M_DMS_ARCHIVES", fldrFilter);
										if (fldrCount > 0 || archiveFldrCount > 0) {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,"Folder name already exist in this folder level");
											return isonMsg;
										}
										String folderIdPath = "";
										if (level > 1) {
											folderData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", parentFilter);
											folderIdPath += folderData.get("folderIdPath").getAsString() + "/"+ i$body.get("folderId").getAsString();
										} else {
											folderIdPath += i$body.get("workspaceId").getAsString() + "/"+ i$body.get("folderId").getAsString();
										}
										
										i$body.addProperty("folderIdPath", folderIdPath);
										// #TKS00001 ends
										i$body.addProperty("isCurrVer", "Y");
										i$body.addProperty("Archive", "N");// #TKS00006 changes
										i$body.addProperty("authStat", "U");
										i$body.addProperty("recordStat", "O");
										i$body.addProperty("operation", SOpr.toUpperCase());
										i$body.addProperty("initiatedOnSrvDate", i$ResM.getOnlydate(new Date())); // Add Date
										i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
										// i$body.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$body.addProperty("authorizer", "");//#SKG00013 changes
										if (level > 1) 
											i$body.addProperty("errorMsg", "SubFolder Added Sucessfully Under " + folderData.get("folderName").getAsString());//#SKG00013 changes
										else
											i$body.addProperty("errorMsg", "Folder Added Sucessfully");// #SKG00013 changes
										i$body.addProperty("authorizedOnSrvDate", "");
										m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
										Integer MaxVer = 0;
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
											MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
										}
										;
										i$body.addProperty("verNo", MaxVer + 1);
										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
										i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);

										in$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029

										return in$;

										// #BVB00033 Starts
									
									} 
									else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
//									}else {
//										i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SCOPE ACCESS RESTRICTION - NO SCOPE ACCESS RIGHTS");
//										return isonMsg;
//									}
//								}else {
//									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
//									return isonMsg;
//								}

								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// Forwarding Request to DB Handler for UPDATE
							if (I$utils.$iStrFuzzyMatch(SOpr, "UPDATE")) {
								try {
//									if(db$Ctrl.db$getIBorgRPAaccess(isonMsg,"Project")>=1) {//#YPR00016 for IBorgAccess
									// if(db$Ctrl.db$getIBorgScopeAccess(isonMsg)>=1){//#YPR00017 for ScopeAccess
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										double i$pdMacroValue = 1; // BVB
										if (i$ledgerUnAuth.size() >= 0) {
											u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
													i$Match);
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {

												i$body.addProperty("isCurrVer", "Y");
												i$body.addProperty("authStat", "U");
												i$body.addProperty("recordStat", "O");
												i$body.addProperty("operation", SOpr.toUpperCase());
												i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
												i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
												i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
												// i$body.addProperty("acquiredBy", i$ResM.iloggedUser);
												i$body.addProperty("acquiredBy", "");
												i$body.addProperty("authorizer", "");
												i$body.addProperty("errorMsg", "Record Sucessfully Updated");
												i$body.addProperty("authorizedOnSrvDate", "");
												m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
												Integer MaxVer = 0;
												if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
													MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
												}
												;
												i$body.addProperty("verNo", MaxVer + 1);

												up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
												db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes
												// BVB Ends
												try {
													JsonObject recIdObject = new JsonObject();
													// #BVB00167 Starts
													// if (i$master != null) {
													if (I$utils.$isNull(i$ledgerCurVer)) {
														recIdObject = i$master.getAsJsonObject("_id");
													} else {
														recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
													}
													;
													db$Ctrl.db$ReleaseRow(recIdObject);

													// Release Lock
												} catch (Exception ex) {
													// Eat Up
												}
												;

												// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
												return up$;

											} else {
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
														"OPERATION FAILED #LUP0001");
												return isonMsg;
											}

										} else {

											i$ledgerCurVer = i$body.deepCopy();

											i$ledgerCurVer.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add
																													// Date
											i$ledgerCurVer.addProperty("acquiredBy", "");
											i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Updated");

											i$ledgerCurVer.remove("_id");
											i$runningQuery = new JsonObject();

											i$runningQuery = i$Match.deepCopy();
											i$runningQuery.addProperty("isCurrVer", "Y");

											// up$ = db$Ctrl.db$UpdateRow(L_Coll_Name,isonMsg, i$ledgerCurVer,
											// i$runningQuery);
											up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer,
													i$runningQuery); // #BVB00029
											db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes
											try {
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												// JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;

											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;

										}
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
//									}else {
//										i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SCOPE ACCESS RESTRICTION - NO SCOPE ACCESS RIGHTS");
//										return isonMsg;
//									}
//								}else {
//									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
//									return isonMsg;
//								}
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00005 Starts
							// Forwarding Request to DB Handler for AUTH
							if (I$utils.$iStrFuzzyMatch(SOpr, "AUTH")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$recordDetails",
											i$recordDetails);
									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$ledgerCurVer = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;

										i$ledgerCurVer.addProperty("authStat", "A");
										// i$ledgerCurVer.addProperty("recordStat", "O");
										i$ledgerCurVer.addProperty("remarks",
												i$ResM.getBodyElementS(isonMsg, "remarks"));
										i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
										i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
										i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date())); // Add
																												// Date
										// i$ledgerCurVer.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Authorized");

										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											// JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;

										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();

										i$runningQuery = i$Match.deepCopy();
										i$runningQuery.addProperty("isCurrVer", "Y");

										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, i$ledgerCurVer, i$runningQuery);
										i$ledgerCurVer.remove("isCurrVer");
										// Updating/ Inserting data to Master
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();

										up$ = db$Ctrl.db$UpdateRow(Coll_Name, isonMsg, i$ledgerCurVer, i$runningQuery,
												"true"); // #BVB00029

										return up$;

										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for CLOSE
							if (I$utils.$iStrFuzzyMatch(SOpr, "CLOSE")) {
								try {
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}", i$Match);
										if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate), i$ResM.I_SUCC)) {
											i$body.addProperty("isCurrVer", "Y");
											i$body.addProperty("authStat", "U");
											i$body.addProperty("recordStat", "C");
											i$body.addProperty("operation", SOpr.toUpperCase());
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.add("initiatedOnSrvDate", i$ResM.adddate(new Date())); // Add Date
											i$body.addProperty("initiator", IResManipulator.iloggedUser.get());
											i$body.addProperty("acquiredBy", IResManipulator.iloggedUser.get());
											i$body.addProperty("authorizer", "");
											i$body.addProperty("errorMsg", "Record Sucessfully Closed");
											i$body.addProperty("authorizedOnSrvDate", "");
											m$x = db$Ctrl.db$GetTopRow(L_Coll_Name, i$Match, "verNo");
											Integer MaxVer = 0;
											if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(m$x), i$ResM.I_SUCC)) {
												MaxVer = db$Ctrl.db$GetColI(m$x, "verNo");
											}
											;
											i$body.addProperty("verNo", MaxVer + 1);
											// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
											up$ = db$Ctrl.db$InsertRow(L_Coll_Name, isonMsg, i$body); // #BVB00029
											try {
												JsonObject recIdObject = new JsonObject();
												// if (i$master != null) {
												if (I$utils.$isNull(i$ledgerCurVer)) {
													recIdObject = i$master.getAsJsonObject("_id");
												} else {
													recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
												}
												;
												// JsonObject re$ = i$releaseLock(recIdObject);
												db$Ctrl.db$ReleaseRow(recIdObject);
												// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
												// //
												// Release Lock
											} catch (Exception ex) {
												// Eat Up
											}
											;
											// db$Ctrl.db$ReleaseRow(db$Ctrl.db$GetColS(m$x, "_id"));
											return up$;
										} else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
													"OPERATION FAILED #LUP0001");
											return isonMsg;
										}
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;

							// Forwarding Request to DB Handler for DELETE
							if (I$utils.$iStrFuzzyMatch(SOpr, "DELETE")) {
								try {
//									if(db$Ctrl.db$getIBorgRPAaccess(isonMsg,"Project")>=1) {//#YPR00016 for IBorgAccess
									// if(db$Ctrl.db$getIBorgScopeAccess(isonMsg)>=1){//#YPR00017 for ScopeAccess
									// #BVB00033 Starts
									JsonObject argJson = new JsonObject();
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "isonMsg", isonMsg);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i$Annotate", i$Annotate);
									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "privateKey", privateKey);

									argJson = i$ReqM.processMsg(argJson);
									// if (argJson != null) {
									isonMsg = argJson.getAsJsonObject("isonMsg");
									i$body = isonMsg.getAsJsonObject("i-body");
									if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC)) {
										// #BVB00033 Ends
										JsonObject u$pdate, m$x, up$ = null;
										/*
										 * u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"N\"}",
										 * i$Match); if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(u$pdate),
										 * i$ResM.I_SUCC)) {
										 */
										i$ledgerCurVer.addProperty("folderId", i$body.get("folderId").getAsString());
										i$ledgerCurVer.addProperty("isCurrVer", "N");
										i$ledgerCurVer.addProperty("recordStat", "D");
										i$ledgerCurVer.addProperty("operation", SOpr.toUpperCase());
										i$ledgerCurVer.addProperty("initiator", IResManipulator.iloggedUser.get());
										// i$ledgerCurVer.addProperty("acquiredBy", i$ResM.iloggedUser);
										i$ledgerCurVer.addProperty("acquiredBy", "");
										i$ledgerCurVer.addProperty("authorizer", IResManipulator.iloggedUser.get());
										i$ledgerCurVer.addProperty("errorMsg", "Record Sucessfully Deleted");
										i$ledgerCurVer.add("authorizedOnSrvDate", i$ResM.adddate(new Date()));
//										i$ledgerCurVer.addProperty("remarks",
//												i$ResM.getBodyElementS(isonMsg, "remarks"));

										// Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
                                 
										try {
											JsonObject recIdObject = new JsonObject();
											// if (i$master != null) {
											if (I$utils.$isNull(i$ledgerCurVer)) {
												recIdObject = i$master.getAsJsonObject("_id");
											} else {
												recIdObject = i$ledgerCurVer.getAsJsonObject("_id");
											}
											;
											// JsonObject re$ = i$releaseLock(recIdObject);
											db$Ctrl.db$ReleaseRow(recIdObject);
											// db$Ctrl.db$ReleaseRow(i$ResM.convertId(i$master.getAsJsonObject("_id")));
											// //
											// Release Lock
										} catch (Exception ex) {
											// Eat Up
										}
										;
										i$ledgerCurVer.remove("_id");
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();
//										//NK00001 starts //#NK00069 starts
//										JsonObject filt = new JsonObject();   
//										JsonObject res = new JsonObject();  
//										filt.addProperty("parentFolderId", i$body.get("folderId").getAsString());
//										filt.addProperty("Archive", "Y");
//										res = db$Ctrl.db$GetRow("ICOR_M_DMS_ARCHIVES", filt);
//										if (!I$utils.$isNull(res)) {
//											JsonObject i$Archive = new JsonObject();
//											i$Archive.addProperty("isCurrVer", "N");
//											i$Archive.addProperty("Archive", "N");
//											i$Archive.addProperty("FoldRestor", "Y");
//											up$ = db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES", i$Archive, filt);
//										}else {
//											JsonObject filts = new JsonObject();  
//											JsonObject result = new JsonObject();   
//											filts.addProperty("parentFolderName", i$body.get("folderId").getAsString());
//											filts.addProperty("Archive", "Y");
//											result = db$Ctrl.db$GetRow("ICOR_M_DMS_ARCHIVES", filts);
//											if (!I$utils.$isNull(result)) {
//												JsonObject i$Archive = new JsonObject();
//												i$Archive.addProperty("isCurrVer", "N");
//												i$Archive.addProperty("Archive", "N");
//												i$Archive.addProperty("FoldRestor", "Y");
//												up$ = db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES", i$Archive, filts);
//											}
//										}
										//NK00001 ends
										//SKG00021 starts changes
//										// #NK00003 starts
//											for (int i = 0; i<i$body.get("documents").getAsJsonArray().size(); i++) {
//												try {
//													JsonObject filt1 = new JsonObject();
//													filt1.addProperty("FileUrlToken", i$body.getAsJsonArray("documents").get(i).getAsJsonObject().get("FileUrlToken").getAsString());
//													filt1.addProperty("Favourites", "Y");
//													JsonObject res1 = db$Ctrl.db$GetRow("ICOR_M_DMS_FAVOURITE", filt1);
//													if (!I$utils.$isNull(res1)) {
//			                                        	JsonObject i$favourite = new JsonObject();
//			                                        	i$favourite.addProperty("isCurrVer", "N");
//			                                        	i$favourite.addProperty("Favourites", "N");
//			                                        	i$favourite.addProperty("FoldRestor", "Y");
//			                                            up$ = db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", i$favourite, filt1);
//			                                        }
//												}catch(Exception e) {
//												}
//											}
//										//#NK00003 ends
										String foldLevel = i$body.get("folderLevel").getAsString();
										String foldId = i$body.get("folderId").getAsString();
										JsonObject foldQ = new JsonObject();
										JsonObject foldP = new JsonObject();
										foldQ.addProperty("workspaceId", i$body.get("workspaceId").getAsString());
										if (I$utils.$iStrFuzzyMatch(foldLevel, "3")) {
											foldQ.addProperty("folders.folders.folders.folderId", foldId);
											foldP.addProperty("folders.folders.folders.$", 1);
											JsonObject FoldInfo = db$Ctrl.db$GetRow("ICOR_M_DMS_WORKSPACES", foldQ, foldP);
											JsonObject FoldtoRes = FoldInfo.get("folders").getAsJsonArray().get(0).getAsJsonObject().get("folders").getAsJsonArray().get(0).getAsJsonObject().get("folders").getAsJsonArray().get(0).getAsJsonObject();
											JsonObject FoldRes = db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS_RESTORE", FoldtoRes);
										} else if (I$utils.$iStrFuzzyMatch(foldLevel, "2")) {
											foldQ.addProperty("folders.folders.folderId", foldId);
											foldP.addProperty("folders.folders.$", 1);
											JsonObject FoldInfo = db$Ctrl.db$GetRow("ICOR_M_DMS_WORKSPACES", foldQ, foldP);
											JsonObject FoldtoRes = FoldInfo.get("folders").getAsJsonArray().get(0).getAsJsonObject().get("folders").getAsJsonArray().get(0).getAsJsonObject();
											JsonObject FoldRes = db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS_RESTORE", FoldtoRes);
										}else {
											foldQ.addProperty("folders.folderId", foldId);
											foldP.addProperty("folders.$", 1);
											JsonObject FoldInfo = db$Ctrl.db$GetRow("ICOR_M_DMS_WORKSPACES", foldQ, foldP);
											JsonObject FoldtoRes = FoldInfo.get("folders").getAsJsonArray().get(0).getAsJsonObject();
											JsonObject FoldRes = db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS_RESTORE", FoldtoRes);
										}
										JsonObject foldData = IDoc$ctrl.getFolderIds(isonMsg);
										JsonArray foldIDs = foldData.getAsJsonObject("i-body").get("FolderIDs").getAsJsonArray();
										for (int i = 0; i < foldIDs.size(); i++) {
											try {
												JsonObject filt1 = new JsonObject();
												filt1.addProperty("folderId", foldIDs.get(i).getAsString());
												filt1.addProperty("Favourites", "Y");
												JsonObject res1 = db$Ctrl.db$GetRow("ICOR_M_DMS_FAVOURITE", filt1);
												if (!I$utils.$isNull(res1)) {
													JsonObject i$favourite = new JsonObject();
													i$favourite.addProperty("isCurrVer", "N");
													i$favourite.addProperty("Favourites", "N");
													i$favourite.addProperty("FoldRestor", "Y");
													up$ = db$Ctrl.db$UpdateRow("ICOR_M_DMS_FAVOURITE", i$favourite,filt1);
												}
												
												JsonObject filt = new JsonObject();   
												JsonObject res = new JsonObject();  
												filt.addProperty("folderId", foldIDs.get(i).getAsString());
												filt.addProperty("Archive", "Y");
												filt.addProperty("isCurrVer", "Y");
												res = db$Ctrl.db$GetRow("ICOR_M_DMS_ARCHIVES", filt);
												if (!I$utils.$isNull(res)) {
													JsonObject i$Archive = new JsonObject();
													i$Archive.addProperty("isCurrVer", "N");
													i$Archive.addProperty("Archive", "N");
													i$Archive.addProperty("FoldRestor", "Y");
													up$ = db$Ctrl.db$UpdateRow("ICOR_M_DMS_ARCHIVES", i$Archive, filt);
												}
											} catch (Exception e) {
												e.printStackTrace();
												isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to delete the folder");
											}
										} //#NK00069 ends
                                        //SKG00021 end changes
										i$runningQuery.addProperty("isCurrVer", "Y");
										up$ = db$Ctrl.db$UpdateRow(L_Coll_Name, isonMsg, i$ledgerCurVer,
												i$runningQuery); // #BVB00029
										i$ResM.setGobalVals("delFldrFltr", i$runningQuery);// SKG00020 changes 
										db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes
										i$ledgerCurVer.remove("isCurrVer");
										i$runningQuery = new JsonObject();
										i$runningQuery = i$Match.deepCopy();
//										if (i$master != null) {
//											i$runningQuery.add("verNo", i$master.get("verNo"));
//											u$pdate = db$Ctrl.db$UpdateRow(L_Coll_Name, "{\"isCurrVer\"=\"Y\"}",
//													i$runningQuery);
//										}
										//SKG00019 starts
										try {
											up$.get("i-body").getAsJsonObject().addProperty("parentFolderId", i$body.get("parentFolderId").getAsString());
										}catch(Exception e) {
											
										}
										try {
											up$.get("i-body").getAsJsonObject().addProperty("workspaceId", i$body.get("workspaceId").getAsString());
										}catch(Exception e) {
											
										}
										try {
											up$.get("i-body").getAsJsonObject().addProperty("folderId", i$body.get("folderId").getAsString());
										}catch(Exception e) {
											
										}
										try {
											up$.get("i-body").getAsJsonObject().addProperty("folderLevel", i$body.get("folderLevel").getAsString());
										}catch(Exception e) {
											
										}
										try {
											up$.get("i-body").getAsJsonObject().addProperty("folderName", i$body.get("folderName").getAsString());
										}catch(Exception e) {
											
										}
										try {
											up$.get("i-body").getAsJsonObject().addProperty("containDocs", i$body.get("containDocs").getAsString());
										}catch(Exception e) {
											
										}//SKG00019 end
										return up$;
										/*
										 * } else { isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										 * "OPERATION FAILED #LUP0001"); return isonMsg; }
										 */
										// #BVB00033 Starts
									} else {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
												i$ResM.getMsgtext(isonMsg));
										return isonMsg;
									}
									// #BVB00033 Ends
//									}else {
//										i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SCOPE ACCESS RESTRICTION - NO SCOPE ACCESS RIGHTS");
//										return isonMsg;
//									}
//								}else {
//									i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
//									return isonMsg;
//								}

								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00027 Starts
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SOpr2, "")) {
								// #BVB00027 Ends
								try {
									JsonObject u$pdate, m$x, up$ = null;
									i$ledgerCurVer.addProperty("errorMsg", "Record Successfully Retrieved");
									JsonArray docs = i$ledgerCurVer.get("documents").getAsJsonArray();
									if (I$impactoUtil.existObjFromArrWithSearch(docs, "docDel", "Y")) {
										try {
											for (int i = 0; i < docs.size(); i++) {  //#SRM00032 Changes start
												JsonObject doc = new JsonObject();
												doc = docs.get(i).getAsJsonObject();
												if(doc.has("docDel") && I$utils.$iStrFuzzyMatch(doc.get("docDel").getAsString(),"Y")) {
													docs.remove(i);
												}
											}
										} catch (Exception e) {
											e.printStackTrace();
										} //#SRM00032 changes end
									}
									// #BVB00127 Starts
									if (!I$utils.$isNull(i$Projection)) {
										i$ledgerCurVer = I$impactoUtil.refineJsonObject(i$ledgerCurVer, i$Projection);
									}
									// #BVB00127 Ends
									isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
											i$ledgerCurVer);
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
											"Record Sucessfully Retrieved");
									return isonMsg;
								} catch (Exception e) {
									isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
									return isonMsg;
								}
							}
							;
							// #BVB00027 Starts
							// if (I$utils.$iStrFuzzyMatch(SOpr, "QUERYMASTER")) {
							if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYMASTER")) {
									// #BVB00027 Ends
									try {
										JsonObject u$pdate, m$x, up$ = null;

										if (!I$utils.$isNull(i$master)) { // #BVB00165
											i$master.addProperty("errorMsg", "Record Sucessfully Retrieved");
											// #BVB00127 Starts
											if (!I$utils.$isNull(i$Projection)) {
												i$master = I$impactoUtil.refineJsonObject(i$master, i$Projection);
											}
											// #BVB00127 Ends
											isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg,i$ResM.I_BDYTAG,i$master);
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Record Sucessfully Retrieved");
										}
										// #BVB00165 Starts
										else {
											isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "NO RECORDS FOUND");
										}
										// #BVB00165 Ends
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								// #BVB00119 Starts
								if (I$utils.$iStrFuzzyMatch(SOpr2, "QUERYACQ")) {
									logger.debug("Forwarding Request to DB Controller for Query Accquire");
									try {
										JsonObject u$pdate, ac$ = null;

										ac$ = db$Ctrl.db$AcqRow(L_Coll_Name, i$Match);
										;

										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
												i$ResM.getiStat(ac$));

										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
												i$ledgerCurVer);

										// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,"Record Sucessfully
										// Acquired");
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								;

								if (I$utils.$iStrFuzzyMatch(SOpr2, "RELEASELOCK")) {
									logger.debug("Forwarding Request to DB Controller for Query Accquire");
									try {
										JsonObject rl$ = new JsonObject();

										rl$ = db$Ctrl.db$ReleaseRowS(ScrId, i$Match, IResManipulator.iloggedUser.get());
										isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_STATTAG,
												i$ResM.getiStat(rl$));
										return isonMsg;
									} catch (Exception e) {
										isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
										return isonMsg;
									}
								}
								;
// #BVB00119 Ends
							}

							// #BVB00005 Ends
						} else {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									i$validateRes.get("i-Msg").getAsString());
							return isonMsg;
						}
						;

					} else {
						Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
								IDataValidator.i$AnnotRes.get().get("i-Msg").getAsString());
						return isonMsg;
					}

				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
							e.getMessage().toString());
					e.printStackTrace();
					return isonMsg;
				}
			} else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
				return isonMsg;
			}

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
	//#SRM00018 changes start
	public JsonObject favDocView(JsonObject isonMsg, JsonObject isonMapJson) {
        try {
        	String L_Coll_Name;
        	JsonObject i$runningQuery = new JsonObject();
			JsonObject i$Match = i$ResM.getMatch(isonMsg);
			JsonObject i$recordDetails = new JsonObject();
			String SOpr = i$ResM.getOpr(isonMsg);
			String SOpr1 = i$ResM.getOpr1(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			JsonObject i$Projection = new JsonObject();
			JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);

        	try {
				L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
			} catch (Exception e) {
				L_Coll_Name = null;
			}
			;
			if (i$ProjectionArray != null) {
				for (int i = 0; i < i$ProjectionArray.size(); i++) {
					i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
				}
			}
        	  i$runningQuery = new JsonObject();
              i$runningQuery = i$Match.deepCopy();
			  JsonObject i$validateRes = new JsonObject();
			  JsonObject i$ledgerCurVer = new JsonObject();
              i$runningQuery.addProperty("metadata.isCurrVer", "Y");
              JsonArray i$ledgerCurrVer = db$Ctrl.db$GetRows(L_Coll_Name, i$runningQuery.toString());
              logger.debug("i$ledgerCurrVer: " + i$ledgerCurrVer + " Count: " + i$ledgerCurrVer.size());
              i$recordDetails = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$recordDetails, "i$ledgerCurrVer",
                      i$ledgerCurrVer);
			  i$validateRes = igenericWorker.validateRequest(SOpr, SOpr1, SOpr2, i$recordDetails);
				if (i$validateRes.get("i-stat").getAsInt() > 0) {
					if (i$ledgerCurrVer.size() > 0)
						i$ledgerCurVer = i$ledgerCurrVer.get(0).getAsJsonObject();
					if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY") && I$utils.$iStrFuzzyMatch(SOpr2, "")) {
						try {
							i$ledgerCurVer.addProperty("errorMsg", "Record Successfully Retrieved");
							
							if (!I$utils.$isNull(i$Projection)) {
								i$ledgerCurVer = I$impactoUtil.refineJsonObject(i$ledgerCurVer, i$Projection);
							}
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
									i$ledgerCurVer);
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
									"Record Sucessfully Retrieved");
							return isonMsg;
						} catch (Exception e) {
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
							return isonMsg;
						}
					}
					;
				}
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isonMsg;
    }//#SRM00018 changes end
	// #TKS00002 starts
	public JsonObject addFoldrAPI(JsonObject isonMsg) {
		try {
//			String sSOpr = i$ResM.getSrvcopr(isonMsg);
//			String sSvr = i$ResM.getSrvcName(isonMsg);
			JsonObject folderData = new JsonObject();
			JsonArray documents = new JsonArray();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			// SKP00001 Starts
			Boolean cifCreated = false;
			String cifId = null;
			try {
				cifCreated = i$body.get("cifCreated").getAsBoolean();
				cifId = i$body.get("cifId").getAsString();
			} catch (Exception e) {
			}
			// SKP00001 Ends
			folderData.addProperty("roleOrUserType", "");
			// SKP00001 Starts
			if (cifCreated == true) {
				folderData.addProperty("workspaceId", "IWS10002");
			} else {
				folderData.addProperty("workspaceId", "IWS10001");
			}
			// SKP00001 Ends
			folderData.addProperty("scope", "Public");
			String folderId = "IFLD" + +I$utils.$igetRandonNum(99999999);
			i$body.addProperty("folderId", folderId);
			if (i$body.has("seqName")) {// #YPR00110 Starts
				if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(isonMsg), i$ResM.I_SUCC) && I$utils.$iStrFuzzyMatch(i$body.get("seqName").getAsString(), "SEQ#CIFAPPL")) {
//							&& I$utils.$iStrFuzzyMatch(sSvr, "ImpactoSeqService")) {
					// #TKS00008 starts
					String folderIdPath = "";
					String parentFolderId = "";
					String cntCode = "";
					try {
						cntCode = i$body.get("cntCode").getAsString();
					} catch (Exception e) {
					}
					if (I$utils.$iStrFuzzyMatch(cntCode, "CM")) {
						if (cifCreated == true) { // SKP00001 Changes
							folderIdPath = "IWS10002/IFLD10007";
							parentFolderId = "IFLD10007";
						} else {
							folderIdPath = "IWS10001/IFLD10002";
							parentFolderId = "IFLD10002";
						}
					} else if (I$utils.$iStrFuzzyMatch(cntCode, "GA")) {
						if (cifCreated == true) { // SKP00001 Changes
							folderIdPath = "IWS10002/IFLD10008";
							parentFolderId = "IFLD10008";
						} else {
							folderIdPath = "IWS10001/IFLD10003";
							parentFolderId = "IFLD10003";
						}
					} else if (I$utils.$iStrFuzzyMatch(cntCode, "KM")) {
						if (cifCreated == true) { // SKP00001 Changes
							folderIdPath = "IWS10002/IFLD10009";
							parentFolderId = "IFLD10009";
						} else {
							folderIdPath = "IWS10001/IFLD10004";
							parentFolderId = "IFLD10004";
						}
					} else if (I$utils.$iStrFuzzyMatch(cntCode, "ML")) {
						if (cifCreated == true) { // SKP00001 Changes
							folderIdPath = "IWS10002/IFLD10010";
							parentFolderId = "IFLD10010";
						} else {
							folderIdPath = "IWS10001/IFLD10005";
							parentFolderId = "IFLD10005";
						}
					} else {
						if (cifCreated == true) { // SKP00001 Changes
							folderIdPath = "IWS10002/IFLD10011";
							parentFolderId = "IFLD10011";
						} else {
							folderIdPath = "IWS10001/IFLD10006";
							parentFolderId = "IFLD10006";
						}
					}
					String seqNo = i$body.get("seqNo").getAsString();
					folderData.addProperty("folderId", folderId);
					folderData.addProperty("folderIdPath", folderIdPath);
					if (cifCreated == true) { // SKP00001 Changes
						folderData.addProperty("folderName", cifId);
					} else {
						folderData.addProperty("folderName", seqNo);
					}
					folderData.addProperty("folderDesc", seqNo);
					folderData.addProperty("folderLevel", 2);
					folderData.addProperty("parentFolderId", parentFolderId);
					JsonObject query = new JsonObject();
					JsonObject fldrData = new JsonObject();
					if (cifCreated == true) { // SKP00001 Changes
						query.addProperty("workspaceId", "IWS10002");
					} else {
						query.addProperty("workspaceId", "IWS10001");
					}
					query.addProperty("isCurrVer", "Y");
					fldrData.addProperty("folderId", folderId);
					if (cifCreated == true) { // SKP00001 Changes
						fldrData.addProperty("folderName", cifId);
					} else {
						fldrData.addProperty("folderName", seqNo);
					}
					if (cifCreated == true) { // SKP00001 Changes
						fldrData.addProperty("workspaceId", "IWS10002");
					} else {
						fldrData.addProperty("workspaceId", "IWS10001");
					}
					fldrData.addProperty("folderLevel", 2);
					fldrData.addProperty("DocContains", false);
					fldrData.add("folders", new JsonArray());
					String i$Doc = "{'$push':{'folders.$[i].folder':" + fldrData + "}}";
					String arrayFilters = "[{'i.folderId':'" + parentFolderId + "'}]";
					db$Ctrl.db$UpdateNestedArr("ICOR_M_DMS_FOLDERS", i$Doc, query, "false", "N", arrayFilters);
					// #TKS00008 ends
//				updateFilter.addProperty("folderId", folderId);
//				updateFilter.addProperty("folderName", i$body.get("seqNo").getAsString());
//				updateFilter.addProperty("workspaceId" , "IWS10001");
//				updateFilter.addProperty("folderLevel" , 1);
//				updateFilter.addProperty("containDocs", "false");
//				updateFilter.add("folders", new JsonArray());
				}
			} else {
				JsonObject applFldrFilter = new JsonObject();
				JsonObject proj = new JsonObject();
				applFldrFilter.addProperty("folderName", i$body.get("LinkedCustNo").getAsString());
				applFldrFilter.addProperty("isCurrVer", "Y");
				applFldrFilter.addProperty("workspaceId", "IWS10001");
				applFldrFilter.addProperty("parentFolderId", "IWS10001");
				applFldrFilter.addProperty("folderLevel", 1);
				proj.addProperty("folderId", 1);
				proj.addProperty("containDocs", 1);
				proj.addProperty("workspaceId", 1);
				proj.addProperty("parentFolderId", 1);
				proj.addProperty("folderLevel", 1);
				proj.addProperty("folderName", 1);
				proj.addProperty("folderIdPath", 1);
				JsonObject prntFoldrData = db$Ctrl.db$GetRow("ICOR_M_DMS_FOLDERS", applFldrFilter, proj);
				if (prntFoldrData == null) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID FOLDER DETAILS");
					return null;
				}
				String folderIdPath = prntFoldrData.get("folderIdPath").getAsString() + "/" + folderId;
				folderData.addProperty("folderId", folderId);
				folderData.addProperty("folderIdPath", folderIdPath);
				if (i$body.get("DocParentGrpID1").getAsString().toUpperCase().contains("PDF")) {
					folderData.addProperty("folderName", "Other PDFs");
					folderData.addProperty("folderDesc", "Other PDFs");
				} else {
					folderData.addProperty("folderName", i$body.get("DocParentGrpID1").getAsString());
					folderData.addProperty("folderDesc", i$body.get("DocParentGrpID1").getAsString());
				}
				folderData.addProperty("folderLevel", prntFoldrData.get("folderLevel").getAsInt() + 1);
				folderData.addProperty("parentFolderId", prntFoldrData.get("folderId").getAsString());
			}
			folderData.add("documents", documents);
			folderData.addProperty("containDocs", "false");
			folderData.addProperty("tranId", i$body.get("tranId").getAsString());
			folderData.add("allowed$Roles", new JsonArray());
			folderData.add("allowed$Users", new JsonArray());
			folderData.addProperty("isCurrVer", "Y");
			folderData.addProperty("authStat", "A");
			folderData.addProperty("operation", "CREATE");
			folderData.add("initiatedOnSrvDate", i$ResM.adddate(new Date()));
			folderData.addProperty("initiator", IResManipulator.iloggedUser.get());
			folderData.addProperty("errorMsg", "Record Sucessfully Saved through API");
			folderData.addProperty("verNo", 1);
			db$Ctrl.db$InsertRow("ICOR_M_DMS_FOLDERS", folderData);

//				JsonObject filter = new JsonObject();
//				filter.addProperty("workspaceId", "IWS10001");
//				filter.addProperty("isCurrVer" , "Y");
//				String i$Doc = "{'folders': " + updateFilter.getAsJsonObject() + "}";
//				db$Ctrl.db$UpdateRowOperator("ICOR_M_DMS_WORKSPACES", i$Doc, filter, "false","push");
			JsonObject wrkspcFldrDataJsonObject = new JsonObject();
			wrkspcFldrDataJsonObject.add("i-body", folderData);
			i$resPre.ODSCRRFL_CREATE(wrkspcFldrDataJsonObject);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			// #YPR00110 Ends
			// #SKP00002 Starts
			if (cifCreated == true) {
				JsonObject i$header = new JsonObject();
				i$header = isonMsg.get("i-header").getAsJsonObject();
				i$header.addProperty("screenid", "FDMFLUPD");
				i$body.addProperty("DMSLDOC", "Y");
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-header", i$header);
			} // #SKP00002 Ends
			i$resPre.createDmsHstRecs(isonMsg);
			db$Ctrl.db$logDmsHstry(isonMsg); // YPR00099 Changes
			return folderData;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// #TKS00002 ends
	// #BVB00033 Starts
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		// JsonObject argJson = new JsonObject();

		try {
			IFoldersController i$genAppCon = new IFoldersController();
			isonMsg = i$genAppCon.processMsgHandler(isonMsg, isonheader, isonMapJson);
			// Adding Pre Response Message Handler
			if (I$utils.$iStrFuzzyMatch(i$ResM.getScreenID(isonMsg), "ODSCRRFD")&& I$utils.$iStrFuzzyMatch(i$ResM.getOpr(isonMsg), "QUERY")) {
                return favDocView(isonMsg, isonMapJson);//#SRM00018 changes
            }
			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			// argJson = null;
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}

	// #NYE00014 Begins
	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg) {
		try {
			return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));

		} catch (Exception e) {
			logger.debug(" Error in get$FrmDataSetFilter -" + e.getMessage());
			return null;
		}
	}

	// #NYE00014 Ends

	// #BVB00033 Ends
	public IFoldersController() {
		// Cons
	}
}
// #00000001 Ends