/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Baz 		| Apr 23, 2019 | #00000001   | Initial writing
      |0.1 Beta    | Baz 		| May 10, 2019 | #00000002   | changed the DMS upload request
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.ihelpers;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.AcroFields.Item;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.codec.Base64;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IPDFPopulator {
	private Logger logger = LoggerFactory.getLogger(IPDFPopulator.class);
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();

	@SuppressWarnings("rawtypes")
	public String populatePdf(JsonObject pdfDetails, String appNumber, String fileName) {
		String fileUrlToken = null;
		try {

			JsonObject headerJson = new JsonObject();
			JsonObject isonMap = new JsonObject();
			// C:\Users\Xi Carbon\Desktop
			InputStream resourceStream = null;
			String custSigfileCnt = null;
			ArrayList<String> iKeys = new ArrayList<String>();
			Set<Entry<String, JsonElement>> keys = pdfDetails.entrySet();
			iKeys = getKeySet(pdfDetails);
			JsonObject pro$jction = new JsonObject();
			pro$jction.addProperty("fileDowLoadReq", "1");
			// get the File from DMS
			JsonObject arg$Json = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", pro$jction);

			String ScrCtrlCls = arg$Json.get("fileDowLoadReq").getAsJsonObject().get("Controller").getAsString();
			JsonObject fileuriBody = arg$Json.get("fileDowLoadReq").getAsJsonObject().get("IsonBody").getAsJsonObject();
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlCls);
			JsonObject resultf$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			resultf$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, fileuriBody, headerJson, isonMap);
			if (I$utils.$iStrFuzzyMatch(resultf$.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(),
					"i-SUCC")) {
				custSigfileCnt = resultf$.get("i-body").getAsJsonObject().get("FileContent").getAsString();
			} else {
				// pass Later we might return Ison Msg,
				// "FAILED AT RETRIEVING FILES FROM DMS EXC000000");
			}

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			// FileOutputStream os = new FileOutputStream(new File("C,
			// "50m-signedNaive.pdf"));

			PdfReader reader = new PdfReader(Base64.decode(custSigfileCnt));
			// file Token Url for the PDF 5cc0501b8a9ecb33b4f5a3cc
			PdfStamper stamp = new PdfStamper(reader, baos);
			AcroFields form = stamp.getAcroFields();

			@SuppressWarnings("unchecked")
			Map<String, Item> map = new HashMap();

			for (int i = 0; i < iKeys.size(); i++) {
				String key = iKeys.get(i);
				map = form.getFields();
				Iterator iterator = map.keySet().iterator();
				outerloop:

				while (iterator.hasNext()) {
//					logger.debug("Field is >>>" + iterator.next());
					String pdfFld = iterator.next().toString();

					String pdffd = pdfFld.replace(" ", "");
					if (iKeys.get(i).equalsIgnoreCase(pdffd)) {

						logger.debug("Field is >>>" + iterator.next());
						form.setField(pdfFld, pdfDetails.get(iKeys.get(i)).getAsString());
						break outerloop;
					}
				}
			}
			// close pdf stamper

			stamp.setFormFlattening(true);
			stamp.close();
			String Strbase64 = Base64.encodeBytes(baos.toByteArray());
			// Upload the PDF to dms and return fileurl token.
			pro$jction = new JsonObject();
			pro$jction.addProperty("fileUploadReq", "1");
			// get the File from DMS
			arg$Json = new JsonObject();
			arg$Json = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", pro$jction);

			String ScrCtrlClsUs = arg$Json.get("fileUploadReq").getAsJsonObject().get("Controller").getAsString();
			JsonObject fileuriUsBody = arg$Json.get("fileUploadReq").getAsJsonObject().get("IsonBody")
					.getAsJsonObject();
			Class<?> ctrlClassUs;

			JsonObject trnData = new JsonObject();
			// Forward the request to controller for downloading the file
			trnData = fileuriUsBody.get("i-body").getAsJsonObject();
			trnData.addProperty("I#FileData", Strbase64);

			// 00000002 begins

			trnData.addProperty("FileName", fileName);
			trnData.addProperty("tranId", appNumber);
			trnData.addProperty("DocNo", appNumber);
			// 00000002 Ends

			// trnData.addProperty("tranId", app$Json.get("referenceNo").getAsString());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, fileuriUsBody, i$ResM.I_BDYTAG, trnData); //
			// fileuriUsBody.add("i-body", trnData);
			ctrlClassUs = Class.forName(ScrCtrlClsUs);
			JsonObject resultfUs$ = null;
			Method ctrlUsFunc = null;
			ctrlUsFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrlUs$Caller = ctrlClassUs.newInstance();
			resultfUs$ = (JsonObject) ctrlUsFunc.invoke(ctrlUs$Caller, fileuriUsBody, headerJson, isonMap);
			if (I$utils.$iStrFuzzyMatch(resultfUs$.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(),
					"i-SUCC")) {
				fileUrlToken = resultfUs$.get("i-body").getAsJsonObject().get("FileUrlToken").getAsString();
				logger.debug(
						"################################################################################## FILE URL TOKEN");
				logger.debug("##################################################### " + fileUrlToken);
				return fileUrlToken;
			} else {
				// pass Later we might return Ison Msg,
				// "FAILED AT RETRIEVING FILES FROM DMS EXC000000");
			}
			return fileUrlToken;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return fileUrlToken;

	}

	// for getting the Keys of Json Object
	public ArrayList<String> getKeySet(JsonObject i$sonObject) {
		ArrayList<String> iQueus = new ArrayList<String>();
		try {
			Map<String, Object> attributes = new HashMap<String, Object>();
			Set<Entry<String, JsonElement>> entrySet = i$sonObject.entrySet();
			String strKey, strVal;
			for (Map.Entry<String, JsonElement> entry : entrySet) {

				iQueus.add(entry.getKey());

			}
			return iQueus;
		} catch (Exception e) {
			// nothing here
		}

		return iQueus;

	}

	public IPDFPopulator() {
		//super();
		// TODO Auto-generated constructor stub
	}

}
// #00000001 Ends