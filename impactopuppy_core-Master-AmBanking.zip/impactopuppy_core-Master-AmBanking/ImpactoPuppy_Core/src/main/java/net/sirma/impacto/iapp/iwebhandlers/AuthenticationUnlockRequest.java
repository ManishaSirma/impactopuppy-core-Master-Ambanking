 /*
----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.15      | Pavithra S | Sep 5, 2023  | #PAV00018   | New FieldS Addition in unlockAuth
*/

//#PAV00018 Changes Begins
package net.sirma.impacto.iapp.iwebhandlers;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthenticationUnlockRequest {

	@NotNull(message = "Please provide User ID")
    private String username;
	@NotNull(message = "Please provide Password")
    private String password;
    private String sessionID; 
  
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSessionID() {
		return sessionID;
	}
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
}// #PAV00018 Changes Ends
