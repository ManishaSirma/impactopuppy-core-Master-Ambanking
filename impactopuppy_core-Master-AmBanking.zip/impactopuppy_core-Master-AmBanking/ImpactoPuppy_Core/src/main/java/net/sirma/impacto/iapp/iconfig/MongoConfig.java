/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Sep 27, 2018 | #BVB00002   | Encryption and Decryption
      |0.1 Beta    | Piyush 	| Oct 16, 2018 | #PM000003   | Encoding Username and Password
      |0.2.1       | Niegil   	| Jan 25, 2019 | #NYE00044   | MongoConnIdleTime and MongoConnLifeTime loading not happening correctly
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iconfig;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.transaction.NoTransactionException;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;
import com.mongodb.TransactionOptions;
import com.mongodb.WriteConcern;
import com.mongodb.client.ClientSession;
import com.mongodb.client.MongoDatabase;

import net.sirma.impacto.iapp.ialgo.iDCryptor;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

import java.net.URLEncoder;

import javax.annotation.PreDestroy;

@Configuration
@Primary
@PropertySource("classpath:application.properties")
public class MongoConfig extends AbstractMongoConfiguration {
	private Logger logger = Logger.getLogger(MongoConfig.class);
	private Ioutils I$utils = new Ioutils();
	public static MongoClient mongo = null;
	static iDCryptor i$DCryptor = new iDCryptor(128, 1000);
	static MongoClientURI uri = null;
	public ClientSession session = null;
	static String DBServer;
	static String DBPort;
	static String DBName;
	// #BVB00002 Starts
	static String DBUser;
	static String DBPass;
	// #BVB00002 Ends

	public static MongoDatabase getMongoDB() {
		return mongo.getDatabase(DBName);
	}

	public static MongoClient getMongo() {
		return mongo;
	}

	@Override
	protected String getDatabaseName() {
		return DBName;
	}

	@SuppressWarnings({ "unused", "deprecation" })
	@Override
	public Mongo mongo() throws Exception {

		if (mongo == null) {
			logger.debug("Starting Mongo");
			System.out.println("Starting Mongo.class.New");
			DBServer = I$utils.$strValNullIf(PropLoader.env.getProperty("db.mongo.host"), "localhost");
			DBPort = I$utils.$strValNullIf(PropLoader.env.getProperty("db.mongo.port"), "27017");
			DBName = I$utils.$strValNullIf(PropLoader.env.getProperty("db.mongo.database"),
					"Impacto" + PropLoader.env.getProperty("MajorVersion"));
			MongoClientOptions.Builder options = MongoClientOptions.builder()
					.connectionsPerHost(I$utils.$intValNullIf(PropLoader.env.getProperty("MaxMongoPoolSize"), 200))
					.minConnectionsPerHost(I$utils.$intValNullIf(PropLoader.env.getProperty("MinMongoPoolSize"), 20))
					// #NYE00044 Starts
					/*
					 * .maxConnectionIdleTime(I$utils.$intValNullIf(PropLoader.env.getProperty(
					 * "MinMongoPoolSize"),(360 * 1_000)))
					 * .maxConnectionLifeTime(I$utils.$intValNullIf(PropLoader.env.getProperty(
					 * "MinMongoPoolSize"),(360 * 1_000))); ;
					 */
					.maxConnectionIdleTime(
							I$utils.$intValNullIf(PropLoader.env.getProperty("MongoConnIdleTime"), (360 * 1_000)))
					.maxConnectionLifeTime(
							I$utils.$intValNullIf(PropLoader.env.getProperty("MongoConnLifeTime"), (360 * 1_000)));
			;
			// #NYE00044 Ends

			String DBUName = I$utils.$strValNullIf(PropLoader.env.getProperty("db.mongo.user"), "~NONE~");
			logger.debug(DBUName);
			String DBPass = I$utils.$strValNullIf(PropLoader.env.getProperty("db.mongo.pass"), "~NONE~");
			
			

			// #BVB00002 Starts
			if (!I$utils.$iStrFuzzyMatch(DBUName, "~NONE~") && !I$utils.$iStrFuzzyMatch(DBPass, "~NONE~")) {
				ImpactoUtil impactoUtil = new ImpactoUtil();
				DBUName = impactoUtil.decrypt(DBUName);
				DBPass = impactoUtil.decrypt(DBPass);
			}
			// #BVB00002 Ends

			// Format :
			// mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]

			if (I$utils.$iStrFuzzyMatch(DBUName, "~NONE~"))
				uri = new MongoClientURI("mongodb://" + DBServer + ":" + DBPort + "/" + DBName, options);
			else {
				String Pkey = I$utils.$strValNullIf(PropLoader.env.getProperty("impacto.core.pkey"),
						"123421lksjdlfji92349902ljfklsdnsdjfe");
				// #PM000003 Starts
				// DBUName = (java.util.Base64.getDecoder().decode(DBUName)).toString();
				// DBPass = (java.util.Base64.getDecoder().decode(DBPass)).toString();
				// i$DCryptor.decrypt(DBUName.split("::")[1], DBUName.split("::")[0], Pkey,
				// DBUName.split("::")[2]);
				// i$DCryptor.decrypt(DBPass.split("::")[1], DBPass.split("::")[0], Pkey,
				// DBPass.split("::")[2]);
				// #PM000003 Ends
				//DBUName = URLEncoder.encode(DBUName, "UTF-8");
				// uri = new MongoClientURI("mongodb://"+DBUName+":"+DBPass+"@"+DBServer+":"+DBPort+"/"+DBName, options);

				DBUName = URLEncoder.encode(DBUName, "UTF-8");
				DBPass = URLEncoder.encode(DBPass, "UTF-8");
				if (DBServer.contains("cluster")){					
					uri = new MongoClientURI("mongodb+srv://" + DBUName + ":" + DBPass + "@" + DBServer + "/" + DBName, options);
					logger.debug(uri);
				} else {
					uri = new MongoClientURI("mongodb://" + DBUName + ":" + DBPass + "@" + DBServer + ":" + DBPort + "/" + DBName, options);
					logger.debug(uri);
				}
			}
			;

			logger.info("About to connect to MongoDB @ ");
			// logger.info("About to connect to MongoDB @ "+uri.toString());
			try {
				mongo = new MongoClient(uri);
				mongo.setWriteConcern(WriteConcern.ACKNOWLEDGED);
			} catch (MongoException ex) {
				logger.error("An error occoured when connecting to MongoDB", ex);
				ex.printStackTrace();
			} catch (Exception ex) {
				logger.error("An error occoured when connecting to MongoDB", ex);
				ex.printStackTrace();
			}
			// To be able to wait for confirmation after writing on the DB
			mongo.setWriteConcern(WriteConcern.ACKNOWLEDGED);
		}
		return mongo;
	}

	@Override
	protected String getMappingBasePackage() {
		return "net.sirma.impacto.iapp";
	}

	@PreDestroy
	public void MongoClose() {
		if (mongo != null)
			try {
				mongo.close();
				logger.info("Mongo Closed");
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	public ClientSession createSession() {
		session = mongo.startSession();
		session.startTransaction(TransactionOptions.builder().writeConcern(WriteConcern.MAJORITY).build());
		return session;

	}

	public ClientSession getSession() {
		return session;

	}

	public void commitSession() {
		try {
			session.commitTransaction();
			session.close();
			session= null; 
		} catch (MongoException | NoTransactionException e) {
			e.printStackTrace();
		}
	}

	public void abortSession() {
		try {
			session.abortTransaction();
			session.close();
			session= null; 
		} catch (MongoException | NoTransactionException e) {
			e.printStackTrace();
		}
	}

	public MongoConfig() {
		// Const
	}
}
//#00000001 Ends