/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Vijay 		| Mar 05, 2019 | #BVB00082   | Initial writing 
      ----------------------------------------------------------------------------------------------
      
*/
 
package net.sirma.impacto.iapp.icommunication.iemail;
 
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController; 
import net.sirma.impacto.iapp.iwebhandlers.ResponseWrapper;
 
@Controller
public class IEmailVerificator {

	public HttpStatus isonResHTPPStat = null; 
	private DBController db$Ctrl = new DBController(); 

	@RequestMapping(value = "/EmailVerify", method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper generateReport(HttpServletRequest request) {
		JsonObject filter = new JsonObject();
		JsonObject setter = new JsonObject();
		try { 
			JsonParser parser = new JsonParser();
			JsonObject isonBody = parser.parse(request.getReader()).getAsJsonObject();
			
			// Make the email valid in the object 
			String id = isonBody.get("id").getAsString();
			filter.addProperty("digiMEApplicationId", id);
 			
			setter.addProperty("digiMEContact.emailVerified", "Y");
			
			db$Ctrl.db$UpdateRow("ICOR_C_DIGIME_KYC", setter, filter);
			  
		} catch (Exception e) {
			isonResHTPPStat = HttpStatus.EXPECTATION_FAILED;
		}
		isonResHTPPStat = (isonResHTPPStat == null ? HttpStatus.OK : isonResHTPPStat);
		return new ResponseWrapper(null, isonResHTPPStat, null);

	}

}

// #BVB00082 Ends