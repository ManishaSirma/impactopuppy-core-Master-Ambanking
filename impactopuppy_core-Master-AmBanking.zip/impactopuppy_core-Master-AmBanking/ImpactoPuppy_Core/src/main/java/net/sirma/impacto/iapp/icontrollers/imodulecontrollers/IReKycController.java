/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.3.7       | Vijay 		| Apr 21, 2019 | #BVB00124   | Initial writing
      |0.3.7       | Vijay 		| Apr 21, 2019 | #BVB00144   | New functions to Query the ReKYC status
      |0.3.7       | Vijay 		| Apr 21, 2019 | #BVB00146   | Modifcation for Response object of Re-Kyc
      |0.3.16.327  | Bhuvi 		| Jul 25, 2019 | #BHUVI001   | Job for get Expired Document
	  |0.3.17      | Vijay 		| Aug 05, 2019 | #BVB00191   | ReKyc Flow change
	  |0.3.17      | Vijay 		| Aug 06,  2019| #BVB00194   | ReKYC New Flow
	  |0.4.2       | Vijay 		| Aug 31,  2019| #BVB00204   | Adding extrDocuments Object to response
	  |0.4.2       | Vijay 		| Sep 02,  2019| #BVB00206   | Employer Mobile details issue 
	  |2.3.1.408   | Syed 		| Oct 08,  2019| #MAQ00044   | Handling different KeyModes for CIF Query
	  |0.4.2       | Vijay 		| Oct 16,  2019| #BVB00213   | Spouse Name Parsing
	  |0.4.2       | Sindhu  	| Aug 03,  2023| #SRM00053   | Changes for validating the date of birth
	  |0.4.2       | Srikanth  	| Oct 25,  2023| #SRI00013   | Changes for validating the EmploymentType and Discriptioin
      ----------------------------------------------------------------------------------------------
      
*/  
// #BVB00124 Begins

package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IReKycController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private ISmsService I$ISmsService = new ISmsService();
	private IEmailService i$Email = new IEmailService();
	private ImpactoUtil I$Imputils = new ImpactoUtil();

	private static final Logger logger = LoggerFactory.getLogger(IReKycController.class);

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			logger.debug("Entered Processmsg of IReKycController");
			String SOpr = i$ResM.getOpr(isonMsg);
			String SOpr2 = i$ResM.getOpr2(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = doReKyc(isonMsg);
			}
			// #BVB00144 Starts
			else if (I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) {
				if (I$utils.$iStrFuzzyMatch(SOpr2, "VERIFY")) {
					isonMsg = verifyReKycReq(isonMsg);
				} else {
					isonMsg = getReKycDetails(isonMsg);
				}
				// #BVB00144 Ends
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
			logger.debug("Exiting Processmsg of IReKycController");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject doReKyc(JsonObject isonMsg) {
		logger.debug("Entered doReKYC of IReKycController");
		JsonObject filter = new JsonObject();
		String filterS = "";
		JsonObject projection = new JsonObject();
		JsonArray expiredPriCust = new JsonArray();
		try {
			// Get the records which are going to expire today
			filterS = "{$and : [{'cbsDetails.CIF_CREATION.CIF': {$nin: [null, ''] }}, { $or : [ {'personalInfo.priDocDOE_ISO': { $lte: ISODate('"
					+ i$ResM.getOnlydate(new Date()) + "')}}, {'personalInfo.secDocDOE_ISO': { $lte: ISODate('"
					+ i$ResM.getOnlydate(new Date()) + "')} }]} ] }";
			// filterS = "{'personalInfo.priDocDOE_ISO': {$lte: ISODate('" +
			// i$ResM.getOnlydate(new Date()) + "')}}";
//			projection.addProperty("personalInfo", 1);
//		
//			projection.addProperty("contactDetails.mobileNumber", 1);
//			projection.addProperty("cbsDetails.CIF_CREATION.CIF", 1);
//
//			projection.addProperty("documents", 1);

			int countOfExpDocs = db$Ctrl.db$GetCountIS("ICOR_C_B2U_CIF_APPLICATION", isonMsg, filterS);

			double i$noOfIter = Math.ceil(Double.valueOf(countOfExpDocs) / 100);

			for (int i = 0; i < i$noOfIter; i++) {
				expiredPriCust = db$Ctrl.db$GetSummRowsArray("ICOR_C_B2U_CIF_APPLICATION", isonMsg, filterS, projection,
						i, 100 * (i + 1), true);
				// Once received insert them into on collection
				for (int j = 0; j < expiredPriCust.size(); j++) {
					try {
						JsonObject i$runningObj = expiredPriCust.get(j).getAsJsonObject();
						String customerId = i$runningObj.getAsJsonObject("cbsDetails").getAsJsonObject("CIF_CREATION")
								.get("CIF").getAsString();
						// String customerId =
						// i$runningObj.get("cbsDetails.CIF_CREATION.CIF").getAsString();

						// get details of CIF from CIF_DATA
						filter = new JsonObject();
						filter.addProperty("CustomerId", customerId);
						JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter);

						i$runningObj.add("reportingDate", i$ResM.adddate(new Date()));
						i$runningObj.addProperty("remarks", "KYC Documents Expired");
						i$runningObj.add("expiredDocs", getExpiredDocumentList(i$runningObj));
						// i$runningObj.addProperty("cbsDetails.CIF_CREATION.CIF", customerId);
						// get personalInfo Object

						i$runningObj.getAsJsonObject("personalInfo").addProperty("sName",
								cifData.get("CustomerShortName").getAsString());
						filter = new JsonObject();
						filter.addProperty("contactDetails.emailId",
								i$runningObj.getAsJsonObject("contactDetails").get("emailId").getAsString());
						filter.addProperty("contactDetails.mobileNumber",
								i$runningObj.getAsJsonObject("contactDetails").get("mobileNumber").getAsString());

						i$runningObj.remove("_id");

						db$Ctrl.db$UpdateRow("ICOR_M_RE_KYC", i$runningObj, filter, "true");
					} catch (Exception e) {
						// eat up .. need to add logger table for this purpose
					}
				}

			}
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, expiredPriCust);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RE KYC Completed Successfully");
			logger.debug("Exiting doReKYC of IReKycController");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "RE KYC Failed during: ", e.getMessage());
		}
		return isonMsg;
	}

	// #BVB00144 Starts
	public JsonObject verifyReKycReq(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		try {
			// Get the mode and Key
			String mode = i$ResM.getBodyElementS(isonMsg, "mode"); // isonMsg.get("mode").getAsString();
			String key = i$ResM.getBodyElementS(isonMsg, "key"); // isonMsg.get("key").getAsString();

			// Check in CBS_CIF_DATA and get the record.
			if (I$utils.$iStrFuzzyMatch(mode, "CID")) {
				filter.addProperty("CustomerId", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CMB")) {
				filter.addProperty("CustomerMobileId", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CEM")) {
				filter.addProperty("CustomerEmailId", key);
			// MAQ00044 starts
			} else if (I$utils.$iStrFuzzyMatch(mode, "CNI")) {
				filter.addProperty("CustomerNationalId", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CPT")) {
				filter.addProperty("CustomerPassportNo", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CDL")) {
				filter.addProperty("CustomerDriversPermitNo", key);
			} // MAQ00044 ends

			projection.addProperty("CustomerId", 1);
			projection.addProperty("CustomerMobileId", 1);
			projection.addProperty("CustomerEmailId", 1);
			projection.addProperty("CustomerMobileIsdNo", 1);
			projection.addProperty("Mobileisddesc", 1);
			projection.addProperty("CustomerDobDate", 1); //#SRM00053 changes
			
  			projection.addProperty("CustomerFirstName", 1);
			projection.addProperty("CustomerMiddleName", 1);
			projection.addProperty("CustomerLastName", 1);

			JsonObject icorMCbsCif = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection); //#SRM00053 starts
			if (ibody.has("dob") && !I$utils.$iStrFuzzyMatch(icorMCbsCif.get("CustomerDobDate").getAsString(),
					ibody.get("dob").getAsString())) {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID DATE OF BIRTH");
				return isonMsg;
			} // #SRM00053 ends
			if (!I$utils.$isNull(icorMCbsCif)) {
				JsonObject contactDetails = new JsonObject();
				contactDetails.addProperty("emailId", icorMCbsCif.get("CustomerEmailId").getAsString());
				contactDetails.addProperty("mobileNumber", icorMCbsCif.get("CustomerMobileId").getAsString());
				contactDetails.addProperty("CIF", icorMCbsCif.get("CustomerId").getAsString());
				contactDetails.addProperty("mobileISD", icorMCbsCif.get("CustomerMobileIsdNo").getAsString());
				contactDetails.addProperty("mobileISDDesc", icorMCbsCif.get("Mobileisddesc").getAsString());
				JsonObject personalInfo = new JsonObject();

				personalInfo.addProperty("firstName", icorMCbsCif.get("CustomerFirstName").getAsString());
				personalInfo.addProperty("middleName", icorMCbsCif.get("CustomerMiddleName").getAsString());
				personalInfo.addProperty("lastName", icorMCbsCif.get("CustomerLastName").getAsString());
				personalInfo.addProperty("CustomerDobDate", icorMCbsCif.get("CustomerDobDate").getAsString());

				JsonObject icorMCif = new JsonObject();
				icorMCif.add("contactDetails", contactDetails);
				icorMCif.add("personalInfo", personalInfo);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icorMCif);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, i$ResM.I_CUSMEM + " Data Fetched Successfully");
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID "+i$ResM.I_CUSMEM +" DATA");
			}
//			// Add documents, PersonalInfo, Contact Details
//			if (I$utils.$iStrFuzzyMatch(mode, "CID")) {
//				filter.addProperty("cbsDetails.CIF_CREATION.CIF", key);
//			} else if (I$utils.$iStrFuzzyMatch(mode, "CMB")) {
//				filter.addProperty("contactDetails.mobileNumber", key);
//			} else if (I$utils.$iStrFuzzyMatch(mode, "CEM")) {
//				filter.addProperty("contactDetails.emailId", key);
//			}
//			projection.addProperty("contactDetails", 1);
//			projection.addProperty("personalInfo.firstName", 1);
//			projection.addProperty("personalInfo.middleName", 1);
//			projection.addProperty("personalInfo.lastName", 1);
//			JsonArray icroMReKyc = db$Ctrl.db$GetRows("ICOR_M_RE_KYC", filter, projection);
//			if (icroMReKyc.size() > 0) {
//				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
//						icroMReKyc.get(icroMReKyc.size() - 1).getAsJsonObject());
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "REKYC Required");
//			} else {
//				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, icroMReKyc);
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "REKYC Not Required Or Invlaid ID");
//			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED WITH ", e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject getReKycDetails(JsonObject isonMsg) {
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		try {
			String mode = i$ResM.getBodyElementS(isonMsg, "mode");
			String key = i$ResM.getBodyElementS(isonMsg, "key");

			if (I$utils.$iStrFuzzyMatch(mode, "CID")) {
				filter.addProperty("CustomerId", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CMB")) {
				filter.addProperty("CustomerMobileId", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CEM")) {
				filter.addProperty("CustomerEmailId", key);
			// MAQ00044 starts
			} else if (I$utils.$iStrFuzzyMatch(mode, "CNI")) {
				filter.addProperty("CustomerNationalId", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CPT")) {
				filter.addProperty("CustomerPassportNo", key);
			} else if (I$utils.$iStrFuzzyMatch(mode, "CDL")) {
				filter.addProperty("CustomerDriversPermitNo", key);
			} // MAQ00044 ends

//			projection.addProperty("CustomerId", 1);
//			projection.addProperty("CustomerMobileId", 1);
//			projection.addProperty("CustomerEmailId", 1);
//
//			projection.addProperty("CustomerFirstName", 1);
//			projection.addProperty("CustomerMiddleName", 1);
//			projection.addProperty("CustomerLastName", 1);

			JsonObject icorMCbsCif = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection);
			if (!I$utils.$isNull(icorMCbsCif)) {
				// #BVB00191 Starts
				JsonObject i$impObj = convertCBStoImpactoFormat(icorMCbsCif);
				if (!I$utils.$isNull(i$impObj)) {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$impObj);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,i$ResM.I_CUSMEM +  " Data Fetched Successfully");
				} else {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed During "+i$ResM.I_CUSMEM + " Data Fetching");
				}
				// #BVB00191 Ends
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID "+i$ResM.I_CUSMEMCAPS + " DATA");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "FAILED DURING "+i$ResM.I_CUSMEMCAPS + " DATA FETCHING");
		}

		return isonMsg;
	}

// #BVB00144 Ends

	// #BVB00191 Starts
	public JsonObject convertCBStoImpactoFormat(JsonObject CbsCif) {
		JsonObject i$impObj = new JsonObject();
		JsonObject contactDetails = new JsonObject();
		JsonObject employment = new JsonObject();
		JsonObject additionalDetails = new JsonObject();
		JsonObject personalInfo = new JsonObject();
		JsonObject fatcaDeclaration = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject documents = new JsonObject();
		JsonArray expriredDocs = new JsonArray();
		try {

			contactDetails.addProperty("geoLocationDesc", getDefaultValue("Geographic Location",i$ResM.getStrfromObj(CbsCif, "GeoLocationdesc"), i$ResM.getStrfromObj(CbsCif, "Geolocation")));;
			contactDetails.addProperty("branchDesc", i$ResM.getStrfromObj(CbsCif, "BranchName"));
			contactDetails.addProperty("mobileISDDesc", getDefaultValue("Mobile Number",i$ResM.getStrfromObj(CbsCif, "Mobileisddesc"),i$ResM.getStrfromObj(CbsCif, "CustomerMobileIsdNo")));
			contactDetails.addProperty("currency", i$ResM.getStrfromObj(CbsCif, "CustomerCurrency"));

			contactDetails.addProperty("openDt", I$Imputils
					.dateFormatter(i$ResM.getStrfromObj(CbsCif, "CifCreationDate"), "yyyy-MM-dd", "yyyy-MM-dd"));
			contactDetails.addProperty("emailId", i$ResM.getStrfromObj(CbsCif, "CustomerEmailId"));
			contactDetails.addProperty("branch", i$ResM.getStrfromObj(CbsCif, "CustomerBranch"));
			contactDetails.addProperty("geoLocation", i$ResM.getStrfromObj(CbsCif, "Geolocation"));
			contactDetails.addProperty("mobileISD", i$ResM.getStrfromObj(CbsCif, "CustomerMobileIsdNo"));
			contactDetails.addProperty("mobileNumber", i$ResM.getStrfromObj(CbsCif, "CustomerMobileId"));
			contactDetails.addProperty("language", i$ResM.getStrfromObj(CbsCif, "CustomerLanguage"));
			contactDetails.addProperty("CIF", i$ResM.getStrfromObj(CbsCif, "CustomerId"));

			employment.addProperty("sectorEmployedDesc", getDefaultValue("Sector Employed",i$ResM.getStrfromObj(CbsCif, "EmployerCategory"),i$ResM.getStrfromObj(CbsCif, "EmployerCategory")));
			employment.addProperty("employmentTypeDesc", getDefaultValue("Employment Type",i$ResM.getStrfromObj(CbsCif, "EmployerType"), "DEFAULT"));
			employment.addProperty("employerExtensionDesc", i$ResM.getStrfromObj(CbsCif, "Employerextensiondesc"));
			employment.addProperty("avgMonthlyIncomeDesc",i$ResM.getStrfromObj(CbsCif, "Avgmonthlyincomedesc"));
			employment.addProperty("employmentModeDesc", getDefaultValue("Employment Mode",i$ResM.getStrfromObj(CbsCif, "Employmentmodedesc"), "DEFAULT"));
			employment.addProperty("employerDesc",i$ResM.getStrfromObj(CbsCif, "CustomerEmployerDesc"));
			employment.addProperty("payFrequencyDesc", i$ResM.getStrfromObj(CbsCif, "Payfrequencydesc")); // Need to
																											// check
			employment.addProperty("employmentMode", i$ResM.getStrfromObj(CbsCif, "CustomerEmploymentType"));
			// employment.addProperty("accountFunded",
			// i$ResM.getStrfromObj(CbsCif,"CustomerLanguage"));
			// employment.addProperty("enterSourceAccountFunded",
			// i$ResM.getStrfromObj(CbsCif,"CustomerLanguage"));
			// employment.addProperty("purposeBusinessRelationship",
			// i$ResM.getStrfromObj(CbsCif,"CustomerLanguage"));
			employment.addProperty("employer", i$ResM.getStrfromObj(CbsCif, "CustomerCurrentEmployer"));
			employment.addProperty("employeeNo", i$ResM.getStrfromObj(CbsCif, "Employeeno"));
			employment.addProperty("joiningDate", I$Imputils
					.dateFormatter(i$ResM.getStrfromObj(CbsCif, "DateJoinedComp"), "yyyy-MM-dd", "yyyy-MM-dd"));
			employment.addProperty("empAdd1", i$ResM.getStrfromObj(CbsCif, "EAddress1"));
			employment.addProperty("empAdd2", i$ResM.getStrfromObj(CbsCif, "EAddress2"));
			employment.addProperty("payFrequency", i$ResM.getStrfromObj(CbsCif, "SalaryFreq"));
			employment.addProperty("avgMonthlyIncome", i$ResM.getStrfromObj(CbsCif, "Avgmonthlyincome"));
			employment.addProperty("sectorEmployed", i$ResM.getStrfromObj(CbsCif, "Sectoremployed"));
			employment.addProperty("employmentType", i$ResM.getStrfromObj(CbsCif, "Employmenttype"));
		    if(I$utils.$iStrBlank(employment.get("employmentType").getAsString()) || I$utils.$iStrBlank(employment.get("employmentTypeDesc").getAsString())) {  //SRI00013  Changes starts
		    	employment.addProperty("employmentType", "");
		    	employment.addProperty("employmentTypeDesc", "");
		    }						//SRI00013  Changes ends
			try {
				employment.addProperty("employerExtension", i$ResM.getStrfromObj(CbsCif, "ETelephone").substring(0, 4));
			} catch (Exception e) {
				employment.addProperty("employerExtension", i$ResM.getStrfromObj(CbsCif, "ETelephone"));
			}
			try {
				employment.addProperty("employerWorkPhoneNumber",
						i$ResM.getStrfromObj(CbsCif, "ETelephone").substring(4));
			} catch (Exception e) {
				employment.addProperty("employerWorkPhoneNumber", i$ResM.getStrfromObj(CbsCif, "ETelephone"));
			}
			employment.addProperty("officialEmailId", i$ResM.getStrfromObj(CbsCif, "EEmail"));
			employment.addProperty("empZipCode", i$ResM.getStrfromObj(CbsCif, "EmpPincode"));
			employment.addProperty("empfaxNo", i$ResM.getStrfromObj(CbsCif, "EFax"));
			employment.addProperty("occupation", i$ResM.getStrfromObj(CbsCif, "Occupation"));
			additionalDetails.addProperty("custCATDesc", getDefaultValue("Member Category",i$ResM.getStrfromObj(CbsCif, "CustomerCategoryDesc"), i$ResM.getStrfromObj(CbsCif, "CustomerCategory")));
			additionalDetails.addProperty("birthCountryDesc", getDefaultValue("Birth Country",i$ResM.getStrfromObj(CbsCif, "BirthCountryDesc"),i$ResM.getStrfromObj(CbsCif, "BirthCountry")));
			additionalDetails.addProperty("maritalStatusDesc",getDefaultValue("Marital Status", i$ResM.getStrfromObj(CbsCif, "Maritalstatusdesc"),i$ResM.getStrfromObj(CbsCif, "CustomerMaritalStatus") ));
			additionalDetails.addProperty("educationCodeDesc", getDefaultValue("Highest Level of Education",i$ResM.getStrfromObj(CbsCif, "EducationalLevel"), "DEFAULT"));
			additionalDetails.addProperty("tecuReferenceDesc", getDefaultValue("How did you hear about TECU?",i$ResM.getStrfromObj(CbsCif, "TecuRef"),i$ResM.getStrfromObj(CbsCif, "Tecureference")));
			additionalDetails.addProperty("methodOfCommunicationDesc",
					getDefaultValue("Preferred method of Communication",i$ResM.getStrfromObj(CbsCif, "Methodofcommunicationdesc"),i$ResM.getStrfromObj(CbsCif, "CustCommMode") ));
			additionalDetails.addProperty("interestedloanTypeDesc",
					i$ResM.getStrfromObj(CbsCif, "Interestedloantypedesc"));
			additionalDetails.addProperty("accountClassDesc", i$ResM.getStrfromObj(CbsCif, "Accountclassdesc"));
			additionalDetails.addProperty("acClassType", i$ResM.getStrfromObj(CbsCif, "Acclasstype"));
			additionalDetails.addProperty("homephoneExtensionDesc",
					i$ResM.getStrfromObj(CbsCif, "Homephoneextensiondesc"));
			additionalDetails.addProperty("spouseMobileNumberExtensionDesc",
					i$ResM.getStrfromObj(CbsCif, "Spousemobnumberextensiondesc"));
			additionalDetails.addProperty("relationshipDesc", i$ResM.getStrfromObj(CbsCif, "Relationshipdesc"));
			additionalDetails.addProperty("interestedloanType", i$ResM.getStrfromObj(CbsCif, "IntTypOfLoan"));
			additionalDetails.addProperty("guardianName", i$ResM.getStrfromObj(CbsCif, "Guardianname"));
			additionalDetails.addProperty("relationship", i$ResM.getStrfromObj(CbsCif, "Relationship"));
			additionalDetails.addProperty("custCAT", i$ResM.getStrfromObj(CbsCif, "CustomerCategory"));
			additionalDetails.addProperty("accountClass", i$ResM.getStrfromObj(CbsCif, "Accountclass"));
			additionalDetails.addProperty("motherMaidenName", i$ResM.getStrfromObj(CbsCif, "MotherMaidenName"));
			additionalDetails.addProperty("placeOfBirth", i$ResM.getStrfromObj(CbsCif, "PlaceOfBirth"));
			additionalDetails.addProperty("birthCountry", i$ResM.getStrfromObj(CbsCif, "BirthCountry"));
			additionalDetails.addProperty("faxNumber", i$ResM.getStrfromObj(CbsCif, "Fax"));
			// additionalDetails.addProperty("shareHolderCode",i$ResM.getStrfromObj(CbsCif,"CustomerCategoryDescription"));
			additionalDetails.addProperty("educationCode", i$ResM.getStrfromObj(CbsCif, "CustomerEduCode"));
			additionalDetails.addProperty("methodOfCommunication", i$ResM.getStrfromObj(CbsCif, "CustCommMode"));
			additionalDetails.addProperty("tecuReference", i$ResM.getStrfromObj(CbsCif, "Tecureference"));
			additionalDetails.addProperty("spouseMemberOfTecu", i$ResM.getStrfromObj(CbsCif, "SpouseMember"));
			additionalDetails.addProperty("maritalStatus", i$ResM.getStrfromObj(CbsCif, "CustomerMaritalStatus"));
			additionalDetails.addProperty("numberOfDependent", i$ResM.getStrfromObj(CbsCif, "CustomerDependentOthers"));
			additionalDetails.addProperty("numberOfChildren",
					i$ResM.getStrfromObj(CbsCif, "CustomerDependentChildren"));
			additionalDetails.addProperty("anyOtherCreditUnionMember",
					i$ResM.getStrfromObj(CbsCif, "Anyothercreditunionmember"));
			additionalDetails.addProperty("otherCreditUnionName", i$ResM.getStrfromObj(CbsCif, "Othercreditunionname"));
			additionalDetails.addProperty("spouseMemberNumber", i$ResM.getStrfromObj(CbsCif, "Spousemembernumber"));
			String spouseName = i$ResM.getStrfromObj(CbsCif, "SpouseName"); 
			spouseName = spouseName.replace(",", " ");
			spouseName = spouseName.replace("  ", " "); 
			
			String spouse[] = spouseName.split(" ", 2);
			if(spouse.length > 1) {
				additionalDetails.addProperty("spouseFirstName", spouse[0]);
				additionalDetails.addProperty("spouseSurName", spouse[1]);
			}else if(spouse.length == 1){
				additionalDetails.addProperty("spouseFirstName", spouse[0]);
				additionalDetails.addProperty("spouseSurName", "");
			}else {
				additionalDetails.addProperty("spouseFirstName", "");
				additionalDetails.addProperty("spouseSurName", "");
			}
			// additionalDetails.addProperty("spouseFirstName", i$ResM.getStrfromObj(CbsCif, "SpouseName"));
			// additionalDetails.addProperty("spouseSurName", i$ResM.getStrfromObj(CbsCif, "SpouseName"));
			// additionalDetails.addProperty("address2",i$ResM.getStrfromObj(CbsCif,"CustomerDependentChildren"));
			// additionalDetails.addProperty("address3",i$ResM.getStrfromObj(CbsCif,"CustomerDependentChildren"));
			// additionalDetails.addProperty("address4",i$ResM.getStrfromObj(CbsCif,"CustomerDependentChildren"));
			// additionalDetails.addProperty("pincode",i$ResM.getStrfromObj(CbsCif,"CustomerDependentChildren"));
			additionalDetails.addProperty("homephoneExtension", i$ResM.getStrfromObj(CbsCif, "HomeTelIsd"));
			additionalDetails.addProperty("homePhoneNumber", i$ResM.getStrfromObj(CbsCif, "HomeTelNo"));
			additionalDetails.addProperty("spouseMobileNumberExtension",
					i$ResM.getStrfromObj(CbsCif, "Spousemobilenumberextension"));
			additionalDetails.addProperty("spouseMobileNumber", i$ResM.getStrfromObj(CbsCif, "Spousemobilenumber"));
			additionalDetails.addProperty("interestedInLoan", i$ResM.getStrfromObj(CbsCif, "LoanSeekerFlag"));
			// additionalDetails.addProperty("requireLoanInNext6Month",i$ResM.getStrfromObj(CbsCif,"LoanSeekerFlag"));
			additionalDetails.addProperty("nationality", i$ResM.getStrfromObj(CbsCif, "CustomerNationality"));
			
			if(I$utils.$iStrFuzzyMatch(i$ResM.getStrfromObj(CbsCif, "CustomerNationality"), "TT"))
				{
				additionalDetails.addProperty("isNational", "Y");
				
				}
			
			personalInfo.addProperty("sName", i$ResM.getStrfromObj(CbsCif, "CustomerShortName"));
			personalInfo.addProperty("genderDesc", getDefaultValue("Gender",i$ResM.getStrfromObj(CbsCif, "Genderdesc"), i$ResM.getStrfromObj(CbsCif, "CustomerGender")));
			personalInfo.addProperty("prefixDesc", getDefaultValue("Prefix",i$ResM.getStrfromObj(CbsCif, "CustomerPrefix"), "DEFAULT"));
			personalInfo.addProperty("permAddCountryDesc", getDefaultValue("Perm Add Country",i$ResM.getStrfromObj(CbsCif, "PCountryDesc"),i$ResM.getStrfromObj(CbsCif, "PCountry")));
			personalInfo.addProperty("mailAddCountryDesc", getDefaultValue("Mail Add Country",i$ResM.getStrfromObj(CbsCif, "AddressForCorrCntryDesc"),i$ResM.getStrfromObj(CbsCif, "AddressForCorrCntry")));
			personalInfo.addProperty("firstName", i$ResM.getStrfromObj(CbsCif, "CustomerFirstName"));
			// personalInfo.addProperty("mailAddZipCode",i$ResM.getStrfromObj(CbsCif,"Mailaddzipcode"));
			// // Need to check
			// personalInfo.addProperty("mailAddCountry",i$ResM.getStrfromObj(CbsCif,"LoanSeekerFlag"));
			personalInfo.addProperty("mailAddCountry", i$ResM.getStrfromObj(CbsCif, "CustomerNationality"));
			personalInfo.addProperty("mailAddZipCode", i$ResM.getStrfromObj(CbsCif, "Mailaddzipcode"));
			personalInfo.addProperty("permAddZipCode", i$ResM.getStrfromObj(CbsCif, "Permaddzipcode"));
			personalInfo.addProperty("permAddCountry", i$ResM.getStrfromObj(CbsCif, "CustomerNationality"));
			personalInfo.addProperty("priDocName", i$ResM.getStrfromObj(CbsCif, "UniqueIdName"));
			personalInfo.addProperty("priDocId", i$ResM.getStrfromObj(CbsCif, "UniqueIdValue"));
			// personalInfo.addProperty("secDocName",i$ResM.getStrfromObj(CbsCif,"LoanSeekerFlag"));
			// personalInfo.addProperty("secDocID",i$ResM.getStrfromObj(CbsCif,"LoanSeekerFlag"));
			personalInfo.addProperty("gender", i$ResM.getStrfromObj(CbsCif, "CustomerGender"));
			personalInfo.addProperty("prefix", i$ResM.getStrfromObj(CbsCif, "CustomerPrefix"));
			personalInfo.addProperty("middleName", i$ResM.getStrfromObj(CbsCif, "CustomerMiddleName"));
			personalInfo.addProperty("lastName", i$ResM.getStrfromObj(CbsCif, "CustomerLastName"));
			personalInfo.addProperty("dob", I$Imputils.dateFormatter(i$ResM.getStrfromObj(CbsCif, "CustomerDobDate"),
					"yyyy-MM-dd", "yyyy-MM-dd"));
			personalInfo.addProperty("age", i$ResM.getStrfromObj(CbsCif, "CustomerAge"));
			personalInfo.addProperty("mailAddLine1", i$ResM.getStrfromObj(CbsCif, "AddressForCorrespondence1"));
			personalInfo.addProperty("mailAddLine2", i$ResM.getStrfromObj(CbsCif, "AddressForCorrespondence2"));
			personalInfo.addProperty("mailAddLine3", i$ResM.getStrfromObj(CbsCif, "AddressForCorrespondence3"));
			personalInfo.addProperty("mailAddLine4", i$ResM.getStrfromObj(CbsCif, "AddressForCorrespondence4"));

			personalInfo.addProperty("mailAddCity", i$ResM.getStrfromObj(CbsCif, "PAddress3"));
			personalInfo.addProperty("mailAddState", i$ResM.getStrfromObj(CbsCif, "PAddress3"));

			personalInfo.addProperty("permAddLine1", i$ResM.getStrfromObj(CbsCif, "PAddress1"));
			personalInfo.addProperty("permAddLine2", i$ResM.getStrfromObj(CbsCif, "PAddress2"));
			personalInfo.addProperty("permAddLine3", i$ResM.getStrfromObj(CbsCif, "PAddress3"));
			personalInfo.addProperty("permAddLine4", i$ResM.getStrfromObj(CbsCif, "PAddress4"));
			personalInfo.addProperty("permAddCity", i$ResM.getStrfromObj(CbsCif, "Permaddcity"));
			personalInfo.addProperty("permAddState", i$ResM.getStrfromObj(CbsCif, "Permaddstate"));
//			personalInfo.addProperty("priDocDOI",i$ResM.getStrfromObj(CbsCif,"PAddress3"));
//			personalInfo.addProperty("priDocDOE",i$ResM.getStrfromObj(CbsCif,"PAddress3"));
//			personalInfo.addProperty("secDocDOI",i$ResM.getStrfromObj(CbsCif,"PAddress3"));
//			personalInfo.addProperty("secDocDOE",i$ResM.getStrfromObj(CbsCif,"PAddress3"));
			personalInfo.addProperty("permAddLine3", i$ResM.getStrfromObj(CbsCif, "PAddress3"));

			// Get Documents from DOc tracker
			try {
				filter.addProperty("cif", CbsCif.get("CustomerId").getAsString());
				filter.addProperty("isCurrVer", "Y");
				projection.addProperty("documents", 1);
				projection.addProperty("primaryOCrResult", 1);
				projection.addProperty("secondaryOCRResult", 1);
				projection.addProperty("extraDocDetails", 1);
				projection.addProperty("utilityReq", 1);
				projection.addProperty("moreInfo", 1);
				projection.addProperty("fatcaDeclaration", 1);
				projection.addProperty("enhanced_due", 1);
				projection.addProperty("politicatalExposedDetailsDetails", 1);

				documents = db$Ctrl.db$GetRow("ICOR_M_B2U_DOC_TRACKER", filter, projection);
				// documents = documents.get("documents").getAsJsonObject();
				if (!I$utils.$isNull(documents.get("documents").getAsJsonObject())) {
					// #BVB00204 Starts
		            JsonArray documentDetailsArray = documents.get("documents").getAsJsonObject().getAsJsonArray("documentDetails");
					for (int i = 0; i < documentDetailsArray.size(); i++) {
						JsonObject documentObject = documentDetailsArray.get(i).getAsJsonObject();
						JsonObject sideObject = documentObject.getAsJsonArray("sides").get(0).getAsJsonObject();
						String fileUrlToken = sideObject.get("FileUrlToken").getAsString();
						if (fileUrlToken.length() < 35) {
							documentDetailsArray.remove(i);
							i--;
						}
					}
		            documents.add("documentDetails", documentDetailsArray);
					i$impObj.add("documents", i$ResM.getObjfromObj(documents, "documents"));
					i$impObj.add("primaryOCrResult", i$ResM.getObjfromObj(documents, "primaryOCrResult"));
					i$impObj.add("secondaryOCRResult", i$ResM.getObjfromObj(documents, "secondaryOCRResult"));
					i$impObj.add("extraDocDetails", i$ResM.getObjfromObj(documents, "extraDocDetails"));
					// #BVB00204 Ends
					i$impObj.addProperty("utilityReq", i$ResM.getStrfromObj(documents, "utilityReq"));
					i$impObj.add("moreInfo", i$ResM.getObjfromObj(documents, "moreInfo"));
					i$impObj.add("fatcaDeclaration", i$ResM.getObjfromObj(documents, "fatcaDeclaration"));
					i$impObj.add("enhanced_due", i$ResM.getObjfromObj(documents, "enhanced_due"));
					i$impObj.add("politicatalExposedDetailsDetails", i$ResM.getObjfromObj(documents, "politicatalExposedDetailsDetails"));
					
				} else {
					i$impObj.add("documents", new JsonObject());
					i$impObj.add("primaryOCrResult", new JsonObject());
					i$impObj.add("secondaryOCRResult", new JsonObject());
					i$impObj.add("extraDocDetails", new JsonObject()); // #BVB00204
					i$impObj.addProperty("utilityReq", "N");
					i$impObj.add("moreInfo", new JsonObject());
					i$impObj.add("fatcaDeclaration", new JsonObject());
					i$impObj.add("enhanced_due", new JsonObject());
					i$impObj.add("politicatalExposedDetailsDetails", new JsonObject());
					
				}
			} catch (Exception e) {

				i$impObj.add("documents", new JsonObject());
				i$impObj.add("primaryOCrResult", new JsonObject());
				i$impObj.add("secondaryOCRResult", new JsonObject());
				i$impObj.add("extraDocDetails", new JsonObject()); // #BVB00204
				i$impObj.addProperty("utilityReq", "N");
				i$impObj.add("moreInfo", new JsonObject());
				i$impObj.add("fatcaDeclaration", new JsonObject());
				i$impObj.add("enhanced_due", new JsonObject());
				i$impObj.add("politicatalExposedDetailsDetails", new JsonObject());
				
			}

			// Getting OCR results
			try {
				if (!I$utils.$isNull(documents)) {
					JsonArray documentDetails = documents.getAsJsonArray("documentDetails");
					JsonObject i$priObj = I$Imputils.objFromArrWithSearch(documentDetails, "idType", i$ResM.I_PRIDOC);
					JsonObject i$secObj = I$Imputils.objFromArrWithSearch(documentDetails, "idType", i$ResM.I_SECDOC);
					String priDocName = i$ResM.I_NATIONALID;
					String secDocName = i$ResM.I_DRIVERSPERMIT;
					try {
						priDocName = i$priObj.getAsJsonArray("sides").get(0).getAsJsonObject().get("docName")
								.getAsString();
					} catch (Exception e) {

					}
					try {
						secDocName = i$secObj.getAsJsonArray("sides").get(0).getAsJsonObject().get("docName")
								.getAsString();
					} catch (Exception e) {

					}
					personalInfo = buildCardDetails(CbsCif, personalInfo, priDocName, secDocName);

				} else {
					expriredDocs.add("P");
					expriredDocs.add("S");
				}
			} catch (Exception e) {

			}
			i$impObj.add("contactDetails", contactDetails);
			i$impObj.add("employment", employment);
			i$impObj.add("additionalDetails", additionalDetails);
			i$impObj.add("personalInfo", personalInfo);
			//i$impObj.add("fatcaDeclaration", fatcaDeclaration);
			if (expriredDocs.size() <= 0) {
				i$impObj.add("expiredDocs", getExpiredDocumentList(i$impObj));
			} else {
				i$impObj.add("expiredDocs", expriredDocs);
			}

		} catch (Exception e) {
			e.printStackTrace();
			i$impObj = null;
		}

		return i$impObj;
	}

	public JsonObject buildCardDetails(JsonObject CbsCif, JsonObject personalInfo, String priDocName,
			String secDocName) {
		try {

			personalInfo.addProperty("priDocName", priDocName);
			personalInfo.addProperty("secDocName", secDocName);
			if (I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_PASSPORT)) {
				personalInfo.addProperty("priDocId", CbsCif.get("CustomerPassportNo").getAsString());
				personalInfo.addProperty("priDocDOI",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("PassportIssueDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("priDocDOE",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("PassportExpiryDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("priIssCtry", CbsCif.get("PassportIssuedCountry").getAsString());

			} else if (I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_NATIONALID)) {
				personalInfo.addProperty("priDocId", CbsCif.get("CustomerNationalId").getAsString());
				personalInfo.addProperty("priDocDOI", I$Imputils.dateFormatter(
						I$Imputils.trimDate(CbsCif.get("PinIssDate").getAsString()), "yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("priDocDOE", I$Imputils.dateFormatter(
						I$Imputils.trimDate(CbsCif.get("PinExpDate").getAsString()), "yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("priIssCtry", CbsCif.get("IdIssCountry").getAsString());
			} else if (I$utils.$iStrFuzzyMatch(priDocName, i$ResM.I_DRIVERSPERMIT)) {
				personalInfo.addProperty("priDocId", CbsCif.get("CustomerDriversPermitNo").getAsString());
				personalInfo.addProperty("priDocDOI",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("CustomerDpIssueDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("priDocDOE",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("CustomerDpExpiryDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("priIssCtry", CbsCif.get("CustomerDpIssuedCountry").getAsString());
			}

			if (I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_PASSPORT)) {
				personalInfo.addProperty("secDocId", CbsCif.get("CustomerPassportNo").getAsString());
				personalInfo.addProperty("secDocDOI",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("PassportIssueDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("secDocDOE",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("PassportExpiryDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("secIssCtry", CbsCif.get("PassportIssuedCountry").getAsString());
			} else if (I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_NATIONALID)) {
				personalInfo.addProperty("secDocId", CbsCif.get("CustomerNationalId").getAsString());
				personalInfo.addProperty("secDocDOI", I$Imputils.dateFormatter(
						I$Imputils.trimDate(CbsCif.get("PinIssDate").getAsString()), "yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("secDocDOE", I$Imputils.dateFormatter(
						I$Imputils.trimDate(CbsCif.get("PinExpDate").getAsString()), "yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("secIssCtry", CbsCif.get("IdIssCountry").getAsString());
			} else if (I$utils.$iStrFuzzyMatch(secDocName, i$ResM.I_DRIVERSPERMIT)) {
				personalInfo.addProperty("secDocId", CbsCif.get("CustomerDriversPermitNo").getAsString());
				personalInfo.addProperty("secDocDOI",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("CustomerDpIssueDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("secDocDOE",
						I$Imputils.dateFormatter(I$Imputils.trimDate(CbsCif.get("CustomerDpExpiryDate").getAsString()),
								"yyyy-MM-dd", "yyyy-MM-dd"));
				personalInfo.addProperty("secIssCtry", CbsCif.get("CustomerDpIssuedCountry").getAsString());
			}

		} catch (Exception e) {
			personalInfo.addProperty("priDocName", "");
			personalInfo.addProperty("priDocId", "");
			personalInfo.addProperty("priDocDOI", "");
			personalInfo.addProperty("priDocDOE", "");
			personalInfo.addProperty("priIssCtry", "");

			personalInfo.addProperty("secDocName", "");
			personalInfo.addProperty("secDocId", "");
			personalInfo.addProperty("secDocDOI", "");
			personalInfo.addProperty("secDocDOE", "");
			personalInfo.addProperty("secIssCtry", "");
		}
		return personalInfo;
	}

	// #BVB00191 Ends

// #BVB00146 Starts 
	public JsonArray getExpiredDocumentList(JsonObject icorMReKyc) {
		JsonArray expiredDocs = new JsonArray();
		try {
			JsonObject personalInfo = icorMReKyc.getAsJsonObject("personalInfo");

			String priDocDOE = i$ResM.getStrfromObj(personalInfo, "priDocDOE");
			String secDocDOE = i$ResM.getStrfromObj(personalInfo, "secDocDOE");
			if (isDocExpired(priDocDOE)) {
				expiredDocs.add("P");
			}
			if (isDocExpired(secDocDOE) && !I$utils.$iStrFuzzyMatch(secDocDOE, "")) {
				expiredDocs.add("S");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return expiredDocs;
	}

	public boolean isDocExpired(String date) {
		boolean docExpired = false;
		try {
			String currDate = i$ResM.getOnlydate(new Date(), "yyyy-MM-dd");
			String date1 = I$Imputils.dateFormatter(date, "dd/MM/yyyy", "yyyy-MM-dd");
			if (!I$utils.$iStrFuzzyMatch(date1, "")) {
				date = date1;
			}
			if (I$utils.getDateDifference(currDate, I$Imputils.trimDate(date), "yyyy-MM-dd") <= 0) {
				docExpired = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			docExpired = true;
		}
		return docExpired;
	}

	// #BVB00146 Ends
	public IReKycController() {
		// constructor
	}

	// #BHUVI001 Starts
	public JsonObject DocExpired(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();

		int runEntriesCount = 0;
		int noOfThread = 5;
		JsonObject filter = new JsonObject();

		try {

			String collectionName = "ICOR_M_B2U_DOC_TRACKER";
			filter.addProperty("isCurrVer", "Y");
			try {
				runEntriesCount = db$Ctrl.db$GetCountI(collectionName, filter);
			} catch (Exception e) {
				runEntriesCount = 0;
			}
			double i$noOfIter = Double.valueOf(runEntriesCount) / noOfThread;
			i$noOfIter = Math.ceil(i$noOfIter);

			int i$noOfIterThread = (int) i$noOfIter;
			if (i$noOfIterThread < 1500) {
				noOfThread = 1;
				i$noOfIter = Double.valueOf(runEntriesCount);
				i$noOfIter = Math.ceil(i$noOfIter);
				i$noOfIterThread = (int) i$noOfIter;
			}
			argJson.addProperty("totalNumberOfThreads", noOfThread);

			Thread t = null;
			for (int i = 0; i < noOfThread; i++) {

				JsonObject jWrkArgs = new JsonObject();
				JsonObject jArgs = new JsonObject();

				jArgs.addProperty("noOfIter", i$noOfIterThread);
				jArgs.addProperty("threadCount", i);
				jArgs.addProperty("totalNumberOfThreads", noOfThread);
				String sUniqueId = I$Imputils.generateRandomKey();
				jArgs.addProperty("uniqueId", sUniqueId);
				jWrkArgs.add("isonMsg", jArgs.deepCopy());
				jWrkArgs.addProperty("clsName",
						"net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IReKycController");
				jWrkArgs.addProperty("funcName", "GetAllCif");

				IThreadController IThread$worker = new IThreadController(jWrkArgs);
				Thread thread = new Thread();
				thread = new Thread(IThread$worker);
				thread.start();
			}
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "KYC Expired Document Data Processed ");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					i$ResM.I_CUSMEM+ " Data Update failed with: " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject GetAllCif(JsonObject argJson) {

		JsonObject projection = new JsonObject();
		JsonArray runEntries = new JsonArray();
		JsonArray ExpiredDoc = new JsonArray();

		// String uniqueId = argJson.get("uniqueId").getAsInt();
		int totalNumberOfThreads = argJson.get("totalNumberOfThreads").getAsInt();

		int i$noOfIterThread = argJson.get("noOfIter").getAsInt();
		int threadCount = argJson.get("threadCount").getAsInt();

		try {
			String collectionName = "ICOR_M_B2U_DOC_TRACKER";
			double i$noOfIter = Double.valueOf(i$noOfIterThread) / 100;
			i$noOfIter = Math.ceil(i$noOfIter);

			for (int i = 0; i < i$noOfIter; i++) {
				projection.addProperty("personalInfo", 1);
				int skip = 100 * i;
				skip = skip + (i$noOfIterThread * threadCount);
				runEntries = db$Ctrl.db$GetSummRowsArray(collectionName, "{'isCurrVer':'Y'}", projection, skip, 100,
						"Y");
				int s = runEntries.size();
				for (int j = 0; j < runEntries.size(); j++) {

					JsonObject i$runningObj = runEntries.get(j).getAsJsonObject();
					JsonObject personalInfo = i$runningObj.getAsJsonObject("personalInfo");

					String priDocDOE = personalInfo.get("priDocDOE_ISO").getAsString();
					String secDocDOE = personalInfo.get("secDocDOE_ISO").getAsString();
					if (IsDocExpired(priDocDOE, argJson)) {
						String docName = personalInfo.get("priDocName").getAsString();
						sendNotification(i$runningObj, docName, argJson);
					}
					if (IsDocExpired(secDocDOE, argJson)) {
						String docName = personalInfo.get("secDocName").getAsString();
						sendNotification(i$runningObj, docName, argJson);
					}

				}

			}
		} catch (Exception e) {
			e.getMessage();
		}
		return argJson;
	}

	private void sendNotification(JsonObject i$runningObj, String docName, JsonObject argJson) {
		try {
			JsonObject map$Data = new JsonObject();
			Gson gson = new Gson();
			JsonObject projection = new JsonObject();
			projection.addProperty("iOtpCommMode", 1);
			JsonObject to$emailIds = new JsonObject();
			JsonObject $mobNum = new JsonObject();
			JsonObject personalInfo = i$runningObj.get("personalInfo").getAsJsonObject();

			if (personalInfo.has("EmpMail")) {
				to$emailIds.addProperty("toemailid1", personalInfo.get("EmpMail").getAsString());
			}
			if (personalInfo.has("MobNum") && personalInfo.has("IsdMobNum")) {
				$mobNum.addProperty("Mob_Number1",
						personalInfo.get("IsdMobNum").getAsString().concat(personalInfo.get("MobNum").getAsString()));
			}

			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
			JsonObject commMode = cParam.get("iOtpCommMode").getAsJsonObject();

			if (!argJson.isJsonNull()) {

				int expiryMode = argJson.get("ExpiredInDays").getAsInt();
				if (expiryMode == 0) {
					map$Data.addProperty("user", personalInfo.get("firstName").getAsString());
					map$Data.addProperty("document", docName);
					map$Data.addProperty("tmp$name", "IMPACTO_DOCUMENT_EXPIRED");

				} else {
					map$Data.addProperty("user", personalInfo.get("firstName").getAsString());
					map$Data.addProperty("noOfDays", argJson.get("ExpiredInDays").getAsInt());
					map$Data.addProperty("document", docName);
					map$Data.addProperty("tmp$name", "IMPACTO_DOCUMENT_EXPIRY");
				}

			}

			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendSmsOtp").getAsString(), "Y")) {
				try {
					JsonObject argJsonPass = new JsonObject();
					argJsonPass.add("toemailIds", to$emailIds);
					argJsonPass.add("map$Data", map$Data);
					I$ISmsService.sendSMS(argJsonPass);

				} catch (Exception e) {
					e.getMessage();

				}

			}
			if (I$utils.$iStrFuzzyMatch(commMode.get("iSendMailOtp").getAsString(), "Y")) {
				try {
					JsonObject argJsonPass = new JsonObject();
					argJsonPass.add("toemailIds", to$emailIds);
					argJsonPass.add("map$Data", map$Data);
					i$Email.sendEmail(argJsonPass);

				} catch (Exception e) {
					e.getMessage();

				}
			}

		} catch (Exception e) {
			e.getMessage();
		}

	}

	private boolean IsDocExpired(String DocDoe, JsonObject argJson) {
		try {

			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{}");
			int DocValidityInDays = cParam.get("DocValidityInDays").getAsInt();

			String todayDate = I$utils.currentDateinString();
			int DiffinDays = I$utils.getDateDifference(todayDate, DocDoe);
			int ExpiredInDays = 0;

			if (DiffinDays <= 0) {
				argJson.addProperty("ExpiredInDays", ExpiredInDays);
				return true;
			} else {
				if (DocValidityInDays >= DiffinDays) {
					// ExpiredInDays = DocValidityInDays - DiffinDays;
					argJson.addProperty("ExpiredInDays", DiffinDays);
					return true;
				}
			}

		} catch (Exception e) {
			e.getMessage();
			return false;
		}
		return false;

	}

	private String getDefaultValue(String fldName, String lovValue, String lovKeyValue) {
		try {
			
			if(I$utils.$iStrFuzzyMatch(lovValue, "") && !I$utils.$iStrFuzzyMatch(lovKeyValue, "")) {
				lovValue = "";
//				lovValue = "###IMP1###Reselect value for LOV "+fldName+"###IMP2###"; 
			}
		} catch (Exception e) {
			
		}
		return lovValue; 
	}
	// #BHUVI001 Ends
}
// #BVB00124 Ends