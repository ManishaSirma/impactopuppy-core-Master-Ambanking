/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Pruthvi 	| Feb 9, 2021  | #YPR00048   | Initial writing
      |0.1 Beta    | Pruthvi 	| Feb 9, 2021  | #YPR00048   | Added verification mode change functionality
      |0.1 Beta    | Pruthvi 	| Feb 17,2021  | #YPR00051   | Updating of Verification results into application.
      |0.1 Beta    | Pruthvi 	| Mar 03,2021  | #YPR00054   | Added Verify Application Operation form Smartphone.
      |0.1 Beta    | Pruthvi 	| Mar 06,2021  | #YPR00055   | Added Termination of Application for Tests Failed Appls.
      |0.1 Beta    | Pruthvi 	| Mar 11,2021  | #YPR00059   | Updating DocumentDetails from verify stage.
      |0.1 Beta    | Syed 	    | Mar 11,2021  | #MAQ00104   | Handled Retry for failed Appls
      |0.1 Beta    | Devraj     | Mar 18,2021  | #DVJ00045   | Added the status of payment receipt in InitialDeposit stage
      |0.1 Beta    | Pruthvi    | Mar 22,2021  | #YPR00061   | Added Documents updation in OSV stage
      |0.3 Beta    | Pruthvi    | Apr 15,2021  | #YPR00073   | Added Payment deposit success notification changes
      |0.3 Beta    | Pappu      | Apr 17,2021  | #PKY00009   | Added code for online verification notification.
      |2.1 Beta    | Pappu      | Apr 27,2021  | #PKY00010   | Added new service for verification mode
      |2.1 Beta    | Pruthvi    | May 25,2021  | #YPR00081   | Added JobSrvc for Holding applications
      |0.4 Beta    | Pruthvi    | Jun 08,2021  | #YPR00085   | Added Smartphone Verification field changes
      ----------------------------------------------------------------------------------------------
      
*/
// #YPR00048 Begins

package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isrvccontrollers.IRegulaDevScan;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.Ioutils;
public class IRegulaDevScan {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	
	private DBController db$Ctrl = new DBController();
	private static final Logger logger = LoggerFactory.getLogger(IRegulaDevScan.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SvrOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SvrOpr, "scanReq")) {
				isonMsg = scanReq(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(SvrOpr, "checkReq")) {
				isonMsg = checkReq(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(SvrOpr, "updateResp")) {
				isonMsg = updateResp(isonMsg);
			}else if (I$utils.$iStrFuzzyMatch(SvrOpr, "fetchRes")) {
				isonMsg = fetchRes(isonMsg);
			}else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}
	
	public JsonObject checkReq(JsonObject isonMsg) {
		
		try {			
			JsonObject res = db$Ctrl.db$FindAndUpdateRow("ICOR_T_REG_SCAN_DOCS", "{$set:{'scanning':'WIP'}}", "{'scanning':'Pending'}");
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, res.get("i-body").getAsJsonObject().get("request").getAsJsonObject().get("i-body").getAsJsonObject());
			isonMsg.getAsJsonObject("i-body").getAsJsonObject().addProperty("docPresent", "Y");
			isonMsg.get("i-body").getAsJsonObject().addProperty("scanId", res.get("i-body").getAsJsonObject().get("scanId").getAsString());	
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Scannning data found");
		} catch (Exception e) {
			isonMsg.getAsJsonObject("i-body").getAsJsonObject().addProperty("docPresent", "N");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "No data found");
		}
		return isonMsg;
	}
		
	public JsonObject scanReq(JsonObject isonMsg) {
		JsonObject i$Doc = new JsonObject();
		Gson gson = new Gson();
		try {			
			i$Doc.addProperty("currImpactosessionID",
					i$ResM.getGobalValJObj("JSessionDets").get("sessionId").getAsString());
			i$Doc.add("currImpacatocreatedAt", i$ResM.addDateTime(new Date()));
			i$Doc.add("request", isonMsg);
			i$Doc.addProperty("scanning", "Pending");
			String sSeqNm = "SEQ#REGSCAN";
			String sAppndStr ="100"; 
			String sSeqNo = db$Ctrl.db$GetSeqFor(sSeqNm,sAppndStr);
			i$Doc.addProperty("scanId", sSeqNo);
			db$Ctrl.db$InsertRow("ICOR_T_REG_SCAN_DOCS", i$Doc);
			isonMsg.get("i-body").getAsJsonObject().addProperty("scanId", sSeqNo);	
			isonMsg.get("i-body").getAsJsonObject().remove("imgData");
			isonMsg.get("i-body").getAsJsonObject().remove("Base64ImageString");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Scanning initiated successfully..");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
		}
		return isonMsg;
	}

	
	public JsonObject updateResp(JsonObject isonMsg) {
		try {			
			JsonObject i$Match = new JsonObject();
			JsonObject i$Doc = new JsonObject();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			i$Match.addProperty("scanning", "WIP");
			i$Match.addProperty("scanId", i$body.get("scanId").getAsString());
			i$Doc.addProperty("scanning", "Completed");
			i$Doc.add("regRes", i$body.get("regRes").getAsJsonObject());
			JsonObject u$pdate = db$Ctrl.db$UpdateRow("ICOR_T_REG_SCAN_DOCS", i$Doc,i$Match);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, u$pdate);
			isonMsg.get("i-body").getAsJsonObject().remove("regRes");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Scannning data found");
		} catch (Exception e) {
			isonMsg.getAsJsonObject("i-body").getAsJsonObject().addProperty("docPresent", "N");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "No data found");
		}
		return isonMsg;
	}
	
	public JsonObject fetchRes(JsonObject isonMsg) {		
		try {
			JsonObject i$Match = new JsonObject();
			JsonObject i$body = isonMsg.getAsJsonObject("i-body");
			i$Match.addProperty("scanning", "Completed");
			i$Match.addProperty("scanId", i$body.get("scanId").getAsString());
			JsonObject i$Res = db$Ctrl.db$GetRow("ICOR_T_REG_SCAN_DOCS", i$Match);
			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$Res.get("regRes").getAsJsonObject());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Scanning successful");
		} catch (Exception e) {
			isonMsg.getAsJsonObject("i-body").getAsJsonObject().addProperty("docPresent", "N");
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "No data found");
		}
		return isonMsg;
	}

	public IRegulaDevScan() {
		// constructor
	}

}
// #YPR00048 Ends