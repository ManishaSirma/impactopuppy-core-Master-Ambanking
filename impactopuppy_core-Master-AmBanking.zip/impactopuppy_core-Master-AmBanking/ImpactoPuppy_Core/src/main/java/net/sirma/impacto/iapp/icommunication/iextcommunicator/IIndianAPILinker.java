/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Feb 02, 2019 | #BVB00050   | Initial writing 
      ----------------------------------------------------------------------------------------------
*/
// #BVB00050 Begins
package net.sirma.impacto.iapp.icommunication.iextcommunicator;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iworkers.iappworkers.ISdnScanWorker;
import net.sirma.impacto.iapp.icontrollers.iiocontrollers.IFileController;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

import java.io.File;

import org.apache.commons.codec.language.Soundex;

public class IIndianAPILinker {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IIndianAPILinker.class);
	private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
	private IFileController i$fileCtrl = new IFileController();

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);

			if (I$utils.$iStrFuzzyMatch(Scr, "OCRINAPI") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				isonMsg = processMsgHandler(isonMsg);
				// #BVB00056 Starts
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
			// #BVB00056 Ends
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED ", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	public JsonObject processMsgHandler(JsonObject isonMsg) {
		try {
			String type = i$ResM.getBodyElementS(isonMsg, "type");
			String operation1 = i$ResM.getOpr1(isonMsg);
			if (I$utils.$iStrFuzzyMatch(type, "PAN")) {
				isonMsg = PanUpload(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(type, "AADHAR") && I$utils.$iStrFuzzyMatch(operation1, "")) {
				isonMsg = AadharUpload(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(type, "AADHAR") && I$utils.$iStrFuzzyMatch(operation1, "SENDOTP")) {
				isonMsg = AadharSendOTP(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(type, "AADHAR") && I$utils.$iStrFuzzyMatch(operation1, "VERIFY")) {
				isonMsg = AadharVerifyOtp(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(type, "DL")) {
				isonMsg = DriversLicense(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(type, "Passport")) {
				isonMsg = PassportUpload(isonMsg);
			} else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid or Unknown Document");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid or Unknown Document " + e.getMessage());
		}

		return isonMsg;
	}

	public JsonObject AadharSendOTP(JsonObject isonMsg) {
		JsonParser parser = new JsonParser();
		try {

			// Get the Aadhar Number and
			String aadhar = i$ResM.getBodyElementS(isonMsg, "aadharNo");

			// Call Aadhar Api for sending OTP

			JsonObject reqBody = new JsonObject();
			reqBody.addProperty("id_number", aadhar);

			JsonObject JResp = launchRequest(isonMsg, reqBody, "AADHAR_SEND");
			JsonObject resBody = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
			String statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
			if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, resBody.getAsJsonObject("data"));
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
						"OTP Sent to Mobile Linked to Aadhar: " + aadhar);

			} else {
				// Write for the failed in SMS part

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"OTP Sending Failed to Mobile Linked to Aadhar: " + aadhar);

			}

		} catch (Exception e) {
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Failed during Aadhar Retrieval with " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject PassportUpload(JsonObject isonMsg) {
		try {

			// Creating CLient ID
			JsonParser parser = new JsonParser();
			JsonObject resBody = launchRequest(isonMsg, "PASSPORT_CLIENT");
			resBody = parser.parse(resBody.get("resBody").getAsString()).getAsJsonObject();

			String statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
			if (I$utils.$iStrFuzzyMatch(statusCode, "201")) {
				// Get the client Id:

				String clientId = resBody.get("data").getAsJsonObject().get("client_id").getAsString();

				// Call the Next API to fetch the Passport data

				String panImage = i$ResM.getBodyElementS(isonMsg, "document1");
				File sourceFile = i$fileCtrl.createFile(panImage);

				RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
						.addFormDataPart("file", "image.png",
								RequestBody.create(MediaType.parse("image/png"), sourceFile))
						.addFormDataPart("strict_check", "true").build();

				JsonObject filter = new JsonObject();
				filter.addProperty("trnCd", "PASSPORT_UPLOAD");
				JsonObject argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
				argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

				argJson.add("reqBody", new JsonObject());

				String extUrl = argJson.get("extUrl").getAsString();
				extUrl = extUrl.replaceAll("###IMP1###clientId###IMP2###", clientId);
				argJson.addProperty("extUrl", extUrl);

				resBody = I$EWSLnchr.ILaunchReq(argJson, requestBody);

				// resBody = launchRequest(isonMsg, "PASSPORT_UPLOAD");
				resBody = parser.parse(resBody.get("resBody").getAsString()).getAsJsonObject();
				statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");

				if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {
					// Get the data and attach it to body
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
							resBody.getAsJsonObject("data"));
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Passport Data Retrieved Sucessfully");

				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Failed during Passport Retrieval " + resBody.get("message").getAsString());
				}

			} else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"Failed during Passport Retrieval " + resBody.get("message").getAsString());

			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Failed during Passport Retrieval with " + e.getMessage());

		}
		return isonMsg;
	}

	public JsonObject DriversLicense(JsonObject isonMsg) {
		try {

			JsonParser parser = new JsonParser();
			// Get the DL No
			JsonObject reqBody = new JsonObject();
			reqBody.addProperty("id_number", i$ResM.getBodyElementS(isonMsg, "dlNo"));
			if (!I$utils.$iStrBlank(i$ResM.getBodyElementS(isonMsg, "dlNo"))) {
				JsonObject resBody = launchRequest(isonMsg, reqBody, "DL_VERIFY");
				resBody = parser.parse(resBody.get("resBody").getAsString()).getAsJsonObject();

				String statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
				if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {

					JsonObject i$body = resBody.getAsJsonObject("data");
					i$body.addProperty("SURNAME AND GIVEN NAMES", i$body.get("name").getAsString());
					i$body.addProperty("DATE OF BIRTH", i$body.get("dob").getAsString());
					i$body.addProperty("DATE OF ISSUE", i$body.get("doi").getAsString());
					i$body.addProperty("DATE OF EXPIRY", i$body.get("doe").getAsString());
					i$body.addProperty("SEX", i$body.get("gender").getAsString());
					i$body.addProperty("DOCUMENT NUMBER", i$body.get("license_number").getAsString());
					i$body.addProperty("type", "DL");
					i$body.remove("name");
					i$body.remove("dob");
					i$body.remove("doi");
					i$body.remove("doe");
					i$body.remove("gender");
					i$body.remove("license_number");
					i$body.remove("client_id");
					
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
							resBody.getAsJsonObject("data"));
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DL Data Retrieved Sucessfully");

				} else {

					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Failed during DL Data Retrieval with " + resBody.get("message").getAsString());

				}
			} else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Retake the Drivers License");

			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed during DL Data Retrieval " + e.getMessage());

		}
		return isonMsg;
	}

	public JsonObject AadharVerifyOtp(JsonObject isonMsg) {
		try {
			JsonParser parser = new JsonParser();
			// Get the client Id, Otp
			JsonObject reqBody = new JsonObject();
			reqBody.addProperty("client_id", i$ResM.getBodyElementS(isonMsg, "client_id"));
			reqBody.addProperty("otp", i$ResM.getBodyElementS(isonMsg, "otp"));
			if (!I$utils.$iStrFuzzyMatch(i$ResM.getBodyElementS(isonMsg, "otp"), "060606")
					&& !I$utils.$iStrFuzzyMatch(i$ResM.getBodyElementS(isonMsg, "otp"), "070707")) {

				JsonObject resBody = launchRequest(isonMsg, reqBody, "AADHAR_VERIFY");
				resBody = parser.parse(resBody.get("resBody").getAsString()).getAsJsonObject();

				String statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
				if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {

					JsonObject addressFields = resBody.getAsJsonObject("data").getAsJsonObject("address");
					JsonObject i$body = i$impactoUtil.mergeJsonObject(resBody.getAsJsonObject("data"), addressFields);

					i$body.addProperty("SURNAME AND GIVEN NAMES", i$body.get("full_name").getAsString());
					i$body.addProperty("DATE OF BIRTH", i$body.get("dob").getAsString());
					i$body.addProperty("SEX", i$body.get("gender").getAsString());
					i$body.addProperty("DOCUMENT NUMBER", i$body.get("aadhaar_number").getAsString());

					i$body.remove("zip_data");
					i$body.remove("raw_xml");
					i$body.remove("address");
					i$body.remove("care_of");

					i$body.remove("full_name");
					i$body.remove("dob");
					i$body.remove("aadhaar_number");
					i$body.remove("gender");
					
					i$body.addProperty("type", "AADHAR");
					
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Aadhar Data Retrieved Sucessfully");

				}
			} else if (I$utils.$iStrFuzzyMatch(i$ResM.getBodyElementS(isonMsg, "otp"), "060606")) {
				// Vinod Data
				String data = "{\n" + "    \"has_image\" : true,\n"
						+ "    \"client_id\" : \"aadhaar_v2_wlfKcfvruPGzOxUltrvP\",\n" + "    \"gender\" : \"M\",\n"
						+ "    \"face_status\" : false,\n"
						+ "    \"profile_image\" : \"/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADIAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDvhRS4pwFcpsMpR1p22gDmgYDrThS7aUCgBKXNKV4BoAyaADNLyaXHtR+NAhh6ijmnMOaAPagYzLUnNSEZpCKBDOaOadijFADMGmsMGpQKaVoAiNJUhFMoAetPpg4NO3UDA0oFGc9qVTigBcU9RxTc0oPFAxSPzp232pp6cVS1PWdP0a0+06hdxwR9AH+859FHVj9KQjQCEntQVxivMtX+KEaxMmlROCSfnn25HOeACc9x2/w5G9+JfimUEC4WGPHSKIL+py361SixNnu7nFAPOO9fNh8X6w7lpNZ1IZ4KreS4P4bqfbeMtdt5TJDrt/ux0muHkX8mJA+vWq9mxcx9I/0oI45r5/h+JXiWC/W5kvw6gjMLRoY2AGMEYyM+oIPvXo/hz4m6XrVwlpcxNY3DEhCzbo29Bu7HHqAPc0nBhc7fAFHvQehoqSgH0pGGD706mk44NADDimGntUdAh3fFKKUjkU8JQUNA4pQKfikAwaAE/Cg5A6E0r/KM5rz/AMU/EmDR7iSytbd5rhQQWY7VU/gee3TH4UJN7CbsW/GfjceH2Fpbp5l8y5+bhIhjgnB5P+z+eOAfItQ1O+1q7+0Xd5LNMRgyStyB6KOij2AqtPfrezyT3kjmSRizMx6k1TlVFAdCG+laJWFuWmCwHJU7yeWbJ/XvTJP33yiQc9icVUN05CqyYx3waikaJ+h2t9aq3cTHTBY8qyg/WqhPPBI9qvJKkqbZCSfUc8VUmCBiUJx7jNNBYdHt28sBn1p8M8lrOrxSsjDkEHkVW3EnluKXGMnIIBpiaPT/AAV8RbuynNtq1xJc27knzJJMupJ5O5jyOpxyfT0r2eCaK4hSSJ1dGGQR6V8lIxDcV6D4K8e3Oi3aQ3hluLFyFYbstEOmVzwR7fljnMTj1QJ2PeKQjIxSWs8F7aRXVrIJYJV3I44yPp1H07VLsrIsgI7VGQc1Ow61GBzQA/HQ1KRgZpMfud3oal2ZQHFBViLtSDrUqoWzUqWzMScdKAsULsyC2cxZ34+UDqT2FfM+qSreX006yb0YlvMP8fvzzz/WvffiPqo0HwnM6uY7m7Jt4WGQVyCWII77Q2D2OK+cpLvMpJxgnpirgiWU5XaR25I9BRGGGGGcj0rV0/T1vJgHwB1IBrutN06xtbdGSz39jtXJqalVQ0NqVBz1PMm88nB3HHTIqW3tp52ULESWOBjqa9KvrZZrd9sSwxHP3owHI9Ce3Wq/hLRrbUJVu2jHlI7InP3uTyfWpVdct7FvDe9Y5VNBkhJZpYlkUZILdMfzqGXTL5VMzRNs6biMg/nXsv8AZdpFykMaMOQSucH6Vn6paxSfOxDN0yw4x2rL27Nnhoni0kBjJBQZ9xio/KYngZHpiu9v9HR3wQu5iS2Ow9qxLrS2gUsEB+vNbRrJowlh2jmpFK9sVJFLggf0qeaIZw6hc9zxVeNCHwOea3TujlkrH0N8KZ3ufCrB5C4WYhcnOzgfL7dM/wDAs967tYgwryf4JX5E+p6VIcblW5jGP+Auf/RdexR7VcgZz16VjPcqOxnSDDYNRKBuqxdEeYeahApDJ0j3202B91d1TRrvtlPfp0plkocOv8TKQOlO05hgKcYJwQcUFCgbD9TV2Mo0Z24/H/8AVUUsYEpK4Ixnt/jTIiFO0k49PT9aQHjPxt1Uzajp2nLIQkMLysobIYuwAOPbyzj6mvH1jMjY75r0r40kR+PYzF8oFlE2McZDOM4P0H5VwGmRedd4wMdTWy0iQld2NjRYxE4KdDkmu10052hc1z1tbCJQFGOOvrXR6T8hGRxXDVfM7nq0o8qsWb/Tby8tp0gdVMsaom7+Dk5b8sYrT0vTIdIsI7S3B8uIcFjkk9c/rV62ktgp3Hnt7VO80O0sAOOM1ld2sbWW5W3Fs/Ln8KzbxGGTg/Str7bZKmCwDgdPX/PNZOoXds4IWeMn0B5FFmDaRgTgZxjr2qhMqlTkZFWru/to32+YGzVeVkdd8TA59D0qle2pm2mchqkSCR1GC+emOaz4YyrsSM8dccZrS12zlRvtUIJCn5gO1Z0V19pLcYIPSu6nrHQ8ytG09T0v4QK0njUiPllsJCw9t8f/ANavfboLHngceleC/BGNX8dzF14WxkUcZAJeMj6dDXuWo3AaQqnAxj60TRlF6lB13s2Af8/hTIxgYal3cVFI3HHFSWWLQkTgdT7Uke6G4YDPDEcVAG5yO1TTNvnZx1bDfjjn+tAy+koJIY0FVXvkZ4qkr5IJPt0qfKqFJYGgZ4l8cLWOPxBp10NweW1KMP4cK5I7dfnP4AVwmlxiCwa7C7nc4UfjivTvjjEHGguBni5HXp/qf8a4VbWRNPhEKZKIMj1OOacpJRSHTi3K5HDFqNxlgQGI45wPpTnutZ09cvGxQf3ayze6h5xRfMjOeAOMfWrUNrrV3MiuCIiwBYTHGD3xu/lUW72OhPtc2NP8TNI4RyQT2P1rrba+82A8npniuHfRJILgN95OqSZwSfdck/jk12mirCkDh0+bZxWFVR6HVT5mtTnNWvLqGcldxUEGsJSZpw15dJBuPOW5NdrqNklxKoKZXOSAawW0CVo5AH/eycAxMUVT/M/ielFKatYmpFkofRraAK9wGZhyzt1/OqdxHZPJ5trNtbsUaol8NXsDnN7cOAORlgMn3z2pttoNx5+6Y8eoHP4+tae6upmlLblLaFpY8NgnHJ9a5W/s2tNRYxr8j8gDtXoK2EcNvhTk4rl9cTy5IpPQ0Up+9oTXheGp0Xw68S2vhLUvtt3DDN9pURuOTMiZ+8gzg9DxjJ9a9xlmScho2V0YZVlOQR6g18+6ZpUJkgkKmSZ4924Z4I7fl/KvbPDzRL4c0jByPsUIx7eWtacyk2jCdLkimaZGKiIzT3niIwGP1xUZnjHQMfoP/r1RiKrKMZYe9PJyAysSoOM7T+VRVNDuZJFBAB6570hjt8QHOWPtmnrPCCDsk+lQJjO1j7ZqYxBRkEH8qBnGfE+0TU9AgmS2YvBIyeaT/qkdeT+LrEPxrzyEA4Vehr2vVbJNV0e7sCVjeeIqjsu4I/8ACxHswB/CvD7GTMaKyMjqNro4wysOGB9wQRUTV0b0ZK9jSi0SFjv2jJ71eTT4YRwm49gaWxc4A5zWxFEhGWPNcjbPSUFY5q//AHbAsOR2HQegq9YxSC2Mh5z1qrrzRJcuZZUjSJQfmOBk1Z03W4/7NaNWQo+DnjnHvTs2iU0mPScGXy3IB7ZrTOn7wJEBBxn2xXMwatpOoySRJdp9oGRjpn6Hv+FdPpV05sYZGJdHUEH196Gmhppjo7U/xonvxVa5gi+YBNuK1ppI2UBSMnnI61k3mFQ85qWh8qMe8PldD1rnL63jvpYopM4aVQSOuCQDWxfzD1rPsFWbU41kUsoJO31ODj9cVvTVtTlqPoX2tTp0MH2bMj5dUXufkP8AXFexRwQwRJDEAI41CIPYcCvMdB057vxDZrKS2x/NYhv9WqHdgD3YKD9a9QHPX8K0pLS5jipXaQbfbimlRTifypv8VanIOBqSEnDYI+lQ0+IkZoGKw5qaN8Ac1C5oVsUwJp3UxkgZOK8J1RJrTxNrEcy7WN7JMoHTZIxdf0Ne13cuyFiK8w8YCOWTztiicDaHA5IznGfTr+Z9aLXRUZcruUbC4JIxXRQXKrFknHtXEWNyQw5xWrLdsqsN2AO5rjnGzPUhO8SPW9OGpaj9pM6BNgVoni3q2CeRyMdaqxeFo1iDwzzRwk/PGOV/DPSq0muLvKwxtMwOCQOBVmLWtUSEJ9lZ1b7uYzx+X9atRqJaCSUmatzo9tLClqQsUSY+aJFDH/gWM1v2xihtIoIlCxxKFRfQAYFcW+vakj7ri0MijrlAp/DH+FXbXX4JnWMs8Mp52SDH5VLhK2o3odLLMYwe/vWPe3R2nJ61LJcs6kN1+tYl7PyQKhIpy0K11KWPWjTVk+2CVI5WC8BkQsN3HHHqCapySc8mup8KShSVB5JyTXXCndWOCtV5ZXOq8JaPPAW1O8UxzTJsiiP3kjyCS3ucDjqAOeSQOtO0DHWqdo+6IZNW/lJ45q0klZHPKbm+Zi4oUYJNIWpu8DoaCRm6lQkHNMyaVDk4zQMm3Zpvv2poobpmgZS1CYrERk15d4nnJnwOa9F1aQRwM7sFQDlmOAPxrzHXUadpJYxujUdfX6VtSjdmVSSS1MOO4EUu/t6VfM8cseWb5fT1rlZr10uFRuAeo9KvWlwjsFLVlVpdUdFCvpZl430dsyFk/cqeABwK1ZvGNlJHGu4JsTZtRcLjntjr8x596TT4oWxv2kehGa6Kxh023hwtrApzyVjArn51s0ehDm6HOXPi+3uwqRxxh/WNMFu9OgvvOTEqEIexAFdTMunsSywRKT6IAT+VYl6tuh4AFS6i2SBqXUh+3rEu0cqOme1ZF5fCSTiq+paggby4eT3x2rLMuPvNW1Ol1Zy1K1tEW57ry42kJzjoK6XwpNJEyyyn9y54z29/pXGGNr10hGcM4Feg20KxWyRqMBRgV6FGkmnc8nE1mmrHpVgf3WK0UGBXDaLd62zhbNYrxFKg274Vwo/unjr77jx0ratfF1i4MN9HJp1ymBMlyCFRtu4gsQNoA/vheo45rmlTak0tbG8KiaTeh0DNioy3tTd+7kY/CkPXms7GgBsihfrUe4KpYkBQMknsKpDWdOW2W7ku0SzfOy4PKzEYyIgOZcZ6oCOvIIxRsM0Zp4reB5ppEjijUs8jttVQOpJPAFc/N4qkvC0GgWcl8wIV5hEzIvOPuryR15O0dDkilfxPbXl0ItJ0CXVpYpRt84KoRgCQ24hghxnG7b9au3TTXEBi8T6rBa20gObGyZlaRPR5D87cdVjCDrncDzDq8j96P9em4OPMvdZxGp+c1wBfXwu71WYPGrB1t8AAglfkD5yCqZ+7liDwa4jDptPIPWh3SWeWWG2jtonctHAiBREn8K4HGQMAkdTk9SakQYxXr001FXPHqSvI4jxXovkn7ZAPlH3h6VzEc7wkFTx1xXq17ClxbSRuMowwRXnF7pjQ7gPvKSD71z1ko2Z2YaTkmuxPZ680RGT+BrZj8SxlOQ2fqK4llOabk+prnlTjLc7oV5wVjuW8TqE+VTu7VkXOtzzscuFB9657LZ6mnopYgAZJpKnFFSxE5aF37RjJByT1Jqxa2097J8oOzux6Cr2m6ApRZbo8HkIP61tHy4ItsahVHQClKslohxoN6yKlnarDfW0ac7SWY+vBrrYzkYrAsIT9oMzDk8Ct+P7oxXdhf4dzycdb2tkWba4u4ZUFmyeY7KoV1LBueBgEc56fWukXxLo2rqtr4n0yX7Tb/KLhATJEB1DgbXxnHyjdk9RxXLPGroUOcMMHBxXRS+KjeQ2v9saRZ3mJiBcSINu/gnYrqw3YxwGA56DNYYuj7yqRjd+Tsww9X3eRvTzJ9KsbC3lYaTr0zO7EpabkdcE53NFhWGe+Np4611P2K48sMrLNxhjGCDnv8p5HPbk1wUx8OXQkWRZ7QGTczckyA5+UD51VfYAdsVZs7O/to/M0TWyY03BYUbKwoeR8vzIW6dVX+lcDlJO8pNf4lb8UegrW91X9H+hJ9mu9ekUWii9iJz/aF7EY7JRkANBbHJmODkPIWTcvGMiortNB027Y3t3c+IdekYKVVyR5q7hswOAuQcxkuV7Lio7i/vvEMq/bJ5dO0qZd2yAnMsZGM7m++OvJG0/3SckX49X8P+HFdNFhM824qzxsf3g29DK3RcgH5MjPbrT5p35db9l+r6fIGo25und/5FdbjxFfqLaBE0uyUMI4LUCLYvVVLffBHTKhQc9Kyb61+ypukl3TysS42k5Pdtx5J6dR3p0mv37lzHJFBl8ho05C+hznP14qjJK82ZHkdy3JZiT+VdeHo1lJOSUV97+85K1Wk4tJtv8AAYD3705WPc1GMDrTxjPFenY88c43A1hXuniRpGA781u87aZCE8/a+Nsgx079v61y4qDdJ26HXgZqNZX66Hneo6NIjGSJSR3FY7QupwVYH6V65PpikkqKrrpkZ6xLn6V5UcQ0rM9yWGTeh5dFayzSBERix9q6bTND+z4klXL9h6V18emxL0jUH1AqcWgyMCpniHJWRcMOo6mEIJCBtWp4NOLPl+e/PStpLQHtU6wKtZubsa8tzGaAx3ATjAUGrSfe4qORgLm4fOfmx9COP6U+2y2W9a93DR5aUUfM4uXNWkWeg7Zra8OeI10B7uO4SWW0ul+ZIlUlX4AbBI4x16ngYFYZ60jcDLdq0q0o1IOEtjCnNwkpI1JbvTBePxB5PUYh+X8tuf0qG2Gg3Usreb9mJ5EwcxGM+qhvlz+FY3yuODketTKFx8gxjqCK4P7O5fhnJfM7fr1/iijQ8QeIJ9ZSMSRJEidAGLsec8scZHoMDHPWspOcVFcEDaopZpWt7UsoBkOFQE4yx4A/MiuylRhSVoKxzVKs6rvJj1P2gsB/qUOOD94jr+Haq4n1CO182SO2ll5CxRllBHruOf5D61YjiKrHaRbnONvTJb/656n8TVgRTW9wPNRopAflyMdD1HqM9xVuSTtfUlJ9tCnaz6lchy+hajFsQyElBtK8cqSRv6j7uc1FHrenSuyfa40ZT8wl/dkH/gWK6q31yfBjuiHVxtEmACvfPHHpU+peFbHUfKaOK3eRlBHnIGU55yDzj/PSuJ4yVKfLWVk9mdP1eE43p6nNxTxTDdBOko/2HDY/Kq94HeCRUba5B2uOqt2P4HBqC+8Kac80kbW0lpPkFvKbaR9ByuOvIFNi042zCGO7umQLx5rBhu6FTx2POBjhlz1rsU1JW7nOo8runsbunXZvrCOdozHJkpJGf4HUkMPzH5VPgbvSsVJ5NOvoLyaQC0vkVZ+PljuMAbvYHbj+ftuFQCTnrXgVYcsj6qjPmimNwMdhRkD60nOeDS4x6Gs7GpIvI46U9iqKWb7oGSc9BUEk8dvA8szpHGgyzMcAVhT65dahaSTWNqI7AfK09xkNKCQDsUfzP6EVcKbk7GdSaitRhkLEL36sauJKqKAB0rA+2XTsEsLVZiQH82R8IFyRnAOee3TPXBHNaui+D9d12cPqOqtZWZOE8lfmk9Rxjj3OeeOcHHvTqwowvLZHy6pSqz06k1xexwgedNHFnpvcDP09ayzr1ncXK21q7XEz5Cqq7R0zyWx29M10z+GPD/heVJbZGvb/ADu/0siTyyMHOAAB2I/i98dMe+s1nuri+jtllv3YSgon7x2Qbtq4HcLjjtms6WJdVc0VaPdjnRjTfK3djbdrnzZEmiREH3WV85+vAqxHOjvmORWx12tmupa40LTxBOBCBIV27VaUqSMgnAJXgg5OO1ZV3qE2q3TRwJJ5WRtTqXx3IH8v8jOnjJVZ2jB27vQdTDqCvKWvZGSEJl3N0HQetQ3Tk3UCAZwS+0jg4GP0JB/Ciiuu5gjRs7qSwfegRmcfNvHX8e1dJa65YTxiK7jMYOMrIu9GJPT/APWBRRXLicLTq+89zoo1pQ91bGZqmntDI00WfLOXZMf6sHnHHYev/wCuorTUrmxYGJsoOsb8rznOPQ8np39aKKxwkvb0eWrrYquvZVLw0N9Liw1iwSJhmRckoeHQ8cj1HTkcdj6VxusRRWV5HLDcLNH/ABFcnaDxgnpzx0/u8gZFFFRhk6WJdKL93saVXz0VNrUhjZJDNYXHNvdKUz6MRgH/AD3xTtL1RYIF07UZkhvLcCM+YcCReispPUYx70UVeMguf1OrL6knCz6F+61C1sEL3M6RDBIDNyfoO9UTqeqXxC6fpbQr3mvvkA/4COT9f0oorhUUocx6Tk3KwL4eNzcJNq12980ZzGhQJGv4Dr2/rmn6/LClkLdsEN1QcfKP8/pRRWuF/eVYqRhjHyUZNGp4X8PpJp8d/dlHM7bxGOeOwb6f3fXr3FbGta4sZS2s2zPENryDonsPU/oPqCKKKUP9pxbjV1UdkedP9zRvDdnNIk11P5abnkbLMSc/Vif6+9dNarb6Lp5ugXY/dkKjlmH3eM4HcfjyaKK0x05OrGhtFmeGiuR1Opymn20lwj29tbMY4nZEQHOxATsBY8Z2gdetbEcMfh0farmQszgoAmML35Jx6f8A66KKrEVZOrHD/Zf3ipwXK6vVH//Z\",\n"
						+ "    \"share_code\" : \"9444\",\n" + "    \"face_score\" : -1.0,\n"
						+ "    \"zip\" : \"416416\",\n" + "    \"aadhaar_number\" : \"810270865218\",\n"
						+ "    \"dob\" : \"1995-10-31\",\n" + "    \"full_name\" : \"Vinod Anil Pawar\",\n"
						+ "    \"po\" : \"Sangli\",\n" + "    \"loc\" : \"Vasantnagar Sangli\",\n"
						+ "    \"subdist\" : \"Miraj\",\n" + "    \"dist\" : \"Sangli\",\n"
						+ "    \"house\" : \"Gurukrupa,C.S.No.1229\",\n" + "    \"vtc\" : \"Sangli\",\n"
						+ "    \"country\" : \"India\",\n" + "    \"state\" : \"Maharashtra\",\n"
						+ "    \"street\" : \"100 Ft Road\"\n" + "}";
				JsonObject i$body = parser.parse(data).getAsJsonObject();
				i$body.addProperty("SURNAME AND GIVEN NAMES", i$body.get("full_name").getAsString());
				i$body.addProperty("DATE OF BIRTH", i$body.get("dob").getAsString());
				i$body.addProperty("SEX", i$body.get("gender").getAsString());
				i$body.addProperty("DOCUMENT NUMBER", i$body.get("aadhaar_number").getAsString());

				i$body.remove("full_name");
				i$body.remove("dob");
				i$body.remove("aadhaar_number");
				i$body.remove("gender");
				i$body.remove("zip_data");
				i$body.addProperty("type", "AADHAR");
				i$body.remove("raw_xml");
				i$body.remove("address");
				i$body.remove("care_of");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Aadhar Data Retrieved Sucessfully");

			} else if (I$utils.$iStrFuzzyMatch(i$ResM.getBodyElementS(isonMsg, "otp"), "070707")) {
				// Niegil Data
				String data = "{\n" + "    \"gender\": \"M\",\n" + "    \"dob\": \"1984-05-12\",\n"
						+ "    \"care_of\": \"S/O: Chaluvila Yohannan Thomas\",\n" + "    \"face_score\": -1,\n"
						+ "    \"client_id\": \"aadhaar_v2_mepyaiGnlUyKshoegyvh\",\n" + "    \"has_image\": true,\n"
						+ "    \"profile_image\": \"/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADIAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDRUc4qvqik2yIOrOBVpOtR3X/H3YrxzKOv1x/WuE6HsayAn15NbFqMIorNjGSPrWvAuQMda6kcyLcQ7Y61PwBTUXCinMKoYu2kK9aXbjn1607FAEJGOgo6CnswGciovkyTxk8E+1ADlIZFPqM0jKSMGhdo6YFP3r60AQtkdqcvTntUoweaTbySKVgIyv1oC8VIQAcUhGKYEZ+lGBUhHrSEDqaAGYpMYOTTj19aCM9KQHDouTUciCTVbRCcbct+XP8ASpoRge1RLltet8dApz/3y1ci3N5bG3HgsMdK2IVBANZduh8wVsQIRXUc6LS8AUoHPGcGl2krT1UgehNMY3BA96a7BRyae7LGhJIAAyfauA8ZeMjYR+RZXSwy+agLmMNxu+bknA4Vv09eGB019qlvZrJJPPHFEnLPIwUL+J/Csm08SWGpSbbS9hlfGdit8xHrjrjkfnXiPivxhJqt6EEsphjcOqE8bsYzgde/0yfU1kP4g1QtAyxhUiyFAjGCDkHjGOhPago+i7nW7eyiMtzcRwxAcvIwUD6k9OoqOy8R6fqMhSzvoJnGSVRwSMcHj8R+dfPlr4l1Kzm80SMzbzITIMncRgnnvjjPWtTRvGBt7rPlorKxcFlD45JODjIzlxnk/O3XNOwH0TBcEnrwauRybzXC6L4ihvZLcJdxP5iltgI3fTb+f0x78djbzqyY71LEXCGI4xnFJ0UbutOR9wyadtHQ5JpiGEfnTCOx6VMV5470wj5jSAZjBpcDnIpSDjFJj3oA4eIEYA6D3oscNrcoOMrAcfmP8akQCjS4g2oXk/ddqD6Ef/Wrljubz+E2rdf3grWhIxwP0rMtuZcVrxjCgDqa6TBE6jt1p5BAyOfampwKyfEev2mg6TLe3cypGqkKD1ZuwA7/AOe3NUBleKNae20+eNcKWhZ1AJ3EDqOmMncvHB5PpXkGpRvrMkc17xhcCMADjnAI7YzjHP1q5/a99rV1NeSyy+TISII3J4TJI4zxwQPfGTk809Ygo55NYzqW0R1UqV9WZCafBDwkSg+uOacbOM9QBWjJG2flWoHyM1jztnRyJGc9nCCfkB+tNNjascNCv5Vac8ZPaoi3zAdKpSZEoo0LHz7NTJZPhlBIXAyWwcEE8ZGSBkY5PXpXb6B42ttSkMEiPBKh2kNknov3uBtOW24xj5Tgntw1tL5bA9j1qLVrW4ET6ppTMl2i4lRf+Wi4Iz9QCfwrojK+5zTh2PdLG9juEV0cOjDhgcg1pK2SO9eSfDvxaNSs1tbho1uYwAOxcBcficLk/iQMZx6paOZEVhTZkW84GKaxGR6084NM6HBPNAhp4pRjmmkEc5/GhuuRSuBxKfKM0aRkz35HTev/ALNQTgVLoo/c3EvHzTEfkP8A69c0PiN6mxtWa5ckjFasXXnpWdactmtJOOnWuhGCJxyrZ4ArwTxtry+L/FaWsKgafYFkVs5MpJGTxxtyox7D3wPa9caVPDmpGCYQTC1l8uY9I22HDfgefwr538OxKBNIQAScdO1EnaNzWnHmkdDAqxjAACqOTT2uraMjdKg/GqTgy70ZikY647ms+40+KTJLv7ZYCuZJPc7G2tjo0ktrlMpKjH2Oagls1YFl5GcZrnbPfZXBKzb+2K6SxufNUl2HSolHl2CMmyg9mrZGcduapSW6Rty9Xrm7SPIQjcpPXmsXUJHumAiOP97kCqje5MnZFzzFL/K6ge5rdsWBjUqwIIwT71xaaYchnnIJ7KOK6HRo57M7N3mQscnPBzW6sZO7Wxi6xavofiBLy1IRWcSqB2Of88V9AeGL03uj2lwSCZI1YlQcHI7Z7V4z4xthJp0NyoG6OTBPsf8A9Vel/DGa6l8NQC7QrsAELEg74+x46dxj0A5zmtehhJanddTTWHNPxxTGPeggafxxSEZHXn1p2Rioy2GIHWkxnD7sqal0FWWxYsT80pIyPYf4VATiF/8AdNXtGfzNHte2Aw/8faueC1Namxt2g71oxg9c1n2Z+XFXc8jA61uZIg15Ufw5qiyT+RG1rKHl/uLsOW/Ac18/eHRvtyMcFq+g9RjM+lXcAKqZIXXLLuHK45Hce1fO2hyMtgSpGSxxipq/Ab0PjNTVg9tHkbiOvyjJrFe7vG0xp7dYEkVwvkSkmQj+92HpwM/hWoba5J3sS2fWmCLLfMP0rnptI6ppszUjlNqZpd/2syny1CADZ2J54P51uafJIyqzpsbHOP6UsNmJBuK4UHvxmtews3uGJWPCjofaqnJWCnB3Of1C0Z1aSJcOOQPWsiMGcylwyNGrFAULhmA4XAORk969Ak0547hVZPlP51zmp6aIbolBsY5IHZqdOSaJqxsznLOW6uJ2SRLaJY03P57+Vk/3QSSP89q6LTtQgdA0busYAzHKMMp9vUfnWYygvkqNw9etTIJbmUFue2cVpzIyUWb2rIt54duwD91Q2QP7pB/pXovgRmHhfT9yBP3C9DnI7H8Rz+Neczr5ehXuf+fdzn/gJrv/AAHOJfCmnMp4WEIOf7vH9KuOxjUWp2Yk4ppbHXpUBkAHWmmY49qdzMkMnP1pHbnkVBvGOtNaQg+oqQOPuH2Wkh9FNaumx+Rp1uuQf3Qb/vrn+tY18SLGX6VuWSlLG3V+qxIp/ACsobmlQ1bbgCrqN3qlbjIq2o9/yNakIdIGkjZOjMCB09K+bNEL20LRTZDiRgwYYIOec+9fSZQOMNyCentXzXPdebrV7KGyr3Ej5UYHLE5pSV0aU3aVzsrSRJECsFzTpLZBkqqgVz1ndESocg7c5zW218gQsWzxkVzTg7ndGasRu2w7ccHqKqXOvahHrQFnDGbWIBXZyFGPY5/pWTeeJ4Ip3RRvcdOeK5S7vrvUrv5W2DIwBwM1caTe5E6qij0vWvEd49iJbdE88LhWlOBx6Y61Vs9QOqaKDcqq3McigE+uRkj22lhXDzyXv2JLMxOWjJZmIxj6HvTdL1SS0CpKzbCeAatUbLQj215anZzQDzSSMn2qe3Cg4CEmqNrfpcxHpkeh61ZRuAVJArPkd7MtyVjYnRZdLuIj8oeNkH4jFdn4QZU8PWCxEFfITkfQVwV3cGPSty5Jk6DGO9dx4QJPh/TsknFtGuenRQK6UrI46judVu4ppbGaaG+XFMycmgzHM3SoncrnHTNBwDuA56VG/wAysO2OKQHKaq+ywb3IrpiAGwOgOBiuZu1E81pb9POmVK6IN8wOc5Pas4F1DTgbA56irKSZwapxk7evHerCsAM45rQlFjfwB64Ar5ejQgoCcnHPHevpqSRdpGelfN+oRi21K8t0UBIpnVQOcAMRQzSG4+GRlIXjB7ZzxVm9MzWeIi2Od2T1+n41QjcDkc+tWvPSQFByB1IqeptfQxIrFQ3mTRHJPIAz+tdHb2ETRiRbaIHg9eadaeUgyFHHXPNXG1GK3PzQHawz8opSbbKpRitWQNAVU7IOQckkDmsfVrOCVd5TZKowBjg1tLqtpk/u5gSOcjil8yyuc+bHkn1OAKSumXUcJLQ5CwkMF2m1zgtgr0rr7eUgdARxgnpXPG3ihvnIGQDgZHQVswPGsG7BZieAPWtHqzmjorFydvNt23Dn1B5/PNei+Cwx8N2RdSp2EYxjgEgfpXnBlxEE3OAQeh6Y/wD1GvVfD1ubTRbOBjlo4UU/UAZq3sZyNdM7MCgnB6cUnbrTGPeoIButRZBwORTt5PB49ajzgAA0gOYdHkv9PCfeE278FwTW+CQRjJ5HNc9BM8eu2Z2EqY3yfQFSM/nW+JFVs5qYFT3NGAnbg+tSmUICemKzzfRRjJcVh+IPFVvplg0xYMxyEjB5Y/4e9aJAhPF3i2LQrLeoMsznEcQbBPqT7f8A1q8ZvLiee7mluVRZ5HMrhPugsd3HJ9a0nM+sSy6lqLsd4bHyHaiAfO/0UcD1cr6GuXs5iXKkhvUYzjtg1TjZDi9TRR2GQpzk4471LFM245XJIxzzVZTvyAc561FKCrbk/h5x61CNWdBC3kgAD6D/ABq8puJyMkbAOyg4rnba9Dhck5UcAcV0Ftfx+UcN0GePWplcqLRLLFcBd6uCcdCgP9Kz5mb+IgNnGBWqb2ER7UJHygZzwaxLy7X5gDz1qY7jlboVZI2++Tz+uasW0zbPL+8AcnA/z6VRnunmOBnOOSKt6dFvIBPf0NbpWMLmzbJ588UW4jOAA3ueleuWN6rjaTz7V4xc3txaTobWNJGg/euMZwoI5I/Efqe3HZ6Lrkd/bC4iBUjh0J5U/wCe9NrQhno4IZRikIG2sG11uIKFYmtCPUYZOkgNQxFnhSff1pCCBgcUgkQ8ggml3DqTSEeYN4oVNVOxPuQFBz1O7NI3iKad1US/MxChFOSSewrlHk+zaeLh9oubknyz8uUQH73sSRtB7YY9cGiJnttIefANxduYoyyncEAy5B6AnKrn03iqjTstTRtNnS/8JErziFG818kFgwKj33Z27ffPSsDU57jXtXjt0kUIDsB5C+pYjrjq3PI98VGE+yabwrPdzkFs5JSPjHqBuJz6gKOz8zeS9lpgjABvdR/dgNkFYicEkZH3245BGFPrWkYoTZT1K6iWwdLcBY52EcZbGRDGeO2RufLH3WuZtoyDNwdwIIz6VtapIDqxtlY+XbAQKQeCF4Jx6E7j+NGrxCw1S3sirK8NsgkDY++cuw/Dfj8Kc1oKHxGekvzdeKuL8wGMEdqrzQGNvNQZQ8n2qSJ84GSB6+tc7Zv6khtFMuVUhsZ4NWI7F2A2SgZGcdKWPBI2jjqcCrsbbT90EgZyealzGolVreYKV8wkgf3v/rVTFszE7myCeTWo0hC8HHqT6+oqtLLySGIGO/ehSBxIFRE4wDzzVpJUhjZy2CORiqUk6hWYtxxxnrVGW4kmjO4YjTPFax8yGX7TVHOqiYuUifCiQDlD2cfQ9u43DvXRQxy27XFxaAWUy4juoUAKxMejKD1QnoO2cdxXOXlrCbeyuYUKx3MI4wABIvyuPpkZ/wCBVr6Te3Gy2nhG64gU288RUFZYCOAy45GMqc/7Het7aWML6mjY63fgSw3DwyXMW5nD/ISBySvY8ZPrx0PbU0nxDHfSrCu6O4bgJnIJ9Ae/5CotQ0uGeSLUbN2ACrJCXHOFPI6nJUjaf90HoSRz99ZNp9yJYPk+fdGVf50xg4yPTIwe4wQRyKlxQ7noMOszJjEgI7YOavR683AbFcJcXsrW0OpQyEvIdtwD90SgZzwAPmHzd+dw7cWY9T8yz+0xHc0fyzRkcLnhWBz0ycd8Ec/eFQ4Aczr7yf2vLGu8QwN9njydwCL8o/MAn6mk1S9gFtZwWjv50cKoS3RGJZ2GCODubHHYDrnhqrJJOFJJVoygJ7uP6/NTvE+mO3iS+ZH5e5lAHoAxI/lWgrlLV7W8a205nnaRmtjIzk5LHcw5+gVR7YpyX15pcGlzO7TNveZ9/OBu2AZOehQkehNWNTkaFbW2G7EdkhJbszKZP/Z60b1rOfw9pzNHhv3yue7BWD/zc1QtTEgtA19ZzERy2kzqH2t91cjcGXqP84pbi6j1HUbma7EsJLsxwmSrFs7eo6YrY+yRXHh6K4SRo7mC5J+TIK+Yg2nPsYm/OoLfTVvYL28R5WnjHn52El1LhSSc5H3wc+maVhlHzIEQAThx/tKVP+H61WktWB3RNtJ5x2qxcWjTNGixgzvgARjG8kkDgdyR2qslregtFHC8hGQY1OW49uv6VjKn1RrGp0Y6KWdMfIdvqOamF4cZC8D1FMt7gJ8jDy2DcpJke2PzrRRUmzhFHqPSsZK26NU29jNkvFbjPOarl5pfuoWH5ZrQnKRSHJ4wMAd6hX7YZEMeyMZ+XP8APGMn8KuML7ETlbcoMiqxaU7j6D/GpoNl3byAxgLj5AFP5k5wB+Fbn2a8m0v7XdAT2wl8kl1UAPjdjA+Y8d8r1pI0jk028/dkzRRoUQDCqfNRScDg8EjJ9a3UEjFyZUsIHn0C9iMkO21kWZS2AzKco2M845Qn6Cm2NwZUubC1eRrmeHbGynGSrK23/wAd/MVf8N6PPqetpb3EjLFcJIj4bBxtb+RUH8KdoGjwRa5ppc7z9qRTjsdyY/Dk1diLlPQ5NTlnSF7qd4yrhI2clS5HAAPTLbMmtiy1L+1bP7Hc2MbXEau7zNJt3qFZsYC8HG455zkZ6DC6UIn8S2RhXEJnVkX/AIEMVR0+aLT9WWWdYzbuRG4fJHlldr5HX7rGgNUXdNWJTc2kVys8F0hAV8K8br8yk8cjOV47Mfeq2nXj2F+GZGZSSkkTsRvUghlPOemR0wMCqVzBLZ6nLbuSrJIULfd3dsj68Ee1b+p26SPb6gP3YuIhLJhNo3gkOB7Fl3f8CoHcz9EtTceIrUp8+Z4yUI4GH+YfkKgnne5v2nlYb2k8zHf5g1afhv8AdXNxfI4ie3glmCy8ZfbsC/8AfbCs2C0+26msEQKzEiJSRxlsBf1zUjJ/EsONQVHQK+2BW46HyVqbW9PiXwtpDR/KdtyTg9fmFL4lcXfiK43/ACP55CgHrsIX/wBBGasaw7jRdKsZlCEQO4fqMSyHH6AH8aYivpDTR+FtYXAYEW5APX7+P6mmeG5BHrUa3W4x3DtCyqxG5ZAY8fTn9Ktacyw+Fr5ZQ26ZreJGxwWyzkfklV/D0ay61C12zLFDIZdyjoqAygn2oGUU82C8WWMLG4IIYY3B+x/Db+tWPFWnwf2nLeRJJBDdKt2m/liJFDEf99ErVaR3acNIu4gFzJj+IdR/48DWn4oyl79jll86OCOO1RlGCdqd/wDgeaBEMcTf2PFczyx3caTCCW2fl2UoSrB2DbOjDgDp71l313p6Wm+2FzZtu2vEQJEXjICNw2fXIx6elbkpa38N28UkODPdvLExHVURV/mzVFpmm2t7BfwyYlEVpIRv7OgByPypNc2g1Jxehg2Ki98qC2jPmzHCiV+CScA5GO+etaWs2qx61dQWQWC3jkaNUJ5dQQh+uc5pfDkMcWr2e+MIBexYOP4d60kxWaeOaQZm35B78q279QKeyE3c0by3ig0HS7aAMtzIJpnRuAxdwiH/AMh/5zT7LyV8P308sTCSd4Yo2XopLGVh/wCQwPxo8YvI1hp7E5YabbgEf59c1a3p/wAIbsz84v1OPby2x/I0wKvh63jb7fcRzSfu7SaZCDyC6bMA+xcn8KZ4cmht/E1rKyjLOqNx/ExZV/mKPC8qW1pewyghnsZQB6nG/wDkKo6c6Wmtx3VxkQLcRPn0CFWP86QCWd7HZ6hazSBsQusxUDnAKnA/I1T1Oxa01ia1CkLE+1CwySvVcn02nNS6zEYNVntwoVY5Sg3AgkBiBj88/QVq6hBHLpthfsPvQeVMsbEuTEcElvVl20xEl7aC40+wu1lRZ5ojDIVJLBoyFLMT3KMlGoyPdeG7OJH58+ZVJ6AYhP8ANjUizLJ4RkjEWJ1uFbdjn54mBGf+2QqNIVuPDDRtE5mt5gGcHhRImD+OYgPxpNjHQD7H4afMv726mEZEi5LJGNxYH/eZc/Sm+GFC6l9slhllitg9xIjdU2KTx/wPp9adrz+Ra2dixlKW9uDJH5eGRpDvfH0Vh/3zTrGI23hy7uXRy8zx2qTKxGDy759Qdq/nSAxguJ1VD5iooGzGXDDp+YY/lWj4r+zrq89shd7ZStvGv90rGFAHsGX+dL4ahlufENrsjAkFxGSDzuRTvz/3yf0qnqF0brUHnSICK6kZzn+As28Y/Ij86ANGeU2/hWCGSPia7knRsfwoir/Nm/I1FosdzDpup3A8t9kHkMx5B3uq5H/AA1O15vsmnabbuxuIY7VZSo/6aMXYf98lR+FFrBLa+FpZUb91LcwwEf7iSN/UUwKujwxya9aCVy0c88SMo/hy+w/mADT9a8sa3foDuDXMrqf+2oP8ql8JWhl8SW6MDk3ImH0ADj+VZbK8z208hO8ffOe7KT/SjoBr6ldq+j6LaNndAsjnI7PMQOffbUWhyCObUQON0N3/AOimP9KTV5Xa4ggkH+phtkA/7Zox/Viaf4btxdarJByfMFwvHvA4/rRfURV0Zs+JYA5UJHPCeeg+bdS6zYxf21eNGdvkzyIuO58wL/LP5VA+1XwvEjbiT7YUD+tavjC08nxHcRISAs3nEj3Xef50AQatFcppekX0riRjC8YjPPEUhx+jKPwpumqG0XUYZVd7iMRSqFGcbWKMfw8ytKSA3Phe3unPy293JbqM/wB9Eb+amofDIm+0TWagNLeW0sO4n7pZN4z+OKLgVfDki2viC23AS7pdhU9g+Ux+AOao3cDW986PGDKjGORlbhcHBH5kflSiPM+5FIRhkyA4OSOB+SmtbxNbbr8XaWwVLqOO5ijDYILr3/4Fk/hQBHrkD3UVpqj+Y32qAeZIepdPkfA7cAY+tXLJHn8MXcLgKkU8UjJjDAsro2f/ABwU2L/SvDUgWEsba4SQyFs7Y5FIIA+qL+dUtIM0WmXkbuSxtQz5PU+fFgn8z+dAFvTZIbjw9rDsB96J4/wkKfyemeH18+K704zSStPCwCpj5pVxIAfT7pX8ab4cdZLi7tIbYytNbywIpOMOE3g/99IKqW08tpqCSxryjLIvHygg5AJHXJzx6CgY3W7sahq0tws7kTTM8bdNyE4Cn22H9K070Jb+FtNMUhKTvcTTI395SEBHpwp/M0UUhDPDEdzaXlxch1ln0+3nmGOjlVKAfTkViMGF0CT+5wcjuGH/ANZ6KKBl3xB5cOoyQRMXSMraEk9SkYiP6rWl5inwWIScH+0yw+giH/xVFFADPBVwJfEljJgYKsv/AHzAR/SsbpKUB/unH4OP60UUMDQ1qLZrKOwLRyxwsuD28hQP1FWvCA/4qeEYxnzM/TyDzRRQtw6mAQTq23B/1Gf/AB6tbxEbq4ma8kyJbqCGQY/2o1U/1oooEXbUzXfhS7jA/c21xDc59S6uhH/oNUdAVoNZtTJLhWukfOcbV34wfwU/hRRQAavbw2urzLGrLHFcPFGo6ffxz+Ga0NTjS48PadIh3zBZreVx/DhtyL+T0UUxho91GfDGrIpAR0jKqR2WYAfof1qPQJIJDqUchyGspEXP95FV/wD2Q/lRRSAzrG5ex1RJdqExMJEUEjdg7uT7k4/Cp9dtFttVd7dVaEsHgKqSDG+GUL+gz9aKKOgj/9k=\",\n"
						+ "    \"raw_xml\": \"https://aadhaar-api-docs.s3.amazonaws.com/sirmaindia/aadhaar_xml/610820200210184431354/610820200210184431354-2020-02-10-131431.xml?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Date=20200210T131431Z&X-Amz-Credential=AKIARVQSU3FJ26BNVN6C%2F20200210%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Signature=994a62c03d76de948816995023d34ac2ce53f750f315399c07cd99336906bb4b\",\n"
						+ "    \"face_status\": false,\n" + "    \"share_code\": \"2156\",\n" + "    \"address\":\n"
						+ "    {\n" + "        \"po\": \"Kulathupuzha\",\n"
						+ "        \"vtc\": \"Thinkalkarikkakom\",\n" + "        \"state\": \"Kerala\",\n"
						+ "        \"house\": \"Chaluvila Niegils\",\n" + "        \"dist\": \"Kollam\",\n"
						+ "        \"subdist\": \"Pathanapuram\",\n" + "        \"country\": \"India\",\n"
						+ "        \"street\": \"Kumaramkarikkom\",\n" + "        \"loc\": \"Kulathupuzha\"\n"
						+ "    },\n" + "    \"aadhaar_number\": \"467271996108\",\n"
						+ "    \"zip_data\": \"https://aadhaar-api-docs.s3.amazonaws.com/sirmaindia/aadhaar_xml/610820200210184431354/610820200210184431354-2020-02-10-131431.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Date=20200210T131431Z&X-Amz-Credential=AKIARVQSU3FJ26BNVN6C%2F20200210%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Signature=253f5f95dde9d05e18ac1969734faecf48f8181c3007c1115991694f5a36ddf2\",\n"
						+ "    \"full_name\": \"Niegil John Thomas\",\n" + "    \"zip\": \"691310\"\n" + "\n" + "}";
				JsonObject i$body = parser.parse(data).getAsJsonObject();
				JsonObject addressFields = i$body.getAsJsonObject("address");
 				i$body = i$impactoUtil.mergeJsonObject(i$body, addressFields);

				i$body.addProperty("SURNAME AND GIVEN NAMES", i$body.get("full_name").getAsString());
				i$body.addProperty("DATE OF BIRTH", i$body.get("dob").getAsString());
				i$body.addProperty("SEX", i$body.get("gender").getAsString());
				i$body.addProperty("DOCUMENT NUMBER", i$body.get("aadhaar_number").getAsString());

				i$body.remove("zip_data");
				i$body.remove("raw_xml");
				i$body.remove("address");
				i$body.remove("care_of");
				i$body.remove("full_name");
				i$body.remove("dob");
				i$body.remove("aadhaar_number");
				i$body.remove("gender"); 
				i$body.addProperty("type", "AADHAR"); 
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Aadhar Data Retrieved Sucessfully");
 
			} else {
				String resp = "";
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG,
						parser.parse(resp).getAsJsonObject());
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Aadhar Data Retrieved Sucessfully");

			}

		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Failed during Aadhar Verification with " + e.getMessage());
		}
		return isonMsg;
	}

	public JsonObject AadharUpload(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		try {
			filter.addProperty("trnCd", "AADHAR_UPLOAD");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			String aadharImage = i$ResM.getBodyElementS(isonMsg, "document1");
			if (!I$utils.$iStrBlank(aadharImage)) {
				File sourceFile = i$fileCtrl.createFile(aadharImage);
				argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

				RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
						.addFormDataPart("file", "image.png",
								RequestBody.create(MediaType.parse("image/png"), sourceFile))
						.addFormDataPart("strict_check", "true").build();

				argJson.add("reqBody", new JsonObject());

				JResp = I$EWSLnchr.ILaunchReq(argJson, requestBody);
				// String resp =
				// "{\"unqCommID\":\"b8c5a596-c7ef-4646-91ed-4a510f17627d20200207160251724\",\"resStat\":\"i-SUCC\",\"resCode\":200,\"resBody\":\"{\\\"success\\\":
				// true, \\\"status_code\\\": 200, \\\"data\\\": {\\\"client_id\\\":
				// \\\"ocr_aadhaar_oYfYkeZuntNwgpFIkclc\\\", \\\"ocr_fields\\\":
				// [{\\\"document_type\\\": \\\"aadhaar_front_bottom\\\", \\\"image_url\\\":
				// null, \\\"uniqueness_id\\\":
				// \\\"81ed223a73a09843f91385eed0b2b8cad2b3820b9faadfe17d369cf4bc3ede84\\\",
				// \\\"full_name\\\": {\\\"confidence\\\": 100.0, \\\"value\\\": \\\"Batta Vijay
				// Babu\\\"}, \\\"dob\\\": {\\\"confidence\\\": 90.0, \\\"value\\\":
				// \\\"1993-06-24\\\"}, \\\"aadhaar_number\\\": {\\\"confidence\\\": 90.0,
				// \\\"is_masked\\\": false, \\\"value\\\": \\\"908354086588\\\"},
				// \\\"mother_name\\\": {\\\"confidence\\\": null, \\\"value\\\": null}}]},
				// \\\"message\\\": null, \\\"message_code\\\": \\\"success\\\"}\"}";
				// JResp = parser.parse(resp).getAsJsonObject();
				logger.debug("JResp: " + gson.toJson(JResp));
				JsonObject resBody = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
				String statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
				if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {
					// Get the Aadhar Number and
					JsonObject ocrFields = resBody.getAsJsonObject("data").getAsJsonArray("ocr_fields").get(0)
							.getAsJsonObject();
					String aadhar = ocrFields.getAsJsonObject("aadhaar_number").get("value").getAsString();

					// Call Aadhar Api for sending OTP
					logger.debug("aadhar: " + aadhar);
					JsonObject reqBody = new JsonObject();
					reqBody.addProperty("id_number", aadhar);

					JResp = launchRequest(isonMsg, reqBody, "AADHAR_SEND");
					resBody = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
					statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
					if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {
						ocrFields = resBody.getAsJsonObject("data");
						ocrFields.addProperty("type", "AADHAR_UPLOAD");
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ocrFields);
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC,
								"OTP Sent to Mobile Linked to Aadhar: " + aadhar);

					} else {
						// Write for the failed in SMS part
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP Sent to Mobile Linked to Aadhar");
//					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//							"OTP Sending Failed to Mobile Linked to Aadhar: " + aadhar);

					}

				} else {
					JsonObject i$body = new JsonObject(); 
					i$body.addProperty("type", "AADHAR_UPLOAD");
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
//				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
//						"Failed during Aadhar Retrieval " + resBody.get("message").getAsString());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP Sent to Mobile Linked to Aadhar");
				}
			} else {
				JsonObject i$body = new JsonObject(); 
				i$body.addProperty("type", "AADHAR_UPLOAD");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Retake the Aadhar ID Card");
			}

		} catch (Exception e) {
			JsonObject i$body = new JsonObject(); 
			i$body.addProperty("type", "AADHAR_UPLOAD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "OTP Sent to Mobile Linked to Aadhar");
		}
		return isonMsg;
	}

	public JsonObject launchRequest(JsonObject isonMsg, JsonObject reqBody, String trnCd) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson();
		try {
			filter.addProperty("trnCd", trnCd);
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
			argJson.addProperty("reqBody", gson.toJson(reqBody));
			JResp = I$EWSLnchr.ILaunchReq(argJson);
		} catch (Exception e) {

		}
		return JResp;
	}

	public JsonObject launchRequest(JsonObject isonMsg, RequestBody requestBody, String trnCd) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		try {
			filter.addProperty("trnCd", trnCd);
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

			argJson.add("reqBody", new JsonObject());

			JResp = I$EWSLnchr.ILaunchReq(argJson, requestBody);

		} catch (Exception e) {
			// Need to do
		}
		return JResp;
	}

	public JsonObject launchRequest(JsonObject isonMsg, String trnCd) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		try {
			filter.addProperty("trnCd", trnCd);
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

			argJson.add("reqBody", new JsonObject());

			JResp = I$EWSLnchr.ILaunchReq(argJson, null);

		} catch (Exception e) {
			// Need to do
		}
		return JResp;
	}

	public JsonObject PanUpload(JsonObject isonMsg) {
		JsonObject argJson = new JsonObject();
		JsonObject filter = new JsonObject();
		JsonObject JResp = new JsonObject();
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		try {
			filter.addProperty("trnCd", "PAN_UPLOAD");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			String panImage = i$ResM.getBodyElementS(isonMsg, "document1");
			if (!I$utils.$iStrBlank(panImage)) {
				File sourceFile = i$fileCtrl.createFile(panImage);
				argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

				RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
						.addFormDataPart("file", "image.png",
								RequestBody.create(MediaType.parse("image/png"), sourceFile))
						.addFormDataPart("strict_check", "true").build();

				argJson.add("reqBody", new JsonObject());

				JResp = I$EWSLnchr.ILaunchReq(argJson, requestBody);

				logger.debug("JResp: " + gson.toJson(JResp));
				JsonObject resBody = parser.parse(JResp.get("resBody").getAsString()).getAsJsonObject();
				String statusCode = i$ResM.getStrfromObjWithDefault(resBody, "status_code", "400");
				if (I$utils.$iStrFuzzyMatch(statusCode, "200")) {
					JsonObject i$body = resBody.getAsJsonObject("data");
					i$body.addProperty("SURNAME AND GIVEN NAMES", i$body.get("full_name").getAsString());
					i$body.addProperty("DATE OF BIRTH", i$body.get("dob").getAsString());
					i$body.addProperty("DOCUMENT NUMBER", i$body.get("pan_number").getAsString());

					i$body.remove("full_name");
					i$body.remove("dob");
					i$body.remove("pan_number");
					i$body.remove("client_id");
					i$body.addProperty("type", "PAN");
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "PAN Card Retrieved Sucessfully");
				} else {
					i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							"Failed during PAN Card Retrieval " + resBody.get("message").getAsString());
				}
			} else {
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Retake the PAN Card");
			}
		} catch (Exception e) {

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, new JsonObject());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Failed during PAN Card Retrieval with " + e.getMessage());
		}
		return isonMsg;
	}

	// #BVB00056 Ends
	public IIndianAPILinker() {
		// Cons
	}
}
// #BVB00050 Ends
