/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 	| Jan 24, 2019  | #00000001   | Initial writing
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iconfig;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.annotation.Order;

import net.sirma.impacto.iapp.ihelpers.IConstants;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
@Configuration
@Order(900)
@Primary
@PropertySource("classpath:application.properties")
public class OracleConfig {
    private static final Logger logger = LoggerFactory.getLogger(OracleConfig.class);
    private static Ioutils I$utils = new Ioutils();
    private static ImpactoUtil I$ImUtils = new ImpactoUtil();
    public static DataSource dsOrclWSAdp = null;

    public static Connection getConn() {
    	OracleConnect();
        Connection Conn = null;
        boolean bSucc = false;
        int iRtryCnt = 0;
        int iRtryConn = 0;
        do {
            try {
                do {
                    Conn = dsOrclWSAdp.getConnection();
                    iRtryConn++;
                    if (!Conn.isClosed()) {
                        break;
                    }
                } while (iRtryConn <= 6);

                logger.debug("DB Connection Succeed in Retry" + Integer.toString(iRtryCnt));
                bSucc = true;
                break;
            } catch (Exception e) {
                e.printStackTrace();
                logger.debug("Failed to Connect.." + e.getMessage());
                try {
                    logger.debug("Sleeping before Retry..");
                    Thread.sleep(2000);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
                iRtryCnt++;
                logger.debug("Going for Retry.." + Integer.toString(iRtryCnt));
            }
        } while (iRtryCnt <= 3);

        if (bSucc)
            logger.debug("Success in Retry.." + Integer.toString(iRtryCnt));
        else
            logger.debug("Failed even after " + Integer.toString(iRtryCnt) + " no retries");

        return Conn;
    };

    public static DataSource getDS() {
        if (dsOrclWSAdp == null) {
            // Default DS is java:jboss/datasources/ImpactoOrclWSAdapDS
            String strJNDI = I$utils.$strValNullIf(PropLoader.env.getProperty("impacto.flxWSAdap.dsJNDI"), IConstants.I_DEF_FLXDS.toString());
            try {
                strJNDI = I$ImUtils.decrypt(strJNDI);
                logger.debug("JNDI Name is.." + strJNDI);
                Context ctx = new InitialContext();
                dsOrclWSAdp = (DataSource) ctx.lookup(strJNDI);
                logger.info("Successfully Connected");
                return dsOrclWSAdp;
            } catch (Exception e) {
                logger.debug("failed to get Oracle Connection DS" + e.getMessage());
                logger.error(e.getMessage());
                e.printStackTrace();
                return null;
            }
        } else {
            logger.error("returning existing connection");
            return dsOrclWSAdp;
        }
    }

  
    public static void OracleConnect() {
        try {
            logger.info("Attempting to establish connection to Oracle DB");
            dsOrclWSAdp = getDS();
            if (dsOrclWSAdp != null)
                logger.debug("Succeeded in establishing connection to Oracle DB");
            else
                logger.debug("Failed in establishing connection to Oracle DB..");

        } catch (Exception ex) {
            logger.error("Failed in establishing connection to Oracle DB.." + ex.getMessage());
            ex.printStackTrace();
        };
    }

    @PreDestroy
    public void OracleClose() {
        try {
            if ((dsOrclWSAdp != null) && (dsOrclWSAdp.getConnection() != null)) {
                dsOrclWSAdp.getConnection().close();
            }
            logger.info("flexcube connection Closed");
        } catch (Exception e) {
            logger.debug("failed to close flexcube connection " + e.getMessage());
            e.printStackTrace();
        }
    }

    public OracleConfig() {
        //
    }
}