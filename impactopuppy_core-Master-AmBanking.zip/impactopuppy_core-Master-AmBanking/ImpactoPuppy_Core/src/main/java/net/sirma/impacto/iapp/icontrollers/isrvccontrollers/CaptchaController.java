/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 		| Sep 27, 2018 | #BVB00003   | Captcha Service Property Implementation
      |0.1 Beta    | Valla 		| Dec 20, 2018 | #V0000004   | Captcha Service Property from Collection Implementation
      |0.1 Beta    | Niegil 	| feb 08, 2019 | #NYE00004   | Capthca ID Changes
      |0.3.6       | Vijay	 	| Apr 17, 2019 | #BVB00121   | Captcha ID Length now is 5. 
      |0.3.9       | Vijay	 	| May 20, 2019 | #BVB00152   | Captcha Id overflow fix. Revert of BVB00121
      |0.3.9       | Sumit	 	| July 28,2023 | #SKG00016   | added  background image  Captcha over text Captcha    
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.*;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.*;

public class CaptchaController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(CaptchaController.class);
	private ImpactoUtil i$Outils = new ImpactoUtil(); // #NYE00004
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "getCaptcha")) {
				// #BVB00003 Starts
				// return getCaptcha(isonMsg);
				// if (I$utils.$strValNullIf(PropLoader.env.getProperty("captcha.required"),
				// "").equals("Y")) {

				// #V000004 Starts
				return getCaptcha(isonMsg);

				// #BVB00003 Ends
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return null;
	};

	

	private JsonObject getCaptcha(JsonObject isonMsg) { 
		if (!I$utils.$iStrFuzzyMatch(i$ResM.getSrvcopr2(isonMsg), "iDocx")) {//SKG00016  
			JsonObject JCaptchaDetails = new JsonObject();
			JsonObject JCaptchaStore = new JsonObject();
			Random r = new Random();
			// Going to Generate Token
			try {
				int width = 180;
				int height = 50;
				int length = 6; // #BVB00152
				String possibleChars = "123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ";
				ArrayList<Color> colors = new ArrayList<Color>();

				colors.add(Color.BLACK);
				colors.add(Color.BLUE);
				colors.add(Color.MAGENTA);
				colors.add(Color.getHSBColor(0.56f, 1, 0.2f)); // Red
				colors.add(Color.getHSBColor(0.3f, 1, 0.3f)); // Parrot Green
				colors.add(Color.getHSBColor(0.01f, 1, 0.17f)); // Dark BLue

				String captchaString = "";
				char data[] = {};
				for (int m = 0; m < length; m++) {
					captchaString = captchaString + possibleChars.charAt(r.nextInt(possibleChars.length()));
				}

				// logger.debug("captchaString: " + captchaString);

				data = captchaString.toCharArray();
				BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

				Graphics2D g2d = bufferedImage.createGraphics();
				// #BVB00152 Starts
				// Font font = new Font("Helvetica", Font.BOLD, 28);
				// Font font = new Font("Arial", Font.BOLD, 28);
				Font font = new Font("Courier", Font.BOLD, 28);
				// #BVB00152 Ends
				g2d.setFont(font);

				RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
						RenderingHints.VALUE_ANTIALIAS_ON);

				rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

				g2d.setRenderingHints(rh);

				GradientPaint gp = new GradientPaint(0, 0, Color.white, 0, height / 2, Color.white, true);

				g2d.setPaint(gp);
				g2d.fillRect(0, 0, width, height);
				g2d.setColor(new Color(0, 0, 0));
				// JCaptchaDetails.addProperty("secCode", String.copyValueOf(data));
				JCaptchaStore.addProperty("secCode", String.copyValueOf(data));
				int x = 0;
				int y = 0;

				for (int i = 0; i < data.length; i++) {
					// #BVB00152 Starts
					// x += 18 + (Math.abs(r.nextInt()) % 15);
					x += 16 + (Math.abs(r.nextInt()) % 15);
					// y =30 + Math.abs(r.nextInt()) % 18;
					y = 27 + Math.abs(r.nextInt()) % 18;
					// #BVB00152 Ends
					int colorIndex = r.nextInt(colors.size());
					g2d.setColor(colors.get(colorIndex));
					g2d.drawChars(data, i, 1, x, y);

				}

				g2d.dispose();

				String CapNoise = db$Ctrl.db$GetRandCol("ICOR_S_CAPTCHA_NOISE", "captchNoise");

				BufferedImage img = null;
				try {
					if (!I$utils.$iStrBlank(CapNoise)) {
						byte[] imageByte;
						try {

							// imageByte = decoder.decodeBuffer(CapNoise);
							imageByte = Base64.decodeBase64(CapNoise);
							ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
							img = ImageIO.read(bis);
							bis.close();
						} catch (Exception e) {
							logger.debug("Failed with Error in getting noise image from DB ");
							e.printStackTrace();
						}
					} else {
						logger.debug("Captcha Noise is Null !!! ");
					}
				} catch (Exception e) {
					logger.debug("Failed to Get Noise ::" + e.getMessage());
					e.printStackTrace();
				}

				BufferedImage combined = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
				Graphics2D g = combined.createGraphics();
				g.drawImage(bufferedImage, 0, 0, null);
				g.drawImage(img, 0, 0, null);
				g.dispose();

				String imageString = null;
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				try {
					ImageIO.write(combined, "png", bos);
					byte[] imageBytes = bos.toByteArray();
					imageString = Base64.encodeBase64String(imageBytes);
					// imageString = encoder.encode(imageBytes);
					imageString = imageString.replaceAll(System.lineSeparator(), "");
					imageString = "data:image/png;base64," + imageString;
					JCaptchaDetails.addProperty("captchImage", imageString);
					JCaptchaStore.addProperty("captchImage", imageString);
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();

				}
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());

				/*
				 * String token = generateHMACToken(captchaString, "Captcha", secret,
				 * I$utils.$intValNullIf(PropLoader.env.getProperty("impacto.captcha.expMins"),
				 * "15"));
				 */

				String token = i$Outils.generateRandomKey(); // #NYE00004

				JCaptchaDetails.addProperty("captchaID", token);
				JCaptchaStore.addProperty("captchaID", token);
				JCaptchaStore.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
				db$Ctrl.db$InsertRow("ICOR_S_CAPTCHA_VALIDATOR", JCaptchaStore);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, JCaptchaDetails);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "CAPTCHA RETURNED SUCESSFULLY");
				return isonMsg;

			} catch (Exception e) {
				e.printStackTrace();
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
				e.printStackTrace();
				return isonMsg;
			}

		} else { //SKG00016 starts

			JsonObject JCaptchaDetails = new JsonObject();
			JsonObject JCaptchaStore = new JsonObject();
			Random r = new Random();
			// Going to Generate Token
			try {
				int width = 180;
				int height = 50;
				int length = 6; // #BVB00152
				String possibleChars = "123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ";
				ArrayList<Color> colors = new ArrayList<Color>();
				String captchaString = "";
				char data[] = {};
				for (int m = 0; m < length; m++) {
					captchaString = captchaString + possibleChars.charAt(r.nextInt(possibleChars.length()));
				}
				// logger.debug("captchaString: " + captchaString);
				data = captchaString.toCharArray();
				BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

				JsonObject filter = new JsonObject();
				JsonObject projection = new JsonObject();
				filter.addProperty("captchaId", isonMsg.getAsJsonObject("i-header").get("srvcopr2").getAsString());
				projection.addProperty("_id", 0);
				projection.addProperty("captchNoise", 1);

				JsonObject Db$Res = db$Ctrl.db$GetRow("ICOR_S_CAPTCHA_NOISE", filter, projection);
				String CapNoise = Db$Res.get("captchNoise").getAsString();
				BufferedImage img = null;
				try {
					if (!I$utils.$iStrBlank(CapNoise)) {
						byte[] imageByte;
						try {
							// imageByte = decoder.decodeBuffer(CapNoise);
							imageByte = Base64.decodeBase64(CapNoise);
							ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
							img = ImageIO.read(bis);
							bis.close();
						} catch (Exception e) {
							logger.debug("Failed with Error in getting noise image from DB ");
							e.printStackTrace();
						}
					} else {
						logger.debug("Captcha Noise is Null !!! ");
					}
				} catch (Exception e) {
					logger.debug("Failed to Get Noise ::" + e.getMessage());
					e.printStackTrace();
				}
				Font font = new Font("Courier", Font.BOLD, 20);
				BufferedImage combined = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
				Graphics2D g = combined.createGraphics();
				g.drawImage(bufferedImage, 0, 0, null);
				g.drawImage(img, 0, 0, null);
				g.setFont(font);
				RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
						RenderingHints.VALUE_ANTIALIAS_ON);
				rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
				g.setRenderingHints(rh);
				GradientPaint gp = new GradientPaint(0, 0, Color.white, 0, height / 2, Color.white, true);
				JCaptchaStore.addProperty("secCode", String.copyValueOf(data));
				int x = 0;
				int y = 0;

				for (int i = 0; i < data.length; i++) {
					// #BVB00152 Starts
					// x += 18 + (Math.abs(r.nextInt()) % 15);
					x += 16 + (Math.abs(r.nextInt()) % 15);
					// y =30 + Math.abs(r.nextInt()) % 18;
					y = 27 + Math.abs(r.nextInt()) % 18;
					// #BVB00152 Ends
//					int colorIndex = r.nextInt(colors.size());
					int colorIndex = r.nextInt();
//					g2d.set
//					g2d.setColor(colors.get(colorIndex));
					g.drawChars(data, i, 1, x, y);
				}
				g.dispose();

				String imageString = null;
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				try {
					ImageIO.write(combined, "png", bos);
					byte[] imageBytes = bos.toByteArray();
					imageString = Base64.encodeBase64String(imageBytes);
					// imageString = encoder.encode(imageBytes);
					imageString = imageString.replaceAll(System.lineSeparator(), "");
					imageString = "data:image/png;base64," + imageString;
					JCaptchaDetails.addProperty("captchImage", imageString);
					JCaptchaStore.addProperty("captchImage", imageString);
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();

				}
				String secret = IOUtils.toString(getClass().getClassLoader().getResourceAsStream("secret.key"),
						Charset.defaultCharset());

				/*
				 * String token = generateHMACToken(captchaString, "Captcha", secret,
				 * I$utils.$intValNullIf(PropLoader.env.getProperty("impacto.captcha.expMins"),
				 * "15"));
				 */

				String token = i$Outils.generateRandomKey(); // #NYE00004

				JCaptchaDetails.addProperty("captchaID", token);
				JCaptchaStore.addProperty("captchaID", token);
				JCaptchaStore.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
				db$Ctrl.db$InsertRow("ICOR_S_CAPTCHA_VALIDATOR", JCaptchaStore);
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, JCaptchaDetails);
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "CAPTCHA RETURNED SUCESSFULLY");
				return isonMsg;

			} catch (Exception e) {
				e.printStackTrace();
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
				e.printStackTrace();
				return isonMsg;
			}

		} //SKG00016 end 

	};

}