/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1 Beta    | Nye 		| Feb 28, 2019  | #00000001   | Initial writing
      |0.2.1 Beta    | Nye 		| Mar 01, 2019  | #00000002   | Initial writing
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.iactioncontrollers;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IDataValidator;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IAppMessageHandler {

	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private static final Logger logger = LoggerFactory.getLogger(IAppMessageHandler.class);
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();

	// private void build$Message(JsonObject isonMsg, String istatMsg, JsonArray
	// isonArrMsgBuilder) {
	private String build$Message(JsonObject isonMsg, JsonArray isonArrMsgBuilder) {
		String istatMsg = i$ResM.I_SUCC;
		if (IDataValidator.J$TempStorage.get().has("isonMsgBuilder")) {
			JsonArray isonMsgBuilderJson = IDataValidator.J$TempStorage.get().get("isonMsgBuilder").getAsJsonArray();
			JsonObject isonMsgBuilder$Doc = new JsonObject();
			JsonObject isonMsgBuilderObj = new JsonObject();
			boolean errSet = false;

			// boolean bContinue = false;
			for (int i = 0; i < isonMsgBuilderJson.size(); i++) {
				isonMsgBuilderObj = new JsonObject();
				// if (isonMsgBuilderJson.has(Integer.toString(i))) {
				isonMsgBuilder$Doc = isonMsgBuilderJson.get(i).getAsJsonObject();

				// Check Supress of Message
				if (checkSup(isonMsgBuilder$Doc)) {
					continue;
				}

				// Passed all Hurdles now I am going to Add the message
				isonMsgBuilderObj.addProperty(i$ResM.I_STATMSGCODE, isonMsgBuilder$Doc.get("msgCode").getAsString());
				isonMsgBuilderObj.addProperty(i$ResM.I_MSGTEXT, isonMsgBuilder$Doc.get(i$ResM.I_MSGTEXT).getAsString());
				isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "N");

				if (I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("msgType").getAsString(), "E")) {
					istatMsg = i$ResM.I_ERR;
					errSet = true;
				} else if (!errSet && I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("msgType").getAsString(), "W")) {
					istatMsg = i$ResM.I_WRN;
				}

				if ((I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_WRN)) && (isonMsgBuilder$Doc.has(i$ResM.I_CONFREQ))
						&& (I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get(i$ResM.I_CONFREQ).getAsString(), "1"))) {
					isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "Y"); // Confirmation is Required if the Request
																			// Final Status is Warning
					// Insert into DB with the Msg-Id
					i$ResM.setGobalVals("RequestConf", "Y");
				}
				isonArrMsgBuilder.add(isonMsgBuilderObj);

			}
			;
			// } // Main For loop Closing
		}

		return istatMsg;
	};

	public String getStatus() {
		String istatMsg = i$ResM.I_ERR;
		Gson gson = new Gson();
		try {
			if (IDataValidator.J$TempStorage.get().has("isonMsgBuilder")) {
				JsonArray isonMsgBuilderJson = IDataValidator.J$TempStorage.get().get("isonMsgBuilder")
						.getAsJsonArray();
				// Get all the msgs and get the worst error of all.
				JsonArray tempMsgCode = new JsonArray();
				for (int i = 0; i < isonMsgBuilderJson.size(); i++) {
					tempMsgCode.add(isonMsgBuilderJson.get(i).getAsJsonObject().get("msgCode").getAsString());
				}
				String filter = "{'msgCode' : {$in: " + gson.toJson(tempMsgCode) + "}}";
				// Call db$Distinct
				JsonArray msgTypes = db$Ctrl.db$Distinct("ICOR_C_ISON_MSGS", filter, "msgType");

				if (I$utils.isInArray(msgTypes, "E")) {
					istatMsg = i$ResM.I_ERR;
				} else if (I$utils.isInArray(msgTypes, "W")) {
					istatMsg = i$ResM.I_WARNING;
				} else if (I$utils.isInArray(msgTypes, "S")) {
					istatMsg = i$ResM.I_SUCC;
				}

			}
		} catch (Exception e) {
			logger.debug("Failed while fetching the final Status of the request " + e.getMessage());
		}
		return istatMsg;
	}

	public String build$MessageCurrent(JsonObject isonMsg, JsonArray isonArrMsgBuilder) {
		String istatMsg = i$ResM.getStatMsg(isonMsg);
		JsonObject isonMsgBuilderObj = new JsonObject();
		try {

			isonMsgBuilderObj.addProperty(i$ResM.I_STATMSGCODE, i$ResM.getMsgCode(istatMsg));
			isonMsgBuilderObj.addProperty(i$ResM.I_MSGTEXT,
					getDefaultMsgs(i$ResM.getMsgCode(istatMsg), i$ResM.getMsgtext(isonMsg)));
			isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "N");

			isonArrMsgBuilder.add(isonMsgBuilderObj);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return istatMsg;
	}

	public String build$MessagePartial(JsonObject isonMsg, JsonArray isonArrMsgBuilder) {
		String istatMsg = i$ResM.getStatMsg(isonMsg);
		JsonObject isonMsgBuilderObj = new JsonObject();
		try {
			istatMsg = build$Message(isonMsg, isonArrMsgBuilder);
			if (!i$ResM.getGobalValBol(i$ResM.I_SUP_LOC_MSG)) {
				isonMsgBuilderObj.addProperty(i$ResM.I_STATMSGCODE, i$ResM.getMsgCode(istatMsg));
				isonMsgBuilderObj.addProperty(i$ResM.I_MSGTEXT,
						getDefaultMsgs(i$ResM.getMsgCode(istatMsg), i$ResM.getMsgtext(isonMsg)));
				isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "N");
				istatMsg = i$ResM.getStatMsg(isonMsg);
				isonArrMsgBuilder.add(isonMsgBuilderObj);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return istatMsg;
	}

	public JsonObject get$Message(JsonObject isonMsg) {
		JsonArray isonArrMsgBlnk = new JsonArray();
		;

		try {

			JsonArray isonArrMsgBuilder = new JsonArray();
			JsonObject isonMsgblkObj = new JsonObject();
			isonMsgblkObj.addProperty("msgcode", "");
			isonMsgblkObj.addProperty("msgtext", "");
			isonArrMsgBlnk.add(isonMsgblkObj);
			JsonObject isonMsgBuilderObj = new JsonObject();

			// String istatMsg =
			// isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_STATTAGMSG).getAsString();
			// String istatMsg = getStatus();
			String sDefMsg = "";
			String istatMsg = "";
			// Build the Final Message
			if (I$utils.$iStrBlank(i$ResM.getStatMsg(isonMsg))) { // When the entire flow is through new Flow.
				istatMsg = build$Message(isonMsg, isonArrMsgBuilder);
			} else if (I$utils.$iStrBlank(i$ResM.getStatMsg(isonMsg))
					&& !IDataValidator.J$TempStorage.get().has("isonMsgBuilder")) {
				// if the flow is completely through old flow
				istatMsg = build$MessageCurrent(isonMsg, isonArrMsgBuilder);
			} else {
				// If the flow is partial
				istatMsg = build$MessagePartial(isonMsg, isonArrMsgBuilder);
			}
			// String istatMsg = getStatus();

			if (I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_SUCC)) {
				// Success
				// Adding the Main Success Message
//                	 if (isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_SUCCESS).getAsJsonObject().has(i$ResM.I_MSGTEXT))
//                         sDefMsg = isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_SUCCESS).getAsJsonObject().get(i$ResM.I_MSGTEXT).getAsString();

				if (I$utils.$iStrBlank(sDefMsg))
					sDefMsg = i$ResM.I_SUCCTEXT;
				isonMsgBuilderObj.addProperty(i$ResM.I_STATMSGCODE, i$ResM.I_SUCCWCD);
				isonMsgBuilderObj.addProperty(i$ResM.I_MSGTEXT, getDefaultMsgs(i$ResM.I_SUCCWCD, sDefMsg));
				isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "N");
				isonArrMsgBuilder.add(isonMsgBuilderObj);
			} else if (I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_WRN)) {
				// Warning
//                	 if (isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_WARNING).getAsJsonObject().has(i$ResM.I_MSGTEXT))
//                         sDefMsg = isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_WARNING).getAsJsonObject().get(i$ResM.I_MSGTEXT).getAsString();

				// Adding the Main Success Message
				if (I$utils.$iStrBlank(sDefMsg))
					sDefMsg = i$ResM.I_WRNTEXT;
				isonMsgBuilderObj.addProperty(i$ResM.I_STATMSGCODE, i$ResM.I_WRNWCD);
				isonMsgBuilderObj.addProperty(i$ResM.I_MSGTEXT, getDefaultMsgs(i$ResM.I_WRNWCD, sDefMsg));
				isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "N");
				isonArrMsgBuilder.add(isonMsgBuilderObj);
			} else if (I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_ERR)) {
				// Error
//                	 if (isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_ERROR).getAsJsonObject().has(i$ResM.I_MSGTEXT))
//                         sDefMsg = isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().get(i$ResM.I_ERROR).getAsJsonObject().get(i$ResM.I_MSGTEXT).getAsString();

				// Adding the Main Success Message
				if (I$utils.$iStrBlank(sDefMsg))
					sDefMsg = i$ResM.I_ERRTEXT;
				isonMsgBuilderObj.addProperty(i$ResM.I_STATMSGCODE, i$ResM.I_ERRWCD);
				isonMsgBuilderObj.addProperty(i$ResM.I_MSGTEXT, getDefaultMsgs(i$ResM.I_ERRWCD, sDefMsg));
				isonMsgBuilderObj.addProperty(i$ResM.I_CONFREQ, "N");
				isonArrMsgBuilder.add(isonMsgBuilderObj);
			}

			i$ResM.iHandleResStat(isonMsg, istatMsg, isonArrMsgBuilder);
			// Adding the Message Array to Final Response
//                if (I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_SUCC)) {
//                	
//                	i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, isonArrMsgBuilder); 
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().addProperty(i$ResM.I_STATTAGMSG, i$ResM.I_SUCC); //NYE022019
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_SUCCESS, isonArrMsgBuilder);
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_WARNING, isonArrMsgBlnk);
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_ERROR, isonArrMsgBlnk);
//                }
//                else if (I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_WRN)) {
//                	i$ResM.iHandleResStat(isonMsg, i$ResM.I_WRN, isonArrMsgBuilder); 
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().addProperty(i$ResM.I_STATTAGMSG, i$ResM.I_WRN); //NYE022019
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_SUCCESS, isonArrMsgBlnk);
////                 	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_WARNING, isonArrMsgBuilder);
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_ERROR, isonArrMsgBlnk);
//                }
//                else if (I$utils.$iStrFuzzyMatch(istatMsg, i$ResM.I_ERR)) {
//                	i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, isonArrMsgBuilder);
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().addProperty(i$ResM.I_STATTAGMSG, i$ResM.I_ERR); //NYE022019
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_SUCCESS, isonArrMsgBlnk);
////                	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_WARNING, isonArrMsgBlnk);
////                 	isonMsg.get(i$ResM.I_STATTAG).getAsJsonObject().add(i$ResM.I_ERROR, isonArrMsgBuilder);
//                }

		} catch (Exception e) {
			logger.debug("Failed to Build Message .." + e.getMessage());
			// return isonMsg;
			i$ResM.iHandleRes(isonMsg, i$ResM.I_ERR, i$ResM.I_ERRTEXT, "N");
			// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT
			// ALLOWED", e.getMessage().toString());
		}
		;
		return isonMsg;
	};

	private String getDefaultMsgs(String sMsgCode, String sDefText) {
		String sLang = "ENG";
		JsonObject JMsgRec = new JsonObject();
		if (I$utils.$iStrBlank(sDefText))
			sDefText = "Operation Completed Sucessfully";
		try {
			sLang = (i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("lang").getAsString()).toUpperCase()
					.trim();
		} catch (Exception e) {
			sLang = "ENG";
		}
		;

		try {
			JMsgRec = db$Ctrl.db$GetRow("ICOR_C_ISON_MSGS",
					"{\"msgCode\":\"" + sMsgCode + "\",\"lngCode\":\"" + sLang + "\"}");
			if (JMsgRec != null)
				sDefText = JMsgRec.get(i$ResM.I_MSGTEXT).getAsString();

		} catch (Exception e) {
			logger.debug("Failed to Build Message .." + e.getMessage());

		}
		return sDefText;
	};

	public boolean add$Msg(String sMsgCode, JsonArray sParamlist) { // #00000002 new overload function added
		return add$Msg(sMsgCode, sParamlist, "");
	};

	public boolean add$Msg(String sMsgCode, JsonArray sParamlist, String sDefMsg) {
		try {
			boolean isAlreadyExists = false;
			// Check if the parent exists in global
			// If so then check if conf req for this msg id .. if Y then skip the entire
			// loop
			if (!i$impactoUtil.msgCodeEntry(sMsgCode)) {
				// Check if the msg code is already in the isonMsgBuilder
				// if the isonMsgBuilder is empty .. no issues .. go forward
				// If it is not, then check for the existence .. If not found .. insert
				if (IDataValidator.J$TempStorage.get().has("isonMsgBuilder")) {

					if (i$impactoUtil.existObjFromArrWithSearch(
							IDataValidator.J$TempStorage.get().get("isonMsgBuilder").getAsJsonArray(), "msgCode",
							sMsgCode)) {
						isAlreadyExists = true;
					}

				}
				// else perform the entire function
				if (!isAlreadyExists) {
					String sLang = "ENG";
					String sMsg = "";
					JsonObject JMsgRec = new JsonObject();
					try {
						sLang = (i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("lang").getAsString())
								.toUpperCase().trim();
					} catch (Exception e) {
						sLang = "ENG";
					}
					;

					JMsgRec = db$Ctrl.db$GetRow("ICOR_C_ISON_MSGS",
							"{\"msgCode\":\"" + sMsgCode + "\",\"lngCode\":\"" + sLang + "\"}");
					try {
						sMsg = JMsgRec.get("msgText").getAsString();
					} catch (Exception e) {
						if (!I$utils.$iStrBlank(sDefMsg))
							sMsg = sDefMsg;
						else
							sMsg = "Message Text Not Maintianed";
					}
					;
					if (JMsgRec != null) {
						if (sParamlist != null && sParamlist.size() > 0) {
							for (int i = 0; i < sParamlist.size(); i++) {
								sMsg = sMsg.replaceAll("#" + i + "#", sParamlist.get(i).getAsString());
							}
						}

					} else {
						JMsgRec = new JsonObject();
						JMsgRec.addProperty("msgType", "E");
						JMsgRec.addProperty(i$ResM.I_CONFREQ, "N");
						JMsgRec.addProperty("msgCode", sMsgCode);
					}
					;
					JMsgRec.addProperty(i$ResM.I_MSGTEXT, sMsg);

					if (!IDataValidator.J$TempStorage.get().has("isonMsgBuilder"))
						IDataValidator.J$TempStorage.get().add("isonMsgBuilder", new JsonArray());

					IDataValidator.J$TempStorage.get().get("isonMsgBuilder").getAsJsonArray().add(JMsgRec);
				} else {
					return false;
				}
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.debug("Failed to Build Message .." + e.getMessage());
		}
		return true;
	}

	public boolean checkAdd$Msg(String sMsgCode) {
		try {

			/*
			 * Goal is to check 1) Check if Supp of the Msg Code 2) If Message is Already
			 * Confirmed in the parent Msg 3) If Message is Already Inserted in the
			 * isonMsgBuilder
			 * 
			 * Return false, if msgAddition Will not happen 
			 * Return true, if msgAddtion will happen
			 * 
			 */
			boolean isAlreadyExists = false;
			// Check if the parent exists in global
			// If so then check if conf req for this msg id .. if Y then skip the entire
			// loop
			boolean confRec = i$impactoUtil.msgCodeEntry(sMsgCode);
			// Check if the msg code is already in the isonMsgBuilder
			// if the isonMsgBuilder is empty .. no issues .. go forward
			// If it is not, then check for the existence .. If not found .. insert
			if (IDataValidator.J$TempStorage.get().has("isonMsgBuilder")) {

				if (i$impactoUtil.existObjFromArrWithSearch(
						IDataValidator.J$TempStorage.get().get("isonMsgBuilder").getAsJsonArray(), "msgCode",
						sMsgCode)) {
					isAlreadyExists = true;
				}

			}

			String sLang = "ENG";
			JsonObject JMsgRec = new JsonObject();
			try {
				sLang = (i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("lang").getAsString()).toUpperCase()
						.trim();
			} catch (Exception e) {
				sLang = "ENG";
			}
			;

			JMsgRec = db$Ctrl.db$GetRow("ICOR_C_ISON_MSGS",
					"{\"msgCode\":\"" + sMsgCode + "\",\"lngCode\":\"" + sLang + "\"}");
			boolean suppMsg = checkSup(JMsgRec);
			
			if(suppMsg || isAlreadyExists || confRec ) {
				return false; 
			}else {
				return true;
			}
			
		} catch (Exception e) {
			logger.debug("Failed to Build Message .." + e.getMessage());
		}
		return true;
	}

	public boolean checkSup(JsonObject isonMsgBuilder$Doc) {
		boolean bContinue = false;
		try {

			// suppAll
			if (isonMsgBuilder$Doc.has("suppAll")
					&& I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("suppAll").getAsString(), "1")) {
				return true;
			}
			;
			// suppSrc
			bContinue = false;
			if (isonMsgBuilder$Doc.has("suppSrc")
					&& I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("suppSrc").getAsString(), "1")) {
				JsonArray JTempJArray = isonMsgBuilder$Doc.get("src2Supp").getAsJsonArray();
				String sSrc = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("clientApp").getAsString();
				for (int j = 0; j < JTempJArray.size(); j++) {
					if (I$utils.$iStrFuzzyMatch(JTempJArray.get(j).getAsString(), sSrc)) {
						bContinue = true;
						break;
					}
				}
			}
			;

			if (bContinue)
				return true;
			// suppAnnote
			if (isonMsgBuilder$Doc.has("suppAnnote")
					&& I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("suppAnnote").getAsString(), "1")) {
				JsonArray JTempJArray = isonMsgBuilder$Doc.get("annote2Supp").getAsJsonArray();
				String sAnnote = i$ResM.getGobalValStr("iAnnote");
				for (int j = 0; j < JTempJArray.size(); j++) {
					if (I$utils.$iStrFuzzyMatch(JTempJArray.get(j).getAsString(), sAnnote))

					{
						bContinue = true;
						break;
					}

				}
			}
			;

			if (bContinue)
				return true;
			// suppuserID
			if (isonMsgBuilder$Doc.has("suppuserID")
					&& I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("suppuserID").getAsString(), "1")) {
				JsonArray JTempJArray = isonMsgBuilder$Doc.get("userIDs2Supp").getAsJsonArray();
				String sID = IResManipulator.iloggedUser.get();
				for (int j = 0; j < JTempJArray.size(); j++) {
					if (I$utils.$iStrFuzzyMatch(JTempJArray.get(j).getAsString(), sID))

					{
						bContinue = true;
						break;
					}
				}
			}
			;
			if (bContinue)
				return true;
			// suppsvrObj
			if (!I$utils.$iStrBlank(i$ResM.getGobalValStr("srvcname"))
					&& !I$utils.$iStrBlank(i$ResM.getGobalValStr("srvcopr")) && isonMsgBuilder$Doc.has("suppsvrObj")
					&& I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("suppsvrObj").getAsString(), "1")) {
				JsonArray JTempJArray = isonMsgBuilder$Doc.get("svrObj2Supp").getAsJsonArray();

				try {

					String srvcnameMe = i$ResM.getGobalValStr("srvcname");
					String srvcoprMe = i$ResM.getGobalValStr("srvcopr");
					String srvcopr1Me = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("srvcopr1")
							.getAsString();
					String srvcopr2Me = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("srvcopr2")
							.getAsString();
					String srvcopr3Me = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("srvcopr3")
							.getAsString();

					for (int j = 0; j < JTempJArray.size(); j++) {
						JsonObject JOTObj = JTempJArray.get(j).getAsJsonObject();
						String srvcnameOt = JOTObj.get("srvcname").getAsString();
						String srvcoprOt = JOTObj.get("srvcopr").getAsString();
						String srvcopr1Ot = JOTObj.get("srvcopr1").getAsString();
						String srvcopr2Ot = JOTObj.get("srvcopr2").getAsString();
						String srvcopr3Ot = JOTObj.get("srvcopr3").getAsString();

						if (I$utils.$iStrFuzzyMatch(srvcnameOt, srvcnameMe)
								&& I$utils.$iStrFuzzyMatch(srvcoprOt, srvcoprMe)
								&& I$utils.$iStrFuzzyMatch(srvcopr1Ot, srvcopr1Me)
								&& I$utils.$iStrFuzzyMatch(srvcopr2Ot, srvcopr2Me)
								&& I$utils.$iStrFuzzyMatch(srvcopr3Ot, srvcopr3Me))

						{
							bContinue = true;
							break;
						}
					}
				} catch (Exception ex) {
					//
				}
				;
			}
			;

			if (bContinue)
				return true;
			// suppscrObj
			if (!I$utils.$iStrBlank(i$ResM.getGobalValStr("screenid"))
					&& !I$utils.$iStrBlank(i$ResM.getGobalValStr("operation")) && isonMsgBuilder$Doc.has("scrObj2Supp")
					&& I$utils.$iStrFuzzyMatch(isonMsgBuilder$Doc.get("suppscrObj").getAsString(), "1")) {
				JsonArray JTempJArray = isonMsgBuilder$Doc.get("scrObj2Supp").getAsJsonArray();

				try {

					String screenidMe = i$ResM.getGobalValStr("screenid");
					String operationMe = i$ResM.getGobalValStr("operation");
					String operation1Me = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("operation1")
							.getAsString();
					String operation2Me = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("operation2")
							.getAsString();
					String operation3Me = i$ResM.getGobalValJObj("i-config").getAsJsonObject().get("operation3")
							.getAsString();

					for (int j = 0; j < JTempJArray.size(); j++) {
						JsonObject JOTObj = JTempJArray.get(j).getAsJsonObject();
						String screenidOt = JOTObj.get("screenid").getAsString();
						String operationOt = JOTObj.get("operation").getAsString();
						String operation1Ot = JOTObj.get("operation1").getAsString();
						String operation2Ot = JOTObj.get("operation2").getAsString();
						String operation3Ot = JOTObj.get("operation3").getAsString();

						if (I$utils.$iStrFuzzyMatch(screenidOt, screenidMe)
								&& I$utils.$iStrFuzzyMatch(operationOt, operationMe)
								&& I$utils.$iStrFuzzyMatch(operation1Ot, operation1Me)
								&& I$utils.$iStrFuzzyMatch(operation2Ot, operation2Me)
								&& I$utils.$iStrFuzzyMatch(operation3Ot, operation3Me))

						{
							bContinue = true;
							break;
						}
					}
				} catch (Exception ex) {
					//
				}
				;
			}
			;

			if (bContinue)
				return true;

		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

}
//#00000001 Ends
