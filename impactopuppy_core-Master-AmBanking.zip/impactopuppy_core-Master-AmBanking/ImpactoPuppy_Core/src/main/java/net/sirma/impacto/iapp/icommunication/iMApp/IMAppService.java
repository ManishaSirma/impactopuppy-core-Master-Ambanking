/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Nye 		| Jan 09, 2019 | #00000001   | Initial writing
      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icommunication.iMApp;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;

public class IMAppService {
	private DBController db$Ctrl = new DBController();
	private ImpactoUtil imp$utils = new ImpactoUtil();
	private Logger logger = LoggerFactory.getLogger(IMAppService.class);
	private IResManipulator i$ResM = new IResManipulator();

	public void sendIpin(JsonObject argJson) throws TwilioRestException {

		try {

			// read otpadapter conf from db
			JsonObject i$Param = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", "{\"otpadaptersettings\"=1}");
			JsonObject adptr$cnfdb = i$Param.get("otpadaptersettings").getAsJsonObject();

			// Instantiate twilio adapter
			TwilioRestClient client = new TwilioRestClient(adptr$cnfdb.get("Account SID").getAsString(),
					adptr$cnfdb.get("Auth Token").getAsString());

			// Build a filter for the MessageList
			JsonObject mob$numbers = argJson.get("mobile$numbers").getAsJsonObject();

			JsonObject template$Data = argJson.get("map$Data").getAsJsonObject();

			List<NameValuePair> params = new ArrayList<NameValuePair>();

			String mobilenumber = mob$numbers.get("Mob_Number1").getAsString();

			// read the template form db
			JsonObject i$smsltmpl = db$Ctrl.db$GetRow("ICOR_M_COMM_TEMPLATE",
					"{ Template_ID: \"" + template$Data.get("tmp$name").getAsString() + "\" }");

		
			// Building Logger Json Object
			JsonObject sms$logger = new JsonObject();
			JsonObject statusMsg = new JsonObject();

			sms$logger.addProperty("CommunicationMode", "SMS");
			sms$logger.addProperty("communicationId", imp$utils.randomAlphaNumeric(100));
			
			sms$logger.addProperty("Mobile Number", mobilenumber);
			sms$logger.add("LoggedDate", i$ResM.adddate(new Date()).getAsJsonObject());
			sms$logger.add("LastActionDate", i$ResM.adddate(new Date()).getAsJsonObject());

		

			try {
				// Trigger the otp sending
				MessageFactory messageFactory = client.getAccount().getMessageFactory();

				Message message = messageFactory.create(params);

				statusMsg.addProperty("i_SUCC", "SMS Successfully Sent");

				sms$logger.add("StatusMsg", statusMsg);

				// log details to logger
				db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger);

			} catch (Exception e) {

				statusMsg.addProperty("i_ERROR", "Email Sent Failed");

				sms$logger.add("StatusMsg", statusMsg.get("i_ERROR").getAsJsonObject());

				db$Ctrl.db$InsertRow("ICOR_M_COMMUNICATION_LOGGER", sms$logger);

				e.printStackTrace();

			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}


}
//#00000001 Ends