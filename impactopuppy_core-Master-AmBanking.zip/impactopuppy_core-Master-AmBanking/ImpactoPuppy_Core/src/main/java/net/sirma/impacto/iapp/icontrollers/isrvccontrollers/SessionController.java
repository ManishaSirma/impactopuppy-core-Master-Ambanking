/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.2.1       | Vijay 		| Jan 9, 2019  | #BVB00037   | Initial writing
      |0.2.1       | Vijay 		| Jan 11, 2019 | #BVB00038   | Same Session ID Handling. Moving from Insert to Update with Upsert. 
      |0.2.1       | Vijay 		| Jan 16, 2019 | #BVB00036   | Encryption and Decryption with RSA 
      |0.2.1       | Niegil 	| Feb 08, 2019 | #NYE00001   | Session ID handling and lastActivityAt addition 
      |0.2.1       | Vijay   	| Mar 23, 2019 | #BVB00101   | Time Zone validation
      |0.2.1       | Vijay   	| Mar 23, 2019 | #BVB00110   | CltTimeValReq added at source level for validation of time
      |0.3.6       | Vijay   	| May 04, 2019 | #BVB00143   | Dual key pair Encrypt/Decrypt from all applications 
      |0.3.16      | Vijay   	| Jul 10, 2019 | #BVB00184   | SetupParameters added to response 
      |0.3.17      | Pappu      | Mar 23, 2021 | #PKY00005   | code to add Core Version number In the response of Handshake request
      ----------------------------------------------------------------------------------------------
*/
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import net.sirma.impacto.iapp.ialgo.RSAAsymetricCrypt;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IAppMessageHandler;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;
import net.sirma.impacto.iapp.iconfig.PropLoader;  

public class SessionController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();
	private IResManipulator i$ResM = new IResManipulator();
	RSAAsymetricCrypt i$RSAAsy = new RSAAsymetricCrypt();
	private IAppMessageHandler iAppMsgHandler = new IAppMessageHandler(); 
	private Logger logger = LoggerFactory.getLogger(SessionController.class); // Nye- Change Class Name
																				// always
	   
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {

			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "handShake")) {

				// isonMsg = getKey(isonMsg); // #BVB00036 Starts
				isonMsg = getKeyRSA(isonMsg);
				
				// #PKY00005 starts
				try {
//					if(PropLoader.env.containsKey("MajorVersion") ||PropLoader.env.containsKey("MinorVersion")) {
					String versionAdd = new String();
					String majorVer = I$utils.$strValNullIf(PropLoader.env.getProperty("MajorVersion"), "");
					String minorVer = I$utils.$strValNullIf(PropLoader.env.getProperty("MinorVersion"), "");
					versionAdd = majorVer.concat(" " + minorVer);
					JsonObject iBody = isonMsg.getAsJsonObject("i-body");
					iBody.addProperty("coreVersion", versionAdd);
//				    }
				} catch (Exception e) {
//					logger.debug("Failed to add core value: " + e.getMessage());
				}
				// #PKY00005 ends


			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};

	// #BVB00036 Starts

	private JsonObject getKeyRSA(JsonObject isonMsg) {
		// Gson gson = new Gson();
		JsonObject JSessionStore = new JsonObject();
		JsonObject JSessionDetails = new JsonObject();
		// JsonObject i$Projection = new JsonObject();
		// #BVB00101 Starts
		JsonObject i$projection = new JsonObject();
		JsonObject filter = new JsonObject(); // #BVB00038
		boolean isValidTz = false;
		try {
			JsonObject i$body = i$ResM.getBody(isonMsg);
			JsonObject srcJson = i$ResM.getGobalValJObj("srcJson");
			if(I$utils.$iStrFuzzyMatch(srcJson.get("CltTimeValReq").getAsString(),"Y")) {
			//if (i$body.has("clientTime")) {
				i$projection.addProperty("timeZone", 1);
				String timeZone = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", i$projection).get("timeZone").getAsString();

				String clientTime = i$ResM.getBodyElementS(isonMsg, "clientTime");
				isValidTz = I$impactoUtil.isValidTimeZone(clientTime, timeZone);
			} else {
				isValidTz = true;
			}

			if (isValidTz) {
				// #BVB00101 Ends
				// #BVB00143 Starts 
				byte[][] keyPairD = I$impactoUtil.genKeyPairRSA();
				byte[][] keyPairE = I$impactoUtil.genKeyPairRSA();

				String publicKeySD = I$impactoUtil.base64Encode(keyPairD[0]);
				String privateKeySD = I$impactoUtil.base64Encode(keyPairD[1]);
				
				String publicKeySE = I$impactoUtil.base64Encode(keyPairE[0]);
				String privateKeySE = I$impactoUtil.base64Encode(keyPairE[1]);
				// #BVB00143 Ends
				
//				PublicKey publicKey = i$RSAAsy.getPublic(keyPair[0], 1);
//				PrivateKey privateKey = i$RSAAsy.getPrivate(keyPair[1], 1);

				String sessionId = i$ResM.getClientSessionID(isonMsg);
				JSessionStore.addProperty("sessionId", sessionId);

				JSessionStore.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());

				JSessionStore.add("lastActivityAt", i$ResM.adddate(new Date()).getAsJsonObject());// #NYE00001
				// #BVB00143 Starts 
				JSessionStore.addProperty("SVal", publicKeySD);
				JSessionStore.addProperty("PVal", privateKeySE);
				// #BVB00143 Ends
				
				JSessionDetails = JSessionStore.deepCopy();
				JSessionStore.addProperty("privateKey", privateKeySD);
				JSessionStore.addProperty("publicKeyE", publicKeySE); // #BVB00143 
				JSessionStore.addProperty("SrcID", i$ResM.getSrcId(isonMsg));
				JSessionStore.addProperty("ImeCd", i$ResM.getIME(isonMsg));
				filter = new JsonObject();
				filter.addProperty("sessionId", sessionId);
				try {
					if (I$utils.$iStrFuzzyMatch(i$ResM.getSrcId(isonMsg), "TecuDigiApp")
							|| (I$utils.$iStrFuzzyMatch(i$ResM.getSrcId(isonMsg), "TecuDigiAppIOS"))) {
						Gson gson = new Gson();
						JsonObject i$Projection = new JsonObject();
						i$Projection.addProperty("privateKey", 1);
						i$Projection.addProperty("checkRequestId", 1);
						JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(i$Projection));
						if (cParam.get("checkRequestId").getAsBoolean()) {
							String privateKey = cParam.get("privateKey").getAsString();
							if (0 < db$Ctrl.db$GetCountI("ICOR_S_SESSION_VALIDATOR", filter)) {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "DUPLICATE SESSION");
							}
							if (I$utils.$iStrFuzzyMatch(
									I$impactoUtil.decrypt(i$ResM.getBodyElementS(isonMsg, "requestId"), privateKey),
									i$ResM.getTranId(isonMsg))) {
								JsonArray requestId = new JsonArray();
								requestId.add(i$ResM.getBodyElementS(isonMsg, "tranId"));
								JSessionStore.add("requestId", requestId);
							} else {
								return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
										"SESSION GENERATION FAILED");
							}
						}
					}
				} catch (Exception e) {
				}
				db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", JSessionStore, filter, "true");
				// #BVB00184 Starts 
				try {
				JSessionDetails.add("SetupParameters", srcJson.get("SetupParameters").getAsJsonObject());
				}catch (Exception e) {
					JSessionDetails.add("SetupParameters", new JsonObject());
				}
				// #BVB00184 Ends
				isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, JSessionDetails);
				//isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SESSION KEY RETURNED SUCESSFULLY");
				iAppMsgHandler.add$Msg("12121213", new JsonArray()); 
			}
			// #BVB00101 Starts
			else {
				iAppMsgHandler.add$Msg("12121214", new JsonArray());
				//isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVLAID TIMEZONE DETECTED");
				
			}		
			// #BVB00101 Ends
		} catch (Exception e) {
			logger.debug("Failed in GetKey with error: " + e.getMessage());
			iAppMsgHandler.add$Msg("12121215", new JsonArray());
			// isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SESSION KEY GENERATION FAIL");

		}

		return isonMsg;
	}

	// #BVB00036 Ends
	private JsonObject getKey(JsonObject isonMsg) {
		Gson gson = new Gson();
		JsonObject JSessionStore = new JsonObject();
		JsonObject JSessionDetails = new JsonObject();
		JsonObject i$Projection = new JsonObject();
		JsonObject filter = new JsonObject(); // #BVB00038

		try {
			i$Projection.addProperty("keyLength", 1);
			i$Projection.addProperty("privateKey", 1);
			JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(i$Projection));

			int length = cParam.get("keyLength").getAsInt();
			String privateKey = cParam.get("privateKey").getAsString();
			String sessionId = i$ResM.getClientSessionID(isonMsg);
			JSessionStore.addProperty("sessionId", sessionId);

			JSessionStore.add("createdAt", i$ResM.adddate(new Date()).getAsJsonObject());
			String sessionKey = I$utils.$randomAplhanumeric(length);

			// Adding code for Encryption
			String sessionKeyE = I$impactoUtil.encrypt(sessionKey, privateKey);

			JSessionStore.addProperty("sessionKey", sessionKeyE);
			JSessionDetails = JSessionStore.deepCopy();
			JSessionStore.addProperty("sessionKeyVal", sessionKey);

			// #BVB00038 Starts
			// db$Ctrl.db$InsertRow("ICOR_S_SESSION_VALIDATOR", JSessionStore);
			filter = new JsonObject();
			filter.addProperty("sessionId", sessionId);
			db$Ctrl.db$UpdateRow("ICOR_S_SESSION_VALIDATOR", JSessionStore, filter, "true");
			// #BVB00038 Ends

			isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, JSessionDetails);
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "SESSION KEY RETURNED SUCESSFULLY");

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in GetKey with error: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SESSION KEY GENERATION FAIL");

		}

		return isonMsg;
	};

}