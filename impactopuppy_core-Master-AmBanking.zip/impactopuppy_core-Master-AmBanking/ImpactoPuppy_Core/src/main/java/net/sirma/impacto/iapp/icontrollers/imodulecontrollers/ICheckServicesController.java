/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.4.1.367  | BHUVI 		| AUg 29, 2019 | #BHUVI001   |  Controller for checking Service is up or not
      |2.0.0.0    | BHUVI 		| Sep 09, 2019 | #BHUVI002   |  Call to url changes 
      |2.0.0.0    | BHUVI 		| Sep 09, 2019 | #BHUVI003   |  Screen id changes to L 


      ----------------------------------------------------------------------------------------------
      
*/
// #BHUVI001 Starts

package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import java.io.IOException;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonObject;
import com.itextpdf.text.log.SysoCounter;

import net.sirma.impacto.iapp.icommunication.iextcommunicator.IExtWSLauncher;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ICheckServicesController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

		private Ioutils I$utils = new Ioutils();
		private IResManipulator i$ResM = new IResManipulator();
		private ImpactoUtil i$impactoUtil = new ImpactoUtil();
		private IExtWSLauncher I$EWSLnchr = new IExtWSLauncher();
		private DBController db$Ctrl = new DBController();
		private Logger logger = LoggerFactory.getLogger(ICheckServicesController.class); // #00000002 - Change
	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) { 
		try {
			String SOpr = i$ResM.getOpr(isonMsg);
			String Scr = i$ResM.getScreenID(isonMsg);
			if (I$utils.$iStrFuzzyMatch(Scr, "LB2CHSRC") && I$utils.$iStrFuzzyMatch(SOpr, "QUERY")) { // #BHUVI003 Added
				isonMsg = CheckService(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(Scr, "OB2CHSRC") && I$utils.$iStrFuzzyMatch(SOpr, "CREATE")) {
				//isonMsg = CheckService(isonMsg);
			}
			else {

				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED");
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	}

	private JsonObject CheckService(JsonObject isonMsg) {
		try {
             
			JsonObject i$body=i$ResM.getBody(isonMsg);
			String serviceType=i$body.get("type").getAsString();
//			    if(getStatus(serviceType))
				if(true)
			    {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Service is Available ");
			    }
			    else
			    {
			    	isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Service is Not Available");
			    }
			
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Failed to Fetch Service Status");
			e.getMessage();
			return isonMsg;
		}
		return isonMsg;
	}
	
	public boolean getStatus(String Type) throws IOException {
		try {
			// #BHUVI002 Starts             
		/*	JsonObject JResp = new JsonObject();

			JsonObject headerTags= new JsonObject();
			JsonObject argjson = new JsonObject();
			argjson.addProperty("mediaType", "application/json");
			argjson.addProperty("requestType", "GET");
			argjson.add("headerTags", headerTags);
			argjson.addProperty("extUrl", url);
			argjson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
			
			JResp = I$EWSLnchr.ILaunchReq(argjson);
			String resCode=JResp.get("resCode").getAsString(); 
			if(resCode.equalsIgnoreCase("404"))
			{
				return false;
			}
			else {
				return true;
			}*/
			JsonObject argJson = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject JResp = new JsonObject();
			if(Type.equalsIgnoreCase("Quartz"))
			{
			filter.addProperty("trnCd", "serviceQuartz");
			argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
			argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

			JResp = I$EWSLnchr.ILaunchReq(argJson);
			String resCode = JResp.get("resCode").getAsString();
			logger.debug("Response from the Quartz: "  + resCode);
			if(resCode.equalsIgnoreCase("401"))
			{
				return true;
			}
			else {
				return false;
			}
			}
			else if(Type.equalsIgnoreCase("bridge"))
			{
			    System.out.println("");
				filter.addProperty("trnCd", "serviceBridge");
				argJson = db$Ctrl.db$GetRow("ICOR_C_WS_TRANSMITTER", filter);
				argJson.addProperty("unqCommID", i$impactoUtil.generateRandomKey());

				JResp = I$EWSLnchr.ILaunchReq(argJson);
				String resCode = JResp.get("resCode").getAsString();
				logger.debug("Response from the Bridge: "  + resCode);
				if(resCode.equalsIgnoreCase("401"))
				{
					return true;
				}
				else {
					return false;
				}
			}
			// #BHUVI002 Ends
		} catch (Exception e) {
			e.printStackTrace();
			return false;
 
		}
		return false;
		
	}
	
	
	
}
// #BHUVI001 Ends