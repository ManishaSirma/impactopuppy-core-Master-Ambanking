/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Niegil 		| Sep 4, 2018  | #00000001   | Initial writing
      |0.1 Beta    | Vijay 			| Sep 28, 2018 | #BVB00005   | Added more functions
      |0.1 Beta    | Vijay 			| Dec 09, 2018 | #BVB00023   | Added more functions  
      |0.1.6       | Vijay 			| Dec 14, 2018 | #BVB00030   | Adding function for QueryAgg
      |0.1.7       | Niegil 		| Jan 09, 2019 | #00000002   | Added GridFS Functions
      |0.1.7       | Niegil 		| Jan 16, 2019 | #00000003   | Added Sort Option for MongoQuery
      |0.2.1       | Syed	 		| Jan 21, 2019 | #MAQ00001   | Added skip and limit to QueryAgg()
      |0.2.1       | Syed	 		| Jan 24, 2019 | #MAQ00002   | Added mongoAggregate() from iBridge
      |0.2.1       | Vijay 		    | Feb 14, 2019 | #BVB00058   | GetRow function with Object Id
      |0.2.1       | Vijay 		    | Feb 09, 2019 | #BVB00052   | UpdateMany Functions
      |0.3.6       | Vijay 		    | Apr 15, 2019 | #BVB00113   | Making DMS a 2 step with ID as immediate response and later processing
      |0.3.7       | Vijay 		    | May 02, 2019 | #BVB00137   | Adding handling for queryFilter coming as String
      |0.3.7       | Vijay 		    | May 05, 2019 | #BVB00131   | Aggregate accepting array and executing directly
      |0.3.15.293  | Syed 			| Jun 21, 2019 | #MAQ00020   | Changed Gson to Gson Builder 
      |0.3.7       | Vijay 		    | May 05, 2019 | #BVB00131   | Aggregate accepting array and executing directly 
      |0.3.14.283  | Bhuvi 		    | June 19,2019 | #BHUVI001   | Added skip Absolute to skip manually 
      |0.3.14.283  | Bhuvi 		    | June 19,2019 | #BHUVI002   | Added bulk update by passing Array with where condition($in)
      |0.3.14.327  | Bhuvi 		    | Jul 25, 2019 | #BHUVI003   | Added get distinct from db
      |0.3.14.327  | Baz 		    | Aug 17, 2019 | #00000045   | Revamp Sort code for Query Operation
      |3.2.5.446   | Pruthvi        | Mar 09, 2020 | #YPR00001   | update function for $addToSet modifier
      |3.2.5.446   | Pruthvi        | Mar 12, 2020 | #YPR00002   | update condition for $push modifier
      |3.2.5.446   | Pruthvi        | Apr 06, 2020 | #YPR00008   | update condition for $pull modifier
      |3.2.5.446   | Pappu          | Dec 14, 2021 | #PKY00065   | added condition for $inc modifier
      |3.2.5.446   | Manikanta      | Mar 08, 2022 | #MVT00039   | added code to upload scanned data in fs files
      |3.2.5.446   | Manikanta      | Mar 08, 2022 | #MVT00041   | Added code to download the scanned data from fs files
      |3.2.5.446   | Manikanta 	 	| Mar 08, 2022 | #MVT00043   | Added code to call the upload and download functions
      |3.2.5.446   | Manikanta      | Mar 10, 2022 | #MVT00047   | Added code send the download response from fs files
      |3.2.5.446   | Tarun          | Aug 25, 2022 | #TKS00011   | Added try catch block for metadata fields
      |3.2.5.446   | Tarun          | Sep 01, 2022 | #TKS00012   | Added fields for the metadata
      |3.2.5.446   | Sindhu         | Mar 22, 2023 | #SRM00031   | Added code for separating fileName
      |3.2.5.446   | Sumit          | APR 26, 2023 | #SKG00001   | added code for Remarks reflecting in other party workspace
      |3.2.5.446   | Sumit          | APR 26, 2023 | #SKG00004   | Handled remark is reflecting in manaula workspace 

      ----------------------------------------------------------------------------------------------
      
*/
// #00000001 Begins
package net.sirma.impacto.iapp.iworkers.idbworkers;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mongodb.BasicDBObject;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.GridFSDownloadStream;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.FindOneAndUpdateOptions;
import com.mongodb.client.model.ReturnDocument;
import com.mongodb.client.model.UpdateOptions;

import ch.qos.logback.classic.db.names.ColumnName;
import net.sirma.impacto.iapp.iconfig.MongoConfig;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class ImongoWorker {
	private Logger logger = LoggerFactory.getLogger(ImongoWorker.class);
	private Ioutils I$utils = new Ioutils();
	private IResManipulator I$ResMan = new IResManipulator();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private MongoConfig i$mongoConfig = new MongoConfig();
	// #00000002 Beginsi$Ecl

	// Mongo GrdFS Download Function
	private JsonObject mongoGrdFSDwldB24(JsonObject argJson, JsonObject reqJson) {
		GridFSDownloadStream downloadStream = null;
		ByteArrayOutputStream outputStream = null;
		try {
			MongoDatabase db = MongoConfig.getMongoDB();
			GridFSBucket grid$FS = GridFSBuckets.create(db);
			JsonObject i$body = reqJson.get("i-body").getAsJsonObject();
			// ObjectId fileId = new ObjectId(i$body.get("FileUrlToken").getAsString()); //
			// #BVB00113
			ObjectId fileId = new ObjectId(i$body.get("FileUrlId").getAsString()); // #BVB00113
			downloadStream = grid$FS.openDownloadStream(fileId);
			outputStream = new ByteArrayOutputStream();
			int data = downloadStream.read();
			while (data >= 0) {
				outputStream.write((char) data);
				data = downloadStream.read();
			}
			String base64String = Base64.encodeBase64String(outputStream.toByteArray());
			I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileContent", base64String);
			try {
				downloadStream.close();
			} catch (Exception ex) {
				// Eat up
			}
			try {
				outputStream.close();
			} catch (Exception ex) {
				// Eat up
			}
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "FILE FETCHED SUCCESSFULLY");
			return reqJson;
		} catch (Exception e) {
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO FETCH FILE",
					e.getMessage().toString());
			e.printStackTrace();
		} finally {
			try {
				downloadStream.close();
			} catch (Exception ex) {
				// Eat up
			}
			try {
				outputStream.close();
			} catch (Exception ex) {
				// Eat up
			}
		}
		return reqJson;
	};

	//#MVT00041 starts
		private JsonObject mongoGrdFSScanDwld(JsonObject argJson, JsonObject reqJson) {
			GridFSDownloadStream downloadStream = null;
			ByteArrayOutputStream outputStream = null;
			try {
				MongoDatabase db = MongoConfig.getMongoDB();
				GridFSBucket grid$FS = GridFSBuckets.create(db);
				
				JsonObject i$body = reqJson.getAsJsonObject("i-body");	//#MVT00047 changes starts
				String scanId = i$body.get("scanId").getAsString();
				downloadStream = grid$FS.openDownloadStream(scanId);
				outputStream = new ByteArrayOutputStream();
				int data = downloadStream.read();
				while (data >= 0) {
					outputStream.write((char) data);
					data = downloadStream.read();
				}
				String baseString = new String(outputStream.toByteArray());
				I$ResMan.setGobalVals("scanId", scanId);
				I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileContent", baseString);	//#MVT00047 changes ends
				try {
					downloadStream.close();
				} catch (Exception ex) {
					// Eat up
				}
				try {
					outputStream.close();
				} catch (Exception ex) {
					// Eat up
				}
				reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "FILE FETCHED SUCCESSFULLY");
				return reqJson;
			} catch (Exception e) {
				reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO FETCH FILE",
						e.getMessage().toString());
				e.printStackTrace();
			}
			finally {
				try {
					downloadStream.close();
				} catch (Exception ex) {
					// Eat up
				}
				try {
					outputStream.close();
				} catch (Exception ex) {
					// Eat up
				}

			}
			return reqJson;	
		}	//#MVT00041 ends
	private JsonObject mongoGrdFSDwld(JsonObject argJson, JsonObject reqJson) {
		GridFSDownloadStream downloadStream = null;
		ByteArrayOutputStream outputStream = null;
		try {
			MongoDatabase db = MongoConfig.getMongoDB();
			GridFSBucket grid$FS = GridFSBuckets.create(db);
			JsonObject i$body = reqJson.get("i-body").getAsJsonObject();
//			 ObjectId fileId = new ObjectId(i$body.get("FileUrlToken").getAsString());
			ObjectId fileId = new ObjectId(i$body.get("FileUrlId").getAsString());
			downloadStream = grid$FS.openDownloadStream(fileId);
			outputStream = new ByteArrayOutputStream();
			int data = downloadStream.read();
			while (data >= 0) {
				outputStream.write((char) data);
				data = downloadStream.read();
			}
			String baseString = new String(outputStream.toByteArray());
			I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileContent", baseString);
			try {
				downloadStream.close();
			} catch (Exception ex) {
				// Eat up
			}
			try {
				outputStream.close();
			} catch (Exception ex) {
				// Eat up
			}
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "FILE FETCHED SUCCESSFULLY");
			return reqJson;
		} catch (Exception e) {
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO FETCH FILE",
					e.getMessage().toString());
			e.printStackTrace();
		} finally {
			try {
				downloadStream.close();
			} catch (Exception ex) {
				// Eat up
			}
			try {
				outputStream.close();
			} catch (Exception ex) {
				// Eat up
			}

		}
		return reqJson;
	};

	//#MVT00039 starts
		private JsonObject mongoGrdFSScanReqUpld(JsonObject argJson, JsonObject reqJson) {
			try {
				MongoDatabase db = MongoConfig.getMongoDB();
				GridFSBucket grid$FS = GridFSBuckets.create(db);

				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
				Gson gson = new GsonBuilder().serializeNulls().create();
				Date now = new Date();
				String strDate2 = sdf2.format(now);
				InputStream streamToUploadFrom = null;
				String scanId = reqJson.get("scanId").getAsString();

				streamToUploadFrom = new ByteArrayInputStream(
						gson.toJson(reqJson.get("MsgData").getAsJsonObject()).getBytes("UTF-8"));
				UUID uuid = UUID.randomUUID();
				String sAccessTk = String.valueOf(uuid);

				Map<String, Object> mapMetadat = new LinkedHashMap<String, Object>();
				mapMetadat.put("Msg-id", scanId);
				mapMetadat.put("AccessToken", scanId);
				mapMetadat.put("StorageType", "I-LOGGER");
				mapMetadat.put("UpldSrc", "IMPACTO-LOGGER");
				mapMetadat.put("UpldSvrDateTime", strDate2);
				mapMetadat.put("FileUrlToken", sAccessTk);

				GridFSUploadOptions grid$FSOpts = new GridFSUploadOptions().chunkSizeBytes(15988888)
						.metadata(new Document(mapMetadat));

				ObjectId fileId = grid$FS.uploadFromStream(scanId, streamToUploadFrom, grid$FSOpts);
				I$ResMan.setGobalVals("scanId", scanId);
				I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson, "scanId", scanId);
				I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson, "MsgLocateToken", fileId.toString());
				I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, reqJson, "MsgData");
				reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "REQ LOGGED SUCCESSFULLY");
				return reqJson;
			} catch (Exception e) {
				reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO LOG REQ", e.getMessage().toString());
				e.printStackTrace();
			}
			return reqJson;
		}	//#MVT00039 ends
	// Mongo GrdFS Upload Function

	private JsonObject mongoGrdFSReqUpld(JsonObject argJson, JsonObject reqJson) {
		try {
			MongoDatabase db = MongoConfig.getMongoDB();
			GridFSBucket grid$FS = GridFSBuckets.create(db);

			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
			Date now = new Date();
			String strDate2 = sdf2.format(now);
			InputStream streamToUploadFrom = null;
			// Get the input stream
			streamToUploadFrom = new ByteArrayInputStream(reqJson.get("MsgData").getAsString().getBytes("UTF-8"));

			Map<String, Object> mapMetadat = new LinkedHashMap<String, Object>();

			mapMetadat.put("Msg-id", I$utils.$strValNullIf(reqJson.get("msg-id").getAsString(), "XXXXX"));
			mapMetadat.put("AccessToken", reqJson.get("msg-id").getAsString());
			mapMetadat.put("StorageType", "I-LOGGER");
			mapMetadat.put("UpldSrc", "IMPACTO-LOGGER");
			mapMetadat.put("UpldSvrDateTime", strDate2);

			GridFSUploadOptions grid$FSOpts = new GridFSUploadOptions().chunkSizeBytes(15988888)
					.metadata(new Document(mapMetadat));

			ObjectId fileId = grid$FS.uploadFromStream(reqJson.get("msg-id").getAsString(), streamToUploadFrom,
					grid$FSOpts);
			I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson, "MsgLocateToken", fileId.toString());
			I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, reqJson, "MsgData");
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "REQ LOGGED SUCCESSFULLY");
			return reqJson;
		} catch (Exception e) {
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO LOG REQ", e.getMessage().toString());
			e.printStackTrace();
		}
		return reqJson;
	};

	private JsonObject mongoMultiGrdUpld(JsonObject argJson , JsonObject reqJson) {
		try {
			MongoDatabase db = MongoConfig.getMongoDB();
			GridFSBucket grid$FS = GridFSBuckets.create(db);
			JsonObject i$body = reqJson.getAsJsonObject("i-body");
			JsonArray fileUrlIds = new JsonArray();
			// Gen Access token
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			Date now = new Date();
			String strDate = sdf.format(now);
			String strDate2 = sdf2.format(now);
			UUID uuid = UUID.randomUUID();
			String sAccessTk = String.valueOf(uuid) + strDate.replaceAll("\\s", "");
			// Get the input stream
			for(int i = 0 ; i < i$body.get("files").getAsJsonArray().size() ; i++) {
				InputStream streamToUploadFrom = new ByteArrayInputStream(
						i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("I#FileData").getAsString().getBytes("UTF-8"));
				I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body.get("files").getAsJsonArray().get(i).getAsJsonObject(), "AccessToken", sAccessTk);

				Map<String, Object> mapMetadat = new LinkedHashMap<String, Object>();
				//#TKS00011 starts
				try {
					mapMetadat.put("AccessToken", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("AccessToken").getAsString(), sAccessTk));
				}catch(Exception e) {}
				try {//MSA Starts
		                String[] tokens = null;
		                String filName = null;
		                JsonArray files = i$body.get("files").getAsJsonArray();
//		                for(int j=0 ; j<= files.size();j++) {
//							JsonObject currObj = files.get(j).getAsJsonObject();
		                
							if (i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileName").getAsString().contains(".")) {
								String fileName = i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileName").getAsString();
								tokens = fileName.split("\\.(?=[^\\.]+$)");
								filName = tokens[0]; // MSA ends
							} else {
								filName = i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileName").getAsString();
//										filName = currObj.get("FileName").getAsString(); // SRM00031 Changes
							}
							mapMetadat.put("FileName", filName);
//		                }
					
				}catch(Exception e) {}
				try {
					mapMetadat.put("FileExtn", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileExtn").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("FileSize", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileSize").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("LinkedCustNo", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("LinkedCustNo").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocType", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocType").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocNo", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocNo").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocVersion", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocVersion").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocSubVersion", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocSubVersion").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocIssueDt", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocIssueDt").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocExpiryDt", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocExpiryDt").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocIssueAuthority",
							I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocIssueAuthority").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Compressed", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Compressed").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("OriginalFileName", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("OriginalFileName").getAsString(),
							i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileName").getAsString()));
				}catch(Exception e) {}
				try {
					mapMetadat.put("UpldIP", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("UpldIP").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("UpldIP", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("UpldIP").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("UpldSrc", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("UpldSrc").getAsString(), "IMPACTO"));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key1", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key1").getAsString(), sAccessTk));;
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key2", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key2").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key3", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key3").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key4", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key4").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key5", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key5").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key6", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key6").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("StorageType", "I-DMS");
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key7", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key7").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key8", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key8").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key9", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key9").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("Key10", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("Key10").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("TmpStorageRec", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("TmpStorageRec").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocParentGrpID1", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocParentGrpID1").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocParentGrpID2", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocParentGrpID2").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocParentGrpID3", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocParentGrpID3").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocParentGrpID4", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocParentGrpID4").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocSubGrpID1", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocSubGrpID1").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocSubGrpID2", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocSubGrpID2").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocSubGrpID3", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocSubGrpID3").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocSubGrpID4", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocSubGrpID4").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("UpldDateTime", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("UpldDateTime").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("DocPlaceIssue", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("DocPlaceIssue").getAsString(), ""));
				}catch(Exception e) {}
				try {
					mapMetadat.put("fileKey", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("fileKey").getAsString(), ""));
				}catch(Exception e) {}
				try {
					if(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().has("isPswrdPrctd")) {
						mapMetadat.put("isPswrdPrctd", i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("isPswrdPrctd").getAsBoolean());
					}
					
				}catch(Exception e) {
					//mapMetadat.put("isPswrdPrctd", true);
				}
				try {
					//mapMetadat.put("FileUrlToken", I$utils.$strValNullIf(i$body.get("FileUrlToken").getAsString(), ""));
					mapMetadat.put("FileUrlToken", i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("FileUrlToken").getAsString());
				}catch(Exception e) {}
				try {
					mapMetadat.put("isCurrVer", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("isCurrVer").getAsString(), ""));
				}catch(Exception e) {
					mapMetadat.put("isCurrVer",  "Y");
				}//#TKS00012 changes
				try {
					mapMetadat.put("parentFolderId", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("parentFolderId").getAsString(), ""));
				}catch(Exception e) {
				}
				
				try {//#SKG00001 changes
					mapMetadat.put("remarks", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("AddlFld1").getAsString(), ""));
				}catch(Exception e) {
				}
				try {
	                mapMetadat.put("folderIdPath", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("folderIdPath").getAsString(), ""));//#TKS00003 changes
	            }catch(Exception e) {
	            }
				try {//#TKS00012 changes
					mapMetadat.put("workspaceId", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("workspaceId").getAsString(), ""));
				}catch(Exception e) {
				}
				try {//#TKS00012 changes
					mapMetadat.put("parentFolderName", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("parentFolderName").getAsString(), ""));
				}catch(Exception e) {
				}
				try {//#TKS00012 changes
					mapMetadat.put("tags", new Gson().fromJson(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("tags").getAsJsonArray(), ArrayList.class));
					//mapMetadat.put("tags", i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("tags").getAsJsonArray());//#TKS00003 changes
				}catch(Exception e) {
				}
				try {//#TKS00014 changes
					mapMetadat.put("verNo", I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("verNo").getAsString(), ""));//#TKS00003 changes
				}catch(Exception e) {
				}
				if(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().has("initiator")) {//#TKS00010 changes
					mapMetadat.put("initiator" , I$utils.$strValNullIf(i$body.get("files").getAsJsonArray().get(i).getAsJsonObject().get("initiator").getAsString(), ""));
				}else {
					mapMetadat.put("initiator" , IResManipulator.iloggedUser.get());
				}

				//#TKS00011 ends
				mapMetadat.put("UpldSvrDateTime", strDate2);
				GridFSUploadOptions grid$FSOpts = new GridFSUploadOptions().chunkSizeBytes(5000000)
						.metadata(new Document(mapMetadat));

				ObjectId fileId = grid$FS.uploadFromStream(sAccessTk, streamToUploadFrom, grid$FSOpts);
				fileUrlIds.add(fileId.toString());
			}
			
			// I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileUrlToken",
			// fileId.toString());// #BVB00113
			I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileUrlIds", fileUrlIds); // #BVB00113
			I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, i$body, "I#FileData");
			reqJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson, I$ResMan.I_BDYTAG, i$body);
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "FILE UPLOADED SUCCESSFULLY");
			return reqJson;
		}catch(Exception e) {
			
		}
		return reqJson;
	}
	
	
	private JsonObject mongoGrdFSUpld(JsonObject argJson, JsonObject reqJson) {
		try {
			MongoDatabase db = MongoConfig.getMongoDB();
			GridFSBucket grid$FS = GridFSBuckets.create(db);
			JsonObject i$body = reqJson.getAsJsonObject("i-body");

			// Gen Access token
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			Date now = new Date();
			String strDate = sdf.format(now);
			String strDate2 = sdf2.format(now);
			UUID uuid = UUID.randomUUID();
			String sAccessTk = String.valueOf(uuid) + strDate.replaceAll("\\s", "");
			// Get the input stream
			InputStream streamToUploadFrom = new ByteArrayInputStream(
					i$body.get("I#FileData").getAsString().getBytes("UTF-8"));
			I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "AccessToken", sAccessTk);

			Map<String, Object> mapMetadat = new LinkedHashMap<String, Object>();
			//#TKS00011 starts
			try {
				mapMetadat.put("AccessToken", I$utils.$strValNullIf(i$body.get("AccessToken").getAsString(), sAccessTk));
			}catch(Exception e) {}
			try { //MSA Starts
				String[] tokens = null;
				String filName = null;
				if (i$body.get("FileName").getAsString().contains(".")) {
					String fileName = I$utils.fetchValueFromJsonObj(i$body, "FileName", ""); 
					tokens = fileName.split("\\.(?=[^\\.]+$)");
					filName = tokens[0]; //MSA ends
				} else {
					filName = i$body.get("FileName").getAsString();  // SRM00031 Changes
				}
				mapMetadat.put("FileName", filName);
			}catch(Exception e) {}
			try {
				mapMetadat.put("FileExtn", I$utils.$strValNullIf(i$body.get("FileExtn").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("FileSize", I$utils.$strValNullIf(i$body.get("FileSize").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("LinkedCustNo", I$utils.$strValNullIf(i$body.get("LinkedCustNo").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocType", I$utils.$strValNullIf(i$body.get("DocType").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocNo", I$utils.$strValNullIf(i$body.get("DocNo").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocVersion", I$utils.$strValNullIf(i$body.get("DocVersion").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocSubVersion", I$utils.$strValNullIf(i$body.get("DocSubVersion").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocIssueDt", I$utils.$strValNullIf(i$body.get("DocIssueDt").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocExpiryDt", I$utils.$strValNullIf(i$body.get("DocExpiryDt").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocIssueAuthority",
						I$utils.$strValNullIf(i$body.get("DocIssueAuthority").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Compressed", I$utils.$strValNullIf(i$body.get("Compressed").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("OriginalFileName", I$utils.$strValNullIf(i$body.get("OriginalFileName").getAsString(),
						i$body.get("FileName").getAsString()));
			}catch(Exception e) {}
			try {
				mapMetadat.put("UpldIP", I$utils.$strValNullIf(i$body.get("UpldIP").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("UpldIP", I$utils.$strValNullIf(i$body.get("UpldIP").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("UpldSrc", I$utils.$strValNullIf(i$body.get("UpldSrc").getAsString(), "IMPACTO"));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key1", I$utils.$strValNullIf(i$body.get("Key1").getAsString(), sAccessTk));;
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key2", I$utils.$strValNullIf(i$body.get("Key2").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key3", I$utils.$strValNullIf(i$body.get("Key3").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key4", I$utils.$strValNullIf(i$body.get("Key4").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key5", I$utils.$strValNullIf(i$body.get("Key5").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key6", I$utils.$strValNullIf(i$body.get("Key6").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("StorageType", "I-DMS");
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key7", I$utils.$strValNullIf(i$body.get("Key7").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key8", I$utils.$strValNullIf(i$body.get("Key8").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key9", I$utils.$strValNullIf(i$body.get("Key9").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("Key10", I$utils.$strValNullIf(i$body.get("Key10").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("TmpStorageRec", I$utils.$strValNullIf(i$body.get("TmpStorageRec").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocParentGrpID1", I$utils.$strValNullIf(i$body.get("DocParentGrpID1").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocParentGrpID2", I$utils.$strValNullIf(i$body.get("DocParentGrpID2").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocParentGrpID3", I$utils.$strValNullIf(i$body.get("DocParentGrpID3").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocParentGrpID4", I$utils.$strValNullIf(i$body.get("DocParentGrpID4").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocSubGrpID1", I$utils.$strValNullIf(i$body.get("DocSubGrpID1").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocSubGrpID2", I$utils.$strValNullIf(i$body.get("DocSubGrpID2").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocSubGrpID3", I$utils.$strValNullIf(i$body.get("DocSubGrpID3").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocSubGrpID4", I$utils.$strValNullIf(i$body.get("DocSubGrpID4").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("UpldDateTime", I$utils.$strValNullIf(i$body.get("UpldDateTime").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("DocPlaceIssue", I$utils.$strValNullIf(i$body.get("DocPlaceIssue").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("fileKey", I$utils.$strValNullIf(i$body.get("fileKey").getAsString(), ""));
			}catch(Exception e) {}
			try {
				if(i$body.has("isPswrdPrctd")) {
					mapMetadat.put("isPswrdPrctd", i$body.get("isPswrdPrctd").getAsBoolean());
				}
				
			}catch(Exception e) {
				//mapMetadat.put("isPswrdPrctd", true);
			}
			try {
				mapMetadat.put("FileUrlToken", I$utils.$strValNullIf(i$body.get("FileUrlToken").getAsString(), ""));
			}catch(Exception e) {}
			try {
				mapMetadat.put("isCurrVer", I$utils.$strValNullIf(i$body.get("isCurrVer").getAsString(), ""));
			}catch(Exception e) {
				mapMetadat.put("isCurrVer",  "Y");
			}//#TKS00012 changes
			try {
				mapMetadat.put("parentFolderId", I$utils.$strValNullIf(i$body.get("parentFolderId").getAsString(), ""));
			}catch(Exception e) {
			}
			try {
                mapMetadat.put("folderIdPath", I$utils.$strValNullIf(i$body.get("folderIdPath").getAsString(), ""));//#TKS00003 changes
            }catch(Exception e) {
            }
			try {//#TKS00012 changes
				mapMetadat.put("workspaceId", I$utils.$strValNullIf(i$body.get("workspaceId").getAsString(), ""));
			}catch(Exception e) {
			}
			try {//#TKS00012 changes
				mapMetadat.put("parentFolderName", I$utils.$strValNullIf(i$body.get("parentFolderName").getAsString(), ""));
			}catch(Exception e) {
			}
			try {//#TKS00012 changes
				mapMetadat.put("tags", new Gson().fromJson(I$ResMan.getBodyElementToS(reqJson,"tags" , ""), ArrayList.class));//#TKS00003 changes
			}catch(Exception e) {
			}
			try {//#TKS00014 changes
				mapMetadat.put("verNo", I$utils.$strValNullIf(i$body.get("verNo").getAsString(), ""));//#TKS00003 changes
			}catch(Exception e) {
			}
			try {// #SKG00004 changes
				mapMetadat.put("remarks", I$utils.$strValNullIf(i$body.get("remarks").getAsString(), ""));//SKG00002 changes
			}catch(Exception e) {
			}
			if(i$body.has("initiator")) {//#TKS00010 changes
				mapMetadat.put("initiator" , I$utils.$strValNullIf(i$body.get("initiator").getAsString(), ""));
			}else {
				mapMetadat.put("initiator" , IResManipulator.iloggedUser.get());
			}

			//#TKS00011 ends
			mapMetadat.put("UpldSvrDateTime", strDate2);
			GridFSUploadOptions grid$FSOpts = new GridFSUploadOptions().chunkSizeBytes(5000000)
					.metadata(new Document(mapMetadat));

			ObjectId fileId = grid$FS.uploadFromStream(sAccessTk, streamToUploadFrom, grid$FSOpts);
			// I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileUrlToken",
			// fileId.toString());// #BVB00113
			I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, i$body, "FileUrlId", fileId.toString()); // #BVB00113
			I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, i$body, "I#FileData");
			reqJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, reqJson, I$ResMan.I_BDYTAG, i$body);
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_SUCC, "FILE UPLOADED SUCCESSFULLY");
			return reqJson;
		} catch (Exception e) {
			reqJson = I$ResMan.iHandleResStat(reqJson, I$ResMan.I_ERR, "FAILED TO UPLOAD FILE",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return reqJson;
	};

	// #00000002 Ends

	// Mongo RandomDoc Function
	private JsonObject mongoRandDoc(JsonObject argJson, JsonObject resJson) {
		MongoDatabase db = MongoConfig.getMongoDB();
		MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
		String recSize = I$utils.strip$Dquote(argJson.get("SampleSize").getAsString());
		Document expFields = new Document("size", Integer.valueOf(recSize));

		// run aggregation

		AggregateIterable<org.bson.Document> output = dbColl
				.aggregate(Arrays.asList(new Document("$sample", expFields)));

//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonArray datarow = new JsonArray();
		MongoCursor<Document> dbDCurVal = output.iterator();
		while (dbDCurVal.hasNext()) {
			JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
			datarow.add(jsonElement);
		}

		resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);
		resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
		return resJson;
	};

	// Mongo Top - User Top 1 From MAX
	private JsonObject mongoTop(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		int recSize = -1; // Sent -1 for all Rows
		String queryfilter, sortBy;
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				recSize = argJson.get("recSize").getAsInt();
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "REC SIZE NOT PROVIDED OR INVALID",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			try {
				queryfilter = gsonp.toJson(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				queryfilter = "{}";
			}
			;

			try {
				sortBy = I$ResMan.getJsonStr(argJson.get("sortBy").getAsJsonObject());
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "SORT FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);
			new BasicDBObject();
			BasicDBObject dbSort = BasicDBObject.parse(sortBy);
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			Integer limit = Math.abs(recSize);
			FindIterable<Document> dbCurVal = dbColl.find().filter(dbWhere).sort(dbSort).limit(limit);
//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
			while (dbDCurVal.hasNext()) {
				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);
			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// Mongo Top - User Top 1 From MAX
	private JsonObject mongoLeast(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		int recSize = -1; // Sent -1 for all Rows
		String queryfilter, sortBy;
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				recSize = argJson.get("recSize").getAsInt();
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "REC SIZE NOT PROVIDED OR INVALID",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			try {
				queryfilter = gsonp.toJson(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				queryfilter = "{}";
			}
			;

			try {
				sortBy = I$ResMan.getJsonStr(argJson.get("sortBy").getAsJsonObject());
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "SORT FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);
			new BasicDBObject();
			BasicDBObject dbSort = BasicDBObject.parse(sortBy);
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			Integer limit = Math.abs(recSize) * -1;
			FindIterable<Document> dbCurVal = dbColl.find().filter(dbWhere).sort(dbSort).limit(limit);
//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
			while (dbDCurVal.hasNext()) {
				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);
			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// Mongo Query Function
	private JsonObject mongoQuery(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		int iMaxRowCnt = -1; // Sent -1 for all Rows
		String queryfilter, projection, sort;
		int skip = 0, limit = 0; // #BVB00005
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		String skipAbsolute = "N";// #BHUVI001
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				iMaxRowCnt = argJson.get("MaxRow").getAsInt();
			} catch (Exception e) {
				iMaxRowCnt = -1;
			}
			;
			try {
				queryfilter = gsonp.toJson(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				// #BVB00137 Starts
				try {
					queryfilter = argJson.get("queryfilter").getAsString();
				} catch (Exception ex) {
					queryfilter = "{ \"#\":\"###\" }";
				}
				// #BVB00137 Ends
			}
			;
			try {
				projection = gsonp.toJson(argJson.get("projection").getAsJsonObject());
			} catch (Exception e) {

				projection = "{}";
			}
			;

			// #BVB00005 Starts
			// #BHUVI001 Starts
			try {
				skipAbsolute = argJson.get("skipAbsolute").getAsString();
			} catch (Exception e) {
				// TODO: handle exception
				skipAbsolute = "N";
			}
			// #BHUVI001 Ends
			try {
				limit = argJson.get("limit").getAsInt();
			} catch (Exception e) {
				limit = 0;
			}
			;

			try {
				skip = argJson.get("skip").getAsInt();
				// #BHUVI001 Starts
				if (I$utils.$iStrFuzzyMatch(skipAbsolute, "N")) {
					skip = skip * limit;
				}
				// #BHUVI001 Ends

			} catch (Exception e) {
				skip = 0;
			}
			;

			// #BVB00005 Ends

			// #00000003 Adding Sort Option Begins

			try {
				sort = argJson.get("sort").getAsString();
			} catch (Exception e) {
				// #00000045 begins
				try {
					sort = gsonp.toJson(argJson.get("sort").getAsJsonObject());

				} catch (Exception ec) {
					sort = "{'_id':1}";
				}
				// #00000045 ends
			}
			;
			// #00000003 Adding Sort Option Ends

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);
			new BasicDBObject();
			BasicDBObject dbProj = BasicDBObject.parse(projection);

			// #00000003 Adding Sort Option Begins
			new BasicDBObject();
			BasicDBObject dbSort = BasicDBObject.parse(sort);
			// #00000003 Adding Sort Option Ends

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			// FindIterable<Document> dbCurVal =
			// dbColl.find().filter(dbWhere).projection(dbProj);
			FindIterable<Document> dbCurVal = dbColl.find().filter(dbWhere).projection(dbProj).skip(skip).limit(limit)
					.sort(dbSort); // #00000003 Added Sort

//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
			while (dbDCurVal.hasNext()) {
				if (iMaxRowCnt >= 0 && iRowCnt >= iMaxRowCnt)
					break;
				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);

			if (iMaxRowCnt >= 0 && iRowCnt >= iMaxRowCnt) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN,
						"PARTIAL CONTENT - ONLY " + Integer.toString(iMaxRowCnt) + " ROWS SENT");

			} else if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #BVB00058 Starts
	private JsonObject mongoQueryWithId(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		int iMaxRowCnt = -1; // Sent -1 for all Rows
		String queryfilter, projection, sort, id;
		int skip = 0, limit = 0; // #BVB00005
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				iMaxRowCnt = argJson.get("MaxRow").getAsInt();
			} catch (Exception e) {
				iMaxRowCnt = -1;
			}
			;
			try {
				id = argJson.get("id").getAsString();
			} catch (Exception e) {
				id = "";
			}
			;
			try {
				projection = gsonp.toJson(argJson.get("projection").getAsJsonObject());
			} catch (Exception e) {
				projection = "{}";
			}
			;

			// #BVB00005 Starts

			try {
				limit = argJson.get("limit").getAsInt();
			} catch (Exception e) {
				limit = 0;
			}
			;

			try {
				skip = argJson.get("skip").getAsInt();
				skip = skip * limit;
			} catch (Exception e) {
				skip = 0;
			}
			;

			// #BVB00005 Ends

			// #00000003 Adding Sort Option Begins

			try {
				sort = argJson.get("sort").getAsString();
			} catch (Exception e) {
				sort = "{}";
			}
			;
			// #00000003 Adding Sort Option Ends

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			queryfilter = "{\"_id\" : ObjectId(\"" + I$utils.strip$Dquote(id) + "\")}";
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);
			new BasicDBObject();
			BasicDBObject dbProj = BasicDBObject.parse(projection);

			// #00000003 Adding Sort Option Begins
			new BasicDBObject();
			BasicDBObject dbSort = BasicDBObject.parse(sort);
			// #00000003 Adding Sort Option Ends

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			// FindIterable<Document> dbCurVal =
			// dbColl.find().filter(dbWhere).projection(dbProj);
			FindIterable<Document> dbCurVal = dbColl.find().filter(dbWhere).projection(dbProj).skip(skip).limit(limit)
					.sort(dbSort); // #00000003 Added Sort

//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
			while (dbDCurVal.hasNext()) {
				if (iMaxRowCnt >= 0 && iRowCnt >= iMaxRowCnt)
					break;
				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);

			if (iMaxRowCnt >= 0 && iRowCnt >= iMaxRowCnt) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN,
						"PARTIAL CONTENT - ONLY " + Integer.toString(iMaxRowCnt) + " ROWS SENT");

			} else if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};
	// #BVB00058 Ends

	// Mongo Query Function
	@SuppressWarnings("unchecked")
	private JsonObject mongoQueryAcq(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		String queryfilter, acquiredBy, recID;
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				queryfilter = gsonp.toJson(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "QUERY FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			try {
				acquiredBy = argJson.get("acquiredby").getAsString();
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "ACQUIRED BY USER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;

			try {
				recID = argJson.get("recID").getAsString();
			} catch (Exception e) {
				try {
					recID = argJson.get("queryfilter").getAsJsonObject().get("_id").getAsString();
				} catch (Exception ex) {
					resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "REC ID ANNOTE NOT PROVIDED",
							e.getMessage().toString());
					e.printStackTrace();
					return resJson;
				}
			}
			;

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			// queryfilter.replaceAll(regex, replacement)
			String idSearch = "{\"_id\" : ObjectId(\"" + I$utils.strip$Dquote(recID) + "\")}";
			BasicDBObject dbWhere = BasicDBObject.parse(idSearch);
			Document dbins = Document.parse("{$set:{acquiredBy:\"" + acquiredBy + "\"}}");
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			Document dbCurVal = dbColl.findOneAndUpdate(dbWhere, dbins);
//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG,
					gson.toJsonTree(dbCurVal).getAsJsonObject());
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// Mongo Insert Functions
	private JsonObject mongoInsert(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			String dataStr = gson.toJson(reqMsg.get(I$ResMan.I_BDYTAG).getAsJsonObject());
			Document dbins = Document.parse(dataStr);
			String sessionType = I$ResMan.getStrfromObjWithDefault(argJson,"sessionType",I$ResMan.I_MAIN_SESSION);
			
			if(i$mongoConfig.getSession() == null || I$utils.$iStrFuzzyMatch(sessionType, I$ResMan.I_PRAGMA_SESSION)) {
				dbColl.insertOne(dbins);
			}else {
				dbColl.insertOne(i$mongoConfig.getSession(), dbins);
			}
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY INSERTED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO INSERT DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}
	
	private JsonObject mongoFindAndUpdate(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter, sort, dbins;  // #YPR00001 - operator
		int iMaxRowCnt = -1; // Sent -1 for all Rows
		JsonObject resJson = reqMsg;
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			try {
				queryfilter = I$ResMan.getJsonStr(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "QUERY FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			};
			try {
				dbins = I$ResMan.getJsonStr(argJson.get("dbins").getAsJsonObject());
			} catch (Exception e) {
				dbins = "{}";
			};
			try {
				sort = argJson.get("sort").getAsString();
			} catch (Exception e) {
				sort = "{'_id':1}";
			};
			
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);

			Document docIns = Document.parse(dbins);
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			Document dbCurVal = dbColl.findOneAndUpdate(dbWhere, docIns);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, dbCurVal.toJson());
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// Mongo Update Function
	private JsonObject mongoUpdate(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter, upsert, upMulti, operator , arrFilter;  // #YPR00001 - operator
		JsonObject resJson = reqMsg;
//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			try {
				queryfilter = I$ResMan.getJsonStr(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "WHERE FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			try {
				// #BVB00005 Starts
				// upsert = I$ResMan.getJsonStr(argJson.get("upsert").getAsJsonObject());
				upsert = argJson.get("upsert").getAsString();

				// #BVB00005 Ends
			} catch (Exception e) {
				upsert = "false";
			}
			;
			try {
				arrFilter = I$ResMan.getStrJson(I$ResMan.getJsonArr(argJson.get("arrFilter").getAsString()));
			} catch (Exception e) {
				arrFilter = null;
			};
			;// #YPR00001 Starts
			try {
				
				operator = argJson.get("operator").getAsString();
			} catch (Exception e) {
				operator = "N";
			}
			;
			//#YPR00001 Ends 			
			try {
				upMulti = I$ResMan.getJsonStr(argJson.get("upMulti").getAsJsonObject());
			} catch (Exception e) {
				upMulti = "true";
			}
			;

			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			String dataStr = gson.toJson(reqMsg.get(I$ResMan.I_BDYTAG).getAsJsonObject());
			// #YPR00001 Starts
			Document dbins = new Document();
			if (I$utils.$iStrFuzzyMatch(operator, "N")) {
			    dbins = Document.parse("{$set:" + dataStr + "}");
			
			}else if (I$utils.$iStrFuzzyMatch(operator, "addtoSet")) {
				dbins = Document.parse(" {$addToSet:" + dataStr + "}");
				// #YPR00001 Ends
				// #YPR00002 Starts
			}else if (I$utils.$iStrFuzzyMatch(operator, "push")) {
				dbins = Document.parse(" {$push:" + dataStr + "}");
			// #YPR00002 Ends
				//#YPR00008 Starts
			}else if (I$utils.$iStrFuzzyMatch(operator, "inc")) {  //#PKY00065 changes
				dbins = Document.parse(" {$inc:" + dataStr + "}");
			// #YPR00002 Ends
				//#YPR00008 Starts
			}else if (I$utils.$iStrFuzzyMatch(operator, "pull")) {
				dbins = Document.parse(" {$pull:" + dataStr + "}");
			}//#YPR00008 Ends
			UpdateOptions Update$Options = new UpdateOptions();
			List<Document> arrayFilters= new ArrayList<>();  // #YPR00095 Changes
			Update$Options.upsert(I$utils.$iStrFuzzyMatch(upsert, "true"));
			// #MAQ00120 Starts
			if (arrFilter != null) {
				JsonArray arrFilters = new JsonArray();
				arrFilters = I$ResMan.getJsonArr(argJson.get("arrFilter").getAsString());
				for(int i = 0 ; i < arrFilters.size(); i++) { // #YPR00095 Changes
					String i$runningStrObj = I$ResMan.getJsonStr(arrFilters.get(i).getAsJsonObject());
					arrayFilters.add(Document.parse(i$runningStrObj ));
				}
				Update$Options.arrayFilters(arrayFilters);
//				Update$Options.arrayFilters(Arrays.asList( Document.parse(arrFilter) )); 
			} // #MAQ00120 ends
			if (I$utils.$iStrFuzzyMatch(upMulti, "true"))
				dbColl.updateMany(dbWhere, dbins, Update$Options);
			// BulkWriteResult bulkWriteResult = dbColl.bulkWrite(updates);
			else
				dbColl.updateOne(dbWhere, dbins, Update$Options);
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY UPDATED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO UPDATE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// #BVB0011 Starts
	private JsonObject mongoUpdate$id(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter, upsert;
		JsonObject resJson = reqMsg;
//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			try {
				queryfilter = argJson.get("queryfilter").getAsString();
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "WHERE FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			try {
				// #BVB00005 Starts
				// upsert = I$ResMan.getJsonStr(argJson.get("upsert").getAsJsonObject());
				upsert = argJson.get("upsert").getAsString();

				// #BVB00005 Ends
			} catch (Exception e) {
				upsert = "false";
			}
			;

			// new BasicDBObject();
			ObjectId queryfilterO = new ObjectId(queryfilter);
			BasicDBObject dbWhere = new BasicDBObject(); // .parse(queryfilter);
			dbWhere.put("_id", queryfilterO);

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			String dataStr = gson.toJson(reqMsg.get(I$ResMan.I_BDYTAG).getAsJsonObject());
			Document dbins = Document.parse("{$set:" + dataStr + "}");
			UpdateOptions Update$Options = new UpdateOptions();
			Update$Options.upsert(I$utils.$iStrFuzzyMatch(upsert, "true"));
			/*
			 * if (I$utils.$iStrFuzzyMatch(upMulti, "true")) dbColl.updateMany(dbWhere,
			 * dbins, Update$Options); else
			 */
			dbColl.updateOne(dbWhere, dbins, Update$Options);
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY UPDATED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO UPDATE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	private JsonObject mongoRemove$id(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter;
		JsonObject resJson = reqMsg;
		resJson.remove(I$ResMan.I_BDYTAG);
		try {
			try {
				queryfilter = argJson.get("queryfilter").getAsString();
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "WHERE FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			ObjectId queryfilterO = new ObjectId(queryfilter);
			BasicDBObject dbWhere = new BasicDBObject(); // .parse(queryfilter);
			dbWhere.put("_id", queryfilterO);

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			dbColl.deleteMany(dbWhere);
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY REMOVED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO REMOvE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #BVB0011 Ends

	// Mongo Remove Functions
	private JsonObject mongoRemove(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter;
		JsonObject resJson = reqMsg;
		resJson.remove(I$ResMan.I_BDYTAG);
		try {
			try {
				queryfilter = I$ResMan.getJsonStr(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "WHERE FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			dbColl.deleteMany(dbWhere);
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY REMOVED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO REMOvE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #BVB00005 Starts
	// Mongo Count Functions
	private JsonObject mongoCount(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		String queryfilter;
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020

		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args

			try {
				queryfilter = gsonp.toJson(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				queryfilter = "{ \"#\":\"###\" }";
			}
			;

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);
			new BasicDBObject();
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			long iRowCnt = dbColl.count(dbWhere);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG,
					"{\"iRowCnt\":" + iRowCnt + "}");

			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "COUNT SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE COUNT",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;

	}

	// #BVB00005 Ends

	public JsonObject mongoCopyCollection(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		JsonObject projection = new JsonObject();
		BasicDBObject projectionBson = new BasicDBObject();
		int iMaxRowCnt = -1; // Sent -1 for all Rows
		JsonObject match = new JsonObject();
		String out = "";
		int skip = 0, limit = 0; // #BVB00005
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		List<Bson> options = new ArrayList<Bson>();
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				iMaxRowCnt = argJson.get("MaxRow").getAsInt();
			} catch (Exception e) {
				iMaxRowCnt = -1;
			}
			;
			try {
				match = argJson.get("match").getAsJsonObject();
			} catch (Exception e) {
				match = null;
			}
			;
			try {
				out = gsonp.toJson(argJson.get("out").getAsString());
			} catch (Exception e) {
				out = "";
			}
			;

			try {
				projection = argJson.get("projection").getAsJsonObject();
				projectionBson = BasicDBObject.parse(gsonp.toJson(projection));

			} catch (Exception e) {
				projection = null;
				// projectionBson = BasicDBObject.parse(gsonp.toJson(projection));
			}

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			if (!I$utils.$iStrFuzzyMatch(gsonp.toJson(projection), "{}")) {
				options = Arrays.asList(Aggregates.project(projectionBson), Aggregates.out(out.replace("\"", "")));

			} else {

				options = Arrays.asList(Aggregates.out(out.replace("\"", "")));
			}

			AggregateIterable<Document> dbCurVal = dbColl.aggregate(options);

			if (dbCurVal.first() != null) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "COLLECTION CREATED SUCESSFULLY");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "COLLECTION NOT CREATED");
			}

		} catch (Exception e) {
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG,
					"{\"collectionCreated\":" + 0 + "}");
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO CREATE COLLECTION",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;

	}

	// Mongo Update Function
	private JsonObject mongoUpdate$where(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter, upsert, upMulti;
		JsonObject resJson = reqMsg;
//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			try {
				queryfilter = argJson.get("queryfilter").getAsString();
			} catch (Exception e) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "WHERE FILTER NOT PROVIDED",
						e.getMessage().toString());
				e.printStackTrace();
				return resJson;
			}
			;
			try {
				// #BVB00005 Starts
				// upsert = I$ResMan.getJsonStr(argJson.get("upsert").getAsJsonObject());
				upsert = argJson.get("upsert").getAsString();

				// #BVB00005 Ends
			} catch (Exception e) {
				upsert = "false";
			}
			;
			try {
				upMulti = I$ResMan.getJsonStr(argJson.get("upMulti").getAsJsonObject());
			} catch (Exception e) {
				upMulti = "true";
			}
			;

//			Gson gsonp = new Gson();
			Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			try {
				JsonObject con = new JsonObject();
				con.addProperty("$where", argJson.get("queryfilter").getAsString());
				queryfilter = gsonp.toJson(con);
			} catch (Exception e) {
				e.printStackTrace();
				queryfilter = "{}";
			}
			;
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			String dataStr = gson.toJson(reqMsg.get(I$ResMan.I_BDYTAG).getAsJsonObject());

			Document dbins = Document.parse("{$set:" + dataStr + "}");
			UpdateOptions Update$Options = new UpdateOptions();
			Update$Options.upsert(I$utils.$iStrFuzzyMatch(upsert, "true"));
			dbColl.updateMany(dbWhere, dbins, Update$Options);

			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY UPDATED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO UPDATE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// #0000006 Starts
	// Mongo Count Functions
	private JsonObject mongoRCount(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		int iMaxRowCnt = -1; // Sent -1 for all Rows
		String queryfilter, projection;
//		Gson gsonp = new Gson();
		Gson gsonp = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			try {
				iMaxRowCnt = argJson.get("MaxRow").getAsInt();
			} catch (Exception e) {
				iMaxRowCnt = -1;
			}
			;
			try {
				queryfilter = gsonp.toJson(argJson.get("queryfilter").getAsJsonObject());
			} catch (Exception e) {
				try {
					queryfilter = argJson.get("queryfilter").getAsString();
				} catch (Exception ex) {
					queryfilter = "{ \"#\":\"###\" }";
				}

			}
			;
			try {
				projection = gsonp.toJson(argJson.get("projection").getAsJsonObject());
			} catch (Exception e) {
				projection = "{}";
			}
			;
			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);

			// new BasicDBObject();
			// BasicDBObject dbProj = BasicDBObject.parse(projection);

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			// Long dbCurVal = dbColl.count();
			Long dbCurVal = dbColl.count(dbWhere);
			logger.info("COUNT is: " + dbCurVal);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG,
					"{\"iRowCnt\":" + dbCurVal + "}");

			if (dbCurVal == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "COUNT SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE COUNT",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;

	}

	// Mongo Aggregate Functions along with Arithematic Operations
	private JsonObject mongoAggregateWAO(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;

		AggregateIterable<Document> dbCurVal = null;
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args

			try {
			} catch (Exception e) {
			}
			;
			logger.info("Prinitng the Json Array" + argJson.toString());
			// logger.info("Printing the GROUP" +
			// argJson.getAsJsonObject("queryfilter").get("GROUP").getAsString());

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			// new Document("$match",new Document("active", Boolean.TRUE).append("region",
			// "India")),
			String strAggQuery = null, strOutCollName = null, strDefVal = null;
			String mqry = null;

			try {
				strOutCollName = argJson.getAsJsonObject("queryfilter").get("OUTCOLL").getAsString();
			} catch (Exception e) {
				strOutCollName = null;
			}
			;
			try {
				strAggQuery = argJson.getAsJsonObject("queryfilter").get("Query").getAsString();
			} catch (Exception e) {
				strAggQuery = null;
			}
			;

			try {
				mqry = argJson.getAsJsonObject("queryfilter").get("MQuery").getAsString();
			} catch (Exception e) {
				mqry = null;
			}
			;
			AggregateIterable<Document> ai = null;

			// mqry=" {$match : { \"$EXPOSURE_AMT_AT_POINT\" : { $gt : 0 } } }";
			logger.info("QUERY IS &&&&&&&&&&&&&&&&&&&&&&" + strAggQuery);

			if (mqry != null) {

				ai = dbColl.aggregate(Arrays.asList(Document.parse(mqry), Document.parse(strAggQuery),
						Aggregates.out(strOutCollName)));
			} else {
				ai = dbColl.aggregate(Arrays.asList(Document.parse(strAggQuery), Aggregates.out(strOutCollName)));
			}

//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;

			if (ai.first() != null) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "COLLECTION MODIFIED SUCESSFULLY");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "COLLECTION NOT MODIFIED CREATED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// Mongo Aggregate Functions along with Arthamatic Operations
	@SuppressWarnings({ "unused" })
	private JsonObject mongoAggregateWRA(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;

		AggregateIterable<Document> dbCurVal = null;
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args

			try {
			} catch (Exception e) {
			}
			;
			logger.info("Prinitng the Json Array" + argJson.toString());
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			String strAggQuery = null, strOutCollName = null, strDefVal = null;
			String mqry = null;

			try {
				strOutCollName = argJson.getAsJsonObject("queryfilter").get("OUTCOLL").getAsString();
			} catch (Exception e) {
				strOutCollName = null;
			}
			;
			try {
				strAggQuery = argJson.getAsJsonObject("queryfilter").get("Query").getAsString();
			} catch (Exception e) {
				strAggQuery = null;
			}
			;

			try {
				mqry = argJson.getAsJsonObject("queryfilter").get("MQuery").getAsString();
			} catch (Exception e) {
				mqry = null;
			}
			;
			AggregateIterable<Document> ai = null;

			// mqry=" {$match : { \"$EXPOSURE_AMT_AT_POINT\" : { $gt : 0 } } }";
			logger.info("QUERY IS &&&&&&&&&&&&&&&&&&&&&&" + strAggQuery);

			if (mqry != null) {

				ai = dbColl.aggregate(Arrays.asList(Document.parse(mqry), Document.parse(strAggQuery),
						Aggregates.out(strOutCollName)));
			} else {
				ai = dbColl.aggregate(Arrays.asList(Document.parse(strAggQuery), Aggregates.out(strOutCollName)));
			}

//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			if (ai.first() != null) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "COLLECTION MODIFIED SUCESSFULLY");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "COLLECTION NOT MODIFIED CREATED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #00000008 Begins
	// Mongo Bulk Insert Function
	@SuppressWarnings("null")
	private JsonObject mongoBInsert(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonParser parser = null;
		JsonObject resJson = reqMsg;
//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonArray JBulkArray = reqMsg.getAsJsonArray("i-body");
		try {
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			List<Document> dbinsLst = new ArrayList<Document>();
			for (int i = 0; i < JBulkArray.size(); i++) {
				String dataStr = gson.toJson(JBulkArray.get(i).getAsJsonObject());
				Document dbins = Document.parse(dataStr);
				dbinsLst.add(dbins);
			}
			;
			if (dbinsLst != null)
				dbColl.insertMany(dbinsLst);
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "BULK DATA INSERTION DONE SUCCESSFULLY");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED IN BULK DATA INSERTION",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// #00000009 Begins
	// Mongo Create Collection
	private JsonObject mongoCreateColln(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		try {
			db.createCollection(argJson.get("CollName").getAsString());
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC,
					"COLLECTION " + argJson.get("CollName").getAsString() + " SUCCESSFULLY CREATED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO CREATE COLLECTION",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// #00000019 Begins
	// Mongo Create Collection
	private JsonObject mongoCreateIndex(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		try {
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			String strIndexCollName = null, strOutCollName = null, strDefVal = null;
			String mqry = null;

			try {
				strIndexCollName = argJson.getAsJsonObject("queryfilter").get("INDEXCOlNAME").getAsString();
			} catch (Exception e) {
				strIndexCollName = null;
			}
			;

			new BasicDBObject();
			String rsJson = null;
			if (strIndexCollName != null) {
				BasicDBObject index = new BasicDBObject(strIndexCollName, -1);

				rsJson = dbColl.createIndex(index);
			}
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC,
					"COLLECTION " + argJson.get("CollName").getAsString() + " INDEX SUCCESSFULLY CREATED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO CREATE COLLECTION",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// #BVB00030 Starts

	// #MAQ00002 start
	// Mongo Aggregate Function
	@SuppressWarnings({ "unchecked", "deprecation" })
	private JsonObject mongoAggregate(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;

		AggregateIterable<Document> dbCurVal = null;
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args

			try {
			} catch (Exception e) {
			}
			;
			logger.info("Prinitng the Json Array" + argJson.toString());
			logger.info("Printing the GROUP" + argJson.getAsJsonObject("queryfilter").get("GROUP").getAsString());

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			// new Document("$match",new Document("active", Boolean.TRUE).append("region",
			// "India")),
			String strGroup = null, strMatch = null, strSum = null, strDisplayFld = null, strmSum = null,
					strmDisplayFld = null;
			String strStartDate = null, strEndDate = null, strMfield1 = null, strMfield2 = null;
			String strSGroup = null, strSSum = null, strSDisplayFld = null;
			// strGroup = argJson.get("GROUP").getAsString();
			// creteria =argJson.get("GROUP").getAsString();

			try {
				strSum = argJson.getAsJsonObject("queryfilter").get("SUM").getAsString();
			} catch (Exception e) {
				strSum = null;
			}
			;
			try {
				strDisplayFld = argJson.getAsJsonObject("queryfilter").get("FLDDISPLAY").getAsString();
			} catch (Exception e) {
				strDisplayFld = null;
			}
			;
			try {
				strGroup = argJson.getAsJsonObject("queryfilter").get("GROUP").getAsString();
			} catch (Exception e) {
				strGroup = null;
			}
			;

			try {
				strSSum = argJson.getAsJsonObject("queryfilter").get("SSUM").getAsString();
			} catch (Exception e) {
				strSSum = null;
			}
			;
			try {
				strSDisplayFld = argJson.getAsJsonObject("queryfilter").get("SFLDDISPLAY").getAsString();
			} catch (Exception e) {
				strSDisplayFld = null;
			}
			;
			try {
				strSGroup = argJson.getAsJsonObject("queryfilter").get("SGROUP").getAsString();
			} catch (Exception e) {
				strSGroup = null;
			}
			;

			try {
				strMatch = argJson.getAsJsonObject("queryfilter").get("MATCH").getAsString();
			} catch (Exception e) {
				strMatch = null;
			}
			;
			try {
				strmSum = argJson.getAsJsonObject("queryfilter").get("MSUM").getAsString();
			} catch (Exception e) {
				strmSum = null;
			}
			;
			try {
				strmDisplayFld = argJson.getAsJsonObject("queryfilter").get("MFLDDISPLAY").getAsString();
			} catch (Exception e) {
				strmDisplayFld = null;
			}
			;
			try {
				strStartDate = argJson.getAsJsonObject("queryfilter").get("MSDATE").getAsString();
			} catch (Exception e) {
				strStartDate = null;
			}
			;
			try {
				strEndDate = argJson.getAsJsonObject("queryfilter").get("MEDATE").getAsString();
			} catch (Exception e) {
				strEndDate = null;
			}
			;
			try {
				strMfield1 = argJson.getAsJsonObject("queryfilter").get("MFLD1").getAsString();
			} catch (Exception e) {
				strMfield1 = null;
			}
			;
			try {
				strMfield2 = argJson.getAsJsonObject("queryfilter").get("MFLD2").getAsString();
			} catch (Exception e) {
				strMfield2 = null;
			}
			;
			Document groupQuery = new Document();
			if (strGroup != null && strSum != null && strDisplayFld != null && strSSum == null) {
				groupQuery.append("$group",
						new Document("_id", "$" + strGroup).append(strDisplayFld, new Document("$sum", "$" + strSum)));
			} else if (strGroup != null && strSum != null && strSSum == null) {
				groupQuery.append("$group",
						new Document("_id", "$" + strGroup).append("Count", new Document("$sum", "$" + strSum)));
			} else if (strSSum != null && strDisplayFld != null && strGroup != null && strSum != null) {
				groupQuery.append("$group",
						new Document("_id", "$" + strGroup).append(strDisplayFld, new Document("$sum", "$" + strSum))
								.append("count", new Document("$sum", 1)));
			} else {
				logger.info("GGGGGGGGGGG" + strGroup);
				groupQuery.append("$group",
						new Document("_id", "$" + strGroup).append("count", new Document("$sum", 1)));
			}

			logger.debug("The groupquery :-" + groupQuery);

			Document MatchQuery = new Document();
			if (strMatch != null && strStartDate != null && strEndDate != null) {
				MatchQuery.append("$match", new Document(strMatch,
						new Document("$gte", strStartDate.toString()).append("$lte", strEndDate.toString())));
			} else if (strMatch != null && strMfield1 != null && strMfield2 != null) {
				MatchQuery.append("$match", new Document(strMatch, strMfield1).append(strMatch, strMfield2));
			} else if (strMatch != null && strMfield1 != null) {
				MatchQuery.append("$match", new Document(strMatch, strMfield1));
			}

			logger.debug("The MatchQuery :-" + MatchQuery);

			logger.info("Match Query" + MatchQuery.toString());
			logger.info("GROUP QUERY" + groupQuery.toString());
			if (strMatch != null && strGroup != null) {
				dbCurVal = dbColl.aggregate(Arrays.asList(MatchQuery, groupQuery));
			} else if (strGroup != null) {
				dbCurVal = dbColl.aggregate(Arrays.asList(groupQuery));
			}

//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
			while (dbDCurVal.hasNext()) {

				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				logger.info("JSON RESULT IS SSSSSSSSSSSS" + jsonElement.toString());
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);

			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};
	// #MAQ00002 start

	private JsonObject mongoQueryAgg(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		int iMaxRowCnt = -1; // Sent -1 for all Rows
		AggregateIterable<Document> dbCurVal = null;
		String projection = "";
		int limit, skip;
//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonArray buildAggPara = new JsonArray();

		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			String strAggQuery = "";

			// #MAQ00001 Start
			if (argJson.has("queryfilter")) {
				strAggQuery = gson.toJson(argJson.getAsJsonObject("queryfilter"));
				strAggQuery = "{$match :" + strAggQuery + "}";
				buildAggPara.add(strAggQuery);
			}

			if (argJson.has("projection")) {
				projection = gson.toJson(argJson.getAsJsonObject("projection"));
				projection = "{$project :" + projection + "}";
				buildAggPara.add(projection);
			}

			if (argJson.has("limit")) {
				limit = argJson.get("limit").getAsInt();
				String tempLimit = gson.toJson(limit);
				String mongoLimit = "{$limit :" + tempLimit + "}";
				buildAggPara.add(mongoLimit);
			} else
				limit = 0;

			if (argJson.has("limit")) {
				skip = argJson.get("skip").getAsInt();
				skip = skip * limit;
				String tempSkip = gson.toJson(skip);
				String mongoSkip = "{$skip :" + tempSkip + "}";
				buildAggPara.add(mongoSkip);
			}

			ArrayList<Document> finalAggPara = new ArrayList<Document>();
			for (int i = 0; i < buildAggPara.size(); i++) {
				if (!(buildAggPara.get(i).isJsonNull()))
					finalAggPara.add(Document.parse(buildAggPara.get(i).getAsString()));
			}

			AggregateIterable<Document> ai = null;
			ai = dbColl.aggregate(finalAggPara);

//			AggregateIterable<Document> ai = null;
//
//			if (projection != null) {
//
//				ai = dbColl.aggregate(Arrays.asList(Document.parse(strAggQuery), Document.parse(projection)));
//			} else {
//				ai = dbColl.aggregate(Arrays.asList(Document.parse(strAggQuery)));
//			}
			// #MAQ00001 end

			gson = new GsonBuilder().create();
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = ai.iterator();
			while (dbDCurVal.hasNext()) {
				if (iMaxRowCnt >= 0 && iRowCnt >= iMaxRowCnt)
					break;
				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);

			if (iMaxRowCnt >= 0 && iRowCnt >= iMaxRowCnt) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN,
						"PARTIAL CONTENT - ONLY " + Integer.toString(iMaxRowCnt) + " ROWS SENT");

			} else if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #BVB00030 Ends

	// Mongo Aggregate Function
	@SuppressWarnings({ "unchecked", "deprecation" })
	private JsonObject mongoGetChartData(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;

		AggregateIterable<Document> dbCurVal = null;
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			String strQuery = null;

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			try {
				strQuery = argJson.getAsJsonObject("queryfilter").get("Query").getAsString();
			} catch (Exception e) {
				strQuery = null;
			}
			;

			if (strQuery != null) {
				dbCurVal = dbColl.aggregate(Arrays.asList(Document.parse(strQuery)));
			}

//			Gson gson = new GsonBuilder().create();
			Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
			while (dbDCurVal.hasNext()) {

				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				// logger.info("JSON RESULT IS SSSSSSSSSSSS" + jsonElement.toString());
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);

			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

// #BVB00131 Starts 
	private JsonObject mongoAggregareWOP(JsonObject argJson, JsonObject reqMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = reqMsg;
		JsonArray options = new JsonArray();
		AggregateIterable<Document> dbCurVal = null;
		ArrayList<Document> finalAggPara = new ArrayList<Document>();
//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		JsonArray datarow = new JsonArray();
		int iRowCnt = 0;
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			// Get Mongo Args
			// String strQuery = null;

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());

			try {
				options = argJson.getAsJsonArray("options");
			} catch (Exception e) {
				options = null;
			}
			;
			if (!I$utils.$isNull(options)) {
				for (int i = 0; i < options.size(); i++) {
					JsonElement i$runningEle = options.get(i);
					if (i$runningEle.isJsonPrimitive()) {
						finalAggPara.add(Document.parse(options.get(i).getAsString()));
					} else if (i$runningEle.isJsonArray()) {
						finalAggPara.add(Document.parse(gson.toJson(options.get(i).getAsJsonArray())));
					} else if (i$runningEle.isJsonArray()) {
						finalAggPara.add(Document.parse(gson.toJson(options.get(i).getAsJsonArray())));
						//
					}
				}
				dbCurVal = dbColl.aggregate(finalAggPara);

				// Gson gson = new GsonBuilder().serializeNulls().create();

				MongoCursor<Document> dbDCurVal = dbCurVal.iterator();
				while (dbDCurVal.hasNext()) {

					JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
					datarow.add(jsonElement);
					// logger.info("JSON RESULT IS SSSSSSSSSSSS" + jsonElement.toString());
					iRowCnt++;
				}

			} else {
				iRowCnt = 0;
			}
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);

			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #BVB00131 Ends
	// #NYE00001 Begins
	// Mongo Insert Functions
	private JsonObject mongoGetSeq(JsonObject argJson) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonParser parser = new JsonParser();
		JsonObject resJson = parser.parse(I$ResMan.I_REQTPL_NBDY).getAsJsonObject();
		JsonObject i$body = new JsonObject();
//		Gson gson = new Gson();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		try {
			JsonObject idSearch = argJson.get("queryfilter").getAsJsonObject();
			JsonObject updateClause = argJson.get("updateClause").getAsJsonObject();
			BasicDBObject dbWhere = BasicDBObject.parse(gson.toJson(idSearch));
			Document dbins = Document.parse(gson.toJson(updateClause));
			FindOneAndUpdateOptions dbopts = new FindOneAndUpdateOptions();
			dbopts.returnDocument(ReturnDocument.AFTER);
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			Document dbCurVal = dbColl.findOneAndUpdate(dbWhere, dbins, dbopts);
			i$body.addProperty("currVal", dbCurVal.getInteger("currVal"));
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, i$body);
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "SEQ GENERATED SUCESSFULLY");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO GENERATE SEQ",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	}

	// #NYE00001 Ends
// // #BVB00052 Starts  
	private JsonObject mongoBUpdate(JsonObject argJson, JsonObject reqMsg) {

		MongoDatabase db = MongoConfig.getMongoDB();
		String queryfilter, upsert, upMulti;
		JsonObject resJson = reqMsg;
//		Gson gson = new GsonBuilder().create();
		Gson gson = new GsonBuilder().serializeNulls().create(); // #MAQ00020
		// #BHUVI002 Starts
		String isArr = "Y";
		String columnName = "";

		JsonArray setterArr = new JsonArray();
		JsonObject setterObj = new JsonObject();
		// #BHUVI002 Ends
		try {
			/*
			 * try { queryfilter =
			 * I$ResMan.getJsonStr(argJson.get("queryfilter").getAsJsonObject()); } catch
			 * (Exception e) { resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR,
			 * "WHERE FILTER NOT PROVIDED", e.getMessage().toString()); e.printStackTrace();
			 * return resJson; };
			 */
			// Get the array for setter
			// #BHUVI002 Starts
			if (reqMsg.get("i-body").isJsonArray()) {
				setterArr = reqMsg.get("i-body").getAsJsonArray();
				isArr = "Y";
			} else {
				setterObj = reqMsg.get("i-body").getAsJsonObject();
				isArr = "N";
				columnName = argJson.get("columnName").getAsString();
			}
			// #BHUVI002 Ends
			// Get the array for Filters
			JsonArray filterArr = argJson.getAsJsonArray("queryfilter");

			try {
				// #BVB00005 Starts
				// upsert = I$ResMan.getJsonStr(argJson.get("upsert").getAsJsonObject());
				upsert = argJson.get("upsert").getAsString();

				// #BVB00005 Ends
			} catch (Exception e) {
				upsert = "false";
			}
			;
			try {
				upMulti = I$ResMan.getJsonStr(argJson.get("upMulti").getAsJsonObject());
			} catch (Exception e) {
				upMulti = "true";
			}
			;

			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			// JsonArray JBulkArray = reqMsg.getAsJsonArray("i-body");
			// for (int i = 0; i < setterArr.size(); i++) {
			if (I$utils.$iStrFuzzyMatch(isArr, "Y")) {// #BHUVI002 Added
				for (int i = 0; i < setterArr.size(); i++) {
					try {
						queryfilter = I$ResMan.getJsonStr(filterArr.get(i).getAsJsonObject());
					} catch (Exception e) {
						resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "WHERE FILTER NOT PROVIDED",
								e.getMessage().toString());
						e.printStackTrace();
						return resJson;
					}
					;

					BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);

					String dataStr = gson.toJson(setterArr.get(i).getAsJsonObject());

					Document dbins = Document.parse("{$set:" + dataStr + "}");
					UpdateOptions Update$Options = new UpdateOptions();
					Update$Options.upsert(I$utils.$iStrFuzzyMatch(upsert, "true"));
					if (I$utils.$iStrFuzzyMatch(upMulti, "true"))
						dbColl.updateMany(dbWhere, dbins, Update$Options);
					// BulkWriteResult bulkWriteResult = dbColl.bulkWrite(updates);
					else
						dbColl.updateOne(dbWhere, dbins, Update$Options);

				}
			} else {
				// #BHUVI002 Starts
				String fitlerS = "{'" + columnName + "':{$in: " + I$ResMan.getStrJson(filterArr) + "}}";
				String dataStr = I$ResMan.getStrJson(setterObj);

				BasicDBObject dbWhere = BasicDBObject.parse(fitlerS);
				Document dbins = Document.parse("{$set:" + dataStr + "}");
				UpdateOptions Update$Options = new UpdateOptions();
				Update$Options.upsert(I$utils.$iStrFuzzyMatch(upsert, "true"));
				// if (I$utils.$iStrFuzzyMatch(upMulti, "true"))
				dbColl.updateMany(dbWhere, dbins, Update$Options);
				// BulkWriteResult bulkWriteResult = dbColl.bulkWrite(updates);
//				else
//					dbColl.updateOne(dbWhere, dbins, Update$Options);
//				// #BHUVI002 Ends
			}
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY UPDATED");
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO UPDATE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;

	}

// #BVB00052 Ends
	// #BHUVI003 Start
	private JsonObject mongoDistinct(JsonObject argJson, JsonObject resMsg) {
		MongoDatabase db = MongoConfig.getMongoDB();
		JsonObject resJson = resMsg;
		String queryfilter;
		String fieldName = null;
		Gson gsonp = new GsonBuilder().serializeNulls().create();
		try {
			// Removing the Property for Reading
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_BDYTAG);
			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_REMFRMJSON, resJson, I$ResMan.I_STATTAG);
			try {
				queryfilter = argJson.get("queryfilter").getAsString();
			} catch (Exception e) {
				queryfilter = "{}";
			}
			try {
				fieldName = argJson.get("fieldName").getAsString();
			} catch (Exception e) {

			}

			// Create DB Objects for Mongo Operations
			new BasicDBObject();
			BasicDBObject dbWhere = BasicDBObject.parse(queryfilter);
			new BasicDBObject();
			MongoCollection<org.bson.Document> dbColl = db.getCollection(argJson.get("CollName").getAsString());
			MongoCursor<String> dbDCurVal = dbColl.distinct(fieldName, dbWhere, String.class).iterator();
			System.out.println("");
			Gson gson = new GsonBuilder().serializeNulls().create();
			JsonArray datarow = new JsonArray();
			int iRowCnt = 0;
			while (dbDCurVal.hasNext()) {
				JsonElement jsonElement = gson.toJsonTree(dbDCurVal.next());
				datarow.add(jsonElement);
				iRowCnt++;
			}

			resJson = I$ResMan.iHandleArgJson(I$ResMan.I_ADDTOJSON, resJson, I$ResMan.I_BDYTAG, datarow);
			if (iRowCnt == 0) {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_WRN, "NO MATCHING RECORDS FOUND");
			} else {
				resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_SUCC, "DATA SUCCESSFULLY RETRIEVED");
			}
			;
		} catch (Exception e) {
			resJson = I$ResMan.iHandleResStat(resJson, I$ResMan.I_ERR, "FAILED TO RETRIVE DATA",
					e.getMessage().toString());
			e.printStackTrace();
		}
		return resJson;
	};

	// #BHUVI003 Ends
	// Process Functions
	public JsonObject processDBOpr(JsonObject reqMsg, JsonObject argJson) {
		JsonObject resMsg = new JsonObject();
		resMsg = reqMsg; // Initial Assignment for Response Processing
		// Routing Based on Mongo Opr Mode
		if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Query"))
			resMsg = mongoQuery(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Insert"))
			resMsg = mongoInsert(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update"))
			resMsg = mongoUpdate(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryUpdate"))
			resMsg = mongoFindAndUpdate(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Remove"))
			resMsg = mongoRemove(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "RandomDoc"))
			resMsg = mongoRandDoc(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Top"))
			resMsg = mongoTop(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Least"))
			resMsg = mongoLeast(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryAcq"))
			resMsg = mongoQueryAcq(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Copy"))
			resMsg = mongoCopyCollection(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update$Where"))
			resMsg = mongoUpdate$where(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update$id"))
			resMsg = mongoUpdate$id(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "RCount"))
			resMsg = mongoRCount(argJson, resMsg); //// #00000006
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update$NewFld"))
			resMsg = mongoAggregateWAO(argJson, resMsg); //// #00000007
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "BulkInsert"))
			resMsg = mongoBInsert(argJson, resMsg); //// #00000008
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "CreateColln"))
			resMsg = mongoCreateColln(argJson, resMsg); //// #00000009
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Aggregate"))
			resMsg = mongoAggregate(argJson, resMsg); // #MAQ00002
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "get$ChartData"))
			resMsg = mongoGetChartData(argJson, resMsg); //// #000000010
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "create$Index"))
			resMsg = mongoCreateIndex(argJson, resMsg); //// #000000010
		// BVB
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryAgg"))
			resMsg = mongoQueryAgg(argJson, resMsg); //// #00000007
		// BVB
		// #00000002 Begins
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSUpld"))
			resMsg = mongoGrdFSUpld(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "MultiGrdFSUpld"))
			resMsg = mongoMultiGrdUpld(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSReqUpld"))
			resMsg = mongoGrdFSReqUpld(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSScanUpld")) //#MVT00043 changes
			resMsg = mongoGrdFSScanReqUpld(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSDwldB24"))
			resMsg = mongoGrdFSDwldB24(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSDwld"))
			resMsg = mongoGrdFSDwld(argJson, resMsg);
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSScanDwld")) //#MVT00043 changes
			resMsg = mongoGrdFSScanDwld(argJson, resMsg);
		// #NYE00001 Begin
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GetSeq"))
			resMsg = mongoGetSeq(argJson);
		// #NYE00001 End
		// #00000002 Ends
		// #BVB00058 Starts
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryWithId"))
			resMsg = mongoQueryWithId(argJson, resMsg);
		// #BVB00058 Ends
		// #BVB00052 Starts
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "BulkUpdate"))
			resMsg = mongoBUpdate(argJson, resMsg); //// #00000008
		// #BVB00052 Ends
		// #BVB00131 Starts
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "AggregateWOP"))
			resMsg = mongoAggregareWOP(argJson, resMsg); //// #00000008
		// #BVB00131 Ends
		// #BHUVI003 Start
		else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Distinct"))
			resMsg = mongoDistinct(argJson, resMsg);
		// #BHUVI003 Ends
		return resMsg;
	}

	public JsonObject processDBOpr(JsonObject argJson) {
		try {
			// Generating Impacto ISON Format
			String isonFormat = I$ResMan.I_REQTPL;
			String isonString = "";
			try {
				isonString = argJson.get("isonString").getAsString();
			} catch (Exception e) {
				isonString = "{}";
			}
			isonFormat = isonFormat.replaceAll("(?i)" + I$ResMan.I_BDYRTAG, isonString);
			JsonParser parser = new JsonParser();
			JsonObject resMsg = parser.parse(isonFormat).getAsJsonObject();
			// Routing Based on Mongo Opr Mode
			if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Query"))
				resMsg = mongoQuery(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Insert"))
				resMsg = mongoInsert(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update"))
				resMsg = mongoUpdate(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Remove"))
				resMsg = mongoRemove(argJson, resMsg);
			// #BVB00005 Starts
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "RandomDoc"))
				resMsg = mongoRandDoc(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GrdFSUpld"))
				resMsg = mongoGrdFSUpld(argJson, resMsg);
			// #BVB00005 Ends
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Top"))
				resMsg = mongoTop(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Least"))
				resMsg = mongoLeast(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryAcq"))
				resMsg = mongoQueryAcq(argJson, resMsg);
			// #BVB00005 Starts
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Count"))
				resMsg = mongoCount(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Copy"))
				resMsg = mongoCopyCollection(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update$Where"))
				resMsg = mongoUpdate$where(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update$id"))
				resMsg = mongoUpdate$id(argJson, resMsg);
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "RCount"))
				resMsg = mongoRCount(argJson, resMsg); //// #00000006
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Update$NewFld"))
				resMsg = mongoAggregateWAO(argJson, resMsg); //// #00000007
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "BulkInsert"))
				resMsg = mongoBInsert(argJson, resMsg); //// #00000008
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "CreateColln"))
				resMsg = mongoCreateColln(argJson, resMsg); //// #00000009
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Aggregate"))
				resMsg = mongoAggregate(argJson, resMsg); // #MAQ00002
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "get$ChartData"))
				resMsg = mongoGetChartData(argJson, resMsg); //// #000000010
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "create$Index"))
				resMsg = mongoCreateIndex(argJson, resMsg); //// #000000010
			// BVB
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryAgg"))
				resMsg = mongoQueryAgg(argJson, resMsg);
			// BVB
			// #NYE00001 Begin
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "GetSeq"))
				resMsg = mongoGetSeq(argJson);
			// #NYE00001 End
			// #00000002 Ends
			// #BVB00058 Starts
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "QueryWithId"))
				resMsg = mongoQueryWithId(argJson, resMsg);
			// #BVB00058 Ends
			// #BVB00052 Strats
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "BulkUpdate"))
				resMsg = mongoBUpdate(argJson, resMsg); //// #00000008
			// #BVB00052 Ends
			// #BVB00131 Starts
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "AggregateWOP"))
				resMsg = mongoAggregareWOP(argJson, resMsg);
			// #BVB00131 Ends
			// #BHUVI003 Start
			else if (I$utils.$iStrFuzzyMatch(argJson.get("MongoOprMode").getAsString(), "Distinct"))
				resMsg = mongoDistinct(argJson, resMsg);
			// #BHUVI003 Ends
			return resMsg;
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}
	}

	public ImongoWorker() {
		// Const
	}
}