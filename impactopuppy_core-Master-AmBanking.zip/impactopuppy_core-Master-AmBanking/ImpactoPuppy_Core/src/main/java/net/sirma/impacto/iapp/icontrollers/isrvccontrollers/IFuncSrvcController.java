/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------
      |0.1 Beta    | Syed 		| Jul 27, 2021 | #00000001   | Initial writing
      |0.1 Beta    | Pappu      | Jul 28, 2021 | #PKY00001   | Added condition to handle single func request and group of func request
      |0.1 Beta    | Pappu      | Sep 16, 2021 | #PKY00002   | Added CLOB dataType
      |0.1 Beta    | Samadhan   | Dec 14, 2021 | #SRP00042   | Code changes in exeCallOrcl function for IMB Integration
      |0.1 Beta    | Samadhan   | May 24, 2022 | #SRP00066   | Handle code for AML Checks
      |0.1 Beta    | Pappu      | Jun 21, 2022 | #PKY00078   | handled Aml transaction Alert notification and job to send daily transactions report.
      |0.1 Beta    | Samadhan   | Jun 28, 2022 | #SRP00072   | Handled Fields For AML Check
      |0.1 Beta    | Samadhan   | Sep 19, 2022 | #SRP00085   | Handled Code For AML check Daily Report Job
      |0.1 Beta    | Samadhan   | Sep 22, 2022 | #SRP00086   | Handled Code For AML Daily flexcube transaction.
      |0.1 Beta    | Sushmita   | Oct 11, 2022 | #SKP00001   | Handled code for Ibridge loan func call lov data 
      |0.1 Beta	   | Sindhu     | Oct 18, 2022 | #SRM00003   | Handled Code For AML yearly flexcube transactions.
      |0.1 Beta	   | Madhura    | Oct 25, 2022 | #MSA00001   | Handled Code For AML Monthly flexcube transactions.
      |0.1 Beta    | Sindhu     | Oct 27, 2022 | #SRM00004   | Handled code for ID document result function from flexcube
      |0.1 Beta    | Sindhu     | Oct 31, 2022 | #SRM00005   | Handled code for getting yearly transaction report in table format in the pdf
      |0.1 Beta    | Madhura    | Nov 02, 2022 | #MSA00002   | Handled Code For AML Monthly flexcube transactions.
      |0.1 Beta    | Madhura    | Nov 04, 2022 | #MSA00003   | Handled Code For Summary Server call of AML Monthly flexcube transactions.
      |0.1 Beta	   | Sindhu     | Nov 04, 2022 | #SRM00006   | Handled code for the excess income summary page 
      |0.1 Beta	   | Madhura    | Nov 10, 2022 | #MSA00004   | Handled code for Monthly, according to DB changes
      |0.1 Beta    | Sindhu     | Nov 11, 2022 | #SRM00007   | Handled code for yearly ID document expiration check pdf and changed FlexCube function names
      |0.1 Beta    | Sindhu     | Nov 17, 2022 | #SRM00009   | Handled code for individual customer ID document check and added branch to yearly excess income
	  |0.1 Beta    | Madhura    | Nov 23, 2022 | #MSA00005   | Handled code for creating excel sheet
	  |0.1 Beta    | Manikanta  | Nov 29, 2022 | #MVT00096	 | Added code to handle pdf statement url
	  |0.1 Beta	   | Manikanta  | Feb 14, 2023 | #MVT00106   | Added code to send querterly customer report
	  |0.1 Beta    | Madhura    | Apr 20, 2023 | #MSA00006   | Handled code for creating excel sheet for daily aml transactions
	  |0.1 Beta    | Madhura    | Apr 20, 2023 | #MSA00007   | Handled code for creating excel sheet for daily flexcube aml transactions
	  |0.1 Beta    | Madhura    | Apr 21, 2023 | #MSA00008   | Handled code for converting amount with decimals and adding am/pm to date
	  |0.1 Beta    | Madhura    | Apr 24, 2023 | #MSA00009   | Handled code for flexcube according date format
	  |0.1 Beta    | Madhura    | May 01, 2023 | #MSA00010   | Handled code for printing PageNo and Headlines to the pages of PDF
	  |0.1 Beta    | Manikanta  | may 09, 2023 | #MVT00114	 | added code for Loan amortization and Loan pdf issue
	  |0.1 Beta    | Madhura    | May 11, 2023 | #MSA00011   | Handled code for adding images on PDF pages
	  |0.1 Beta    | Sindhu     | June 16,2023 | #SRM00043   | Handled code for sorting excess income checks according to trn completion time
	  |0.1 Beta    | Madhura    | June 19,2023 | #MSA00019   | Handled code for adding images for Quarterly PDF
	  |0.1 Beta    | Manikanta  | June 26,2023 | #MVT00125   | Added code to handle additional data in aml transactions
	  |0.1 Beta    | Manikanta  | June 27,2023 | #MVT00126   | Added code to aml summary data
	  |0.1 Beta    | Madhura    | June 30,2023 | #MSA00022   | Added code for adding date in Letter request
 	  |0.1 Beta    | Manikanta  | June 30,2023 | #MVT00127   | Added code for nature of business pdf report
 	  |0.1 Beta    | Sindhu     | July 06,2023 | #SRM00047   | Added code for geographic location pdf report
 	  |0.1 Beta    | Madhura    | July 18,2023 | #MSA00024   | Added code for Risk Profiling report
 	  |0.1 Beta    | Sumit      | July 19,2023 | #SKG00016   | Added code for daily flexcube report
 	  |0.1 Beta	   | Srikanth   | July 20,2023 | #SRI00002   | changed filename to reportType for monthly transaction report
 	  |0.1 Beta	   | Madhura    | July 24,2023 | #MSA00025   | Added code for Black and White list Member
 	  |0.1 Beta	   | Srikanth   | July 26,2023 | #SRI00005   | Changed filename and reportType for monthly transaction adding Date Format
 	  |0.1 Beta    | Pavithra   | Aug  01,2023 | #PAV00007   | Called exportSummaryData function , handled default pagination and changed object name
 	  |0.1 Beta    | Pavithra   | Aug  03,2023 | #PAV00009   | Handled sorting for Document checks
 	  |0.1 Beta    | Pavithra   | Aug  07,2023 | #PAV00010   | Handled AmlType and added source field
 	  |0.1 Beta    | Tarun      | Aug 08, 2023 | #TKS00020   | Added changes for KYC checks#MVT00136
 	  |0.1 Beta    | Madhura    | Aug 19, 2023 | #MSA00031   | Implemented TECU generated PDF for Quarterly Statement reports
 	  |0.1 Beta    | Sindhu     | Aug 25,2023  | #SRM00056   | Added code for accounts opened in last 6 months pdf report
 	  |0.1 Beta    | Madhura    | Aug 25,2023  | #MSA00034   | Added code for accounts opened in last 6 months pdf report only for 100 Branch code
 	  |0.1 Beta    | Manikanta  | Aug 28,2023  | #MVT00136   | Added code for monthly flexcube aml transaction reports
 	  |0.1 Beta    | Madhura    | Aug 31,2023  | #MSA00036   | Added code for Letter Request Template
	  |0.1 Beta    | Srikanth   | Sep 26,2023  | #SRI00007   | handled the ExportCsv File for the ExportSummaryData
	  |0.1 Beta    | Manikanta  | Oct 20,2023  | #MVT00140   | Added code for daily and monthly aml reports
	  |0.1 Beta    | Sindhu     | Oct 27,2023  | #SRM00066   | Handled code to trigger email for KYM and riskprofiling jobs
	  |0.1 Beta    | Madhura    | Oct 27,2023  | #MSA00045   | Added code for embassy PDF format for Letter Request
	  |0.1 Beta    | Sindhu     | Nov 02,2023  | #SRM00068   | Handled the OTP validation and trn creation for loan repayment 
	  |0.1 Beta    | Pavithra   | Nov 03,2023  | #PAV00020   | Handled amltype, created date and currver fields for flexcube transcation
	  |0.1 Beta    | Srikanth   | Nov 06,2023  | #SRI00017   | Handled the code For the Monthly report job Status part
	  |0.1 Beta    | Srikanth   | Nov 15,2023  | #SRI00022   | Handled the code For the data set filter for the yearly reports 
	  |0.1 Beta    | Srikanth   | Nov 15,2023  | #SRI00023   | Handled the code For the data set filter for the Monthly reports 
	  |0.1 Beta    | Pavithra   | Dec 14,2023  | #PAV00032   | Handled code changes for signature for Letter Request
	  |0.1 Beta    | Sumit      | Dec 14 2023  | #SKG00039   | Added code for  risk profile getLocReport,getACHTrnReport,blacklisted,whitelisted
	  |0.1 Beta    | Sumit      | Dec 19 2023  | #SKG00040   | Added code for  MONTHLY_REPORT headers part did not get in case of not record found	 
	  |0.1 Beta    | Pavithra   | Dec 20 2023  | #PAV00033   | Added code changes required for IJB00025 JOb
	  |0.1 Beta    | Sumit      | Dec 23 2023  | #SKG00041   | Added code for Daily report and  MONTHLY_REPORT  not getting report type    	  
	  |0.1 Beta    | Sumit      | Dec 28 2023  | #SKG00042   | Added code for Daily report and  MONTHLY_REPORT  Job Optimization 
	  |0.1 Beta    | Srikanth   | Feb 15,2024  | #SRI00032   | Handled the code to check if the email and phone number are present in the database.
	  |0.1 Beta	   | Srikanth   | Mar 20,2024  | #SRI00043   | Code handling for the High Risk Report 
	  |0.1 Beta	   | Srikanth   | Mar 26,2024  | #SRI00044   | code added for the Letter request PDF changes for address field
	  |0.1 Beta	   | Srikanth   | Mar 28,2024  | #SRI00045   | code added for the Letter request PDF changes for address field for Bank Scenario
	|0.1 Beta	   | Srikanth   | Mar 28,2024  | #SRI00046   | code added for the Transaction in to the DB(Loan Repayment)
    -----------------------------------------------------------------------------------------------------------------------------------------------------------------
*/  	
// #00000001 Begins
package net.sirma.impacto.iapp.icontrollers.isrvccontrollers;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import net.sirma.impacto.iapp.icommunication.iemail.IEmailService;
import net.sirma.impacto.iapp.icommunication.isms.ISmsService;
import net.sirma.impacto.iapp.iconfig.PropLoader;
import net.sirma.impacto.iapp.icontrollers.iactioncontrollers.IReqManipulator;
import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.GenericAppController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IKYCController;
import net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IMbpmContorller;
import net.sirma.impacto.iapp.ihelpers.IPDFPopulatorKeyMapping;
import net.sirma.impacto.iapp.ihelpers.IPDFTextExtractor;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IFuncSrvcController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//
	private DBController db$Ctrl = new DBController();
	private static final Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private IEmailService i$Email = new IEmailService();
	private ISmsService I$ISmsService = new ISmsService();
	private IReqManipulator i$ReqM = new IReqManipulator();
	private IResPreFlightHandler i$respre = new IResPreFlightHandler();
	private ImpactoUtil I$Imputils = new ImpactoUtil();
	private static final IMbpmContorller imbpm = new IMbpmContorller();
	private Ioutils I$Ioutils = new Ioutils();
	private ImpactoUtil i$impactoUtil = new ImpactoUtil();
	private GenericAppController i$genAppCtrl = new GenericAppController();
	private static final Logger logger = LoggerFactory.getLogger(IFuncSrvcController.class); // Nye- Change
	private static String strJNDI = I$utils.$strValNullIf(PropLoader.env.getProperty("etl.oracle.jndi"),
			"java:jboss/datasources/ImpactoOrclEtlDS");
	private DataSource dsOrclEtl = null;
	private Ioutils i$outis = new Ioutils();
    
	@Autowired
	private OtpController OtpCntrlr; // SRM00068 Changes to inject dependency automatically
//	@Autowired
//	private IMbpmContorller imbpm ;

// Class Name
	// always
	// **********************************************************************//

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			String SrvOpr = i$ResM.getSrvcopr(isonMsg);
			String scrId = i$ResM.getScreenID(isonMsg);
			String Opr3 = i$ResM.getOpr3(isonMsg);
			if (I$utils.$iStrFuzzyMatch(SrvOpr, "GET_RES")) {
				isonMsg = exeCallOrcl(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "AML_VALIDATION")) {// #SRP00066 Starts
				isonMsg = amlValidations(isonMsg);// #SRP00066 Ends
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "DAILY_REPORT")) { // PKY00078 changes
				isonMsg = amlTransactionsDailyReport(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "GET_REPORT")) { // #SRP00085 Starts
				isonMsg = amlTransactionsReport(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "FLEXCUBE_REPORT")) { // #SRP00085 Starts
				isonMsg = amlFlexcubeDailyTransactionsReport(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "YEARLY_REPORT")) { // #SRM00003 Starts
				isonMsg = amlFlexcubeYearlyTransactionsReport(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "MONTHLY_REPORT")) { // MSA00002 changes
				isonMsg = amlFlexcubeMonthlyTransactionsReport(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(scrId, "SB2IDEXP")) { // MSA00003 changes
				isonMsg = amlMonthlyIDExp(isonMsg);
				if(I$utils.$iStrFuzzyMatch(Opr3, "export")||(I$utils.$iStrFuzzyMatch(Opr3, "exportCsv"))){ //SRI00007 Changes
					isonMsg = i$respre.exportSummaryData(isonMsg); //#PAV00007 changes
	        	}
			} else if (I$utils.$iStrFuzzyMatch(scrId, "SB2EXINC")) { // #SRM00006 changes
				isonMsg = amlYearlyExcessInc(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "CALCULATE")) { //#MVT00114 changes
				isonMsg = calculateLoanDetails(isonMsg);
			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "GENERATE_REPORT")) { //#MVT00126 changes
				isonMsg = generateReports(isonMsg);
//			} else if (I$utils.$iStrFuzzyMatch(SrvOpr, "LOC_REPORT")) { //#SRM00047 changes
//				isonMsg = getLocReport(isonMsg);
			}
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED", e.getMessage().toString());
			e.printStackTrace();
			return isonMsg;
		}
		return isonMsg;
	};

	private Connection getConn() {

		// logger.info("BIGINWT VALUE IS"+Types.BIGINT );
		Connection Conn = null;
		boolean bSucc = false;
		int iRtryCnt = 0;
		int iRtryConn = 0;

		do {
			try {
				Context ctx = new InitialContext();
				dsOrclEtl = (DataSource) ctx.lookup(strJNDI);
				do {
					Conn = dsOrclEtl.getConnection();
					iRtryConn++;
					if (!Conn.isClosed()) {
						break;
					}
				} while (iRtryConn <= 6);

				logger.debug("DB Connection Succeed in Retry" + Integer.toString(iRtryCnt));
				bSucc = true;
				break;
			} catch (NamingException e) {
				e.printStackTrace();
				logger.debug("Failed to Connect.." + e.getMessage());
				try {
					logger.debug("Sleeping before Retry..");
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				iRtryCnt++;
				logger.debug("Going for Retry.." + Integer.toString(iRtryCnt));
			} catch (SQLException e) {
				e.printStackTrace();
				logger.debug("DB Connection failed.." + e.getMessage());
				try {
					logger.debug("Sleeping before Retry..");
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				iRtryCnt++;
				logger.debug("Going for Retry.." + Integer.toString(iRtryCnt));
			}
		} while (iRtryCnt <= 3);

		if (bSucc)
			logger.debug("Success in Retry.." + Integer.toString(iRtryCnt));
		else
			logger.debug("Failed even after " + Integer.toString(iRtryCnt) + " no retries");

		return Conn;
	};

	public JsonObject exeCallOrcl(JsonObject argJson) {// #SRP00042 changes
		JsonObject i$body = argJson.get("i-body").getAsJsonObject();  //#SRM00068 changes for OTP validation along with trn create starts
		
		if (i$body.has("otp")) {
			OtpController OtpCntrlr = new OtpController();
			JsonObject isonMsgOTP = OtpCntrlr.verifyOTP(i$body, argJson);
			if (I$utils.$iStrFuzzyMatch(
					isonMsgOTP.get("i-stat").getAsJsonObject().get("i-statMsg").getAsString(), "i-ERROR")) {
				argJson.remove("i-body");
				return argJson;
			} 
		} //#SRM00068 changes end
		String strQry;
		Connection conn = null;
		CallableStatement stmt = null;

//		JsonObject i$body = argJson.get("i-body").getAsJsonObject(); // #PKY00001 starts

		JsonObject accountDetailsObj = new JsonObject();

//		if (i$body.has("letterObj")) {
//			JsonObject letterDetails = i$body.get("letterObj").getAsJsonObject();
//		}
		JsonArray funcDetails = new JsonArray();
		if (i$body.has("funcDetails"))
			funcDetails = i$body.get("funcDetails").getAsJsonArray();
		else
			funcDetails.add(i$body);
		
		if(argJson.has("i-header")) {
		if(I$utils.$iStrFuzzyMatch(argJson.get("i-header").getAsJsonObject().get("srvcname").getAsString(), "AMLCHECK") && 
				I$utils.$iStrFuzzyMatch(argJson.get("i-header").getAsJsonObject().get("srvcopr").getAsString(), "MONTHLY_REPORT")) {
			JsonObject filter = new JsonObject();
			filter.addProperty("Type", "CBS_BRANCH");
			filter.addProperty("KeyId", "100");
			JsonObject proj = new JsonObject();
			proj.addProperty("BranchDate", 1);
			JsonObject cbsData = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter , proj);
			String date = cbsData.get("BranchDate").getAsString();
			i$body.get("funcDetails").getAsJsonArray().get(1).getAsJsonObject().addProperty("p_dt" , date);
			i$body.get("funcDetails").getAsJsonArray().get(2).getAsJsonObject().addProperty("p_dt" , date);
			i$body.get("funcDetails").getAsJsonArray().get(3).getAsJsonObject().addProperty("p_dt" , date);
			i$body.get("funcDetails").getAsJsonArray().get(4).getAsJsonObject().addProperty("p_dt" , date);
		}
		}
		JsonArray iBodyDetFunc = new JsonArray();
		JsonObject funcRes = new JsonObject();
		try {
			logger.debug("Trying for DB Connection");

			try {
				for (int j = 0; j < funcDetails.size(); j++) {
					try {
						JsonArray accountDetails = new JsonArray();
						JsonObject funcData = new JsonObject();
						JsonObject iBody = funcDetails.get(j).getAsJsonObject();
						String funcName = iBody.get("funcName").getAsString(); // #PKY00001 ends

						JsonObject funcDet = db$Ctrl.db$GetRow("ICOR_M_BRIDGE_FUNC",
								"{'funcName':'" + iBody.get("funcName").getAsString() + "'}");
						if (!I$utils.$isNull(funcDet)) {
							conn = getConn();
							conn.setAutoCommit(false);
							strQry = funcDet.get("QUERY").getAsString();
							stmt = conn.prepareCall(strQry);
							JsonArray params = funcDet.get("inParams").getAsJsonArray();
							for (int i = 0; i < params.size(); i++) {
								JsonObject currObj = params.get(i).getAsJsonObject();
								String fieldName = currObj.get("fieldName").getAsString();
								String fieldType = currObj.get("fieldType").getAsString();
								if (I$utils.$iStrFuzzyMatch(fieldType, "STRING")) {
									stmt.setString(i + 2, iBody.get(fieldName).getAsString());
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "INTEGER")) {
									stmt.setInt(i + 2, iBody.get(fieldName).getAsInt());
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "FLOAT")) {
									stmt.setFloat(i + 2, iBody.get(fieldName).getAsFloat());
								}
							}

							params = funcDet.get("outParams").getAsJsonArray();
							for (int i = 0; i < params.size(); i++) {
								JsonObject currObj = params.get(i).getAsJsonObject();
								String fieldName = currObj.get("fieldName").getAsString();
								String fieldType = currObj.get("fieldType").getAsString();
								if (I$utils.$iStrFuzzyMatch(fieldType, "STRING")) {
									stmt.registerOutParameter(i + 1, Types.VARCHAR);
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "INTEGER")) {
									stmt.registerOutParameter(i + 1, Types.INTEGER);
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "FLOAT")) {
									stmt.registerOutParameter(i + 1, Types.FLOAT);
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "DATE")) {
									stmt.registerOutParameter(i + 1, Types.DATE);
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "CLOB")) { // #PKY00002 chnages
									stmt.registerOutParameter(i + 1, Types.CLOB);
								}
							}
							stmt.execute();
							for (int i = 0; i < params.size(); i++) {
								JsonObject currObj = params.get(i).getAsJsonObject();
								String fieldName = currObj.get("fieldName").getAsString();
								String fieldType = currObj.get("fieldType").getAsString();
								if (I$utils.$iStrFuzzyMatch(fieldType, "STRING")) {
									iBody.addProperty(fieldName, stmt.getString(i + 1));
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "INTEGER")) {
									iBody.addProperty(fieldName, stmt.getInt(i + 1));
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "FLOAT")) {
									iBody.addProperty(fieldName, stmt.getFloat(i + 1));
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "DATE")) {
									iBody.addProperty(fieldName, stmt.getDate(i + 1).toString());
								} else if (I$utils.$iStrFuzzyMatch(fieldType, "CLOB")) { // #PKY00002 starts
									Clob clob = stmt.getClob(i + 1);
									Reader reader = clob.getCharacterStream();
									StringBuffer buffer = new StringBuffer();
									int ch;
									while ((ch = reader.read()) != -1) {
										buffer.append("" + (char) ch);
									}
									iBody.addProperty(fieldName, buffer.toString());
								} // #PKY00002 ends
							};
							funcData.add(funcName, iBody); // #PKY00001 changes
							// SKP00001 Starts
							String date = I$utils.$getISONowAm();
							if (I$utils.$iStrFuzzyMatch(funcName, "fn_getCIFLoanDCNDigi")) {
								JsonObject funcDataObj = funcData.get("fn_getCIFLoanDCNDigi").getAsJsonObject();
								String l_data = funcDataObj.get("l_data").getAsString();
								String[] fields = l_data.split("\n");
								for (int i = 0; i < fields.length; i++) {
									accountDetailsObj = new JsonObject();
									String feild = fields[i];
									accountDetailsObj.addProperty("keyId", "00" + i);
									accountDetailsObj.addProperty("keyDesc", feild);
									accountDetails.add(accountDetailsObj);
								}
								JsonObject response = new JsonObject();
								response.addProperty("funcName", iBody.get("funcName").getAsString());
								response.addProperty("p_loan_no", iBody.get("p_loan_no").getAsString());
								response.add("accountDetails", accountDetails);
								iBodyDetFunc.add(response);
							} else if (I$utils.$iStrFuzzyMatch(funcName, "GET_TRN_RECONCILIATION")) {
								JsonObject funcDataObj = funcData.get("GET_TRN_RECONCILIATION").getAsJsonObject();
								String l_data = funcDataObj.get("l_data").getAsString();
								String[] fields = l_data.split("\n");
								for (int i = 0; i < fields.length; i++) {
									accountDetailsObj = new JsonObject();
									String feild = fields[i];
									String[] data = feild.split("~");
									accountDetailsObj.addProperty("Transaction Ref No", data[0]);
									accountDetailsObj.addProperty("Branch", data[1]);
									accountDetailsObj.addProperty("Account No", data[2]);
									accountDetailsObj.addProperty("Amount", data[3]);
									accountDetailsObj.addProperty("Transaction type", data[4]);
									accountDetailsObj.addProperty("Date", data[5]);
									accountDetails.add(accountDetailsObj);
								}
								JsonObject response = new JsonObject();
								response.addProperty("funcName", iBody.get("funcName").getAsString());
								response.add("accountDetails", accountDetails);
								iBodyDetFunc.add(response);
							}else if (I$utils.$iStrFuzzyMatch(funcName, "fn_getCIFShareDetails")) {
								JsonObject result = generateMiniStatement(funcData, argJson);
								return result;
							}else if (I$utils.$iStrFuzzyMatch(funcName, "GET_LOAN_REPAYMENT_DETAILS")) {// MSA changes
								String tranId = i$body.get("tranId").getAsString();
								iBody.addProperty("tranId", tranId);
								JsonObject finalResult = sendEmail(iBody);
								iBodyDetFunc.add(finalResult);
							}else if (I$utils.$iStrFuzzyMatch(funcName, "GET_CIF_SHARE_DEPOSIT")) {// MSA changes
								return funcData;
							}else if (I$utils.$iStrFuzzyMatch(funcName, "fn_cifaccountreopen")) {// MSA changes
								return funcData;
							}else if (I$utils.$iStrFuzzyMatch(funcName, "GET_CUST_QUARTERLY_STMT")) {// #MVT00106 changes begins
								if (funcData.get("GET_CUST_QUARTERLY_STMT").getAsJsonObject().get("l_data")
										.getAsString().contains("statement has not been generated")) {
									argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_ERR,funcData.get("GET_CUST_QUARTERLY_STMT").getAsJsonObject().get("l_data")
													.getAsString());
									return argJson;
								}
								return sendQuerterlyReport(funcData, argJson);// #MVT00106 changes ends
							}
							else if (I$utils.$iStrFuzzyMatch(funcName, "GET_CUST_REKYM_INFO")) {     // SRI00032 changes starts
								String l_data = funcData.getAsJsonObject("GET_CUST_REKYM_INFO").get("l_data")
										.getAsString();
								String p_cust_no = funcData.getAsJsonObject("GET_CUST_REKYM_INFO").get("p_cust_no")
										.getAsString();
								String[] parts = l_data.split(" - ");
								String email = null;
								String phoneNumber = null;
								JsonObject projection = new JsonObject();
								JsonObject filter = new JsonObject();

								if (parts.length >= 8) {
									email = parts[6];
									phoneNumber = parts[7];
								}
								if (!I$utils.$iStrFuzzyMatch(email, "") && !I$utils.$iStrFuzzyMatch(phoneNumber, "")) {
									iBodyDetFunc.add(funcData);
								} else {
									// Check if email and phone number are present in the database
									projection.addProperty("_id", 0);
									projection.addProperty("CustomerMobileId", 1);
									projection.addProperty("CustomerEmailId", 1);
									filter.addProperty("CustomerId", p_cust_no);
									JsonObject db$res = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projection);
									email = db$res.get("CustomerEmailId").getAsString();
									phoneNumber = db$res.get("CustomerMobileId").getAsString();
									if (!I$utils.$iStrFuzzyMatch(email, "")) {
										parts[6] = email;
							        }
							        if (!I$utils.$iStrFuzzyMatch(phoneNumber, "")) {
							        	parts[7]= phoneNumber;
							        }
							        l_data = String.join(" - ", parts);
									if (!I$utils.$iStrFuzzyMatch(email, "") || !I$utils.$iStrFuzzyMatch(phoneNumber, "")) {
										funcData.getAsJsonObject("GET_CUST_REKYM_INFO").addProperty("l_data", l_data);
										iBodyDetFunc.add(funcData);
									} else {
										argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_WRN,
												"Please note that the Email or Mobile number is not present on the system. Request you to contact TECU Credit Union for further clarification");
										return argJson;
									}
								}
							}																		// SRI00032 changes ends
							else if(I$utils.$iStrFuzzyMatch(funcName, "GET_ACH_MONTH_COUNT") || 
									I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA") || 
									I$utils.$iStrFuzzyMatch(funcName, "GET_ALL_CASH_DAY") || 
									I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_50") ||
									I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_CH_50") ||
									I$utils.$iStrFuzzyMatch(funcName, "FN_PD_EXC_ALL_CASH_20") ||//SKG00042 chnages
									I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_50") || // SKG00016 changes
									I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_AC02_20")||
									I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHDP_50")||//SKG00042 changes
									I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_20")) {
								if(I$utils.$iStrFuzzyMatch(funcName, "GET_ACH_MONTH_COUNT")) {
									funcData.addProperty("fileName", "ACH_Monthly_Report"+"Listed_Business_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Calendar.getInstance().getTime())+".pdf");    //SRI00005
									funcData.addProperty("ReportType", "List of Members whose 'ACH + all Cheque transactions (BD04, BU02)' exceed TTD 50000- per month");//SKG00042 changes
								}
								else if(I$utils.$iStrFuzzyMatch(funcName, "GET_ALL_CASH_DAY")) {
									funcData.addProperty("fileName", "All_Cash_Monthly_Report"+"Listed_Business_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Calendar.getInstance().getTime())+".pdf");		//SRI00005
									funcData.addProperty("ReportType", "List of Members whose 'All Cash transactions (CHDP, CHWL, FTRQ)' exceed TTD 50000- per month");//SKG00042 changes
								}
								//SKG00042 starts
								else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHDP_50")) {
									funcData.addProperty("fileName", "fn_mno_exc_CHDP_50_Report"+"Listed_Business_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Calendar.getInstance().getTime())+".pdf");		//SRI00005
									funcData.addProperty("ReportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 50000- per month");
								}//SKG00042 end
								else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_50")) {
									funcData.addProperty("fileName", "fn_mno_exc_CHWL_50_Report"+"Listed_Business_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Calendar.getInstance().getTime())+".pdf");		//SRI00005
									funcData.addProperty("ReportType", "List of Members whose '1001 Cash Withdrawal' transactions exceed TTD 50000- per month");//SKG00042 changes
								}
								else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_CH_50")) {
									funcData.addProperty("fileName", "MONO_EXC_CHQ_CH_50_"+date+".pdf");
									funcData.addProperty("reportType", "List of Members whose 'Cheque + Cash' exceed TTD 50000- per day");//SKG00041 chnages
								}
								else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_50")) {
									funcData.addProperty("fileName", "MNO_EXC_CHQ_50_"+date+".pdf");
									funcData.addProperty("reportType", "List of Members whose 'All Cheque transactions (BD04, BU02)' exceed TTD 50000- per day");//SKG00041 changes
								}
								else if (I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_AC02_20")) {
									funcData.addProperty("fileName", "MONO_EXC_AC02_20_" + date + ".pdf");
									funcData.addProperty("reportType",
											"List of Members whose 'ACH' transactions exceed TTD 20000- per day");//SKG00041 chnages
								}
								else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_20")) {//
									funcData.addProperty("fileName", "CHWL Per Day Report"+date+".pdf");
								funcData.addProperty("reportType", "List of Members whose '1001 Cash Withdrawal' transactions exceed TTD 20000- per day");
								}
								//SKG00042 starts
								
								else if(I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA")) {//
									funcData.addProperty("fileName", "GET_CHDP_MONTH_DATA"+"Listed_Business_"+new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Calendar.getInstance().getTime())+".pdf");		//SRI00005
									funcData.addProperty("ReportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 50000- per month");
								}
								//SKG00041 starts
								else if(I$utils.$iStrFuzzyMatch(funcName, "FN_PD_EXC_ALL_CASH_20")) {//
									funcData.addProperty("fileName", "GET_ALL_CASH_DAY"+date+".pdf");
								funcData.addProperty("reportType", "List of Members whose 'All Cash transactions (CHDP, CHWL, FTRQ)' exceed TTD 20000- per day");
								}//SKG00042 end
//								else if(I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA")) {
//									funcData.addProperty("fileName", "GET_CHDP_MONTH_DATA"+date+".pdf");
//								funcData.addProperty("reportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 20000- per day");
//								}
//								
//								
								
//								if(I$utils.$iStrFuzzyMatch(funcName, "GET_ACH_MONTH_COUNT") || 
//										I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA") || 
//										I$utils.$iStrFuzzyMatch(funcName, "GET_ALL_CASH_DAY") || 
//										I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_50")) {
//									funcData.addProperty("ReportType", "MONTHLY REPORT");
//								}else {
//									funcData.addProperty("ReportType", "PER DAY REPORT");
//								}
//								
								if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_CH_50")) //SKG00042 starts
									funcData.addProperty("ReportType", "List of Members whose 'Cheque + Cash' exceed TTD 50000- per day");
								else if (I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_50")) /// not showing
									funcData.addProperty("ReportType", "List of Members whose 'All Cheque transactions (BD04, BU02)' exceed TTD 50000- per day");
								else if (I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_AC02_20"))
										funcData.addProperty("ReportType", "List of Members whose 'ACH' transactions exceed TTD 20000- per day");
								else if (I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_20")) /// showing
										funcData.addProperty("ReportType", "List of Members whose '1001 Cash Withdrawal' transactions exceed TTD 20000- per day");
								else if (I$utils.$iStrFuzzyMatch(funcName, "FN_PD_EXC_ALL_CASH_20"))
										funcData.addProperty("ReportType", "List of Members whose 'All Cash transactions (CHDP, CHWL, FTRQ)' exceed TTD 20000- per day");
//	
								else if (I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA"))
										funcData.addProperty("ReportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 20000- per day");
//	                          //SKG00042 end
//								else if (I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA"))
//										funcData.addProperty("ReportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 20000- per day");
//	
									
								else if (I$utils.$iStrFuzzyMatch(funcName, "GET_ACH_MONTH_COUNT"))
									funcData.addProperty("ReportType", "List of Members whose 'ACH + all Cheque transactions (BD04, BU02)' exceed TTD 50000- per month");//SKG00042 changes

								else if (I$utils.$iStrFuzzyMatch(funcName, "GET_ALL_CASH_DAY"))
									funcData.addProperty("ReportType", "List of Members whose 'All Cash transactions (CHDP, CHWL, FTRQ)' exceed TTD 50000- per month");//SKG00042 changes

								
								else if (I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHDP_50"))
									funcData.addProperty("ReportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 50000- per month");

								
								else if (I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_50"))
									funcData.addProperty("ReportType", "List of Members whose '1001 Cash Withdrawal' transactions exceed TTD 50000- per month");//SKG00042 changes

								
								
						//SKG00041 end		
								final IPDFTextExtractor pdfReport = new IPDFTextExtractor();
								JsonParser parser = new JsonParser();
								String data = "";
								try {//SKG00040 chnages
									if(I$utils.$iStrFuzzyMatch(funcName, "GET_ACH_MONTH_COUNT"))
										data = funcData.get("GET_ACH_MONTH_COUNT").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "GET_ALL_CASH_DAY"))
										data = funcData.get("GET_ALL_CASH_DAY").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHDP_50"))//SKG00042 changes
										data = funcData.get("fn_mno_exc_CHDP_50").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_50"))
										data = funcData.get("fn_mno_exc_CHWL_50").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_CH_50"))
										data = funcData.get("fn_mno_exc_CHQ_CH_50").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHQ_50"))
										data = funcData.get("fn_mno_exc_CHQ_50").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "FN_PD_EXC_ALL_CASH_20"))//SKG00042 changes
											data = funcData.get("FN_PD_EXC_ALL_CASH_20").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_AC02_20"))
										data = funcData.get("fn_mno_exc_AC02_20").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "fn_mno_exc_CHWL_20"))
										data = funcData.get("fn_mno_exc_CHWL_20").getAsJsonObject().get("l_data").getAsString();
									else if(I$utils.$iStrFuzzyMatch(funcName, "GET_CHDP_MONTH_DATA"))//SKG00042 chnages
										data = funcData.get("GET_CHDP_MONTH_DATA").getAsJsonObject().get("l_data").getAsString();
								}catch(Exception e) {
									JsonArray dataObj = new JsonArray();
									JsonObject ibody = new JsonObject();
									//SKG00040 starts
									String columns = "['Sl.No','Branch Code','Branch Name','Member Number','Account Number','Member Name','Transaction Amount','Debit or Credit' , 'Transaction Type' , 'Digi App / Flexcube']";
									String columnNames = "['Sl.No','Branch Code','Branch Name','Member Number','Account Number','Member Name','Transaction Amount','Debit or Credit' , 'Transaction Type' , 'Digi App / Flexcube']";
									JsonArray clms = parser.parse(columns).getAsJsonArray();
									JsonArray columnName = parser.parse(columnNames).getAsJsonArray();
									funcData.add("columns", clms);
									funcData.add("rowData", dataObj);
									funcData.add("columnNames", columnName);
									funcData.addProperty("noOfColumns", clms.size());
									ibody.add("i-body", funcData);
									ibody = pdfReport.generatePDFReport(ibody);
									iBodyDetFunc.add(ibody);
								}
								if(!I$utils.$iStrBlank(data)) {
									String[] dataArray = data.split("\n");
								//	SKG00040 end
									JsonArray dataObj = new JsonArray();
									JsonObject ibody = new JsonObject();
									NumberFormat formatter = new DecimalFormat("####,###,###.##");
									for(int i = 0 ; i < dataArray.length ; i++) {
										String runningString = dataArray[i];
										JsonObject runningObj = new JsonObject();  //#MVT00136 changes begins
//										try { //TKS00020 starts
//											runningObj.addProperty("Sl.No", runningString.split("~")[0]);
//										} catch (Exception e) {
	//
//										}
										try {
											runningObj.addProperty("Branch Code", runningString.split("~")[3].substring(0, 3));
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Branch Name", runningString.split("~")[1]);
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Member Number", runningString.split("~")[2]);
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Account Number", runningString.split("~")[3]);
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Member Name", runningString.split("~")[4]);
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Transaction Amount", runningString.split("~")[5]);
										} catch (Exception e) {
											
										}
										try {
											runningObj.addProperty("Debit or Credit", runningString.split("~")[6]);
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Transaction Type", runningString.split("~")[7]);
										} catch (Exception e) {

										}
										try {
											runningObj.addProperty("Digi App / Flexcube", runningString.split("~")[8]);
										} catch (Exception e) {

										} //TKS00020 end  
										dataObj.add(runningObj);
									} //#MVT00136 changes ends
									String columns = "['Sl.No','Branch Code','Branch Name','Member Number','Account Number','Member Name','Transaction Amount','Debit or Credit' , 'Transaction Type' , 'Digi App / Flexcube']";
									String columnNames = "['Sl.No','Branch Code','Branch Name','Member Number','Account Number','Member Name','Transaction Amount','Debit or Credit' , 'Transaction Type' , 'Digi App / Flexcube']";
									JsonArray clms = parser.parse(columns).getAsJsonArray();
									JsonArray columnName = parser.parse(columnNames).getAsJsonArray();
									funcData.add("columns", clms);
									funcData.add("rowData", dataObj);
									funcData.add("columnNames", columnName);
									funcData.addProperty("noOfColumns", clms.size());
									ibody.add("i-body", funcData);
									ibody = pdfReport.generatePDFReport(ibody);
									iBodyDetFunc.add(ibody);
								}	
							}else {
								iBodyDetFunc.add(funcData); // #PKY00001 changes					
							}
							// SKP00001 Ends
							stmt.close();
							stmt = null;
							conn.close(); // Return to connection pool
							conn = null; // Make sure we don't close it twice

						}
					} catch (Exception e) {

						stmt.close();
						stmt = null;
						conn.close(); // Return to connection pool
						conn = null; // Make sure we don't close it twice
					}
				}
				funcRes.add("funcRes", iBodyDetFunc); // #PKY00001 changes
				argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i-body", funcRes);
				argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

			} catch (Exception e) {
				argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_ERR, "OPERATION FAILED");
			}
			;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Always make sure result sets and statements are closed,
			// and the connection is returned to the pool

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}

		}
		return argJson;
	}

	private JsonObject db$GetRow(String string, JsonObject filter, JsonObject projection) {
		// TODO Auto-generated method stub
		return null;
	}

	// #MVT00106 begins
	public JsonObject sendQuerterlyReport(JsonObject funcData, JsonObject argJson) {
		try {
			JsonObject filter = new JsonObject();
			JsonObject projctn = new JsonObject();
			JsonObject map$Data = new JsonObject();
			JsonObject resBody = new JsonObject();
			JsonArray attachment = new JsonArray();
			JsonObject requestObj = new JsonObject();
			JsonObject toEmailIds = new JsonObject();
			JsonObject emailObject = new JsonObject();
			JsonObject mobile$numbers = new JsonObject();
			JsonObject ibody = argJson.get("i-body").getAsJsonObject();
			String accNumber = funcData.get("GET_CUST_QUARTERLY_STMT").getAsJsonObject().get("p_cust_ac_no").getAsString();
			String cif = accNumber.substring(3, 9);
			projctn.addProperty("_id", 0);
			projctn.addProperty("CustomerEmailId", 1);
			projctn.addProperty("CustomerMobileId", 1);
			filter.addProperty("CustomerId", cif);
			JsonObject cifData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filter, projctn);
			String statements = funcData.get("GET_CUST_QUARTERLY_STMT").getAsJsonObject().get("l_data").getAsString();
			/*ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
			//MSA00019 starts
			document.setMargins(10, 10, 140, 200);
			PdfWriter writer1 = PdfWriter.getInstance(document, byteArrayOutputStream);
			HeaderFooterPageEvent3 event = new HeaderFooterPageEvent3();
			writer1.setPageEvent(event);
			event.onStartPage(writer1, document);
			event.onEndPage(writer1, document);
			//MSA00019 ends
			
			document.open();
			Font font = new Font(FontFamily.COURIER, 8, Font.NORMAL, BaseColor.BLACK);
			Chunk content = new Chunk(sample);
			Paragraph para = new Paragraph();

			para.setFont(font);
			para.setLeading(0, 1);
			para.setAlignment(para.ALIGN_JUSTIFIED_ALL);
			para.add(content);
			document.add(para);
			document.close();
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(pdfBytes);*/
			//MSA00031 starts
			try {
			String []statementsArr = statements.split("\n");
			for(int i=0; i< statementsArr.length; i++) {
				try {
				String trimStr = statementsArr[i].trim();
				String str = statementsArr[i];
				
				if(i == 0) {
					statements = statements.replace(str, trimStr);
				}
				if (trimStr.startsWith("Period")) {
					statements = statements.replace("                                Period         :", "                                Period         :");
				}
				if (trimStr.startsWith("Loan Number")) {
					statements = statements.replace("                                Loan Number     :", "                                Loan Number    :");
				}
				if (trimStr.startsWith("Loan Type")) {
					statements = statements.replace("                                Loan Type     :", "                                Loan Type      :");
				}
				if (trimStr.startsWith("Installments")) {
					statements = statements.replace("                                Installments    :", "                                Installments   :");
				}
				if (trimStr.startsWith("Opening Balance")) {
					statements = statements.replace("         Opening Balance:                                     ", "         Opening Balance : ");
				}
				if (trimStr.startsWith("DATE")) {
					statements = statements.replace(trimStr,"   "+trimStr);
				}
				if (trimStr.startsWith("INTEREST")) {
					statements = statements.replace("INTEREST         :", "INTEREST          :");
				}
				if (trimStr.startsWith("PENALTY INTEREST")) {
					statements = statements.replace("PENALTY INTEREST :", "PENALTY INTEREST  :");
				}
				if (trimStr.startsWith("OVERDUE INTEREST :")) {
					statements = statements.replace("OVERDUE INTEREST :", "OVERDUE INTEREST  :");
				}
				if (trimStr.startsWith("Member No")) {
					statements = statements.replace("                                        Member No   :", "                                        Member No    :");
				}
				if (trimStr.startsWith("Account No")) {
					statements = statements.replace("                                        Account No  :", "                                        Account No   :");
				}
				if (trimStr.startsWith("Account Type")) {
					statements = statements.replace("                                        Account Type:", "                                        Account Type :");
				}
				if (trimStr.startsWith("Branch")) {
					statements = statements.replace("                                        Branch      :", "                                        Branch       :");
				}
				if (trimStr.startsWith("OPENING BALANCE")) {
					statements = statements.replace("   OPENING BALANCE         ", "OPENING BALANCE :");
				}
				if (trimStr.startsWith("Statement From")) {
					statements = statements.replace("Statement From          :", "Statement   From  :");
				}
				if (trimStr.startsWith("AVAILABLE BALANCE")) {
					statements = statements.replace("   AVAILABLE BALANCE:", "AVAILABLE BALANCE :");
				}
			}catch(Exception e) {
				e.printStackTrace();
			   }
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			Document document = new Document(PageSize.A4);
			PdfWriter writer = PdfWriter.getInstance(document, baos);
			document.setMarginMirroring(true);
			document.setMargins(20, 20, 170, 80);
			HeaderFooterPageEvent5 event2 = new HeaderFooterPageEvent5();
			writer.setPageEvent(event2);
			event2.onStartPage(writer, document);
			document.open();
			Font font = new Font(FontFamily.COURIER, 8, Font.NORMAL, BaseColor.BLACK);
			Chunk content1 = new Chunk(statements);
			Paragraph para = new Paragraph();

			para.setFont(font);
			para.setLeading(0, 1);
			para.add(content1);
			document.add(para);
			document.close();

			int pageCount = writer.getPageNumber();
			byte[] pdfAsBytes = baos.toByteArray();
			Font smallFont = new Font(FontFamily.COURIER, 7, Font.NORMAL, BaseColor.BLACK);
			PdfReader reader = new PdfReader(pdfAsBytes);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			DataOutputStream output = new DataOutputStream(outputStream);
			document = new Document();
			document.open();
			PdfStamper stamper = new PdfStamper(reader, output);
			for (int j = 1; j <= pageCount; j++) {
				ColumnText.showTextAligned(stamper.getOverContent(j), Element.ALIGN_CENTER,
						new Phrase(j + " / " + pageCount, smallFont), 280, 30, 0);
			}
			stamper.close();
			byte[] finalPdfAsBytes = outputStream.toByteArray();
			String base64String = java.util.Base64.getEncoder().encodeToString(finalPdfAsBytes);//MSA00031 ends

			if (I$utils.$iStrFuzzyMatch(ibody.get("sendEmail").getAsString(), "true")) {
				map$Data.addProperty("FullName", "Test");
				map$Data.addProperty("tmp$name", "TMPL#TT#CUSTOMER#QUERTERLY#REPORT#MAIL");
				emailObject.addProperty("template", base64String);
				emailObject.addProperty("docType", "application/pdf");
				emailObject.addProperty("fileName", "CUSTOMER QUARTERLY REPORT" + ".pdf");
				attachment.add(emailObject);
				toEmailIds.addProperty("toemailid1", cifData.get("CustomerEmailId").getAsString());
				mobile$numbers.addProperty("Mob_Number1", cifData.get("CustomerMobileId").getAsString());

				requestObj.add("map$Data", map$Data);
				requestObj.add("attachment", attachment);
				requestObj.add("toemailIds", toEmailIds);
				requestObj.add("mobile$numbers", mobile$numbers);
				JsonObject i$resE = i$Email.SendEmailWOThread(requestObj);
				JsonObject i$resM = I$ISmsService.SendSMSWOThread(requestObj);
				argJson = i$ResM.iHandleResStat(argJson, i$ResM.I_SUCC, "EMAIL SENT SUCCESSFULLY");
			}

			if (I$utils.$iStrFuzzyMatch(ibody.get("download").getAsString(), "true")) {
				ibody.addProperty("downloadData", base64String);
				argJson = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argJson, "i-body", ibody);
			}
			
//		    PDDocument doc = PDDocument.load(sample);
			/*
			 * StringBuffer sb = new StringBuffer(); Reader inputString = new
			 * StringReader(sample); BufferedReader br = new BufferedReader(inputString);
			 * 
			 * String content = null; while ((content = br.readLine()) != null) {
			 * sb.append(content); } String text = sb.toString();
			 * 
			 * //Create a pdf document PdfDocument doc = new PdfDocument(); PdfSection
			 * section = doc.getSections().add(); PdfPageBase page =
			 * section.getPages().add(); //Create a PdfFont PdfTrueTypeFont font = new
			 * PdfTrueTypeFont(new Font("Calibri", Font.PLAIN, 20));
			 * 
			 * //Set string format PdfStringFormat format = new PdfStringFormat();
			 * format.setLineSpacing(20f); PdfBrush brush = PdfBrushes.getBlack();
			 * PdfTextLayout textLayout = new PdfTextLayout();
			 * textLayout.setBreak(PdfLayoutBreakType.Fit_Page);
			 * textLayout.setLayout(PdfLayoutType.Paginate); Point2D bounds = new
			 * Point2D.Float(); // bounds.setRect(10, 20,
			 * page.getCanvas().getClientSize().getWidth(),
			 * page.getCanvas().getClientSize().getHeight());
			 * 
			 * PdfTextWidget textWidget = new PdfTextWidget(text, font, brush);
			 * textWidget.setStringFormat(format); textWidget.draw(page, bounds,
			 * textLayout);
			 * 
			 * 
			 * //Save doc.close();
			 */
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}
		return argJson;
	}

	// #MVT00106 changes ends
	
	// SRM00049 Changes start
	public void getTrnExceedReport(String scanId) {

		JsonObject argObj = new JsonObject();
		JsonObject i$bdy = new JsonObject();
		try {
			final IPDFTextExtractor pdfReport = new IPDFTextExtractor();
			JsonObject filter = new JsonObject();
			JsonObject filt = new JsonObject();
			JsonObject filtr = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonParser parser = new JsonParser();
			JsonObject resObj = new JsonObject();
			JsonArray resArray = new JsonArray();
			JsonObject updateObj = new JsonObject();
			JsonArray funcDetails = new JsonArray();
			JsonObject funObject = new JsonObject();


			filter.addProperty("Type", "CBS_BRANCH");
			projection.addProperty("_id", 0);
			projection.addProperty("BranchDate", 1);
			resObj = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter, projection);

			funObject.addProperty("funcName", "GET_CIF_EXCEED_10");
			funObject.add("p_dt", resObj.get("BranchDate"));
			funcDetails.add(funObject);
			i$bdy.add("funcDetails", funcDetails);
			argObj.add("i-body", i$bdy);
			JsonObject res = exeCallOrcl(argObj);
			JsonObject ibody = res.get("i-body").getAsJsonObject();
			JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
			JsonObject functionobject = funcRes.get(0).getAsJsonObject().get("GET_CIF_EXCEED_10").getAsJsonObject();
			String op_output = functionobject.get("l_data").getAsString();
			String[] op = op_output.split("\n");
			projection.addProperty("CustomerBranch", 1);
			projection.addProperty("BranchName", 1);
			projection.addProperty("CustomerId", 1);
			projection.addProperty("CustomerFullName", 1);

			String fYear = null;
			String pCode = null;
			try {
				Calendar calendar = Calendar.getInstance();
				int month = calendar.get(Calendar.MONTH) + 1;
				int year = calendar.get(Calendar.YEAR);
				if (month <= 9) {
					pCode = "M0" + month;
				} else {
					pCode = "M" + month;
				}
				fYear = "FY" + year;
			} catch (Exception e) {

			}

			for (int i = 0; i < op.length; i++) {
				try {
		            JsonObject dbData = new JsonObject();
					String arr1 = op[i];
					String[] data = arr1.split("~");
					String cifId = data[0];
					String no_of_trn = data[1];
					filtr.addProperty("CustomerId", cifId);
					JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filtr, projection);
					dbData.addProperty("CustomerBranch", usrData.get("CustomerBranch").getAsString());
					dbData.addProperty("BranchName", usrData.get("BranchName").getAsString());
					dbData.addProperty("CustomerId", usrData.get("CustomerId").getAsString());
					dbData.addProperty("CustomerFullName", usrData.get("CustomerFullName").getAsString());
					dbData.addProperty("TotalTrn", no_of_trn);
					resArray.add(dbData);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			String columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName', 'TotalTrn']";
			String columnNames = "['Sl.No','Branch','Branch Name','Member ID','Member Name', 'No. of Transations per month']";
			JsonArray clms = parser.parse(columns).getAsJsonArray();
			JsonArray columnName = parser.parse(columnNames).getAsJsonArray();

			ibody.add("columns", clms);
			ibody.add("rowData", resArray);
			ibody.add("columnNames", columnName);
			ibody.addProperty("fileName", "List of Members whose transactions exceed 10 per month (as per Appendix E).");
			ibody.addProperty("noOfColumns", clms.size());
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody);
			argObj = pdfReport.generatePDFReport(argObj);

			filt.addProperty("ScanId", scanId);
			filt.addProperty("ReportType", "Transactions_exceeding_10");
			updateObj.addProperty("ReportType", "Transactions_exceeding_10");
			updateObj.addProperty("peroidCode", pCode);
			updateObj.addProperty("financialYear", fYear);
			updateObj.addProperty("schedularId", I$Imputils.generateRandomString(20));
			updateObj.addProperty("Created At", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			updateObj.add("reportResults", resArray);
			
			updateObj.addProperty("report", argObj.getAsJsonObject("i-body").get("report").getAsString());
			db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	
	public synchronized void getACHTrnReport(JsonObject scanDetails) {
		String scanId = scanDetails.get("scanId").getAsString();
		JsonObject argObj = new JsonObject();
		JsonObject i$bdy = new JsonObject();
		try {
			final IPDFTextExtractor pdfReport = new IPDFTextExtractor();
			JsonObject filter = new JsonObject();
			JsonObject filt = new JsonObject();
//			JsonObject filtr = new JsonObject();
			JsonObject projection = new JsonObject();
			JsonObject resObj = new JsonObject();
			JsonArray resArray1 = new JsonArray();
			JsonArray resArray2 = new JsonArray();
			JsonArray resArray3 = new JsonArray();
			JsonArray resArray4= new JsonArray();
			JsonObject updateObj = new JsonObject();
//			JsonArray reshead = new JsonArray();//SKG00039 changes
//			JsonArray funcDetails = new JsonArray();
//			JsonObject funObject = new JsonObject();
			JsonObject res = new JsonObject();
			JsonArray funcArr = new JsonArray();
			JsonObject functionobject = new JsonObject();
			String funName = "";

			funcArr.add("GET_ACH_COUNT");
			funcArr.add("FN_GET_MEM_PRD_LIST");
			funcArr.add("GET_CIF_EXCEED_10");
			funcArr.add("GET_NEW_AC");
			filter.addProperty("Type", "CBS_BRANCH");
			projection.addProperty("_id", 0);
			projection.addProperty("BranchDate", 1);
            projection.addProperty("headers", 1);//// SKG00038 changes

			resObj = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter, projection);

			for (int i = 0; i < funcArr.size(); i++) {
				try {
					JsonArray funcDetails = new JsonArray();
					JsonObject funObject = new JsonObject();//SKG00039 starts
					JsonArray headers = new JsonArray();
					JsonObject ibody = new JsonObject();
					try {
						funName = funcArr.get(i).getAsString();
						funObject.addProperty("funcName", funName);
						funObject.addProperty("p_dt", resObj.get("BranchDate").getAsString());
						funcDetails.add(funObject);
						i$bdy.add("funcDetails", funcDetails);
						argObj.add("i-body", i$bdy);
						res = exeCallOrcl(argObj);
						ibody = res.get("i-body").getAsJsonObject();
						JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
						functionobject = funcRes.get(0).getAsJsonObject().get(funcArr.get(i).getAsString())
								.getAsJsonObject();
					}catch(Exception e) {
						e.printStackTrace();
					}//SKG00039 end
					if (I$utils.$iStrFuzzyMatch(funName, "FN_GET_MEM_PRD_LIST")) {
						try {//SKG00039 starts 
							String op_output = null;
							String[] op = new String[]{};
							try {
								op_output = functionobject.get("l_data").getAsString();
								op = op_output.split("\n");
								projection.addProperty("CustomerBranch", 1);
								projection.addProperty("BranchName", 1);
								projection.addProperty("CustomerId", 1);
								projection.addProperty("CustomerFullName", 1);
							}catch(Exception e) {
								
							}//SKG00039 end
							for (int j = 0; j < op.length; j++) {
								try {
									JsonObject dbData = new JsonObject();
									String arr1 = op[j];
									String[] data = arr1.split("~");
									String slno = data[0];
									String cifId = data[1];
									String memberName = data[2];
									String products_availed = data[3];
									String products_Desc = data[4];
									String branchCode = data[5];
									String breanchDesc = data[6];
//									filtr.addProperty("CustomerId", cifId);
//									JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filtr, projection);
									dbData.addProperty("Branch Code", branchCode);
									dbData.addProperty("Branch Name", breanchDesc);
									dbData.addProperty("Member Id", cifId);
									dbData.addProperty("Member Name", memberName);
									dbData.addProperty("Products Availed", products_availed);
									dbData.addProperty("Product description", products_Desc);
									if (I$utils.$iStrFuzzyMatch(products_availed, "AC02")
											|| I$utils.$iStrFuzzyMatch(products_availed, "LD02")
											|| I$utils.$iStrFuzzyMatch(products_availed, "MOBILE BANKING")) {
										dbData.addProperty("riskType", "High Risk");
									} else if (I$utils.$iStrFuzzyMatch(products_availed, "SHARES DEPOSIT")
											|| I$utils.$iStrFuzzyMatch(products_availed, "SHARES")
											|| I$utils.$iStrFuzzyMatch(products_availed, "CHARACTER LOAN")) {
										dbData.addProperty("riskType", "Medium Risk");
									} else if (I$utils.$iStrFuzzyMatch(products_availed, "SHARES DEPOSIT")) {
										dbData.addProperty("riskType", "Low Risk");
									} else {
										dbData.addProperty("riskType", "Low Risk");
									}
									resArray1.add(dbData);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}

//							String columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName', 'Products/Services availed','Risk Type']";
//							String columnNames = "['Sl.No','Branch','Branch Name','Member ID','Member Name', 'Products/Services availed', 'Risk Type ']";
//							JsonArray clms = parser.parse(columns).getAsJsonArray();
//							JsonArray columnName = parser.parse(columnNames).getAsJsonArray();

//							ibody.add("columns", clms);
							ibody.add("rowData", resArray1);
//							ibody.add("columnNames", columnName);
//							ibody.addProperty("noOfColumns", clms.size());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody);
//					argObj = pdfReport.generatePDFReport(argObj);
							//SKG00039 starts
							JsonObject head = new JsonObject();
							head.addProperty("Mebmer Id", 1);
							head.addProperty("Member Name", 2);
							head.addProperty("Products Availed", 3);
							head.addProperty("Product description", 4);
							head.addProperty("Branch Code", 5);
							head.addProperty("Branch Name", 6);
							head.addProperty("RiskType", 7);
							
							headers.add(head);
							
							//SKG00039 end
							filt.addProperty("ScanId", scanId);
							filt.addProperty("ReportType", "List of Members availing Products/Services");
							updateObj.addProperty("fileName",
									"Products/Services_report_" + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()) + ".pdf");
							updateObj.addProperty("ReportType", "List of Members availing Products/Services");
							updateObj.addProperty("CreatedAt", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
							updateObj.add("reportResults", resArray1);
							updateObj.add("headers", headers);//SKG00039 changes
							updateObj.addProperty("Status", "WIP");//#PAV00018 Changes
							updateObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
							updateObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
//					updateObj.addProperty("report", argObj.getAsJsonObject("i-body").get("report").getAsString());
							db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
						}catch(Exception e) {
							resArray1 = new JsonArray();
						}
					} else if (I$utils.$iStrFuzzyMatch(funName, "GET_NEW_AC")) {  //#SRM00056 start

						try {//MSA00034 starts
//							JsonObject fltr = new JsonObject();
//							JsonObject proj = new JsonObject();
//							JsonObject res$Obj = new JsonObject();
//							fltr.addProperty("Type", "CBS_BRANCH");
//							fltr.addProperty("KeyId", "100");
//							proj.addProperty("_id", 0);
//							proj.addProperty("BranchDate", 1);
//							res$Obj = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", fltr, proj);
//							
//							funObject.addProperty("funcName", funName);
//							funObject.add("p_dt", res$Obj.get("BranchDate"));
//							funcDetails.add(funObject);
//							i$bdy.add("funcDetails", funcDetails);
//							argObj.add("i-body", i$bdy);
//							res = exeCallOrcl(argObj);
//							JsonObject i$body = res.get("i-body").getAsJsonObject();
//							JsonArray func$Res = i$body.get("funcRes").getAsJsonArray();
//							functionobject = func$Res.get(0).getAsJsonObject().get(funcArr.get(i).getAsString())
//									.getAsJsonObject();//MSA00034 ends
							//SKG00039 starts 
							String op_output = null;
							String[] op = new String[]{};
							try {
								op_output = functionobject.get("l_data").getAsString();
								op = op_output.split("\n");
							} catch (Exception e) {

							}//SKG00039 end							
							resArray2 = new JsonArray();

							for (int k = 0; k < op.length; k++) {
								try {
									JsonObject dbData = new JsonObject();
									String arr1 = op[k];
									String[] data = arr1.split("~");
//									String slno = data[0];
									String branchCode = data[1];
									String branchName = data[2];
									String cifId = data[3];
									String memberName = data[4];
//									String accountNo = data[5];
									String date = data[5];
//									filtr.addProperty("CustomerId", cifId);
//									JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filtr, projection);
									dbData.addProperty("Branch Code", branchCode);
									dbData.addProperty("Branch Name", branchName);
									dbData.addProperty("Member ID", cifId);
									dbData.addProperty("Member Name", memberName);
//									dbData.addProperty("AccountNo", accountNo);
									dbData.addProperty("Date of Member Onboarding", date);
									resArray2.add(dbData);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							//SKG00039 starts
							
							JsonObject head = new JsonObject();
							head.addProperty("Branch Code", 1);
							head.addProperty("Branch Name", 2);
							head.addProperty("Mebmer Id", 3);
							head.addProperty("Member Name", 4);
							head.addProperty("Date of Member Onboarding", 5);
							headers.add(head);
							//SKG00039 end
							ibody.add("rowData", resArray2);
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody);

							filt.addProperty("ScanId", scanId);
							filt.addProperty("ReportType",
									"List of New Accounts Opened in the last 6 months");
							updateObj.addProperty("fileName",
									"new_accounts_last_6_months" + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()) + ".pdf");
							updateObj.addProperty("ReportType",
									"List of New Accounts Opened in the last 6 months");
							updateObj.addProperty("CreatedAt", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
							updateObj.add("reportResults", resArray2);
							updateObj.add("headers", headers);
							updateObj.addProperty("Status", "WIP");
							updateObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
							updateObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
							db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
						
						}catch(Exception e) {
							resArray2 = new JsonArray();
						}  //#SRM00056 end
					} else if (I$utils.$iStrFuzzyMatch(funName, "GET_ACH_COUNT")) {
						try {
							//SKG00039 starts 
							String op_output = null;
							String[] op = new String[]{};
							try {
								op_output = functionobject.get("l_data").getAsString();
								op = op_output.split("\n");
								projection.addProperty("CustomerBranch", 1);
								projection.addProperty("BranchName", 1);
								projection.addProperty("CustomerId", 1);
								projection.addProperty("CustomerFullName", 1);

							} catch (Exception e) {
								e.printStackTrace();
							}
							//SKG00039 end
							for (int k = 0; k < op.length; k++) {
								try {
									JsonObject dbData = new JsonObject();
									String arr1 = op[k];
									String[] data = arr1.split("~");
									String cifId = data[3];
									String branchcode = data[1];
									String branchName = data[2];
									String memberName = data[4];
									String no_of_trn = data[5];
//									filtr.addProperty("CustomerId", cifId);
//									JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filtr, projection);
									dbData.addProperty("Branch Code", branchcode);
									dbData.addProperty("Branch Name", branchName);
									dbData.addProperty("Member Id", cifId);
									dbData.addProperty("Member Name", memberName);
									dbData.addProperty("Total Transaction", no_of_trn);
									resArray3.add(dbData);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							//SKG00039 starts
							JsonObject head = new JsonObject();
							head.addProperty("Branch Code", 1);
							head.addProperty("Branch Name", 2);
							head.addProperty("Mebmer Id", 3);
							head.addProperty("Member Name", 4);
							head.addProperty("Total Transaction", 5);
							headers.add(head);
							//SKG00039 end
//							String columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName', 'TotalTrn']";
//							String columnNames = "['Sl.No','Branch','Branch Name','Member ID','Member Name', 'No. of Transactions per month']";
//							JsonArray clms = parser.parse(columns).getAsJsonArray();
//							JsonArray columnName = parser.parse(columnNames).getAsJsonArray();

							ibody.add("rowData", resArray3);
//							ibody.add("columnNames", columnName);
//							ibody.addProperty("noOfColumns", clms.size());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody);
//							argObj = pdfReport.generatePDFReport(argObj);

							filt.addProperty("ScanId", scanId);
							filt.addProperty("ReportType",
									"List of Members who receive or remit more than 2 ACH transactions per month");
							updateObj.addProperty("fileName",
									"2_ACH_trn_report_" + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()) + ".pdf");
							updateObj.addProperty("ReportType",
									"List of Members who receive or remit more than 2 ACH transactions per month");
							updateObj.addProperty("CreatedAt", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
							updateObj.add("reportResults", resArray3);
							updateObj.add("headers", headers);
							updateObj.addProperty("Status", "WIP");
							updateObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
							updateObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
							db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
						
						}catch(Exception e) {
							resArray3 = new JsonArray();
						}
						
					} else if (I$utils.$iStrFuzzyMatch(funName, "GET_CIF_EXCEED_10")) {
						try {  //SKG00039 starts
							String op_output =null;
							String[] op = new String[]{};
							try {
							   op_output = functionobject.get("l_data").getAsString();
								 op = op_output.split("\n");
								projection.addProperty("CustomerBranch", 1);
								projection.addProperty("BranchName", 1);
								projection.addProperty("CustomerId", 1);
								projection.addProperty("CustomerFullName", 1);
							}catch(Exception e) {
							}//SKG00039 end
							for (int l = 0; l < op.length; l++) {
								try {
									JsonObject dbData = new JsonObject();
									String arr1 = op[l];
									String[] data = arr1.split("~");
									String SlNo = data[0];
									String cifId = data[3];
									String branchcode = data[1];
									String branchName = data[2];
									String memberName = data[4];
									String no_of_trn = data[5];
//									filtr.addProperty("CustomerId", cifId);
//									JsonObject usrData = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", filtr, projection);
									dbData.addProperty("Branch Code", branchcode);
									dbData.addProperty("Branch Name", branchName);
									dbData.addProperty("Mebmer Id", cifId);
									dbData.addProperty("Member Name",memberName);
									dbData.addProperty("Total Transaction", no_of_trn);
									resArray4.add(dbData);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							
							//SKG00039 starts
							JsonObject head = new JsonObject();
							head.addProperty("Branch Code", 1);
							head.addProperty("Branch Name", 2);
							head.addProperty("Mebmer Id", 3);
							head.addProperty("Member Name", 4);
							head.addProperty("Total Transaction", 5);
							headers.add(head);
							//SKG00039 end
//							String columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName', 'TotalTrn']";
//							String columnNames = "['Sl.No','Branch','Branch Name','Member ID','Member Name', 'No. of Transactions per month']";
//							JsonArray clms = parser.parse(columns).getAsJsonArray();
//							JsonArray columnName = parser.parse(columnNames).getAsJsonArray();

//							ibody.add("columns", clms);
							ibody.add("rowData", resArray4);
//							ibody.add("columnNames", columnName);
//							ibody.addProperty("noOfColumns", clms.size());
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody);
//							argObj = pdfReport.generatePDFReport(argObj);

							filt.addProperty("ScanId", scanId);
							filt.addProperty("ReportType",
									"List of Members whose transactions exceed 10 per month (as per Appendix E)");
							updateObj.addProperty("fileName",
									"More_than_10_trn_report_" + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
											.format(Calendar.getInstance().getTime()) + ".pdf");
							updateObj.addProperty("ReportType",
									"List of Members whose transactions exceed 10 per month (as per Appendix E)");
							updateObj.addProperty("CreatedAt", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
									.format(Calendar.getInstance().getTime()));
							updateObj.add("reportResults", resArray4);
							updateObj.add("headers", headers);
							updateObj.addProperty("Status", "WIP");
							updateObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
							updateObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
							db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
						
						}catch(Exception e) {
							resArray4 = new JsonArray();
						}
					}
//					updateObj.addProperty("schedulerId", I$Imputils.generateRandomString(20));
//					updateObj.addProperty("CreatedAt", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
//							.format(Calendar.getInstance().getTime()));
//					updateObj.add("reportResults", resArray);
//					updateObj.add("headers", headers);//SKG00039 changes
//					updateObj.addProperty("Status", "WIP");//#PAV00018 Changes
//					updateObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
//					updateObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
////			updateObj.addProperty("report", argObj.getAsJsonObject("i-body").get("report").getAsString());
//					db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // #SRM00049 changes end
	
	public synchronized void getLocReport(JsonObject scanDetails) { 	 // #SRM00047 changes start
		String scanId = scanDetails.get("scanId").getAsString();	
		try {
			final IPDFTextExtractor pdfReport = new IPDFTextExtractor();
			JsonParser parser = new JsonParser();
			JsonObject filter = new JsonObject();
			JsonObject fltr4 = new JsonObject();
			JsonObject fltr1 = new JsonObject();
			JsonObject fltr2 = new JsonObject();
			JsonObject fltr3 = new JsonObject();
			JsonObject filter1 = new JsonObject();
			JsonObject filter2 = new JsonObject();
			JsonArray dbData = new JsonArray();
			JsonArray dbData2 = new JsonArray();
			JsonObject projection = new JsonObject();
			JsonObject projection2 = new JsonObject();
			JsonObject sort = new JsonObject();
			JsonObject ibody = new JsonObject();
			JsonObject ibody1 = new JsonObject();
			JsonObject argObj = new JsonObject();
			JsonArray headers = new JsonArray();//SKG00039 changes

			JsonObject filt = new JsonObject();	
			JsonObject filt2 = new JsonObject();
			JsonObject updateObj = new JsonObject();
			JsonObject updateObj2 = new JsonObject();
			JsonArray valuesList = new JsonArray();
	
//			String location = "['Albania', 'The Bahamas','Barbados','Botswana','Cambodia','Ghana','Iraq','Iceland','Jamaica','Mauritius','Mongolia','Myanmar','Nicaragua','Pakistan','Panama','Syria','Uganda','Vanuatu','Venezuela','Yemen','Zimbabwe','Democratic People’s Republic of Korea (DPRK)','Iran']";
//			JsonArray business = parser.parse(location).getAsJsonArray();
			filter1.addProperty("dataFormulaId", "Geographic_Origin");
			JsonObject icorMDataFormula = db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA", filter1);
			JsonArray formulaRatingArray = icorMDataFormula.getAsJsonArray("formulaRating");
			for (int i = 0; i < formulaRatingArray.size(); i++) {
				JsonObject ratingObject = formulaRatingArray.get(i).getAsJsonObject();
                String value = ratingObject.get("value").getAsString();
                valuesList.add(value);
            }
			JsonArray business =valuesList;

			sort.addProperty("_id", -1);
			projection.addProperty("_id", 0);
			projection.addProperty("CustomerId", 1);
			projection.addProperty("CustomerFullName", 1);
			projection.addProperty("BranchName", 1);
			projection.addProperty("CustomerBranch", 1);
			projection.addProperty("GeoLocationdesc", 1);
			projection.addProperty("CifCreationDate", 1);	
			filter.add("GeoLocationdesc", parser.parse("{'$in': " + business.getAsJsonArray() + " }" ).getAsJsonObject());
			dbData = db$Ctrl.db$GetRows$Sort("ICOR_M_CBS_CIF_DATA", filter, projection, sort);
			//SKG00039 starts 
			JsonObject head = new JsonObject();
			head.addProperty("CustomerId", 1);
			head.addProperty("CustomerFullName", 2);
			head.addProperty("BranchName", 3);
			head.addProperty("CustomerBranch", 4);
			head.addProperty("GeoLocationdesc", 6);
			head.addProperty("CifCreationDate", 5);
			headers.add(head);
			ibody.add("rowData", dbData);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody);
			
			filt.addProperty("ScanId", scanId);
			filt.addProperty("ReportType", "List of Members living or conducting business in a high risk location within the country");
			updateObj.addProperty("ReportType", "List of Members living or conducting business in a high risk location within the country");
			updateObj.addProperty("fileName", "High_risk_loc_report_" +new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime())+ ".pdf");
			updateObj.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			updateObj.add("reportResults", dbData);
			updateObj.add("headers", headers);//SKG00039 chnages

			updateObj.addProperty("Status", "WIP");//#PAV00018 Changes
			updateObj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
			updateObj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
			db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, filt, "true");
			
			
			JsonArray valuesList2 = new JsonArray();
			JsonArray filterArr = new JsonArray();
			filter2.addProperty("dataFormulaId", "Geographic_Location");
			JsonObject icorMDataFormula2 = db$Ctrl.db$GetRow("ICOR_M_DATA_FORMULA", filter2);
			JsonArray formulaRatingArray2 = icorMDataFormula2.getAsJsonArray("formulaRating");
			for (int i = 0; i < formulaRatingArray2.size(); i++) {
				JsonObject ratingObject2 = formulaRatingArray2.get(i).getAsJsonObject();
                String value2 = ratingObject2.get("value").getAsString();
                valuesList2.add(value2);
            }
			JsonArray business2 =valuesList2;
			JsonArray headers1 = new JsonArray();
			JsonObject arrayFilter = new JsonObject();
			JsonObject addressObj = new JsonObject();
			sort.addProperty("_id", -1);
			projection2.addProperty("_id", 0);
			projection2.addProperty("CustomerId", 1);
			projection2.addProperty("CustomerFullName", 1);
			projection2.addProperty("BranchName", 1);
			projection2.addProperty("CustomerBranch", 1);
			projection2.addProperty("GeoLocationdesc", 1);
			projection2.addProperty("CifCreationDate", 1);	
//			fltr.add("GeoLocationdesc", parser.parse("{'$in': " + business2.getAsJsonArray() + " }" ).getAsJsonObject());
			addressObj.add("$in", business2);
			fltr1.add("AddressForCorrespondence1", addressObj);
			fltr2.add("AddressForCorrespondence2", addressObj);
			fltr3.add("AddressForCorrespondence3", addressObj);
			fltr4.add("AddressForCorrespondence4", addressObj);
//			fltr.add("PAddress1", parser.parse("{'$in': " + business2.getAsJsonArray() + " }" ).getAsJsonObject());
//			fltr.add("PAddress2", parser.parse("{'$in': " + business2.getAsJsonArray() + " }" ).getAsJsonObject());
//			fltr.add("PAddress3", parser.parse("{'$in': " + business2.getAsJsonArray() + " }" ).getAsJsonObject());
//			fltr.add("PAddress4", parser.parse("{'$in': " + business2.getAsJsonArray() + " }" ).getAsJsonObject());
			filterArr.add(fltr1);
			filterArr.add(fltr2);
			filterArr.add(fltr3);
			filterArr.add(fltr4);
			arrayFilter.add("$or", filterArr);
			dbData2 = db$Ctrl.db$GetRows$Sort("ICOR_M_CBS_CIF_DATA", arrayFilter, projection2, sort);
			
			JsonObject head1 = new JsonObject();
			head1.addProperty("CustomerId", 1);
			head1.addProperty("CustomerFullName", 2);
			head1.addProperty("BranchName", 3);
			head1.addProperty("CustomerBranch", 4);
			head1.addProperty("GeoLocationdesc", 5);
			headers1.add(head1);
			ibody1.add("rowData", dbData2);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, argObj, i$ResM.I_BDYTAG, ibody1);
			
			filt2.addProperty("ScanId", scanId);
			filt2.addProperty("ReportType", "List of Members holding citizenship/residency in high risk or non co-operative jurisdiction");
			updateObj2.addProperty("ReportType", "List of Members holding citizenship/residency in high risk or non co-operative jurisdiction");
			updateObj2.addProperty("fileName", "High_risk_residence_report_" +new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime())+ ".pdf");
			updateObj2.addProperty("CreatedAt", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
					.format(Calendar.getInstance().getTime()));
			updateObj2.add("reportResults", dbData2);
			updateObj2.add("headers", headers1);
			
			updateObj2.addProperty("Status", "WIP");
			updateObj2.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));
			updateObj2.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));
			
			db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj2, filt2, "true");
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	} // #SRM00047 changes end
	// MSA starts
	public JsonObject sendEmail(JsonObject iBody) {
		try {
			String accNum = iBody.get("accountNumber").getAsString();
			JsonObject fltr = new JsonObject();
			JsonObject argJson1 = new JsonObject();
			JsonObject map$Data = new JsonObject();
			String xmlData = iBody.get("account_data").getAsString();
			String cif = accNum.substring(3, 9);
			fltr.addProperty("CustomerId", cif);
			JsonObject data = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", fltr);
			String sKeyE = data.get("CustomerEmailId").getAsString();
			String custName = data.get("CustomerFullName").getAsString();
			//MSA00070 starts
			String pattern = "<MSGSTAT>(.*?)</MSGSTAT>";
			Pattern r = Pattern.compile(pattern);// Created a Pattern object
			Matcher m = r.matcher(xmlData);// Created a Matcher object
			String stat = null;
			if (m.find()) {
				stat = m.group(1);
			} else {
				stat = "";
			}
			if (stat.contentEquals("FAILURE")) {
				map$Data.addProperty("tmp$name", "TMPL#LOAN#REPAYMENT#NOTIFICATION#FAILED");
				map$Data.addProperty("memName", custName);
			}else {
				map$Data.addProperty("tmp$name", "TMPL#LOAN#REPAYMENT#NOTIFICATION");
				map$Data.addProperty("fromAcc", iBody.get("settlementAccNumbero").getAsString());
				map$Data.addProperty("Branch", iBody.get("branchCode").getAsString());
				map$Data.addProperty("toAcc", iBody.get("accountNumber").getAsString());
				map$Data.addProperty("amount", iBody.get("amountToPay").getAsString());
				map$Data.addProperty("memName", custName);
			}
			// SRI00046  changes Starts 
			try {
				JsonObject object = new JsonObject();
				JsonObject trnData = new JsonObject();
				object.addProperty("unqCommID", i$impactoUtil.generateRandomKey());
				object.addProperty("tranId", iBody.get("tranId").getAsString());
				object.addProperty("extSys", "FLEXCUBE");
				object.addProperty("trnCd", "LoanRepayment");
				object.addProperty("ctrnCd", "FCUBSRTService");
				object.addProperty("ctrnOpr", "CreateTransaction");
				object.addProperty("ctrnOpr1", "@");
				object.addProperty("ctrnOpr2", "@");
				object.addProperty("ctrnOpr3", "@");
				object.addProperty("initatedBy", cif);
				object.add("impactoInDtTime", i$ResM.addDateTime(new Date()));
				trnData.addProperty("funcName", iBody.get("funcName").getAsString());
				trnData.addProperty("branchCode", iBody.get("branchCode").getAsString());
				trnData.addProperty("accountNumber", iBody.get("accountNumber").getAsString());
				trnData.addProperty("amountToPay", iBody.get("amountToPay").getAsString());
				trnData.addProperty("settlementBranch", iBody.get("settlementBranch").getAsString());
				trnData.addProperty("settlementAccNumbero", iBody.get("settlementAccNumbero").getAsString());
				object.add("trnData", trnData);
				object.addProperty("account_data", iBody.get("account_data").getAsString());
				db$Ctrl.db$InsertRow("ICOR_C_TRNFWD_MONITOR", object);
			}catch(Exception e) {
				e.printStackTrace();
			}
			// SRI00046  changes end
			argJson1.add("map$Data", map$Data);
			argJson1.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + sKeyE + "\"}"));
			JsonObject i$resE = i$Email.SendEmailWOThread(argJson1);//MSA00070 ends
		} catch (Exception e) {
			e.printStackTrace();
		}

		return iBody;
	}

	// MSA ends
	public JsonObject generateMiniStatement(JsonObject funcData, JsonObject argJson) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
			try {
				PdfWriter.getInstance(document, byteArrayOutputStream);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
			JsonObject isonMsgCopy = argJson.deepCopy();
			JsonObject i$Body = new JsonObject();
//			String referenceNo = argJson.get("i-body").getAsJsonObject().get("letterObj").getAsJsonObject()
//					.get("referenceNo").getAsString();
			String referenceNo = argJson.get("i-body").getAsJsonObject().get("referenceNo").getAsString();
//			String type = argJson.get("i-body").getAsJsonObject().get("letterObj").getAsJsonObject().get("type")
//					.getAsString();
			String type = argJson.get("i-body").getAsJsonObject().get("type").getAsString();
			JsonObject i$Header = isonMsgCopy.getAsJsonObject("i-header");

			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation1", "FILEUPLD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "screenid", "FDMFLUPD");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation", "CREATE");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileName", referenceNo + ".pdf");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileExtn", ".pdf");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileSize", 2307138);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocType", "LETTER MINI STATEMENT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "I#FileData", base64Str);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Compressed", "N");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "OriginalFileName", "N");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "tranId", "y9m6jis5r3cGZTEqxGzS");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID1", "MINI STATEMENT");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "LinkedCustNo", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocNo", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubVersion", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueDt", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocExpiryDt", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueAuthority", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldIP", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldSrc", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key5", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key6", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key7", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key8", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key9", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key10", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "TmpStorageRec", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldDateTime", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocPlaceIssue", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld1", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld2", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld3", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld4", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld5", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld6", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld7", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld8", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld9", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld10", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocVersion", "");
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_HEADER, i$Header);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_BDYTAG, i$Body);
			i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsgCopy, i$ResM.I_STATTAG);

			JsonObject isonReqhead = new JsonObject();
			JsonObject isonMapJson = new JsonObject();
			String url = "";
			String ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController";
			Class<?> ctrlClass;
			ctrlClass = Class.forName(ScrCtrlClass);
			JsonObject result$ = null;
			Method ctrlFunc = null;
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
			Object ctrl$Caller = ctrlClass.newInstance();
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsgCopy, isonReqhead, isonMapJson); // #BVB00068
			if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-SUCC")) {
				JsonObject projection = new JsonObject();// #MVT00096 code changes
				String FileUrlToken = result$.get("i-body").getAsJsonObject().get("FileUrlToken").getAsString();
				String Query = "FileUrlToken=" + FileUrlToken;
				// url = "http://localhost:63002/ImpactoPuppy_Core/miniStatement.pdf?"+Query;
				// //local
				// url =
				// "https://impactosuitedeveloper.com/ImpactoWebPuppy/miniStatement.pdf?"+Query;
				// //remote
				// url = "https://impactosuite.com/QAImpactoPuppy/miniStatement.pdf"+Query;//QA
				// Encoding charset to be used
				projection.addProperty("_id", 0);
				projection.addProperty("pdfStatementURL", 1);
				url = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", projection).getAsJsonObject().get("pdfStatementURL")
						.getAsString() + Query;
				url = url.replace("##type##", "Letter_Request_" + type);
				String charset = "UTF-8"; // #MVT00096 code changes
				Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
				hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
				argJson = generateQRcode(url, funcData, argJson, FileUrlToken, byteArrayOutputStream, document, charset,
						hashMap, 100, 100);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return argJson;
	}

	public JsonObject generateQRcode(String data, JsonObject funcData, JsonObject isonMsgCopy, String FileUrlToken,
			ByteArrayOutputStream byteArrayOutputStream, Document document1, String charset, Map map, int h, int w)
			throws WriterException, IOException, DocumentException {
		Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
		hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
		BitMatrix matrix = new MultiFormatWriter().encode(new String(data.getBytes(charset), charset),
				BarcodeFormat.QR_CODE, w, h);
//		BufferedImage bufferedImage = MatrixToImageWriter.toBufferedImage(matrix);
		String mapData = funcData.get("fn_getCIFShareDetails").getAsJsonObject().get("l_data").getAsString();
		String[] strData = mapData.split("###");
		Image iTextImage = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Document document = new Document();//#MSA00011 changes
		JsonObject signName = new JsonObject();
//		ImageIO.write(bufferedImage, "png", baos);
		//MSA00040 starts
		int max = 6;
		int min = 1;
		int randomNum = (int)(Math.random()* (max - min + 1) + min);//PAV00032 Changes
		String randomSign = "SIGN00"+randomNum;
		JsonObject filter1 = new JsonObject();
		filter1.addProperty("signId", randomSign);
		JsonObject signDetl = db$Ctrl.db$GetRow("ICOR_M_TECU_SIGNATURES_COLL", filter1);
//		signName.addProperty("signName", signDetl.get("name").getAsString());
		i$ResM.setGobalVals("signTemplate", signDetl.get("template").getAsString());//MSA00040 ends
		JsonObject flxdata = new JsonObject();
		String lData = null;
		String avgL_data = null;
		String l_data = null;
		try {
			iTextImage = Image.getInstance(baos.toByteArray());
		} catch (BadElementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//MSA00022 starts
//		String cif = isonMsgCopy.get("i-body").getAsJsonObject().get("letterObj").getAsJsonObject().get("customerId").getAsString();
		JsonObject iBodyObj = isonMsgCopy.getAsJsonObject("i-body");
		iBodyObj.addProperty("signName", signDetl.get("name").getAsString());
		String cif = isonMsgCopy.get("i-body").getAsJsonObject().get("customerId").getAsString();
		JsonArray flxArr = new JsonArray();
		try {
			JsonObject ison$Body = new JsonObject();
			ison$Body = isonMsgCopy.deepCopy();
			JsonObject i$body = ison$Body.get("i-body").getAsJsonObject();
			JsonArray funcDtl = new JsonArray();
			JsonObject funcDtlObj = new JsonObject();
			JsonObject funcDtlObj_1 = new JsonObject();
			JsonObject funcDtlObj_2 = new JsonObject();
			funcDtlObj.addProperty("p_member",cif);
			funcDtlObj.addProperty("funcName","GET_CIF_BRANCH_DATE");
			funcDtlObj_1.addProperty("p_member_no",cif);
			funcDtlObj_1.addProperty("funcName","FN_GET_MEM_BAL_AVG");
			funcDtlObj_2.addProperty("p_member",cif);
			funcDtlObj_2.addProperty("funcName","GET_CIF_EMI_DETAILS");
			funcDtl.add(funcDtlObj);
			funcDtl.add(funcDtlObj_1);
			funcDtl.add(funcDtlObj_2);
			i$body.add("funcDetails", funcDtl);
        	flxdata = exeCallOrcl(ison$Body); 
        	flxArr = flxdata.getAsJsonObject("i-body").getAsJsonArray("funcRes");
        	for (int j = 0; j < flxArr.size(); j++) {
//					lData = flxArr.get(j).getAsJsonObject().getAsJsonObject("GET_CIF_BRANCH_DATE").get("l_data").getAsString();
					JsonObject runningObj = flxArr.get(j).getAsJsonObject();
					Set<String> keys = runningObj.keySet();
					for (String key : keys) {
						try {
							if (I$utils.$iStrFuzzyMatch(key, "GET_CIF_BRANCH_DATE")) {
								lData = runningObj.getAsJsonObject("GET_CIF_BRANCH_DATE").get("l_data").getAsString();
							} else if (I$utils.$iStrFuzzyMatch(key, "FN_GET_MEM_BAL_AVG")) {
								avgL_data = runningObj.getAsJsonObject("FN_GET_MEM_BAL_AVG").get("l_data").getAsString();
							} else if (I$utils.$iStrFuzzyMatch(key, "GET_CIF_EMI_DETAILS")) {
								l_data = runningObj.getAsJsonObject("GET_CIF_EMI_DETAILS").get("l_data").getAsString();
							}
						}catch(Exception e) {}
					}
        	}
        }catch(Exception e) {
        	e.printStackTrace();
        }
		//MSA00022 ends
		i$ResM.setGobalVals("uniqueId", isonMsgCopy.get("i-body").getAsJsonObject().get("uniqueId").getAsString());
		document.setMargins(20, 10, 120, 100);
//		avgL_data = flxArr.get(1).getAsJsonObject().getAsJsonObject("FN_GET_MEM_BAL_AVG").get("l_data").getAsString();
//		l_data = flxArr.get(2).getAsJsonObject().getAsJsonObject("GET_CIF_EMI_DETAILS").get("l_data").getAsString();
		PdfWriter writer1 = PdfWriter.getInstance(document, byteArrayOutputStream);
		String date = i$ResM.getOnlydate(new Date());
		Date dateStr = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
	    String strDate = formatter.format(dateStr);
	    Font font = new Font(FontFamily.HELVETICA, 7, Font.BOLD, BaseColor.BLACK);
	    Font font_1 = new Font(FontFamily.HELVETICA, 8, Font.BOLD, BaseColor.BLACK);
		JsonObject i$body = isonMsgCopy.get("i-body").getAsJsonObject();
		String[] avgData = avgL_data.split("\n");
		String[] emiData = l_data.split("\n");
		JsonObject embDetl = new JsonObject();
		StringBuilder strAddrfullname = new StringBuilder();
		//MSA00011 starts
//		HeaderFooterPageEvent2 event = new HeaderFooterPageEvent2();
//		writer1.setPageEvent(event);
//		event.onStartPage(writer1, document);
//		HeaderFooterPageEvent2i event2 = new HeaderFooterPageEvent2i();
//		writer1.setPageEvent(event2);
//		event2.onEndPage(writer1, document);
		HeaderFooterPageEvent6 event = new HeaderFooterPageEvent6();
		writer1.setPageEvent(event);
		event.onStartPage(writer1, document);
		event.onEndPage(writer1, document);
		
		String srvcname = isonMsgCopy.get("i-header").getAsJsonObject().get("srvcname").getAsString();
		String srvcopr = isonMsgCopy.get("i-header").getAsJsonObject().get("srvcopr").getAsString();
		if (!I$utils.$iStrFuzzyMatch(srvcname, "REQUEST_FOR_LETTER_STMT") && !I$utils.$iStrFuzzyMatch(srvcopr, "LETTER_REQ")) {
			HeaderFooterPageEvent7 event7 = new HeaderFooterPageEvent7();
			writer1.setPageEvent(event7);
			event7.onStartPage(writer1, document);
		}
		//MSA00011 ends
		
		document.open();//MSA00045 starts
		Paragraph para = new Paragraph(" ");
		if (I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "travel")) {
			try {
				JsonObject filter = new JsonObject();
				filter.addProperty("KeyDesc", i$body.get("embassyNameDesc").getAsString());
				embDetl = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", filter);
//				String add1 = embDetl.get("ADDRESS1").getAsString();
//				String add2 = embDetl.get("ADDRESS2").getAsString();
				
//				if (!i$outis.$iStrBlank(add1) || !i$outis.$iStrBlank(add2)) {
//					try {
//						strAddrfullname.append(add1);
//						strAddrfullname.append(" ");
//					} catch (Exception e) {}
//					try {
//						strAddrfullname.append(add2);
//					} catch (Exception e) {}
//				}
				Paragraph para21 = null;
				Paragraph para22 = new Paragraph();
				Paragraph para23 = new Paragraph();
				Paragraph para24 = new Paragraph();
				Paragraph para25 = new Paragraph();
				Paragraph para26 = new Paragraph();
				Paragraph para27 = new Paragraph();
				Paragraph para28 = new Paragraph();
				Paragraph para29 = new Paragraph();
				Paragraph para29_E = new Paragraph();
				Paragraph para29_M = new Paragraph();
				Paragraph para30 = new Paragraph();
				Chunk textUnderline22 = null;
				Chunk textUnderline23 = null;
				Chunk textUnderline24 = null;
				Chunk textUnderline24i = null;
				Chunk textUnderline25 = null;
				Chunk textUnderline25i = null;
				Chunk textUnderline26 = null;
				Chunk textUnderline27 = null;
				Chunk textUnderline28 = null;
				Chunk textUnderline29 = null;
				Chunk textUnderline29_E = null;
				Chunk textUnderline29_M = null;
				Chunk textUnderline30 = null;
				try {
					para22.setFont(FontFactory.getFont("Arial", 11, Font.BOLD, BaseColor.BLACK));
					textUnderline22 = new Chunk(strDate);
					Phrase phrase22 = new Phrase();
					phrase22.add(textUnderline22);
					para22.add(phrase22);
					para22.setAlignment(Element.ALIGN_LEFT);
					document.add(para22);
				} catch (Exception e) {
				}
				document.add(para);
				
				try {
					para21 = new Paragraph("  ");
					document.add(para21);
				} catch (Exception e) {
				}
				try {
					textUnderline23 = new Chunk("The Visa Officer",FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					Phrase phrase23 = new Phrase();
					phrase23.add(textUnderline23);
					para23.add(phrase23);
					para23.setAlignment(Element.ALIGN_LEFT);
					document.add(para23);
				} catch (Exception e) {
				}

				try {
					textUnderline30 = new Chunk(i$body.get("embassyNameDesc").getAsString(),FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					Phrase phrase30 = new Phrase();
					phrase30.add(textUnderline30);
					para30.add(phrase30);
					para30.setAlignment(Element.ALIGN_LEFT);
					document.add(para30);
				} catch (Exception e) {
				}

//				try {
//					textUnderline28 = new Chunk(strAddrfullname.toString().toUpperCase(),FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK));
//					Phrase phrase28 = new Phrase();
//					phrase28.add(textUnderline28);
//					para28.add(phrase28);
//					para28.setAlignment(Element.ALIGN_LEFT);
//					document.add(para28);
//				} catch (Exception e) {
//				}
				try {
					textUnderline29_E = new Chunk(embDetl.get("ADDRESS1").getAsString(),FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					Phrase phrase29_E = new Phrase();
					phrase29_E.add(textUnderline29_E);
					para29_E.add(phrase29_E);
					para29_E.setAlignment(Element.ALIGN_LEFT);
					document.add(para29_E);
				} catch (Exception e) {
				}
				try {
					if(embDetl.get("ADDRESS3").getAsString().isEmpty()) {
					textUnderline29_M = new Chunk(embDetl.get("ADDRESS2").getAsString(),FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					}else {
						textUnderline29_M = new Chunk(embDetl.get("ADDRESS2").getAsString(),FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					}
					Phrase phrase29_M = new Phrase();
					phrase29_M.add(textUnderline29_M);
					para29_M.add(phrase29_M);
					para29_M.setAlignment(Element.ALIGN_LEFT);
					document.add(para29_M);
				} catch (Exception e) {
				}
				try {
					textUnderline29 = new Chunk(embDetl.get("ADDRESS3").getAsString(),FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					Phrase phrase29 = new Phrase();
					phrase29.add(textUnderline29);
					para29.add(phrase29);
					para29.setAlignment(Element.ALIGN_LEFT);
					document.add(para29);
				} catch (Exception e) {
				}

				try {
					textUnderline24 = new Chunk("Name: ", FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK));
					textUnderline24i = new Chunk(i$body.get("memberName").getAsString().toUpperCase(), FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					para24.add(textUnderline24);
					para24.add(textUnderline24i);
					para24.setAlignment(Element.ALIGN_LEFT);
					document.add(para);
					document.add(para24);
				} catch (Exception e) {
				}
				try {
					textUnderline25 = new Chunk("Member Number: ", FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK));
					textUnderline25i = new Chunk(i$body.get("customerId").getAsString().toUpperCase(), FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
					para25.add(textUnderline25);
					para25.add(textUnderline25i);
					para25.setAlignment(Element.ALIGN_LEFT);
					document.add(para25);
				} catch (Exception e) {
				}
				PdfPTable avgTable = new PdfPTable(3);
				avgTable.setWidthPercentage(100);
//				int[] headingTablewidths = { 50, 30, 50 };
//				avgTable.setWidths(headingTablewidths);
				
				Chunk accNo = new Chunk("Account No.",FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
				accNo.setUnderline(0.8f, -3f);
				Paragraph paraAcc = new Paragraph(accNo);
				PdfPCell cell21 = new PdfPCell(paraAcc);
				cell21.setBorder(PdfPCell.NO_BORDER);
				
				Chunk datee = new Chunk("Date",FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
				datee.setUnderline(0.8f, -3f);
				Paragraph paraDate = new Paragraph(datee);
				PdfPCell cell22 = new PdfPCell(paraDate);
				cell22.setBorder(PdfPCell.NO_BORDER);
				cell22.setPaddingLeft(13);
				
				Chunk balancee = new Chunk("Balance",FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
				balancee.setUnderline(0.8f, -3f);
				Paragraph paraBalance = new Paragraph(balancee);
				PdfPCell cell23 = new PdfPCell(paraBalance);
				cell23.setBorder(PdfPCell.NO_BORDER);
				cell23.setPaddingLeft(13); 
				
				avgTable.addCell(cell21);
				avgTable.addCell(cell22);
				avgTable.addCell(cell23);
				PdfPCell cell24 = new PdfPCell();
				PdfPCell cell25 = new PdfPCell();
				PdfPCell cell26 = new PdfPCell();
				JsonArray finalArr = new JsonArray();
				for (int i = 0; i < avgData.length; i++) {
					try {
						String str = avgData[i];
						if (I$utils.$iStrBlank(str)) {
							PdfPCell emptyCell = new PdfPCell(new Phrase(" "));
							emptyCell.setBorder(PdfPCell.NO_BORDER);
							emptyCell.setColspan(3);
							avgTable.addCell(emptyCell);
							continue;
						}

						String[] accArr = str.split("~");
						for (int j = 0; j < 1; j++) {
							try {
								String accNumber = accArr[1];
								if (!I$utils.isInArray(finalArr, accNumber)) {
									finalArr.add(accNumber);
									break;
								} else {
									str= str.replace(accNumber, " ");
									break;
								}
							} catch (Exception e) {

							}
						}
						
						
						String[] arr = str.split("~");
						try {
							try {
								if (arr.length >= 1 && !arr[1].equals("")) {
									cell24 = new PdfPCell(new Paragraph(arr[1],
											FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK)));
									cell24.setBorder(PdfPCell.NO_BORDER);
								} else {
									cell24 = new PdfPCell(new Paragraph(" "));
									cell24.setBorder(PdfPCell.NO_BORDER);
								}
//								cell24.setBorderColor(BaseColor.WHITE);
							} catch (Exception e) {

							}
							try {
								if (arr.length >= 2 && !arr[2].equals("")) {
									cell25 = new PdfPCell(new Paragraph(arr[2],
											FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK)));
									cell25.setBorder(PdfPCell.NO_BORDER);
								} else {
									cell25 = new PdfPCell(new Paragraph(" "));
									cell25.setBorder(PdfPCell.NO_BORDER);
								}
//								cell25.setBorderColor(BaseColor.WHITE);
							} catch (Exception e) {

							}
							
//								if (arr.length >= 3 && !arr[3].equals("")) {
//									String value = arr[3];
//									double balance = Double.parseDouble(value);
//									String balanceCom = null;
//									if (balance >= 1000) {
//										Double d1 = Double.valueOf(balance);
//										NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//										balanceCom = formatterBal.format(d1);
//									} else {
//										balanceCom = Double.toString(balance);
//									}
//									cell26 = new PdfPCell(new Paragraph("$ " + balanceCom,
//											FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK)));
//									cell26.setPaddingLeft(11);
//									cell26.setBorder(PdfPCell.NO_BORDER);
//								} 
							try {
								try {
									if (arr.length >=4 && !arr[3].equals("")) {
										cell26 = new PdfPCell(new Paragraph("$" + arr[3],
												FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK)));
										cell26.setPaddingLeft(11);
										cell26.setBorder(PdfPCell.NO_BORDER);
									} else {
										cell26 = new PdfPCell(new Paragraph(" "));
										cell26.setBorder(PdfPCell.NO_BORDER);
									}
//									cell26.setHorizontalAlignment(Element.ALIGN_CENTER);
								} catch (Exception e) {

								}
							} catch (Exception e) {

							}
							try {
								if (str.contains("Average 151 Share Balance")
										|| str.contains("Average 150 Share Deposit Balance")) {
									cell24 = new PdfPCell(new Paragraph(" ", font));
									cell24.setBorder(PdfPCell.NO_BORDER);
									cell25 = new PdfPCell(new Paragraph(" ", font));
									cell25.setBorder(PdfPCell.NO_BORDER);
									cell26 = new PdfPCell(new Paragraph(" ", font));
									cell26.setBorder(PdfPCell.NO_BORDER);
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							avgTable.addCell(cell24);
							avgTable.addCell(cell25);
							avgTable.addCell(cell26);
//								}

						} catch (Exception e) {

						}
					} catch (Exception e) {

					}
				}
				for (int i = 0; i < avgData.length; i++) {
					String str = avgData[i];
					if (str.contains("Average 151 Share Balance")) {
						para26.setFont(FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
						textUnderline26 = new Chunk(str);
						Phrase phrase4 = new Phrase();
						phrase4.add(textUnderline26);
						para26.add(phrase4);
						para26.setAlignment(Element.ALIGN_LEFT);
					}
					if (str.contains("Average 150 Share Deposit Balance")) {
						para27.setFont(FontFactory.getFont("Arial", 12, Font.BOLD, BaseColor.BLACK));
						textUnderline27 = new Chunk(str);
						Phrase phrase5 = new Phrase();
						phrase5.add(textUnderline27);
						para27.add(phrase5);
						para27.setAlignment(Element.ALIGN_LEFT);
					}
				}
				document.add(para21);
				document.add(avgTable);
//				document.add(para21);
				document.add(para26);
				document.add(para27);
				document.add(para21);

				Paragraph para31 = new Paragraph();
				Paragraph para32 = new Paragraph();
				Paragraph para33 = new Paragraph();
				Paragraph para34 = new Paragraph();
				Paragraph para35 = new Paragraph();
				Paragraph para36 = new Paragraph();
				Paragraph sign = new Paragraph();
				
				Chunk textUnderline31 = null;
				Chunk textUnderline32 = null;
				Chunk textUnderline33 = null;
				Chunk textUnderline34 = null;
				Chunk textUnderline35 = null;
				Chunk textUnderline36 = null;
				try {
					textUnderline31 = new Chunk("Respectfully",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					Phrase phrase31 = new Phrase();
					phrase31.add(textUnderline31);
					para31.add(phrase31);
					para31.setAlignment(Element.ALIGN_LEFT);
					float remainingSpace = document.getPageSize().getHeight() - document.topMargin() - document.bottomMargin();
                    try {
                        if (remainingSpace < 650.0) {
                        	document.add(para);
                            document.add(para);
                            document.add(para);
//                            document.add(para51);
                        }}catch(Exception e)
                        {
                            e.printStackTrace();
                        }
					document.add(para31);
				} catch (Exception e) {
				}
//				try {
//					textUnderline32 = new Chunk("TECU CREDIT UNION",FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK));
//					Phrase phrase32 = new Phrase();
//					phrase32.add(textUnderline32);
//					para32.add(phrase32);
//					para32.setAlignment(Element.ALIGN_LEFT);
//					document.add(para32);
//				} catch (Exception e) {
//				}
//				try {
//					textUnderline33 = new Chunk("CO-OPERATIVE SOCIETY LIMITED",FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK));
//					Phrase phrase33 = new Phrase();
//					phrase33.add(textUnderline33);
//					para33.add(phrase33);
//					para33.setAlignment(Element.ALIGN_LEFT);
//					document.add(para33);
////					document.add(para);
////		     		document.add(para);
////				    document.add(para); 
//				} catch (Exception e) {
//				}
				try {//#PAV00032 Changes Starts
					ByteArrayOutputStream byteImgL = new ByteArrayOutputStream();
					String base64Image = i$ResM.getGobalValStr("signTemplate");
					byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
					BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
					ImageIO.write(img, "png", byteImgL);
					byte[] byteArrL = byteImgL.toByteArray();
					Image footerImgL = Image.getInstance(byteArrL);
					footerImgL.scaleAbsolute(100, 25); 
					document.add(footerImgL); 
				} catch (Exception e) {
				}//#PAV00032 Changes Ends
//				try {
//                    textUnderline34 = new Chunk("______________________________",FontFactory.getFont("Arial", 12, Font.NORMAL, BaseColor.BLACK));
//                    Phrase phrase34 = new Phrase();
//                    phrase34.add(textUnderline34);
//                    para34.add(phrase34);
//                    para34.setAlignment(Element.ALIGN_LEFT);
//                    para34.setSpacingBefore(-12f);
//                    document.add(para34);
//                } catch (Exception e) {
//                }
				try {
					textUnderline35 = new Chunk("AUTHORIZED SIGNATURE",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					Phrase phrase35 = new Phrase();
					phrase35.add(textUnderline35);
					para35.add(phrase35);
					para35.setAlignment(Element.ALIGN_LEFT);
					document.add(para35);
				} catch (Exception e) {
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			document.newPage();
		}//MSA00045 ends
//		/*
//		try {
//			document.add(iTextImage);
//		} catch (DocumentException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Paragraph para0 = new Paragraph();;
		Paragraph para1 = new Paragraph();;
		Paragraph para2 = new Paragraph();
		Paragraph para3 = new Paragraph();;
		Paragraph para4 = new Paragraph();;
		Paragraph para5 = new Paragraph();;
		Paragraph para6 = new Paragraph();;
		Paragraph para7 = new Paragraph();;
		Paragraph para72 = new Paragraph();;
		Paragraph para7i = new Paragraph();;
		Paragraph para8 = new Paragraph();;
		Paragraph para9 = new Paragraph();;
		Paragraph para36 = new Paragraph();
		Chunk textUnderline0 = null;
		Chunk textUnderline1 = null;
		Chunk textUnderline2 = null;
		Chunk textUnderline3 = null;
		Chunk textUnderline4 = null;
		Chunk textUnderline5 = null;
		Chunk textUnderline6 = null;
		Chunk textUnderline7 = null; 
		Chunk textUnderline72 = null; 
		Chunk textUnderline7i = null;
		Chunk textUnderline8 = null;
		Chunk textUnderline9 = null;
		Chunk textUnderline36 = null;
		try {
			textUnderline0 = new Chunk(strDate,FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			Phrase phrase0 = new Phrase();
			phrase0.add(textUnderline0);
			para0.add(phrase0);
			para0.setAlignment(Element.ALIGN_LEFT);
			para0.setSpacingAfter(-8f);
			document.add(para0);
		} catch (Exception e) {
		}
		document.add(para);
		try {
			if (I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "bank")
					|| I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "Other")) {
				try {
					textUnderline1 = new Chunk("The Manager,",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					Phrase phrase1 = new Phrase();
					phrase1.add(textUnderline1);
					para1.add(phrase1);
					para1.setAlignment(Element.ALIGN_LEFT);
				} catch (Exception e) {

				}
			} else {
				textUnderline1 = new Chunk("The Visa Officer",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				Phrase phrase1 = new Phrase();
				phrase1.add(textUnderline1);
				para1.add(phrase1);
				para1.setAlignment(Element.ALIGN_LEFT);
			}
			para1.setSpacingAfter(-3f);
			document.add(para);
			document.add(para1);
		}catch(Exception e) {
			
		}
		try {
			if(I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(),"bank")) {
				textUnderline6 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("bankNameDesc").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			}else if(I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(),"Other")) {
				textUnderline6 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("bankOrInstitutionName").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			}else {
				textUnderline6 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("embassyNameDesc").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			}
			Phrase phrase6 = new Phrase();
			phrase6.add(textUnderline6);
			para6.add(phrase6);
			para6.setAlignment(Element.ALIGN_LEFT);
			para6.setSpacingAfter(-3f);
			document.add(para6);
			} catch (Exception e) {
			}
		try {
			if (I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "bank")) {
				
				//SRI00045 starts
//				if (i$body.get("requestDetails").getAsJsonObject().has("bankNameDesc")) {
//					textUnderline72 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("bankNameDesc").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
//				} else {
//					textUnderline72 = new Chunk(" ");
//				}
//				Phrase phrase72 = new Phrase();
//				phrase72.add(textUnderline72);
//				para72.add(phrase72);
//				para72.setAlignment(Element.ALIGN_LEFT);
//				para72.setSpacingAfter(-3f);
//				document.add(para72);
//				//SRI00045 ends 
				
				if (i$body.get("requestDetails").getAsJsonObject().has("bankBranch")) {
					textUnderline7 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("bankBranch").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				} else {
					textUnderline7 = new Chunk(" ");
				}
				Phrase phrase7 = new Phrase();
				phrase7.add(textUnderline7);
				para7.add(phrase7);
				para7.setAlignment(Element.ALIGN_LEFT);
				para7.setSpacingAfter(-8f);
				document.add(para7);
			}else if(I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(),"Other")) {
						//SRI00044 starts
				if (i$body.get("requestDetails").getAsJsonObject().has("collectFrom")) {
					textUnderline72 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("bankAddress").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				} else {
					textUnderline72 = new Chunk(" ");
				}
				Phrase phrase72 = new Phrase();
				phrase72.add(textUnderline72);
				para72.add(phrase72);
				para72.setAlignment(Element.ALIGN_LEFT);
				para72.setSpacingAfter(-3f);
				document.add(para72);
				       //SRI00044 ends 
				if (i$body.get("requestDetails").getAsJsonObject().has("collectFrom")) {
					textUnderline7 = new Chunk(i$body.get("requestDetails").getAsJsonObject().get("collectFrom").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				} else {
					textUnderline7 = new Chunk(" ");
				}
				Phrase phrase7 = new Phrase();
				phrase7.add(textUnderline7);
				para7.add(phrase7);
				para7.setAlignment(Element.ALIGN_LEFT);
				para7.setSpacingAfter(-8f);
				document.add(para7);
			}else {
//				textUnderline7 = new Chunk(strAddrfullname.toString().toUpperCase(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				textUnderline2 = new Chunk(embDetl.get("ADDRESS1").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				textUnderline7 = new Chunk(embDetl.get("ADDRESS2").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				textUnderline7i = new Chunk(embDetl.get("ADDRESS3").getAsString(),FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				
				Phrase phrase2 = new Phrase();
				phrase2.add(textUnderline2);
				para2.add(phrase2);
				para2.setAlignment(Element.ALIGN_LEFT);
				para2.setSpacingAfter(-3f);
				document.add(para2);
				
				Phrase phrase7 = new Phrase();
				phrase7.add(textUnderline7);
				para7.add(phrase7);
				para7.setAlignment(Element.ALIGN_LEFT);
				para7.setSpacingAfter(-3f);
				document.add(para7);
				
				Phrase phrase7i = new Phrase();
				phrase7i.add(textUnderline7i);
				para7i.add(phrase7i);
				para7i.setAlignment(Element.ALIGN_LEFT);
				para7i.setSpacingAfter(-3f);
				document.add(para7i);
			}
			} catch (Exception e) {
			}
			document.add(para);
		try {
			textUnderline3 = new Chunk("Dear Sir/Madam,",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			Phrase phrase3 = new Phrase();
			phrase3.add(textUnderline3);
			para3.add(phrase3);
			para3.setAlignment(Element.ALIGN_LEFT);
			para3.setSpacingAfter(-2f);
			para3.setLeading(0, 1);
			document.add(para3);
		} catch (Exception e) {

		}
		document.add(para);
		try {
			if (I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "travel")) {
				String memId = i$body.get("memberName").getAsString().toUpperCase()+" (" + i$body.get("customerId").getAsString()+ ")";
				Chunk memIdchunk = new Chunk(memId);
				try {
				if(I$utils.$iStrFuzzyMatch(i$body.get("requestDetails").getAsJsonObject().get("statementRequiredForSelf").getAsString(), "No")) {
				try {
//					textUnderline8 = new Chunk("We are pleased to submit the account standing of "
//							+ memIdchunk +" & "+i$body.get("requestDetails").getAsJsonObject().get("nameOfPerson").getAsString()
//							+ " who has indicated that "+i$body.get("requestDetails").getAsJsonObject().get("nameOfPerson").getAsString() +" intends to "+i$body.get("requestDetails").getAsJsonObject().get("purposeOfVisit").getAsString()
//							+ " in the " + embDetl.get("COUNTRY").getAsString() + ".",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					textUnderline8 = new Chunk("We are pleased to submit the account standing of "
							+ i$body.get("requestDetails").getAsJsonObject().get("nameOfPerson").getAsString() +" and "
							+ memIdchunk +
							" who have indicated their intention to travel "
							+ "to " + embDetl.get("COUNTRY").getAsString() + ".",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				} catch (Exception e) {
				}
				}else {
//					textUnderline8 = new Chunk("We are pleased to submit the account standing of "
//							+  memIdchunk + " who has indicated that "+i$body.get("memberName").getAsString() +" intends to "+i$body.get("requestDetails").getAsJsonObject().get("purposeOfVisit").getAsString()
//							+ " in the " + embDetl.get("COUNTRY").getAsString() + ".",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					textUnderline8 = new Chunk("We are pleased to submit the account standing of "
							+  i$body.get("memberName").getAsString()  + "("+ memIdchunk +")"+" who has indicated their intention to travel"+" to " + embDetl.get("COUNTRY").getAsString() + ".",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
				}
				Phrase phrase8 = new Phrase();
				phrase8.add(textUnderline8);
				phrase8.setLeading(0, 1);
				para8.add(phrase8);
				para8.setAlignment(Element.ALIGN_LEFT);
				para8.setSpacingAfter(-3f);
				para8.setLeading(0, 1);
				document.add(para8);
				}catch(Exception e) {
					e.printStackTrace();
				}
				Paragraph spaceBetweenLines = new Paragraph(" ");
				spaceBetweenLines.setSpacingAfter(-3f); 
				document.add(spaceBetweenLines); 
				try {
					textUnderline9 = new Chunk(
							"The present balance on the member's accounts are as follow :-",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					Phrase phrase9 = new Phrase();
					phrase9.add(textUnderline9);
					para9.add(phrase9);
					para9.setAlignment(Element.ALIGN_LEFT);
					para9.setSpacingAfter(2f);
					document.add(para9);
				} catch (Exception e) {
				}
			}

			else {
				try {
					try {
//				textUnderline4 = new Chunk(i$body.get("letterObj").getAsJsonObject().get("memberName").getAsString()
//						+ " (" + i$body.get("letterObj").getAsJsonObject().get("customerId").getAsString() + ")");
						textUnderline4 = new Chunk(i$body.get("memberName").getAsString().toUpperCase() + " ("
								+ i$body.get("customerId").getAsString() + ")",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					} catch (Exception e) {
					}

					Phrase phrase4 = new Phrase();
					phrase4.add(textUnderline4);
					para4.add(phrase4);
					para4.setAlignment(Element.ALIGN_LEFT);
					para4.setSpacingAfter(-3f);
					document.add(para4);
				} catch (Exception e) {

				}
				try {
					textUnderline5 = new Chunk("This is to certify that the above named member's position as at "
							+ new Chunk(lData,FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.RED)) + " is as follows :-",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
					Phrase phrase5 = new Phrase();
					phrase5.add(textUnderline5);
					para5.add(phrase5);
					para5.setAlignment(Element.ALIGN_LEFT);
					para5.setSpacingAfter(2f);
					document.add(para5);
				} catch (Exception e) {

				}
			}
		} catch (Exception e) {
		}
		String[] loanData = strData[0].split("\n");
		String[] sharesData = strData[1].split("\n");
		String[] lineOfCreditData = strData[2].split("\n");
		String[] fdData = strData[3].split("\n");
		Chunk textUnderline = null;
		Phrase phrase = null;
		
		//Loan Details
//		para = new Paragraph("  ");
		Paragraph para40 = new Paragraph();
		Chunk textUnderline40 = new Chunk("Loan Details",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
		textUnderline40.setUnderline(0.8f, -1f);
		Phrase phrase40  = new Phrase();
		phrase40.add(textUnderline40);
		para40.add(phrase40);
		try {
//			document.add(para);
			document.add(para40);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PdfPTable table40 = new PdfPTable(4);
		table40.setWidthPercentage(100);
		PdfPCell cell40_1 = new PdfPCell(new Paragraph("Account No.",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell40_1.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell40_2 = new PdfPCell(new Paragraph("Interest",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell40_2.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell40_3 = new PdfPCell(new Paragraph("Balance",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell40_3.setHorizontalAlignment(Element.ALIGN_CENTER);
//		PdfPCell cell40_4 = new PdfPCell(new Paragraph("Total",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		PdfPCell cell40_5 = new PdfPCell(new Paragraph("Account Description",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell40_5.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell40_6 = null;
		PdfPCell cell40_7 = null;
		PdfPCell cell40_8 = null;
//		PdfPCell cell40_9 = null;
		PdfPCell cell40_10 = null;
		table40.addCell(cell40_1);
		table40.addCell(cell40_2);
		table40.addCell(cell40_3);
//		table40.addCell(cell40_4);
		table40.addCell(cell40_5);
		
		if (loanData.length >= 1) {
//			para = new Paragraph("  ");
//			textUnderline = new Chunk("Loan Details\n\r");
//			textUnderline.setUnderline(0.8f, -1f);
//			phrase = new Phrase();
//			phrase.add(textUnderline);
//			para.add(phrase);
//			try {
//				document.add(para);
//			} catch (DocumentException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			table = new PdfPTable(5); // Create 2 columns in table.
//			table.setWidthPercentage(100);
//			cell1 = new PdfPCell(new Paragraph("Account No"));
//			cell2 = new PdfPCell(new Paragraph("Interest"));
//			cell3 = new PdfPCell(new Paragraph("Balance"));
//			cell4 = new PdfPCell(new Paragraph("Total"));
//			cell5 = new PdfPCell(new Paragraph("Account Description"));
//			table.addCell(cell1);
//			table.addCell(cell2);
//			table.addCell(cell3);
//			table.addCell(cell4);
//			table.addCell(cell5);
			for (int i = 0; i < loanData.length; i++) {
				String str = loanData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("~");
				try {
					if (!arr[0].equals("")) {
						cell40_6 = new PdfPCell(new Paragraph(arr[0],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell40_6 = new PdfPCell(new Paragraph("      Total:",FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//						cell40_6.setBorderWidthLeft(0);
//						cell40_6.setBorderWidthBottom(0);
					}
					cell40_6.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 2 && !arr[1].equals("")) {
						cell40_7 = new PdfPCell(new Paragraph("$"+arr[1],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell40_7 = new PdfPCell(new Paragraph(" "));
					}
					cell40_7.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 3 && !arr[2].equals("")) {
						cell40_8 = new PdfPCell(new Paragraph("$"+arr[2],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell40_8 = new PdfPCell(new Paragraph(" "));
					}
					cell40_8.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
//				try {
//					if (arr.length >= 3 && !arr[2].equals("")) {
//						String value = arr[2];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell40_8 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell40_8 = new PdfPCell(new Paragraph(" "));
//					}
//					cell40_8.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
//				try {
//					if (arr.length >= 3 && !arr[3].equals("")) {
//						String value = arr[3];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell40_9 = new PdfPCell(new Paragraph(balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell40_9 = new PdfPCell(new Paragraph(" "));
//					}
//				} catch (Exception e) {
//
//				}
				try {
//					if (arr.length >= 3 && !arr[3].equals("")) {
					if (arr.length >= 4) {
						cell40_10 = new PdfPCell(new Paragraph(arr[3],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell40_10 = new PdfPCell(new Paragraph(" "));
//						cell40_10.setBorderWidthRight(0);
//						cell40_10.setBorderWidthBottom(0);
					}
					cell40_10.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {
					cell40_10 = new PdfPCell(new Paragraph(" "));
				}
				table40.addCell(cell40_6);
				table40.addCell(cell40_7);
				table40.addCell(cell40_8);
//				table40.addCell(cell40_9);
				table40.addCell(cell40_10);
			}
//			table40.setSpacingAfter(5f);
			try {
				table40.setSpacingBefore(5f);
				document.add(table40);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Share Deatils
		para = new Paragraph("  ");
		Paragraph para41 = new Paragraph();
		Chunk textUnderline41 = new Chunk("Share Details",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
		textUnderline41.setUnderline(0.8f, -1f);
		Phrase phrase41  = new Phrase();
		phrase41.add(textUnderline41);
		para41.add(phrase41);
		try {
			document.add(para41);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PdfPTable table41 = new PdfPTable(4);
		table41.setWidthPercentage(100);
		PdfPCell cell41_1 = new PdfPCell(new Paragraph("Account No.",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell41_1.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell41_4 = new PdfPCell(new Paragraph("Interest",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell41_4.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell41_2 = new PdfPCell(new Paragraph("Balance",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell41_2.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell41_3 = new PdfPCell(new Paragraph("Account Description",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell41_3.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell41_6 = null;
		PdfPCell cell41_7 = null;
		PdfPCell cell41_8 = null;
		PdfPCell cell41_9 = null;
		table41.addCell(cell41_1);
		table41.addCell(cell41_4);
		table41.addCell(cell41_2);
		table41.addCell(cell41_3);
		if (sharesData.length >= 1) {
//			para = new Paragraph("  ");
//			textUnderline = new Chunk("Share Details\n\r");
//			textUnderline.setUnderline(0.8f, -1f);
//			phrase = new Phrase();
//			phrase.add(textUnderline);
//			para.add(phrase);
//			try {
//				document.add(para);
//			} catch (DocumentException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			table = new PdfPTable(3);
//			table.setWidthPercentage(100);
//			cell1 = new PdfPCell(new Paragraph("Account No"));
//			cell2 = new PdfPCell(new Paragraph("Balance"));
//			cell3 = new PdfPCell(new Paragraph("Account Description"));
//			table.addCell(cell1);
//			table.addCell(cell2);
//			table.addCell(cell3);
			for (int i = 0; i < sharesData.length; i++) {
				String str = sharesData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("~");
				try {
					if (arr.length >= 1 && !arr[0].equals("")) {
						cell41_6 = new PdfPCell(new Paragraph(arr[0],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell41_6 = new PdfPCell(new Paragraph("      Total:",FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//						cell41_6.setBorderWidthLeft(0);
//						cell41_6.setBorderWidthBottom(0);
					}
					cell41_6.setHorizontalAlignment(Element.ALIGN_CENTER);
					
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 2 && !arr[1].equals("")) {
						cell41_9 = new PdfPCell(new Paragraph("$"+arr[1],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell41_9 = new PdfPCell(new Paragraph(" "));
					}
					cell41_9.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				
				try {
					if (arr.length >= 3 && !arr[2].equals("")) {
						cell41_7 = new PdfPCell(new Paragraph("$"+arr[2],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell41_7 = new PdfPCell(new Paragraph(" "));
					}
					cell41_7.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				
//				try {
//					if (arr.length >= 2 && !arr[1].equals("")) {
//						String value = arr[1];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell41_9 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell41_9 = new PdfPCell(new Paragraph(" "));
//					}
//					cell41_9.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
				
//				try {
//					if (arr.length >= 3 && !arr[2].equals("")) {
//						String value = arr[2];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell41_7 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell41_7 = new PdfPCell(new Paragraph(" "));
//					}
//					cell41_7.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
				try {
//					if (!arr[3].equals("") && arr.length >= 4) {
					if (arr.length >= 4) {
						cell41_8 = new PdfPCell(new Paragraph(arr[3],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell41_8 = new PdfPCell(new Paragraph(" "));
//						cell41_8.setBorderWidthRight(0);
//						cell41_8.setBorderWidthBottom(0);
					}
					cell41_8.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {
					cell41_8 = new PdfPCell(new Paragraph(" "));
				}
				table41.addCell(cell41_6);
				table41.addCell(cell41_9);
				table41.addCell(cell41_7);
				table41.addCell(cell41_8);

			}
//			table41.setSpacingAfter(15f);
			try {
				table41.setSpacingBefore(5f);
				document.add(table41);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Loan of Credit Details
		para = new Paragraph("  ");
		Paragraph para42 = new Paragraph();
		Chunk textUnderline42 = new Chunk("Line Of Credit Details",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
		textUnderline42.setUnderline(0.8f, -1f);
		Phrase phrase42  = new Phrase();
		phrase42.add(textUnderline42);
		para42.add(phrase42);
		try {
			document.add(para42);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PdfPTable table42 = new PdfPTable(5);
		table42.setWidthPercentage(100);
		PdfPCell cell42_1 = new PdfPCell(new Paragraph("Account No.",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell42_1.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell42_2 = new PdfPCell(new Paragraph("Interest",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell42_2.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell42_3 = new PdfPCell(new Paragraph("Current Balance",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell42_3.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell42_4 = new PdfPCell(new Paragraph("Available Balance",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell42_4.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell42_5 = new PdfPCell(new Paragraph("Account Description",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell42_5.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell42_6 = null;
		PdfPCell cell42_7 = null;
		PdfPCell cell42_8 = null;
		PdfPCell cell42_9 = null;
		PdfPCell cell42_10 = null;
		table42.addCell(cell42_1);
		table42.addCell(cell42_2);
		table42.addCell(cell42_3);
		table42.addCell(cell42_4);
		table42.addCell(cell42_5);
		
		if(lineOfCreditData.length >= 1) {
//			para = new Paragraph("  ");
//			textUnderline = new Chunk("Line Of Credit Details\n\r");
//			textUnderline.setUnderline(0.8f, -1f);
//			phrase = new Phrase();
//			phrase.add(textUnderline);
//			para.add(phrase);
//			try {
//				document.add(para);
//			} catch (DocumentException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			table = new PdfPTable(5);
//			cell1 = new PdfPCell(new Paragraph("Account No"));
//			cell2 = new PdfPCell(new Paragraph("Interest"));
//			cell3 = new PdfPCell(new Paragraph("Current Balance"));
//			cell4 = new PdfPCell(new Paragraph("Available Balance"));
//			cell5 = new PdfPCell(new Paragraph("Account Description"));
//			table.addCell(cell1);
//			table.addCell(cell2);
//			table.addCell(cell3);
//			table.addCell(cell4);
//			table.addCell(cell5);
			for (int i = 0; i < lineOfCreditData.length; i++) {
				String str = lineOfCreditData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("~");
				try {
//					if (!arr[0].equals("") && arr.length >= 1) {
					if (!arr[0].equals("")) {
						cell42_6 = new PdfPCell(new Paragraph(arr[0],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell42_6 = new PdfPCell(new Paragraph("    Total:",FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//						cell42_6.setBorderWidthLeft(0);
//						cell42_6.setBorderWidthBottom(0);
					}
					cell42_6.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				try {
					if (!arr[1].equals("") && arr.length >= 2) {
						cell42_7 = new PdfPCell(new Paragraph("$"+arr[1],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell42_7 = new PdfPCell(new Paragraph(""));
					}
					cell42_7.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				try {
					if (!arr[2].equals("") && arr.length >= 3) {
						cell42_8 = new PdfPCell(new Paragraph("$"+arr[2],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell42_8 = new PdfPCell(new Paragraph(" "));
					}
					cell42_8.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				
				try {
					if (!arr[3].equals("") && arr.length >= 4) {
						cell42_9 = new PdfPCell(new Paragraph("$"+arr[3],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell42_9 = new PdfPCell(new Paragraph(" "));
					}
					cell42_9.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				
//				try {
//					if (!arr[2].equals("") && arr.length >= 3) {
//						String value = arr[2];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell42_8 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell42_8 = new PdfPCell(new Paragraph(""));
//					}
//					cell42_8.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
//				try {
//					if (!arr[3].equals("") && arr.length >= 4) {
//						String value = arr[3];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell42_9 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell42_9 = new PdfPCell(new Paragraph(""));
//					}
//					cell42_9.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
				try {
//					if (!arr[4].equals("") && arr.length >= 5) {
					if ( arr.length >= 5) {
						cell42_10 = new PdfPCell(new Paragraph(arr[4],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell42_10 = new PdfPCell(new Paragraph(""));
//						cell42_10.setBorderWidthRight(0);
//						cell42_10.setBorderWidthBottom(0);//23M24
					}
					cell42_10.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {
					cell42_10 = new PdfPCell(new Paragraph(""));
				}
				table42.addCell(cell42_6);
				table42.addCell(cell42_7);
				table42.addCell(cell42_8);
				table42.addCell(cell42_9);
				table42.addCell(cell42_10);
			}
			try {
				table42.setSpacingBefore(5f);
				document.add(table42);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Fixed Deposit details
		para = new Paragraph("  ");
		Paragraph para43 = new Paragraph();
		Chunk textUnderline43 = new Chunk("Fixed Deposit Details",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
		textUnderline43.setUnderline(0.8f, -1f);
		Phrase phrase43  = new Phrase();
		phrase43.add(textUnderline43);
		para43.add(phrase43);
		try {
			document.add(para43);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PdfPTable table43 = new PdfPTable(4);
		table43.setWidthPercentage(100);
		PdfPCell cell43_1 = new PdfPCell(new Paragraph("Account No.",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell43_1.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell43_4 = new PdfPCell(new Paragraph("Interest",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell43_4.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell43_2 = new PdfPCell(new Paragraph("Balance",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell43_2.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell43_3 = new PdfPCell(new Paragraph("Account Description",FontFactory.getFont("Arial", 9, Font.BOLD, BaseColor.BLACK)));
		cell43_3.setHorizontalAlignment(Element.ALIGN_CENTER);
		PdfPCell cell43_6 = null;
		PdfPCell cell43_7 = null;
		PdfPCell cell43_8 = null;
		PdfPCell cell43_9 = null;
		table43.addCell(cell43_1);
		table43.addCell(cell43_4);
		table43.addCell(cell43_2);
		table43.addCell(cell43_3);
		if (fdData.length >= 1) {
//			para = new Paragraph("  ");
//			textUnderline = new Chunk("Fixed Deposit\n\r");
//			textUnderline.setUnderline(0.8f, -1f);
//			phrase = new Phrase();
//			phrase.add(textUnderline);
//			para.add(phrase);
//			try {
//				document.add(para);
//			} catch (DocumentException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			table = new PdfPTable(3);
//			cell1 = new PdfPCell(new Paragraph("Account No"));
//			cell2 = new PdfPCell(new Paragraph("Balance"));
//			cell3 = new PdfPCell(new Paragraph("Account Description"));
//			table.addCell(cell1);
//			table.addCell(cell2);
//			table.addCell(cell3);
			for (int i = 0; i < fdData.length; i++) {
				String str = fdData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("~");
				try {
					if (!arr[0].equals("") && arr.length >= 1) {
						cell43_6 = new PdfPCell(new Paragraph(arr[0],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell43_6 = new PdfPCell(new Paragraph("    Total:",FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//						cell43_6.setBorderWidthLeft(0);
//						cell43_6.setBorderWidthBottom(0);
					}
					cell43_6.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				
				try {
					if (arr.length >= 2 && !arr[1].equals("")) {
						cell43_9 = new PdfPCell(new Paragraph("$"+arr[1],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell43_9 = new PdfPCell(new Paragraph(" "));
					}
					cell43_9.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				try {
					if (!arr[2].equals("") && arr.length >= 3) {
						cell43_7 = new PdfPCell(new Paragraph("$"+arr[2],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					} else {
						cell43_7 = new PdfPCell(new Paragraph(" "));
					}
					cell43_7.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {

				}
				
//				try {
//					if (!arr[1].equals("") && arr.length >= 2) {
//						String value = arr[1];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell43_9 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell43_9 = new PdfPCell(new Paragraph(" "));
//					}
//					cell43_9.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
				
//				try {
//					if (!arr[2].equals("") && arr.length >= 3) {
//						String value = arr[2];
//						double balance = Double.parseDouble(value);
//						String balanceCom = null;
//						if (balance >= 1000) {
//							Double d1 = Double.valueOf(balance);
//							NumberFormat formatterBal = new DecimalFormat("##,##,###.00");
//							balanceCom = formatterBal.format(d1);
//						}
//						else {
//							balanceCom = Double.toString(balance);
//						}
//						cell43_7 = new PdfPCell(new Paragraph("$"+balanceCom,FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
//					}else {
//						cell43_7 = new PdfPCell(new Paragraph(" "));
//					}
//					cell43_7.setHorizontalAlignment(Element.ALIGN_CENTER);
//				} catch (Exception e) {
//
//				}
				try {
//					if (!arr[3].equals("") && arr.length >= 4) {
					if (arr.length >= 4) {
						cell43_8 = new PdfPCell(new Paragraph(arr[3],FontFactory.getFont("Arial", 8, Font.BOLD, BaseColor.BLACK)));
					}else {
						cell43_8 = new PdfPCell(new Paragraph(" "));
//						cell43_8.setBorderWidthRight(0);
//						cell43_8.setBorderWidthBottom(0);//23M24
					}
					cell43_8.setHorizontalAlignment(Element.ALIGN_CENTER);
				} catch (Exception e) {
					cell43_8 = new PdfPCell(new Paragraph(" "));
				}

				table43.addCell(cell43_6);
				table43.addCell(cell43_9);
				table43.addCell(cell43_7);
				table43.addCell(cell43_8);

			}
//			table43.setSpacingAfter(15f);
			try {
				table43.setSpacingBefore(5f);
				table43.setSpacingAfter(5f);
				document.add(table43);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		document.add(para);
		//MSA00052 starts
			para = new Paragraph("  ");
//			Paragraph para36 = new Paragraph();
//			Chunk textUnderline36 = null;
//			Phrase phrase36 = new Phrase();
		if(I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "bank") || I$utils.$iStrFuzzyMatch(i$body.get("type").getAsString(), "Other")) {
		try {
			for (int i = 0; i < emiData.length; i++) {
				String str = emiData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("~");
//				para36 = new Paragraph("  ");
				Phrase phrase36 = new Phrase();
				textUnderline36 = new Chunk(arr[0]+" : $" +arr[1]+"\n",FontFactory.getFont("Arial", 9, Font.NORMAL, BaseColor.BLACK));
				phrase36.add(textUnderline36);
				para36.add(phrase36);
				para36.setAlignment(Element.ALIGN_LEFT);
			}
//			document.add(para36);
		}catch(Exception e) {
			e.printStackTrace();
		}
		}else {
//			para36 = new Paragraph("  ");
			Phrase phrase36 = new Phrase();
			textUnderline36 = new Chunk("We would appreciate the usual courtesies to our member. Any further enquiries may be addressed to"+"  "+"the undersigned either by telephone or letter.",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			phrase36.add(textUnderline36);
			para36.add(phrase36);
			para36.setAlignment(Element.ALIGN_LEFT);
		}
		para36.setSpacingAfter(-5f);
//		para36.setLeading(0, 1);
		document.add(para36);
		
		//MSA00052 ends
//		para = new Paragraph("  ");
		try {
//			textUnderline = new Chunk(
//					i$body.get("letterObj").getAsJsonObject().get("specificInstructions").getAsString());
			textUnderline = new Chunk(i$body.get("specificInstructions").getAsString(),font);
		} catch (Exception e) {

		}
		phrase = new Phrase();
		phrase.add(textUnderline);
		para.add(phrase);
		para.setAlignment(Element.ALIGN_LEFT);
		try {
			document.add(para);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		Paragraph parai = new Paragraph();
//		textUnderline = new Chunk(
//				"Respectfully\r\nTECU CREDIT UNION\r\nCO-OPERATIVE  SOCIETY  LIMITED\r\n\n\n----------------------------------\r\nAUTHORIZED  SIGNATURE",font);
//		phrase = new Phrase();
//		phrase.add(textUnderline);
//		parai.add(phrase);
//		parai.setAlignment(Element.ALIGN_LEFT);
//		try {
//			document.add(parai);
//		} catch (DocumentException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		Paragraph para51 = new Paragraph();
		Paragraph para52 = new Paragraph();
		Paragraph para53 = new Paragraph();
		Paragraph para54 = new Paragraph();
		Paragraph para55 = new Paragraph();
		Chunk textUnderline51 = null;
		Chunk textUnderline52 = null;
		Chunk textUnderline53 = null;
		Chunk textUnderline54 = null;
		Chunk textUnderline55 = null;
		try {
			textUnderline51 = new Chunk("Respectfully",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			Phrase phrase51 = new Phrase();
			phrase51.add(textUnderline51);
			para51.add(phrase51);
			para51.setAlignment(Element.ALIGN_LEFT);
			para51.setSpacingAfter(-5f);
			float remainingSpace = document.getPageSize().getHeight() - document.topMargin() - document.bottomMargin();
            try {
                if (remainingSpace < 650.0) {
                	document.add(para);
                    document.add(para);
                    document.add(para);
//                    document.add(para51);
                }}catch(Exception e)
                {
                    e.printStackTrace();
                }
			document.add(para51);
		} catch (Exception e) {
		}
//		try {
//			textUnderline52 = new Chunk("TECU CREDIT UNION",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
//			Phrase phrase52 = new Phrase();
//			phrase52.add(textUnderline52);
//			para52.add(phrase52);
//			para52.setAlignment(Element.ALIGN_LEFT);
//			para52.setSpacingAfter(-5f);
//			document.add(para52);
//		} catch (Exception e) {
//		}
//		try {
//			textUnderline53 = new Chunk("CO-OPERATIVE  SOCIETY  LIMITED",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
//			Phrase phrase53 = new Phrase();
//			phrase53.add(textUnderline53);
//			para53.add(phrase53);
//			para53.setAlignment(Element.ALIGN_LEFT);
//			para53.setSpacingAfter(-5f);
//			document.add(para53);
////			document.add(para);
//		} catch (Exception e) {
//		}
		try {//#PAV00032 Changes Starts
			ByteArrayOutputStream byteImgL = new ByteArrayOutputStream();
			String base64Image = i$ResM.getGobalValStr("signTemplate");
			byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
			BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
			ImageIO.write(img, "png", byteImgL);
			byte[] byteArrL = byteImgL.toByteArray();
			Image footerImgL = Image.getInstance(byteArrL);
			footerImgL.scaleAbsolute(100, 25); 
			document.add(footerImgL); 
		} catch (Exception e) {
		}//#PAV00032 Changes Ends
//		try {
//            textUnderline54 = new Chunk("______________________________",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
//            Phrase phrase54 = new Phrase();
//            phrase54.add(textUnderline54);
//            para54.add(phrase54);
//            para54.setAlignment(Element.ALIGN_LEFT);
//            para54.setSpacingAfter(-5f);
//            para54.setSpacingBefore(-12f);//#PAV00032 Changes 
//            document.add(para54);
//        } catch (Exception e) {
//        }
		try {
			textUnderline55 = new Chunk("AUTHORIZED SIGNATURE",FontFactory.getFont("Arial", 10, Font.BOLD, BaseColor.BLACK));
			Phrase phrase55 = new Phrase();
			phrase55.add(textUnderline55);
			para55.add(phrase55);
			para55.setAlignment(Element.ALIGN_LEFT);
			para55.setSpacingAfter(-5f);
			document.add(para55);
		} catch (Exception e) {
		}
		
		document.close();
		byte[] pdfBytes = byteArrayOutputStream.toByteArray();
		String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
		JsonObject i$Body = new JsonObject();
		JsonObject i$Header = isonMsgCopy.getAsJsonObject("i-header");
//		String referenceNo = isonMsgCopy.get("i-body").getAsJsonObject().get("letterObj").getAsJsonObject()
//				.get("referenceNo").getAsString();
		String referenceNo = isonMsgCopy.get("i-body").getAsJsonObject().get("referenceNo").getAsString();
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation1", "FILEUPLD");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "screenid", "FDMFLUPD");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Header, "operation", "CREATE");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileName", referenceNo + ".pdf");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileUrlToken", FileUrlToken);
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileExtn", ".pdf");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "FileSize", 2307138);
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocType", "LETTER MINI STATEMENT");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "I#FileData", base64Str);
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Compressed", "N");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "OriginalFileName", "N");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "tranId", "y9m6jis5r3cGZTEqxGzS");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID1", "MINI STATEMENT");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "LinkedCustNo", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocNo", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubVersion", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueDt", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocExpiryDt", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocIssueAuthority", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldIP", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldSrc", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key1", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key2", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key3", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key4", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key5", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key6", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key7", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key8", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key9", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "Key10", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "TmpStorageRec", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID2", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID3", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocParentGrpID4", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID1", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID2", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID3", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocSubGrpID4", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "UpldDateTime", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocPlaceIssue", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld1", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld2", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld3", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld4", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld5", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld6", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld7", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld8", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld9", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "AddlFld10", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, i$Body, "DocVersion", "");
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_HEADER, i$Header);
		i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_BDYTAG, i$Body);
		i$ResM.iHandleArgJson(i$ResM.I_REMFRMJSON, isonMsgCopy, i$ResM.I_STATTAG);

		JsonObject isonReqhead = new JsonObject();
		JsonObject isonMapJson = new JsonObject();
//		String url = "";
		String ScrCtrlClass = "net.sirma.impacto.iapp.icontrollers.imodulecontrollers.IDmsController";
		Class<?> ctrlClass = null;
		try {
			ctrlClass = Class.forName(ScrCtrlClass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject result$ = null;
		Method ctrlFunc = null;
		try {
			ctrlFunc = ctrlClass.getMethod("processMsg", JsonObject.class, JsonObject.class, JsonObject.class);
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object ctrl$Caller = null;
		try {
			ctrl$Caller = ctrlClass.newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			result$ = (JsonObject) ctrlFunc.invoke(ctrl$Caller, isonMsgCopy, isonReqhead, isonMapJson);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // #BVB00068
		if (I$utils.$iStrFuzzyMatch(i$ResM.getStatMsg(result$), "i-SUCC")) {
			JsonObject respBody = new JsonObject();
			respBody.addProperty("url", data);
			respBody.addProperty("I#FileData", base64Str);
			isonMsgCopy = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsgCopy, i$ResM.I_BDYTAG, respBody);
		}
		return isonMsgCopy;
	}

	public JsonObject amlValidations(JsonObject isonMsg) {// #SRP00066 Start
		JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
		JsonArray funArray = ibody.get("funcDetails").getAsJsonArray();
		JsonArray transactionDet = new JsonArray(); // PKY00078 changes
		try {
			String count = "";
			for (int i = 0; i < funArray.size(); i++) {
				JsonObject funObject = funArray.get(i).getAsJsonObject();
				
				String funName = funObject.get("funcName").getAsString();
				String custAccNo = funObject.get("p_cust_ac_no").getAsString();
				String branch = funObject.get("p_branch").getAsString();
//				String amount = funObject.get("p_amount").getAsString();
				String amoutntCom = funObject.get("p_amount").getAsString();
				String amount = null;
				try {
					double number = Double.parseDouble(amoutntCom);
					if (number >= 1000) {
						Double d1 = Double.valueOf(number);
						NumberFormat formatter = new DecimalFormat("####,###,###.00"); // #MVT00113 changes
						amount = formatter.format(d1);
					} else {
						Double d1 = Double.valueOf(number);
						NumberFormat formatter = new DecimalFormat("####,###,###.00"); // #MVT00113 changes
						amount = formatter.format(d1);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				String custNo = funObject.get("CustomerId").getAsString();
				String amlCheck = funObject.get("amlCheck").getAsString();
				String transferType = ibody.get("transferType").getAsString();
				if ((I$utils.$iStrFuzzyMatch(funName, "fn_getCustDailyAMLCheck"))
						|| (I$utils.$iStrFuzzyMatch(funName, "fn_getCustMonthlyAMLCheck"))
						|| (I$utils.$iStrFuzzyMatch(funName, "fn_getCustYearlyAMLCheck"))) {
					// count = funObject.get("count").getAsString();	//#MVT00125 changes starts
					JsonObject filter = new JsonObject();
					if(funObject.has("memberName")) {
						filter.addProperty("memberName", funObject.get("memberName").getAsString());
					}
					if(funObject.has("branchName")) {
						filter.addProperty("branchName", funObject.get("branchName").getAsString());
					}
					if(funObject.has("creditOrDebit")) {
						filter.addProperty("creditOrDebit", funObject.get("creditOrDebit").getAsString());
					}
					if(funObject.has("transactionDate")) {
						filter.addProperty("TransactionDate", funObject.get("transactionDate").getAsString());
					}
					if(funObject.has("source")) {
						filter.addProperty("source", funObject.get("source").getAsString());
					}	//#MVT00125 changes ends
					if (I$utils.$iStrFuzzyMatch(funName, "fn_getCustDailyAMLCheck")) { //#PAV00010 Changes starts
						filter.addProperty("amlType", "daily");
					}
					if (I$utils.$iStrFuzzyMatch(funName, "fn_getCustMonthlyAMLCheck")) {
						filter.addProperty("amlType", "monthly");
					}
					if (I$utils.$iStrFuzzyMatch(funName, "fn_getCustYearlyAMLCheck")) {
						filter.addProperty("amlType", "yearly");
					} //#PAV00010 Changes ends
					filter.add("CreatedDate", i$ResM.adddate(new Date()).getAsJsonObject());
					filter.add("TransactionTime", i$ResM.adddate(new Date()).getAsJsonObject()); //#MVT00140 changes
					filter.addProperty("FunctionName", funName);
					filter.addProperty("AccountNo", custAccNo);
					filter.addProperty("BranchNo", branch);
					filter.addProperty("isCurrVer", "Y");
					filter.addProperty("TransactionAmount", amount);
					filter.addProperty("CustomerNo", custNo);
					filter.addProperty("TransferType", transferType.toUpperCase());//#MVT00126 changes
					filter.addProperty("amlCheck", amlCheck);
					filter.addProperty("status", "Initiated");
					filter.addProperty("source", funObject.get("source").getAsString());//#PAV00010 Changes
					// PKY00078 starts
					JsonObject db$Res = db$Ctrl.db$InsertRow("ICOR_M_AML_CHECKS", filter);
					String i$statMsg = i$ResM.getStatMsg(db$Res);
					if (I$utils.$iStrFuzzyMatch(funObject.get("amlCheck").getAsString(), "Y")
							&& I$utils.$iStrFuzzyMatch(i$statMsg, i$ResM.I_SUCC)) {
						transactionDet.add(filter);
					}
					// PKY00078 ends
				}
			}
			// PKY00078 starts
			if (!I$utils.$isNull(transactionDet)) {
				sendAlertForAmlTransaction(transactionDet);
			}
			// PKY00078 ends
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "DATA UPDATION SUCCESSFULL");
		} catch (Exception e) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "SOMETHING WENT WRONG");
		}
		return isonMsg; // #SRP00066 Ends
	}

	// MSA00003 Starts
	public JsonObject amlMonthlyIDExp(JsonObject isonMsg) {
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			int iRowCnt = 0;
			Gson gson = new Gson();
			int intPgNo, intRecs;
			String sort = "{'_id':-1}";
			try {
				intPgNo = ibody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = ibody.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 0; //#PAV00007 changes
			}

			iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_CUST_MONTHLY_TRN_DETAILS", isonMsg, "{}");

			projection.addProperty("_id", 0);
			projection.addProperty("finacialYear", 1);
			projection.addProperty("periodCode", 1);
			projection.addProperty("initiatedTime", 1);
			projection.addProperty("completionTime", 1);
			projection.addProperty("totalCount", 1);
			projection.addProperty("schedulerId", 1);
			projection.addProperty("PDF", 1);
			if (ibody.has("dataSetFltr")) { 										// SRI00023 starts
				JsonObject j$DataFilter = i$genAppCtrl.get$FrmDataSetFilter(isonMsg);
				iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_CUST_MONTHLY_TRN_DETAILS", isonMsg, gson.toJson(j$DataFilter));
				JsonObject result = db$Ctrl.db$GetRows$Sort("ICOR_M_CUST_MONTHLY_TRN_DETAILS", j$DataFilter, projection, intPgNo, intRecs, sort);//#PAV00009 starts
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", iRowCnt);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result.get("i-body").getAsJsonArray());
			} else {
				iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_CUST_MONTHLY_TRN_DETAILS", isonMsg, gson.toJson(filter));
				JsonObject result = db$Ctrl.db$GetRows$Sort("ICOR_M_CUST_MONTHLY_TRN_DETAILS", filter, projection,
						intPgNo, intRecs, sort);// #PAV00009 starts
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", iRowCnt);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", result.get("i-body").getAsJsonArray());
			}																		//SRI00023  Ends
		} catch (Exception e) {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	}

	// MSA00003 ends
	// MSA00002 starts
	public JsonObject amlFlxMonthlyTransReport(JsonObject isonMsg) {
		try {
//			JsonObject i$body = isonMsg.get("i-body").getAsJsonObject();
//			JsonArray funcDetail = i$body.get("funcDetails").getAsJsonArray();
//			JsonObject funcObj = funcDetail.get(0).getAsJsonObject();
//			String funcName = funcObj.get("funcName").getAsString();
			// String branch1 = funcObj.get("p_branch").getAsString();
			final IPDFPopulatorKeyMapping pdfMapping = new IPDFPopulatorKeyMapping();
			StringBuilder pdf$Content = new StringBuilder();
			JsonObject monthlyAttachmentData = new JsonObject();
			JsonObject ACHMonthlyAttachmentData = new JsonObject();
			JsonObject CHPDMonthlyAttachmentData = new JsonObject();
			JsonObject ALLCASHMonthlyAttachmentData = new JsonObject();
			JsonObject CHWLMonthlyAttachmentData = new JsonObject();
			String periodCode = isonMsg.get("PCode").getAsString();
			String finacialYear = isonMsg.get("FYear").getAsString();
			JsonObject amlContent = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonObject res = exeCallOrcl(isonMsg);
			JsonObject getMonthlyId = new JsonObject();
			JsonObject getACHMonthly = new JsonObject();
			JsonObject getCHPDMonthly = new JsonObject();
			JsonObject getALLCASHMonthly = new JsonObject();
			JsonObject getCHWLCASHMonthly = new JsonObject();
			String base64MonthlyId = "";
			String base64ACHMonthly = "";
			String base64CHPDMonthly = "";
			String base64ALLCASHMonthly = "";
			String base64CHWLMonthly = "";
			JsonObject resBody = res.get("i-body").getAsJsonObject();
			JsonArray funcRes = resBody.get("funcRes").getAsJsonArray();
			String istatus= new String();
			try { //TKS00020 starts 
				getMonthlyId = funcRes.get(0).getAsJsonObject();
			}catch(Exception e) {
				
			}
			try {
				getACHMonthly = funcRes.get(1).getAsJsonObject();
			} catch (Exception e) {

			}
			try {
				getCHPDMonthly = funcRes.get(2).getAsJsonObject();
			} catch (Exception e) {

			}
			try {
				getALLCASHMonthly = funcRes.get(3).getAsJsonObject();
			} catch (Exception e) {

			}
			try {
				getCHWLCASHMonthly = funcRes.get(4).getAsJsonObject();
			} catch (Exception e) {

			}						//SRI00017 Changes Starts
			try {
				base64ACHMonthly = getACHMonthly.get("i-body").getAsJsonObject().get("report").getAsString();
				if(!I$utils.$iStrBlank(base64ACHMonthly)) {
					ACHMonthlyAttachmentData.addProperty("status","Completed");
	            }else {
	            	ACHMonthlyAttachmentData.addProperty("status","Failed");
	            }
			}catch(Exception e) {
				ACHMonthlyAttachmentData.addProperty("status","Failed");
			}
			try {
				base64CHPDMonthly = getCHPDMonthly.get("i-body").getAsJsonObject().get("report").getAsString();
				if(!I$utils.$iStrBlank(base64CHPDMonthly)) {
					CHPDMonthlyAttachmentData.addProperty("status","Completed");
	            }else {
	            	CHPDMonthlyAttachmentData.addProperty("status","Failed");
	            }
			} catch (Exception e) {
				CHPDMonthlyAttachmentData.addProperty("status","Failed");
			}
			try {
				base64ALLCASHMonthly = getALLCASHMonthly.get("i-body").getAsJsonObject().get("report").getAsString();
				if (!I$utils.$iStrBlank(base64ALLCASHMonthly)){
					ALLCASHMonthlyAttachmentData.addProperty("status","Completed");
				}else {
					ALLCASHMonthlyAttachmentData.addProperty("status","Failed");
				}
			} catch (Exception e) {
				    ALLCASHMonthlyAttachmentData.addProperty("status","Failed");
			}
			try {
				base64CHWLMonthly = getCHWLCASHMonthly.get("i-body").getAsJsonObject().get("report").getAsString(); 
				if (!I$utils.$iStrBlank(base64CHWLMonthly)){
					CHWLMonthlyAttachmentData.addProperty("status","Completed");
				}else {
					CHWLMonthlyAttachmentData.addProperty("status","Failed");
				}
			} catch (Exception e) {
            	CHWLMonthlyAttachmentData.addProperty("status","Failed");
			}//TKS00020 end     //SRI00017 changes Ends
			ACHMonthlyAttachmentData.addProperty("docType", "application/pdf");
			ACHMonthlyAttachmentData.addProperty("fileName", "GET_ACH_MONTH_COUNT_Report"+"Listed_Business_"+i$ResM.getdateTime(new Date())+".pdf");  //#MVT00140 changes begins//SKG00042 chnages
			ACHMonthlyAttachmentData.addProperty("ReportType", "List of Members whose 'ACH + all Cheque transactions (BD04, BU02)' exceed TTD 50000- per month"); //SRI00002 changes
			ACHMonthlyAttachmentData.addProperty("template", base64ACHMonthly);
			
			ALLCASHMonthlyAttachmentData.addProperty("docType", "application/pdf");
			ALLCASHMonthlyAttachmentData.addProperty("fileName", "GET_ALL_CASH_DAY_Report"+"Listed_Business_"+i$ResM.getdateTime(new Date())+".pdf");
			ALLCASHMonthlyAttachmentData.addProperty("ReportType", "List of Members whose 'All Cash transactions (CHDP, CHWL, FTRQ)' exceed TTD 50000- per month"); //SRI00002 changes
			ALLCASHMonthlyAttachmentData.addProperty("template", base64ALLCASHMonthly);
			//SKG00042 chnagses
			CHPDMonthlyAttachmentData.addProperty("docType", "application/pdf");
			CHPDMonthlyAttachmentData.addProperty("fileName", "fn_mno_exc_CHDP_50_Report"+"Listed_Business_"+i$ResM.getdateTime(new Date())+".pdf");
			CHPDMonthlyAttachmentData.addProperty("ReportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 50000- per month"); //SRI00002 changes
			CHPDMonthlyAttachmentData.addProperty("template", base64CHPDMonthly);
		
			CHWLMonthlyAttachmentData.addProperty("docType", "application/pdf");
			CHWLMonthlyAttachmentData.addProperty("fileName", "fn_mno_exc_CHWL_50_Report"+"Listed_Business_"+i$ResM.getdateTime(new Date())+".pdf");  //#MVT00140 changes ends//SKG00042 changses
			CHWLMonthlyAttachmentData.addProperty("ReportType", "List of Members whose '1001 Cash Withdrawal' transactions exceed TTD 50000- per month"); //SRI00002 changes
			CHWLMonthlyAttachmentData.addProperty("template", base64CHWLMonthly);
			int count = 0;
			JsonArray memArray3 = new JsonArray();
			JsonObject branch$ = new JsonObject();
			String branch = "";
			
			try { //TKS00020 starts 
				branch = getMonthlyId.get("fn_get_monthly_id_result").getAsJsonObject().get("p_branch").getAsString();
			}catch(Exception e) {
				
			}//TKS00020 end
			
			branch$.addProperty("Branch", branch);

			if (I$utils.$iStrFuzzyMatch(getMonthlyId.get("fn_get_monthly_id_result").getAsJsonObject().get("funcName").getAsString(), "fn_get_monthly_id_result")) {
				//res = exeCallOrcl(isonMsg);
				// JsonArray memArray2 = new JsonArray();
//				JsonObject ibody = res.get("i-body").getAsJsonObject();
//				JsonArray funcResponse = ibody.get("funcRes").getAsJsonArray();
				JsonObject functionobject = getMonthlyId.get("fn_get_monthly_id_result").getAsJsonObject();
				String op_output = functionobject.get("l_data").getAsString();
				String[] fields = op_output.split("\n");

				for (int i = 0; i < fields.length; i++) {
					try {
						JsonArray memArray = new JsonArray();
						String field = fields[i];
						// String branch =
						// funcDetail.get(0).getAsJsonObject().get("p_branch").getAsString();
						String[] elem = field.split("#");
						String result = elem[0];
						// memObject.addProperty("p_Branch",
						// funcDetail.get(0).getAsJsonObject().get("p_branch").getAsString());
//		                                memObject.addProperty(result);
						memArray.add(result);
						for (int j = 0; j < memArray.size(); j++) {
							pdf$Content.append(memArray.get(j).toString().replace("\"", ""));
						}
						pdf$Content.append("\n");
						if (pdf$Content.length() <= 0) {
							pdf$Content.append(
									"There were no AML transactions recorded on the Flexcube system for today hence no records.");
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				for (int i = 0; i < fields.length; i++) {
					try {
						JsonObject memObject = new JsonObject();
						String field = fields[i];
						// String branch =
						// funcDetail.get(0).getAsJsonObject().get("p_branch").getAsString();
						String[] elem = field.split("#");
						String result = elem[0];
						memObject.addProperty("result", result);
						for (int j = 0; j < memObject.size(); j++) {
							memArray3.add(memObject);
						}
						count++;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				amlContent.add("transactionDetails", memArray3);
				amlContent.addProperty("periodCode", periodCode);
				amlContent.addProperty("finacialYear", finacialYear);
				amlContent.addProperty("p_Branch", branch);
				amlContent.addProperty("totalCount", count);
				amlContent.add("initiatedTime", i$ResM.addDateTime(new Date()));
				amlContent.addProperty("status", "initiated");
				amlContent.addProperty("schedulerId", I$Imputils.generateRandomString(20));
				filter.addProperty("schedulerId", amlContent.get("schedulerId").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_M_CUST_MONTHLY_TRN_DETAILS", amlContent, filter, "true");

				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
				PdfWriter.getInstance(document, byteArrayOutputStream);
				document.open();
				Paragraph para4 = new Paragraph("  ");
				Chunk textUnderline = new Chunk("Monthly Document Check Report");
				textUnderline.setUnderline(0.8f, -1f);
				Phrase phrase = new Phrase();
				phrase.add(textUnderline);
				Paragraph para5 = new Paragraph();
				para5.add(branch$.toString().replace("\"", "").replace("{", "").replace("}", ""));
				Paragraph para0 = new Paragraph();
				para0.add(phrase);
				para0.setAlignment(Element.ALIGN_CENTER);
				Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
				Paragraph para = new Paragraph(pdf$Content.toString(), font);
				Paragraph para2 = new Paragraph();
				String str = I$Ioutils.$getISONowAm();
				para2.add(new Phrase(str));
//				para2.add(new Phrase(I$Ioutils.$getISONowAm().replace("T", " ").replace("Z", " ")));
				para2.setAlignment(Element.ALIGN_CENTER);
				Paragraph para3 = new Paragraph("  ", font);
				document.add(para4);
				document.add(para0);
				document.add(para2);
				document.add(para5);
				document.add(para3);
				document.add(para);
				document.close();

				byte[] pdfBytes = byteArrayOutputStream.toByteArray();
				base64MonthlyId = Base64.getEncoder().encodeToString(pdfBytes);
				monthlyAttachmentData.addProperty("docType", "application/pdf");
				monthlyAttachmentData.addProperty("fileName", "Monthly Report on Missing / Expired Documents"+" "+str+".pdf");
				monthlyAttachmentData.addProperty("template", base64MonthlyId);
			}
			JsonObject dataSetFilter = new JsonObject();
			JsonObject datasetProjection = new JsonObject();
			JsonObject emailDataset$Data = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
			dataSetFilter.addProperty("datasetId", "Dataset_5681");
			datasetProjection.addProperty("userDetails", 1);
			datasetProjection.addProperty("sendEmail", 1);
			datasetProjection.addProperty("sendSms", 1);
			emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
			if (!I$utils.$isNull(emailDataset$Data)) {
				JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
				boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
				boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
				for (int i1 = 0; i1 < userDet.size(); i1++) {
					try {
						if (sendEmail) {
							JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							keyE = keyE.concat(Email);
							if (i1 < userDet.size() - 1) {
								keyE = keyE.concat(",");
							}
						}
						if (sendSMS) {
							JsonObject jsonObject = userDet.get(i1).getAsJsonObject();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							keyM = keyM.concat(SMS);
							if (i1 < userDet.size() - 1) {
								keyM = keyM.concat(",");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					JsonArray attachment = new JsonArray();
					map$Data.addProperty("tmp$name", "TMPL#TT#FLEXCUBE#IDDOC#EXPIRED#MONTHLY#REPORT#MAIL");
					argJson.add("map$Data", map$Data);
					argJson.addProperty("key$Type", "notification");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					attachment.add(monthlyAttachmentData);
					attachment.add(ACHMonthlyAttachmentData);
					attachment.add(CHPDMonthlyAttachmentData);
					attachment.add(ALLCASHMonthlyAttachmentData);
					attachment.add(CHWLMonthlyAttachmentData);
					argJson.add("attachment", attachment);
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
						JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
						JsonObject statusMsg = i$resE.get("i-stat").getAsJsonObject();
						if (statusMsg.has("i-statMsg")) {
							amlContent.add("PDF", monthlyAttachmentData);//#PAV00007 Changes
							amlContent.add("ACH_Monthly_Report", ACHMonthlyAttachmentData);
							amlContent.add("CHDP_Monthly_Report", CHPDMonthlyAttachmentData);
							amlContent.add("All_Cash_Monthly_Report", ALLCASHMonthlyAttachmentData);
							amlContent.add("CHWL_Monthly_Report", CHWLMonthlyAttachmentData);
							amlContent.addProperty("status", "completed");
							amlContent.add("completionTime", i$ResM.addDateTime(new Date()));
							JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_CUST_MONTHLY_TRN_DETAILS", amlContent,
									filter, "true");
						}
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
			}
		} catch (Exception e) {
			logger.debug("Error in sending Flexcube Aml transactions Monthly report");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in sending Flexcube Aml transactions Monthly report");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	}

	public JsonObject amlFlexcubeMonthlyTransactionsReport(JsonObject isonMsg) {
		String fYear = null;
		String pCode = null;
		JsonObject filter = new JsonObject();
		filter.addProperty("privateKey", "SIRMASIRMASIRMAS");
		int date = 0;
		int month = 0;
		int year = 0;
		try {
			Calendar calendar = Calendar.getInstance();
			date = calendar.get(Calendar.DATE);
			month = calendar.get(Calendar.MONTH) + 1;
			year = calendar.get(Calendar.YEAR);

			if (month <= 9) {
				pCode = "M0" + month;
			} else {
				pCode = "M" + month;
			}
			fYear = "FY" + year;
		} catch (Exception e) {

		}
		isonMsg.addProperty("PCode", pCode);
		isonMsg.addProperty("FYear", fYear);

		JsonObject monthlyReport = new JsonObject();
		JsonObject $Data = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter);
		JsonObject i$Datas = $Data.get("monthlyReportValidationParams").getAsJsonObject();
//		date = 22;

		// MSA00004 starts
		if ((month == 1 && date == i$Datas.get("Jan").getAsInt())|| (month == 3 && date == i$Datas.get("Mar").getAsInt())|| (month == 5 && date == i$Datas.get("May").getAsInt())|| (month == 7 && date == i$Datas.get("Jul").getAsInt())|| (month == 8 && date == i$Datas.get("Aug").getAsInt())|| (month == 10 && date == i$Datas.get("Oct").getAsInt())|| (month == 12 && date == i$Datas.get("Dec").getAsInt())) {
			monthlyReport = amlFlxMonthlyTransReport(isonMsg);
		} else if ((month == 2 && date == i$Datas.get("Feb").getAsInt())) {
			monthlyReport = amlFlxMonthlyTransReport(isonMsg);
		} else if ((month == 4 && date == i$Datas.get("Apr").getAsInt())|| (month == 6 && date == i$Datas.get("Jun").getAsInt())|| (month == 9 && date == i$Datas.get("Sept").getAsInt())|| (month == 11 && date == i$Datas.get("Nov").getAsInt())) {
			monthlyReport = amlFlxMonthlyTransReport(isonMsg);
		}else {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Invalid month and date combination");    //SRI00040 Changes
		}
		// MSA00004 ends
		return isonMsg;

	}
	// MSA00002 ends

	//SRM00066 changes start
	public void jobEmailNotification(String ScanType, String currentStatus, String date) {
		try {
            JsonObject emailDataset$Data = new JsonObject();
            JsonObject filter = new JsonObject();
            JsonObject projection = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
            filter.addProperty("datasetId", "Dataset_5683");
            projection.addProperty("userDetails", 1);
            projection.addProperty("sendEmail", 1);
            projection.addProperty("sendSms", 1);
            emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
            
            if(!I$utils.$isNull(emailDataset$Data)) {
            	JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
                boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
                boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
                for (int j = 0; j < userDet.size(); j++) {
                    try {
                        if (sendEmail) {
                            JsonObject jsonObject = userDet.get(j).getAsJsonObject();
                            String Email = jsonObject.get("userEmailId").getAsString();
                            keyE = keyE.concat(Email);
                            if (j < userDet.size() - 1) {
                                keyE = keyE.concat(","); 
                            }
                        }
                        if (sendSMS) {
                            JsonObject jsonObject = userDet.get(j).getAsJsonObject();
                            String SMS = jsonObject.get("userMobileNo").getAsString();
                            keyM = keyM.concat(SMS);
                            if (j < userDet.size() - 1) {
                                keyM = keyM.concat(",");
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            try {
            	JsonObject map$Data = new JsonObject();
                JsonObject data = new JsonObject();
                map$Data.addProperty("tmp$name", "TMPL#KYC#JOB#STATUS#REMINDER");
                map$Data.addProperty("JobType", ScanType);
                map$Data.addProperty("status", currentStatus);
                map$Data.addProperty("initiatedAt", date);
                argJson.add("map$Data", map$Data);  
                
                argJson.addProperty("key$Type", "notification");
                argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
                argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
                if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
                    JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
                    JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
                    
                }
            } catch(Exception e) {
            	e.printStackTrace();
            }
            
            
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	// SRM00066 changes end
	public JsonObject amlTransactionsReport(JsonObject isonMsg) {// #SRP00085 Starts
		JsonObject i$body = isonMsg.get("i-body").getAsJsonObject();
		JsonArray funcDetail = i$body.get("funcDetails").getAsJsonArray();
		JsonObject funcObj = funcDetail.get(0).getAsJsonObject();
		String funcName = funcObj.get("funcName").getAsString();
		try {
			JsonObject res;
			if (I$utils.$iStrFuzzyMatch(funcName, "fn_getCustFlexcubeAMLChecks")) {
				res = exeCallOrcl(isonMsg);
				JsonObject ibody = res.get("i-body").getAsJsonObject();
				JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
				JsonObject functionobject = funcRes.get(0).getAsJsonObject().get("fn_getCustFlexcubeAMLChecks")
						.getAsJsonObject();
				String op_output = functionobject.get("l_data").getAsString();
//				String op_output = "CUSTOMER_000161~TECU - MARABELLA BRANCH~CREDIT~FLEXCUBE~FJB2125701213072~100~Cash Deposit~1000001613130048~000161~24000~01-MAY-2023~Daily~Y";
				String[] fields = op_output.split("~");
				String xrefid = fields[4];
				String branch = fields[5];
				String transferType = fields[6];
				String account_no = fields[7];
				String amount = null;
				String amoutntCom = fields[9];
				try {
					double number = Double.parseDouble(amoutntCom);
					if (number >= 1000) {
						Double d1 = Double.valueOf(number);
						NumberFormat formatter = new DecimalFormat("####,###,###.00"); // #MVT00113 changes
						amount = formatter.format(d1);
					} else {
						Double d1 = Double.valueOf(number);
						NumberFormat formatter = new DecimalFormat("####,###,###.00"); // #MVT00113 changes
						amount = formatter.format(d1);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				String posting_date = fields[10];
				String thresholdLevel = fields[11];
				String cif = account_no.substring(3, 9);
				JsonObject filter1 = new JsonObject();
				filter1.addProperty("memberName", fields[0]); // #MVT00125 changes starts
				filter1.addProperty("branchName", fields[1]);
				filter1.addProperty("creditOrDebit", fields[2]);
				filter1.addProperty("source", fields[3]);
				filter1.addProperty("TransactionReferenceNo", xrefid);
				filter1.addProperty("BranchNo", branch);
				filter1.add("CreatedDate", i$ResM.adddate(new Date()).getAsJsonObject());//PAV00020 Changes
				filter1.addProperty("amlType", "daily");//PAV00020 Changes
				filter1.addProperty("isCurrVer","Y");//PAV00020 Changes
				filter1.addProperty("TransferType", transferType.toUpperCase());// #MVT00126 changes
				filter1.addProperty("AccountNo", account_no);
				filter1.addProperty("CustomerNo", cif);
				filter1.addProperty("TransactionAmount", amount);
				filter1.addProperty("TransactionDate", posting_date);
				filter1.addProperty("ThresholdLevel", thresholdLevel);
				filter1.addProperty("amlCheck", "Y");//#MVT00126 changes
				filter1.add("TransactionTime", i$ResM.addDateTime(new Date()));
				
//				JsonObject db$Res = db$Ctrl.db$InsertRow("ICOR_C_FLEXCUBE_AML_TRN", filter1);
				JsonObject db$Res = db$Ctrl.db$InsertRow("ICOR_M_AML_CHECKS", filter1);	//#MVT00125 changes ends
				JsonObject filter = new JsonObject();
				JsonObject projection = new JsonObject();
				JsonObject emailDataset$Data = new JsonObject();
				String keyE = new String();
				String keyM = new String();
				JsonObject argJson = new JsonObject();
				filter.addProperty("datasetId", "Dataset_5681");
				projection.addProperty("userDetails", 1);
				projection.addProperty("sendEmail", 1);
				projection.addProperty("sendSms", 1);
				emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
				if (!I$utils.$isNull(emailDataset$Data)) {
					JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								keyE = keyE.concat(Email);
								if (i < userDet.size() - 1) {
									keyE = keyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								keyM = keyM.concat(SMS);
								if (i < userDet.size() - 1) {
									keyM = keyM.concat(",");
								}
							}
						} catch (Exception e) {
						}
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					JsonArray attachment = new JsonArray();
					map$Data.addProperty("tmp$name", "TMPL#TT#AML#CHECK#DAILY#TRANSACTION#ALERT");
					map$Data.addProperty("xrefid", xrefid);
					map$Data.addProperty("Branch", branch);
					map$Data.addProperty("Transfer Type", transferType);
					map$Data.addProperty("Transaction Amount", amount);
					map$Data.addProperty("account_no", account_no);
					map$Data.addProperty("posting_date", posting_date);
//					map$Data.addProperty("ThresholdLevel", thresholdLevel);
					argJson.add("map$Data", map$Data);
					argJson.addProperty("key$Type", "alert");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
						JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
				}
			}
//				else {
//				logger.debug("Failed to find Email/Mobile for Alert.");
//			}
//		} catch (Exception e) {
//
//		}
//		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
//	}// #SRP00085 Ends
			// #SRM00009 changes start
			else if (I$utils.$iStrFuzzyMatch(funcName, "fn_getCIFIDDocResults")) {
				res = exeCallOrcl(isonMsg);
				JsonObject ibody = res.get("i-body").getAsJsonObject();
				JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
				JsonObject functionobject = funcRes.get(0).getAsJsonObject().get("fn_getCIFIDDocResults")
						.getAsJsonObject();
				String funName = functionobject.get("funcName").getAsString();
				String branch = functionobject.get("p_branch").getAsString();
				String pCustNo = functionobject.get("p_customer_no").getAsString();
				JsonObject filter1 = new JsonObject();
				JsonObject data = new JsonObject();

				String schedulerId1 = I$Imputils.generateRandomString(20);
				String fYear = null;
				String pCode = null;
				try {
					Calendar calendar = Calendar.getInstance();
					int month = calendar.get(Calendar.MONTH) + 1;
					int year = calendar.get(Calendar.YEAR);
					if (month <= 9) {
						pCode = "M0" + month;
					} else {
						pCode = "M" + month;
					}
					fYear = "FY" + year;
				} catch (Exception e) {
					e.printStackTrace();
				}
				String op_output = functionobject.get("l_data").getAsString();
				String[] fields = op_output.split("~");
				data.addProperty("branchNo", branch);
				data.addProperty("periodCode", pCode);
				data.addProperty("finacialYear", fYear);
				data.addProperty("SchedulerId", schedulerId1);
				filter1.addProperty("SchedulerId", data.get("SchedulerId").getAsString());
				db$Ctrl.db$UpdateRow("ICOR_C_FLEXCUBE_IDDOC_RESULTS", data, filter1, "true");

				JsonObject filter = new JsonObject();
				JsonObject projection = new JsonObject();
				JsonObject emailDataset$Data = new JsonObject();
				String keyE = "";
				String keyM = "";
				JsonObject argJson = new JsonObject();
				filter.addProperty("datasetId", "Dataset_5681");
				projection.addProperty("userDetails", 1);
				projection.addProperty("sendEmail", 1);
				projection.addProperty("sendSms", 1);
				emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
				if (!I$utils.$isNull(emailDataset$Data)) {
					JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
					for (int i = 0; i < userDet.size(); i++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								keyE = keyE.concat(Email);
								if (i < userDet.size() - 1) {
									keyE = keyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(i).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								keyM = keyM.concat(SMS);
								if (i < userDet.size() - 1) {
									keyM = keyM.concat(",");
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					map$Data.addProperty("tmp$name", "TMPL#TT#ID#DOCS#EXPIRED#FLEXCUBE");
					map$Data.addProperty("Branch", branch);
					map$Data.addProperty("memberId", pCustNo);
					map$Data.addProperty("message", op_output);
					argJson.add("map$Data", map$Data);
					argJson.addProperty("key$Type", "alert");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						i$Email.SendEmailWOThread(argJson);
						I$ISmsService.SendSMSWOThread(argJson);
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
				}
			} // #SRM00009 changes end

			// #SRM00004 changes start
			else if (I$utils.$iStrFuzzyMatch(funcName, "fn_get_yearly_id_result")) {
				res = exeCallOrcl(isonMsg);
				JsonObject ibody = res.get("i-body").getAsJsonObject();
				JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
				JsonObject functionobject = funcRes.get(0).getAsJsonObject().get("fn_get_yearly_id_result")
						.getAsJsonObject();
				JsonArray funArray = i$body.get("funcDetails").getAsJsonArray();
				StringBuilder pdf$Content = new StringBuilder();
				JsonObject attachmentData = new JsonObject();
				JsonObject branch$ = new JsonObject();
				JsonObject filter = new JsonObject(); // #SRM00007 change start
				String schedulerId = I$Imputils.generateRandomString(20);
				String fYear = null;
				String pCode = null;
				try {
					Calendar calendar = Calendar.getInstance();
					int month = calendar.get(Calendar.MONTH) + 1;
					int year = calendar.get(Calendar.YEAR);
					if (month <= 9) {
						pCode = "M0" + month;
					} else {
						pCode = "M" + month;
					}
					fYear = "FY" + year;
				} catch (Exception e) {
				}
				for (int j = 0; j < funArray.size(); j++) {
					JsonObject funObject = funArray.get(j).getAsJsonObject();
					String branch = funObject.get("p_branch").getAsString();
					branch$.addProperty("Branch", branch);
					String op_output = null;
					String[] fields = new String[]{};
					try {
						op_output = functionobject.get("l_data").getAsString();
						fields = op_output.split("\n");
					}catch(Exception e) {
						pdf$Content.append("There were no AML transactions recorded on the Flexcube system.");
					}
					if(fields.length > 0) {
						for (int i = 0; i < fields.length; i++) {
							try {
								JsonArray memArray = new JsonArray();
								String field = fields[i];
								String[] elem = field.split(",");
								String result = elem[0];
								memArray.add(result);
								for (int k = 0; k < memArray.size(); k++) {
									pdf$Content.append(memArray.get(k).toString().replace("\"", ""));
								}
								pdf$Content.append("\n");
								if (pdf$Content.length() <= 0) {
									pdf$Content.append("There were no AML transactions recorded on the Flexcube system.");
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
					JsonObject data = new JsonObject();
					data.add("initiatedTime", i$ResM.addDateTime(new Date()));
					data.addProperty("status", "initiated");
					data.addProperty("branchNo", branch);
					data.addProperty("emailStatus", "pending");
					data.addProperty("periodCode", pCode);
					data.addProperty("finacialYear", fYear);
					data.addProperty("SchedulerId", schedulerId);
					filter.addProperty("SchedulerId", data.get("SchedulerId").getAsString());
					db$Ctrl.db$UpdateRow("ICOR_C_FLEXCUBE_IDDOC_RESULTS", data, filter, "true");

					ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
					Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
					PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
					//MSA00010 starts
					HeaderFooterPageEvent event = new HeaderFooterPageEvent();
					writer.setPageEvent(event);
//					event.onEndPage(writer, document);
					event.onStartPage(writer, document);
					document.setMargins(10, 10, 50, 0);//MSA00010 ends
					document.open();
					Paragraph para4 = new Paragraph("  ");
					Font font1 = new Font(FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.BLACK);
					Chunk textUnderline = new Chunk("Yearly ID Document Check Report");
					textUnderline.setUnderline(0.9f, -1f);
					textUnderline.setFont(font1);
					Phrase phrase = new Phrase();
					phrase.add(textUnderline);
					Paragraph para5 = new Paragraph();
					para5.add(branch$.toString().replace("\"", "").replace("{", "").replace("}", ""));
					Paragraph para0 = new Paragraph();
					para0.add(phrase);
					para0.setAlignment(Element.ALIGN_CENTER);
					Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
					Paragraph para = new Paragraph(pdf$Content.toString(), font);
					Paragraph para2 = new Paragraph();
					DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm aa");
					String dateString = dateFormat.format(new Date()).toString();
					String finalstr = dateString.replace("am", "AM").replace("pm","PM");
					para2.add(finalstr);
					para2.setAlignment(Element.ALIGN_CENTER);
					Paragraph para3 = new Paragraph("  ", font);
					document.add(para4);
					document.add(para0);
					document.add(para2);
					document.add(para5);
					document.add(para3);
					document.add(para);
					document.close();
					
					byte[] pdfBytes = byteArrayOutputStream.toByteArray();
					String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
					attachmentData.addProperty("docType", "application/pdf");
					attachmentData.addProperty("fileName", "ID document report" + ".pdf");
					attachmentData.addProperty("template", base64Str);
					JsonObject projection = new JsonObject();
					JsonObject emailDataset$Data = new JsonObject();
					String keyE = new String();
					String keyM = new String();
					JsonObject argJson = new JsonObject();
					JsonObject dataSetFilter = new JsonObject();
					dataSetFilter.addProperty("datasetId", "Dataset_5692");
					projection.addProperty("userDetails", 1);
					projection.addProperty("sendEmail", 1);
					projection.addProperty("sendSms", 1);
					emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, projection);
					if (!I$utils.$isNull(emailDataset$Data)) {
						JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
						boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
						boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(),
								"Y");
						for (int i = 0; i < userDet.size(); i++) {
							try {
								if (sendEmail) {
									JsonObject jsonObject = userDet.get(i).getAsJsonObject();
									String Email = jsonObject.get("userEmailId").getAsString();
									keyE = keyE.concat(Email);
									if (i < userDet.size() - 1) {
										keyE = keyE.concat(",");
									}
								}
								if (sendSMS) {
									JsonObject jsonObject = userDet.get(i).getAsJsonObject();
									String SMS = jsonObject.get("userMobileNo").getAsString();
									keyM = keyM.concat(SMS);
									if (i < userDet.size() - 1) {
										keyM = keyM.concat(",");
									}
								}
							} catch (Exception e) {
							}
						}
					}
					try {
						JsonObject map$Data = new JsonObject();
						JsonArray attachment = new JsonArray();
						map$Data.addProperty("tmp$name", "TMPL#TT#FLEXCUBE#IDDOC#EXPIRED#YEARLY#REPORT#MAIL");
						map$Data.addProperty("Branch", branch);
						argJson.add("map$Data", map$Data);
						argJson.addProperty("key$Type", "alert");
						attachment.add(attachmentData);
						argJson.add("attachment", attachment);
						argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
						argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
						if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
							JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
							JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
							JsonObject statusMsg = i$resE.get("i-stat").getAsJsonObject();
							if (statusMsg.has("i-statMsg")) {
								data.addProperty("status", "completed");
								data.addProperty("emailStatus", "delivered");
								data.add("completionTime", i$ResM.addDateTime(new Date()));
								data.add("pdf", attachmentData);
								db$Ctrl.db$UpdateRow("ICOR_C_FLEXCUBE_IDDOC_RESULTS", data, filter);
							} // #SRM00007 changes end
						}
					} catch (Exception e) {
						logger.debug("Failed to send email and sms" + e.getMessage());
					}
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
			}
		} catch (Exception e) {
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	} // #SRM00004 changes end

	// #SRP00086 Starts
	public JsonObject amlFlexcubeDailyTransactionsReport(JsonObject isonMsg) {
		try {
			String schedulerId = I$Imputils.generateRandomString(20);
//			String date = I$utils.$getISONowAm();
			JsonObject date = new JsonObject();
			JsonObject preFilter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonArray preFilter2 = new JsonArray();
			JsonObject projection = new JsonObject();
			JsonObject exlattachmentData = new JsonObject();
			JsonObject projectionKeys = new JsonObject();
			JsonObject attachmentData = new JsonObject();
			//MSA00009 starts
			Date grtrDate = I$utils.changeDate(1, "SUB", "D");
			Date lsrDate = I$utils.changeDate(0, "SUB", "D");
			String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
			date.add("$gt", iso$date);
			preFilter.add("TransactionTime", date);
			iso$date = Ioutils.dateFromatter(lsrDateS);
			date.add("$lte", iso$date);
			preFilter.add("TransactionTime", date);
			preFilter2.add(preFilter);
			filter.add("$or", preFilter2);
//			JsonObject fltr = new JsonObject();
//			fltr.addProperty("privateKey" ,"SIRMASIRMASIRMAS");
//			JsonObject paramData = db$Ctrl.db$GetRow("ICOR_C_PARAM", fltr);
//			String amlDate = paramData.get("amlDate").getAsString();
//			filter.addProperty("TransactionDate", amlDate);
			//MSA00009 ends
			projection.addProperty("TransactionReferenceNo", 1);
			projection.addProperty("BranchNo", 1);
			projection.addProperty("AccountNo", 1);
			projection.addProperty("TransactionAmount", 1);
			projection.addProperty("TransactionDate", 1);
			projection.addProperty("ThresholdLevel", 1);
			projection.addProperty("_id", 0);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_M_AML_CHECKS", filter, projection);
			int size = i$Body.size();
			StringBuilder pdf$Content = new StringBuilder();
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject db$Doc = i$Body.get(i).getAsJsonObject();
					projectionKeys.addProperty("Transaction Reference No",
							db$Doc.get("TransactionReferenceNo").getAsString());
					projectionKeys.addProperty("Branch No", db$Doc.get("BranchNo").getAsString());
					projectionKeys.addProperty("Account No", db$Doc.get("AccountNo").getAsString());
					projectionKeys.addProperty("Transaction Amount", db$Doc.get("TransactionAmount").getAsString());
					projectionKeys.addProperty("Transaction Date", db$Doc.get("TransactionDate").getAsString());
					projectionKeys.addProperty("Threshold Level", db$Doc.get("ThresholdLevel").getAsString());
					Set<String> keys = projectionKeys.keySet();
					for (String key : keys) {
						try {
							String val = projectionKeys.get(key).getAsString();
							pdf$Content = pdf$Content.append(key + " : " + val + "\n");
						} catch (Exception e) {
						}
					}
					pdf$Content.append("\n");
				} catch (Exception e) {
				}
			}
			if (pdf$Content.length() <= 0) {
				pdf$Content.append(
						"There were no AML transactions recorded on the Flexcube system for today hence no records.");
			}
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
			PdfWriter.getInstance(document, byteArrayOutputStream);
			document.open();
			Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
			Paragraph para = new Paragraph(pdf$Content.toString(), font);
			para.setLeading(0, 1);
			PdfPTable table = new PdfPTable(1);
			table.setWidthPercentage(95);
			PdfPCell cell = new PdfPCell();
			cell.setBorderColor(BaseColor.DARK_GRAY);
			Font font2 = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
			Paragraph para2 = new Paragraph("Daily Report Of Flexcube AML Transactions", font2);
			Paragraph para3 = new Paragraph();
			para3.setFont(font);
			para3.add("Flexcube AML Transaction Date : ");// #SRP00072 Changes
			String str = I$Ioutils.$getISONowAm();
			para3.add(new Phrase(str));
			Paragraph para4 = new Paragraph("  ", font);
			para3.setAlignment(Element.ALIGN_RIGHT);
			para2.setAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(50);
			cell.setPadding(5);
			cell.setPaddingTop(10);
			cell.setVerticalAlignment(Element.ALIGN_LEFT);
			cell.addElement(para2);
			cell.addElement(para3);
			cell.addElement(para4);
			cell.addElement(para);
			table.addCell(cell);
			document.add(table);
			document.close();
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
			attachmentData.addProperty("docType", "application/pdf");
			attachmentData.addProperty("fileName", "Flexcube Aml transactions report" + ".pdf");
			attachmentData.addProperty("template", base64Str);

			// #MSA00007 starts
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sh = wb.createSheet("Sheet1");
			HSSFRow row = sh.createRow(0);
			HSSFFont i$font = wb.createFont();
			sh.setColumnWidth(0, 5000);
			sh.setColumnWidth(1, 4000);
			sh.setColumnWidth(2, 4000);
			sh.setColumnWidth(3, 4000);
			sh.setColumnWidth(4, 4000);
			sh.setColumnWidth(5, 4000);
			HSSFCellStyle style = wb.createCellStyle();
			row.setRowStyle(style);
			int rowCount = 0;
			String[] headings = { "Transaction Reference No", "Branch No", "Account No", "Transaction Amount",
					"Transaction Date", "Threshold Level" };

			for (int i = 0; i < headings.length; i++) {
				try {
					row.createCell(i).setCellValue(headings[i]);
					i$font.setFontName(headings[i]);
					i$font.setColor(IndexedColors.BLACK.getIndex());
					i$font.setBold(true);
				}catch(Exception e) {
				}
			}
			JsonArray memArray = new JsonArray();
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject db$Doc = i$Body.get(i).getAsJsonObject();
					projectionKeys.addProperty("Transaction Reference No",
							db$Doc.get("TransactionReferenceNo").getAsString());
					projectionKeys.addProperty("Branch No", db$Doc.get("BranchNo").getAsString());
					projectionKeys.addProperty("Account No", db$Doc.get("AccountNo").getAsString());
					projectionKeys.addProperty("Transaction Amount", db$Doc.get("TransactionAmount").getAsString());
					projectionKeys.addProperty("Transaction Date", db$Doc.get("TransactionDate").getAsString());
					projectionKeys.addProperty("Threshold Level", db$Doc.get("ThresholdLevel").getAsString());
					memArray.add(projectionKeys);
				} catch (Exception e) {

				}
			}
			for (int i = 0; i < memArray.size(); i++) {
				try {
					JsonObject rec = memArray.get(i).getAsJsonObject();
					String tranRefNo = null, branchNo = null, accNo = null, tranAmt = null, tranDate = null,threshLev = null;
					try {
						tranRefNo = rec.get("Transaction Reference No").getAsString();
					} catch (Exception e) {
					}
					try {
						branchNo = rec.get("Branch No").getAsString();
					} catch (Exception e) {
					}
					try {
						accNo = rec.get("Account No").getAsString();
					} catch (Exception e) {
					}
					try {
						tranAmt = rec.get("Transaction Amount").getAsString();
					} catch (Exception e) {
					}
					try {
						tranDate = rec.get("Transaction Date").getAsString();
					} catch (Exception e) {
					}
					try {
						threshLev = rec.get("Threshold Level").getAsString();
					} catch (Exception e) {
					}
					row = sh.createRow(++rowCount);
					Cell cell1 = row.createCell(0);
					cell1.setCellValue(tranRefNo);
					Cell cell2 = row.createCell(1);
					cell2.setCellValue(branchNo);
					Cell cell3 = row.createCell(2);
					cell3.setCellValue(accNo);
					Cell cell4 = row.createCell(3);
					cell4.setCellValue(tranAmt);
					Cell cell5 = row.createCell(4);
					cell5.setCellValue(tranDate);
					Cell cell6 = row.createCell(5);
					cell6.setCellValue(threshLev);
				} catch (Exception e) {

				}
			}

			wb.write(outputStream);
			byte[] exlBytes = outputStream.toByteArray();
			String base64String = Base64.getEncoder().encodeToString(exlBytes);
			System.out.println(base64String);
			exlattachmentData.addProperty("docType", "application/excel");
			exlattachmentData.addProperty("fileName", "Flexcube Aml transactions report" + ".xls");
			exlattachmentData.addProperty("template", base64String);
			// #MSA00007 ends

			// SKG00016 starts
						JsonObject AllCashDATAAttachmentData = new JsonObject();
						JsonObject CHPDMonthlyAttachmentData = new JsonObject();
						JsonObject mnoExcCHWLAttachmentData = new JsonObject();
						JsonObject mnoExcAC02AttachmentData = new JsonObject();
						JsonObject getmnoExcCHQCH50AttachmentData = new JsonObject();
						JsonObject mnoexcCHQ50AttachmentData = new JsonObject();
						
						AllCashDATAAttachmentData.addProperty("docType", "application/pdf");
						AllCashDATAAttachmentData.addProperty("status", "Initiated");
						AllCashDATAAttachmentData.addProperty("fileName", "FN_PD_EXC_ALL_CASH_20"+ i$ResM.getdateTime(new Date())+".pdf");  //#MVT00140 changes begins//SKG00041 changes
						AllCashDATAAttachmentData.addProperty("reportType", "List of Members whose 'All Cash transactions (CHDP, CHWL, FTRQ)' exceed TTD 20000- per day");
						
						CHPDMonthlyAttachmentData.addProperty("docType", "application/pdf");
						CHPDMonthlyAttachmentData.addProperty("status", "Initiated");
						CHPDMonthlyAttachmentData.addProperty("fileName", "GET_CHDP_MONTH_DATA"+i$ResM.getdateTime(new Date())+".pdf");//SKG00041 changes
						CHPDMonthlyAttachmentData.addProperty("reportType", "List of Members whose '1401 Cash Deposit' transactions exceed TTD 20000- per day");
						
						mnoExcCHWLAttachmentData.addProperty("docType", "application/pdf");
						mnoExcCHWLAttachmentData.addProperty("status", "Initiated");
						mnoExcCHWLAttachmentData.addProperty("fileName", "fn_mno_exc_CHWL_20"+i$ResM.getdateTime(new Date())+".pdf");//SKG00042 changses
						mnoExcCHWLAttachmentData.addProperty("reportType", "List of Members whose '1001 Cash Withdrawal' transactions exceed TTD 20000- per day");
						
						mnoExcAC02AttachmentData.addProperty("docType", "application/pdf");
						mnoExcAC02AttachmentData.addProperty("status", "Initiated");
						mnoExcAC02AttachmentData.addProperty("fileName", "fn_mno_exc_AC02_20"+i$ResM.getdateTime(new Date())+".pdf");
						mnoExcAC02AttachmentData.addProperty("reportType", "List of Members whose 'ACH' transactions exceed TTD 20000- per day");//SKG00042 changes

						// SKG00041 starts 
						getmnoExcCHQCH50AttachmentData.addProperty("docType", "application/pdf");
						getmnoExcCHQCH50AttachmentData.addProperty("status", "Initiated");
						getmnoExcCHQCH50AttachmentData.addProperty("fileName", "fn_mno_exc_CHQ_CH_50"+i$ResM.getdateTime(new Date())+".pdf");
						getmnoExcCHQCH50AttachmentData.addProperty("reportType", "List of Members whose 'Cheque + Cash' exceed TTD 50000- per day");

						
						mnoexcCHQ50AttachmentData.addProperty("docType", "application/pdf");
						mnoexcCHQ50AttachmentData.addProperty("Status", "Initiated");
						mnoexcCHQ50AttachmentData.addProperty("fileName", "fn_mno_exc_CHQ_50"+i$ResM.getdateTime(new Date())+".pdf");  //#MVT00140 changes begins
						mnoexcCHQ50AttachmentData.addProperty("reportType", "List of Members whose 'All Cheque transactions (BD04, BU02)' exceed TTD 50000- per day");

					//	SKG00041 end
						try {
							JsonObject i$body = i$ResM.getBody(isonMsg);
							
							if (i$body.has("funcDetails")) {
								JsonObject cbsFltr = new JsonObject();
								cbsFltr.addProperty("Type", "CBS_BRANCH");
								cbsFltr.addProperty("KeyId", "100");
								JsonObject proj = new JsonObject();
								proj.addProperty("BranchDate", 1);
								JsonObject cbsData = db$Ctrl.db$GetRow("ICOR_M_CBS_E_DATA", cbsFltr, proj);
								String branchDate = cbsData.get("BranchDate").getAsString();
								try {
									i$ResM.getBody(isonMsg).get("funcDetails").getAsJsonArray().get(0).getAsJsonObject().addProperty("p_dt", branchDate);
								} catch (Exception e) {
								}
								try {
									i$ResM.getBody(isonMsg).get("funcDetails").getAsJsonArray().get(1).getAsJsonObject().addProperty("p_dt", branchDate);
								} catch (Exception e) {
								}
								try {
									i$ResM.getBody(isonMsg).get("funcDetails").getAsJsonArray().get(2).getAsJsonObject().addProperty("p_dt", branchDate);
								} catch (Exception e) {
								}
								try {
									i$ResM.getBody(isonMsg).get("funcDetails").getAsJsonArray().get(3).getAsJsonObject().addProperty("p_dt", branchDate);
								} catch (Exception e) {
								}
								try {
									i$ResM.getBody(isonMsg).get("funcDetails").getAsJsonArray().get(4).getAsJsonObject().addProperty("p_dt", branchDate);
								} catch (Exception e) {
								}
								try {
									i$ResM.getBody(isonMsg).get("funcDetails").getAsJsonArray().get(5).getAsJsonObject().addProperty("p_dt", branchDate);
								} catch (Exception e) {
								}
								
								JsonObject res = exeCallOrcl(isonMsg);
								JsonObject getAllCashDay = new JsonObject();
								JsonObject getCHPDMonthly = new JsonObject();
								JsonObject getmnoExcCHWL = new JsonObject();
								JsonObject getmnoExcAC02 = new JsonObject();
								JsonObject getmnoExcCHQCH50 = new JsonObject();
								JsonObject getmnoexcCHQ50 = new JsonObject();
								
								String base64AllCashDay = "";
								String base64CHPDMonthly = "";
								String base64mnoExcCHW = "";
								String base64mnoExcAC02 = "";
								String base64mnoExcCHQCH50 = "";
								String base64ExcCHQ50 = "";
//								JsonArray base64=new JsonArray();
								JsonObject resBody = res.get("i-body").getAsJsonObject();
								JsonArray funcRes = resBody.get("funcRes").getAsJsonArray();
								try {
									getAllCashDay = funcRes.get(0).getAsJsonObject();
									base64AllCashDay = getAllCashDay.get("i-body").getAsJsonObject().get("report").getAsString();
									if(!I$utils.$iStrBlank(base64AllCashDay)) {
										AllCashDATAAttachmentData.addProperty("status","Completed");
					                }else {
					                	AllCashDATAAttachmentData.addProperty("status","Failed");
					                }
								} catch (Exception e) {
									AllCashDATAAttachmentData.addProperty("status","Failed");
								}
								try {
									getCHPDMonthly = funcRes.get(1).getAsJsonObject();
									base64CHPDMonthly = getCHPDMonthly.get("i-body").getAsJsonObject().get("report").getAsString();
									if(!I$utils.$iStrBlank(base64CHPDMonthly)) {
										CHPDMonthlyAttachmentData.addProperty("status","Completed");
					                }else {
					                	CHPDMonthlyAttachmentData.addProperty("status","Failed");
					                }
								} catch (Exception e) {
									CHPDMonthlyAttachmentData.addProperty("status","Failed");
								}
								try {
									getmnoExcCHWL = funcRes.get(2).getAsJsonObject();
									base64mnoExcCHW = getmnoExcCHWL.get("i-body").getAsJsonObject().get("report").getAsString();
									if(!I$utils.$iStrBlank(base64mnoExcCHW)) {
										mnoExcCHWLAttachmentData.addProperty("status","Completed");
					                }else {
					                	mnoExcCHWLAttachmentData.addProperty("status","Failed");
					                }
								} catch (Exception e) {
									mnoExcCHWLAttachmentData.addProperty("status","Failed");
								}
								try {
									getmnoExcAC02 = funcRes.get(3).getAsJsonObject();
									base64mnoExcAC02 = getmnoExcAC02.get("i-body").getAsJsonObject().get("report").getAsString();
									if(!I$utils.$iStrBlank(base64mnoExcAC02)) {
										mnoExcAC02AttachmentData.addProperty("status","Completed");
					                }else {
					                	mnoExcAC02AttachmentData.addProperty("status","Failed");
					                }
								} catch (Exception e) {
									mnoExcAC02AttachmentData.addProperty("status","Failed");
								}
								try {
									getmnoExcCHQCH50 = funcRes.get(4).getAsJsonObject();
									base64mnoExcCHQCH50 = getmnoExcCHQCH50.get("i-body").getAsJsonObject().get("report").getAsString();
									if(!I$utils.$iStrBlank(base64mnoExcCHQCH50)) {
										mnoexcCHQ50AttachmentData.addProperty("status","Completed");
					                }else {
					                	mnoexcCHQ50AttachmentData.addProperty("status","Failed");
					                }
								} catch (Exception e) {
									mnoexcCHQ50AttachmentData.addProperty("status","Failed");
								}
								try {
									getmnoexcCHQ50 = funcRes.get(5).getAsJsonObject();
									base64ExcCHQ50 = getmnoexcCHQ50.get("i-body").getAsJsonObject().get("report").getAsString();
									if(!I$utils.$iStrBlank(base64ExcCHQ50)) {
										getmnoExcCHQCH50AttachmentData.addProperty("status","Completed");
					                }else {
					                	getmnoExcCHQCH50AttachmentData.addProperty("status","Failed");
					                }
								} catch (Exception e) {
									getmnoExcCHQCH50AttachmentData.addProperty("status","Failed");
								}
//								base64.add(base64AllCashDay); 
//								base64.add(base64CHPDMonthly);
//								base64.add(base64mnoExcCHW);
//								base64.add(base64mnoExcAC02);
//								base64.add(base64mnoExcCHQCH50);
//								base64.add(base64ExcCHQ50);
//								JsonArray pdfbase64=new JsonArray();
//								pdfbase64.addAll(base64);
								
								
//								db$Ctrl.db$UpdateRow("ICOR_M_DAILY_FLX_AML_TRANSACTION", "");
								AllCashDATAAttachmentData.addProperty("template", base64AllCashDay);
								CHPDMonthlyAttachmentData.addProperty("template", base64CHPDMonthly);
								mnoExcCHWLAttachmentData.addProperty("template", base64mnoExcCHW);
								mnoExcAC02AttachmentData.addProperty("template", base64mnoExcAC02);
								getmnoExcCHQCH50AttachmentData.addProperty("template", base64ExcCHQ50);
								mnoexcCHQ50AttachmentData.addProperty("template", base64mnoExcCHQCH50 ); 
								// SKG00016 end
							}
						}catch(Exception e) {
							
						}
			
			
			JsonObject dataSetFilter = new JsonObject();
			JsonObject datasetProjection = new JsonObject();
			JsonObject emailDataset$Data = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
			dataSetFilter.addProperty("datasetId", "Dataset_5682");
			datasetProjection.addProperty("userDetails", 1);
			datasetProjection.addProperty("sendEmail", 1);
			datasetProjection.addProperty("sendSms", 1);
			emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
			if (!I$utils.$isNull(emailDataset$Data)) {
				JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
				boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
				boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
				for (int i = 0; i < userDet.size(); i++) {
					try {
						if (sendEmail) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							keyE = keyE.concat(Email);
							if (i < userDet.size() - 1) {
								keyE = keyE.concat(",");
							}
						}
						if (sendSMS) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							keyM = keyM.concat(SMS);
							if (i < userDet.size() - 1) {
								keyM = keyM.concat(",");
							}
						}
					} catch (Exception e) {
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					JsonArray attachment = new JsonArray();
					map$Data.addProperty("tmp$name", "TMPL#TT#AML#FLEXCUBE#TRANSACTIONS#DAILY#REPORT#MAIL");
					argJson.add("map$Data", map$Data);
					argJson.addProperty("key$Type", "notification");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					attachment.add(attachmentData);
					attachment.add(exlattachmentData);
					attachment.add(AllCashDATAAttachmentData);
					attachment.add(CHPDMonthlyAttachmentData);
					attachment.add(mnoExcCHWLAttachmentData);
					attachment.add(mnoExcAC02AttachmentData);
					attachment.add(getmnoExcCHQCH50AttachmentData);
					attachment.add(mnoexcCHQ50AttachmentData);
					argJson.add("attachment", attachment);
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
						JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
					}
					
					// SKG00016 starts
					JsonArray allReports = new JsonArray();
					JsonObject reportObj = new JsonObject();
					JsonObject reports = new JsonObject();
					
					try {
						String fYear = null;
						String pCode = null;
//						JsonObject amlContent = new JsonObject();
						
						int date_1 = 0;
						int month = 0;
						int year = 0;
						try {
							Calendar calendar = Calendar.getInstance();
							date_1 = calendar.get(Calendar.DATE);
							month = calendar.get(Calendar.MONTH) + 1;
							year = calendar.get(Calendar.YEAR);

							if (month <= 9) {
								pCode = "M0" + month;
							} else {
								pCode = "M" + month;
							}
							fYear = "FY" + year;
						} catch (Exception e) {

						}
					
//					reportObj.add("Flexcube Aml transactions report",attachmentData);
//					reportObj.add("ALL CASH DAY Report",AllCashDATAAttachmentData);
//					reportObj.add("CHDP Monthly Report",CHPDMonthlyAttachmentData);
//					reportObj.add("MONO EXC CHWL Report",mnoExcCHWLAttachmentData);
//					reportObj.add("MONO EXC AC02 Report",mnoExcAC02AttachmentData);
//					reportObj.add("MNO EXC CHQ CH Report",mnoExcAC02AttachmentData);
//					reportObj.add("MONO EXC CHQ 50 Report",mnoexcCHQ50AttachmentData);
					
//					allReports.add(attachmentData);
					allReports.add(AllCashDATAAttachmentData);
					allReports.add(CHPDMonthlyAttachmentData);
					allReports.add(mnoExcCHWLAttachmentData);
					allReports.add(mnoExcAC02AttachmentData);
					allReports.add(getmnoExcCHQCH50AttachmentData);
					allReports.add(mnoexcCHQ50AttachmentData);
					
//					reports.addProperty("FYear", fYear);
//					reports.add("initiatedTime", i$ResM.addDateTime(new Date()));
//					reports.addProperty("PCode", pCode);
//					reports.add("Reports", reportObj);
//					reports.addProperty("SchedularId",schedulerId);
					
//					allReports.add(reportObj);
					JsonObject curObj = new JsonObject();
					JsonArray insertObj = new JsonArray();
					for(int i=0 ; i<allReports.size() ; i++) {
						try {
//							filter = new JsonObject();
							curObj = allReports.get(i).getAsJsonObject();
//							curObj.addProperty("reportType", curObj.get("fileName").getAsString().split(".")[0]);
							curObj.addProperty("FYear", fYear);
							curObj.add("initiatedTime", i$ResM.addDateTime(new Date()));
							curObj.addProperty("PCode", pCode);
//							reports.add("Reports", reportObj);
							curObj.addProperty("SchedularId",schedulerId);
//							filter.addProperty( "fileName", curObj.get("fileName").getAsString().split(".")[0]);
//							filter.addProperty("SchedularId",schedulerId);
//							JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_AML_CHECKS", curObj,filter, "true");
							insertObj.add(curObj);
						}catch(Exception e) {
						}

					}
					JsonObject db$Res = db$Ctrl.db$InsertMany("ICOR_M_AML_CHECKS", insertObj);
//					JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_AML_CHECKS", curObj,filter, "true");
					System.out.println();
					}catch(Exception e){
					}
					// SKG00016 end			
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
			}
		} catch (Exception e) {
			logger.debug("Error in sending Flexcube Aml transactions daily report");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in sending Flexcube Aml transactions daily report");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	} // #SRP00086 Ends

		// PKY00078 starts
	public void sendAlertForAmlTransaction(JsonArray transactionDet) {

		JsonObject alertData = transactionDet.get(0).getAsJsonObject();
		JsonObject filter = new JsonObject();
		JsonObject projection = new JsonObject();
		JsonObject emailDataset$Data = new JsonObject();
		String keyE = new String();
		String keyM = new String();
		JsonObject argJson = new JsonObject();
		filter.addProperty("datasetId", "Dataset_5677");
		projection.addProperty("userDetails", 1);
		projection.addProperty("sendEmail", 1);
		projection.addProperty("sendSms", 1);
		emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", filter, projection);
		if (!I$utils.$isNull(emailDataset$Data)) {
			JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
			boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
			boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
			for (int i = 0; i < userDet.size(); i++) {
				try {
					if (sendEmail) {
						JsonObject jsonObject = userDet.get(i).getAsJsonObject();
						String Email = jsonObject.get("userEmailId").getAsString();
						keyE = keyE.concat(Email);
						if (i < userDet.size() - 1) {
							keyE = keyE.concat(",");
						}
					}
					if (sendSMS) {
						JsonObject jsonObject = userDet.get(i).getAsJsonObject();
						String SMS = jsonObject.get("userMobileNo").getAsString();
						keyM = keyM.concat(SMS);
						if (i < userDet.size() - 1) {
							keyM = keyM.concat(",");
						}
					}
				} catch (Exception e) {
				}
			}
			try {
				// MSA00008 starts
				JsonObject map$Data = new JsonObject();
				String amt = alertData.get("Amount").getAsString();
				Double dbl = Double.valueOf(amt);
				NumberFormat formatter = new DecimalFormat("#0,000.00");
				String amountCom = formatter.format(dbl);
				String date = alertData.get("CreatedDate").getAsJsonObject().get("$date").getAsString()
						.replace("T", " ").replace("Z", "");
				SimpleDateFormat dt = new SimpleDateFormat("yyyy-mm-dd hh:mm");
				Date date23 = dt.parse(date);
				SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-mm-dd hh:mm aa");
				String finalDate = dt1.format(date23);
				String finalStr = finalDate.replace("am", "AM").replace("pm","PM");
				// MSA00008 ends
				map$Data.addProperty("tmp$name", "TMPL#TT#AML#CHECK#TRANSACTION#ALERT");
				map$Data.addProperty("CustomerNo", alertData.get("CustomerNo").getAsString());// #SRP00072 Starts
				map$Data.addProperty("CustomerAccNo", alertData.get("CustomerAccNo").getAsString());
				map$Data.addProperty("Branch", alertData.get("Branch").getAsString());
				map$Data.addProperty("Amount", amountCom);
//				map$Data.addProperty("CreatedDate", alertData.get("CreatedDate").getAsJsonObject().get("$date").getAsString().replace("T", ", ").replace("Z", "")); //#SRP00072 Ends
				map$Data.addProperty("CreatedDate", finalStr);
				map$Data.addProperty("Daily", "");
				map$Data.addProperty("Monthly", "");
				map$Data.addProperty("Yearly", "");
				for (int i = 0; i < transactionDet.size(); i++) {
					String transactionType = transactionDet.get(i).getAsJsonObject().get("FunctionNmae").getAsString();
					if (I$utils.$iStrFuzzyMatch(transactionType, "fn_getCustDailyAMLCheck")) {
						map$Data.addProperty("Daily", "daily");
					}
					if (I$utils.$iStrFuzzyMatch(transactionType, "fn_getCustMonthlyAMLCheck")) {
						map$Data.addProperty("Monthly", "monthly");
					}
					if (I$utils.$iStrFuzzyMatch(transactionType, "fn_getCustYearlyAMLCheck")) {
						map$Data.addProperty("Yearly", "yearly");
					}
				}
				argJson.add("map$Data", map$Data);
				argJson.addProperty("key$Type", "alert");
				argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
				argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
				if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
					JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
					JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
				}
			} catch (Exception e) {
				logger.debug("Failed to send email and sms" + e.getMessage());
			}
		} else {
			logger.debug("Failed to find Email/Mobile for Alert.");
		}

	}

	public JsonObject amlYearlyExcessInc(JsonObject isonMsg) { // #SRM00006 changes start
		try {
			JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
			JsonObject filter = new JsonObject();
			JsonObject projection = new JsonObject();
			Gson gson = new Gson();
			int intPgNo, intRecs;
			int iRowCnt = 0;
			String sort;   //#SRM00043 Changes start
			try {
				String sortField = ibody.get("sort").getAsString();
				sort = "{'"+sortField+"':-1}";
			} catch (Exception e) {
				sort = "{'_id':-1}";
			}  //#SRM00043 changes end
			try {
				intPgNo = ibody.get("intPgNo").getAsInt();
			} catch (Exception e) {
				intPgNo = 0;
			}
			try {
				intRecs = ibody.get("intRecs").getAsInt();
			} catch (Exception e) {
				intRecs = 50;
			}
			projection.addProperty("_id", 0);
			projection.addProperty("finacialYear", 1);
			projection.addProperty("periodCode", 1);
			projection.addProperty("initiatedTime", 1);
			projection.addProperty("status", 1);           //SRI00019  Changes
			projection.addProperty("completionTime", 1);
			projection.addProperty("transactionCount", 1);
			projection.addProperty("SchedulerId", 1);//#MVT00126 changes starts
			projection.addProperty("fileName", 1);
			projection.addProperty("pdf.template",1);
			if(ibody.has("dataSetFltr")) {    									//SRI00022 starts 
				JsonObject j$DataFilter = i$genAppCtrl.get$FrmDataSetFilter(isonMsg);
				iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_CUSTOMER_YEARLY_TRN_DETAILS", isonMsg, gson.toJson(j$DataFilter));
				JsonObject result = db$Ctrl.db$GetRows$Sort("ICOR_M_CUSTOMER_YEARLY_TRN_DETAILS", j$DataFilter,
						projection, intPgNo, intRecs, sort);
				JsonArray dbresult = result.getAsJsonArray("i-body");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", iRowCnt);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", dbresult);
			}else {
				iRowCnt = db$Ctrl.db$GetCountI("ICOR_M_CUSTOMER_YEARLY_TRN_DETAILS", isonMsg, gson.toJson(filter));
				JsonObject result = db$Ctrl.db$GetRows$Sort("ICOR_M_CUSTOMER_YEARLY_TRN_DETAILS", filter,
						projection, intPgNo, intRecs, sort);
				JsonArray dbresult = result.getAsJsonArray("i-body");
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowCnt", iRowCnt);
				i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, ibody, "iRowData", dbresult);
			}																 //SRI00022 Ends 	
			//#MVT00126 changes ends
		} catch (Exception e) {
			return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Operation failed");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	} // #SRM00006 end
		// #SRM00003 Changes

	public JsonObject amlFlexcubeYearlyTransactionsReport(JsonObject isonMsg) {
		try {
			JsonObject i$body = isonMsg.get("i-body").getAsJsonObject();
			JsonArray funcDetail = i$body.get("funcDetails").getAsJsonArray();
			JsonObject funcObj = funcDetail.get(0).getAsJsonObject();
			String funcName = funcObj.get("funcName").getAsString();
			StringBuilder pdf$Content = new StringBuilder();
			JsonObject attachmentData = new JsonObject();
			JsonObject exlattachmentData = new JsonObject();
			JsonObject amlContent = new JsonObject();
			JsonObject filter = new JsonObject();
			String schedulerId = I$Imputils.generateRandomString(20);
			String fYear = null;
			String pCode = null;
			int count = 0;
			JsonObject branch$ = new JsonObject(); // #SRM00009 changes
			String brn = " "+funcDetail.get(0).getAsJsonObject().get("p_branch").getAsString();//PAV00033 Changes
			branch$.addProperty("Branch ", brn);
			JsonObject res;
			try {
				Calendar calendar = Calendar.getInstance();
				int month = calendar.get(Calendar.MONTH) + 1;
				int year = calendar.get(Calendar.YEAR);
				if (month <= 9) {
					pCode = "M0" + month;
				} else {
					pCode = "M" + month;
				}
				fYear = "FY" + year;
			} catch (Exception e) {
			}
			if (I$utils.$iStrFuzzyMatch(funcName, "fn_getcifexcincome_yr")) {
				
				res = exeCallOrcl(isonMsg);
				JsonArray memArray = new JsonArray();
				JsonObject ibody = res.get("i-body").getAsJsonObject();
				JsonArray funcRes = ibody.get("funcRes").getAsJsonArray();
				JsonObject functionobject = funcRes.get(0).getAsJsonObject().get("fn_getcifexcincome_yr")
						.getAsJsonObject();
				String[] fields=new String[] {};//PAV00033 Changes Starts
				String op_output = "";
				try {
					 op_output = functionobject.get("l_data").getAsString();
					 fields = op_output.split("\n");
				}catch(Exception e) {
					
				}//PAV00033 Changes Ends
//				String op_output = functionobject.get("l_data").getAsString();
//				String[] fields = op_output.split("\n");
				try {
					if(fields.length > 0) {
						for (int i = 0; i < fields.length; i++) {
							try {
								JsonObject memObject = new JsonObject();
								String field = fields[i];
								String[] elem = field.split("~");
								String slNo = null, memberNo = null, amount = null, memberSalary = null, annualSalary = null,difference = null, branch = null, memName = null, branchName = null, frequency = null;
								count++;
								try {
									 slNo = String.valueOf(count);
								} catch (Exception e) {}
								try {
									 memberNo = elem[0];
								} catch (Exception e) {}
								try {
									 amount = elem[1];
								} catch (Exception e) {}
								try {
									 memberSalary = elem[2];
								} catch (Exception e) {}
								try {
									 annualSalary = elem[3];
								} catch (Exception e) {}
								try {
									 difference = elem[4];
								} catch (Exception e) {}
								try {
									 branch = elem[5];
								} catch (Exception e) {}
								try {
									 memName = elem[6];
								} catch (Exception e) {}
								try {
									 branchName = elem[7];
								} catch (Exception e) {}
								try {
									frequency = elem[8];
								} catch (Exception e) {}
								memObject.addProperty("Sl.No", slNo);
								memObject.addProperty("Member No", memberNo);
								memObject.addProperty("Total Credits in the account", amount);
								memObject.addProperty("Member Salary", memberSalary);
								memObject.addProperty("Annual Salary", annualSalary);
								memObject.addProperty("Difference", difference);
								memObject.addProperty("Branch", branch);
								memObject.addProperty("Member Name", memName);
								memObject.addProperty("Branch Name", branchName);
								memObject.addProperty("Frequency", frequency);
								memArray.add(memObject);
//								count++;
								for (int j = 0; j < memArray.size(); j++) {
									pdf$Content.append(memArray.get(j).toString());
								}
								pdf$Content.append("\n");
								if (pdf$Content.length() <= 0) {
									pdf$Content.append(
											"There were no AML transactions recorded on the Flexcube system for today hence no records.");
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}else {//PAV00033 Changes 
						pdf$Content.append(
								"There were no AML transactions recorded on the Flexcube system for today hence no records.");
					}
				}catch(Exception e) {
					
				}

				amlContent.addProperty("transactionCount", count);
				amlContent.add("initiatedTime", i$ResM.addDateTime(new Date()));
				amlContent.add("Transaction_details", memArray);
				amlContent.addProperty("periodCode", pCode);
				amlContent.addProperty("finacialYear", fYear);
				amlContent.addProperty("SchedulerId", schedulerId);
				amlContent.addProperty("fileName", "Excess Income Yearly Transaction Report");
				filter.addProperty("SchedulerId", amlContent.get("SchedulerId").getAsString());
				JsonObject db$Res = db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_YEARLY_TRN_DETAILS", amlContent, filter,
						"true");

//                #SRM00005 Changes start

				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//				Rectangle pageSize = new Rectangle(612, 792);
//				pageSize.setBackgroundColor(new BaseColor(0xFF, 0xFF, 0xDE));
//				Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
//				document.setMargins(20,20,100,30);
				Document document = new Document(PageSize.A4.rotate(), 0.75F, 0.75F, 0.75F, 0.75F);
				document.setMargins(10, 10, 100, 30);

				//MSA00010 starts
				PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
				HeaderFooterPageEvent event = new HeaderFooterPageEvent();
				writer.setPageEvent(event);
				event.onEndPage(writer, document);  //MSA00010 ends
				
				HeaderFooterPageEvent2 event2 = new HeaderFooterPageEvent2();
				writer.setPageEvent(event2);
				event2.onStartPage(writer, document);
				
				
				document.open();
//				Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
				PdfPTable table = new PdfPTable(1);
				table.setWidthPercentage(80);
//				table.setTotalWidth(150);
				PdfPCell cell = new PdfPCell();
				cell.setBorderColor(BaseColor.DARK_GRAY);
				Font font2 = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
				Paragraph para2 = new Paragraph("Excess Income Yearly Transaction Report", font2);
				Paragraph para3 = new Paragraph("  ", font2);
				para3.add("Date : ");
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh.mm aa");
				String dateString = dateFormat.format(new Date()).toString();
				String finalstr = dateString.replace("am", "AM").replace("pm","PM");
				para3.add(new Phrase(finalstr));
				Paragraph para4 = new Paragraph("  ", font2);
				Paragraph para5 = new Paragraph();
				para5.add(branch$.toString().replace("\"", "").replace("{", "").replace("}", ""));
				para5.setAlignment(Element.ALIGN_CENTER);
				para3.setAlignment(Element.ALIGN_CENTER);
				para2.setAlignment(Element.ALIGN_CENTER);
				cell.setMinimumHeight(50);
				cell.setPadding(5);
				cell.setPaddingTop(10);
				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.addElement(para2);
				cell.addElement(para3);
				cell.addElement(para4);
				cell.addElement(para5); // #SRM00009 changes
				table.addCell(cell);
				
//				Row<PDPage> row4 = table.createRow(100.0f);
				
				document.add(table);
				PdfPTable table1 = new PdfPTable(10);
				table1.setWidthPercentage(100);
//				table1.setWidths(new int[] {50, 100, 200, 100, 150, 150, 150, 150, 150});
				table1.setWidths(new int[] {60, 100, 100, 100, 100, 100, 100, 100, 100, 100});
//                String pdfContent = pdf$Content.toString();
//                String[] content = pdfContent.split(",");
//				
				PdfPCell c1 = new PdfPCell(new Phrase("Sl.No"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Member No"));
//				PdfPCell c1 = new PdfPCell(new Phrase("Member No"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Member Name"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Branch No"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Branch Name"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Total Credits in the account (A)"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Member Salary (B)"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
//				c1 = new PdfPCell(new Phrase("Annual Salary (C=B*12)"));
				c1 = new PdfPCell(new Phrase("Annual Salary (C)"));//PAV00033 Changes
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Difference (A-C)"));
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);
				c1 = new PdfPCell(new Phrase("Frequency"));//PAV00033 Changes Starts
				c1.setHorizontalAlignment(Element.ALIGN_CENTER);
				c1.setBackgroundColor(BaseColor.YELLOW);
				table1.addCell(c1);//PAV00033 Changes Ends
				table1.setHeaderRows(1);
				for (int i = 0; i < fields.length; i++) {
					try {
					String field = fields[i];
					String[] elem = field.split("~");
					String slNo = null, memberNo= null, amount= null, memberSalary= null, annualSalary= null, difference= null, branch= null, memName = null, branchName = null, frequency = null;//PAV00033 Changes
					try {
//						 slNo = String.valueOf(count);
						int k=i;
						slNo = String.valueOf(++k);
					} catch (Exception e) {}
					try {
						memberNo = elem[0];
					} catch (Exception e) {}
					try {
						String amountCom = null;
						amountCom = elem[1];
//						amountCom = elem[1];
						double number = Double.parseDouble(amountCom);
						if (number >= 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00");
							amount = formatter.format(d1);
							
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00"); //#MVT00113 changes
							amount = formatter.format(d1);
						}
					} catch (Exception e) {}
					try {
						String amountCom = null;
						amountCom = elem[2];
						double number = Double.parseDouble(amountCom);
						if (number >= 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00");
							memberSalary = formatter.format(d1);
							
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00"); //#MVT00113 changes
							memberSalary = formatter.format(d1);
						}
//						memberSalary = elem[3];
					} catch (Exception e) {}
					try {
						String amountCom = null;
						amountCom = elem[3];
						double number = Double.parseDouble(amountCom);
						if (number >= 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00");
							annualSalary = formatter.format(d1);
							
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00"); //#MVT00113 changes
							annualSalary = formatter.format(d1);
						}
//						annualSalary = elem[4];
					} catch (Exception e) {}
					try {
						String amountCom = null;
						amountCom = elem[4];
						double number = Double.parseDouble(amountCom);
						if (number >= 1000) {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00");
							difference = formatter.format(d1);
							
						}
						else {
							Double d1 = Double.valueOf(number);
							NumberFormat formatter = new DecimalFormat("##,##,##,##,###.00"); //#MVT00113 changes
							difference = formatter.format(d1);
						}
//						difference = elem[5];
					} catch (Exception e) {}
					try {
						branch = elem[5];
					} catch (Exception e) {}
					try {
						memName = elem[6];
					} catch (Exception e) {}
					try {
						branchName = elem[7];
					} catch (Exception e) {}
					try {//PAV00033 Changes
						frequency = elem[8];
					} catch (Exception e) {}
					cell.addElement(table1);
					PdfPCell d1 = new PdfPCell(new Phrase(slNo));
					d1.setHorizontalAlignment(Element.ALIGN_CENTER);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(memberNo));
					d1.setHorizontalAlignment(Element.ALIGN_CENTER);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(memName));
					d1.setHorizontalAlignment(Element.ALIGN_LEFT);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(branch));
					d1.setHorizontalAlignment(Element.ALIGN_CENTER);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(branchName));
					d1.setHorizontalAlignment(Element.ALIGN_LEFT);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(amount));
					d1.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(memberSalary));
					d1.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(annualSalary));
					d1.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(difference));
					d1.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table1.addCell(d1);
					d1 = new PdfPCell(new Phrase(frequency));//PAV00033 Changes
					d1.setHorizontalAlignment(Element.ALIGN_RIGHT);
					table1.addCell(d1);
					}catch(Exception e) {
						
					}
				}
//				PdfWriter writer = null;
//				PdfTemplate total = writer.getDirectContent().createTemplate(30, 12);
//				ColumnText.showTextAligned(total, Element.ALIGN_LEFT,new Phrase(String.valueOf(writer.getPageNumber() - 1), normal),2, 2, 0);
				document.add(table1);
				document.close();
//				 //#SRM00005 end
//
				byte[] pdfBytes = byteArrayOutputStream.toByteArray();
				String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
				attachmentData.addProperty("docType", "application/pdf");
				attachmentData.addProperty("fileName", "Excess income yearly transaction report" + ".pdf");
				attachmentData.addProperty("template", base64Str);

				// #MSA00005 starts
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sh = wb.createSheet("Sheet1");
				HSSFRow row = sh.createRow(0);
				HSSFFont i$font = wb.createFont();
				sh.setColumnWidth(0, 4000);
				sh.setColumnWidth(1, 4000);
				sh.setColumnWidth(2, 4000);
				sh.setColumnWidth(3, 4000);
				sh.setColumnWidth(4, 4000);
				sh.setColumnWidth(5, 4000);
				sh.setColumnWidth(6, 4000);
				sh.setColumnWidth(7, 4000);
				sh.setColumnWidth(8, 4000);
				sh.setColumnWidth(9, 4000);//PAV00033 Changes
				HSSFCellStyle style = wb.createCellStyle();
				row.setRowStyle(style);
				int rowCount = 0;
				String[] headings = {"Sl.No", "Member No", "Total Credits in the account", "Member Salary", "Annual Salary", "Difference", "Branch",
						"Member Name", "Branch Name", "Frequency"};//PAV00033 Changes

				for (int i = 0; i < headings.length; i++) {
					row.createCell(i).setCellValue(headings[i]);
					i$font.setFontName(headings[i]);
					i$font.setColor(IndexedColors.BLACK.getIndex());
					i$font.setBold(true);

				}
				
				for (int i = 0; i < memArray.size(); i++) {
					String slNo = null, memNo = null, amount = null, memSal = null, annSal = null, diff = null, branch = null,
							memName = null, branchName = null, frequency = null;//PAV00033 Changes
					try {
						JsonObject rec = memArray.get(i).getAsJsonObject();
						try {
							slNo = rec.get("Sl.No").getAsString();
						} catch (Exception e) {
						}
						try {
							memNo = rec.get("Member No").getAsString();
						} catch (Exception e) {
						}
						try {
							amount = rec.get("Total Credits in the account").getAsString();
						} catch (Exception e) {
						}
						try {
							memSal = rec.get("Member Salary").getAsString();
						} catch (Exception e) {
						}
						try {
							annSal = rec.get("Annual Salary").getAsString();
						} catch (Exception e) {
						}
						try {
							diff = rec.get("Difference").getAsString();
						} catch (Exception e) {
						}
						try {
							branch = rec.get("Branch").getAsString();
						} catch (Exception e) {
						}
						try {
							memName = rec.get("Member Name").getAsString();
						} catch (Exception e) {
						}
						try {
							branchName = rec.get("Branch Name").getAsString();
						} catch (Exception e) {
						}
						try {//PAV00033 Changes
							frequency = rec.get("Frequency").getAsString();
						} catch (Exception e) {
						}
						row = sh.createRow(++rowCount);
						Cell cell1 = row.createCell(0);
						cell1.setCellValue(slNo);
						Cell cell2 = row.createCell(1);
						cell2.setCellValue(memNo);
						Cell cell3 = row.createCell(2);
						cell3.setCellValue(amount);
						Cell cell4 = row.createCell(3);
						cell4.setCellValue(memSal);
						Cell cell5 = row.createCell(4);
						cell5.setCellValue(annSal);
						Cell cell6 = row.createCell(5);
						cell6.setCellValue(diff);
						Cell cell7 = row.createCell(6);
						cell7.setCellValue(branch);
						Cell cell8 = row.createCell(7);
						cell8.setCellValue(memName);
						Cell cell9 = row.createCell(8);
						cell9.setCellValue(branchName);
						Cell cell10 = row.createCell(9);//PAV00033 Changes
						cell10.setCellValue(frequency);
					} catch (Exception e) {

					}
				}

				wb.write(outputStream);
				byte[] exlBytes = outputStream.toByteArray();
				String base64String = Base64.getEncoder().encodeToString(exlBytes);
				System.out.println(base64String);
				exlattachmentData.addProperty("docType", "application/excel");
				exlattachmentData.addProperty("fileName", "Excess income yearly transaction report" + ".xls");
				exlattachmentData.addProperty("template", base64String);
				// #MSA00005 ends

				JsonObject dataSetFilter = new JsonObject();
				JsonObject datasetProjection = new JsonObject();
				JsonObject emailDataset$Data = new JsonObject();
				String keyE = new String();
				String keyM = new String();
				JsonObject argJson = new JsonObject();
				dataSetFilter.addProperty("datasetId", "Dataset_5682");
				datasetProjection.addProperty("userDetails", 1);
				datasetProjection.addProperty("sendEmail", 1);
				datasetProjection.addProperty("sendSms", 1);
				emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
				if (!I$utils.$isNull(emailDataset$Data)) {
					JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
					boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
					boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
					for (int j = 0; j < userDet.size(); j++) {
						try {
							if (sendEmail) {
								JsonObject jsonObject = userDet.get(j).getAsJsonObject();
								String Email = jsonObject.get("userEmailId").getAsString();
								keyE = keyE.concat(Email);
								if (j < userDet.size() - 1) {
									keyE = keyE.concat(",");
								}
							}
							if (sendSMS) {
								JsonObject jsonObject = userDet.get(j).getAsJsonObject();
								String SMS = jsonObject.get("userMobileNo").getAsString();
								keyM = keyM.concat(SMS);
								if (j < userDet.size() - 1) {
									keyM = keyM.concat(",");
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					try {
						JsonObject map$Data = new JsonObject();
						JsonArray attachment = new JsonArray();
						JsonObject data = new JsonObject();
						map$Data.addProperty("tmp$name", "TMPL#TT#FLEXCUBE#EXCESS#INCOME#YEARLY#REPORT#MAIL");
						argJson.add("map$Data", map$Data);
						argJson.addProperty("key$Type", "notification");
						argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
						argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
						attachment.add(attachmentData);
						attachment.add(exlattachmentData);
						argJson.add("attachment", attachment);
						if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
							JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
							JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
							JsonObject statusMsg = i$resE.get("i-stat").getAsJsonObject();
							if (statusMsg.has("i-statMsg")) {
								data.addProperty("status", "completed");
								data.add("completionTime", i$ResM.addDateTime(new Date()));
								data.add("pdf", attachmentData);
								data.add("excel", exlattachmentData);
								db$Ctrl.db$UpdateRow("ICOR_M_CUSTOMER_YEARLY_TRN_DETAILS", data, filter);
							}
						}
					} catch (Exception e) {
						logger.debug("Failed to send email and sms" + e.getMessage());
						return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
					}
				} else {
					logger.debug("Failed to find Email/Mobile for Alert.");
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
				}
			}
		} catch (Exception e) {
			logger.debug("Error in sending Flexcube Aml transactions yearly report");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
					"Error in sending Flexcube Aml transactions yearly report");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	} // #SRM00003 end

	public JsonObject amlTransactionsDailyReport(JsonObject isonMsg) throws DocumentException {
		try {
			JsonObject date = new JsonObject();
			JsonObject preFilter = new JsonObject();
			JsonObject filter = new JsonObject();
			JsonArray preFilter2 = new JsonArray();
			JsonObject projection = new JsonObject();
			JsonObject attachmentData = new JsonObject();
			JsonObject exlattachmentData = new JsonObject();
			JsonObject projectionKeys = new JsonObject();
			Date grtrDate = I$utils.changeDate(1, "SUB", "D");
			Date lsrDate = I$utils.changeDate(0, "SUB", "D");
			String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
			date.add("$gt", iso$date);
			preFilter.add("TransactionTime", date);
			iso$date = Ioutils.dateFromatter(lsrDateS);
			date.add("$lte", iso$date);
			preFilter.add("TransactionTime", date);
			preFilter2.add(preFilter);
			filter.add("$or", preFilter2);
			filter.addProperty("amlCheck", "Y");// #SRP00072 Starts
			projection.addProperty("CreatedDate", 1);
			projection.addProperty("CustomerAccNo", 1);
			projection.addProperty("Branch", 1);
			projection.addProperty("Amount", 1);
			projection.addProperty("CustomerNo", 1);// #SRP00072 Starts
			// projection.addProperty("amlCheck", 1);
			projection.addProperty("_id", 0);
			JsonArray i$Body = db$Ctrl.db$GetRows("ICOR_M_AML_CHECKS", filter, projection);
			int size = i$Body.size();
			StringBuilder pdf$Content = new StringBuilder();
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject db$Doc = i$Body.get(i).getAsJsonObject();
					projectionKeys.addProperty("AML Transaction Date", db$Doc.get("CreatedDate").getAsString());
					projectionKeys.addProperty("Member Account No", db$Doc.get("CustomerAccNo").getAsString());
					projectionKeys.addProperty("Branch", db$Doc.get("Branch").getAsString());
					projectionKeys.addProperty("Amount", db$Doc.get("Amount").getAsString());
					projectionKeys.addProperty("Member No", db$Doc.get("CustomerNo").getAsString());
					Set<String> keys = projectionKeys.keySet();
					for (String key : keys) {
						try {
							String val = projectionKeys.get(key).getAsString();
							pdf$Content = pdf$Content.append(key + " : " + val + "\n");
						} catch (Exception e) {
						}
					}
					pdf$Content.append("\n");
				} catch (Exception e) {
				}
			}
			if (pdf$Content.length() <= 0) {
				pdf$Content.append("No Record found.");
			}
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
			PdfWriter.getInstance(document, byteArrayOutputStream);
			document.open();
			Font font = new Font(FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
			Paragraph para = new Paragraph(pdf$Content.toString(), font);
			para.setLeading(0, 1);
//			 Chunk glue = new Chunk(new VerticalPositionMark());
			PdfPTable table = new PdfPTable(1);
			table.setWidthPercentage(95);
			PdfPCell cell = new PdfPCell();
			// cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
			cell.setBorderColor(BaseColor.DARK_GRAY);
			// PdfPCell cell2 = new PdfPCell();
			Font font2 = new Font(FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
			// i$ResM.getdateTime(new Date());
			Paragraph para2 = new Paragraph("Daily Report Of AML Transactions", font2);
			Paragraph para3 = new Paragraph();
			para3.setFont(font);
			// para3.add("ref : ");
			// para3.add(refNo+"\n");
			para3.add("AML Transaction Date : ");// #SRP00072 Changes
//			para3.add(new Phrase(DateTime.now().toString("MMM dd, YYYY hh:mm:ss")));
			String str = I$Ioutils.$getISONowAm();
			para3.add(new Phrase(str));
			Paragraph para4 = new Paragraph("  ", font);
			para3.setAlignment(Element.ALIGN_RIGHT);
			para2.setAlignment(Element.ALIGN_CENTER);
			cell.setMinimumHeight(50);
			cell.setPadding(5);
			cell.setPaddingTop(10);
			cell.setVerticalAlignment(Element.ALIGN_LEFT);
			cell.addElement(para2);
			cell.addElement(para3);
			cell.addElement(para4);
			cell.addElement(para);
//			cell.setTextAlignment(TextAlignment.CENTER);
			// cell.setHorizontalAlignment(0);
//			 cell.addElement(para2);
			table.addCell(cell);
			document.add(table);
			document.close();
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(pdfBytes);
			attachmentData.addProperty("docType", "application/pdf");
			attachmentData.addProperty("fileName", "Aml transactions report" + ".pdf");
			attachmentData.addProperty("template", base64Str);

			//#MSA00006 starts
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sh = wb.createSheet("Sheet1");
			HSSFRow row = sh.createRow(0);
			HSSFFont i$font = wb.createFont();
			sh.setColumnWidth(0, 4000);
			sh.setColumnWidth(1, 4000);
			sh.setColumnWidth(2, 4000);
			sh.setColumnWidth(3, 4000);
			sh.setColumnWidth(4, 4000);
			HSSFCellStyle style = wb.createCellStyle();
			row.setRowStyle(style);
			int rowCount = 0;
			String[] headings = { "AML Transaction Date", "Member Account No", "Branch", "Amount", "Member No" };

			for (int i = 0; i < headings.length; i++) {
				row.createCell(i).setCellValue(headings[i]);
				i$font.setFontName(headings[i]);
				i$font.setColor(IndexedColors.BLACK.getIndex());
				i$font.setBold(true);

			}
			JsonArray memArray = new JsonArray();
			for (int i = 0; i < i$Body.size(); i++) {
				try {
					JsonObject db$Doc = i$Body.get(i).getAsJsonObject();
					projectionKeys.addProperty("AML Transaction Date", db$Doc.get("CreatedDate").getAsString());
					projectionKeys.addProperty("Member Account No", db$Doc.get("CustomerAccNo").getAsString());
					projectionKeys.addProperty("Branch", db$Doc.get("Branch").getAsString());
					projectionKeys.addProperty("Amount", db$Doc.get("Amount").getAsString());
					projectionKeys.addProperty("Member No", db$Doc.get("CustomerNo").getAsString());
					memArray.add(projectionKeys);
				} catch (Exception e) {

				}
			}

			for (int i = 0; i < memArray.size(); i++) {
				try {
					JsonObject rec = memArray.get(i).getAsJsonObject();
					String amlDate = null, accNo = null, branch = null, amt = null, memNo = null;
					try {
						amlDate = rec.get("AML Transaction Date").getAsString();
					} catch (Exception e) {
					}
					try {
						accNo = rec.get("Member Account No").getAsString();
					} catch (Exception e) {
					}
					try {
						branch = rec.get("Branch").getAsString();
					} catch (Exception e) {
					}
					try {
						amt = rec.get("Amount").getAsString();
					} catch (Exception e) {
					}
					try {
						memNo = rec.get("Member No").getAsString();
					} catch (Exception e) {
					}
				row = sh.createRow(++rowCount);
				Cell cell1 = row.createCell(0);
				cell1.setCellValue(amlDate);
				Cell cell2 = row.createCell(1);
				cell2.setCellValue(accNo);
				Cell cell3 = row.createCell(2);
				cell3.setCellValue(branch);
				Cell cell4 = row.createCell(3);
				cell4.setCellValue(amt);
				Cell cell5 = row.createCell(4);
				cell5.setCellValue(memNo);
				}catch(Exception e) {
					
				}
			}

			wb.write(outputStream);
			byte[] exlBytes = outputStream.toByteArray();
			String base64String = Base64.getEncoder().encodeToString(exlBytes);
			System.out.println(base64String);
			exlattachmentData.addProperty("docType", "application/excel");
			exlattachmentData.addProperty("fileName", "Aml transactions report" + ".xls");
			exlattachmentData.addProperty("template", base64String);
			// #MSA00006 ends

			JsonObject dataSetFilter = new JsonObject();
			JsonObject datasetProjection = new JsonObject();
			JsonObject emailDataset$Data = new JsonObject();
			String keyE = new String();
			String keyM = new String();
			JsonObject argJson = new JsonObject();
			dataSetFilter.addProperty("datasetId", "Dataset_5678");
			datasetProjection.addProperty("userDetails", 1);
			datasetProjection.addProperty("sendEmail", 1);
			datasetProjection.addProperty("sendSms", 1);
			emailDataset$Data = db$Ctrl.db$GetRow("ICOR_M_EMAIL_DATASETS", dataSetFilter, datasetProjection);
			if (!I$utils.$isNull(emailDataset$Data)) {
				JsonArray userDet = emailDataset$Data.get("userDetails").getAsJsonArray();
				boolean sendSMS = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendSms").getAsString(), "Y");
				boolean sendEmail = I$utils.$iStrFuzzyMatch(emailDataset$Data.get("sendEmail").getAsString(), "Y");
				for (int i = 0; i < userDet.size(); i++) {
					try {
						if (sendEmail) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String Email = jsonObject.get("userEmailId").getAsString();
							keyE = keyE.concat(Email);
							if (i < userDet.size() - 1) {
								keyE = keyE.concat(",");
							}
						}
						if (sendSMS) {
							JsonObject jsonObject = userDet.get(i).getAsJsonObject();
							String SMS = jsonObject.get("userMobileNo").getAsString();
							keyM = keyM.concat(SMS);
							if (i < userDet.size() - 1) {
								keyM = keyM.concat(",");
							}
						}
					} catch (Exception e) {
					}
				}
				try {
					JsonObject map$Data = new JsonObject();
					JsonArray attachment = new JsonArray();
					map$Data.addProperty("tmp$name", "TMPL#TT#AML#TRANSACTIONS#DAILY#REPORT#MAIL");
					argJson.add("map$Data", map$Data);
					argJson.addProperty("key$Type", "notification");
					argJson.add("toemailIds", i$ResM.getJsonObj("{\"toemailid1\":\"" + keyE + "\"}"));
					argJson.add("mobile$numbers", i$ResM.getJsonObj("{\"Mob_Number1\":\"" + keyM + "\"}"));
					attachment.add(attachmentData);
					attachment.add(exlattachmentData); //MSA00006 changes
					argJson.add("attachment", attachment);
					if (!I$utils.$iStrBlank(keyE) || !I$utils.$iStrBlank(keyM)) {
						JsonObject i$resE = i$Email.SendEmailWOThread(argJson);
						JsonObject i$resM = I$ISmsService.SendSMSWOThread(argJson);
					}
				} catch (Exception e) {
					logger.debug("Failed to send email and sms" + e.getMessage());
					return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to send email and sms");
				}
			} else {
				logger.debug("Failed to find Email/Mobile for Alert.");
				return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed to find Email/Mobile for Alert");
			}
		} catch (Exception e) {
			logger.debug("Error in sending Aml transactions daily report");
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Error in sending Aml transactions daily report");
		}
		return isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "Job completed successfully");
	}

	public JsonObject flexcubeDataMapping(String base64, JsonObject isonMsg) {
		try {
			String cif = isonMsg.get("i-body").getAsJsonObject().get("cif").getAsString();
			String custName = isonMsg.get("i-body").getAsJsonObject().get("CustomerFullName").getAsString();
			String shareBalance = null;
			JsonObject iBody = isonMsg.get("i-body").getAsJsonObject();
			try {
				if (iBody.has("totalShareBalance")) {
					shareBalance = isonMsg.get("i-body").getAsJsonObject().get("loanDetails").getAsJsonObject()
							.get("totalShareBalance").getAsString();
				} else {
					shareBalance = "0.00";
				}
			} catch (Exception e) {

			}
			String data = "";
			JsonObject i$body = new JsonObject();
			JsonObject result = new JsonObject();
			JsonArray funcDetails = new JsonArray();
			JsonObject function = new JsonObject();
			function.addProperty("funcName", "GET_FD_LOC_LOAN_DET");
			function.addProperty("p_cust_no", cif);
			funcDetails.add(function);
			i$body.add("funcDetails", funcDetails);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
			result = exeCallOrcl(isonMsg);
			data = result.get("i-body").getAsJsonObject().get("funcRes").getAsJsonArray().get(0).getAsJsonObject()
					.get("GET_FD_LOC_LOAN_DET").getAsJsonObject().get("l_full_data").getAsString();
			//#MVT00114 changes begins
			String[] dataArr = data.split("~");
			int arrLength = dataArr.length;
			String[] fdData = {""};
			String[] loanData = {""};
			String[] locData = {""};
			if(dataArr.length<3) {
				fdData = data.split("~")[0].split("\n");
				loanData = data.split("~")[1].split("\n");
			} else {
				fdData = data.split("~")[0].split("\n");
				loanData = data.split("~")[2].split("\n");
				locData = data.split("~")[1].split("\n");
			}
			//#MVT00114 changes ends
			byte[] loanBytes = org.apache.commons.codec.binary.Base64.decodeBase64(base64);
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			Document document = new Document(PageSize.LETTER, 0.75F, 0.75F, 0.75F, 0.75F);
			PdfWriter.getInstance(document, byteArrayOutputStream);
			document.open();
			Paragraph para0 = null;
			Paragraph para1 = null;
			Paragraph para2 = null;
			Paragraph para3 = null;
			PdfPCell cell1 = null;
			PdfPCell cell2 = null;
			PdfPCell cell3 = null;
			PdfPCell cell4 = null;
			PdfPCell cell5 = null;
			PdfPCell cell6 = null;
			PdfPCell cell7 = null;
			PdfPCell cell8 = null;
			PdfPCell cell9 = null;
			PdfPCell cell10 = null;
			PdfPCell cell11 = null;
			PdfPCell cell12 = null;
			Chunk textUnderline0 = null;
			Chunk textUnderline1 = null;
			Chunk textUnderline2 = null;
			Chunk textUnderline3 = null;
			try {
				para3 = new Paragraph("\r\n");
				textUnderline3 = new Chunk(cif);
				Phrase phrase3 = new Phrase();
				phrase3.add(textUnderline3);
				para3.add(phrase3);
				para3.setAlignment(Element.ALIGN_LEFT);
			} catch (Exception e) {
			}
			try {
				para0 = new Paragraph("  Member Id : ");
				textUnderline0 = new Chunk(cif);
				Phrase phrase0 = new Phrase();
				phrase0.add(textUnderline0);
				para0.add(phrase0);
				para0.setAlignment(Element.ALIGN_LEFT);
			} catch (Exception e) {
			}

			try {
				para1 = new Paragraph("  Member Name : ");
				textUnderline1 = new Chunk(custName);
				Phrase phrase1 = new Phrase();
				phrase1.add(textUnderline1);
				para1.add(phrase1);
				para1.setAlignment(Element.ALIGN_LEFT);
			} catch (Exception e) {

			}
			try {
				para2 = new Paragraph("  Share Balance : ");
				try {
					textUnderline2 = new Chunk(shareBalance);
				} catch (Exception e) {

				}
				Phrase phrase2 = new Phrase();
				phrase2.add(textUnderline2);
				para2.add(phrase2);
				para2.setAlignment(Element.ALIGN_LEFT);
			} catch (Exception e) {

			}
			try {
				document.add(para0);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				document.add(para1);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				document.add(para2);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Paragraph para = null;
			Chunk textUnderline = null;
			Phrase phrase = null;
			PdfPTable table = null;
			para = new Paragraph("  ");
			textUnderline = new Chunk("Fixed Deposit Details\n\r");
			textUnderline.setUnderline(0.8f, -1f);
			phrase = new Phrase();
			phrase.add(textUnderline);
			para.add(phrase);
			try {
				document.add(para);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			table = new PdfPTable(1); // Create 2 columns in table.
			cell1 = new PdfPCell(new Paragraph("FD Certificate"));
			table.addCell(cell1);
			for (int i = 0; i < fdData.length; i++) {
				String str = fdData[i];
				if (str.equals(""))
					continue;
				try {
					if (!str.equals(""))
						cell2 = new PdfPCell(new Paragraph(str));
				} catch (Exception e) {

				}
				if (cell2 != null)
					table.addCell(cell2);
			}
			table.setSpacingAfter(15f);
			try {
				document.add(table);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			para = new Paragraph("  ");
			textUnderline = new Chunk("Loan Details\n\r");
			textUnderline.setUnderline(0.8f, -1f);
			phrase = new Phrase();
			phrase.add(textUnderline);
			para.add(phrase);
			try {
				document.add(para);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			table = new PdfPTable(6);
			cell1 = new PdfPCell(new Paragraph("Loan Account"));
			cell2 = new PdfPCell(new Paragraph("Loan Bal"));
			cell3 = new PdfPCell(new Paragraph("Share Linked"));
			cell4 = new PdfPCell(new Paragraph("EMI Amount"));
			cell5 = new PdfPCell(new Paragraph("Interest OverDue"));
			cell6 = new PdfPCell(new Paragraph("Penal Int"));
			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			table.addCell(cell6);
			for (int i = 0; i < loanData.length; i++) {
				String str = loanData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("#");
				try {
					if (arr.length >= 1 && !arr[0].equals(""))
						cell7 = new PdfPCell(new Paragraph(arr[0]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 2 && !arr[1].equals(""))
						cell8 = new PdfPCell(new Paragraph(arr[1]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 3 && !arr[2].equals(""))
						cell9 = new PdfPCell(new Paragraph(arr[2]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 4 && !arr[3].equals(""))
						cell10 = new PdfPCell(new Paragraph(arr[3]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 5 && !arr[4].equals(""))
						cell11 = new PdfPCell(new Paragraph(arr[4]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 6 && !arr[5].equals(""))
						cell12 = new PdfPCell(new Paragraph(arr[5]));
				} catch (Exception e) {

				}
				if (cell7 != null)
					table.addCell(cell7);
				if (cell8 != null)
					table.addCell(cell8);
				if (cell9 != null)
					table.addCell(cell9);
				if (cell10 != null)
					table.addCell(cell10);
				if (cell11 != null)
					table.addCell(cell11);
				if (cell12 != null)
					table.addCell(cell12);
			}
			table.setSpacingAfter(15f);
			try {
				document.add(table);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			para = new Paragraph("  ");
			textUnderline = new Chunk("Line Of Credit\n\r");
			textUnderline.setUnderline(0.8f, -1f);
			phrase = new Phrase();
			phrase.add(textUnderline);
			para.add(phrase);
			try {
				document.add(para);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			table = new PdfPTable(5);
			cell1 = new PdfPCell(new Paragraph("LOC Account No."));
			cell2 = new PdfPCell(new Paragraph("Limit Amount"));
			cell3 = new PdfPCell(new Paragraph("Current Balance"));
			cell4 = new PdfPCell(new Paragraph("EMI Amount"));
			cell5 = new PdfPCell(new Paragraph("Status"));
			table.addCell(cell1);
			table.addCell(cell2);
			table.addCell(cell3);
			table.addCell(cell4);
			table.addCell(cell5);
			for (int i = 0; i < locData.length; i++) {
				String str = locData[i];
				if (str.equals(""))
					continue;
				String[] arr = str.split("#");
				try {
					if (arr.length >= 1 && !arr[0].equals(""))
						cell6 = new PdfPCell(new Paragraph(arr[0]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 2 && !arr[1].equals(""))
						cell7 = new PdfPCell(new Paragraph(arr[1]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 3 && !arr[2].equals(""))
						cell8 = new PdfPCell(new Paragraph(arr[2]));
				} catch (Exception e) {

				}
				try {
					if (arr.length >= 4 && !arr[3].equals(""))
						cell9 = new PdfPCell(new Paragraph(arr[3]));
				} catch (Exception e) {

				}
				if (cell6 != null)
					table.addCell(cell6);
				if (cell7 != null)
					table.addCell(cell7);
				if (cell8 != null)
					table.addCell(cell8);
				if (cell9 != null)
					table.addCell(cell9);
			}
			table.setSpacingAfter(15f);
			try {
				document.add(table);
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			document.close();
			byte[] pdfBytes = byteArrayOutputStream.toByteArray();
			List<byte[]> arrays = new ArrayList<byte[]>();
			arrays.add(loanBytes);
			arrays.add(pdfBytes);
			byte[] resultBytes = mergePDF(arrays);
			String base64Str = Base64.getEncoder().encodeToString(resultBytes);
			i$body = new JsonObject();
			i$body.addProperty("I#FileData", base64Str);
			i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, i$body);
		} catch (Exception e) {

		}
		return isonMsg;
	}

	public byte[] mergePDF(List<byte[]> pdfFilesAsByteArray) throws DocumentException, IOException {

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		Document document = null;
		PdfCopy writer = null;

		for (byte[] pdfByteArray : pdfFilesAsByteArray) {

			try {
				PdfReader reader = new PdfReader(pdfByteArray);
				int numberOfPages = reader.getNumberOfPages();

				if (document == null) {
					document = new Document(reader.getPageSizeWithRotation(1));
					writer = new PdfCopy(document, outStream); // new
					document.open();
				}
				PdfImportedPage page;
				for (int i = 0; i < numberOfPages;) {
					++i;
					page = writer.getImportedPage(reader, i);
					writer.addPage(page);
				}
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		}

		document.close();
		outStream.close();
		return outStream.toByteArray();

	}
	// PKY00078 ends
	//#MVT00114 begins
	public JsonObject calculateLoanDetails(JsonObject isonMsg) {
        try {
            int tenure;
            double iRate;
            int time;
            double principle;
            double totalInt = 0;
            double etcIntrest =0.0;
            double iPaid=0, principalPaid = 0, newBalance = 0, totalbal;
            DecimalFormat format = new DecimalFormat("##.##");
            Calendar cal = Calendar.getInstance();
            JsonObject resObject = new JsonObject();
            JsonObject ibody = isonMsg.getAsJsonObject("i-body");
            
            tenure = ibody.get("tenure").getAsInt();
            iRate = ibody.get("iRate").getAsDouble();
            principle = ibody.get("principle").getAsDouble();
            
            int months = tenure;
            String loanDate = ibody.get("loanStartDate").getAsString();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = formatter.parse(loanDate);
            cal.setTime(startDate);
            int date = cal.get(Calendar.DATE);
            int lastday = cal.getActualMaximum(Calendar.DATE);    
    
//         time = tenure*12;
            totalbal = principle;
            iRate = (iRate/100)/12;
            double monthlyEMI= Double.parseDouble(format.format( ((principle * iRate) / (1 - Math.pow(1 + iRate, -tenure)))));
            double totalLoanAmtPaid = (Double.parseDouble(format.format(monthlyEMI))*months);
            ibody.addProperty("TotalLoanAmtPaid",format.format( totalLoanAmtPaid));

//         double totalInterst = (totalLoanAmtPaid - principle)+etcIntrest;
            if(date>15) {
                try {
                	totalLoanAmtPaid = totalLoanAmtPaid + monthlyEMI;
                    ibody.addProperty("TotalLoanAmtPaid",format.format( totalLoanAmtPaid));
                    int addDay = 0;
                    cal.add(Calendar.MONTH, 1);
                    int nextMonthlDays = cal.getActualMaximum(Calendar.DATE);
                    int daydiff = lastday-date+addDay;
                    int n = (nextMonthlDays + daydiff);
                    double addint = (principle*ibody.get("iRate").getAsDouble()*n)/(100*cal.getActualMaximum(Calendar.DAY_OF_YEAR));

                    totalInt= addint;
                    totalLoanAmtPaid = Double.parseDouble(format.format(monthlyEMI - totalInt));                    
                    totalbal = Double.parseDouble(format.format(principle - totalLoanAmtPaid));

                } catch(Exception e) {
                    logger.debug(e.getMessage());
                }
            } else {
            	try {
//            		cal.add(Calendar.MONTH, 1);
                    int nextMonthlDays = cal.getActualMaximum(Calendar.DATE);
                    int n = lastday-date;
//                  int n = daydiff;
                    double addint = (principle*ibody.get("iRate").getAsDouble()*n)/(100*cal.getActualMaximum(Calendar.DAY_OF_YEAR));

                    totalInt= Double.parseDouble(format.format (addint));
                    totalLoanAmtPaid = Double.parseDouble(format.format(monthlyEMI - totalInt));                    
                    totalbal = Double.parseDouble(format.format(principle - totalLoanAmtPaid));
            	} catch(Exception e) {
            		e.getMessage();
            	}
			}
//         tenure = tenure+1;
			int i = 0;
			int month = cal.get(Calendar.MONTH);
			cal.set(Calendar.DAY_OF_MONTH, 1);
			int tempMonth = month + 1;
			int endMonth = tenure + month;
			month++;
			for (int m = month; m <= endMonth; m++) {
//             ++i;
//             cal.add(Calendar.MONTH, i);
//             Date temp = cal.getTime();
//             int daysInMonth = cal.getActualMaximum(Calendar.DATE);
//             iPaid = totalbal * (ibody.get("iRate").getAsDouble()*12) / (100);
				cal.set(Calendar.MONTH, tempMonth);
				cal.set(Calendar.DAY_OF_MONTH, 1);
//             Date firstDay = cal.getTime();
				cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
				int n = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

				iPaid = Double.parseDouble(format.format((totalbal * ibody.get("iRate").getAsDouble() * n)
						/ (100 * cal.getActualMaximum(Calendar.DAY_OF_YEAR))));
				principalPaid = Double.parseDouble(format.format(monthlyEMI - iPaid));
//                newBalance = totalbal - principalPaid;
				newBalance = totalbal + iPaid - monthlyEMI;
				totalbal = Double.parseDouble(format.format(newBalance));
//                totalLoanAmtPaid = totalLoanAmtPaid + principalPaid;

				logger.debug("===========" + iPaid + " " + cal.getTime() + "===========");
				totalInt = totalInt + iPaid;

				if (m % 12 == 0) {
					tempMonth = 1;
				} else {
					tempMonth++;
				}
				if(newBalance<0) {
					break;
				}

//             double montInt = ibody.get("iRate").getAsDouble()/12;
//             iPaid = totalbal * (montInt/ 100);
//             if(m==0) {
//                 iPaid = iPaid + etcIntrest;
//             }
//             double iPaid1 = principle * iRate;
//             if(principalPaid<totalbal) {
//                 newBalance = totalbal + iPaid - monthlyEMI;
//             } else {
//                 newBalance = totalbal;
//             }
//             totalbal = newBalance;
//             totalInt = totalInt + iPaid;        
			}
			ibody.addProperty("MonthlyEMI", format.format(monthlyEMI));
            ibody.addProperty("TotalLoanAmtPaid",format.format(Double.parseDouble(format.format(monthlyEMI))*months));
//			ibody.addProperty("TotalLoanAmtPaid", format.format(principle + totalInt));
			ibody.addProperty("TotalInterst", format.format(totalInt));
			ibody.addProperty("Tenor", tenure);
		} catch (Exception e) {
			e.getMessage();
			return i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "Failed To Calculate Amortization");
		}
		return isonMsg;
    }//#MVT00114 ends
	public JsonObject generateReports(JsonObject isonMsg) throws IOException{
        try {
        	String columns = "";
        	String columnNames = "";
            JsonArray clms = new JsonArray();
            JsonArray names = new JsonArray();
            JsonParser parser = new JsonParser();
            JsonObject sort = new JsonObject();
            JsonObject filter = new JsonObject();
            JsonArray dbData = new JsonArray();
            JsonObject projection = new JsonObject();
            final IPDFTextExtractor pdfReport = new IPDFTextExtractor();
            Gson gson = new GsonBuilder().serializeNulls().create();
            
            sort.addProperty("_id", -1);
            projection.addProperty("_id", 0);
            JsonObject ibody = isonMsg.get("i-body").getAsJsonObject();
            if(I$utils.$iStrFuzzyMatch("CIF_REPORT", ibody.get("ReportType").getAsString())) {
            	try {
                    ibody.addProperty("fileName", "CIF CREATION REPORT");
            		columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName','CifCreationDate']";
                    columnNames = "['Sl.No','Branch Id','Branch Name','Member Id','Member FullName','Creation Date']";
                    
            		projection.addProperty("CustomerId", 1);
                    projection.addProperty("CustomerFullName", 1);
                    projection.addProperty("BranchName", 1);
                    projection.addProperty("CustomerBranch", 1);
                    projection.addProperty("CifCreationDate", 1);                  
            		Date date = new Date(System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000);
                    filter.add("createdDate", parser.parse("{'$gt': " + date.toString() + " }" ).getAsJsonObject());                    
            	} catch(Exception e) {
            		logger.debug(e.getMessage());
            	}
            } else if (I$utils.$iStrFuzzyMatch("Nature_of_Business", ibody.get("ReportType").getAsString())) {
                ibody.addProperty("fileName", "BUSSINESS NATURE REPORT");
                String bussinesType = "['Accountant','Art Dealer','Attorney-at-Law','Gaming House','Jeweller','Money or Value Transfer Service','Motor Vehicle Sales','Pool Betting','Private Members’ Club','Real Estate','Trust and Company Service Provider']";
                columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName','Occupation','CifCreationDate']";
                columnNames = "['Sl.No','Branch Id','Branch Name','Member Id','Member FullName','Occupation','Creation Date']";
                
                JsonArray business = parser.parse(bussinesType).getAsJsonArray();                
                projection.addProperty("CustomerId", 1);
                projection.addProperty("CustomerFullName", 1);
                projection.addProperty("BranchName", 1);
                projection.addProperty("CustomerBranch", 1);
                projection.addProperty("Occupation", 1);
                projection.addProperty("CifCreationDate", 1);                
                filter.add("Occupation", parser.parse("{'$in': " + business.getAsJsonArray() + " }" ).getAsJsonObject());
                
			} else if (I$utils.$iStrFuzzyMatch("SOURCE_OF_INCOME", ibody.get("ReportType").getAsString())) {
				try {
					ibody.addProperty("fileName", "SOURCE OF INCOME REPORT");
					columns = "['Sl.No','CustomerBranch','BranchName','CustomerId','CustomerFullName','Employmenttype','CifCreationDate']";
					columnNames = "['Sl.No','Branch Id','Branch Name','Member Id','Member FullName','Source Of Income','Creation Date']";

					projection.addProperty("CustomerId", 1);
					projection.addProperty("CustomerFullName", 1);
					projection.addProperty("BranchName", 1);
					projection.addProperty("CustomerBranch", 1);
	                projection.addProperty("Employmenttype", 1);
					projection.addProperty("CifCreationDate", 1);
					JsonObject subqry = new JsonObject();
					subqry.addProperty("$ne", "Via Salary");
					filter.add("Employmenttype", subqry);
				} catch (Exception e) {
					logger.debug(e.getMessage());
				}
			}
            
            dbData = db$Ctrl.db$GetRows$Sort("ICOR_M_CBS_CIF_DATA",filter, projection, sort);            
            clms = parser.parse(columns).getAsJsonArray();
            names = parser.parse(columnNames).getAsJsonArray();
            ibody.add("columns", clms);
            ibody.add("rowData", dbData);
            ibody.add("columnNames", names);
            ibody.addProperty("noOfColumns", clms.size());
            i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_BDYTAG, ibody);
            isonMsg = pdfReport.generatePDFReport(isonMsg);
        } catch(Exception e) {
            e.getMessage();
        }
        return isonMsg;
    }
	//#MVT00127 ends
	
	//MSA00024 starts
	public void getRiskPrfReport(JsonArray scanData, String scanId) {
		try {
			Gson gson = new Gson();
			String date = I$utils.$getISONowAm();
			JsonArray finalData = new JsonArray();
			JsonArray lowData = new JsonArray();
			JsonArray mediumData = new JsonArray();
			JsonArray highData = new JsonArray();
			JsonArray headers = new JsonArray();
			for (int i = 0; i < scanData.size(); i++) {
				try {
					JsonObject runningObj = scanData.get(i).getAsJsonObject();
					Set<String> keys = runningObj.keySet();
					for (String key : keys) {
						try {
							if (I$utils.$iStrFuzzyMatch(key, "INDIVIDUAL_WEIGHT")) {
								JsonArray weightArr = runningObj.get(key).getAsJsonArray();
								scanData.get(i).getAsJsonObject().addProperty("Branch Code",
										runningObj.get("CustomerBranch").getAsString());
								scanData.get(i).getAsJsonObject().addProperty("Branch Name",
										runningObj.get("BranchName").getAsString());
								scanData.get(i).getAsJsonObject().addProperty("Member ID",
										runningObj.get("CustomerId").getAsString());
								scanData.get(i).getAsJsonObject().addProperty("Member Name",
										runningObj.get("CustomerFullName").getAsString());
								scanData.get(i).getAsJsonObject().addProperty("Total Risk Score",
										runningObj.get("MODEL_VALUE").getAsString());
								for (int m = 0; m < weightArr.size(); m++) {
									try {
										scanData.get(i).getAsJsonObject().addProperty(String.valueOf(m + 1),
												weightArr.get(m).getAsJsonObject().get("value").getAsDouble());
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
								break;
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					scanData.get(i).getAsJsonObject().remove("INDIVIDUAL_WEIGHT");
					scanData.get(i).getAsJsonObject().remove("CustomerId");
					scanData.get(i).getAsJsonObject().remove("CustomerFullName");
					scanData.get(i).getAsJsonObject().remove("CustomerBranch");
					scanData.get(i).getAsJsonObject().remove("BranchName");
					scanData.get(i).getAsJsonObject().remove("MODEL_VALUE");
					scanData.get(i).getAsJsonObject().remove("ScanType");
					scanData.get(i).getAsJsonObject().remove("MODEL_RATING");
					scanData.get(i).getAsJsonObject().remove("MODEL_COLOR");
					scanData.get(i).getAsJsonObject().remove("CompletedTime");
					scanData.get(i).getAsJsonObject().remove("ScanId");
				} catch (Exception e) {
				}
			}
			for (int i = 0; i < scanData.size(); i++) {
				try {
					if (I$utils.$iStrFuzzyMatch("Low",
							scanData.get(i).getAsJsonObject().get("MODEL_CLASS").getAsString())) {
						lowData.add(scanData.get(i).getAsJsonObject());
					}
					if (I$utils.$iStrFuzzyMatch("High",
							scanData.get(i).getAsJsonObject().get("MODEL_CLASS").getAsString())) {
						highData.add(scanData.get(i).getAsJsonObject());
					}
					if (I$utils.$iStrFuzzyMatch("Medium",
							scanData.get(i).getAsJsonObject().get("MODEL_CLASS").getAsString())) {
						mediumData.add(scanData.get(i).getAsJsonObject());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			JsonObject tempFilter = new JsonObject();
			JsonObject lowDataObj = new JsonObject();
			JsonObject MediumDataObj = new JsonObject();
			JsonObject HighDataObj = new JsonObject();
			lowDataObj.add("Low", lowData);
			MediumDataObj.add("Medium", mediumData);
			HighDataObj.add("High", highData);
			finalData.add(lowDataObj);
			finalData.add(MediumDataObj);
			finalData.add(HighDataObj);
			//SKG00039 starts
			JsonObject head = new JsonObject();
			head.addProperty("Branch Code", 1);
			head.addProperty("Branch Name", 2);
			head.addProperty("Member ID", 3);
			head.addProperty("Member Name", 4);
			head.addProperty("Total Risk Score", 5);
			headers.add(head);
			//SKG00039 end
			for (int i = 0; i < finalData.size(); i++) {
				try {
					JsonObject currObject = new JsonObject();
					JsonObject updateObj = new JsonObject();
					JsonObject runningData = finalData.get(i).getAsJsonObject();
					JsonArray runningArr = new JsonArray();
					Set<String> keys = runningData.keySet();
					for (String key : keys) {     //SRI00043 changes  starts
						try {
							runningArr = runningData.get(key).getAsJsonArray();
							if (runningArr.size() <= 0) {
								tempFilter.addProperty("ScanId", scanId);
								tempFilter.addProperty("ReportType",
										"List of Members whose current KYM Risk Rating is '" + key + "'");
								updateObj.addProperty("ReportType",
										"List of Members whose current KYM Risk Rating is '" + key + "'");
								updateObj.addProperty("fileName", "List of Members whose current KYM Risk Rating is '"
										+ key + "'_" + date + ".pdf");
								currObject.add("$each", runningArr);
								updateObj.add("headers", headers);// SKG00039 changes
								updateObj.addProperty("ScanId", scanId);
								updateObj.addProperty("CreatedAt",
										new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
												.format(Calendar.getInstance().getTime()));
							} else {
								for (int s = 0; s < runningArr.size(); s++) {
									try {
										JsonObject runningObj = runningArr.get(s).getAsJsonObject();
										for (int t = 0; t < 1; t++) {
											try {
												tempFilter.addProperty("ScanId", scanId);
												updateObj.addProperty("ScanId", scanId);
												updateObj.addProperty("CreatedAt",
														new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH)
																.format(Calendar.getInstance().getTime()));

												if (I$utils.$iStrFuzzyMatch("Low",
														runningObj.get("MODEL_CLASS").getAsString())) {
													for (int j = 0; j < runningArr.size(); j++) {
														try {
															runningArr.get(j).getAsJsonObject().remove("MODEL_CLASS");
														} catch (Exception e) {
															e.printStackTrace();
														}
													}
													currObject.add("$each", runningArr);
													updateObj.addProperty("fileName",
															"List of Members whose current KYM Risk Rating is 'Low'_"
																	+ date + ".pdf");
													updateObj.addProperty("ReportType",
															"List of Members whose current KYM Risk Rating is 'Low'");
													tempFilter.addProperty("ReportType",
															"List of Members whose current KYM Risk Rating is 'Low'");
												} else if (I$utils.$iStrFuzzyMatch("High",
														runningObj.get("MODEL_CLASS").getAsString())) {
													for (int j = 0; j < runningArr.size(); j++) {
														try {
															runningArr.get(j).getAsJsonObject().remove("MODEL_CLASS");
														} catch (Exception e) {
															e.printStackTrace();
														}
													}
													currObject.add("$each", runningArr);
													updateObj.addProperty("fileName",
															"List of Members whose current KYM Risk Rating is 'High'_"
																	+ date + ".pdf");
													updateObj.addProperty("ReportType",
															"List of Members whose current KYM Risk Rating is 'High'");
													tempFilter.addProperty("ReportType",
															"List of Members whose current KYM Risk Rating is 'High'");
												} else if (I$utils.$iStrFuzzyMatch("Medium",
														runningObj.get("MODEL_CLASS").getAsString())) {
													for (int j = 0; j < runningArr.size(); j++) {
														try {
															runningArr.get(j).getAsJsonObject().remove("MODEL_CLASS");
														} catch (Exception e) {
															e.printStackTrace();
														}
													}
													currObject.add("$each", runningArr);
													updateObj.addProperty("fileName",
															"List of Members whose current KYM Risk Rating is 'Medium'_"
																	+ date + ".pdf");
													updateObj.addProperty("ReportType",
															"List of Members whose current KYM Risk Rating is 'Medium'");
													tempFilter.addProperty("ReportType",
															"List of Members whose current KYM Risk Rating is 'Medium'");
												}
											} catch (Exception e) {
												e.printStackTrace();
											}
										}
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}											
					}																				//SRI00043 changes Ends
					db$Ctrl.db$UpdateRow("ICOR_M_RISK_REPORT", updateObj, tempFilter, "true");
					JsonObject CustomerIdObj1 = new JsonObject();
					CustomerIdObj1.add("reportResults", currObject);
					String i$CustomerIdDoc = gson.toJson(CustomerIdObj1);
					updateObj.add("headers", headers);//SKG00039 chnages
					db$Ctrl.db$UpdateRowOperator("ICOR_M_RISK_REPORT", i$CustomerIdDoc, tempFilter, "true", "push");
				} catch (Exception e) {
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}//MSA00024 ends
	// MSA00025 starts
	public synchronized void getWhite$BlackMemTypeReport(JsonObject isonMsg) {
		try {
			String scanId = isonMsg.get("scanId").getAsString();
			String date1 = I$utils.$getISONowAm();
			JsonObject filter1 = new JsonObject();
			filter1.addProperty("privateKey", "SIRMASIRMASIRMAS");
			int date = 0;
			int month = 0;
			int year = 0;
			try {
				Calendar calendar = Calendar.getInstance();
				date = calendar.get(Calendar.DATE);
				month = calendar.get(Calendar.MONTH) + 1;
				year = calendar.get(Calendar.YEAR);
			} catch (Exception e) {

			}
			JsonObject $Data = db$Ctrl.db$GetRow("ICOR_C_PARAM", filter1);
			JsonObject i$Datas = $Data.get("monthlyReportValidationParams").getAsJsonObject();

			// MSA00004 starts
			if ((month == 1 && date == i$Datas.get("Jan").getAsInt()) || (month == 2 && date == i$Datas.get("Feb").getAsInt()) || (month == 3 && date == i$Datas.get("Mar").getAsInt()) || (month == 5 && date == i$Datas.get("May").getAsInt()) || (month == 7 && date == i$Datas.get("Jul").getAsInt()) || (month == 8 && date == i$Datas.get("Aug").getAsInt()) || (month == 10 && date == i$Datas.get("Oct").getAsInt()) || (month == 12 && date == i$Datas.get("Dec").getAsInt()) || (month == 4 && date == i$Datas.get("Apr").getAsInt()) || (month == 6 && date == i$Datas.get("Jun").getAsInt()) || (month == 9 && date == i$Datas.get("Sept").getAsInt()) || (month == 11 && date == i$Datas.get("Nov").getAsInt())) {
				JsonArray dbDataWhiteList = new JsonArray();
				JsonArray dbDataBlackList = new JsonArray();
				JsonObject projection = new JsonObject();
				JsonObject sort = new JsonObject();
				JsonArray filterArr = new JsonArray();
				JsonArray headers = new JsonArray();//SKG00039 chnages

				JsonObject finalFltr = new JsonObject();
				JsonObject monthFltr = new JsonObject();
				Date grtrDate = I$utils.changeTodaysDate(date, "SUB", "D");
				Date lsrDate = I$utils.changeTodaysDate(0, "SUB", "D");
				String grtrDateS = I$utils.changeDateFormat(grtrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
				String lsrDateS = I$utils.changeDateFormat(lsrDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
				JsonObject iso$date = Ioutils.dateFromatter(grtrDateS);
				JsonObject temp = new JsonObject();
				temp.add("$gt", iso$date);
				monthFltr.add("authorizedOnSrvDate", temp);
				filterArr.add(monthFltr);
				temp = new JsonObject();
				monthFltr = new JsonObject();
				iso$date = Ioutils.dateFromatter(lsrDateS);
				temp.add("$lte", iso$date);
				monthFltr.add("authorizedOnSrvDate", temp);
				filterArr.add(monthFltr);
				finalFltr.add("$and", filterArr);

				sort.addProperty("_id", -1);
				projection.addProperty("_id", 0);
				projection.addProperty("customerId", 1);
				projection.addProperty("customerName", 1);
//				projection.addProperty("financialCycle", 1);
//				projection.addProperty("financialCycleTo", 1);
				projection.addProperty("reason", 1);
				projection.addProperty("whiteStartDate", 1);
				projection.addProperty("whiteEndDate", 1);
				projection.addProperty("blackStartDate", 1);
				projection.addProperty("blackEndDate", 1);
				dbDataWhiteList = db$Ctrl.db$GetRows$Sort("ICOR_M_B2U_WHITELISTED_CUSTOMER", finalFltr, projection,sort);
				dbDataBlackList = db$Ctrl.db$GetRows$Sort("ICOR_M_BLACK_LIST", finalFltr, projection, sort);
				//SKG00039 starts
				JsonObject head = new JsonObject();
				head.addProperty("Member ID", 1);
				head.addProperty("Member Name", 2);
				head.addProperty("From Date", 3);
				head.addProperty("To Date", 4);
				head.addProperty("Reason", 5);
				head.addProperty("Branch Code", 6);
				head.addProperty("Branch Name", 7);
				headers.add(head);
				//SKG00039 end
				JsonArray finalInsertobj = new JsonArray();
				if(dbDataWhiteList.size()<=0) {
					JsonObject whitelstMem = new JsonObject();
					whitelstMem.addProperty("ReportType", "List of Whitelisted Members");
					whitelstMem.addProperty("fileName", "List of Whitelisted Members_" + date1 + ".pdf");
					whitelstMem.add("reportResults", dbDataWhiteList);
					whitelstMem.add("headers", headers);//SKG00039 changes
					whitelstMem.addProperty("ScanId", scanId);
					whitelstMem.addProperty("CreatedAt",new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
					finalInsertobj.add(whitelstMem);
				}
				if(dbDataBlackList.size()<=0) {
					JsonObject blacklstMem = new JsonObject();
					blacklstMem.addProperty("ReportType", "List of Blacklisted Members");
					blacklstMem.addProperty("fileName", "List of Blacklisted Members_" + date1 + ".pdf");
					blacklstMem.add("reportResults", dbDataBlackList);
					blacklstMem.add("headers", headers);//SKG00039 chnages
					blacklstMem.addProperty("ScanId", scanId);
					blacklstMem.addProperty("CreatedAt",new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
					finalInsertobj.add(blacklstMem);
				}
				
				JsonArray finalData = new JsonArray();
				finalData.add(dbDataWhiteList);
				finalData.add(dbDataBlackList);
				for (int i = 0; i < finalData.size(); i++) {
					try {
						JsonArray updateObjs = new JsonArray();
						JsonObject update$Obj = new JsonObject();
						JsonArray currentData = finalData.get(i).getAsJsonArray();
						if(currentData.size() > 0) {
							for (int j = 0; j < currentData.size(); j++) {
								try {
									if (currentData.get(j).getAsJsonObject().has("whiteStartDate") && currentData.get(j).getAsJsonObject().has("whiteEndDate")) {
										try {
										currentData.get(j).getAsJsonObject().addProperty("Member ID", currentData.get(j).getAsJsonObject().get("customerId").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("Member Name", currentData.get(j).getAsJsonObject().get("customerName").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("From Date", currentData.get(j).getAsJsonObject().get("whiteStartDate").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("To Date", currentData.get(j).getAsJsonObject().get("whiteEndDate").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("Reason", currentData.get(j).getAsJsonObject().get("reason").getAsString());
										currentData.get(j).getAsJsonObject().remove("reason");
										currentData.get(j).getAsJsonObject().remove("whiteStartDate");
										currentData.get(j).getAsJsonObject().remove("whiteEndDate");
										currentData.get(j).getAsJsonObject().remove("customerId");
										currentData.get(j).getAsJsonObject().remove("customerName");
										update$Obj.addProperty("ReportType", "List of Whitelisted Members");
										update$Obj.addProperty("fileName", "List of Whitelisted Members_" + date1 + ".pdf");
									}catch(Exception e) {
										e.printStackTrace();
									}
										
									} 
									else if (currentData.get(j).getAsJsonObject().has("blackStartDate") && currentData.get(j).getAsJsonObject().has("blackEndDate")) {
										try {
										currentData.get(j).getAsJsonObject().addProperty("Member ID", currentData.get(j).getAsJsonObject().get("customerId").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("Member Name", currentData.get(j).getAsJsonObject().get("customerName").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("From Date", currentData.get(j).getAsJsonObject().get("blackStartDate").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("To Date", currentData.get(j).getAsJsonObject().get("blackEndDate").getAsString());
										currentData.get(j).getAsJsonObject().addProperty("Reason", currentData.get(j).getAsJsonObject().get("reason").getAsString());
										currentData.get(j).getAsJsonObject().remove("reason");
										currentData.get(j).getAsJsonObject().remove("blackStartDate");
										currentData.get(j).getAsJsonObject().remove("blackEndDate");
										currentData.get(j).getAsJsonObject().remove("customerId");
										currentData.get(j).getAsJsonObject().remove("customerName");
										update$Obj.addProperty("ReportType", "List of Blacklisted Members");
										update$Obj.addProperty("fileName", "List of Blacklisted Members_" + date1 + ".pdf");
									}catch(Exception e) {
										e.printStackTrace();
									}
										
									}
									JsonObject ciffilter = new JsonObject();
									JsonObject proj = new JsonObject();
									proj.addProperty("CustomerBranch", 1);
									proj.addProperty("BranchName", 1);
									ciffilter.addProperty("CustomerId",currentData.get(j).getAsJsonObject().get("Member ID").getAsString());
									JsonObject dbRes = db$Ctrl.db$GetRow("ICOR_M_CBS_CIF_DATA", ciffilter, proj);
									currentData.get(j).getAsJsonObject().addProperty("Branch Code",dbRes.get("CustomerBranch").getAsString());
									currentData.get(j).getAsJsonObject().addProperty("Branch Name",dbRes.get("BranchName").getAsString());
									update$Obj.add("reportResults", currentData);
									JsonObject reportResult = new JsonObject();
									reportResult.add("reportResult", currentData);
									updateObjs.add(reportResult);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							update$Obj.addProperty("ScanId", scanId);
							update$Obj.addProperty("CreatedAt",new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).format(Calendar.getInstance().getTime()));
							update$Obj.addProperty("Status","WIP");
							update$Obj.addProperty("financialYear", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "financialYear", ""));   //SRI00017 Changes
							update$Obj.addProperty("periodCode", imbpm.fecthValueFormJson(IKYCController.pCode$fYear(), "periodCode", ""));			//SRI00017 Changes 
							finalInsertobj.add(update$Obj);
						}
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				db$Ctrl.db$InsertMany("ICOR_M_RISK_REPORT", finalInsertobj);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}// MSA00025 ends
	//MSA00010 starts
	class HeaderFooterPageEvent extends PdfPageEventHelper {
		public void onEndPage(PdfWriter writer, Document document) {
			int n = document.getPageNumber();
			if (n > 0) {
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER,new Phrase("page " + writer.getPageNumber()), 550, 30, 0);
			}
		}

		public void onStartPage(PdfWriter writer, Document document) {
			int n = document.getPageNumber();
			if (n > 1) {
				Font font = new Font(FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.BLACK);
				Chunk reportTitle = new Chunk("Yearly ID Document Check Report");
				reportTitle.setFont(font);
				reportTitle.setUnderline(0.9f, -1f);
				Phrase phrase = new Phrase();
				phrase.add(reportTitle);
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, phrase, 300, 750, 0);
			}
		}

	}
	//MSA00010 ends
	
	//MSA00011 starts
	class HeaderFooterPageEvent2 extends PdfPageEventHelper {
		public void onStartPage(PdfWriter writer, Document document) {
			try {
				int pageNo = writer.getPageNumber();
				Image headerImg = null;
				RenderedImage renderedImage = null;
				ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
				if (pageNo >= 1) {
					try {
						renderedImage = generateImage("header");
						ImageIO.write(renderedImage, "jpg", byteImg);
						byte[] byteArr = byteImg.toByteArray();
						headerImg = Image.getInstance(byteArr);
//						headerImg.setAbsolutePosition(150, 700);
						headerImg.setAbsolutePosition(220, 500);//PAV00033 Changes
						headerImg.scaleAbsolute(350, 80);
						writer.getDirectContent().addImage(headerImg);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} catch (Exception e) {
			}
		}
	}
	class HeaderFooterPageEvent2i extends PdfPageEventHelper {
		public void onEndPage(PdfWriter writer, Document document) {
			try {
				int pageNo = writer.getPageNumber();
				Image footerImg = null;
				RenderedImage renderedImage = null;
				ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
				if (pageNo >= 1) {
					try {
						renderedImage = generateImage("footer");
						ImageIO.write(renderedImage, "jpg", byteImg);
						byte[] byteArr = byteImg.toByteArray();
						footerImg = Image.getInstance(byteArr);
						footerImg.setAbsolutePosition(150, 10);
						writer.getDirectContent().addImage(footerImg);
					} catch (Exception e) {
						e.printStackTrace();
					}

				}
			} catch (Exception e) {
			}
		}
	}
	//MSA00019 starts
	public class HeaderFooterPageEvent3 extends PdfPageEventHelper {
		public void onStartPage(PdfWriter writer, Document document) {
			try {
				int pageNo = writer.getPageNumber();
				Image headerImg = null;
				RenderedImage renderedImage = null;
				ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
				if (pageNo >= 1) {
					try {
						renderedImage = generateImage("Quarterly_Header");
						ImageIO.write(renderedImage, "jpg", byteImg);
						byte[] byteArr = byteImg.toByteArray();
						headerImg = Image.getInstance(byteArr);
						headerImg.setAbsolutePosition(20, 670);
						writer.getDirectContent().addImage(headerImg);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} catch (Exception e) {
			}
		}
		
		public void onEndPage(PdfWriter writer, Document document) {
			try {
				int pageNo = writer.getPageNumber();
				Image footerImg = null;
				RenderedImage renderedImage = null;

				ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
				if (pageNo >= 1) {
					try {

						float pdfPageWidth = 600;
						float pdfPageHeight = 700;
						renderedImage = generateImage("Quarterly_WaterMark");
						ImageIO.write(renderedImage, "jpg", byteImg);
						byte[] byteArr = byteImg.toByteArray();
						footerImg = Image.getInstance(byteArr);
//						footerImg.setAbsolutePosition(20, 500);
						writer.getDirectContentUnder().addImage(footerImg, pdfPageWidth, 0, 0, pdfPageHeight, 0, 0);

					} catch (Exception e) {
						e.printStackTrace();
					}

				}
			} catch (Exception e) {
			}
		}
	}//MSA00019 ends
	//MSA00031 starts
	public class HeaderFooterPageEvent5 extends PdfPageEventHelper {
		public void onStartPage(PdfWriter writer, Document document) {
			try {
				String base64 = "";
				JsonObject jFilter = new JsonObject();
				jFilter.addProperty("pdfId", "STMT001");
				jFilter.addProperty("active", "A");

				JsonObject pdfHelper = new JsonObject();
				pdfHelper = db$Ctrl.db$GetRow("ICOR_M_PDF_TEMPLATE", jFilter);
				base64 = pdfHelper.get("template").getAsString();
				
//				String content = new String(Files.readAllBytes(Paths.get("/home/madhura/Desktop/Base64.txt")));

				PdfContentByte cb = writer.getDirectContent();
				byte[] byteArrr = java.util.Base64.getDecoder().decode(base64);
				PdfReader reader = new PdfReader(byteArrr);
				PdfImportedPage page = writer.getImportedPage(reader, 1);
				cb.addTemplate(page, 0, 0);
				
			} catch (Exception e) {
			}
		}
	}//MSA00031 ends
	//MSA00036 starts
	public class HeaderFooterPageEvent6 extends PdfPageEventHelper {
		public void onStartPage(PdfWriter writer, Document document) {
			try {
				String base64 = "";
				JsonObject jFilter = new JsonObject();
				jFilter.addProperty("pdfId", "STMT002");
				jFilter.addProperty("active", "A");

				JsonObject pdfHelper = new JsonObject();
				pdfHelper = db$Ctrl.db$GetRow("ICOR_M_PDF_TEMPLATE", jFilter);
				base64 = pdfHelper.get("template").getAsString();

				PdfContentByte cb = writer.getDirectContent();
				byte[] byteArrr = java.util.Base64.getDecoder().decode(base64);
				PdfReader reader = new PdfReader(byteArrr);
				PdfImportedPage page = writer.getImportedPage(reader, 1);
				cb.addTemplate(page, 0, 0);
				
			} catch (Exception e) {
			}
		}
		public void onEndPage(PdfWriter writer, Document document) {
			int n = document.getPageNumber();
			String uniqueId = i$ResM.getGobalValStr("uniqueId");
			if (n > 0) {
				try {
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, new Phrase(uniqueId),
							550, 10, 0);
					//MSA00040 starts
//					byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
//					BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
//					ImageIO.write(img, "jpg", byteImgL);
//					byte[] byteArrL = byteImgL.toByteArray();
//					footerImgL = Image.getInstance(byteArrL);
//					writer.getDirectContentUnder().addImage(footerImgL, pdfPageWidthL, 0, 0, pdfPageHeightL, 20, 144);
					//MSA00040 ends
					} catch (Exception e) {
						e.printStackTrace();
				}
			}
		}
	}//MSA00036 ends
	
	public class HeaderFooterPageEvent7 extends PdfPageEventHelper {
		public void onStartPage(PdfWriter writer, Document document) {
			try {
				int n = document.getPageNumber();
				RenderedImage renderedImage = null;
				ByteArrayOutputStream byteImg = new ByteArrayOutputStream();
				Image footerImg = null;
				if (n > 0) {
					try {
						float pdfPageWidth = 600;
						float pdfPageHeight = 700;
						renderedImage = generateImage("Letter_WaterMark");
						ImageIO.write(renderedImage, "jpg", byteImg);
						byte[] byteArr = byteImg.toByteArray();
						footerImg = Image.getInstance(byteArr);
						writer.getDirectContentUnder().addImage(footerImg, pdfPageWidth, 0, 0, pdfPageHeight, 0, 0);

					} catch (Exception e) {
						e.printStackTrace();
					}
				}} catch (Exception e) {
			}
		}
	}
	
	public RenderedImage generateImage(String imageLocation) throws IOException {
		RenderedImage renderedImage = null;
		try {
			if (I$Ioutils.$iStrFuzzyMatch(imageLocation, "header")) {
//				ClassLoader classLoader = getClass().getClassLoader();
				try {
					File file = new ClassPathResource("Embassy-Letter-header.jpg").getFile();
					renderedImage = javax.imageio.ImageIO.read(file);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (I$Ioutils.$iStrFuzzyMatch(imageLocation, "footer")) {
				File file = new ClassPathResource("Embassy-Letter-footer.jpg").getFile();
				renderedImage = javax.imageio.ImageIO.read(file);
			}//MSA00019 starts
			else if (I$Ioutils.$iStrFuzzyMatch(imageLocation, "Quarterly_Header")) {
				File file = new ClassPathResource("Quarterly_Header.jpg").getFile();
				renderedImage = javax.imageio.ImageIO.read(file);
			}
			else if (I$Ioutils.$iStrFuzzyMatch(imageLocation, "Quarterly_WaterMark")) {
				File file = new ClassPathResource("Quarterly_WaterMark.jpg").getFile();
				renderedImage = javax.imageio.ImageIO.read(file);
			}//MSA00019 ends
			else if (I$Ioutils.$iStrFuzzyMatch(imageLocation, "Letter_WaterMark")) {
				File file = new ClassPathResource("Letter_WaterMark.jpg").getFile();
				renderedImage = javax.imageio.ImageIO.read(file);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return renderedImage;
	}//MSA00011 ends

};