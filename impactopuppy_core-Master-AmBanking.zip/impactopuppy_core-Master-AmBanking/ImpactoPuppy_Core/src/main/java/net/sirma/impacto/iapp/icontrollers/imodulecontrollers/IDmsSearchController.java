/*
      Good Faith Statement & Confidentiality : The below code is part of IMPACTO Suite of products . 
      Sirma Business Consulting India reserves all rights to this code . No part of this code should 
      be copied, stored or transmitted in any form for whatsoever reason without prior written consent 
      of Sirma Business Consulting (India).Employees or developers who have access to this code shall 
      take all reasonable precautions to protect the source code and documentation, and preserve its
      confidential, proprietary and trade secret status in perpetuity.Any breach of the obligations 
      to protect confidentiality of IMPACTO may cause immediate and irreparable harm to Sirma Business 
      Consulting, which cannot be adequately compensated by monetary damages. Accordingly, any breach 
      or threatened breach of confidentiality shall entitle Sirma Business Consulting to seek preliminary
      and permanent injunctive relief in addition to such remedies as may otherwise be available.
 
      //But by the grace of God We are what we are, and his grace to us was not without effect. No, 
      //We worked harder than all of them--yet not We, but the grace of God that was with us.
      ----------------------------------------------------------------------------------------------
      |Version No  | Changed by | Date         | Change Tag  | Changes Done
      ----------------------------------------------------------------------------------------------    
      |0.4 Beta    | Pruthvi  	| JuL 09, 2020 | #YPR00096   | Initial Writing
      |0.4 Beta    | Pruthvi  	| JuL 09, 2020 | #YPR00096   | Added Custom File Search options in DMS
      |0.4 Beta    | Tarun  	| JuL 12, 2020 | #TKS00005   | Added code for mapping fields
      |0.4 Beta    | Tarun  	| Sep 01, 2022 | #TKS00015   | Added code to add projection for the doc search
      |0.5 Beta    | karthik    | Nov 29, 2023 | #NK00067    | Added code for workspace filter
      ----------------------------------------------------------------------------------------------
*/
package net.sirma.impacto.iapp.icontrollers.imodulecontrollers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import net.sirma.impacto.iapp.icontrollers.idbcontollers.DBController;
import net.sirma.impacto.iapp.icontrollers.isentrycontroller.SentryGuardController;
import net.sirma.impacto.iapp.ihelpers.IResManipulator;
import net.sirma.impacto.iapp.ihelpers.IResPreFlightHandler;
import net.sirma.impacto.iapp.iutils.ImpactoUtil;
import net.sirma.impacto.iapp.iutils.Ioutils;

public class IDmsSearchController {
	// *******************REQ*FOR*MOST*CONTROLLER*OPERS***********************//

	// @Autowired
	private DBController db$Ctrl = new DBController();
	private Ioutils I$utils = new Ioutils();
	private IResManipulator i$ResM = new IResManipulator();
	private Logger logger = LoggerFactory.getLogger(IDmsSearchController.class);
//	private IReqManipulator i$ReqM = new IReqManipulator(); // #BVB00033

	// **********************************************************************//
	private SentryGuardController Sentry$Controller = new SentryGuardController();
	private JsonObject i$Annotate = null;
//	private ISeqConsistencyController i$seqConsCtrl = new ISeqConsistencyController();
	private ImpactoUtil I$impactoUtil = new ImpactoUtil();

	@SuppressWarnings({ "unused", "null" })
	public JsonObject processMsgHandler(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		JsonObject i$body = null;
		String Coll_Name, L_Coll_Name;
		Gson gson = new GsonBuilder().serializeNulls().create();
		JsonObject projection = new JsonObject();

		JsonObject i$Match = i$ResM.getMatch(isonMsg);
		JsonArray i$ProjectionArray = i$ResM.getProjection(isonMsg);
		JsonObject i$Projection = new JsonObject();
		JsonParser parser = new JsonParser();

		String SOpr = i$ResM.getOpr(isonMsg);
		String ScrId = i$ResM.getScreenID(isonMsg);

		try {
			// #BVB00019 Starts
			boolean hasRights = false;
			if (!I$utils.$iStrFuzzyMatch(ScrId.substring(0, 1), "L"))
				hasRights = db$Ctrl.db$hasRights(IResManipulator.iloggedUser.get(), ScrId, SOpr);
			else
				hasRights = true;

			//  #YPR00096 starts only for File search and rebuild with datasetfilter
			// Summary
			if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
				JsonArray dataFilter = new JsonArray();
				JsonObject dataSetFltr = isonMsg.get("i-body").getAsJsonObject().get("dataSetFltr").getAsJsonObject();
				dataFilter = dataSetFltr.get("data").getAsJsonArray();
				for(int i = 0 ; i < dataFilter.size(); i++) {
					JsonObject i$running = new JsonObject();
					i$running = dataFilter.get(i).getAsJsonObject();
					String iField = i$running.get("iField").getAsString();
					if(I$utils.$iStrFuzzyMatch(iField, "FileUrlToken")) {
						iField = "metadata.FileUrlToken";
					}else if(I$utils.$iStrFuzzyMatch(iField, "FileName")) {
						iField = "metadata.FileName";
					}else if(I$utils.$iStrFuzzyMatch(iField, "LinkedCustNo")) {
						iField = "metadata.LinkedCustNo";
					}else if(I$utils.$iStrFuzzyMatch(iField, "initiator")) {
						iField = "metadata.initiator";
					}else if(I$utils.$iStrFuzzyMatch(iField, "FileExtn")) {
						iField = "metadata.FileExtn";
					}else if(I$utils.$iStrFuzzyMatch(iField, "FileSize")) {
						iField = "metadata.FileSize";
					}else if(I$utils.$iStrFuzzyMatch(iField, "tags")) {
						iField = "metadata.tags";
					}else if(I$utils.$iStrFuzzyMatch(iField, "createdOn")) {
						iField = "metadata.UpldSvrDateTime";
					}else if(I$utils.$iStrFuzzyMatch(iField, "verNo")) {
						iField = "metadata.verNo";
					}
					 String str = isonMsg.get("i-body").getAsJsonObject().get("dataSetFltr").getAsJsonObject().get("data")
					.getAsJsonArray().get(i).getAsJsonObject().get("iField").getAsString();
					 
					 String replaced = str.replace(str , iField);
					 isonMsg.get("i-body").getAsJsonObject().get("dataSetFltr").getAsJsonObject().get("data")
						.getAsJsonArray().get(i).getAsJsonObject().addProperty("iField", replaced);
					
				}

				JsonObject j$DataFilter = get$FrmDataSetFilter(isonMsg);
				if ((j$DataFilter != null) && (j$DataFilter.has("Invalid$Expr"))) {

					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
							j$DataFilter.get("Invalid$Expr").getAsString());
					return isonMsg;
				}
				// #NYE00015 Begin
				else if (j$DataFilter != null) {
					// Get Formated I-MATCH Dataset Filter
					i$Match = j$DataFilter;
				}
				// #NYE00015 End
			}
			if (hasRights) {
				// #BVB00016 Starts
				if (i$ProjectionArray != null) {
					for (int i = 0; i < i$ProjectionArray.size(); i++) {
						i$Projection.addProperty(i$ProjectionArray.get(i).getAsString(), 1);
					}
				} else {

					JsonArray i$ProjectionMap = i$ResM.getIProjection(isonMapJson);
					if (i$ProjectionMap != null) {// #BVB00033
						try {
							if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
								for (int i = 0; i < i$ProjectionMap.size(); i++) {
									i$Projection.addProperty(i$ProjectionMap.get(i).getAsString(), 1);
								}
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, i$Projection);
							} else {
								i$Projection = null;
								i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
							}
						} catch (Exception e) {
							e.printStackTrace();
							i$Projection = null;
							i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
						}
						;
						// #BVB00033 Starts
					} else {
						i$Projection = null;
						i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, i$ResM.I_PROJECTION, "{}");
					}
					// #BVB00033 Ends
					// i$Projection = new JsonObject();
				}
				// #BVB00016 Ends
				// #BVB00035 Starts
				projection = new JsonObject();
				projection.addProperty("privateKey", 1);
				JsonObject cParam = db$Ctrl.db$GetRow("ICOR_C_PARAM", "{}", gson.toJson(projection));
				String privateKey = cParam.get("privateKey").getAsString();
				JsonObject filter = new JsonObject();
				filter.addProperty("sessoinId", i$ResM.getClientSessionID(isonMsg));
				JsonObject sessionValidator = db$Ctrl.db$GetRow("ICOR_S_SESSION_VALIDATOR", gson.toJson(filter),
						gson.toJson(projection));

				// #BVB00035 Ends

				Integer i$MaxRow = -1;
				// #BVB00005 Starts
				JsonObject i$recordDetails = new JsonObject();
				JsonObject i$validateRes = new JsonObject();
				JsonObject i$ledgerCurVer = new JsonObject();
				// #BVB00005 Ends
				try {
					i$MaxRow = isonMsg.get("i-MaxRows").getAsInt();
				} catch (Exception e) {
					try {
						i$MaxRow = isonMapJson.get("MaxRows").getAsInt();
					} catch (Exception ex) {
						i$MaxRow = -1;
					}
					;
				}
				;

				try {
					Coll_Name = isonMapJson.get("COLLNAME").getAsString();
				} catch (Exception e) {
					Coll_Name = null;
				}
				;

				if (!(I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) && (i$Match == null)
						|| (I$utils.$iStrBlank(gson.toJson(i$Match)))) { // #MAQ00003
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN MATCH ANNOTATE");
					return isonMsg;
				}
				;

				try {
					L_Coll_Name = isonMapJson.get("L_COLLNAME").getAsString();
				} catch (Exception e) {
					L_Coll_Name = null;
				}
				;

				if (I$utils.$iStrBlank(Coll_Name) || I$utils.$iStrBlank(L_Coll_Name)) {
					Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN METHOD TAB ANNOTATE");
					return isonMsg;
				}
				;

				try {
					// String ScrID = i$ResM.getScreenID(isonMsg); // #BVB00035
					String SOpr1 = i$ResM.getOpr1(isonMsg);
					String SOpr2 = i$ResM.getOpr2(isonMsg);
					String SOpr3 = i$ResM.getOpr3(isonMsg);
					// #MAQ00002 start
					try {
						i$body = isonMsg.getAsJsonObject("i-body");
					} catch (Exception e) {
						i$body = null;
					}
					// #MAQ00002 end

					if (!I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						i$Annotate = db$Ctrl.db$GetRow("ICOR_C_WEB_VALIDATOR",
								"{\"ANNOTATION\":\"" + ScrId + "_" + SOpr + "\"}"); // #BVB00035 changes ScrID to ScrId
						if (i$Annotate == null) {
							Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
									"INVALID OR UNKNOWN METHOD ANNOTATE");
							return isonMsg;
						}
						;

					} else if (I$utils.$iStrFuzzyMatch(SOpr, "SUMMARY")) {
						// Forwarding Request to DB Handler for SUMMARY
						logger.debug("Forwarding Request to DB Controller for Summary");
						// #MAQ00002 start
						isonMsg.add("i-body", i$body);
						int intPgNo, intRecs;
						try {
							intPgNo = i$body.get("intPgNo").getAsInt();
						} catch (Exception e) {
							intPgNo = 0;
						}
						try {
							intRecs = i$body.get("intRecs").getAsInt();
						} catch (Exception e) {
							intRecs = 0;
						}
						// #MAQ00013 starts
						String sort = "";
						try {
							String sortField = i$body.get("sort").getAsString();
							sort = "{'" + sortField + "':1}";
						} catch (Exception e) {
							sort = "{'_id':-1}";
						}
						// #MAQ00013 starts

						// #MAQ00004 starts
						if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_COUNT")) {

							// #MAQ00009 starts
							int iRowCnt = 0;
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									if (i$Match != null) {
										i$Match.addProperty("isCurrVer", "Y");
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
									}
									// Added
									// Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, "{\"isCurrVer\"=\"Y\"}"); // #BVB00016

								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null)
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
									// Added Projection
									else
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends
							// #MAQ00014 starts
						} else if (I$utils.$iStrFuzzyMatch(SOpr2, "GET_PAG")) {
							// #MAQ00009 starts
							int iRowCnt = 0;
							JsonObject db$res = null;

							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", "{}");
							try {
								if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
									JsonArray accWsArr = db$Ctrl.db$getDMSAccessWS();
									if (i$Match != null) {
										//#NK00067 starts
										i$Match.addProperty("metadata.isCurrVer", "Y");
										try {
											i$Match.addProperty("metadata.workspaceId", i$body.get("workspaceId").getAsString());
										} catch (Exception e) {
											i$Match.add("metadata.workspaceId",parser.parse("{'$in':" + accWsArr + "}").getAsJsonObject());
										} // #NK00067 ends
										i$Projection.addProperty("metadata.FileUrlToken", 1);
										i$Projection.addProperty("metadata.FileName", 1);
										i$Projection.addProperty("metadata.FileSize", 1);
										i$Projection.addProperty("metadata.FileExtn", 1);
										i$Projection.addProperty("metadata.DocSubGrpID1", 1);
										i$Projection.addProperty("metadata.LinkedCustNo", 1);
										i$Projection.addProperty("metadata.isPswrdPrctd", 1);
										i$Projection.addProperty("metadata.fileKey", 1);
										i$Projection.addProperty("metadata.parentFolderId", 1);
										i$Projection.addProperty("metadata.workspaceId", 1);
										i$Projection.addProperty("metadata.parentFolderName", 1);
										i$Projection.addProperty("metadata.initiator", 1);
										i$Projection.addProperty("metadata.UpldSvrDateTime", 1);
										i$Projection.addProperty("metadata.Favourites", 1);
										i$Projection.addProperty("metadata.tags", 1);//#TKS00015 changes
										i$Projection.addProperty("metadata.verNo", 1);
										i$Projection.addProperty("metadata.Favourite", 1);
										i$Projection.addProperty("metadata.remarks", 1);
										i$Projection.addProperty("metadata.authorizer", 1);
										i$Projection.addProperty("_id", 0);
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); 
										db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);
									}
									// Added
									// Projection
									else {
										i$Match = new JsonObject();
										i$Match.addProperty("isCurrVer", "Y");
										i$Match.add("metadata.workspaceId",parser.parse("{'$in':" + accWsArr + "}").getAsJsonObject());
										iRowCnt = db$Ctrl.db$GetCountI(L_Coll_Name, isonMsg, gson.toJson(i$Match)); // #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);// #BVB00016 Added
																						// Projection

									}
								} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
										|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
									if (i$Match != null) {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, gson.toJson(i$Match));// #BVB00016
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match,
												i$Projection, intPgNo, intRecs, sort);
										// Added Projection

									} else {
										iRowCnt = db$Ctrl.db$GetCountI(Coll_Name, isonMsg, "{}");
										db$res = db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
												i$Projection, intPgNo, intRecs, sort);

									}
									// #MAQ00002 end
								}
							} catch (Exception e) {
							}

							i$body.addProperty("iRowCnt", String.valueOf(iRowCnt));
							i$body.add("iRowData", db$res.get("i-body").getAsJsonArray());
							isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_SUCC, "RECORD RETRIEVED SUCCESSFULLY");

							i$body.addProperty("iRowCnt", iRowCnt);
							isonMsg = i$ResM.iHandleArgJson(i$ResM.I_ADDTOJSON, isonMsg, "i-body", i$body);
							return isonMsg;
							// #MAQ00009 ends

						}
						// #MAQ00014 ends
						// #MAQ00004 ends
						else {
							// #MAQ00005 code starts
							if (I$utils.$iStrFuzzyMatch(SOpr1, "Ledger") || I$utils.$iStrFuzzyMatch(SOpr1, "L")) {
								if (i$Match != null) {
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort)); // #BVB00016
								}

								else {
									i$Match = new JsonObject();
									i$Match.addProperty("isCurrVer", "Y");
									return (db$Ctrl.db$GetRows$Sort(L_Coll_Name, isonMsg, i$MaxRow, i$Match,
											i$Projection, intPgNo, intRecs, sort));// #BVB00016 Added
																					// Projection
								}
							} else if (I$utils.$iStrFuzzyMatch(SOpr1, "Master")
									|| I$utils.$iStrFuzzyMatch(SOpr1, "M")) {
								if (i$Match != null)
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, i$Match, i$Projection,
											intPgNo, intRecs, sort));// #BVB00016
																		// Added
																		// Projection
								else
									return (db$Ctrl.db$GetRows$Sort(Coll_Name, isonMsg, i$MaxRow, new JsonObject(),
											i$Projection, intPgNo, intRecs, sort));// #BVB00016

								// #MAQ00005 code ends
							} else {
								isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOWN OPR MODE");
								return isonMsg;
							}
						}
					} else {
						isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "INVALID OR UNKNOW OPERATION");
						return isonMsg;
					}
					;
				} catch (Exception e) {
					isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
							e.getMessage().toString());
					e.printStackTrace();
					return isonMsg;
				}

			} else {
				Sentry$Controller.isonResHTPPStat = HttpStatus.BAD_REQUEST;
				isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR,
						"ACCESS RESTRICTION - USER DOES NOT HAVE RIGHTS");
				return isonMsg;
			}

		} catch (Exception excep) {
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION NOT ALLOWED",
					excep.getMessage().toString());
			excep.printStackTrace();
			return isonMsg;
		}

		return isonMsg;
	};
	
	//#YPR00096 ends

	public JsonObject processMsg(JsonObject isonMsg, JsonObject isonheader, JsonObject isonMapJson) {
		try {
			IDmsSearchController i$dmsSearchCon = new IDmsSearchController();
			IResPreFlightHandler i$resPre = new IResPreFlightHandler();
			isonMsg = i$dmsSearchCon.processMsgHandler(isonMsg, isonheader, isonMapJson);

//			isonMsg = i$resPre.processMsg(i$Annotate, isonMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Failed in Process Msg: " + e.getMessage());
			isonMsg = i$ResM.iHandleResStat(isonMsg, i$ResM.I_ERR, "OPERATION FAILED", e.getMessage().toString());
			e.printStackTrace();

		}

		return isonMsg;

	}

	public JsonObject get$FrmDataSetFilter(JsonObject isonMsg) {
		try {
			return (I$impactoUtil.get$FrmDataSetFilter(isonMsg));

		} catch (Exception e) {
			logger.debug(" Error in get$FrmDataSetFilter -" + e.getMessage());
			return null;
		}
	}

	public IDmsSearchController() {
		// Cons
	}

}
